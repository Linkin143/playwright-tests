"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_super-cards_dist_cards_super-infopane_CardActionTemplates_js"],{7014(e,t,o){o.d(t,{m(){return P}});var i=o(56911),n=o(38493),a=o(60815),r=o(55230),s=o(92011),d=o(56863);class c extends s.L{}class l extends((0,d.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends l{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(!this.readOnly)switch(e.key){case r.Mm:case r.gG:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,t){super.checkedChanged(e,t),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,i.Cg)([(0,n.CF)({attribute:"readonly",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",Array)],h.prototype,"defaultSlottedNodes",void 0);var p=o(37180),u=o(74849),m=o(64187),g=o(60993),b=o(73477),f=o(22131),x=o(50882),y=o(48196),v=o(86856),k=o(7896),$=o(74838),w=o(79288),C=o(46203),z=o(26920),T=o(43774),_=o(95239),S=o(14996),F=o(48751),L=o(41123),M=o(74089),N=o(4283);const I=u.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,m.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${k.O};
        margin: calc(${$.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${w.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${g.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${y.D} / 2) + ${$.vR}) * 2px);
        height: calc(((${y.D} / 2) + ${$.vR}) * 1px);
        background: ${C.le};
        border-radius: calc(${y.D} * 1px);
        border: calc(${z.XA} * 1px) solid ${T.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${C.jM};
        border-color: ${T.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${C.RS};
        border-color: ${T.p4};
    }

    :host(:${b.N}) .switch {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${S.WN};
        border-color: ${S.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${y.D} - (${$.vR} * 5.5)) * 1px);
        width: calc((${y.D} - (${$.vR} * 5.5)) * 1px);
        top: calc(${$.vR} * 1px);
        background: ${F.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${F.l};
        cursor: pointer;
        font-size: ${L.K};
        line-height: ${L.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${F.l};
        font-size: ${L.K};
        line-height: ${L.Z};
        margin-inline-end: calc(${$.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${$.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${M.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${N.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${N.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${M.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${N.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${M.J_};
    }

    :host([aria-checked="true"]:${b.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${S.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new v.t(u.A`
            .checked-indicator {
                left: calc(${$.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${y.D} / 2) + ${$.vR}) + ${$.vR}) * 1px
                );
            }
        `,u.A`
            .checked-indicator {
                right: calc(${$.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${y.D} / 2) + ${$.vR}) + ${$.vR}) * 1px
                );
            }
        `),(0,f.mr)(u.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${x.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${x.A.Field};
                border-color: ${x.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${x.A.HighlightText};
                border-color: ${x.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${x.A.Highlight};
                border-color: ${x.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${x.A.HighlightText};
                border-color: ${x.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${x.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${x.A.Highlight};
            }
            :host(:${b.N}) .switch {
                border-color: ${x.A.Highlight};
                box-shadow: 0 0 0 2px ${x.A.Field},
                    0 0 0 4px ${x.A.FieldText};
            }
            :host([aria-checked="true"]:${b.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${x.A.Field},
                    0 0 0 4px ${x.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${x.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${x.A.Field};
                border-color: ${x.A.GrayText};
            }
            .status-message,
            .label {
                color: ${x.A.FieldText};
            }
        `));var D=o(96950),R=o(82774),B=o(18893);const E=function(e={}){return D.qy`
        <template
            role="switch"
            aria-checked="${e=>e.checked}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            tabindex="${e=>e.disabled?null:0}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <label
                part="label"
                class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,R.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,B.R)(e.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:D.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),P=class extends h{}.compose({name:`${p.c.prefix}-switch`,template:E,styles:I})},8344(e,t,o){o.d(t,{$(){return i}});var i,n=o(58792);!function(e){let t,o,i,a,r,s,d,c,l,h;e.ImageSize={TopicCardImageStandardDimensions:{height:80,width:80},ContentCardImageStandardDimensions:{height:68,width:68},ContentCardProviderImgStandardDimensions:{height:16,width:16},SuggestionCardImgStandardDimensions:{height:42,width:42}},e.topicCardBackupImageUrl="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAtCmK3.img",e.informationCardAutosMarketplaceToggle="autosMarketplaceToggle",e.informationCardBoostToggle="boostToggle",e.informationCardBingShoppingToggle="bingShoppingToggle",e.informationCardCommunityToggle="communityToggle",e.informationCardDonationToggle="donationToggle",e.informationCardMoneyToggle="moneyToggle",e.informationCardCryptoToggle="cryptoToggle",e.informationCardDailyBriefToggle="dailyBriefToggle",e.informationCardDailyWonderToggle="dailyWonderToggle",e.informationCardMarketBriefToggle="marketBriefToggle",e.informationCardSportsToggle="sportsToggle",e.informationCardEsportsToggle="esportsToggle",e.informationCardWeatherToggle="weatherToggle",e.informationCardPrismFeedToggle="prismFeedToggle",e.informationCardRecipeToggle="recipeToggle",e.informationCardRewardsToggle="rewardsToggle",e.informationCardTravelToggle="travelToggle",e.informationCardTrafficToggle="trafficToggle",e.informationCardHoroscopeToggle="horoscopeToggle",e.informationCardOnThisDayToggle="onThisDayToggle",e.informationCardElectionsToggle="electionsToggle",e.informationCardRealEstateToggle="realEstateToggle",e.informationCardEntertainmentToggle="EntertainmentToggle",e.informationCardTrendingSearchToggle="trendingSearchToggle",e.informationCardMangaToggle="mangaToggle",e.informationCardSavingsToggle="savingsToggle",e.informationCardRichCalendarToggle="richCalendarToggle",e.informationCardCopilotToggle="copilotToggle",e.feedSettingReactionsToggle="reactionsToggle",e.feedSettingCommentsToggle="commentsToggle",e.productivitySettingMicrosoftFeedCardToggle="microsoftFeedCardToggle",e.gamingSettingConnectToXboxToggle="connectToXboxToggle",e.gamingSettingGamingCardsToggle="gamingCardsToggle",e.gamingSettingCasualGamesCardToggle="casualGamesCardToggle",e.informationCardCasualGamesToggle="casualGamesToggle",e.linkedInCardToggle="linkedInCardToggle",e.informationCardHealthToggle="healthCardToggle",e.personalizedOffersCardToggle="personalizedOffersCardToggle",e.informationCardTopStoriesToggle="topStoriesToggle",e.trendingNewsToggle="trendingNewsToggle",e.hotListToggle="hotListToggle",e.groceryCardToggle="groceryToggle",e.marketPlaceCardToggle="marketPlaceToggle",e.contentRecommendationsToggle="contentRecommendationsToggle",e.localDayToggle="localDayToggle",e.momentInTimeToggle="momentInTimeToggle",e.cegrowthToggle="cegrowthToggle",e.pollsToggle="pollsToggle",e.videoCarouselToggle="videoCarouselToggle",e.webNewsCarouselToggle="webNewsCarouselToggle",e.videoShoppingToggle="videoShoppingToggle",e.recommendedSearchToggle="recommendedSearchToggle",e.topCommentsToggle="topCommentsToggle",e.localNewsToggle="localNewsToggle",e.defaultToastNotificationTimeoutMs=3e3,e.sectionVisibilityBufferPx=25,e.sidePaneLayoutResponsiveWidth=611,e.stickySearchHeights={c1:66,c2:82,default:100},e.searchBoxHalfHeight=70,e.defaultStickyHeaderHeightPx=158,e.oneColumnStickyHeaderHeightPx=50,e.sectionIds={followedInterests:"followed-interests",followedPublishers:"followed-publishers",recommendedTopics:"recommended-topics",discoverInterests:"discover-interests",savedStories:"saved-stories",mutedPublishers:"muted-publishers",readStories:"read-stories",tuneFeed:"tune-feed",notification:"notification",settings:"settings-root",feedSettings:"feed-settings-root",refreshPage:"refresh-page",hiddenTopics:"hidden-topics",followedList:"followed-list",blockedList:"blocked-list"},e.sdSettingsSectionIds={root:"settings-root",Sports:"sports-settings",Esports:"esports-settings",Weather:"weather-settings",CasualGamesCard:"casualGames-settings",Finance:"finance-settings",Crypto:"crypto-settings",DailyBrief:"dailyBrief-settings",DailyWonder:"dailyWonder-settings",MarketBrief:"marketBrief-settings",Shopping:"shopping-settings",Traffic:"traffic-settings",Market:"market-settings",Horoscope:"horoscope-settings",HotList:"hot-list-settings",Travel:"travel-settings",Recipe:"recipe-settings",Rewards:"rewards-settings",PrismFeed:"prismFeed-settings",OnThisDay:"on-this-day",AutosMarketplace:"autos-marketplace-settings",GenericElection:"elections-settings",Health:"health-settings",TopStories:"top-stories-settings",TrendingNews:"trending-news-settings",Grocery:"grocery-settings",PersonalizedOffers:"personalized-offers-settings",MarketPlace:"marketPlace-settings",LinkedInCard:"linkedin-settings",ContentRecommendations:"content-recommendations-settings",LocalDay:"localDay-settings",MomentInTime:"moment-in-time-settings",Polls:"polls-settings",RealEstate:"real-estate-settings",cegrowth:"cegrowth-settings",VideoCarousel:"video-carousel-settings",WebNewsCarousel:"web-news-carousel-settings",VideoShopping:"video-shopping-settings",RecommendedSearch:"recommended-search-settings",TrendingSearch:"trending-search-settings",Manga:"manga-settings",Boost:"boost-settings",Savings:"savings-settings",Community:"community-settings",Entertainment:"entertainment-premier-settings",LocalNews:"local-news-settings",RichCalendar:"rich-calendar-settings",Donation:"donation-settings",TopComments:"topcomments-settings",Copilot:"copilot-settings"},e.productivitySettingsSectionIds={root:"productivity-settings-root",MicrosoftFeedCard:"recommended-documents-settings"},e.feedSettingsSectionIds={root:"feed-settings-root",Reactions:"reactions-settings",Comments:"comments-settings"},e.gamingSettingsSectionIds={root:"gaming-settings-root",ConnectToXbox:"connect-to-xbox-settings",GamingCards:"gaming-cards-settings"},e.gamingInlineSettingsSectionIds={CasualGamesCard:"casual-games-settings"},e.accountLinkingSettingsSectionIds={root:"account-linking-settings-root",PersonalAccount:"personal-account-settings"},e.privacySettingsSectionIds={privacy:"privacy"},function(e){e.MyInterests="MyInterests",e.MySaves="MySaves",e.History="History",e.Setting="Setting",e.AADSetting="AADSetting",e.Personalize="Personalize",e.Notification="Notification"}(t=e.PageType||(e.PageType={})),e.defaultSelectedSection={Personalize:e.sectionIds.discoverInterests,MyInterests:e.sectionIds.discoverInterests,AADSetting:e.accountLinkingSettingsSectionIds.root,Setting:(0,n.rA)().IsChinaCompliance?e.sdSettingsSectionIds.root:e.sdSettingsSectionIds.Market},function(e){e.Weather="Weather",e.CasualGamesCard="CasualGamesCard",e.Sports="Sports",e.Esports="Esports",e.Finance="Finance",e.Crypto="Crypto",e.DailyBrief="DailyBrief",e.DailyWonder="DailyWonder",e.MarketBrief="MarketBrief",e.Shopping="Shopping",e.Traffic="Traffic",e.Horoscope="Horoscope",e.HotList="HotList",e.Travel="Travel",e.Recipe="Recipe",e.Rewards="Rewards",e.PrismFeed="PrismFeed",e.OnThisDay="OnThisDay",e.AutosMarketplace="AutosMarketplace",e.EventSDCardElection="EventSDCardElection",e.Health="Health",e.TopStories="TopStories",e.TrendingNews="TrendingNews",e.Grocery="Grocery",e.PersonalizedOffers="PersonalizedOffers",e.MarketPlace="MarketPlace",e.LinkedInCard="LinkedInCard",e.ContentRecommendations="ContentRecommendations",e.LocalDay="LocalDay",e.MomentInTime="MomentInTime",e.Polls="Polls",e.RealEstate="RealEstate",e.cegrowth="cegrowth",e.VideoCarousel="VideoCarousel",e.WebNewsCarousel="WebNewsCarousel",e.VideoShopping="VideoShopping",e.RecommendedSearch="RecommendedSearch",e.TrendingSearch="TrendingSearch",e.Manga="Manga",e.Boost="Boost",e.Savings="Savings",e.Community="Community",e.Entertainment="Entertainment",e.LocalNews="LocalNews",e.RichCalendar="RichCalendar",e.Donation="Donation",e.TopComments="TopComments",e.Copilot="Copilot"}(o=e.SdSettingCardType||(e.SdSettingCardType={})),function(e){e.MicrosoftFeedCard="MicrosoftFeedCard"}(i=e.ProductivitySettingCardType||(e.ProductivitySettingCardType={})),function(e){e.Reactions="Reactions",e.Comments="Comments"}(a=e.FeedSettingCardType||(e.FeedSettingCardType={})),function(e){e.ConnectToXbox="ConnectToXbox",e.GamingCards="GamingCards"}(r=e.GamingSettingCardType||(e.GamingSettingCardType={})),function(e){e.CasualGamesCard="CasualGamesCard"}(s=e.GamingInlineSettingCardType||(e.GamingInlineSettingCardType={})),function(e){e.PersonalAccount="PersonalAccount"}(d=e.AccountLinkingCardType||(e.AccountLinkingCardType={})),function(e){e.Privacy="privacy"}(c=e.PrivacySettingCardType||(e.PrivacySettingCardType={})),e.SdSettingsOrder=["LinkedInCard","Weather","CasualGamesCard","Finance","Crypto","MarketBrief","Sports","Esports","Traffic","Shopping","VideoShopping","Horoscope","HotList","Travel","Recipe","Rewards","PrismFeed","OnThisDay","EventSDCardElection","Health","AutosMarketplace","RealEstate","Grocery","PersonalizedOffers","MarketPlace","ContentRecommendations","LocalDay","MomentInTime","Polls","cegrowth","TopStories","TrendingNews","LocalNews","DailyWonder","VideoCarousel","WebNewsCarousel","RecommendedSearch","TrendingSearch","Manga","Boost","Savings","Community","Entertainment","RichCalendar","Donation","DailyBrief","TopComments","Copilot"],e.ProductivitySettingsOrder=["MicrosoftFeedCard"],e.FeedSettingsOrder=["Reactions","Comments"],e.GamingSettingsOrder=["ConnectToXbox","GamingCards"],e.GamingInlineSettingsOrder=["CasualGamesCard"],e.PrivacySettingsOrder=["privacy"],e.SettingCardTelemetryMapping={Weather:e.informationCardWeatherToggle,Sports:e.informationCardSportsToggle,Esports:e.informationCardEsportsToggle,Finance:e.informationCardMoneyToggle,Crypto:e.informationCardCryptoToggle,DailyBrief:e.informationCardDailyBriefToggle,DailyWonder:e.informationCardDailyWonderToggle,MarketBrief:e.informationCardMarketBriefToggle,Shopping:e.informationCardBingShoppingToggle,VideoShopping:e.videoShoppingToggle,Travel:e.informationCardTravelToggle,Traffic:e.informationCardTrafficToggle,Recipe:e.informationCardRecipeToggle,Rewards:e.informationCardRewardsToggle,PrismFeed:e.informationCardPrismFeedToggle,Horoscope:e.informationCardHoroscopeToggle,OnThisDay:e.informationCardOnThisDayToggle,EventSDCardElection:e.informationCardElectionsToggle,Health:e.informationCardHealthToggle,AutosMarketplace:e.informationCardAutosMarketplaceToggle,RealEstate:e.informationCardRealEstateToggle,TopStories:e.informationCardTopStoriesToggle,TrendingNews:e.trendingNewsToggle,HotList:e.hotListToggle,Grocery:e.groceryCardToggle,PersonalizedOffers:e.personalizedOffersCardToggle,MarketPlace:e.marketPlaceCardToggle,LinkedInCard:e.linkedInCardToggle,ContentRecommendations:e.contentRecommendationsToggle,LocalDay:e.localDayToggle,MomentInTime:e.momentInTimeToggle,Polls:e.pollsToggle,VideoCarousel:e.videoCarouselToggle,WebNewsCarousel:e.webNewsCarouselToggle,RecommendedSearch:e.recommendedSearchToggle,TrendingSearch:e.informationCardTrendingSearchToggle,Manga:e.informationCardMangaToggle,Boost:e.informationCardBoostToggle,Savings:e.informationCardSavingsToggle,Community:e.informationCardCommunityToggle,Entertainment:e.informationCardEntertainmentToggle,LocalNews:e.localNewsToggle,Donation:e.informationCardDonationToggle,RichCalendar:e.informationCardRichCalendarToggle,cegrowth:e.cegrowthToggle,CasualGamesCard:e.informationCardCasualGamesToggle,TopComments:e.topCommentsToggle,Copilot:e.informationCardCopilotToggle},e.FeedSettingCardTelemetryMapping={Reactions:e.feedSettingReactionsToggle,Comments:e.feedSettingCommentsToggle},e.ProductivitySettingCardTelemetryMapping={MicrosoftFeedCard:e.productivitySettingMicrosoftFeedCardToggle},e.GamingSettingCardTelemetryMapping={ConnectToXbox:e.gamingSettingConnectToXboxToggle,GamingCards:e.gamingSettingGamingCardsToggle},e.GamingInlineSettingCardTelemetryMapping={CasualGamesCard:e.gamingSettingCasualGamesCardToggle},e.PrivacyCardTelemetryMapping={privacy:"privacy"},e.treeItemTag="FLUENT-TREE-ITEM",e.savesHash="#saves",e.publishersHash="#mutedPublishers",e.followedInterestsHash="#followed-interests",e.discoveryInterestsMenuId="menuItem-discover-interests",e.notificationMenuId="menuItem-notification",e.sourceNameTag="source",e.settingsRootMenuId="menuItem-settings-root",e.maxNumberOfResults=6,e.FluentTreeItemTagName="fluent-item-tree",e.MutedPublishersId="mutedpublishers",e.MsftPublishersCardTagName="msft-publishers-card",e.MutedPublishersMenuItemId="menuItem-muted-publishers",e.TopStoriesEnabledId="IsTopStoriesEnabled",function(e){e.Sports="Sports",e.AccountLinking="AccountLinking",e.GamingCards="GamingCards",e.None="None"}(l=e.InlineSettingsType||(e.InlineSettingsType={})),e.ActionBasedSettingCardTargetMap={ContentRecommendations:{targetId:"localperspective",targetType:"beaconpromo"},MomentInTime:{definitionName:"eventcontentcardmit1",targetId:"eventcontentcardmit1",targetType:"TopicFeed"},LinkedInCard:{definitionName:"linkedinnews",targetType:"TopicFeed"},VideoCarousel:{definitionName:"watch-video",targetType:"TopicFeed"},WebNewsCarousel:{definitionName:"webnlnews",targetType:"TopicFeed"},Crypto:{definitionName:"Segment_Finance_CryptoCard",targetType:"StructuredCard"},MarketBrief:{definitionName:"Segment_Finance_MarketBrief",targetType:"StructuredCard"},TopStories:{definitionName:"topstories",targetId:"topstories",targetType:"TopicFeed"},TrendingNews:{definitionName:"trending now",targetId:"trending now",targetType:"TopicFeed"},HotList:{definitionName:"hotlist",targetId:"hotlist",targetType:"TopicFeed"},LocalNews:{targetId:"localnews",targetType:"LocalNewsFeed"},DailyBrief:{definitionName:"DailyBrief",targetId:"DailyBrief",targetType:"DailyBriefing"},TopComments:{definitionName:"topcomments",targetId:"topcomments",targetType:"TopicFeed"}},function(e){e[e.InitialScreen=0]="InitialScreen",e[e.ConfirmationScreen=1]="ConfirmationScreen",e[e.ConfirmationSuccess=2]="ConfirmationSuccess",e[e.ConfirmationFailure=3]="ConfirmationFailure"}(h=e.PrivacySettingState||(e.PrivacySettingState={})),e.widgetsRegionCards=new Set(["Weather","Finance","Sports","Traffic","TopStories"]),e.widgetRegionCardWithDB=new Set(["Weather","Finance","DailyBrief","Traffic","TopStories"])}(i||(i={}))},17288(e,t,o){o.d(t,{F(){return f}});var i=o(56911),n=o(2958),a=o(37180),r=o(7014),s=o(92011),d=o(38493);class c extends s.L{constructor(){super(...arguments),this.preText="",this.postText="",this.enableTwoLine=!1}connectedCallback(){super.connectedCallback(),this.spinnerCompleteTimer=window.setTimeout(()=>{this.spinnerCompletedCallback&&this.spinnerCompletedCallback()},3e3)}disconnectedCallback(){super.disconnectedCallback(),clearTimeout(this.spinnerCompleteTimer),this.spinnerCompleteTimer=void 0}}(0,i.Cg)([(0,d.CF)({attribute:"pre-text"})],c.prototype,"preText",void 0),(0,i.Cg)([(0,d.CF)({attribute:"post-text"})],c.prototype,"postText",void 0),(0,i.Cg)([(0,d.CF)({attribute:"enable-two-line",mode:"boolean"})],c.prototype,"enableTwoLine",void 0);var l=o(12640),h=o(92393),p=o(74849);const u=p.A` .spinner-background{stroke:rgba(0,0,0,0.07)}.meter{stroke:${h.W_}}.checkmark-background{fill:${h.W_}}.checkmark{fill:white}`,m=p.A` .spinner-background{stroke:rgba(255,255,255,0.54)}.meter{stroke:white}.checkmark-background{fill:white}.checkmark{fill:black}`,g=p.A` :host{display:flex;flex-direction:column;align-items:center}:host([card-size="_1x_1y"]) .text,:host([card-size="_2x_1y"]) .text,:host([card-size="0.5u"]) .text{display:none}:host([card-size="_1x_1y"]) svg,:host([card-size="_2x_1y"]) svg,:host([card-size="0.5u"]) svg{height:30px;width:30px}:host(.check-icon[card-size="_1x_1y"]),:host(.check-icon[card-size="_2x_1y"]),:host(.check-icon[card-size="0.5u"]){padding-top:0;padding-bottom:11px}svg{aspect-ratio:1 / 1;height:auto;margin:auto;width:var(--animated-spinner-size,48px)}.spinner-background{fill:none;stroke-width:2.5px}.meter{animation:spinner 3s linear;fill:none;stroke-dasharray:150;stroke-dashoffset:0;stroke-linecap:round;stroke-width:2.5px;transform:rotate(-90deg);transform-origin:50% 50%}@keyframes spinner{from{stroke-dashoffset:150}to{stroke-dashoffset:0}}.checkmark-background{animation:checkmark-background 4s linear;transform-origin:50% 50%}@keyframes checkmark-background{0%,75%{fill-opacity:0}78%{fill-opacity:1}}.checkmark{animation:checkmark 4s linear;animation-fill-mode:both;transform:translate(8px,8px);transform-origin:50% 50%}@keyframes checkmark{0%,75%{transform:scale(0) translate(8px,8px)}85%{transform:scale(1.25) translate(8px,8px)}100%{transform:scale(1) translate(8px,8px)}}span{display:block;font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);overflow:hidden;position:absolute;text-overflow:ellipsis;white-space:nowrap;width:236px}.two-line span{white-space:unset;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.two-line.text{height:40px}.text{height:20px;padding-top:8px;width:236px}.pre-text{animation:fadeout 1s;animation-delay:3s;animation-fill-mode:both}.post-text{animation:fadein 1s;animation-delay:3s;animation-fill-mode:both}@keyframes fadein{from{opacity:0}to{opacity:1}}@keyframes fadeout{from{opacity:1}to{opacity:0}}@media (-ms-high-contrast:active),(prefers-contrast:more){${u}
    }
`.withBehaviors(new l.N(u,m)),b=o(96950).qy`<svg part="icon" viewBox="0 0 48 48"><circle class="spinner-background" cx="24" cy="24" r="21.5" /><circle class="meter" cx="24" cy="24" r="21.5" /><circle class="checkmark-background" cx="24" cy="24" r="24"/><path class="checkmark" d="M11.3333 22.1144L6.27614 17.0572C5.75544 16.5365 4.91122 16.5365 4.39052 17.0572C3.86983 17.5779 3.86983 18.4221 4.39052 18.9428L10.3905 24.9428C10.9112 25.4635 11.7554 25.4635 12.2761 24.9428L26.9428 10.2761C27.4635 9.75545 27.4635 8.91122 26.9428 8.39052C26.4221 7.86983 25.5779 7.86983 25.0572 8.39052L11.3333 22.1144Z"/></svg><div part="text" class="text ${e=>e.enableTwoLine?"two-line":""}"><span part="pre-text"class="pre-text" role="alert">${e=>e.preText}</span><span part="post-text" class="post-text">${e=>e.postText}</span></div>`;let f=class extends c{};f=(0,i.Cg)([(0,s.E)({name:"msn-animated-done-spinner",template:b,styles:g})],f),n.m.define(a.c.registry),r.m.define(a.c.registry)},29995(e,t,o){o.d(t,{M(){return s}});var i=o(96950),n=o(60402),a=o(82774),r=o(35106);function s(e={}){return i.qy`
        <a
            class="control"
            part="control"
            download="${e=>e.download}"
            href="${e=>e.href}"
            hreflang="${e=>e.hreflang}"
            ping="${e=>e.ping}"
            referrerpolicy="${e=>e.referrerpolicy}"
            rel="${e=>e.rel}"
            target="${e=>e.target}"
            type="${e=>e.type}"
            aria-atomic="${e=>e.ariaAtomic}"
            aria-busy="${e=>e.ariaBusy}"
            aria-controls="${e=>e.ariaControls}"
            aria-current="${e=>e.ariaCurrent}"
            aria-describedby="${e=>e.ariaDescribedby}"
            aria-details="${e=>e.ariaDetails}"
            aria-disabled="${e=>e.ariaDisabled}"
            aria-errormessage="${e=>e.ariaErrormessage}"
            aria-expanded="${e=>e.ariaExpanded}"
            aria-flowto="${e=>e.ariaFlowto}"
            aria-haspopup="${e=>e.ariaHaspopup}"
            aria-hidden="${e=>e.ariaHidden}"
            aria-invalid="${e=>e.ariaInvalid}"
            aria-keyshortcuts="${e=>e.ariaKeyshortcuts}"
            aria-label="${e=>e.ariaLabel}"
            aria-labelledby="${e=>e.ariaLabelledby}"
            aria-live="${e=>e.ariaLive}"
            aria-owns="${e=>e.ariaOwns}"
            aria-relevant="${e=>e.ariaRelevant}"
            aria-roledescription="${e=>e.ariaRoledescription}"
            ${(0,n.K)("control")}
        >
            ${(0,r.LT)(e)}
            <span class="content" part="content">
                <slot ${(0,a.e)("defaultSlottedContent")}></slot>
            </span>
            ${(0,r.aO)(e)}
        </a>
    `}},32785(e,t,o){o.d(t,{L(){return r}});var i=o(75688),n=o(96950),a=o(69259);i.k;const r=n.qy`<style>msn-hide-story-card.ad-feedback-confirmation { background: var(--hide-story-background); } msn-hide-story-card.ad-feedback-confirmation fluent-button { width: 150px; text-align: center; display: block; margin: 54px auto 8px; } msn-hide-story-card.ad-feedback-confirmation fluent-button::part(control) { width: 100%; letter-spacing: inherit; line-height: inherit; word-spacing: inherit; } msn-hide-story-card.ad-feedback-confirmation fluent-button:hover { background: var(--button-hover-color); } msn-hide-story-card.ad-feedback-confirmation::part(content-region) { margin: 0 auto; text-align: center; padding: 110px 16px 0px 16px; } msn-hide-story-card.ad-feedback-confirmation::part(action-region) { display: block; position: static; margin: 0; padding: 0px 16px 16px; }</style><msn-hide-story-card hideStoryTitle=${e=>e.adFeedbackProps.localizedStrings.confirmationText} class="ad-feedback-confirmation">${(0,a.z)(e=>{var t;return!(null!==(t=e.adFeedbackProps)&&void 0!==t&&null!==(t=t.configOptions)&&void 0!==t&&t.enableAdFeedbackV1UpdatePhase1)},n.qy`<fluent-button slot="actions" autofocus appearance="neutral" aria-label=${e=>e.adFeedbackProps.localizedStrings.undoText} title=${e=>e.adFeedbackProps.localizedStrings.undoText} id="Undo" @click=${e=>e.undoHideButtonCallback&&e.undoHideButtonCallback()}>${e=>e.adFeedbackProps.localizedStrings.undoText}</fluent-button>`)}</msn-hide-story-card>`},34768(e,t,o){o.d(t,{F7(){return d},Xt(){return c}});var i=o(6711),n=o(24642),a=o(67860);const r=(0,n.el)(i.DE,i.l2,i.L6,i.tN);function s(e){return t=>{const o=(0,a.xL)(t),n=o>=r(t)?-1:1;return(0,a.FD)(o+n*e(t),(0,i.ro)(t))}}const d=(0,n.kT)(s(i.DE)),c=(0,n.kT)(s(i.l2)),l=(0,n.kT)(s(i.L6)),h=(0,n.kT)(s(i.tN)),p=(0,n.kT)(s(i.SL));(0,n.kT)(e=>({rest:d(e),hover:c(e),active:l(e),focus:h(e),selected:p(e)}))},43774(e,t,o){o.d(t,{p4(){return g},ls(){return b},vA(){return m},nF(){return u}});var i=o(45755),n=o(68009),a=o(95239);const{create:r}=i.G,s=r("neutral-stroke-strong-hover-delta",40),d=r("neutral-stroke-strong-active-delta",16),c=r("neutral-stroke-strong-focus-delta",25);var l=o(31023);const{create:h}=i.G,p=h({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,t,o,i,a,r){const s=(0,n.F)(t),d=e.colorContrast(t,o),c=e.closestIndexOf(d);return{rest:d,hover:e.get(c+s*i),active:e.get(c+s*a),focus:e.get(c+s*r)}}(e(l.r),e(a.p),3,e(s),e(d),e(c))}}),u=h("neutral-stroke-strong-rest",e=>e(p).evaluate(e).rest),m=h("neutral-stroke-strong-hover",e=>e(p).evaluate(e).hover),g=h("neutral-stroke-strong-active",e=>e(p).evaluate(e).active),b=h("neutral-stroke-strong-focus",e=>e(p).evaluate(e).focus)},45899(e,t,o){o.d(t,{m(){return u}});var i=o(37180),n=o(56911),a=o(7511),r=o(38493);class s extends a._{appearanceChanged(e,t){e!==t&&(this.classList.add(t),this.classList.remove(e))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="neutral")}defaultSlottedContentChanged(){const e=this.defaultSlottedContent.filter(e=>e.nodeType===Node.ELEMENT_NODE);1===e.length&&e[0]instanceof SVGElement?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,n.Cg)([r.CF,(0,n.Sn)("design:type",String)],s.prototype,"appearance",void 0);var d=o(74849),c=o(25984),l=o(17767);const h=d.A`
    ${c._9}
`.withBehaviors((0,l.f)("accent",c.Vw),(0,l.f)("hypertext",c.aY),(0,l.f)("lightweight",c.ZI),(0,l.f)("outline",c.LA),(0,l.f)("stealth",c.ss)),p=(0,o(29995).M)(),u=s.compose({name:`${i.c.prefix}-anchor`,template:p,styles:h,shadowOptions:{delegatesFocus:!0}})},56286(e,t,o){o.d(t,{c(){return c}});var i=o(6711),n=o(24642),a=o(55609),r=o(67860);function s(e,t,o,n,s,d){return c=>{const l=(0,a.OB)(e,c),h=(0,r.ud)(c)?-1:1,p=(0,r.A2)(i.oR)(l)(r.HE)(()=>h)((0,r.EC)((0,a.OB)(t,c)))(c),u=(0,r.yB)(e,p)(c),m=(0,a.OB)(o,c),g=(0,a.OB)(n,c),b=(0,a.OB)(s,c),f=(0,a.OB)(d,c);return function(e,t,o,i,n,a,s){const d=e+o*Math.abs(i-n),c=1===o?i<n:o*i>o*n,l=c?e:d,h=c?d:e,p=l+o*a,u=l+o*s;return{rest:(0,r.FD)(l,t),hover:(0,r.FD)(h,t),active:(0,r.FD)(p,t),focus:(0,r.FD)(u,t)}}(u,l,h,m,g,b,f)}}function d(e){return s(i.ro,e,0,0,0,0)}const c=(0,n.sP)(n.TF.rest,(0,n.kT)(d(4.5)));(0,n.sP)(n.TF.rest,(0,n.kT)(d(3)))},60714(e,t,o){o.d(t,{X(){return c}});var i=o(96950),n=o(69259),a=o(17857),r=o(33477),s=o(8344),d=o(17288);o(75688).k,d.F;const c=i.qy`<style>${(0,n.z)(e=>e.enableInstantHide,i.qy` msn-animated-done-spinner[card-size="_1x_1y"].check-icon, msn-animated-done-spinner[card-size="_2x_1y"].check-icon, msn-animated-done-spinner[card-size="0.5u"].check-icon { padding-top: 0; padding-bottom: 16px; } msn-hide-story-card[card-size="_1x_1y"].instant-hide fluent-button:first-of-type, msn-hide-story-card[card-size="_2x_1y"].instant-hide fluent-button:first-of-type, msn-hide-story-card[card-size="0.5u"].instant-hide fluent-button:first-of-type { margin-inline-end: 8px; } msn-hide-story-card[card-size="_1x_1y"].instant-hide fluent-button, msn-hide-story-card[card-size="_2x_1y"].instant-hide fluent-button, msn-hide-story-card[card-size="0.5u"].instant-hide fluent-button { width: 130px; display: inline-flex; margin: 0; box-sizing: border-box; -webkit-box-sizing: border-box; } msn-hide-story-card[card-size="_1x_1y"].hide-feedback.instant-hide::part(content-region), msn-hide-story-card[card-size="_2x_1y"].hide-feedback.instant-hide::part(content-region), msn-hide-story-card[card-size="0.5u"].hide-feedback.instant-hide::part(content-region) { padding-top: 12px; } msn-hide-story-card.instant-hide::part(content-region) { padding-top: 46px; } msn-hide-story-card .check-icon.instant-hide { padding-bottom: 32px; align-items: center; flex-direction: column; } msn-hide-story-card .personalize-text { font-size: var(--type-ramp-base-font-size, 14px); line-height: var(--type-ramp-base-line-height, 20px); margin-top: 20px; text-align: center; padding: 0 20px; } msn-hide-story-card .personalize { color: var(--stealth-button-text-color) } `)} msn-hide-story-card { container-type: inline-size; } msn-hide-story-card[card-size="1u"] { --animated-spinner-size: 18%; } msn-hide-story-card[card-size="_2x_2y"] { --animated-spinner-size: 8.25%; } @container (width<290px) { msn-animated-done-spinner.check-icon { padding: 7% 0px !important; } } @container (width<270px) { msn-animated-done-spinner.check-icon { padding: 5% 0px !important; } } msn-hide-story-card[card-size="_1x_1y"].hide-confirm, msn-hide-story-card[card-size="_2x_1y"].hide-confirm, msn-hide-story-card[card-size="0.5u"].hide-confirm { --heading-line-height: var(--type-ramp-base-line-height, 20px); --heading-font-size: var(--type-ramp-base-font-size, 14px); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback.hide-confirm::part(content-region), msn-hide-story-card[card-size="_2x_1y"].hide-feedback.hide-confirm::part(content-region), msn-hide-story-card[card-size="0.5u"].hide-feedback.hide-confirm::part(content-region) { padding-top: 16px; } msn-hide-story-card.hide-confirm { --heading-line-height: var(--type-ramp-plus-1-line-height); --heading-font-size: var(--type-ramp-plus-1-font-size); } msn-hide-story-card.hide-confirm fluent-button { width: 100%; max-width: 236px; text-align: center; display: block; border-radius: 20px; margin: 0 auto 8px; } msn-hide-story-card.hide-confirm fluent-button::part(control):focus-visible { border: none; box-shadow: none; } msn-hide-story-card fluent-button::part(control) { width: inherit; display: -webkit-box; overflow: hidden; -webkit-box-orient: vertical; text-overflow: ellipsis; } msn-hide-story-card.hide-confirm::part(content-region) { width: 78.67%; margin: 0 auto; text-align: center; padding-top: 38px; } msn-hide-story-card[card-size="0.75u"].hide-confirm::part(content-region) { padding-top: 16px; } msn-hide-story-card::part(heading) { -webkit-line-clamp: var(--heading-max-lines, 3) } msn-hide-story-card::part(action-region) { display: block; position: static; margin: auto; text-align: center; } .check-icon { display: flex; justify-content: center; fill: var(--neutral-foreground-rest); padding-bottom: 36px; } msn-animated-done-spinner.check-icon { padding-top: 20px; padding-bottom: 26px; } msn-animated-done-spinner[card-size="0.75u"].check-icon { padding-top: 8px; padding-bottom: 12px; }</style><msn-hide-story-card class="hide-feedback hide-confirm ${e=>e.enableInstantHide?"instant-hide":""}" hideStoryTitle=${e=>e.hideStoryTitleData.text} data-text=${e=>e.hideStoryTitleData.dataTag} card-size=${e=>e.cardSize} data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.hideStoryCard)||void 0===t?void 0:t.getMetadataTag()}}" role="group" aria-labelledby="heading">${(0,n.z)(e=>!e.enableInstantHide&&e.cardSize!=r.uE._1x_1y&&e.cardSize!=r.uE._2x_1y,i.qy`<div slot="actions" class="check-icon">${i.qy`<svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg"><path d="M19.9999 0C31.0456 0 39.9999 8.9543 39.9999 20C39.9999 31.0457 31.0456 40 19.9999 40C8.95424 40 -6.10352e-05 31.0457 -6.10352e-05 20C-6.10352e-05 8.9543 8.95424 0 19.9999 0ZM28.6338 13.6161C28.1782 13.1605 27.4584 13.1301 26.9676 13.525L26.8661 13.6161L16.7499 23.7322L13.1338 20.1161C12.6457 19.628 11.8542 19.628 11.3661 20.1161C10.9104 20.5717 10.8801 21.2915 11.2749 21.7824L11.3661 21.8839L15.8661 26.3839C16.3217 26.8395 17.0415 26.8699 17.5323 26.475L17.6338 26.3839L28.6338 15.3839C29.122 14.8957 29.122 14.1043 28.6338 13.6161Z"/></svg>`}</div>`)} ${(0,n.z)(e=>e.enableInstantHide,i.qy`<msn-animated-done-spinner slot="actions" class="check-icon" pre-text="${e=>e.blockedAdvertiser?e.feedbackHideAdvertiser:e.hideConfirmationUpdatingFeedText}" post-text="${e=>e.hideConfirmationDoneText}" card-size=${e=>e.cardSize} enable-two-line="${e=>e.showAdFeedback&&e.enableReportAdDialog&&e.blockedAdvertiser}" :spinnerCompletedCallback="${e=>"like-button"===e.entryPoint?e.likeEntryPointSpinnerCompleteCallback:e.cardActionDismissCallback}"></msn-animated-done-spinner>`)} ${(0,n.z)(e=>!e.enableInstantHide,i.qy`<fluent-button slot="actions" aria-label=${e=>e.refreshFeedButtonText} title=${e=>e.refreshFeedButtonText} id="Refresh" @click=${e=>e.refreshFeedCallback&&e.refreshFeedCallback()} data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.refreshFeedButton)||void 0===t?void 0:t.getMetadataTag()}}">${e=>e.refreshFeedButtonText}</fluent-button><fluent-button slot="actions" class="stealth-button" aria-label=${e=>e.personalizeButtonTextData.text} title=${e=>e.personalizeButtonTextData.text} data-text=${e=>e.personalizeButtonTextData.dataTag} id="Personalize" @click=${(e,t)=>e.personalizeButtonCallback&&e.personalizeButtonCallback(h(e.cardActionStatus),t.event)} data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.confirmButton)||void 0===t?void 0:t.getMetadataTag()}}" data-customhandled="true">${e=>e.personalizeButtonTextData.text}</fluent-button>`)} ${(0,n.z)(e=>e.enableInstantHide,i.qy` ${(0,n.z)(e=>!e.showAdFeedback||!e.enableReportAdDialog,i.qy`<fluent-button slot="actions" class="instant-hide" aria-label=${e=>e.personalizeButtonTextData.text} title=${e=>e.personalizeButtonTextData.text} data-text=${e=>e.personalizeButtonTextData.dataTag} id="Personalize" @click=${function(e,t){const o=e.cardActionStatus;if(e.useAlternativeStrings||!e.undoHideButtonCallback||!l(o))return e.personalizeButtonCallback&&e.personalizeButtonCallback(h(e.cardActionStatus),t.event);return e.undoHideButtonCallback()}} data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.confirmButton)||void 0===t?void 0:t.getMetadataTag()}}" data-customhandled="true">${e=>e.personalizeButtonTextData.text}</fluent-button>`)}<fluent-button slot="actions" class="stealth-button instant-hide" aria-label=${e=>e.undoHideButtonText} title=${e=>e.undoHideButtonText} tabindex="0" id="Undo" @click=${e=>e.undoHideButtonCallback&&e.undoHideButtonCallback(void 0,l(e.cardActionStatus,e.enableReportAdDialog))} data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.confirmationUndoButton)||void 0===t?void 0:t.getMetadataTag()}}">${e=>e.undoHideButtonText}</fluent-button>`)}</msn-hide-story-card>`;function l(e,t){if(t)return Boolean(e&(a.J.hidden^a.J.hideAds^a.J.adFeedbackSubmitted));const o=a.J.hide|a.J.hidden,i=a.J.mute|a.J.report|a.J.showFewer|a.J.showMore|a.J.dismiss|a.J.hideAds;return Boolean(e&o)&&!(e&i)}const h=e=>e&a.J.mute?s.$.sectionIds.mutedPublishers:s.$.sectionIds.discoverInterests},64186(e,t,o){o.d(t,{Wl(){return d}});var i=o(6711),n=o(24642),a=o(67860);const r=(0,n.el)(i.DE,i.l2,i.L6,i.tN,i.q,i.oj,i.Ws,i.Mc);function s(e){return t=>{const o=(0,a.xL)(t),n=o>=r(t)?-1:1;return(0,a.FD)(o+n*e(t),(0,i.ro)(t))}}const d=(0,n.kT)(s(i.q)),c=(0,n.kT)(s(i.oj)),l=(0,n.kT)(s(i.Ws)),h=(0,n.kT)(s(i.Mc)),p=(0,n.kT)(s(i.pW));(0,n.kT)(e=>({rest:d(e),hover:c(e),active:l(e),focus:h(e),selected:p(e)}))},75688(e,t,o){o.d(t,{k(){return U}});var i=o(56911),n=o(4731),a=o(37180),r=o(88817),s=o(45899),d=o(73079),c=o(92011),l=o(38493),h=o(60815);class p extends c.L{constructor(){super(...arguments),this.actionAlignment="horizontal",this.isHeadingLoaded=!1}actionsSlottedNodesChanged(){var e,t;const o=null===(e=this.actionsSlottedNodes[0])||void 0===e?void 0:e.children[0];o&&window.setTimeout(()=>{o.focus()},0),null===(t=this.actionsSlottedNodes[0])||void 0===t||t.focus()}headingSlottedNodesChanged(){!this.isHeadingLoaded&&window.setTimeout(()=>{this.isHeadingLoaded=!0},0)}}(0,i.Cg)([(0,l.CF)({attribute:"align-actions"})],p.prototype,"actionAlignment",void 0),(0,i.Cg)([l.CF],p.prototype,"hideStoryTitle",void 0),(0,i.Cg)([h.sH],p.prototype,"actionsSlottedNodes",void 0),(0,i.Cg)([h.sH],p.prototype,"headingSlottedNodes",void 0),(0,i.Cg)([h.sH],p.prototype,"isHeadingLoaded",void 0);var u=o(7040),m=o(55609),g=o(34768),b=o(64186),f=o(56286),x=o(48751),y=o(89580),v=o(86856),k=o(30860),$=o(74849),w=o(64187),C=o(22131),z=o(12640),T=o(50882),_=o(58792),S=o(9307);const F=$.A` :host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item#Undo){right:0}`,L=$.A` :host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item#Undo){left:0}`,M=$.A` :host{--hide-story-background:${(0,u.dR)(()=>k.go)(m.Ay)};
        --button-color: ${(0,g.F7)((0,u.dR)(()=>k.go))(m.Ay)};
        --button-hover-color: ${(0,g.Xt)((0,u.dR)(()=>k.go))(m.Ay)};
        --stealth-button-color: ${(0,b.Wl)((0,u.dR)(()=>k.go))(m.Ay)};
        --stealth-button-text-color: ${(0,f.c)((0,u.k6)(()=>k.go))(m.Ay)};
        --neutral-fill-rest: ${(0,g.F7)((0,u.dR)(()=>k.go))(m.Ay)};
        --neutral-fill-hover: ${(0,g.Xt)((0,u.dR)(()=>k.go))(m.Ay)}}:host(.hide-feedback.instant-hide){${(0,S.zJ)(_.T3.CurrentMarket)?"--hide-story-background: linear-gradient(-90deg, #F6FAFF 2%, #F7FCFF 31.46%, #EAF6FF 97.33%);":"--hide-story-background: linear-gradient(90deg, #F6FAFF 2%, #F7FCFF 31.46%, #EAF6FF 97.33%);"}
    }
`,N=$.A` :host{--hide-story-background:${(0,u.pq)(()=>k.kJ)(m.Ay)};
        --button-color: ${(0,g.F7)((0,u.pq)(()=>k.kJ))(m.Ay)};
        --button-hover-color: ${(0,g.Xt)((0,u.pq)(()=>k.kJ))(m.Ay)};
        --stealth-button-color: ${(0,b.Wl)((0,u.pq)(()=>k.kJ))(m.Ay)};
        --stealth-button-text-color: ${(0,f.c)((0,u.k6)(()=>k.kJ))(m.Ay)};
        --neutral-fill-rest: ${(0,g.F7)((0,u.pq)(()=>k.kJ))(m.Ay)};
        --neutral-fill-hover: ${(0,g.Xt)((0,u.pq)(()=>k.kJ))(m.Ay)};
    }
`,I=$.A` :host{forced-color-adjust:auto}:host(.hide-feedback) ::slotted(fluent-menu-item){border-color:${T.A.ButtonText}}:host(.hide-feedback) ::slotted(fluent-menu-item:hover),:host(.hide-feedback) ::slotted(fluent-menu-item:focus){background-color:${T.A.Highlight};
        color: ${T.A.HighlightText}}:host(.hide-feedback) ::slotted(fluent-menu-item:focus),:host(.hide-feedback) ::slotted(fluent-button:focus){border-color:${T.A.ButtonText};
        box-shadow: 0 0 0 calc((var(--focus-stroke-width) - var(--stroke-width)) * 1px) ${T.A.ButtonText}}:host(.hide-feedback) ::slotted(.stealth-button:hover),:host(.hide-feedback) ::slotted(.stealth-button:focus){color:var(--stealth-button-text-color)}`,D=$.A`
        ${(0,w.V)("flex")} :host{--action-region-padding-top:0;--content-region-padding-top:16px;--content-region-width:236px;box-sizing:border-box;flex-direction:column;height:100%;position:relative;width:100%}:host(.hide-confirm[card-size="_1x_1y"]) .content-region,:host(.hide-confirm[card-size="_2x_1y"]) .content-region,:host(.hide-confirm[card-size="0.5u"]) .content-region{margin-inline:28px}:host(.hide-confirm[card-size="_1x_1y"]) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm[card-size="_1x_1y"]) ::slotted(fluent-button.stealth-button:hover),:host(.hide-confirm[card-size="_2x_1y"]) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm[card-size="_2x_1y"]) ::slotted(fluent-button.stealth-button:hover),:host(.hide-confirm[card-size="0.5u"]) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm[card-size="0.5u"]) ::slotted(fluent-button.stealth-button:hover){background:var(--button-hover-color)}:host(.hide-confirm[card-size="_1x_1y"]) ::slotted(fluent-button),:host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item),:host(.hide-feedback.instant-hide[card-size="_1x_1y"]) ::slotted(fluent-button.stealth-button),:host(.hide-confirm[card-size="_2x_1y"]) ::slotted(fluent-button),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item),:host(.hide-feedback.instant-hide[card-size="_2x_1y"]) ::slotted(fluent-button.stealth-button),:host(.hide-confirm[card-size="0.5u"]) ::slotted(fluent-button),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item),:host(.hide-feedback.instant-hide[card-size="0.5u"]) ::slotted(fluent-button.stealth-button){height:24px;font-size:var(--type-ramp-minus-1-font-size,12px);color:var(--neutral-foreground-rest);background:var(--button-color)}:host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item#Undo){position:absolute;height:18px;width:18px;top:0;margin-inline-end:8px;margin-top:8px;min-width:18px}:host([card-size="_1x_1y"]) .content-region,:host([card-size="_2x_1y"]) .content-region,:host([card-size="0.5u"]) .content-region{padding-top:20px;height:40px;width:232px}:host([card-size="_1x_1y"]) ::slotted(fluent-menu-item),:host([card-size="_2x_1y"]) ::slotted(fluent-menu-item),:host([card-size="0.5u"]) ::slotted(fluent-menu-item){height:24px}:host([card-size="_1x_1y"]) .action-region,:host([card-size="_2x_1y"]) .action-region,:host([card-size="0.5u"]) .action-region{padding-top:10px;padding-bottom:14px}.action-region{display:flex;position:absolute;padding:0 16px 16px;padding-top:var(--action-region-padding-top);justify-content:space-around;bottom:0;width:100%;box-sizing:border-box;align-items:center}:host([align-actions="vertical"]) .action-region{display:block;margin:auto;position:static}.content-region{display:inline-flex;flex-direction:column;align-items:center;padding:16px 16px 0 16px;padding-top:var(--content-region-padding-top);cursor:default}:host([align-actions="vertical"]) .content-region{display:block;margin:auto;text-align:center;width:var(--content-region-width)}.heading,::slotted(.heading){text-decoration:none;color:${x.l};
            font-size: var(--heading-font-size, ${y.Y});
            line-height: var(--heading-line-height, ${y.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,2)}::slotted(fluent-button){margin-bottom:8px;width:48%}:host(.hide-feedback){background:var(--hide-story-background)}:host(.hide-feedback) ::slotted(fluent-menu-item),:host(.hide-confirm) ::slotted(fluent-button){background:var(--button-color);border:calc(var(--stroke-width) * 1px) solid transparent}:host(.hide-feedback) ::slotted(.stealth-button){background:var(--stealth-button-color);color:var(--stealth-button-text-color)}:host(.hide-feedback.instant-hide) ::slotted(.stealth-button){background:transparent}:host(.hide-feedback) ::slotted(fluent-menu-item:hover),:host(.hide-confirm) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm) ::slotted(.stealth-button:hover){background:var(--button-hover-color)}:host(.hide-feedback) ::slotted(fluent-menu-item:focus),:host(.hide-feedback) ::slotted(fluent-button:focus){border:calc(var(--stroke-width) * 1px) solid var(--focus-stroke-outer);box-shadow:0 0 0 calc((var(--focus-stroke-width) - var(--stroke-width)) * 1px) var(--focus-stroke-outer)}:host(.hide-feedback) ::slotted(.stealth-button:hover),:host(.hide-feedback) ::slotted(.stealth-button:focus){background:var(--stealth-button-color)}`.withBehaviors(new v.t(F,L),(0,C.mr)(I),new z.N(M,N));var R=o(96950),B=o(82774),E=o(69259),P=o(10108);const A=R.qy`<div class="content-region" part="content-region" aria-live="assertive"><slot name="heading" ${(0,B.e)({property:"headingSlottedNodes"})}>${(0,E.z)(e=>e.isHeadingLoaded,R.qy`<span class="heading" part="heading" aria-level="2" role="heading">${e=>e.hideStoryTitle}</span>`)}</slot></div><div class="action-region" part="action-region"><slot name="actions" ${(0,B.e)({property:"actionsSlottedNodes",filter:(0,P.Y)("fluent-radio-group, fluent-radio, fluent-button, fluent-anchor, fluent-menu-item")})}></slot></div>`;let U=class extends p{};U=(0,i.Cg)([(0,c.E)({name:"msn-hide-story-card",template:A,styles:D,shadowOptions:{delegatesFocus:!0}})],U),n.m.define(a.c.registry),r.m.define(a.c.registry),s.m.define(a.c.registry),d.m.define(a.c.registry)},88817(e,t,o){o.d(t,{m(){return B}});var i=o(56911),n=o(38493),a=o(60815),r=o(55230),s=o(92011),d=o(56863);class c extends s.L{}class l extends((0,d.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends l{constructor(){super(),this.initialValue="on",this.proxy.setAttribute("type","radio")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}defaultCheckedChanged(){this.$fastController.isConnected&&!this.dirtyChecked&&(this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}connectedCallback(){super.connectedCallback(),this.validate(),"radiogroup"!==this.parentElement?.getAttribute("role")&&null===this.getAttribute("tabindex")&&(this.disabled||this.setAttribute("tabindex","0")),this.checkedAttribute&&(this.dirtyChecked||this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}isInsideRadioGroup(){return null!==this.closest("[role=radiogroup]")}keypressHandler(e){if(e.key!==r.gG)return!0;this.checked||this.readOnly||(this.checked=!0)}clickHandler(e){this.disabled||this.readOnly||this.checked||(this.checked=!0)}}(0,i.Cg)([(0,n.CF)({attribute:"readonly",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",String)],h.prototype,"name",void 0),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",Array)],h.prototype,"defaultSlottedNodes",void 0);var p=o(37180),u=o(74849),m=o(64187),g=o(73477),b=o(60993),f=o(22131),x=o(50882),y=o(48196),v=o(74838),k=o(26920),$=o(43774),w=o(46203),C=o(7896),z=o(48751),T=o(41123),_=o(95239),S=o(14996),F=o(79288);const L=u.A`
    ${(0,m.V)("inline-flex")} :host {
        --input-size: calc((${y.D} / 2) + ${v.vR});
        align-items: center;
        outline: none;
        margin: calc(${v.vR} * 1px) 0;
        ${""} user-select: none;
        position: relative;
        flex-direction: row;
        transition: all 0.2s ease-in-out;
    }

    .control {
        position: relative;
        width: calc(var(--input-size) * 1px);
        height: calc(var(--input-size) * 1px);
        box-sizing: border-box;
        border-radius: 50%;
        border: calc(${k.XA} * 1px) solid ${$.nF};
        background: ${w.le};
        outline: none;
        cursor: pointer;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        font-family: ${C.O};
        color: ${z.l};
        ${""} padding-inline-start: calc(${v.vR} * 2px + 2px);
        margin-inline-end: calc(${v.vR} * 2px + 2px);
        cursor: pointer;
        font-size: ${T.K};
        line-height: ${T.Z};
    }

    .control,
    .checked-indicator {
        flex-shrink: 0;
    }

    .checked-indicator {
        position: absolute;
        top: 5px;
        left: 5px;
        right: 5px;
        bottom: 5px;
        border-radius: 50%;
        display: inline-block;
        background: ${z.l};
        fill: ${z.l};
        opacity: 0;
        pointer-events: none;
    }

    :host(:enabled) .control:hover {
        background: ${w.jM};
        border-color: ${$.vA};
    }

    :host(:enabled) .control:active {
        background: ${w.RS};
        border-color: ${$.p4};
    }

    :host(:${g.N}) .control {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${S.WN};
        border-color: ${S.WN};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${b.Z};
    }

    :host([aria-checked="true"]) .checked-indicator {
        opacity: 1;
    }

    :host([disabled]) {
        opacity: ${F.q};
    }
`.withBehaviors((0,f.mr)(u.A`
            .control {
                forced-color-adjust: none;
                border-color: ${x.A.FieldText};
                background: ${x.A.Field};
            }
            :host(:enabled) .control:hover,
            .control:active {
                border-color: ${x.A.Highlight};
                background: ${x.A.Field};
            }
            :host(:${g.N}) .control {
                border-color: ${x.A.Highlight};
                box-shadow: 0 0 0 2px ${x.A.Field},
                    0 0 0 4px ${x.A.FieldText};
            }
            :host([aria-checked="true"]:${g.N}:enabled) .control {
                border-color: ${x.A.Highlight};
                box-shadow: 0 0 0 2px ${x.A.Field},
                    0 0 0 4px ${x.A.FieldText};
            }
            :host([aria-checked="true"]:enabled) .control:hover,
            .control:active {
                border-color: ${x.A.Highlight};
                background: ${x.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${x.A.Highlight};
                fill: ${x.A.Highlight};
            }
            :host([aria-checked="true"]) .control:hover .checked-indicator {
                background: ${x.A.HighlightText};
                fill: ${x.A.HighlightText};
            }
            :host([disabled]) {
                forced-color-adjust: none;
                opacity: 1;
            }
            :host([disabled]) .label {
                color: ${x.A.GrayText};
            }
            :host([disabled]) .control,
            :host([aria-checked="true"][disabled]) .control:hover,
            .control:active {
                background: ${x.A.Field};
                border-color: ${x.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                fill: ${x.A.GrayText};
                background: ${x.A.GrayText};
            }
        `));var M=o(96950),N=o(82774),I=o(79109),D=o(18893);const R=function(e={}){return M.qy`
        <template
            role="radio"
            aria-checked="${e=>e.checked}"
            aria-required="${e=>e.required}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <div part="control" class="control">
                <slot name="checked-indicator">
                    ${(0,D.R)(e.checkedIndicator)}
                </slot>
            </div>
            <label
                part="label"
                class="${e=>["label",!e.defaultSlottedNodes?.length&&"label__hidden"].filter(Boolean).join(" ")}"
            >
                <slot
                    ${(0,N.e)({property:"defaultSlottedNodes",filter:I.g})}
                ></slot>
            </label>
        </template>
    `}({checkedIndicator:M.qy`
        <div part="checked-indicator" class="checked-indicator"></div>
    `}),B=h.compose({name:`${p.c.prefix}-radio`,template:R,styles:L})},92349(e,t,o){o.d(t,{F(){return c}});var i=o(96950),n=o(69259),a=o(17857),r=o(33477);o(75688).k;const s=i.qy` ${(0,n.z)(e=>e.dislikeButtonText||e.useUpdatedHideStoryStrings,i.qy`<fluent-menu-item tabindex="0" aria-label=${e=>`${e.useUpdatedHideStoryStrings?e.notRelevantButtonText:e.dislikeButtonText} menu item`} title=${e=>e.useUpdatedHideStoryStrings?e.notRelevantButtonText:e.dislikeButtonText} id="DislikeTopic" @change=${e=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus&a.J.showFewer?e.cardActionStatus^a.J.hidden:e.cardActionStatus^a.J.showFewer^a.J.hidden,"ShowFewer",!0,e.cardActionClickHandler,null,!1,void 0,void 0,e.entryPoint)} slot="actions" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.dislikeButton)||void 0===t?void 0:t.getMetadataTag()}}"><div class="menu-item-text">${e=>e.useUpdatedHideStoryStrings?e.notRelevantButtonText:e.dislikeButtonText}</div></fluent-menu-item>`)} ${(0,n.z)(e=>e.useUpdatedHideStoryStrings,i.qy`<fluent-menu-item tabindex="0" aria-label=${e=>`${e.clickbaitButtonText} menu item`} title=${e=>e.clickbaitButtonText} id="DislikeTopic" @change=${e=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus&a.J.showFewer?e.cardActionStatus^a.J.hidden:e.cardActionStatus^a.J.showFewer^a.J.hidden,"ShowFewer",!0,e.cardActionClickHandler,null,!1,void 0,void 0,e.entryPoint)} slot="actions" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.dislikeButton)||void 0===t?void 0:t.getMetadataTag()}}"><div class="menu-item-text">${e=>e.clickbaitButtonText}</div></fluent-menu-item>`)}<fluent-menu-item tabindex="0" aria-label=${e=>e.mutePublisherButtonText} title=${e=>`${e.mutePublisherButtonText} menu item`} id="MutePublisher" @change=${(e,t)=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus&e.cardActionStatus^a.J.mute^a.J.hidden,"Mute",!0,e.cardActionClickHandler,e.providerId,!1,t.event,void 0,e.entryPoint)} slot="actions" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.mutePublisherButton)||void 0===t?void 0:t.getMetadataTag()}}"><div class="menu-item-text">${e=>e.mutePublisherButtonText}</div></fluent-menu-item>${(0,n.z)(e=>!e.useUpdatedHideStoryStrings,i.qy`<fluent-menu-item tabindex="0" aria-label=${e=>`${e.reportButtonText} menu item`} title=${e=>e.reportButtonText} id="Report" @change=${e=>e.openReportDialog&&e.openReportDialog(e.currentCardData)} slot="actions" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.reportButton)||void 0===t?void 0:t.getMetadataTag()}}"><div class="menu-item-text">${e=>e.reportButtonText}</div></fluent-menu-item>`)}
`,d=i.qy`<fluent-menu-item tabindex="0" aria-label=${e=>e.goodRecommendationButtonText} title=${e=>e.goodRecommendationButtonText} id="GoodRecommendation" @change=${e=>e.onGoodRecommendationButtonClick()} slot="actions" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.goodRecommendationButton)||void 0===t?void 0:t.getMetadataTag()}}"><div class="menu-item-text">${e=>e.goodRecommendationButtonText}</div></fluent-menu-item>${(0,n.z)(e=>!e.isFollowingPublisher,i.qy`<fluent-menu-item tabindex="0" aria-label=${e=>e.followPublisherButtonText} title=${e=>e.followPublisherButtonText} id="FollowPublisher" @change=${e=>e.onFollowPublisherButtonClick()} slot="actions" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.followPublisherButton)||void 0===t?void 0:t.getMetadataTag()}}"><div class="menu-item-text">${e=>e.followPublisherButtonText}</div></fluent-menu-item>`)}<fluent-menu-item tabindex="0" aria-label=${e=>e.manageInterestsButtonText} title=${e=>e.manageInterestsButtonText} id="ManageInterests" @change=${e=>e.personalizeButtonCallback&&e.personalizeButtonCallback()} slot="actions" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.manageInterestsButton)||void 0===t?void 0:t.getMetadataTag()}}"><div class="menu-item-text">${e=>e.manageInterestsButtonText}</div></fluent-menu-item>`,c=i.qy`<style>msn-hide-story-card { container-type: inline-size; } msn-hide-story-card.hide-feedback { --heading-line-height: var(--type-ramp-plus-1-line-height); --heading-font-size: var(--type-ramp-plus-1-font-size); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback, msn-hide-story-card[card-size="_2x_1y"].hide-feedback, msn-hide-story-card[card-size="0.5u"].hide-feedback { --heading-line-height: var(--type-ramp-base-line-height, 20px); --heading-font-size: var(--type-ramp-base-font-size, 14px); } msn-hide-story-card[card-size="_1x_1y"] fluent-menu-item#Report, msn-hide-story-card[card-size="0.5u"] fluent-menu-item#Report { display: none; } msn-hide-story-card.hide-feedback fluent-menu-item { width: 78.6%; max-width: 240px; text-align: center; display: block; border-radius: 20px; margin: 0 auto 8px; } msn-hide-story-card[card-size="_1x_1y"].hide-feedback:not(.hide-confirm)::part(content-region), msn-hide-story-card[card-size="_2x_1y"].hide-feedback:not(.hide-confirm)::part(content-region), msn-hide-story-card[card-size="0.5u"].hide-feedback:not(.hide-confirm)::part(content-region) { padding-top: 20px; padding-inline: 20px; } msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo { width: 18px; margin-inline-end: 10px; margin-top: 11px; color: var(--neutral-foreground-rest); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo:hover>svg>path, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo:hover>svg>path, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo:hover>svg>path { transition: all 0.5s ease 0s; d: path(var(--undo-filled-path)); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo svg, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo svg, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo svg { transform: translate(3px, 3px); } msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo.stealth-button:hover, msn-hide-story-card[card-size="_1x_1y"].hide-feedback fluent-menu-item#Undo:focus, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo.stealth-button:hover, msn-hide-story-card[card-size="_2x_1y"].hide-feedback fluent-menu-item#Undo:focus, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo.stealth-button:hover, msn-hide-story-card[card-size="0.5u"].hide-feedback fluent-menu-item#Undo:focus { background: transparent; } msn-hide-story-card[card-size="_1x_1y"] .menu-item-text, msn-hide-story-card[card-size="_2x_1y"] .menu-item-text, msn-hide-story-card[card-size="0.5u"] .menu-item-text { margin-top: 1px; } msn-hide-story-card fluent-menu-item::part(control) { width: 236px; } msn-hide-story-card[card-size="_2x_1y"].hide-feedback::part(content-region) { width: 500px; } msn-hide-story-card.hide-feedback::part(content-region) { width: 78.67%; margin: 0 auto; text-align: center; justify-content: center; --content-region-padding-top: 38px; } msn-hide-story-card[card-size="0.75u"].hide-feedback::part(content-region) { --content-region-padding-top: 24px; } msn-hide-story-card.hide-feedback.has-subtitle::part(content-region) { --content-region-padding-top: 24px; } msn-hide-story-card::part(heading) { -webkit-line-clamp: var(--heading-max-lines, 3) } msn-hide-story-card::part(action-region) { display: block; position: static; margin: auto; } .menu-item-text { margin-top: 5px; padding: 0 8px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }</style><msn-hide-story-card class="hide-feedback ${e=>e.enableInstantHide?"instant-hide":""}" hideStoryTitle=${e=>e.hideStoryTitleData.text} data-text=${e=>e.hideStoryTitleData.dataTag} card-size=${e=>e.cardSize} data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.hideStoryCard)||void 0===t?void 0:t.getMetadataTag()}}" role="group" aria-labelledby="heading"><span class="heading" part="heading" slot="heading" id="heading" role="heading" aria-level="2">${e=>e.hideStoryTitleData.text}</span>${(0,n.z)(e=>"like-button"===e.entryPoint,d)} ${(0,n.z)(e=>"like-button"!==e.entryPoint,s)}<fluent-menu-item tabindex="0" class="stealth-button" aria-label=${e=>`${e.enableInstantHide?e.hideFeedbackCancelText:e.undoHideButtonText} menu item`} title=${e=>e.enableInstantHide?e.hideFeedbackCancelText:e.undoHideButtonText} id="Undo" @keydown=${(e,t)=>{var o,i;if("Enter"!==(null===(o=t.event)||void 0===o?void 0:o.key)&&" "!==(null===(i=t.event)||void 0===i?void 0:i.key))return!0;e.undoHideButtonCallback&&e.undoHideButtonCallback(t.parent)}} @change=${e=>e.undoHideButtonCallback&&e.undoHideButtonCallback()} slot="actions" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.cancelButton)||void 0===t?void 0:t.getMetadataTag()}}" style="--undo-filled-path:'M-0.000976562 0.75C-0.000976562 0.335786 0.334809 0 0.749023 0C1.16324 0 1.49902 0.335786 1.49902 0.75V3.84461L4.17206 1.17157C5.73416 -0.390524 8.26682 -0.390524 9.82891 1.17157C11.391 2.73367 11.391 5.26633 9.82891 6.82843L4.87896 11.7784C4.58607 12.0713 4.1112 12.0713 3.8183 11.7784C3.52541 11.4855 3.52541 11.0106 3.8183 10.7177L8.76825 5.76777C9.74456 4.79146 9.74456 3.20854 8.76825 2.23223C7.79194 1.25592 6.20903 1.25592 5.23272 2.23223L2.96495 4.5H5.24902C5.66324 4.5 5.99902 4.83579 5.99902 5.25C5.99902 5.66421 5.66324 6 5.24902 6H0.849023C0.379581 6 -0.000976562 5.61944 -0.000976562 5.15V0.75Z'";>${(0,n.z)(e=>e.cardSize!=r.uE._1x_1y&&e.cardSize!=r.uE._2x_1y&&e.cardSize!=r.uE._05u,i.qy`<div class="menu-item-text">${e=>e.enableInstantHide?e.hideFeedbackCancelText:e.undoHideButtonText}</div>`)} ${(0,n.z)(e=>e.cardSize==r.uE._1x_1y||e.cardSize==r.uE._2x_1y||e.cardSize==r.uE._05u,i.qy`<svg width="11" height="12" viewBox="0 0 15 16" xmlns="http://www.w3.org/2000/svg"><path d="M0.000976562 0.5C0.000976562 0.223858 0.224834 0 0.500977 0C0.77712 0 1.00098 0.223858 1.00098 0.5V4.34262L4.17202 1.17157C5.73412 -0.390524 8.26678 -0.390524 9.82888 1.17157C11.391 2.73367 11.391 5.26633 9.82888 6.82843L4.80375 11.8536C4.60849 12.0488 4.2919 12.0488 4.09664 11.8536C3.90138 11.6583 3.90138 11.3417 4.09664 11.1464L9.12177 6.12132C10.2933 4.94975 10.2933 3.05025 9.12177 1.87868C7.9502 0.707107 6.0507 0.707107 4.87913 1.87868L1.75781 5H5.50098C5.77712 5 6.00098 5.22386 6.00098 5.5C6.00098 5.77614 5.77712 6 5.50098 6H0.600977C0.269607 6 0.000976562 5.73137 0.000976562 5.4V0.5Z"/></svg>`)}</fluent-menu-item></msn-hide-story-card>`},97637(e,t,o){o.d(t,{j(){return r}});var i=o(96950),n=o(69259),a=o(39957);o(75688).k;const r=i.qy`<style>msn-hide-story-card { container-type: inline-size; } @container (width<290px) or ((width>400px) and (width<592px)) { msn-hide-story-card.report-ad fluent-radio-group { height: fit-content !important; overflow: visible !important; } msn-hide-story-card.report-ad::part(action-region) { margin: 15px 0px 0px 0px !important; } msn-hide-story-card.report-ad .ad-actions-button-container { height: 30% !important; } } @container (width<275px) or ((width>400px) and (width<562px)) { msn-hide-story-card.report-ad::part(action-region) { margin: 10px 0px 0px 0px !important; padding: 0px 14px 14px 21px !important; } msn-hide-story-card.report-ad .ad-actions-button-container { height: 26% !important; } } msn-hide-story-card.report-ad { background: var(--hide-story-background); z-index: 3; } msn-hide-story-card.report-ad::part(content-region) { flex-direction: row; margin: 0; text-align: left; padding: 16px 16px 0px 24px; } msn-hide-story-card.report-ad.block-adv::part(content-region) { text-align: start; padding-block: 17px 2px; padding-inline: 50px 50px; --heading-max-lines: 1; } msn-hide-story-card.report-ad::part(action-region) { display: block; height: 100%; position: static; margin: 26px 0px 0px 0px; padding: 0px 16px 16px 24px; } msn-hide-story-card.report-ad.block-adv::part(action-region) { margin: 0px 0px 0px 0px; } msn-hide-story-card.report-ad fluent-radio-group { padding: 0 4px; height: 144px; overflow-y: auto; } msn-hide-story-card.report-ad.block-adv fluent-radio-group { padding: 0 0px; overflow-y: unset; height: 152px; padding-bottom: 11px; } msn-hide-story-card.report-ad fluent-button { width: 45%; display: inline-block; margin: auto 5px 8px; text-align: center; } msn-hide-story-card.report-ad fluent-radio { padding: 8px 0px 8px 0px; margin: 0; display: flex; } msn-hide-story-card.report-ad.block-adv fluent-radio { padding: 8px 0px 4px 0px; margin: 0; display: inline-flex; align-items: center; gap: 2px; } msn-hide-story-card.report-ad.block-adv fluent-radio::part(label) { display: inline-block; max-width: 211px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; } msn-hide-story-card.report-ad fluent-button::part(content) { text-overflow: ellipsis; overflow: hidden; } msn-hide-story-card.report-ad fluent-button::part(control) { width: 100%; letter-spacing: inherit; line-height: inherit; word-spacing: inherit; } msn-hide-story-card.report-ad .ad-actions-button-container { display: flex; height: 33%; } msn-hide-story-card.report-ad .ad-actions-checkbox-container { display: none; } msn-hide-story-card.report-ad.block-adv .ad-actions-checkbox-container.block-adv { border-top: 0.5px solid rgba(0, 0, 0, 0.08); display: block; padding-top: 6px; padding-bottom: 4px; } msn-hide-story-card.report-ad.block-adv .ad-actions-checkbox-container.block-adv fluent-checkbox::part(label) { display: inline-block; max-width: 211px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; } .svg-row { width: 20px; height: 20px; background-image: url("${e=>{var t;return null===(t=e.adFeedbackProps)||void 0===t?void 0:t.icons.titleIcon}}"); background-size: contain; background-repeat: no-repeat; position: absolute; inset-inline-start: 23px; top: 18px; z-index: 4; } msn-hide-story-card.report-ad.block-adv .ad-actions-button-container { display: flex; position: absolute; bottom: 12px; left: 16px; justify-content: center; align-items: center; height: 32px; margin-top: auto; width: 90%; margin-top: 5px; } msn-hide-story-card.report-ad.block-adv fluent-button.submit, msn-hide-story-card.report-ad.block-adv fluent-button.cancel { flex-basis: 50%; min-width: 0; border-radius: 4px; margin: 0 5px; /* Add margin to create space between buttons */ } msn-hide-story-card.report-ad.block-adv fluent-button.cancel { font-weight: 600; box-shadow: inset 0 0 0 2px var(--neutral-fill-hover); background: var(--neutral-fill-rest); } msn-hide-story-card.report-ad.block-adv fluent-radio.checked::part(control) { border-color: #0078d4; } msn-hide-story-card.report-ad.block-adv fluent-radio.checked::part(checked-indicator) { inset: 2px; background: #0078d4; left: 3px; bottom: 3px; }</style>${(0,n.z)(e=>{var t;return null===(t=e.adFeedbackProps.configOptions)||void 0===t?void 0:t.enableAdBlockAdvertiser},i.qy`<div class="svg-row"></div>`)}<msn-hide-story-card hideStoryTitle=${e=>{const{configOptions:t,localizedStrings:o}=e.adFeedbackProps;return null!=t&&t.enableAdBlockAdvertiser?(null==o?void 0:o.feedbackReportAdTitle)??o.reportIssueTitleText:o.reportIssueTitleText}} title=${e=>{const{configOptions:t,localizedStrings:o}=e.adFeedbackProps;return null!=t&&t.enableAdBlockAdvertiser?(null==o?void 0:o.feedbackReportAdTitle)??o.reportIssueTitleText:o.reportIssueTitleText}} class="report-ad${e=>{var t;return null!==(t=e.adFeedbackProps.configOptions)&&void 0!==t&&t.enableAdBlockAdvertiser?" block-adv":""}}"><fluent-radio-group slot="actions" value="${e=>e.adFeedbackProps.selectedFeedbackType}" @change=${(e,t)=>e.adFeedbackProps.chooseFeedbackOption(t.event)} orientation="vertical">${(0,a.ux)(e=>e.adFeedbackProps.feedbackTypes,i.qy`<fluent-radio value=${e=>e.value} id=${e=>e.value} aria-label=${e=>e.text} title=${e=>e.text} class=${(e,t)=>t.parent.adFeedbackProps.selectedFeedbackType===e.value?"checked":""}>${e=>e.text}</fluent-radio>`)}</fluent-radio-group><div class="ad-actions-checkbox-container${e=>e.adFeedbackProps.disableSubmitButton||1!=e.adFeedbackProps.showBlockAdvertiser?"":" block-adv"}" slot="actions"><fluent-checkbox id="blockAdvertiser" aria-label=${e=>e.adFeedbackProps.localizedStrings.feedbackBlockAdvertiserCheck} title=${e=>e.adFeedbackProps.localizedStrings.feedbackBlockAdvertiserCheck} data-t="${e=>{var t,o;return null===(t=e.adFeedbackProps.generateTelemetryData("adFeedbackBlockAdvertiser"))||void 0===t||null===(o=t.getMetadataTag)||void 0===o?void 0:o.call(t)}}" @change=${(e,t)=>e.adFeedbackProps.toggleBlockAdvertiser(t.event)}>${e=>e.adFeedbackProps.localizedStrings.feedbackBlockAdvertiserCheck}</fluent-checkbox></div><div class="ad-actions-button-container" slot="actions"><fluent-button appearance="accent" class="submit" ?disabled=${e=>e.adFeedbackProps.disableSubmitButton} aria-label=${e=>e.adFeedbackProps.localizedStrings.saveButtonText} title=${e=>e.adFeedbackProps.localizedStrings.saveButtonText} data-t="${e=>{var t,o;return null===(t=e.adFeedbackProps.generateTelemetryData("adFeedbackSubmit"))||void 0===t||null===(o=t.getMetadataTag)||void 0===o?void 0:o.call(t)}}" @click=${e=>e.adFeedbackProps.submitFeedback()}>${e=>e.adFeedbackProps.localizedStrings.saveButtonText}</fluent-button><fluent-button appearance="neutral" class="cancel" aria-label=${e=>e.adFeedbackProps.localizedStrings.cancelText} title=${e=>e.adFeedbackProps.localizedStrings.cancelText} data-t="${e=>{var t,o;return null===(t=e.adFeedbackProps.generateTelemetryData("Cancel"))||void 0===t||null===(o=t.getMetadataTag)||void 0===o?void 0:o.call(t)}}" @click=${e=>e.undoHideButtonCallback&&e.undoHideButtonCallback()}>${e=>e.adFeedbackProps.localizedStrings.cancelText}</fluent-button></div></msn-hide-story-card>`},99649(e,t,o){o.r(t),o.d(t,{CardActionTemplates(){return d}});var i=o(60714),n=o(92349),a=o(97637),r=o(32785),s=o(96950);const d={hideStoryAdFeedbackConfirmationCardTemplate:s.qy`
${r.L}
`,hideStoryConfirmationCardTemplate:s.qy`
${i.X}
`,hideStoryFeedbackCardTemplate:s.qy`
${n.F}
`,hideStoryReportAdCardTemplate:s.qy`
${a.j}
`}}}]);