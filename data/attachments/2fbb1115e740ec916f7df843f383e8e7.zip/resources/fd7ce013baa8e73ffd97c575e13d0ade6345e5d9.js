// © Microsoft Corporation. All rights reserved.
import { getAppEnvironment } from "@msnews/core";
import { waitForAboveTheFoldVisuallyReadyAsync } from "@msnews/milestone-data";
import { Telemetry } from "@msnews/telemetry-contracts";
/**
 * Prefetch manifest bundles (common, experience, vendors, microsoft) after above the fold is visually ready.
 * Fetches manifest from CDN and prefetches the specified bundles.
 */
export function prefetchViewsCoreBundles() {
    waitForAboveTheFoldVisuallyReadyAsync().then(() => {
        const baseUrl = `${getAppEnvironment().AssetsUrl}/bundles/v1/views/latest`;
        const manifestUrl = `${baseUrl}/manifest.json`;
        let status = "error";
        fetch(manifestUrl)
            .then(response => response.json())
            .then((manifest) => {
            const bundlesToPrefetch = ["common.js", "experience.js", "vendors.js", "microsoft.js"];
            bundlesToPrefetch.forEach(bundleKey => {
                const bundleFile = manifest[bundleKey];
                if (bundleFile) {
                    const link = document.createElement("link");
                    link.rel = "prefetch";
                    link.href = `${baseUrl}/${bundleFile}`;
                    link.as = "script";
                    link.crossOrigin = "anonymous";
                    document.head.appendChild(link);
                }
            });
            status = "success";
        })
            .catch(() => {
            status = "error";
        })
            .finally(() => {
            Telemetry.addOrUpdateTmplProperty("prefetchViewsBundles", status);
        });
    });
}
//# sourceMappingURL=prefetchUtils.js.map