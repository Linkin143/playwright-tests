// © Microsoft Corporation. All rights reserved.
import { AdPageMetadataType, appEnvironment, headData, getAdPageMetadataDeviceType } from "@msnews/fundamentals";
const PUBLISHER_NAME = "msn";
const PAGE_TYPE = "homepage";
export function getAdMetadata() {
    const [marketLanguage, marketCountry] = appEnvironment.CurrentMarket?.split("-") || [];
    const clientSettings = headData?.ClientSettings;
    const language = clientSettings?.locale?.language || marketLanguage;
    const deviceType = getAdPageMetadataDeviceType();
    return {
        [AdPageMetadataType.Publisher]: PUBLISHER_NAME,
        [AdPageMetadataType.Language]: language?.toLowerCase(),
        [AdPageMetadataType.Market]: marketCountry?.toLowerCase(),
        [AdPageMetadataType.PageType]: PAGE_TYPE,
        [AdPageMetadataType.DeviceType]: deviceType
    };
}
//# sourceMappingURL=adMetadata.js.map