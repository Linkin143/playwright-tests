(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_render-mode-indicator_dist_index_js"],{7014(e,t,i){"use strict";i.d(t,{m(){return D}});var o=i(56911),n=i(38493),a=i(60815),r=i(55230),s=i(92011),d=i(56863);class l extends s.L{}class c extends((0,d.dx)(l)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class p extends c{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(!this.readOnly)switch(e.key){case r.Mm:case r.gG:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,t){super.checkedChanged(e,t),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,o.Cg)([(0,n.CF)({attribute:"readonly",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],p.prototype,"readOnly",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",Array)],p.prototype,"defaultSlottedNodes",void 0);var h=i(37180),b=i(74849),u=i(64187),g=i(60993),x=i(73477),k=i(22131),m=i(50882),v=i(48196),f=i(86856),w=i(7896),$=i(74838),y=i(79288),C=i(46203),F=i(26920),S=i(43774),R=i(95239),M=i(14996),z=i(48751),B=i(41123),E=i(74089),_=i(4283);const A=b.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,u.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${w.O};
        margin: calc(${$.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${y.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${g.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${v.D} / 2) + ${$.vR}) * 2px);
        height: calc(((${v.D} / 2) + ${$.vR}) * 1px);
        background: ${C.le};
        border-radius: calc(${v.D} * 1px);
        border: calc(${F.XA} * 1px) solid ${S.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${C.jM};
        border-color: ${S.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${C.RS};
        border-color: ${S.p4};
    }

    :host(:${x.N}) .switch {
        box-shadow: 0 0 0 2px ${R.p}, 0 0 0 4px ${M.WN};
        border-color: ${M.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${v.D} - (${$.vR} * 5.5)) * 1px);
        width: calc((${v.D} - (${$.vR} * 5.5)) * 1px);
        top: calc(${$.vR} * 1px);
        background: ${z.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${z.l};
        cursor: pointer;
        font-size: ${B.K};
        line-height: ${B.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${z.l};
        font-size: ${B.K};
        line-height: ${B.Z};
        margin-inline-end: calc(${$.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${$.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${E.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${_.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${_.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${E.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${_.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${E.J_};
    }

    :host([aria-checked="true"]:${x.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${R.p}, 0 0 0 4px ${M.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new f.t(b.A`
            .checked-indicator {
                left: calc(${$.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${v.D} / 2) + ${$.vR}) + ${$.vR}) * 1px
                );
            }
        `,b.A`
            .checked-indicator {
                right: calc(${$.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${v.D} / 2) + ${$.vR}) + ${$.vR}) * 1px
                );
            }
        `),(0,k.mr)(b.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${m.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${m.A.Field};
                border-color: ${m.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${m.A.HighlightText};
                border-color: ${m.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${m.A.Highlight};
                border-color: ${m.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${m.A.HighlightText};
                border-color: ${m.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${m.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${m.A.Highlight};
            }
            :host(:${x.N}) .switch {
                border-color: ${m.A.Highlight};
                box-shadow: 0 0 0 2px ${m.A.Field},
                    0 0 0 4px ${m.A.FieldText};
            }
            :host([aria-checked="true"]:${x.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${m.A.Field},
                    0 0 0 4px ${m.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${m.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${m.A.Field};
                border-color: ${m.A.GrayText};
            }
            .status-message,
            .label {
                color: ${m.A.FieldText};
            }
        `));var O=i(96950),L=i(82774),U=i(18893);const I=function(e={}){return O.qy`
        <template
            role="switch"
            aria-checked="${e=>e.checked}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            tabindex="${e=>e.disabled?null:0}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <label
                part="label"
                class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,L.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,U.R)(e.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:O.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),D=class extends p{}.compose({name:`${h.c.prefix}-switch`,template:I,styles:A})},8278(e){e.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M13.78 3.28a.75.75 0 00-1.06-1.06L10.5 4.44V3.25a.75.75 0 00-1.5 0V6.2a.75.75 0 00.8.8H12.75a.75.75 0 000-1.5h-1.19l2.22-2.22zM6.25 13.5a.75.75 0 01-.75-.75v-1.19l-2.22 2.22a.75.75 0 01-1.06-1.06l2.22-2.22H3.25a.75.75 0 010-1.5H6.2a.75.75 0 01.8.8V12.75c0 .41-.34.75-.75.75z"></path></svg>'},37721(e){e.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M10.12 10.83l4.03 4.02a.5.5 0 00.7-.7l-13-13a.5.5 0 10-.7.7l3.23 3.23a6.7 6.7 0 00-2.3 3.08l-.05.15-.01.06s-.08.5.35.61a.5.5 0 00.61-.35L3 8.6a3.02 3.02 0 01.2-.52c.16-.34.4-.8.78-1.26.3-.36.66-.72 1.13-1.02l1.57 1.58a2.5 2.5 0 103.45 3.45zm-.74-.74a1.5 1.5 0 11-1.97-1.97l1.97 1.97zm-3.06-5.9l.85.86C7.43 5.02 7.71 5 8 5c2.04 0 3.29.91 4.03 1.82A5.7 5.7 0 0113 8.6v.02a.5.5 0 00.97-.25v-.02a2.3 2.3 0 00-.06-.18 6.7 6.7 0 00-1.12-1.98A5.95 5.95 0 008 4a6.9 6.9 0 00-1.68.2z"></path></svg>'},43774(e,t,i){"use strict";i.d(t,{p4(){return g},ls(){return x},vA(){return u},nF(){return b}});var o=i(45755),n=i(68009),a=i(95239);const{create:r}=o.G,s=r("neutral-stroke-strong-hover-delta",40),d=r("neutral-stroke-strong-active-delta",16),l=r("neutral-stroke-strong-focus-delta",25);var c=i(31023);const{create:p}=o.G,h=p({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,t,i,o,a,r){const s=(0,n.F)(t),d=e.colorContrast(t,i),l=e.closestIndexOf(d);return{rest:d,hover:e.get(l+s*o),active:e.get(l+s*a),focus:e.get(l+s*r)}}(e(c.r),e(a.p),3,e(s),e(d),e(l))}}),b=p("neutral-stroke-strong-rest",e=>e(h).evaluate(e).rest),u=p("neutral-stroke-strong-hover",e=>e(h).evaluate(e).hover),g=p("neutral-stroke-strong-active",e=>e(h).evaluate(e).active),x=p("neutral-stroke-strong-focus",e=>e(h).evaluate(e).focus)},47452(e,t,i){"use strict";i.d(t,{RenderModeIndicator(){return ee}});var o=i(56911),n=i(74998),a=i(2827),r=i(58792),s=i(15525),d=i(92011),l=i(60815),c=i(84047),p=i(94043),h=i(2171),b=i(26220),u=i(10910),g=i(21297);const x="mockFeedOverride";var k,m,v;!function(e){e.CSR="CSR",e.SSR="SSR",e.SSROnly="SSR Only",e.CSRFallback="CSR Fallback",e.Ruby="Ruby"}(k||(k={})),function(e){e.None="",e.NTP="msedgntp",e.Windows="winp2fptaskbarhover",e.Homepage="hpmsn",e.Sapphire="superappdhp",e.Copilot="cp_msn_news",e.CMC="cp_msn_cmc"}(m||(m={})),function(e){e.Unknown="unknown",e.EdgeChromium="edgeChromium",e.HomePage="homePage",e.Views="views"}(v||(v={}));const f=[19015,19017,20203,34007,34011,34014,34015,34018],w=["ssrenable","csronly","ssronly","prerender","query","istest","rubyopt","wcssr",c.cs];var $;!function(e){e.both="both",e.desktop="desktop",e.mobile="mobile",e.prong="prong"}($||($={}));const y="item",C="spalink:",F="flights:";function S(e){return e.map(e=>null!=e&&e.toString?e.toString():`${e}`).join(" ")}class R extends d.L{constructor(){super(),this.allRenderModeOptions=[],this.isPrerender=!!n.Rb.IsPrerender,this.renderModeOptions=[],this.showCriticalOnly=!1,this.allErrorLogs=[],this.criticalErrorLogs=[],this.showErrorDialog=!1,this.overview="",this.isViewsApp=!1,this.selectedRenderMode="CSR",this.selectedOcid="",this.customSpalinkInput="",this.spalinkExpanded=!1,this.customFlightidInput="",this.flightidExpanded=!1,this.showMockFeedPanel=!1,this.mockFeedInput="",this.mockFeedStatus="",this.hasMockFeed=!1,this.isControlKeyPressed=!1,this.prevErrorCount=0,this.ocidValues={"":{label:"No Ocid",MBApp:void 0,MBId:void 0,type:"both"},msedgntp:{label:"NTP",MBApp:void 0,MBId:void 0,type:"desktop"},winp2fptaskbarhover:{label:"Windows",MBApp:void 0,MBId:void 0,type:"desktop"},hpmsn:{label:"Homepage",MBApp:void 0,MBId:void 0,type:"desktop"},superappdhp:{label:"Sapphire",MBApp:void 0,MBId:void 0,type:"mobile"},cp_msn_news:{label:"Copilot",MBApp:"copilot",MBId:"Android",type:"mobile"},cp_msn_cmc:{label:"CMC",MBApp:void 0,MBId:void 0,type:"desktop"}},this.updateRenderMode=async()=>{if((0,p.S)()){this.renderMode=window.isSSREnabled?"SSR Only":"CSR",this.updateRenderModeOptions(),await(0,u._Z)(this);h.vv.get("__hydrationPromise__")&&(window.isSSRCompleted?this.renderMode="SSR":window.isCSRFallback&&(this.renderMode="CSR Fallback"))}else this.renderMode="SSR Only";(g.gR.isRuby||this.isViewsApp&&(0,a.ns)())&&(this.renderMode="Ruby"),this.updateRenderModeOptions()},this.updateErrorLogHistory=()=>{const e=h.vv.get("__ErrorLogHistory__")??[];Array.isArray(e)&&e.length!==this.prevErrorCount&&(e.length>500||(this.prevErrorCount=e.length,this.allErrorLogs=e.map(S),this.criticalErrorLogs=this.allErrorLogs.filter(e=>f.some(t=>e.includes(`"id":${t}`))),this.overview=`${this.allErrorLogs.length} errors logged on this page, ${this.criticalErrorLogs.length} of them are critical errors!`))},this.beforeChangeRenderMode=e=>{"Ruby"===e.name&&g.gR.updateUserSelection(!0,!0),window.location.href=e.link},this.beforeChangeViewsRenderMode=e=>{const t=new URL(e);window.location.pathname!==t.pathname&&(t.pathname=window.location.pathname,e=t.toString()),this.isControlKeyPressed?window.open(e,"_blank"):window.location.href=e},this.listenForCtrlKeyPress=e=>{e.ctrlKey&&("keydown"===e.type?this.isControlKeyPressed=!0:"keyup"===e.type&&(this.isControlKeyPressed=!1))};try{switch((0,r.rA)().AppType){case"edgeChromium":this.minimized=!1,this.appType="edgeChromium";break;case"homePage":this.minimized="phone"===n.Rb.ClientSettings.deviceFormFactor,this.appType="homePage";break;case"views":this.minimized=!1,this.appType="views",this.isViewsApp=!0;break;default:this.minimized=!1,this.appType="unknown"}}catch(e){}}reloadWithNondicator(){const e=new URL((0,b.$N)());e.searchParams.append("noindicator","true"),location.href=e.toString()}connectedCallback(){super.connectedCallback(),this.initAllRenderModeOptions(),this.updateRenderMode(),this.updateErrorLogHistory(),this.detectCurrentSpalink(),this.detectCurrentFlightid(),this.checkMockFeedOnInit(),this.isViewsApp&&(this.detectCurrentOcid(),window.addEventListener("keydown",this.listenForCtrlKeyPress),window.addEventListener("keyup",this.listenForCtrlKeyPress)),window.addEventListener("ErrorLogHistoryUpdated",this.updateErrorLogHistory),window.addEventListener("HydrationPromiseCreated",this.updateRenderMode)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("ErrorLogHistoryUpdated",this.updateErrorLogHistory),window.removeEventListener("HydrationPromiseCreated",this.updateRenderMode),this.isViewsApp&&(window.removeEventListener("keydown",this.listenForCtrlKeyPress),window.removeEventListener("keyup",this.listenForCtrlKeyPress))}toggleErrorDetailList(e){0===this.allErrorLogs.length?this.showErrorDialog=!1:this.showErrorDialog=void 0!==e?e:!this.showErrorDialog}toggleMinimized(){this.minimized=!this.minimized}toggleErrorFilter(){this.showCriticalOnly=!this.showCriticalOnly}initAllRenderModeOptions(){const e=new URL((0,b.$N)());w.forEach(t=>e.searchParams.delete(t));const t=new URL(e);t.searchParams.append("csronly","true");const i=t.searchParams.getAll(y);t.searchParams.delete(y),i.filter(e=>"should1sUseFdheadQsp:true"!==e).forEach(e=>t.searchParams.append(y,e));const o=new URL(e),n=o.searchParams.getAll(y);null!=n&&n.some(e=>e.includes("should1sUseFdheadQsp"))||o.searchParams.append(y,"should1sUseFdheadQsp:true"),o.searchParams.append("ssrenable","true"),o.searchParams.append("istest","true");const a=new URL(o);if(a.searchParams.append("ssronly","true"),this.isViewsApp&&(a.searchParams.append("wcssr","1"),o.searchParams.append("wcssr","1")),this.allRenderModeOptions=[{name:"CSR",link:t.toString()},{name:"SSR",link:o.toString()},{name:"SSR Only",link:a.toString()}],"edgeChromium"===this.appType){const t=new URL(e);t.searchParams.append("fcruby","1");const i={name:"Ruby",link:t.toString()};this.allRenderModeOptions.push(i)}if(this.isViewsApp){const t=new URL(e);t.searchParams.append(c.cs,"ruby");const i={name:"Ruby",link:t.toString()};this.allRenderModeOptions.push(i)}}updateRenderModeOptions(){var e;null!==(e=(0,b.$N)())&&void 0!==e&&e.includes("localhost")||(this.renderModeOptions=this.allRenderModeOptions.filter(e=>e.name!==this.renderMode))}detectCurrentOcid(){if(this.isViewsApp&&(0,p.S)()){var e;const t=new URL(window.location.href);let i=t.searchParams.get("ocid");if(null!==(e=(0,b.$N)())&&void 0!==e&&e.includes("localhost")){const e=t.searchParams.get("clientSettings");if(e)try{i=JSON.parse(e).ocid}catch(e){}}i&&this.ocidValues[i]?this.selectedOcid=i:this.selectedOcid=""}}detectCurrentSpalink(){const e=(0,b.$N)();if(e){const t=new URL(e).searchParams.getAll(y);for(const e of t)if(e.startsWith(C))return void(this.currentSpalink=e.substring(8));this.currentSpalink=void 0}}getUrlWithOcid(e){var t,i;const o=new URL(window.location.href),n=this.renderMode||"CSR",a=new URL((null===(t=this.allRenderModeOptions.find(e=>e.name===n))||void 0===t?void 0:t.link)||o.toString());a.searchParams.delete("ocid"),a.searchParams.delete("MBApp"),a.searchParams.delete("MBId"),"cp_msn_news"!==e&&(a.searchParams.delete("hasBridge"),a.searchParams.delete("isDarkTheme")),"cp_msn_news"!==e&&"cp_msn_cmc"!==e||a.searchParams.delete(c.cs);const r=this.ocidValues[e];if(!r)return window.location.href;if(null!==(i=(0,b.$N)())&&void 0!==i&&i.includes("localhost")){let t={};const i=a.searchParams.get("clientSettings");if(i)try{t=JSON.parse(i)}catch(e){t={}}t.ocid=e,r&&(t.deviceFormFactor="mobile"===r.type?"phone":"desktop"),a.searchParams.set("clientSettings",JSON.stringify(t))}else a.searchParams.set("ocid",e);return r.MBApp&&a.searchParams.set("MBApp",r.MBApp),r.MBId&&a.searchParams.set("MBId",r.MBId),"cp_msn_news"===e&&(a.searchParams.set("hasBridge","true"),a.searchParams.set("isDarkTheme","false")),a.toString()}detectCurrentFlightid(){const e=(0,b.$N)();if(e){const t=new URL(e).searchParams.getAll(y);for(const e of t)if(e.startsWith(F))return void(this.currentFlightid=e.substring(8));this.currentFlightid=void 0}}getUrlWithFlightid(e){const t=new URL(window.location.href),i=t.searchParams.getAll(y);t.searchParams.delete(y);for(const e of i)e.startsWith(F)||t.searchParams.append(y,e);return t.searchParams.append(y,`${F}${e}`),t.toString()}applyFlightid(e){const t=e.trim();t&&this.beforeChangeViewsRenderMode(this.getUrlWithFlightid(t))}getUrlWithoutFlightid(){const e=new URL(window.location.href),t=e.searchParams.getAll(y);e.searchParams.delete(y);for(const i of t)i.startsWith(F)||e.searchParams.append(y,i);return e.toString()}getUrlWithSpalink(e){const t=new URL(window.location.href),i=t.searchParams.getAll(y);t.searchParams.delete(y);for(const e of i)e.startsWith(C)||t.searchParams.append(y,e);return t.searchParams.append(y,`${C}${e}`),t.toString()}applySpalink(e){const t=e.trim();t&&this.beforeChangeViewsRenderMode(this.getUrlWithSpalink(t))}getUrlWithoutSpalink(){const e=new URL(window.location.href),t=e.searchParams.getAll(y);e.searchParams.delete(y);for(const i of t)i.startsWith(C)||e.searchParams.append(y,i);return e.toString()}toggleSpalinkExpanded(){this.spalinkExpanded=!this.spalinkExpanded}toggleFlightidExpanded(){this.flightidExpanded=!this.flightidExpanded}toggleMockFeedPanel(){this.showMockFeedPanel=!this.showMockFeedPanel,this.showMockFeedPanel&&this.loadMockFeedFromStorage()}loadMockFeedFromStorage(){try{const e=(0,s.Lg)(),t=null==e?void 0:e.getItem(x);t?(this.mockFeedInput=t,this.hasMockFeed=!0,this.mockFeedStatus="Mock feed loaded from storage"):(this.mockFeedInput="",this.hasMockFeed=!1,this.mockFeedStatus="")}catch(e){this.mockFeedStatus="Error loading mock feed"}}saveAndReload(){try{var e,t,i;const o=(0,s.Lg)();if(!o)return void(this.mockFeedStatus="localStorage not available");if(!this.mockFeedInput.trim())return void(this.mockFeedStatus="Please enter feed JSON");const n=JSON.parse(this.mockFeedInput),a=(null==n||null===(e=n.regions)||void 0===e?void 0:e.length)||0,r=(null==n||null===(t=n.sections)||void 0===t?void 0:t.length)||0,d=(null==n||null===(i=n.cardMetadata)||void 0===i?void 0:i.length)||0;a||r||d||(this.mockFeedStatus="Warning: Feed has no regions/sections/cardMetadata. Capture feed after page loads. Saving anyway for debug."),o.setItem(x,this.mockFeedInput),this.hasMockFeed=!0,window.location.reload()}catch(e){this.mockFeedStatus="Invalid JSON format"}}clearMockFeed(){try{const e=(0,s.Lg)();null==e||e.removeItem(x),this.mockFeedInput="",this.hasMockFeed=!1,window.location.reload()}catch(e){this.mockFeedStatus="Error clearing mock feed"}}captureCurrentFeed(){try{var e,t,i;const o=window.__lastRawWpoResponse;if(null==o||null===(e=o.sections)||void 0===e||!e.length)return void(this.mockFeedStatus="No raw WPO response available. Wait for feed to load.");const n=o.sections.length,a=o.sections.map(e=>e.region).join(", "),{authContext:r,locationContextDictionary:s,...d}=o,l=JSON.stringify(d,null,2);this.mockFeedInput=l,this.mockFeedStatus=`Captured (${n} sections: ${a}). Ready to Apply & Reload.`;const c=null===(t=this.shadowRoot)||void 0===t||null===(i=t.querySelector)||void 0===i?void 0:i.call(t,".mock-feed-textarea");c&&(c.value=l)}catch(e){this.mockFeedStatus="Error capturing feed: "+e.message}}handleMockFeedInputChange(e){const t=e.target;this.mockFeedInput=t.value}checkMockFeedOnInit(){try{const e=(0,s.Lg)(),t=null==e?void 0:e.getItem(x);this.hasMockFeed=!!t}catch{}}}(0,o.Cg)([l.sH],R.prototype,"minimized",void 0),(0,o.Cg)([l.sH],R.prototype,"renderMode",void 0),(0,o.Cg)([l.sH],R.prototype,"renderModeOptions",void 0),(0,o.Cg)([l.sH],R.prototype,"showCriticalOnly",void 0),(0,o.Cg)([l.sH],R.prototype,"allErrorLogs",void 0),(0,o.Cg)([l.sH],R.prototype,"criticalErrorLogs",void 0),(0,o.Cg)([l.sH],R.prototype,"showErrorDialog",void 0),(0,o.Cg)([l.sH],R.prototype,"overview",void 0),(0,o.Cg)([l.sH],R.prototype,"isViewsApp",void 0),(0,o.Cg)([l.sH],R.prototype,"selectedRenderMode",void 0),(0,o.Cg)([l.sH],R.prototype,"selectedOcid",void 0),(0,o.Cg)([l.sH],R.prototype,"currentSpalink",void 0),(0,o.Cg)([l.sH],R.prototype,"customSpalinkInput",void 0),(0,o.Cg)([l.sH],R.prototype,"spalinkExpanded",void 0),(0,o.Cg)([l.sH],R.prototype,"currentFlightid",void 0),(0,o.Cg)([l.sH],R.prototype,"customFlightidInput",void 0),(0,o.Cg)([l.sH],R.prototype,"flightidExpanded",void 0),(0,o.Cg)([l.sH],R.prototype,"showMockFeedPanel",void 0),(0,o.Cg)([l.sH],R.prototype,"mockFeedInput",void 0),(0,o.Cg)([l.sH],R.prototype,"mockFeedStatus",void 0),(0,o.Cg)([l.sH],R.prototype,"hasMockFeed",void 0);var M=i(86856),z=i(74849);const B=z.A`
.render-mode-indicator{left:0px}`,E=z.A`
.render-mode-indicator{right:0px}`,_=z.A` .render-mode-indicator{bottom:0;cursor:default;position:fixed;z-index:1000;display:flex;flex-direction:column}.render-mode-indicator-label,.render-mode-option-label{align-items:center;color:white;display:flex;font-size:18px;justify-content:space-between;height:48px;max-height:48px;position:relative;width:270px;box-sizing:border-box;padding:10px;overflow-y:hidden}.render-mode-indicator.minimized .render-mode-indicator-label{width:180px;font-size:12px;height:36px;padding:9px}.render-mode-indicator.minimized .render-mode-option-label{max-height:0px;width:180px;padding:0px}.ocid-options-container{background:#0067B8;align-items:center;color:white;display:flex;flex-direction:column;font-size:16px;width:270px;box-sizing:border-box;padding:8px 10px}.ocid-options-label{margin-bottom:8px;font-weight:500}.ocid-options-buttons{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;width:100%}.ocid-option-link{background:rgba(255,255,255,0.15);border-radius:4px;color:white;cursor:pointer;font-size:12px;font-weight:500;padding:4px 8px;text-decoration:none;transition:background-color 0.2s}.ocid-option-link:hover{background:rgba(255,255,255,0.3);text-decoration:none}.ocid-option-link.selected{background:rgba(255,255,255,0.4);font-weight:bold}.render-mode-indicator.minimized .ocid-options-container{display:none}.expandable-section{--section-bg:#333;--section-bg-active:#222;--section-content-bg:#1a1a1a;--section-focus-color:#fff;width:270px;color:white}.expandable-header{display:flex;justify-content:space-between;align-items:center;padding:0 12px;height:36px;cursor:pointer;font-size:14px;font-weight:500;background:var(--section-bg);border:none;color:white;width:100%;box-sizing:border-box;min-width:0}.expandable-header:hover{filter:brightness(1.1)}.expandable-title{display:flex;align-items:center;gap:6px;overflow:hidden;min-width:0}.expandable-label{flex-shrink:0;white-space:nowrap}.expandable-value{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0;opacity:0.85}.expandable-expand-icon{font-size:10px;opacity:0.8;flex-shrink:0}.expandable-content{padding:12px;display:flex;flex-direction:column;gap:10px;background:var(--section-content-bg)}.expandable-buttons{display:flex;gap:6px;flex-wrap:wrap}.expandable-btn{flex:1;padding:6px 10px;border:none;border-radius:4px;cursor:pointer;font-size:11px;font-weight:500;transition:background-color 0.2s;text-decoration:none;text-align:center;color:white}.expandable-custom-input{display:flex;gap:6px;align-items:center}.expandable-text-field{flex:3;padding:8px;border:1px solid rgba(255,255,255,0.2);border-radius:4px;background:rgba(0,0,0,0.3);color:#fff;font-size:11px;outline:none;min-width:0;box-sizing:border-box}.expandable-text-field:focus{border-color:var(--section-focus-color)}.expandable-text-field::placeholder{color:rgba(255,255,255,0.5)}.render-mode-indicator.minimized .expandable-section{display:none}.expandable-section.active .expandable-header{background:var(--section-bg-active)}.expandable-btn.rolling,.expandable-btn.capture{background:#0078D4}.expandable-btn.rolling:hover,.expandable-btn.capture:hover{background:#106EBE}.expandable-btn.staging,.mock-feed-btn.apply{background:#B146C2}.expandable-btn.staging:hover,.mock-feed-btn.apply:hover{background:#9A3DAA}.expandable-btn.remove,.expandable-btn.clear{background:#D83B01}.expandable-btn.remove:hover,.expandable-btn.clear:hover{background:#C23301}.expandable-btn.apply{background:#107C10}.expandable-btn.apply:hover{background:#0E6B0E}.expandable-btn.save{background:#107C10}.expandable-btn.save:hover{background:#0E6B0E}.spalink-section{--section-bg:#6B4FA0;--section-bg-active:#553C85;--section-content-bg:#4a3570;--section-focus-color:#CE93D8}.flightid-section{--section-bg:#2E7D32;--section-bg-active:#1B5E20;--section-content-bg:#1a5e20;--section-focus-color:#81C784}.mock-feed-section{--section-bg:#00838F;--section-bg-active:#00695C;--section-content-bg:#1a5a5e;--section-focus-color:#4EC9B0}.mock-feed-section .mock-feed-textarea{width:100%;height:150px;padding:8px;border:1px solid rgba(255,255,255,0.2);border-radius:4px;background:rgba(0,0,0,0.3);color:#fff;font-family:'Consolas','Monaco',monospace;font-size:11px;resize:vertical;box-sizing:border-box}.mock-feed-section .mock-feed-textarea:focus{outline:none;border-color:var(--section-focus-color)}.mock-feed-section .mock-feed-textarea::placeholder{color:rgba(255,255,255,0.5)}.mock-feed-section .mock-feed-status{padding:6px 8px;border-radius:4px;background:rgba(0,0,0,0.3);color:#4EC9B0;font-size:11px;text-align:center}.flightid-section .flightid-text-field{flex:none;width:100%}.render-mode-indicator.views-app .render-mode-option{cursor:pointer}.render-mode-indicator.views-app .render-mode-option{flex:1;margin:2px;border:2px solid transparent;transition:all 0.2s ease}.render-mode-indicator.views-app .render-mode-option.current-mode{border:2px solid white;box-shadow:0 0 5px rgba(255,255,255,0.5)}.render-mode-indicator.views-app .render-mode-option-label{font-size:16px;text-align:center;justify-content:center}.render-mode-indicator.csr-indicator > .render-mode-indicator-label,.render-mode-option.csr-indicator > .render-mode-option-label{background:#E4BC11}.render-mode-indicator.csr-fallback-indicator > .render-mode-indicator-label,.render-mode-option.csr-fallback-indicator > .render-mode-option-label{background:#C03401}.render-mode-indicator.ssr-indicator > .render-mode-indicator-label,.render-mode-option.ssr-indicator > .render-mode-option-label{background:#107C10}.render-mode-indicator.ssr-only-indicator > .render-mode-indicator-label,.render-mode-option.ssr-only-indicator > .render-mode-option-label{background:#0078D4}.render-mode-indicator.ruby-indicator > .render-mode-indicator-label,.render-mode-option.ruby-indicator > .render-mode-option-label{background:#B146C2}.render-mode-option{text-decoration:none;cursor:pointer}.render-mode-option:hover .render-mode-option-label{filter:brightness(1.15)}.render-mode-current-label{text-decoration:none;cursor:unset;color:inherit}.render-mode-current-label:visited,.render-mode-current-label:hover,.render-mode-current-label:active{color:inherit}.error-badge{align-items:center;background:#D83B01;border:1px solid #FF9349;border-radius:50% 50%;color:#FFFFFF;display:flex;justify-content:center;margin:-12px;height:24px;position:absolute;top:0px;width:24px;max-width:24px;font-size:10px;right:0px;cursor:pointer}.render-mode-indicator.minimized .prerender-badge{display:none}.prerender-badge{align-items:center;color:#FFF;display:flex;height:18px;justify-content:center;font-size:10px;background:#777;border-radius:9px;padding:0 4px}fluent-dialog.error-dialog::part(control){border:1px solid #FF9349}fluent-dialog.error-dialog .error-detail{height:100%}fluent-dialog.error-dialog .error-detail > .error-header{padding:6px;background:#D83B01;color:#FFFFFF;height:36px;box-sizing:border-box;font-size:14px;display:flex;justify-content:space-between}fluent-dialog.error-dialog .error-detail > .error-header > .error-filter-wrapper{display:flex;justify-content:center;align-items:center;gap:6px}fluent-dialog.error-dialog .error-detail > .error-list{max-height:calc(100% - 36px);max-width:100vw;overflow-y:auto}fluent-dialog.error-dialog .error-detail > .error-list > .error-item{font-size:12px;margin:6px;background:#FCEBEB;color:#000;border-radius:6px;word-wrap:break-word;padding:6px}.control-btn-group{height:24px;display:flex}.control-btn{background:inherit;min-width:unset;width:24px;height:24px;border-radius:4px}.control-btn:hover{background:rgba(255,255,255,0.2)}.control-btn::part(control){padding:0}.control-btn > span[slot="start"]{margin-inline-end:0}.control-btn > span[slot="start"] > svg{fill:#EFEFEF}`.withBehaviors(new M.t(B,E));var A=i(96950),O=i(39957),L=i(69259),U=i(96911),I=i.n(U),D=i(8278),N=i.n(D),H=i(37721),P=i.n(H);const j={CSR:"csr-indicator","CSR Fallback":"csr-fallback-indicator",SSR:"ssr-indicator","SSR Only":"ssr-only-indicator",Ruby:"ruby-indicator"},W=A.qy`<button class="error-badge" title="${e=>e.overview}" aria-label="error badge" @click=${e=>e.toggleErrorDetailList()}>${e=>e.allErrorLogs.length}</button>`,J=A.qy`<fluent-dialog trap-focus="true" modal="true" role="dialog" part="dialog" class="error-dialog" @dismiss=${e=>e.toggleErrorDetailList(!1)}><div class="error-detail"><div class="error-header">${e=>e.overview}<div class="error-filter-wrapper"><span>critical only</span><fluent-switch :checked=${e=>e.showCriticalOnly} @change=${e=>e.toggleErrorFilter()}></fluent-switch></div></div><div class="error-list">${(0,O.ux)(e=>e.showCriticalOnly?e.criticalErrorLogs:e.allErrorLogs,A.qy`<div class="error-item">${e=>e}</div>`)}</div></div></fluent-dialog>`,V=A.qy`<div class="ocid-options-container"><span class="ocid-options-label">OCID Options:</span><div class="ocid-options-buttons">${(0,O.ux)(e=>Object.entries(e.ocidValues),A.qy`<a class="ocid-option-link ${(e,t)=>e[0]===t.parent.selectedOcid?"selected":""}" @click=${(e,t)=>t.parent.beforeChangeViewsRenderMode(t.parent.getUrlWithOcid(e[0]))}>${e=>{return`${t=e[1].type,"desktop"===t?"💻":"mobile"===t?"📱":"prong"===t?"🪟":"💻📱"} ${e[1].label}`;var t}}</a>`)}</div></div>`,T=A.qy`<div class="expandable-section spalink-section ${e=>e.spalinkExpanded?"expanded":""} ${e=>e.currentSpalink?"active":""}"><button type="button" class="expandable-header spalink-header" aria-expanded="${e=>e.spalinkExpanded}" aria-label="${e=>"Spalink section"+(e.currentSpalink?`: ${e.currentSpalink}`:"")}" @click=${e=>e.toggleSpalinkExpanded()}><span class="expandable-title spalink-title"><span class="expandable-label">🔗 Spalink:</span>${(0,L.z)(e=>!!e.currentSpalink,A.qy`<span class="expandable-value" title="${e=>e.currentSpalink}">${e=>e.currentSpalink}</span>`)}</span><span class="expandable-expand-icon spalink-expand-icon">${e=>e.spalinkExpanded?"▼":"▶"}</span></button>${(0,L.z)(e=>e.spalinkExpanded,A.qy`<div class="expandable-content spalink-content"><div class="expandable-buttons spalink-buttons">${(0,L.z)(e=>"rolling"!==e.currentSpalink,A.qy`<a class="expandable-btn spalink-btn rolling" href="${e=>e.getUrlWithSpalink("rolling")}" aria-label="Apply rolling spalink">🔄 Rolling</a>`)} ${(0,L.z)(e=>"staging"!==e.currentSpalink,A.qy`<a class="expandable-btn spalink-btn staging" href="${e=>e.getUrlWithSpalink("staging")}" aria-label="Apply staging spalink">🧪 Staging</a>`)} ${(0,L.z)(e=>!!e.currentSpalink,A.qy`<a class="expandable-btn spalink-btn remove" href="${e=>e.getUrlWithoutSpalink()}" aria-label="Remove current spalink">❌ Remove</a>`)}</div><div class="expandable-custom-input spalink-custom-input"><input type="text" class="expandable-text-field spalink-text-field" placeholder="Enter custom spalink..." aria-label="Custom spalink value" .value=${e=>e.customSpalinkInput} @input=${(e,t)=>(e.customSpalinkInput=t.event.target.value,!0)} @keydown=${(e,t)=>{if("Enter"!==t.event.key)return!0;e.applySpalink(e.customSpalinkInput)}} /><a class="expandable-btn spalink-btn apply" href="${e=>e.customSpalinkInput?e.getUrlWithSpalink(e.customSpalinkInput):"#"}" aria-label="Apply custom spalink">✅ Apply</a></div></div>`)}</div>`,Q=A.qy`<div class="expandable-section flightid-section ${e=>e.flightidExpanded?"expanded":""} ${e=>e.currentFlightid?"active":""}"><button type="button" class="expandable-header flightid-header" aria-expanded="${e=>e.flightidExpanded}" aria-label="${e=>"Flightid section"+(e.currentFlightid?`: ${e.currentFlightid}`:"")}" @click=${e=>e.toggleFlightidExpanded()}><span class="expandable-title flightid-title"><span class="expandable-label">✈️ Flightid:</span>${(0,L.z)(e=>!!e.currentFlightid,A.qy`<span class="expandable-value" title="${e=>e.currentFlightid}">${e=>e.currentFlightid}</span>`)}</span><span class="expandable-expand-icon flightid-expand-icon">${e=>e.flightidExpanded?"▼":"▶"}</span></button>${(0,L.z)(e=>e.flightidExpanded,A.qy`<div class="expandable-content flightid-content"><input type="text" class="expandable-text-field flightid-text-field" placeholder="Enter custom flightid..." aria-label="Custom flightid value" .value=${e=>e.customFlightidInput} @input=${(e,t)=>(e.customFlightidInput=t.event.target.value,!0)} @keydown=${(e,t)=>{if("Enter"!==t.event.key)return!0;e.applyFlightid(e.customFlightidInput)}} /><div class="expandable-buttons flightid-buttons">${(0,L.z)(e=>!!e.currentFlightid,A.qy`<a class="expandable-btn flightid-btn remove" href="${e=>e.getUrlWithoutFlightid()}" aria-label="Remove current flightid">❌ Remove</a>`)}<a class="expandable-btn flightid-btn apply" href="${e=>e.customFlightidInput?e.getUrlWithFlightid(e.customFlightidInput):"#"}" aria-label="Apply custom flightid">✅ Apply</a></div></div>`)}</div>`,q=A.qy`<div class="expandable-section mock-feed-section ${e=>e.showMockFeedPanel?"expanded":""} ${e=>e.hasMockFeed?"active":""}"><div class="expandable-header mock-feed-header" @click=${e=>e.toggleMockFeedPanel()}><span class="expandable-title mock-feed-title">${e=>e.hasMockFeed?"📋 Mock Feed Active":"📋 Mock Feed"}</span><span class="expandable-expand-icon mock-feed-expand-icon">${e=>e.showMockFeedPanel?"▼":"▶"}</span></div>${(0,L.z)(e=>e.showMockFeedPanel,A.qy`<div class="expandable-content mock-feed-content"><div class="expandable-buttons mock-feed-buttons"><button class="expandable-btn mock-feed-btn capture" @click=${e=>e.captureCurrentFeed()}>📥 Capture</button><button class="expandable-btn mock-feed-btn apply" @click=${e=>e.saveAndReload()}>🔄 Apply & Reload</button><button class="expandable-btn mock-feed-btn clear" @click=${e=>e.clearMockFeed()}>🗑️ Clear</button></div><textarea class="mock-feed-textarea" placeholder="Paste feed JSON here, or click 'Capture' to get the current feed response..." .value=${e=>e.mockFeedInput} @input=${(e,t)=>e.handleMockFeedInputChange(t.event)}></textarea>${(0,L.z)(e=>e.mockFeedStatus,A.qy`<div class="mock-feed-status">${e=>e.mockFeedStatus}</div>`)}</div>`)}</div>`,G=A.qy`<div class="render-mode-indicator ${e=>e.renderMode?j[e.renderMode]:""} ${e=>e.minimized?"minimized":""}">${(0,L.z)(e=>e.renderMode,A.qy`<div class="render-mode-indicator-label" title="${e=>`Current render mode is ${e.renderMode}`}"><a href="${window.location.href}" target="_blank" class="render-mode-current-label">${e=>`🚀 Mode: ${e.renderMode}`}</a>${(0,L.z)(e=>"CSR"===e.renderMode,A.qy`<span class="prerender-badge">${e=>e.isPrerender?"prerender":"non-prerender"}</span>`)}<div class="control-btn-group"><fluent-button class="control-btn" title="Hide indicator(refresh)" @click=${e=>e.reloadWithNondicator()}><span slot="start">${A.qy.partial(P())}</span></fluent-button><fluent-button class="control-btn" title="${e=>e.minimized?"Expand indicator":"Collapse indicator"}" @click=${e=>e.toggleMinimized()}>${e=>e.minimized?A.qy`<span slot="start">${A.qy.partial(I())}</span>`:A.qy`<span slot="start">${A.qy.partial(N())}</span>`}</fluent-button></div></div>${(0,L.z)(e=>e.isViewsApp&&!e.minimized,V)} ${(0,L.z)(e=>!!e.allErrorLogs.length,W)} `)} ${(0,O.ux)(e=>e.renderModeOptions,A.qy`<a href="${e=>e.link}" target="_blank" class="render-mode-option ${e=>j[e.name]}" @click=${(e,t)=>t.parent.isViewsApp?t.parent.beforeChangeViewsRenderMode(e.link):t.parent.beforeChangeRenderMode(e)}><div class="render-mode-option-label">${e=>`👉 Please test ${e.name}`}</div></a>`)} ${(0,L.z)(e=>!e.minimized,T)} ${(0,L.z)(e=>!e.minimized,Q)} ${(0,L.z)(e=>!e.minimized,q)} ${(0,L.z)(e=>e.showErrorDialog,J)}</div>`;var K=i(4731),X=i(37180),Y=i(69400),Z=i(7014);K.m.define(X.c.registry),Y.m.define(X.c.registry),Z.m.define(X.c.registry);let ee=class extends R{};ee=(0,o.Cg)([(0,d.E)({name:"render-mode-indicator",template:G,styles:_})],ee)},96911(e){e.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M8.48 2a.75.75 0 000 1.5h2.96L3.5 11.44V8.48a.75.75 0 00-1.5 0v4.67c0 .47.38.85.85.85h4.67a.75.75 0 000-1.5H4.56l7.94-7.94v2.96a.75.75 0 001.5 0V2.85a.85.85 0 00-.85-.85H8.48z"></path></svg>'}}]);