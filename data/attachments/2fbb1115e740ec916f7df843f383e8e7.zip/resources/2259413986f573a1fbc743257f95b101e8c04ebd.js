"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_ruby-coachmark_dist_index_js"],{7014(e,t,r){r.d(t,{m(){return j}});var i=r(56911),o=r(38493),c=r(60815),a=r(55230),s=r(92011),n=r(56863);class l extends s.L{}class d extends((0,n.dx)(l)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends d{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(!this.readOnly)switch(e.key){case a.Mm:case a.gG:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,t){super.checkedChanged(e,t),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,i.Cg)([(0,o.CF)({attribute:"readonly",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,i.Cg)([c.sH,(0,i.Sn)("design:type",Array)],h.prototype,"defaultSlottedNodes",void 0);var u=r(37180),b=r(74849),p=r(64187),g=r(60993),k=r(73477),w=r(22131),v=r(50882),$=r(48196),y=r(86856),x=r(7896),m=r(74838),f=r(79288),F=r(46203),C=r(26920),T=r(43774),_=r(95239),E=r(14996),A=r(48751),S=r(41123),z=r(74089),N=r(4283);const P=b.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,p.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${x.O};
        margin: calc(${m.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${f.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${g.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${$.D} / 2) + ${m.vR}) * 2px);
        height: calc(((${$.D} / 2) + ${m.vR}) * 1px);
        background: ${F.le};
        border-radius: calc(${$.D} * 1px);
        border: calc(${C.XA} * 1px) solid ${T.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${F.jM};
        border-color: ${T.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${F.RS};
        border-color: ${T.p4};
    }

    :host(:${k.N}) .switch {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${E.WN};
        border-color: ${E.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${$.D} - (${m.vR} * 5.5)) * 1px);
        width: calc((${$.D} - (${m.vR} * 5.5)) * 1px);
        top: calc(${m.vR} * 1px);
        background: ${A.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${A.l};
        cursor: pointer;
        font-size: ${S.K};
        line-height: ${S.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${A.l};
        font-size: ${S.K};
        line-height: ${S.Z};
        margin-inline-end: calc(${m.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${m.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${z.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${N.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${N.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${z.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${N.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${z.J_};
    }

    :host([aria-checked="true"]:${k.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${E.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new y.t(b.A`
            .checked-indicator {
                left: calc(${m.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${$.D} / 2) + ${m.vR}) + ${m.vR}) * 1px
                );
            }
        `,b.A`
            .checked-indicator {
                right: calc(${m.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${$.D} / 2) + ${m.vR}) + ${m.vR}) * 1px
                );
            }
        `),(0,w.mr)(b.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${v.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${v.A.Field};
                border-color: ${v.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${v.A.HighlightText};
                border-color: ${v.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${v.A.Highlight};
                border-color: ${v.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${v.A.HighlightText};
                border-color: ${v.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${v.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${v.A.Highlight};
            }
            :host(:${k.N}) .switch {
                border-color: ${v.A.Highlight};
                box-shadow: 0 0 0 2px ${v.A.Field},
                    0 0 0 4px ${v.A.FieldText};
            }
            :host([aria-checked="true"]:${k.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${v.A.Field},
                    0 0 0 4px ${v.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${v.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${v.A.Field};
                border-color: ${v.A.GrayText};
            }
            .status-message,
            .label {
                color: ${v.A.FieldText};
            }
        `));var R=r(96950),B=r(82774),D=r(18893);const I=function(e={}){return R.qy`
        <template
            role="switch"
            aria-checked="${e=>e.checked}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            tabindex="${e=>e.disabled?null:0}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <label
                part="label"
                class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,B.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,D.R)(e.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:R.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),j=class extends h{}.compose({name:`${u.c.prefix}-switch`,template:I,styles:P})},39360(e,t,r){r.d(t,{RubyCoachmarkWC(){return te}});var i=r(56911),o=r(92011),c=r(23429),a=r(60815),s=r(38493),n=r(15525),l=r(99476),d=r(21297),h=r(74845),u=r(22341),b=r(93552);const p="ruby_opt_out_action",g=e=>{const t=(null==e?void 0:e.replaceAll("{entityName}","Copilot Discover"))||"";return(null==t?void 0:t.replaceAll("{entitySuffix}","(Preview)"))||""};var k=r(19359),w=r(85349);function v(){return(0,k.g)("CopilotDiscover_toggle",{type:w.b5.Settings},w.MS.Customize,w.EG.Click,{}).getMetadataTag()??""}var $=r(59575),y=r(45702),x=r(26419),m=r(66198),f=r(30010);function F(e){c.L.enqueue(()=>{!async function(e){const t=await(0,m.TW)(f.u.rubyToggle),r={id:"rubyToggle",group:"Functional",placementSource:"Internal",surfaceModel:{surfaceType:"Coachmark",size:$.fB.Medium,position:{coachmarkAnchor:t||f.u.rubyToggle,anchoringPosition:$.M7.Below,hasPointer:!0,pointerPosition:$.X1.Opposite,elementObserveResize:f.u.settingsButton}},contentModel:{title:g(null==e?void 0:e.classicCoachmarkTitle)||"",description:g(null==e?void 0:e.classicCoachmarkDescription)||"",contentType:y.r.CallToAction}};await(0,x.sn)().then(e=>{e.sendInternalPlacement(r)})}(e)})}var C=r(94043),T=r(77367);class _ extends o.L{constructor(){super(...arguments),this.renderSwitch=!1,this.renderTooltip=!1,this.rubyToggleSwitchTelemetryTag="",this.rubyCoachmarkTelemetryTag="",this.closeButtonTelemetryTag="",this.marketingPage="https://aka.ms/copilot-discover",this.rubyToggleRef=null,this.signInAvailable=!1,this.classicNTPToggle=!1,this.classicCoachmark=!1,this.persistClassicCoachmark=!1,this.superNavToggle=!1,this.enableCopilotToggleColorTrmt=!1,this.isTranslucentBackground=!1,this.__updateObjects=()=>{try{const e=(0,n.Lg)().getObject(p);e&&"true"!==e&&(0,n.Lg)().removeObject(p),(0,n.Lg)().setObject(p,"true")}catch(e){(0,u.vV)(b.T62,`Error setting opt out action: ${e}`)}},this.onRubySwitchChange=()=>{try{this.classicNTPToggle||this.superNavToggle?(d.gR.updateUserSelection(!0),this.classicCoachmark&&(0,h.zK)()):(this.__updateObjects(),d.gR.updateUserSelection(!1))}catch(e){(0,u.vV)(b.T62,`Error updating user selection from ruby switch: ${e}`)}},this.onCloseTooltipClick=()=>{this.renderTooltip=!1},this.i=e=>{const t=e||h.oF;window.setTimeout(()=>{this.renderTooltip=!0,c.L.enqueue(()=>this.renderTooltip)},100),window.setTimeout(()=>{this.renderTooltip=!1,c.L.enqueue(()=>this.renderTooltip)},t)}}rubyToggleRefChanged(){this.rubyToggleRef&&(0,C.S)()&&(0,m.KO)(f.u.rubyToggle,this.rubyToggleRef)}connectedCallback(){super.connectedCallback(),(0,C.S)()&&this.h()}h(){var e;if(this.rubyToggleSwitchTelemetryTag=v(),this.rubyCoachmarkTelemetryTag=(e=this.marketingPage,(0,k.g)("CopilotDiscover_nav",{type:w.b5.ExternalLink},w.MS.Navigate,w.EG.Click,{destinationUrl:e}).getMetadataTag()??""),this.classicCoachmark&&this.classicNTPToggle){this.closeButtonTelemetryTag=(0,k.g)("CopilotDiscover_close",{type:w.b5.Coachmark},w.MS.Close,w.EG.Click,{}).getMetadataTag()??"";const e=(0,n.Lg)().getObject("showClassicCoachmark"),t=!e||"false"!==e||"1"===(0,l.a)().get("fcruby");return t&&this.persistClassicCoachmark&&((0,m.KO)(f.u.rubyToggle,this.rubyToggleRef),F(this.classicCoachmarkStrings),(0,n.Lg)().setObject("showClassicCoachmark","false")),void(t&&T.YT.addOrUpdateTmplProperty("classicCoachmarkShown","1"))}if(this.classicNTPToggle||this.superNavToggle)return;"true"!==(0,n.Lg)().getObject("showRubyCoachmark")&&"1"!==(0,l.a)().get("fcruby")||((0,n.Lg)().setObject("showRubyCoachmark","false"),T.YT.addOrUpdateTmplProperty("rubyCoachmarkShown","1"),this.i())}}(0,i.Cg)([a.sH],_.prototype,"rubyCoachmarkStrings",void 0),(0,i.Cg)([a.sH],_.prototype,"classicCoachmarkStrings",void 0),(0,i.Cg)([a.sH],_.prototype,"renderSwitch",void 0),(0,i.Cg)([a.sH],_.prototype,"renderTooltip",void 0),(0,i.Cg)([a.sH],_.prototype,"rubyToggleSwitchTelemetryTag",void 0),(0,i.Cg)([a.sH],_.prototype,"rubyCoachmarkTelemetryTag",void 0),(0,i.Cg)([a.sH],_.prototype,"closeButtonTelemetryTag",void 0),(0,i.Cg)([a.sH],_.prototype,"marketingPage",void 0),(0,i.Cg)([a.sH],_.prototype,"rubyToggleRef",void 0),(0,i.Cg)([(0,s.CF)({attribute:"signin-available",mode:"boolean"})],_.prototype,"signInAvailable",void 0),(0,i.Cg)([(0,s.CF)({attribute:"classic-ntp-toggle",mode:"boolean"})],_.prototype,"classicNTPToggle",void 0),(0,i.Cg)([(0,s.CF)({attribute:"classic-coachmark",mode:"boolean"})],_.prototype,"classicCoachmark",void 0),(0,i.Cg)([(0,s.CF)({attribute:"persist-classic-coachmark",mode:"boolean"})],_.prototype,"persistClassicCoachmark",void 0),(0,i.Cg)([(0,s.CF)({attribute:"super-nav-toggle",mode:"boolean"})],_.prototype,"superNavToggle",void 0),(0,i.Cg)([(0,s.CF)({attribute:"copilot-toggle-ct1",mode:"boolean"})],_.prototype,"enableCopilotToggleColorTrmt",void 0),(0,i.Cg)([(0,s.CF)({attribute:"translucent-bg",mode:"boolean"})],_.prototype,"isTranslucentBackground",void 0);var E=r(29222),A=r(32257),S=r(74849),z=r(22131),N=r(4126),P=r(77558);const R=S.A`
fluent-switch.ruby-switch[current-checked=false]::part(checked-indicator){background:#FFFFFF}fluent-switch.ruby-switch[current-checked=false]::part(switch){border-color:#6E6E6E}.ruby-switch-label .preview-text{color:#FFFFFF}`,B=S.A`
fluent-switch.ruby-switch[current-checked=true]::part(checked-indicator){background:#FFFFFF}fluent-switch.ruby-switch[current-checked=true]::part(switch){background:#4BA849FF}`.withBehaviors((0,z.G2)(R)),D=S.A`
fluent-switch.ruby-switch[current-checked=true]::part(switch){background:#F6FAFEFF}fluent-switch.ruby-switch[current-checked=true]::part(checked-indicator){background:#1E2024}`,I=S.A`
fluent-switch.ruby-switch[current-checked=true]::part(switch){background:#24282FFF}fluent-switch.ruby-switch[current-checked=true]::part(checked-indicator){background:#FFF}`.withBehaviors((0,z.G2)(D)),j=S.A`
.tooltip-arrow{border-left:1px solid #FFF;border-top:1px solid #FFF}`,M=S.A`
.tooltip-text,.tooltip-link{color:#FFF}.ruby-switch-label{color:var(--header-text-color-override,#FFFFFF)}.ruby-switch-label .preview-text{color:var(--header-text-color-override,#8D9198)}fluent-switch.ruby-switch::part(switch){border:1px solid rgba(0,0,0,0)}.discover-tooltip,.tooltip-arrow{background:#1C2024}`,O=S.A`
.ruby-switch-label .preview-text,.ruby-switch-label .normal-text{color:#1E2024}`,H=S.A`
.ruby-switch-label .preview-text,.ruby-switch-label .normal-text{color:#FFFFFF}fluent-switch.ruby-switch::part(switch){border-color:#4A4A4A}`,L=S.A`
.ruby-switch-label{font-size:16px;padding-block:3px;padding-inline-end:8px}.ruby-switch-label .normal-text,.ruby-switch-label .preview-text{color:#FFFFFF}fluent-switch.ruby-switch[current-checked=true]::part(checked-indicator){background:#FFFFFF}fluent-switch.ruby-switch[current-checked=true]::part(switch){background:#4BA849FF}`.withBehaviors(new N.o("isTranslucentBackground",!0,O),(0,z.G2)(H)),U=S.A`
.ruby-switch-label{padding-inline-end:8px;padding-block:5px}fluent-switch.ruby-switch[current-checked=false]::part(checked-indicator){background:rgba(0,0,0,0.61);border-color:rgba(0,0,0,0.61)}fluent-switch.ruby-switch[current-checked=true]::part(checked-indicator){background:${E.gCv}}fluent-switch.ruby-switch[current-checked=true]::part(switch){border:1px solid rgba(255,255,255,0);background:${E.yCo};
}
`,W=S.A`
.ruby-toggle{margin-inline-end:8px;width:max-content;display:flex}.ruby-switch-label{color:var(--header-text-color-override,#1E2024);font-size:14px;font-weight:400;line-height:20px;gap:4px;margin:0;display:flex;align-items:flex-start;cursor:pointer}.ruby-switch-label .preview-text{color:var(--header-text-color-override,${A.Adh})}.discover-tooltip{z-index:${P.P.Below.toString()};display:flex;width:248px;height:auto;flex-direction:column;border-radius:20px;background:rgb(255,255,255);padding:16px;align-items:flex-start;color:#1E2024;font-size:14px;font-weight:400;line-height:20px;text-wrap:wrap;overflow-wrap:break-word;position:absolute;top:38px;inset-inline-end:4px;border:1px solid transparent;visibility:hidden;opacity:0;--elevation:11;box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(.13 * (2 - var(--background-luminance,1))))}:host([signin-available]) .discover-tooltip{inset-inline-end:62px}.tooltip-arrow{inset-inline-start:77%;background:rgb(255,255,255);border-radius:3px;position:absolute;height:16px;width:16px;top:34px;transform:rotateZ(45deg);visibility:hidden;opacity:0}:host([signin-available]) .tooltip-arrow{inset-inline-start:64%}.discover-tooltip.visible,.tooltip-arrow.visible{opacity:1;transition:opacity 0.2s ease-in-out;visibility:visible}.tooltip-link{color:#1E2024;text-decoration:underline;cursor:pointer;pointer-events:all;margin-inline-end:4px}`.withBehaviors((0,z.G2)(M),(0,z.mr)(j),new N.o("classicNTPToggle",!1,U),new N.o("classicNTPToggle",!0,L),new N.o("superNavToggle",!0,B),new N.o("enableCopilotToggleColorTrmt",!0,I));var Z=r(96950),q=r(66591),G=r(69259),J=r(60402);const K=Z.qy`<div class=${e=>(0,q.x)("discover-tooltip",["visible",e.renderTooltip])}><span class="tooltip-text"><a href=${e=>e.marketingPage} class="tooltip-link" target="_blank" data-t=${e=>e.rubyCoachmarkTelemetryTag}>${e=>{var t;return g(null===(t=e.rubyCoachmarkStrings)||void 0===t?void 0:t.copilotDiscover)}}</a>${e=>{var t;return null===(t=e.rubyCoachmarkStrings)||void 0===t?void 0:t.copilotDiscoverTooltip}}</span></div><div class=${e=>(0,q.x)("tooltip-arrow",["visible",e.renderTooltip])}></div>`,Q=Z.qy`
${(0,G.z)(e=>{var t;return null===(t=e.rubyCoachmarkStrings)||void 0===t?void 0:t.copilotDiscoverTooltip},K)}<div class="ruby-toggle" id="ruby-toggle"><label class="ruby-switch-label" for="ruby-switch"><span class="normal-text">${e=>{var t;return g(null===(t=e.rubyCoachmarkStrings)||void 0===t?void 0:t.copilotDiscover)}}</span><span class="preview-text">${e=>{var t;return g(null===(t=e.rubyCoachmarkStrings)||void 0===t?void 0:t.copilotDiscoverPreview)}}</span></label><fluent-switch id="ruby-switch" @change=${e=>e.onRubySwitchChange()} aria-checked=${e=>!e.classicNTPToggle&&!e.superNavToggle} current-checked=${e=>!e.classicNTPToggle&&!e.superNavToggle} class="ruby-switch" role="switch" title="${e=>{var t;return g(null===(t=e.rubyCoachmarkStrings)||void 0===t?void 0:t.copilotDiscover)}}" data-t=${e=>e.rubyToggleSwitchTelemetryTag} ${(0,J.K)("rubyToggleRef")}></fluent-switch></div>`;var V=r(2958),X=r(37180),Y=r(4731),ee=r(7014);V.m.define(X.c.registry),Y.m.define(X.c.registry),ee.m.define(X.c.registry);let te=class extends _{};te=(0,i.Cg)([(0,o.E)({name:"ruby-coachmark",template:Q,styles:W})],te)},43774(e,t,r){r.d(t,{p4(){return g},ls(){return k},vA(){return p},nF(){return b}});var i=r(45755),o=r(68009),c=r(95239);const{create:a}=i.G,s=a("neutral-stroke-strong-hover-delta",40),n=a("neutral-stroke-strong-active-delta",16),l=a("neutral-stroke-strong-focus-delta",25);var d=r(31023);const{create:h}=i.G,u=h({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,t,r,i,c,a){const s=(0,o.F)(t),n=e.colorContrast(t,r),l=e.closestIndexOf(n);return{rest:n,hover:e.get(l+s*i),active:e.get(l+s*c),focus:e.get(l+s*a)}}(e(d.r),e(c.p),3,e(s),e(n),e(l))}}),b=h("neutral-stroke-strong-rest",e=>e(u).evaluate(e).rest),p=h("neutral-stroke-strong-hover",e=>e(u).evaluate(e).hover),g=h("neutral-stroke-strong-active",e=>e(u).evaluate(e).active),k=h("neutral-stroke-strong-focus",e=>e(u).evaluate(e).focus)}}]);