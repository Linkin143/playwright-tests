// © Microsoft Corporation. All rights reserved.
import { getAppEnvironment } from "@msnews/core";
export function insertManifestHeader(market) {
    let url;
    if (getAppEnvironment().HostPage.hostName != "localhost.msn.com") {
        url = `${getAppEnvironment().StaticsUrl}latest/0/homepage/json/${market}.webmanifest`;
    }
    else {
        // eslint-disable-next-line
        url = "https://assets.msn.com/staticsb/statics/latest/0/homepage/json/localhost.webmanifest";
    }
    const el = document.createElement("link");
    el.setAttribute("rel", "manifest");
    el.setAttribute("href", url);
    document.head.appendChild(el);
}
//# sourceMappingURL=pwa.js.map