"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_super-container_dist_register_MsftInfopaneModule_js"],{5675(i,t,e){e.d(t,{S(){return r}});var a=e(96950);function r(){return a.qy`
        <template slot="tabpanel" role="tabpanel">
            <slot></slot>
        </template>
    `}},10103(i,t,e){e.d(t,{y(){return r}});var a=e(92011);class r extends a.L{}},10699(i,t,e){e.d(t,{Ob(){return $}});var a=e(70635),r=e(96950),s=e(82774),o=e(69259);const n=r.qy`<template><slot ${(0,s.e)({property:"items",filter(i){return i instanceof HTMLElement&&null!==i.offsetParent}})}></slot>${(0,o.z)(i=>i.layout===a.Y.list,r.qy` <span class="topic">${i=>i.topic}</span> `)} ${i=>i.dividerTemplate}</template>`;var d=e(7896),h=e(41123),l=e(48751),c=e(95239),m=e(89580),g=e(86856),p=e(74849),v=e(64187),u=e(22131);const f=p.A` :host([layout="double"]) .divider-1{left:0}:host([layout="triple"]) .divider-1{left:0}:host([layout="triple"]) .divider-2{left:0}:host([layout="mosaic"]) .divider-1{left:0}:host([layout="mosaic"]) .divider-2{left:1px}`,b=p.A` :host([layout="double"]) .divider-1{right:0}:host([layout="triple"]) .divider-1{right:0}:host([layout="triple"]) .divider-2{right:0}:host([layout="mosaic"]) .divider-1{right:0}:host([layout="mosaic"]) .divider-2{right:1px}`,x=p.A`
        ${(0,v.V)("grid")} :host{box-sizing:border-box;font-family:${d.O};
            font-size: ${h.K};
            line-height: ${h.Z};
            color: ${l.l};height:100%;width:100%;position:relative}:host([layout="single"]){grid-template-columns:1fr}:host([layout="double"]){grid-template-columns:1fr 1fr}:host([layout="split"]){grid-template-rows:1fr 1fr}:host([layout="triple"]){grid-template-columns:1fr 1fr 1fr}:host([layout="mosaic"]){grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr}:host([layout="mosaic"]) ::slotted(:first-child){grid-row:1 / span 2;grid-column:1}:host([layout="mosaic"]) ::slotted(msft-content-card:not(:first-child)){--mask-gradient:linear-gradient(rgba(0,0,0,0),${c.p})}:host([layout="list"]){grid-template-rows:auto 1fr 1fr 1fr;grid-template-columns:3fr 2fr}:host([layout="list"]) ::slotted(:first-child){grid-row:1 / span 4;grid-column:1}:host([layout="list"]) ::slotted(msft-content-card:not(:first-child)){background:${c.p};
            --heading-font-size: ${h.K};
            --heading-line-height: ${h.Z}}.topic{grid-row:1;grid-column:2;font-size:${m.Y};
            line-height: ${m.v};
            background: ${c.p};padding:6px 12px}.divider{background:rgba(255,255,255,0.4);position:absolute;left:20px;right:20px;top:20px;bottom:20px;z-index:1;pointer-events:none;opacity:0}:host([layout="double"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="split"]) .divider-1{grid-row:2;height:1px;top:0;opacity:1}:host([layout="triple"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="triple"]) .divider-2{grid-column:3;width:1px;opacity:1}:host([layout="mosaic"]) .divider-1{grid-column:2;grid-row:1 / span 2;width:1px;opacity:1}:host([layout="mosaic"]) .divider-2{grid-column:2;grid-row:2;height:1px;top:0;opacity:1}`.withBehaviors(new g.t(f,b),(0,u.mr)(p.A` .divider{background:none}`));var w=e(99900);const $=a.s.compose({name:`${w.i.prefix}-info-pane-slide`,template:n,styles:x})},15856(i,t,e){e.d(t,{n(){return v}});var a=e(56911),r=e(92011),s=e(60815),o=e(38493),n=e(22870),d=e(87122),h=e(40865),l=e(64668),c=e(64515),m=e(94407),g=e(72526);class p extends g.L{constructor(){super(),this.cardFillColor="#222",this.size="_1x_2y",this.expanded=!1}}(0,a.Cg)([o.CF],p.prototype,"size",void 0),(0,a.Cg)([(0,o.CF)({mode:"boolean"})],p.prototype,"expanded",void 0);class v extends r.L{constructor(){super(...arguments),this.headingLevel=2,this.title="",this.isArticleCard=()=>this.parent instanceof l.df,this.isFlexArticleCard=()=>this.parent instanceof p}connectedCallback(){super.connectedCallback(),this.imagePosition||(this.imagePosition="end"),this.parent=(0,h.Z)(this),this.parent&&(this.notifier=s.cP.getNotifier(this.parent),this.notifier.subscribe(this,"cardFillColor"),this.notifier.subscribe(this,"size"),this.handleChange(this.parent,"cardFillColor"),this.handleChange(this.parent,"size"),this.addEventListener("mouseover",this.mouseOver),this.addEventListener("mouseout",this.mouseOut),this.addEventListener("focusin",this.focusIn),this.addEventListener("focusout",this.focusOut))}disconnectedCallback(){super.disconnectedCallback(),this.notifier&&(this.notifier.unsubscribe(this,"cardFillColor"),this.notifier.unsubscribe(this,"size"),this.removeEventListener("mouseover",this.mouseOver),this.removeEventListener("mouseout",this.mouseOut),this.removeEventListener("focusin",this.focusIn),this.removeEventListener("focusout",this.focusOut))}handleChange(i,t){switch(this.half="_1x_1y"===i.size,t){case"cardFillColor":if(!i.cardFillColor)break;this.gradientColor=i.cardFillColor,this.gradientVariables=this.generateGradientVariables();break;case"size":this.wide="_2x_2y"===i.size}}handleContentCardLinkClick(i){return this.handleContentCardClickOverride?this.handleContentCardClickOverride(i):(this.$emit("link-invoked",i),!0)}generateGradientVariables(){const{r:i,g:t,b:e}=(0,n.Hs)(this.gradientColor),a=new d.M(i,t,e,(0,c.P)("image",this.childElements)?this.half?.6:.8:.6).toStringWebRGBA(),r=new d.M(i,t,e,0).toStringWebRGBA();return`--gradient-mid-color: ${a}; --gradient-color: ${this.gradientColor}; --radial-gradient-color: ${r}; -webkit-tap-highlight-color: transparent;`}mouseOver(){this.setExpanded(!0),this.hasHover=!0}mouseOut(){this.hasFocus||this.setExpanded(!1),this.hasHover=!1}focusIn(){this.setExpanded(!0),this.hasFocus=!0}focusOut(){this.hasHover||this.setExpanded(!1),this.hasFocus=!1}filteredContentIndicator(){return Array.isArray(this.contentIndicatorNodes)?this.contentIndicatorNodes.filter(i=>i instanceof m.L):[]}setExpanded(i){this.filteredContentIndicator().forEach(t=>t.expanded=i)}}(0,a.Cg)([(0,o.CF)({attribute:"heading-level",mode:"fromView",converter:o.R$})],v.prototype,"headingLevel",void 0),(0,a.Cg)([o.CF],v.prototype,"href",void 0),(0,a.Cg)([o.CF],v.prototype,"target",void 0),(0,a.Cg)([(0,o.CF)({attribute:"image-position"})],v.prototype,"imagePosition",void 0),(0,a.Cg)([(0,o.CF)({attribute:"immersive-card",mode:"boolean"})],v.prototype,"immersiveCard",void 0),(0,a.Cg)([s.sH],v.prototype,"anchorTelemetryTag",void 0),(0,a.Cg)([s.sH],v.prototype,"childElements",void 0),(0,a.Cg)([s.sH],v.prototype,"wide",void 0),(0,a.Cg)([s.sH],v.prototype,"half",void 0),(0,a.Cg)([s.sH],v.prototype,"notifier",void 0),(0,a.Cg)([s.sH],v.prototype,"parent",void 0),(0,a.Cg)([s.sH],v.prototype,"gradientColor",void 0),(0,a.Cg)([s.sH],v.prototype,"gradientVariables",void 0),(0,a.Cg)([s.sH],v.prototype,"contentIndicatorNodes",void 0),(0,a.Cg)([s.sH],v.prototype,"title",void 0),(0,a.Cg)([s.sH],v.prototype,"handleContentCardClickOverride",void 0)},15961(i,t,e){e.d(t,{m(){return w}});var a=e(99751),r=e(37180),s=e(74849),o=e(64187),n=e(73477),d=e(22131),h=e(50882),l=e(48196),c=e(7896),m=e(41123),g=e(74838),p=e(48751),v=e(57416),u=e(26920),f=e(14996);const b=s.A`
    ${(0,o.V)("inline-flex")} :host {
        box-sizing: border-box;
        font-family: ${c.O};
        font-size: ${m.K};
        font-weight: 400;
        line-height: ${m.Z};
        height: calc(${l.D} * 1px);
        padding: 0 calc((6 + (${g.vR} * 2 * ${g.Br})) * 1px);
        color: ${p.l};
        border-radius: calc(${v.Pb} * 1px);
        border: calc(${u.XA} * 1px) solid transparent;
        align-items: center;
        justify-content: center;
        grid-row: 1;
        cursor: pointer;
    }

    :host([aria-selected="true"]) {
        z-index: 2;
    }

    :host(:hover),
    :host(:active) {
        color: ${p.l};
    }

    :host(:${n.N}) {
        outline: none;
        border: calc(${u.XA} * 1px) solid ${f.WN};
        box-shadow: 0 0 0 calc((${u.vd} - ${u.XA}) * 1px)
            ${f.WN};
    }

    :host(:focus) {
        outline: none;
    }

    :host(.vertical) {
        justify-content: end;
        grid-column: 2;
    }

    :host(.vertical[aria-selected="true"]) {
        z-index: 2;
    }

    :host(.vertical:hover),
    :host(.vertical:active) {
        color: ${p.l};
    }

    :host(.vertical:hover[aria-selected="true"]) {
    }
`.withBehaviors((0,d.mr)(s.A`
            :host {
                forced-color-adjust: none;
                border-color: transparent;
                color: ${h.A.ButtonText};
                fill: currentcolor;
            }
            :host(:hover),
            :host(.vertical:hover),
            :host([aria-selected="true"]:hover) {
                background: ${h.A.Highlight};
                color: ${h.A.HighlightText};
                fill: currentcolor;
            }
            :host([aria-selected="true"]) {
                background: ${h.A.HighlightText};
                color: ${h.A.Highlight};
                fill: currentcolor;
            }
            :host(:${n.N}) {
                border-color: ${h.A.ButtonText};
                box-shadow: none;
            }
        `)),x=(0,e(60347).M)(),w=a.s.compose({name:`${r.c.prefix}-tab`,template:x,styles:b})},25717(i,t,e){e.d(t,{T(){return r}});var a=e(96950);function r(){return a.qy`
        <slot></slot>
    `}},26813(i,t,e){e.d(t,{D(){return p},P(){return g}});var a=e(56911),r=e(60815),s=e(96950),o=e(92011),n=e(38493),d=e(55230),h=e(5096),l=e(50180),c=e(35106),m=e(88458);const g={vertical:"vertical",horizontal:"horizontal"};class p extends o.L{constructor(){super(...arguments),this.orientation=g.horizontal,this.hideActiveIndicator=!1,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=i=>"true"===i.getAttribute("aria-disabled"),this.isFocusableElement=i=>!this.isDisabledElement(i),this.setTabs=()=>{const i="gridColumn",t="gridRow",e=this.isHorizontal()?i:t;this.activeTabIndex=this.getActiveIndex(),this.showActiveIndicator=!1,this.tabs.forEach((a,r)=>{if("tab"===a.slot){const i=this.activeTabIndex===r&&this.isFocusableElement(a);!this.hideActiveIndicator&&this.isFocusableElement(a)&&(this.showActiveIndicator=!0);const t=this.tabIds[r],e=this.tabpanelIds[r];a.setAttribute("id",t),a.setAttribute("aria-selected",i?"true":"false"),a.setAttribute("aria-controls",e),a.addEventListener("click",this.handleTabClick),a.addEventListener("keydown",this.handleTabKeyDown),a.setAttribute("tabindex",i?"0":"-1"),i&&(this.activetab=a)}a.style[i]="",a.style[t]="",a.style[e]=`${r+1}`,this.isHorizontal()?a.classList.remove("vertical"):a.classList.add("vertical")})},this.setTabPanels=()=>{this.tabpanels?.forEach((i,t)=>{const e=this.tabIds[t],a=this.tabpanelIds[t];i.setAttribute("id",a),i.setAttribute("aria-labelledby",e),this.activeTabIndex!==t?(i.setAttribute("tabindex","-1"),i.setAttribute("hidden",""),i.setAttribute("aria-hidden","true")):(i.removeAttribute("tabindex"),i.removeAttribute("hidden"),i.removeAttribute("aria-hidden"))})},this.handleTabClick=i=>{const t=i.currentTarget;1===t.nodeType&&this.isFocusableElement(t)&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(t),this.setComponent())},this.handleTabKeyDown=i=>{if(this.isHorizontal())switch(i.key){case d.kT:i.preventDefault(),this.adjustBackward(i);break;case d.bb:i.preventDefault(),this.adjustForward(i)}else switch(i.key){case d.I5:i.preventDefault(),this.adjustBackward(i);break;case d.HX:i.preventDefault(),this.adjustForward(i)}switch(i.key){case d.kE:i.preventDefault(),this.adjust(-this.activeTabIndex);break;case d.FM:i.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1)}},this.adjustForward=i=>{const t=this.tabs;let e=0;for(e=this.activetab?t.indexOf(this.activetab)+1:1,e===t.length&&(e=0);e<t.length&&t.length>1;){if(this.isFocusableElement(t[e])){this.moveToTabByIndex(t,e);break}if(this.activetab&&e===t.indexOf(this.activetab))break;e+1>=t.length?e=0:e+=1}},this.adjustBackward=i=>{const t=this.tabs;let e=0;for(e=this.activetab?t.indexOf(this.activetab)-1:0,e=e<0?t.length-1:e;e>=0&&t.length>1;){if(this.isFocusableElement(t[e])){this.moveToTabByIndex(t,e);break}e-1<0?e=t.length-1:e-=1}},this.moveToTabByIndex=(i,t)=>{const e=i[t];this.activetab=e,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=t,e.focus(),this.setComponent()}}orientationChanged(){this.$fastController.isConnected&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}activeidChanged(i,t){this.$fastController.isConnected&&(this.tabs.length<=(this.tabpanels?.length??0)||this.tabs.length<=(this.lazyPanels?.length??0))&&(this.prevActiveTabIndex=this.tabs.findIndex(t=>t.id===i),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(){this.$fastController.isConnected&&(this.tabs.length<=(this.tabpanels?.length??0)||this.tabs.length<=(this.lazyPanels?.length??0))&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}lazyPanelsChanged(){this.$fastController.isConnected&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.handleActiveIndicatorPosition())}tabpanelsChanged(){this.$fastController.isConnected&&(this.tabpanels?.length??0)<=this.tabs.length&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):0}getTabIds(){return this.tabs.map(i=>i.getAttribute("id")??`tab-${(0,l.NF)()}`)}getTabPanelIds(){return this.lazyPanels?this.lazyPanels.map(i=>i.id):(this.tabpanels||[]).map(i=>i.getAttribute("id")??`panel-${(0,l.NF)()}`)}setComponent(){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.focusTab(),this.change())}isHorizontal(){return this.orientation===g.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&!this.hideActiveIndicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;const i=this.isHorizontal()?"gridColumn":"gridRow",t=this.isHorizontal()?"translateX":"translateY",e=this.isHorizontal()?"offsetLeft":"offsetTop",a=this.activeIndicatorRef[e];this.activeIndicatorRef.style[i]=`${this.activeTabIndex+1}`;const r=this.activeIndicatorRef[e];this.activeIndicatorRef.style[i]=`${this.prevActiveTabIndex+1}`;const s=r-a;this.activeIndicatorRef.style.transform=`${t}(${s}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",()=>{this.ticking=!1,this.activeIndicatorRef.style[i]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${t}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")})}adjust(i){const t=this.tabs.filter(i=>!this.isDisabledElement(i)),e=t.indexOf(this.activetab),a=(0,h.AB)(0,t.length-1,e+i),r=this.tabs.indexOf(t[a]);r>-1&&this.moveToTabByIndex(this.tabs,r)}focusTab(){this.tabs[this.activeTabIndex].focus()}connectedCallback(){super.connectedCallback(),this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex()}}(0,a.Cg)([n.CF,(0,a.Sn)("design:type",String)],p.prototype,"orientation",void 0),(0,a.Cg)([n.CF,(0,a.Sn)("design:type",String)],p.prototype,"activeid",void 0),(0,a.Cg)([r.sH,(0,a.Sn)("design:type",Array)],p.prototype,"tabs",void 0),(0,a.Cg)([r.sH,(0,a.Sn)("design:type",Array)],p.prototype,"lazyPanels",void 0),(0,a.Cg)([r.sH,(0,a.Sn)("design:type",s.kc)],p.prototype,"lazyPanelTemplate",void 0),(0,a.Cg)([r.sH,(0,a.Sn)("design:type",Array)],p.prototype,"tabpanels",void 0),(0,a.Cg)([(0,n.CF)({attribute:"hide-active-indicator",mode:"boolean"}),(0,a.Sn)("design:type",Object)],p.prototype,"hideActiveIndicator",void 0),(0,a.Cg)([r.sH,(0,a.Sn)("design:type",HTMLElement)],p.prototype,"activeIndicatorRef",void 0),(0,a.Cg)([r.sH,(0,a.Sn)("design:type",Boolean)],p.prototype,"showActiveIndicator",void 0),(0,m.X)(p,c.qw)},32747(i,t,e){e.d(t,{j(){return p}});var a=e(74849),r=e(50882),s=e(64187),o=e(22131),n=e(41123),d=e(57416),h=e(37998),l=e(4283),c=e(7896),m=e(48751),g=e(70246);const p=a.A`
        ${(0,s.V)("grid")} :host{--elevation:4;box-sizing:border-box;font-family:${c.O};
            font-size: ${n.K};
            line-height: ${n.Z};
            color: ${m.l};
            background: ${g.k};
            border-radius: calc(${d.JU} * 1px);
            ${h.ET};overflow:hidden;height:100%;grid-template-columns:auto 1fr auto;grid-template-rows:auto 1fr;width:100%}:host(:hover) ::slotted([slot="previous-flipper"]),:host(:hover) .previous-flipper,:host(:hover) ::slotted([slot="next-flipper"]),:host(:hover) .next-flipper{opacity:1;transition:opacity 0.2s ease-in-out}.tablist{display:var(--hidden-tablist,grid);grid-template-rows:auto auto;grid-template-columns:auto;position:relative;width:max-content;align-self:center;justify-self:center;grid-row:1;grid-column:1 / span 3;z-index:3;cursor:pointer}::slotted([slot="previous-flipper"]),.previous-flipper{margin:8px;grid-column:1;grid-row:1 / span 2;align-self:center;z-index:2;opacity:0}::slotted([slot="next-flipper"]),.next-flipper{margin:8px;grid-column:3;grid-row:1 / span 2;align-self:center;z-index:2;opacity:0}:host([layout="1-column"]){--heading-font-size:${n.K};
            --heading-line-height: ${n.Z}}.activeIndicator{grid-row:2;grid-column:1;width:20px;height:3px;border-radius:calc(${d.Pb} * 1px);
            justify-self: center;
            background: ${l.IR}}.activeIndicatorTransition{transition:transform 0.2s ease-in-out}.tabpanel{grid-row:1/3;grid-column-start:1;grid-column-end:4;position:relative}`.withBehaviors((0,o.mr)(a.A` .activeIndicator{forced-color-adjust:none;background:${r.A.Highlight}}.tablist{background:${r.A.Canvas};
                }
            `))},36248(i,t,e){e.d(t,{K(){return T}});var a=e(56911),r=e(60815),s=e(15856),o=e(70635),n=e(96950),d=e(416),h=e(10108),l=e(60402),c=e(69259),m=e(82774),g=e(64515);const p=i=>t=>(0,g.P)(i,t.childElements)?n.qy`<div id="${i}" class="${i}" part="${i}"><slot name="${i}"></slot></div>`:"",v=n.qy`<template role="article" ?immersive-card="${i=>i.isArticleCard()||i.isInfoPaneSlide()}" ${(0,d.Y)({property:"childElements",filter:(0,h.Y)()})}><div ${(0,l.K)("article")} part="article" class="article${i=>(0,g.P)("image",i.childElements)?` image-pos-${i.imagePosition}`:" no-image"} ${i=>i.wide?" wide":""} ${i=>i.split?" split":""} ${i=>i.single?" single":""} ${i=>i.double?" double":""} ${i=>i.triple?" triple":""}" style="${i=>i.gradientVariables}">${i=>"start"===i.imagePosition?p("image")(i):""}<div class="text" part="text"><div class="gradient" part="gradient"></div>${i=>(0,g.P)("start",i.childElements)?n.qy`<slot name="start" part="start"></slot>`:""}<div class="heading-wrapper">${p("attribution")}<a id="heading" class="heading" part="heading" href="${i=>i.href??void 0}" target=${i=>i.target??void 0} @click=${(i,t)=>i.handleContentCardLinkClick(t.event)} data-t="${i=>i.anchorTelemetryTag}"><span role="heading" aria-level="${i=>i.headingLevel}"><slot></slot></span></a></div>${p("abstract")}<div class="actions" part="actions"><slot name="start-action"></slot><slot name="end-action"></slot></div></div><div class="image-end" part="image-end"><div class="image-end-container" part="image-end-container"><div class="image-container" part="image-container"><div ${(0,l.K)("backgroundImage")} class="background-image" part="background-image"></div>${(0,c.z)(i=>"end"===i.imagePosition,n.qy`<div id="image" class="image" part="image"><slot name="image" ${(0,m.e)("imageSlottedNodes")}></slot></div>`)}</div><div class="image-end-gradient-container" part="image-end-gradient-container"><div class="image-end-gradient-top" part="image-end-gradient-top"></div><div class="image-end-gradient-bottom" part="image-end-gradient-bottom"></div></div></div></div>${i=>(0,g.P)("hide-story",i.childElements)?n.qy`<div class="hide-story-wrapper" part="hide-story-wrapper">${p("hide-story")}</div>`:""}</div></template>`;var u=e(89580),f=e(71157),b=e(86856),x=e(74849),w=e(73477),$=e(22131),y=e(87483);const k=x.A` :host([immersive-card]) .wide .image-end{right:0;left:unset}:host([immersive-card]) .wide .image-end-gradient-top{background:linear-gradient( 270deg,var(--gradient-mid-color) 0%,var(--gradient-color) 100% )}:host([immersive-card]) .wide .image-end-gradient-bottom{background:linear-gradient( 270deg,transparent 0%,var(--gradient-mid-color) 100% )}:host([immersive-card]) .wide.narrow-image .image-end-gradient-top{background:linear-gradient( 270deg,transparent 0%,var(--gradient-mid-color) 100% )}:host([immersive-card]) .split.wide.wide-image .text{left:0}:host([immersive-card]) .split.wide.wide-image .image-end-gradient-top{background:linear-gradient( 270deg,var(--gradient-mid-color) 0%,var(--gradient-color) 100% )}:host([immersive-card]) .split.wide.wide-image .image-end-gradient-bottom{background:linear-gradient( 270deg,transparent 0%,var(--gradient-mid-color) 100% )}`,z=x.A` :host([immersive-card]) .wide .image-end{right:unset;left:0}:host([immersive-card]) .wide .image-end-gradient-top{background:linear-gradient( 90deg,var(--gradient-mid-color) 0%,var(--gradient-color) 100% )}:host([immersive-card]) .wide .image-end-gradient-bottom{background:linear-gradient( 90deg,transparent 0%,var(--gradient-mid-color) 100% )}:host([immersive-card]) .wide.narrow-image .image-end-gradient-top{background:linear-gradient( 90deg,transparent 0%,var(--gradient-mid-color) 100% )}:host([immersive-card]) .split.wide.wide-image .text{right:0}:host([immersive-card]) .split.wide.wide-image .image-end-gradient-top{background:linear-gradient( 90deg,var(--gradient-mid-color) 0%,var(--gradient-color) 100% )}:host([immersive-card]) .split.wide.wide-image .image-end-gradient-bottom{background:linear-gradient( 90deg,transparent 0%,var(--gradient-mid-color) 100% )}`,C=x.A` :host{overflow:hidden;--gradient-mid-color:rgba(34,34,34,0.8);--gradient-color:#222;--radial-gradient-color:rgba(34,34,34,0)}${y.BX};:host([immersive-card]) .wide .attribution ::slotted(msft-attribution),:host([immersive-card]) .no-image .attribution ::slotted(msft-attribution){margin-bottom:8px}:host([immersive-card]) .wide .text .heading-wrapper{height:100%;display:flex;align-items:center}:host([immersive-card]) .heading,:host([immersive-card]) .triple.narrow-image .heading{-webkit-line-clamp:var(--heading-max-lines,2)}.text{display:flex;flex-direction:column}::slotted([slot="start-action"]){z-index:0}:host([immersive-card]) .gradient,:host([immersive-card]) .wide .gradient{display:none}:host([immersive-card]) .actions{position:static;width:100%;min-height:28px}:host([immersive-card]) .image-end{width:100%;height:225px;position:absolute;top:0;left:0}:host([immersive-card]) .image-end-container{width:100%;max-height:225px;overflow:hidden;position:relative}:host([immersive-card]) .image-end-gradient-container{width:100%;position:absolute;bottom:0}:host([immersive-card]) .image-end-gradient-top{height:52px;background:linear-gradient( 180deg,transparent 0%,var(--gradient-mid-color) 100% )}:host([immersive-card]) .image-end-gradient-bottom{height:25px;background:linear-gradient( 180deg,var(--gradient-mid-color) 0%,var(--gradient-color) 100% )}:host([immersive-card]) .image-end .image-end-container .image{display:flex;align-items:center;flex-direction:column;width:100%;position:relative}:host([immersive-card]) .image-end .image-end-container .image ::slotted(img){height:auto;object-fit:contain;object-position:center top}:host([immersive-card]) .background-image:not([style]),:host([card]) .background-image{display:none}:host([immersive-card]) .background-image{display:block;width:100%;height:100%;position:absolute;top:0;left:0;background:50% 50% / cover no-repeat transparent;filter:blur(4px);transform:scale(1.2)}:host([immersive-card]:${w.N}) .image-container,:host([immersive-card]:hover) .image-container{opacity:0.5}:host([immersive-card]:${w.N}) .image-container .image,:host([immersive-card]:hover) .image-container .image{opacity:1}:host([immersive-card]) .split.wide.wide-image .text{width:66%}:host([immersive-card]) .split.wide .heading{font-size:${u.Y};
        line-height: ${u.v}}.split.wide .heading::after{top:unset;cursor:pointer}:host([immersive-card]) .split.wide.wide-image .image-end{width:unset}:host([immersive-card]) .split.wide.wide-image .image-end-gradient-container{display:flex}:host([immersive-card]) .split.wide.wide-image .image-end-gradient-container:after{height:unset;background:transparent}:host([immersive-card]) .split.wide.wide-image .image-end-gradient-top{width:30px;height:100%;position:static}:host([immersive-card]) .split.wide.wide-image .image-end-gradient-bottom{width:100px;height:100%;position:static}:host([immersive-card]) .triple .heading{-webkit-line-clamp:var(--heading-max-lines,3)}:host([immersive-card]) .triple.wide-image .heading{-webkit-line-clamp:var(--heading-max-lines,4)}:host([immersive-card]) .double.wide-image .heading{-webkit-line-clamp:var(--heading-max-lines,4)}:host([immersive-card]) .wide .text{padding:calc(var(--msft-article-padding) * 1px);width:47%}:host([immersive-card]) .wide .heading{font-size:${f.T};
        line-height: ${f.O};-webkit-line-clamp:var(--heading-max-lines,6)}:host([immersive-card]) .wide .image-end{width:unset;height:100%}:host([immersive-card]) .wide .image-end-container{max-width:405px;max-height:100%;overflow:hidden;position:relative}:host([immersive-card]) .wide .image-end-gradient-container{display:flex;width:100%;height:100%;position:absolute;top:0;left:0}:host([immersive-card]) .wide .image-end-gradient-top{width:30px;height:100%}:host([immersive-card]) .wide .image-end-gradient-bottom{width:100px;height:100%}:host([immersive-card]) .wide-image .text{width:100%;height:unset;padding:0 28px 17px 28px}:host([immersive-card]) .article.wide-image .actions{width:100%;position:static}:host([immersive-card]) .wide-image .image-end .image-end-container{max-width:100%}:host([immersive-card]) .wide.wide-image .heading{-webkit-line-clamp:var(--heading-max-lines,1)}:host([immersive-card]) .wide.wide-image .heading::after{top:unset}:host([immersive-card]) .wide.wide-image .image-end,:host([immersive-card]) .wide.wide-image .image-end .image-end-container .image ::slotted(img){width:100%}:host([immersive-card]) .wide.wide-image .image-end-gradient-container{display:block;width:100%;position:absolute;bottom:0}:host([immersive-card]) .wide.wide-image .image-end-gradient-container:after{content:"";height:45px;background:var(--gradient-color);position:absolute;bottom:0;right:0;left:0}:host([immersive-card]) .wide.wide-image .image-end-gradient-top{width:100%;height:47px;background:linear-gradient( 180deg,transparent 0%,var(--gradient-mid-color) 100% );position:absolute;bottom:74px}:host([immersive-card]) .wide.wide-image .image-end-gradient-bottom{width:100%;height:29px;background:linear-gradient( 180deg,var(--gradient-mid-color) 0%,var(--gradient-color) 100% );position:absolute;bottom:45px}:host([immersive-card]) .single.narrow-image .image-end-container{max-width:unset}:host([immersive-card]) .single.narrow-image .image-end .image-end-container .image ::slotted(img){width:auto;height:304px}:host([immersive-card]) .wide.single.narrow-image .text{width:50%}:host([immersive-card]) .wide.single.narrow-image .text .heading-wrapper{padding-inline-end:18px}:host([immersive-card]) .wide.narrow-image .image-end-gradient-top{width:10px;height:100%}:host([immersive-card]) .wide.narrow-image .image-end-gradient-bottom{display:none}`.withBehaviors(new b.t(k,z),(0,$.mr)(x.A` :host{forced-color-adjust:auto}:host([immersive-card]) .gradient,:host([immersive-card]) .image-end-gradient-container,:host([immersive-card]) .wide .image-end-gradient-container,:host([immersive-card]) .wide.wide-image .image-end-gradient-container{display:none}`));var I=e(99900);class F extends s.n{constructor(){super(...arguments),this.isInfoPaneSlide=()=>this.parentElement instanceof o.s}imageSlottedNodesChanged(i,t){if(null!=t&&t.length){const i=t[0],e=parseInt(i.getAttribute("width")||"1",10),a=parseInt(i.getAttribute("height")||"1",10),r=Math.round(e/a*100)/100;(r<F.narrowImageThreshold||r>F.wideImageThreshold)&&this.backgroundImage.style.setProperty("background-image",`url(${i.src})`),this.article.classList.toggle("wide-image",r>F.wideImageThreshold),this.article.classList.toggle("narrow-image",r<F.narrowImageThreshold)}}connectedCallback(){var i;super.connectedCallback(),this.handleChange(null===(i=this.parentNode)||void 0===i?void 0:i.parentNode,"cardFillColor")}handleChange(i,t){"size"===t?(this.wide="single"===i.layout||"split"===i.layout,this.split="split"===i.layout,this.single="single"===i.layout,this.double="double"===i.layout,this.triple="triple"===i.layout):super.handleChange(i,t)}}F.narrowImageThreshold=1.33,F.wideImageThreshold=1.36,(0,a.Cg)([r.sH],F.prototype,"split",void 0),(0,a.Cg)([r.sH],F.prototype,"single",void 0),(0,a.Cg)([r.sH],F.prototype,"double",void 0),(0,a.Cg)([r.sH],F.prototype,"triple",void 0),(0,a.Cg)([r.sH],F.prototype,"backgroundImage",void 0),(0,a.Cg)([r.sH],F.prototype,"imageSlottedNodes",void 0);const T=F.compose({name:`${I.i.prefix}-info-pane-ad`,template:v,styles:C,shadowOptions:{delegatesFocus:!0}})},37256(i,t,e){e.d(t,{R(){return c}});var a=e(64187),r=e(22131),s=e(74849),o=e(50882),n=e(37998),d=e(57416),h=e(95239),l=e(48751);const c=s.A`
    ${(0,a.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${h.p};
        color: ${l.l};
        border-radius: calc(${d.JU} * 1px);
        ${n.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,r.mr)(s.A`
            :host {
                forced-color-adjust: none;
                background: ${o.A.Canvas};
                box-shadow: 0 0 0 1px ${o.A.CanvasText};
            }
        `))},37510(i,t,e){e.d(t,{m(){return m}});var a=e(10103),r=e(37180),s=e(74849),o=e(64187),n=e(7896),d=e(61138),h=e(74838);const l=s.A`
    ${(0,o.V)("block")} :host {
        box-sizing: border-box;
        font-family: ${n.O};
        font-size: ${d.k};
        font-weight: 400;
        line-height: ${d.F};
        padding: 0 calc((6 + (${h.vR} * 2 * ${h.Br})) * 1px);
    }
`,c=(0,e(5675).S)(),m=a.y.compose({name:`${r.c.prefix}-tab-panel`,template:c,styles:l})},38380(i,t,e){e.d(t,{v(){return a}});const a=(0,e(25717).T)()},47879(i,t,e){e.d(t,{L(){return c}});var a=e(10103);class r extends a.y{}var s=e(5675),o=e(7896),n=e(61138),d=e(74849),h=e(64187);const l=d.A`
    ${(0,h.V)("flex")} :host{box-sizing:border-box;font-family:${o.O};
        font-size: ${n.k};
        line-height: ${n.F};
        height: 100%;
    }
`,c=r.compose({name:"msn-info-pane-panel",template:(0,s.S)(),styles:l})},58754(i,t,e){e.d(t,{h_(){return g}});var a=e(92135),r=e(22192),s=e(96950),o=e(82774),n=e(69259),d=e(60402),h=e(31157);const l=s.qy`<template @mouseover="${(i,t)=>i.handleMouseOver(t.event)}" @mouseout="${(i,t)=>i.handleMouseOut(t.event)}" @focusin="${(i,t)=>i.handleFocusIn(t.event)}" @focusout="${(i,t)=>i.handleFocusOut(t.event)}"><slot name="previous-flipper"><fluent-flipper part="previous-flipper" class="previous-flipper" direction="${i=>i.direction===h.O.rtl?"next":"previous"}" @keypress="${(i,t)=>i.slideKeyPressHandler(t.event,-1)}" @click="${(i,t)=>i.slideKeyPressHandler(t.event,-1)}" data-t="${i=>i.previousFlipperTelemetryTag}"></fluent-flipper></slot>${r.p}<div class="tablist" part="tablist" role="tablist"><slot class="tab" name="tab" part="tab" ${(0,o.e)("tabs")}></slot>${(0,n.z)(i=>i.activeindicator,s.qy`<div ${(0,d.K)("activeIndicatorRef")} class="activeIndicator" part="activeIndicator"></div>`)}</div><slot name="next-flipper"><fluent-flipper part="next-flipper" class="next-flipper" direction="${i=>i.direction===h.O.rtl?"previous":"next"}" @keypress="${(i,t)=>i.slideKeyPressHandler(t.event,1)}" @click="${(i,t)=>i.slideKeyPressHandler(t.event,1)}" data-t="${i=>i.nextFlipperTelemetryTag}"></fluent-flipper></slot>${r.S}<div class="tabpanel"><slot name="tabpanel" part="tabpanel" ${(0,o.e)("tabpanels")}></slot></div></template>`;var c=e(32747),m=e(99900);const g=a.hN.compose({name:`${m.i.prefix}-info-pane`,template:l,styles:c.j})},60347(i,t,e){e.d(t,{M(){return s}});var a=e(96950),r=e(35106);function s(i={}){return a.qy`
        <template slot="tab" role="tab" aria-disabled="${i=>i.disabled}">
            ${(0,r.LT)(i)}
            <slot></slot>
            ${(0,r.aO)(i)}
        </template>
    `}},64515(i,t,e){function a(i,t){return t&&t.some(t=>t.slot===i)}e.d(t,{P(){return a}})},64668(i,t,e){e.d(t,{df(){return l},RE(){return c}});var a=e(56911),r=e(38493),s=e(72526),o=e(38380),n=e(37256);const d=e(74849).A`
    ${n.R} @supports not (contain:content){:host{overflow:hidden}}:host([size="_1x_2y"]){--card-height:304px;--card-width:300px}:host([size="_2x_2y"]){--card-height:304px;--card-width:612px}:host([size="_1x_1y"]){--card-height:146px;--card-width:300px}`;var h=e(99900);class l extends s.L{constructor(){super(),this.cardFillColor="#222",this.size="_1x_2y"}}(0,a.Cg)([r.CF],l.prototype,"size",void 0);const c=l.compose({name:`${h.i.prefix}-article-card`,template:o.v,styles:d,shadowOptions:{delegatesFocus:!0}})},70246(i,t,e){e.d(t,{k(){return c}});var a=e(45755),r=e(37820),s=e(97004),o=e(47691),n=e(356),d=e(31023);const{create:h}=a.G,l=h({name:"neutral-layer-card-container-recipe"},{evaluate(i){return function(i,t,e){const a=(0,r.qE)(i.closestIndexOf((0,s.Z)(t))-e,0,i.swatches.length-1);return i.get(a+e)}(i(d.r),i(n.l),i(o.E))}}),c=h("neutral-layer-card-container",i=>i(l).evaluate(i))},70635(i,t,e){e.d(t,{Y(){return a},s(){return l}});var a,r=e(56911),s=e(60815),o=e(96950),n=e(92011),d=e(38493);!function(i){i.single="single",i.double="double",i.split="split",i.triple="triple",i.mosaic="mosaic",i.list="list"}(a||(a={}));const h=new Map;class l extends n.L{constructor(){super(...arguments),this.dividerTemplate=null,this.layout=a.single}itemsChanged(i,t){this.$fastController.isConnected&&(this.dividerTemplate=function(i){if(h.has(i))return h.get(i);if(i<1)return h.set(i,null),null;const t=new Array(i).fill("").map((i,t)=>o.qy`<div class="divider divider-${t+1}" part="divider"></div>`).reduce((i,t)=>o.qy`${i}${t}`);return h.set(i,t),t}(this.items.length-1))}}(0,r.Cg)([s.sH],l.prototype,"items",void 0),(0,r.Cg)([s.sH],l.prototype,"dividerTemplate",void 0),(0,r.Cg)([d.CF],l.prototype,"layout",void 0),(0,r.Cg)([d.CF],l.prototype,"topic",void 0)},72526(i,t,e){e.d(t,{L(){return p}});var a=e(56911),r=e(96193),s=e(47429),o=e(60815),n=e(22870),d=e(38493),h=e(95239),l=e(31023),c=e(24458),m=e(5291),g=e(57606);class p extends r.z{cardFillColorChanged(i,t){if(t){const i=(0,n.Hs)(t);null!==i&&(this.neutralPaletteSource=t,h.p.setValueFor(this,m.q.create(i.r,i.g,i.b)))}}neutralPaletteSourceChanged(i,t){if(t){const i=(0,n.Hs)(t),e=m.q.create(i.r,i.g,i.b);l.r.setValueFor(this,g.p.create(e))}}handleChange(i,t){this.cardFillColor||h.p.setValueFor(this,i=>i(c.M3).evaluate(i,i(h.p)))}connectedCallback(){super.connectedCallback();const i=(0,s.Zo)(this);if(i){const t=o.cP.getNotifier(i);t.subscribe(this,"fillColor"),t.subscribe(this,"neutralPalette"),this.handleChange(i,"fillColor")}}}(0,a.Cg)([(0,d.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,a.Sn)("design:type",String)],p.prototype,"cardFillColor",void 0),(0,a.Cg)([(0,d.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,a.Sn)("design:type",String)],p.prototype,"neutralPaletteSource",void 0)},83036(i,t,e){var a=e(37180),r=e(15961),s=e(37510),o=e(93533),n=e(58754),d=e(36248),h=e(10699),l=e(99900),c=e(47879),m=e(95324);h.Ob.define(l.i.registry),n.h_.define(l.i.registry),d.K.define(l.i.registry),c.L.define(l.u.registry),m.K.define(l.u.registry),r.m.define(a.c.registry),s.m.define(a.c.registry),o.m.define(a.c.registry)},87483(i,t,e){e.d(t,{BX(){return g}});var a=e(41123),r=e(14996),s=e(95239),o=e(7896),n=e(48751),d=e(74849),h=e(64187),l=e(22131),c=e(73477),m=e(50882);d.A` .hide-story-wrapper{right:16px}.hide-story{right:-32px}:host([immersive-card]) .image{right:0}:host([immersive-card]) .image-pos-start .image{right:initial;left:0}:host([immersive-card]) .text{left:0}:host([immersive-card]) .image-pos-start .text{right:0;left:initial}:host([immersive-card]) .gradient{left:0;right:-84px}:host([immersive-card]) .wide.no-image .gradient{right:-100%}:host([immersive-card]) .image-pos-start .gradient{right:0;left:-120px}:host([immersive-card]) .wide .gradient{background:linear-gradient( 270deg,transparent 0%,var(--gradient-mid-color) 102px,var(--gradient-color) 246px )}:host([immersive-card]) .wide.image-pos-start .gradient{background:linear-gradient( 90deg,transparent 0%,var(--gradient-mid-color) 102px,var(--gradient-color) 246px )}:host([immersive-card]) .wide .heading:after{right:-100%;left:0}:host([immersive-card]) .wide.image-pos-start .heading:after{left:-100%;right:0}::slotted([slot="content-indicator"]){left:calc(var(--msft-article-padding) * 1px);pointer-events:none}:host([immersive-card]) .wide.image-pos-start ::slotted([slot="content-indicator"]){left:calc(50% + var(--msft-article-padding) * 1px)}:host([immersive-card]) .half .text{padding:16px 0 16px 16px}:host([immersive-card]) .half .image{padding:16px 16px 6px 8px}:host([immersive-card]) .half .gradient,:host([immersive-card]) .no-image.half .gradient{background:linear-gradient( 76.68deg,var(--gradient-color) 0%,var(--gradient-mid-color) 100% )}:host([immersive-card]) .no-image.half .actions{left:16px}`,d.A` .hide-story-wrapper{left:16px}.hide-story{left:-32px}:host([immersive-card]) .image{left:0}:host([immersive-card]) .image-pos-start .image{left:initial;right:0}:host([immersive-card]) .text{right:0}:host([immersive-card]) .image-pos-start .text{left:0;right:initial}:host([immersive-card]) .gradient{right:0;left:-120px}:host([immersive-card]) .wide.no-image .gradient{left:-100%}:host([immersive-card]) .image-pos-start .gradient{left:0;right:-120px}:host([immersive-card]) .wide .gradient{background:linear-gradient( 90deg,transparent 0%,var(--gradient-mid-color) 102px,var(--gradient-color) 246px )}:host([immersive-card]) .wide.image-pos-start .gradient{background:linear-gradient( 270deg,transparent 0%,var(--gradient-mid-color) 102px,var(--gradient-color) 246px )}::slotted([slot="content-indicator"]){right:calc(var(--msft-article-padding) * 1px)}:host([immersive-card]) .wide.image-pos-start ::slotted([slot="content-indicator"]){right:calc(50% + var(--msft-article-padding) * 1px)}:host([immersive-card]) .half .text{padding:16px 16px 16px 0px}:host([immersive-card]) .half .image{padding:16px 8px 16px 16px}:host([immersive-card]) .half .gradient,:host([immersive-card]) .no-image.half .gradient{background:linear-gradient( 294deg,var(--gradient-color) 0%,var(--gradient-mid-color) 100% )}:host([immersive-card]) .no-image.half .actions{right:16px}`;const g=d.A`
    ${(0,h.V)("block")} :host{--msft-article-padding:16;--msft-flex-button-padding:40;--msft-card-font-color:${n.l};width:100%;height:100%;outline:none}.article{position:relative;overflow:hidden;display:grid;grid-template-columns:1fr auto;column-gap:calc(var(--msft-article-padding) * 1px)}.heading,.abstract{display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical}.heading{hyphens:auto;font-weight:600;text-decoration:none;color:var(--msft-card-font-color);font-size:var(--msft-article-heading-font-size,16px);line-height:var(--msft-article-heading-line-height,24px);-webkit-line-clamp:var(--heading-max-lines,3);margin:0;outline:0}:host([immersive-card]) .article.half{display:grid;grid-template-columns:1fr auto;grid-gap:0;width:100%;height:100%;overflow:visible;position:relative;background:#FFFFFF}:host([immersive-card]) .half .text{grid-column:1/2;height:100%;position:unset}:host([immersive-card]) .half .image{grid-column:2/3;width:82px;height:82px;position:relative;z-index:1;pointer-events:none}:host([immersive-card]) .half .image ::slotted(img){border-radius:var(--half-card-image-corner-radius,6px)}:host([immersive-card]) .half .actions{width:100%;padding:16px;box-sizing:border-box;position:absolute;bottom:0;left:0;right:0}:host([immersive-card]) .article.no-image.half{display:flex;grid-template-columns:none}:host([immersive-card]) .no-image.half .text{padding:16px}:host([immersive-card]) .no-image.half .actions{padding:0}:host([immersive-card]) .half .gradient,:host([immersive-card]) .no-image.half .gradient{position:absolute;top:0;bottom:0;left:0;right:0}:host([immersive-card]:hover) .half .gradient,:host([immersive-card]:hover) .no-image.half .gradient{background:var(--gradient-color);opacity:0.4;z-index:-1}:host([immersive-card]:hover) .article.half,:host([immersive-card]:hover) .no-image.half{background:transparent}:host([immersive-card]) .half .heading,:host([immersive-card]) .no-image.half .heading{font-size:var(--msft-article-heading-font-size,14px);line-height:var(--msft-article-heading-line-height,20px);-webkit-line-clamp:var(--heading-max-lines,2);margin-bottom:0}:host([immersive-card]) .has-abstract.half .heading{-webkit-line-clamp:var(--heading-max-lines,1)}:host([immersive-card]) .half .abstract,:host([immersive-card]) .no-image.half .abstract{font-size:var(--abstract-font-size,12px);line-height:var(--abstract-line-height,16px);-webkit-line-clamp:var(--heading-max-lines,1);margin-bottom:0}:host([immersive-card]) .article.no-image.half .attribution ::slotted(msft-attribution){max-width:100%}:host([immersive-card]) .half .attribution ::slotted(msft-attribution){margin-bottom:14px;max-width:170px;overflow:hidden}.heading:hover,.heading:${c.N}{text-decoration:underline}.heading:focus{outline:auto}.heading:after{content:"";position:absolute;bottom:0;right:0;left:0;width:var(--card-width);height:var(--card-height);z-index:1}.wide .heading:after,.no-image .heading:after{top:0}.abstract,::slotted(p){-webkit-line-clamp:var(--abstract-max-lines,3);font-weight:400;font-size:var(--abstract-font-size,14px);line-height:var(--abstract-line-height,20px);font-kerning:auto;margin:0;opacity:0.8}:host([immersive-card]){background:${s.p}}:host([immersive-card]) .no-image{background:#FFFFFF}:host([immersive-card]) ::slotted(img){max-width:100%}.image-pos-end{grid-template-columns:auto 1fr}:host([immersive-card]) .article{position:relative;overflow:visible;grid-template-columns:none;height:100%;display:block}:host([immersive-card]) .attribution ::slotted(msft-attribution),:host([immersive-card]) .abstract{color:var(--msft-card-font-color);margin-bottom:12px}:host([immersive-card]) .heading{color:var(--msft-card-font-color);margin-bottom:6px}:host([immersive-card]) .image{position:absolute;display:block;max-width:100%;top:0;transition:opacity 0.1s linear}:host([immersive-card]:${c.N}) .image,:host([immersive-card]:hover) .image{opacity:0.5}:host([immersive-card]) .text{position:absolute;bottom:0;width:100%;z-index:1;padding:24px calc(var(--msft-article-padding) * 1px) 16px calc(var(--msft-article-padding) * 1px);box-sizing:border-box}:host([immersive-card]) .gradient{background:linear-gradient( 180deg,transparent 0%,var(--gradient-mid-color) 62.5%,var(--gradient-color) 100% );position:absolute;top:-21px;bottom:79px;z-index:-1}:host([immersive-card]) .no-image .gradient,:host([immersive-card]) .wide.no-image .gradient{background:linear-gradient( 44.24deg,var(--gradient-color) 0%,var(--gradient-mid-color) 100% )}:host([immersive-card]) .no-image .gradient,:host([immersive-card]) .wide .gradient{bottom:0}:host([immersive-card]) ::slotted([slot="start"]),:host([immersive-card]) ::slotted([slot="end"]){color:var(--msft-card-font-color);position:relative}:host([immersive-card]) .wide .text{height:100%;width:50%}:host([immersive-card]) .text{padding:52px calc(var(--msft-article-padding) * 1px) 16px calc(var(--msft-article-padding) * 1px)}:host([immersive-card]) .no-image .text{height:100%;width:100%;bottom:initial;padding:56px calc(var(--msft-article-padding) * 1px) 16px calc(var(--msft-article-padding) * 1px)}:host([immersive-card]) .actions{display:flex;justify-content:space-between}:host([immersive-card]) .article.no-image .actions,:host([immersive-card]) .article.wide .actions,:host([immersive-card]) .article.wide.image-pos-end.flex-card .actions{position:absolute;bottom:calc(var(--msft-article-padding) * 1px);width:calc(100% - calc(var(--msft-article-padding) * 2px))}:host([immersive-card]) .article.wide.flex-card .actions{width:calc(100% - calc((var(--msft-article-padding) * 2px) + (var(--msft-flex-button-padding) * 1px)))}::slotted([slot="start-action"]),::slotted([slot="end-action"]),::slotted([slot="hide-story"]){z-index:4}:host([immersive-card]) .hide-story-wrapper{position:absolute;display:flex;flex-direction:row;top:16px}:host([immersive-card]) .hide-story{display:flex;justify-content:center;align-items:center;opacity:0;transition:opacity 0.1s linear}:host([immersive-card]:hover) .hide-story,:host([immersive-card]:focus-within) .hide-story{opacity:1}:host([immersive-card]) ::slotted(fluent-button),::slotted(fluent-button){--control-corner-radius:40;height:28px;min-width:28px}::slotted([slot="hide-story"]){font-family:${o.O};
        display: flex;
        padding: 0;
        justify-content: center;
        align-items: center;
        position: relative;
        outline: none;
        font-size: ${a.K};
        line-height: ${a.Z};
        height: 28px;
        min-width: 28px;
        background-color: rgba(0,0,0,0.54);
        color: #FFFFFF;
        fill: #FFFFFF;
        cursor: pointer;
        border-radius: 100%;
        border: 2px solid transparent;
        margin-inline-start: 4px;
    }

    ::slotted([slot="hide-story"]:${c.N}){border-color:${r.WN};
    }

    ::slotted([slot="hide-story"]:${c.N}),::slotted([slot="hide-story"]:hover){background-color:rgba(0,0,0,0.62)}::slotted([slot="hide-story"]:active){background-color:rgba(0,0,0,0.49)}::slotted([slot="content-indicator"]){position:absolute;top:calc(var(--msft-article-padding) * 1px);z-index:1}@supports not (contain:content){:host([immersive-card]){overflow:hidden}}.hide-story-wrapper{inset-inline-end:16px}.hide-story{inset-inline-end:-32px}:host([immersive-card]) .image{inset-inline-end:0}:host([immersive-card]) .image-pos-start .image{inset-inline-end:initial;inset-inline-start:0}:host([immersive-card]) .text{inset-inline-start:0}:host([immersive-card]) .image-pos-start .text{inset-inline-end:0;inset-inline-start:initial}:host([immersive-card]) .gradient{inset-inline-start:0;inset-inline-end:-84px}:host([immersive-card]) .wide.no-image .gradient{inset-inline-end:-100%}:host([immersive-card]) .image-pos-start .gradient{inset-inline-end:0;inset-inline-start:-120px}:host([immersive-card]) .wide .heading:after{inset-inline-end:-100%;inset-inline-start:0}:host([immersive-card]) .wide.image-pos-start .heading:after{inset-inline-start:-100%;inset-inline-end:0}::slotted([slot="content-indicator"]){inset-inline-start:calc(var(--msft-article-padding) * 1px);pointer-events:none}:host([immersive-card]) .wide.image-pos-start ::slotted([slot="content-indicator"]){inset-inline-start:calc(50% + var(--msft-article-padding) * 1px)}:host([immersive-card]) .half .text{padding-block:16px;padding-inline-end:0;padding-inline-start:16px}:host([immersive-card]) .half .image{padding-block-start:16px;padding-inline-end:16px;padding-block-end:6px;padding-inline-start:8px}:host([immersive-card]) .no-image.half .actions{padding-inline-start:16px}:host([immersive-card]) .wide .gradient-ltr{background:linear-gradient( 270deg,transparent 0%,var(--gradient-mid-color) 102px,var(--gradient-color) 246px )}:host([immersive-card]) .wide.image-pos-start .gradient-ltr{background:linear-gradient( 90deg,transparent 0%,var(--gradient-mid-color) 102px,var(--gradient-color) 246px )}:host([immersive-card]) .half .gradient-ltr,:host([immersive-card]) .no-image.half .gradient-ltr{background:linear-gradient( 76.68deg,var(--gradient-color) 0%,var(--gradient-mid-color) 100% )}:host([immersive-card]) .wide .gradient-rtl{background:linear-gradient( 90deg,transparent 0%,var(--gradient-mid-color) 102px,var(--gradient-color) 246px )}:host([immersive-card]) .wide.image-pos-start .gradient-rtl{background:linear-gradient( 270deg,transparent 0%,var(--gradient-mid-color) 102px,var(--gradient-color) 246px )}:host([immersive-card]) .half .gradient-rtl,:host([immersive-card]) .no-image.half .gradient-rtl{background:linear-gradient( 294deg,var(--gradient-color) 0%,var(--gradient-mid-color) 100% )}`.withBehaviors((0,l.mr)(d.A` :host([immersive-card]),:host([immersive-card]) .heading{background:${m.A.ButtonFace};
                color: ${m.A.ButtonText}}:host([immersive-card]) .attribution ::slotted(msft-attribution),:host([immersive-card]) .abstract{background:${m.A.ButtonFace};
                color: ${m.A.CanvasText}}:host([href]) .heading,:host([immersive-card][href]) .heading{color:${m.A.LinkText};
            }

            .heading:hover,
            .heading:${c.N}{text-decoration:underline}:host([immersive-card]) .gradient{background:linear-gradient( 180deg,transparent 0%,${m.A.ButtonFace} 62.5%,
                    ${m.A.ButtonFace} 100% )}:host([immersive-card]) .wide .gradient{background:linear-gradient( 270deg,transparent 0%,${m.A.ButtonFace} 102px,
                    ${m.A.ButtonFace} 246px )}:host([immersive-card]) .wide.image-pos-start .gradient{background:linear-gradient( 90deg,transparent 0%,${m.A.ButtonFace} 102px,
                    ${m.A.ButtonFace} 246px )}:host([immersive-card]) .no-image .gradient,:host([immersive-card]) .wide.no-image .gradient{background:linear-gradient( 65.94deg,${m.A.ButtonFace} 8.23%,
                    ${m.A.ButtonFace} 93.81% )}:host([immersive-card]) .hide-story{background:none}.abstract,::slotted(p){opacity:1}::slotted([slot="hide-story"]){background-color:${m.A.ButtonFace};
                border-color: ${m.A.ButtonText};
                fill: ${m.A.ButtonText};
            }

            ::slotted([slot="hide-story"]:hover),
            ::slotted([slot="hide-story"]:${c.N}){background-color:${m.A.Highlight};
                border-color: ${m.A.ButtonText};
                fill: ${m.A.HighlightText}}:host([immersive-card]) .half .gradient,:host([immersive-card]) .no-image.half .gradient{background:${m.A.ButtonFace};
            }
        `))},92135(i,t,e){e.d(t,{hN(){return m}});var a,r,s=e(56911),o=e(60815),n=e(92011),d=e(38493),h=e(55230),l=e(5096),c=e(72691);!function(i){i._1_column="1_column",i._2_column="2_column"}(a||(a={})),function(i){i.vertical="vertical",i.horizontal="horizontal"}(r||(r={}));class m extends n.L{constructor(){super(...arguments),this.slideKeyPressHandler=(i,t)=>{this.adjust(t)},this.layout=a._2_column,this.orientation=r.horizontal,this.activeindicator=!1,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.isHovered=!1,this.isFocused=!1,this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=i=>"true"===i.getAttribute("aria-disabled"),this.isFocusableElement=i=>!this.isDisabledElement(i),this.setTabs=()=>{const i=this.isHorizontal()?"gridColumn":"gridRow";this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex(),this.tabs.forEach((t,e)=>{if("tab"===t.slot&&this.isFocusableElement(t)){this.activeindicator&&(this.showActiveIndicator=!0);const i=this.tabIds[e],a=this.tabpanelIds[e];t.setAttribute("id","string"!=typeof i?`tab-${e+1}`:i),t.setAttribute("aria-selected",this.activeTabIndex===e?"true":"false"),t.setAttribute("aria-controls","string"!=typeof a?`panel-${e+1}`:a),t.addEventListener("click",this.handleTabClick),t.addEventListener("keydown",this.handleTabKeyDown),t.setAttribute("tabindex",this.activeTabIndex===e?"0":"-1"),this.activeTabIndex===e&&(this.activetab=t)}else this.showActiveIndicator=!1;t.style[i]=`${e+1}`,this.isHorizontal()?t.classList.remove("vertical"):t.classList.add("vertical")})},this.setTabPanels=()=>{this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.tabpanels.forEach((i,t)=>{const e=this.tabIds[t],a=this.tabpanelIds[t];i.setAttribute("id","string"!=typeof a?`panel-${t+1}`:a),i.setAttribute("aria-labelledby","string"!=typeof e?`tab-${t+1}`:e),this.activeTabIndex!==t?i.setAttribute("hidden",""):i.removeAttribute("hidden")})},this.handleTabClick=i=>{const t=i.currentTarget;1===t.nodeType&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(t),this.setComponent()),i.preventDefault()},this.handleTabKeyDown=i=>{const t=i.key;if(this.isHorizontal())switch(t){case h.kT:i.preventDefault(),this.adjustBackward(i);break;case h.bb:i.preventDefault(),this.adjustForward(i)}else switch(t){case h.I5:i.preventDefault(),this.adjustBackward(i);break;case h.HX:i.preventDefault(),this.adjustForward(i)}switch(t){case h.kE:i.preventDefault(),this.adjust(-this.activeTabIndex);break;case h.FM:i.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1)}},this.adjustForward=i=>{const t=this.tabs;let e=0;for(e=this.activetab?t.indexOf(this.activetab)+1:1,e===t.length&&(e=0);e<t.length&&t.length>1;){if(this.isFocusableElement(t[e])){this.moveToTabByIndex(t,e);break}if(this.activetab&&e===t.indexOf(this.activetab))break;e+1>=t.length?e=0:e+=1}},this.adjustBackward=i=>{const t=this.tabs;let e=0;for(e=this.activetab?t.indexOf(this.activetab)-1:0,e=e<0?t.length-1:e;e>=0&&t.length>1;){if(this.isFocusableElement(t[e])){this.moveToTabByIndex(t,e);break}e-1<0?e=t.length-1:e-=1}},this.moveToTabByIndex=(i,t)=>{const e=i[t];this.activetab=e,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=t,e.focus(),this.setComponent()}}autoScrollChanged(){this.$fastController.isConnected&&this.updateAutoScroll()}autoScrollIntervalMsChanged(){this.$fastController.isConnected&&this.updateAutoScroll()}handleChange(){this.direction=c.o.getValueFor(this)}connectedCallback(){super.connectedCallback(),this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex(),this.direction=c.o.getValueFor(this),c.o.subscribe(this),this.activeindicator||(this.activeindicator=!1),this.updateAutoScroll()}disconnectedCallback(){super.disconnectedCallback(),c.o.unsubscribe(this),window.clearTimeout(this.autoScrollTimer)}activeidChanged(){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabpanelsChanged(){this.$fastController.isConnected&&this.tabpanels.length<=this.tabs.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition(),this.$emit("tabpanels-changed",this.tabpanels))}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):this.initialId&&this.tabs&&this.tabs.length>0?(0,l.Vf)(0,this.tabs.length-1,this.initialId):0}getTabIds(){return void 0===this.tabs?[null]:this.tabs.map(i=>i.getAttribute("id"))}getTabPanelIds(){return void 0===this.tabpanels?[null]:this.tabpanels.map(i=>i.getAttribute("id"))}setComponent(i){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.change(),this.setTabs(),this.handleActiveIndicatorPosition(),this.setTabPanels(),i||this.focusTab(),this.change())}isHorizontal(){return this.orientation===r.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&this.activeindicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;const i=this.isHorizontal()?"gridColumn":"gridRow",t=this.isHorizontal()?"translateX":"translateY",e=this.isHorizontal()?"offsetLeft":"offsetTop",a=this.activeIndicatorRef[e];this.activeIndicatorRef.style[i]=`${this.activeTabIndex+1}`;const r=this.activeIndicatorRef[e];this.activeIndicatorRef.style[i]=`${this.prevActiveTabIndex+1}`;const s=r-a;this.activeIndicatorRef.style.transform=`${t}(${s}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",()=>{this.ticking=!1,this.activeIndicatorRef.style[i]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${t}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")})}adjust(i,t){void 0!==this.tabs&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=(0,l.Vf)(0,this.tabs.length-1,this.activeTabIndex+i),this.setComponent(t))}focusTab(){this.tabs[this.activeTabIndex].focus()}handleFocusIn(i){this.isFocused=!0,this.updateAutoScroll()}handleFocusOut(i){null!==i.relatedTarget&&this.contains(i.relatedTarget)||(this.isFocused=!1,this.updateAutoScroll())}handleMouseOver(i){this.isHovered=!0,this.updateAutoScroll()}handleMouseOut(i){this.isHovered=!1,this.updateAutoScroll()}updateAutoScroll(){let i=!1;this.isHovered||this.isFocused||!this.autoScroll||(i=!0),i&&void 0===this.autoScrollTimer&&(this.autoScrollTimer=window.setTimeout(()=>{this.autoScrollDelayMs&&(this.autoScrollDelayMs=0),this.adjust(1,!0),this.autoScrollTimer=void 0,this.updateAutoScroll()},(this.autoScrollDelayMs||0)+(this.autoScrollIntervalMs||6e3))),i||void 0===this.autoScrollTimer||(window.clearTimeout(this.autoScrollTimer),this.autoScrollTimer=void 0)}}(0,s.Cg)([d.CF],m.prototype,"layout",void 0),(0,s.Cg)([(0,d.CF)({attribute:"auto-scroll",mode:"boolean"})],m.prototype,"autoScroll",void 0),(0,s.Cg)([(0,d.CF)({attribute:"auto-scroll-interval-ms",converter:d.R$})],m.prototype,"autoScrollIntervalMs",void 0),(0,s.Cg)([(0,d.CF)({attribute:"auto-scroll-delay-ms",converter:d.R$})],m.prototype,"autoScrollDelayMs",void 0),(0,s.Cg)([o.sH],m.prototype,"nextFlipperTelemetryTag",void 0),(0,s.Cg)([o.sH],m.prototype,"previousFlipperTelemetryTag",void 0),(0,s.Cg)([o.sH],m.prototype,"direction",void 0),(0,s.Cg)([d.CF],m.prototype,"orientation",void 0),(0,s.Cg)([d.CF],m.prototype,"activeid",void 0),(0,s.Cg)([(0,d.CF)({attribute:"initial-id",converter:d.R$})],m.prototype,"initialId",void 0),(0,s.Cg)([o.sH],m.prototype,"tabs",void 0),(0,s.Cg)([o.sH],m.prototype,"tabpanels",void 0),(0,s.Cg)([(0,d.CF)({mode:"boolean"})],m.prototype,"activeindicator",void 0),(0,s.Cg)([o.sH],m.prototype,"activeIndicatorRef",void 0),(0,s.Cg)([o.sH],m.prototype,"showActiveIndicator",void 0)},93533(i,t,e){e.d(t,{m(){return $}});var a=e(26813),r=e(37180),s=e(74849),o=e(64187),n=e(22131),d=e(50882),h=e(7896),l=e(41123),c=e(48751),m=e(57416),g=e(4283);const p=s.A`
    ${(0,o.V)("grid")} :host {
        box-sizing: border-box;
        font-family: ${h.O};
        font-size: ${l.K};
        line-height: ${l.Z};
        color: ${c.l};
        grid-template-columns: auto 1fr auto;
        grid-template-rows: auto 1fr;
    }

    .tablist {
        display: grid;
        grid-template-rows: auto auto;
        grid-template-columns: auto;
        position: relative;
        width: max-content;
        align-self: end;
    }

    ::slotted([slot="start"]),
    ::slotted([slot="end"]) {
        align-self: center;
    }

    :host([orientation="horizontal"]) ::slotted([slot="end"]) {
        grid-column: 3;
    }

    .active-indicator {
        grid-row: 2;
        grid-column: 1;
        width: 20px;
        height: 3px;
        border-radius: calc(${m.Pb} * 1px);
        justify-self: center;
        background: ${g.IR};
    }

    .activeIndicatorTransition {
        transition: transform 0.2s ease-in-out;
    }

    .tabpanel {
        grid-row: 2;
        grid-column-start: 1;
        grid-column-end: 4;
        position: relative;
    }

    :host([orientation="vertical"]) {
        grid-template-rows: auto 1fr auto;
        grid-template-columns: auto 1fr;
    }

    :host([orientation="vertical"]) .tablist {
        grid-row-start: 2;
        grid-row-end: 2;
        display: grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        position: relative;
        width: max-content;
        justify-self: end;
        width: 100%;
    }

    :host([orientation="vertical"]) .tabpanel {
        grid-column: 2;
        grid-row-start: 1;
        grid-row-end: 4;
    }

    :host([orientation="vertical"]) ::slotted([slot="end"]) {
        grid-row: 3;
    }

    :host([orientation="vertical"]) .active-indicator {
        grid-column: 1;
        grid-row: 1;
        width: 3px;
        height: 20px;
        border-radius: calc(${m.Pb} * 1px);
        align-self: center;
        background: ${g.IR};
    }

    :host([orientation="vertical"]) .activeIndicatorTransition {
        transition: transform 0.2s linear;
    }
`.withBehaviors((0,n.mr)(s.A`
            .active-indicator,
            :host([orientation="vertical"]) .active-indicator {
                forced-color-adjust: none;
                background: ${d.A.Highlight};
            }
        `));var v=e(96950),u=e(82774),f=e(69259),b=e(60402),x=e(35106);const w=function(i={}){return v.qy`
        ${(0,x.LT)(i)}
        <div class="tablist" part="tablist" role="tablist">
            <slot name="tab" ${(0,u.e)("tabs")}></slot>

            ${(0,f.z)(i=>i.showActiveIndicator,v.qy`
                    <div
                        ${(0,b.K)("activeIndicatorRef")}
                        class="active-indicator"
                        part="active-indicator"
                    ></div>
                `)}
        </div>
        ${(0,x.aO)(i)}
        <div class="tabpanel" part="tabpanel">
            <slot name="tabpanel" ${(0,u.e)("tabpanels")}></slot>
        </div>
    `}(),$=a.D.compose({name:`${r.c.prefix}-tabs`,template:w,styles:p})},94407(i,t,e){e.d(t,{L(){return n}});var a=e(56911),r=e(60815),s=e(92011),o=e(38493);class n extends s.L{constructor(){super(...arguments),this.expanded=!1}defaultItemsChanged(){this.$fastController.isConnected&&(this.shouldanimate=this.defaultItems.length>0)}}(0,a.Cg)([(0,o.CF)({mode:"boolean"})],n.prototype,"expanded",void 0),(0,a.Cg)([r.sH],n.prototype,"defaultItems",void 0),(0,a.Cg)([(0,o.CF)({mode:"boolean",attribute:"animate"})],n.prototype,"shouldanimate",void 0)},95324(i,t,e){e.d(t,{K(){return u}});var a=e(99751);class r extends a.s{}var s=e(60347),o=e(74849),n=e(50882),d=e(64187),h=e(73477),l=e(22131),c=e(7896),m=e(48751),g=e(26920),p=e(14996);const v=o.A`
    ${(0,d.V)("inline-flex")} :host{box-sizing:border-box;font-family:${c.O};
        min-height: 6px;
        min-width: 6px;
        background-color: ${m.l};border-radius:20px;opacity:0.4;grid-row:1;z-index:1;margin:0px 2px}:host([aria-selected="true"]){z-index:2;opacity:1;min-width:30px}:host(:hover),:host(:active){background:${m.l};
        opacity: 1;
    }

    :host(:${h.N}){outline:none;box-shadow:0 0 0 calc((${g.vd} - ${g.XA}) * 1px)
            rgba(0,0,0,1), 0 0 0 calc((${g.vd} + ${g.XA}) * 1px)
            ${p.WN}}:host(:focus){outline:none}`.withBehaviors((0,l.mr)(o.A` :host{forced-color-adjust:none;border-color:transparent;color:${n.A.ButtonText};
                fill: ${n.A.ButtonText}}:host(:hover),:host([aria-selected="true"]:hover){background:${n.A.Highlight};
                color: ${n.A.HighlightText};
                fill: ${n.A.HighlightText}}:host([aria-selected="true"]){background:${n.A.HighlightText};
                color: ${n.A.Highlight};
                fill: ${n.A.Highlight};
            }
            :host(:${h.N}){border-color:${n.A.ButtonText};
                box-shadow: 0 0 0 calc((${g.vd} - ${g.XA}) * 1px)
                    rgba(0,0,0,1), 0 0 0 calc((${g.vd} + ${g.XA}) * 1px)
                    ${n.A.ButtonText};
            }
        `)),u=r.compose({name:"msn-info-pane-tab",template:(0,s.M)(),styles:v})},96193(i,t,e){e.d(t,{z(){return r}});var a=e(92011);class r extends a.L{}},99751(i,t,e){e.d(t,{s(){return d}});var a=e(56911),r=e(92011),s=e(38493),o=e(35106),n=e(88458);class d extends r.L{}(0,a.Cg)([(0,s.CF)({mode:"boolean"}),(0,a.Sn)("design:type",Boolean)],d.prototype,"disabled",void 0),(0,n.X)(d,o.qw)}}]);