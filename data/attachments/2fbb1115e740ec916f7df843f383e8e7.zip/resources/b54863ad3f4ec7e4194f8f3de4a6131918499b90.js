"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_traffic-card-settings_dist_index_js-_21391"],{4968(t,i,e){e.d(i,{f(){return c}});var o=e(64187),s=e(74849),a=e(42792),n=e(99657),r=e(36452);const c=s.A.partial`position: relative; z-index: ${n.D};`;s.A`
    ${a.e}
    ${a.nH}

    ${(0,o.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${c}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${r.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${r.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${r.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(a.kc)},99061(t,i,e){e.d(i,{msftTrafficCardSettings(){return Z}});var o=e(65636),s=e(37180),a=e(88817),n=e(121),r=e(65007),c=e(48785),l=e(98790),h=e(99900),d=e(56911),u=e(68073),g=e(16032),p=e(52875),m=e(90379),v=e(92011),f=e(38493),b=e(60815);const x=["_1x_2y","_2x_2y","_3x_2y"];class $ extends v.L{get locationAutoSuggestClient(){return this._locationAutoSuggestClient||(this._locationAutoSuggestClient=(0,u.X)(this.locationAutoSuggestConfig)),this._locationAutoSuggestClient}get locationPdpClient(){return this._locationPdpClient||(this._locationPdpClient=new g.h),this._locationPdpClient}constructor(){super(),this.isValidMsa=!1,this.showSuggests=!0,this.hasLocationInput=!1,this.scenario="traffic",this.handleDocumentKeydown=t=>{!t.defaultPrevented&&this.suggestedLocations&&0!==this.suggestedLocations.length&&"Tab"===t.code&&(null==this.selectedLocation||this.selectedLocation<0||this.suggestedLocations&&this.suggestedLocations.length&&this.selectedLocation===this.suggestedLocations.length)&&(this.showSuggests=!1)},this.handleClickOutside=t=>{!t.defaultPrevented&&this.suggestedLocations&&0!==this.suggestedLocations.length&&(this.showSuggests=!1)},this.homeOptions=[],this.workOptions=[],this.radioGroup&&this.radioGroup.focus()}get getHeaderText(){return"_1x_3y"===this.size&&this.enableCommuteSettings&&this.isMsa&&this.isValidMsa?this.localizedStrings.editLocationsText:"commute"===this.scenario?this.localizedStrings.editHomeWorkHeader:this.localizedStrings.editCardText}get showInputControl(){return"Specify"===this.locationMode}get is2yHeight(){return x.includes(this.size)}makeDropdownItem(t,i){return{title:t,ariaLabel:t,onClick:()=>{this.scenario=i},isActive:this.scenario===i,telemetryTag:(0,m.i9)(i).getMetadataTag()}}get settingsDropdownItems(){return[this.makeDropdownItem(this.localizedStrings.editCardText,"traffic"),this.makeDropdownItem(this.localizedStrings.editHomeWorkHeader,"commute")]}handleInputForSuggest(t){this.showSuggests||(this.showSuggests=!0),t&&t.preventDefault(),this.selectedLocationName=void 0,this.geocodedSelectedLocation=void 0,this.inputControl&&(this.triggerLocationSuggest(this.inputControl.value),this.hasLocationInput=!!this.inputControl.value)}selectSuggestLocation(t,i){this.inputControl&&(this.inputControl.value=t),this.selectLocation(i)}chooseLocationMode(t){if(t.defaultPrevented||!t.target)return;t.preventDefault(),this.showSuggests=!1;const i=t.target.value;i!==this.locationMode&&(this.locationMode=i,window.setTimeout(()=>{this.showInputControl?this.inputControl&&this.inputControl.focus():this.detectLocationRadio&&this.detectLocationRadio.focus()},0))}async onDismissSettingsClick(){this.isUserLocationUpdated||this.isHomeUpdated||this.isWorkUpdated?this.openConfirmCancelBanner():this.cancelSetting()}cancelSetting(){this.onDismissBannerClick(),this.$emit("cancel"),this.inputControl&&(this.inputControl.value=""),this.scenario="traffic"}onDismissBannerClick(){this.cardBannerData=void 0}async openConfirmCancelBanner(){this.cardBannerData={bannerTitle:this.localizedStrings.commuteSettingStrings&&this.localizedStrings.commuteSettingStrings.bannerContentSaveChanges,bannerType:"yes-no",yesOverwriteOption:{tooltip:void 0,clickAction:()=>{this.saveSetting()}},noOverwriteOption:{tooltip:void 0,clickAction:()=>{this.cancelSetting()}},onDismissClick:()=>{this.onDismissBannerClick()}}}async saveSetting(){this.onDismissBannerClick();let t=Promise.resolve(),i=Promise.resolve(),e=Promise.resolve(),o=!1,s=!1;const a=this.isUserLocationUpdated;let n;if(a&&("Specify"===this.locationMode&&this.geocodedSelectedLocation?e=this.geocodedSelectedLocation.then(async t=>{t&&this.locationPdpClient.setHomeLocation(t)}):"AutoDetect"===this.locationMode&&(e=this.locationPdpClient.updateUserSettings("","1"))),this.homeCombobox&&(this.homeCombobox.value?(t=this.updateCommuteLocation(!0,this.homeOptions,this.homeCombobox),o=!0):t=(0,m.q$)("Home")),this.workCombobox&&(this.workCombobox.value?(i=this.updateCommuteLocation(!1,this.workOptions,this.workCombobox),s=!0):i=(0,m.q$)("Work")),await Promise.all([e,t,i]),this.localizedStrings){n=void 0;const t=this.isHomeUpdated,i=this.isWorkUpdated;t||i||!a?a?n=this.localizedStrings.generalLocationUpdatedToast:t&&i?n=this.localizedStrings.homeAndWorkSavedToast:t?n=o?this.localizedStrings.homeSavedToast:this.localizedStrings.homeRemovedToast:i&&(n=s?this.localizedStrings.workSavedToast:this.localizedStrings.workRemovedToast):"AutoDetect"===this.locationMode?n=this.localizedStrings.locationDetectedToast:this.selectedLocationName&&(n=this.localizedStrings.locationSpecifiedToast.replace("{0}",this.selectedLocationName))}this.$emit("save",{toastMessage:n,newLocationMode:this.locationMode}),this.inputControl&&(this.inputControl.value="")}async updateCommuteLocation(t,i,e){var o;if(-1===e.selectedIndex)return;const s=i[e.selectedIndex];s.displayName=(0,m.Dd)(s);const a=await(null===(o=this.commuteAutosuggestClient)||void 0===o?void 0:o.geocodeSuggestion(s));a&&await(0,m.yD)(t,a)}connectedCallback(){if(super.connectedCallback(),"_1x_1y"==this.size&&(this.size="_1x_2y"),this.inputControl){const t=this.inputControl.value.length;this.inputControl.setSelectionRange(t,t)}this.focus(),document.addEventListener("keydown",this.handleDocumentKeydown),document.addEventListener("click",this.handleClickOutside),this.loadCommuteLocations()}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this.handleDocumentKeydown),document.removeEventListener("click",this.handleClickOutside)}handleOnKeyDownSearchBox(t){if(!this.showSuggests||!this.suggestedLocations||0==this.suggestedLocations.length)return!0;switch(t.code){case"Tab":t.preventDefault(),t.shiftKey?(this.selectedLocation=-1,this.specifyLocationRadio&&this.specifyLocationRadio.focus()):(this.selectedLocation=0,this.focusSelectedElement());break;case"ArrowDown":t.preventDefault(),this.selectedLocation=0,this.focusSelectedElement()}return!0}focusSelectedElement(){if(null!=this.selectedLocation&&-1!=this.selectedLocation){var t;null===(t=this.selectedSuggestion.querySelectorAll("li")[this.selectedLocation].firstElementChild)||void 0===t||t.focus()}}handleOnKeyDownAutoSuggestBox(t){switch(t.code){case"Escape":this.showSuggests=!1,this.selectedLocation=-1,this.inputControl&&(this.inputControl.value=""),this.inputControl.focus();break;case"Enter":if(null!=this.selectedLocation){this.selectedSuggestion.querySelectorAll("li")[this.selectedLocation].click()}this.showSuggests=!1,this.selectedLocation=-1,this.inputControl.focus();break;case"Tab":null!=this.selectedLocation&&this.suggestedLocations&&(t.shiftKey?this.selectedLocation=(this.selectedLocation+this.suggestedLocations.length-1)%this.suggestedLocations.length:this.selectedLocation=(this.selectedLocation+1)%this.suggestedLocations.length,this.focusSelectedElement());break;case"ArrowDown":null!=this.selectedLocation&&this.suggestedLocations&&(this.selectedLocation=(this.selectedLocation+1)%this.suggestedLocations.length,this.focusSelectedElement());break;case"ArrowUp":null!=this.selectedLocation&&this.suggestedLocations&&(this.selectedLocation=(this.selectedLocation+this.suggestedLocations.length-1)%this.suggestedLocations.length,this.focusSelectedElement())}}selectLocation(t){if(!this.lastFetchedLocations||0===this.lastFetchedLocations.length)return;const i=this.lastFetchedLocations[t];i&&(this.geocodedSelectedLocation=this.locationAutoSuggestClient.geocodeSuggestion(i),this.selectedLocationName=(0,m.SV)(i)),this.suggestedLocations=void 0}async triggerLocationSuggest(t){let i;const e=t.trim();if(e){i=await this.locationAutoSuggestClient.getAutoSuggestResponse(e);const t=this.size;this.is2yHeight&&i&&i.length>3?i=i.slice(0,3):"_1x_1y"===t&&i&&i.length>1&&(i=i.slice(0,1)),this.lastFetchedLocations=i,null!=i&&i.length>0?this.suggestedLocations=i.map(t=>t.displayName||p.getAutoSuggestionName(t)):this.suggestedLocations=[this.localizedStrings.noLocationFound]}}async handleCommuteAutosuggest(t,i){var e,o;if(!t.data)return;const s=null===(e=t.target)||void 0===e?void 0:e.control.value;let a=await(null===(o=this.commuteAutosuggestClient)||void 0===o?void 0:o.getAutoSuggestResponse(s));"_1x_3y"!==this.size&&a&&(a=a.slice(0,4)),"home"===i&&a?this.homeOptions=a:a&&(this.workOptions=a)}clearCommuteOptions(t){"home"===t&&this.homeCombobox.value?this.homeCombobox.value="":"work"===t&&this.workCombobox.value&&(this.workCombobox.value="")}async loadCommuteLocations(){if(!this.commuteLocations){try{this.commuteLocations=await(0,m.ZX)(),this.isValidMsa=!0}catch(t){this.isValidMsa=!1}this.initialWorkName=this.commuteLocations&&this.commuteLocations.work&&this.commuteLocations.work.displayName,this.initialHomeName=this.commuteLocations&&this.commuteLocations.home&&this.commuteLocations.home.displayName}}get isWorkUpdated(){const t=this.workCombobox&&this.workCombobox.value;return!(!this.initialWorkName&&!t)&&t!==this.initialWorkName}get isHomeUpdated(){const t=this.homeCombobox&&this.homeCombobox.value;return!(!this.initialHomeName&&!t)&&t!==this.initialHomeName}get isUserLocationUpdated(){return!!("AutoDetect"===this.locationMode&&this.locationMode!==this.initialLocationMode||"Specify"===this.locationMode&&this.selectedLocationName)}}(0,d.Cg)([f.CF],$.prototype,"size",void 0),(0,d.Cg)([(0,f.CF)({attribute:"is-msa",mode:"boolean"})],$.prototype,"isMsa",void 0),(0,d.Cg)([(0,f.CF)({attribute:"enable-commute-settings",mode:"boolean"})],$.prototype,"enableCommuteSettings",void 0),(0,d.Cg)([(0,f.CF)({attribute:"valid-msa",mode:"boolean"})],$.prototype,"isValidMsa",void 0),(0,d.Cg)([(0,f.CF)({attribute:"initial-location-mode"})],$.prototype,"initialLocationMode",void 0),(0,d.Cg)([(0,f.CF)({attribute:"location-mode"})],$.prototype,"locationMode",void 0),(0,d.Cg)([(0,f.CF)({attribute:"autosuggest-state"})],$.prototype,"autoSuggestState",void 0),(0,d.Cg)([(0,f.CF)({attribute:"bottom-align",mode:"boolean"})],$.prototype,"bottomAlign",void 0),(0,d.Cg)([b.sH],$.prototype,"suggestedLocations",void 0),(0,d.Cg)([b.sH],$.prototype,"selectedLocation",void 0),(0,d.Cg)([b.sH],$.prototype,"selectedLocationName",void 0),(0,d.Cg)([b.sH],$.prototype,"showSuggests",void 0),(0,d.Cg)([b.sH],$.prototype,"hasLocationInput",void 0),(0,d.Cg)([b.sH],$.prototype,"scenario",void 0),(0,d.Cg)([b.sH],$.prototype,"detectLocationTelemetryTag",void 0),(0,d.Cg)([b.sH],$.prototype,"specifyLocationTelemetryTag",void 0),(0,d.Cg)([b.sH],$.prototype,"saveTelemetryTag",void 0),(0,d.Cg)([b.sH],$.prototype,"cancelTelemetryTag",void 0),(0,d.Cg)([b.sH],$.prototype,"suggestTelemetryTag",void 0),(0,d.Cg)([b.sH],$.prototype,"localizedStrings",void 0),(0,d.Cg)([b.sH],$.prototype,"commuteAutosuggestClient",void 0),(0,d.Cg)([b.sH],$.prototype,"homeOptions",void 0),(0,d.Cg)([b.sH],$.prototype,"workOptions",void 0),(0,d.Cg)([b.sH],$.prototype,"commuteLocations",void 0),(0,d.Cg)([b.sH],$.prototype,"superSdData",void 0),(0,d.Cg)([b.sH],$.prototype,"cardBannerData",void 0),(0,d.Cg)([b.sH],$.prototype,"locationAutoSuggestConfig",void 0),(0,d.Cg)([b.sH],$.prototype,"activeLocation",void 0),(0,d.Cg)([b.sH],$.prototype,"detectedLocation",void 0);var w=e(7896),y=e(45476),k=e(26920),_=e(36452),C=e(57416),S=e(61138),D=e(22131),A=e(4968),L=e(12640),T=e(74849);const z=(0,m.nX)("icons-wc/icons/traffic/HomeIcon.svg"),M=(0,m.nX)("icons-wc/icons/traffic/HomeSuperSVG.svg"),O=(0,m.nX)("icons-wc/icons/traffic/WorkIcon.svg"),I=(0,m.nX)("icons-wc/icons/traffic/WorkSuperSVG.svg"),B=(0,m.nX)("icons-wc/icons/traffic/SubtractCircleLight.svg"),H=(0,m.nX)("icons-wc/icons/traffic/SubtractCircleDark.svg"),P=T.A` .commute-icon.home{background:url(${z}) no-repeat center}.commute-icon.work{background:url(${O}) no-repeat center}.delete-icon{background:url(${B}) no-repeat center}.detected-location-name{color:##616161}`,U=T.A` .commute-icon.home{background:url(${M}) no-repeat center}.commute-icon.work{background:url(${I}) no-repeat center}.delete-icon{background:url(${H}) no-repeat center}.detected-location-name{color:#ADADAD}`,j=T.A` :host{font-family:${w.O}}:host([bottom-align][size="_1x_2y"]){top:var(--oneu-halfu-align-top,inherit)}.settings-inner{${A.f} position:relative}.edit-location-radio-group{inset-inline-start:8px}.detected-location-name{font-size:14px;font-weight:400;line-height:20px;margin-inline-start:36px;margin-inline-end:16px}.commute-icon{margin-inline-end:4px;width:26px;height:26px}.delete-icon{width:20px;height:20px}.commute-row{display:inline-grid;width:268px;grid-template-columns:26px auto 20px;gap:4px;margin-bottom:16px;align-items:center}.commute-text-field{width:100%;min-width:200px}.auto-suggest{width:${230..toString()}px;display:flex;border:1px solid var(--neutral-foreground-rest);border-radius:4px;height:30px;margin-inline-start:36px}.location-input{flex:1 0 0px;background:transparent;border:none;outline:none;padding-inline-start:9px;color:var(--neutral-foreground-rest);text-overflow:ellipsis;font-family:var(--body-font);font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);margin-top:auto;margin-bottom:auto;height:calc(100% - 4px);width:${230..toString()}px}.commute-text-field::part(indicator){display:none}.suggest-list-container{position:absolute}.suggest-list{display:block;position:absolute;list-style:none;background:${y.Wl};
        border: calc(${k.XA} * 1px) solid ${_.I2};
        border-radius: ${C.Pb};
        margin: 0px;
        margin-inline-start: 36px;
        padding: 0;
        z-index: 99;
        outline: none;
        width: ${230..toString()}px}.suggest-item{text-overflow:ellipsis;word-wrap:break-word;font-size:${S.k};
        line-height: ${S.F};position:relative;width:100%}.suggest-item::part(control){justify-content:flex-start}.suggest-item-text{overflow:hidden;width:${210..toString()}px;text-overflow:ellipsis;text-align:start}.suggest-item-text-2c{width:${522..toString()}px}.suggest-item-text-3c{width:${834..toString()}px}.section-header{font-weight:600;line-height:20px;font-size:14px;margin-bottom:12px;pointer-events:none}.commute-header{margin-top:20px}.location-box-2c{width:${542..toString()}px}.location-box-3c{width:${854..toString()}px;
    }
    `.withBehaviors((0,D.mr)(T.A` :host{forced-color-adjust:auto}`),new L.N(P,U));var E=e(96950),W=e(60402),F=e(69259),G=e(39957);const V=t=>{switch(t){case"_3x_2y":return"location-box-3c";case"_2x_2y":return"location-box-2c";default:return""}},K=E.qy`<fluent-option value=${(t,i)=>i.index||"0"}>${t=>(0,m.Dd)(t)}</fluent-option>`,N=E.qy`<li role="option" title="${t=>t}" aria-label="${t=>t}" @click="${(t,i)=>i.parent.selectSuggestLocation(t,i.index)}" data-t="${(t,i)=>i.parent.suggestTelemetryTag}"><fluent-button class="suggest-item" part="suggest-item" appearance="stealth" aria-hidden="true"><div class="suggest-item-text ${(t,i)=>(t=>{switch(t){case"_3x_2y":return"suggest-item-text-3c";case"_2x_2y":return"suggest-item-text-2c";default:return""}})(i.parent.size)}">${t=>t}</div></fluent-button></li>`,R=E.qy`<div class="auto-suggest ${t=>V(t.size)}"><input class="location-input ${t=>V(t.size)}" tabindex="0" title=${t=>t.localizedStrings.locationSearchPlaceholder} placeholder="${t=>t.localizedStrings.locationSearchPlaceholder}" @input=${t=>t.handleInputForSuggest()} @keydown="${(t,i)=>t.handleOnKeyDownSearchBox(i.event)}" value="${t=>"Specify"==t.initialLocationMode&&t.activeLocation?(0,m.SV)(t.activeLocation):""}" type="text" appearance="filled" autofocus="autofocus" autoComplete="off" aria-autocomplete="both" aria-controls="traffic-location-search-list" aria-owns="traffic-location-search-list" ${(0,W.K)("inputControl")} /></div>`,q=E.qy`<fluent-radio-group class="edit-location-radio-group" value="${t=>t.locationMode}" @change="${(t,i)=>t.chooseLocationMode(i.event)}" aria-labelledby="setlocationmode" name="set-location-mode" orientation="vertical" ${(0,W.K)("radioGroup")}><fluent-radio value="AutoDetect" data-t="${t=>t.detectLocationTelemetryTag}" ${(0,W.K)("detectLocationRadio")}>${t=>t.localizedStrings&&t.localizedStrings.locationDetect}</fluent-radio>${(0,F.z)(t=>"AutoDetect"===t.locationMode,E.qy`<div class="detected-location-name">${t=>t.detectedLocation&&(0,m.SV)(t.detectedLocation)}</div>`)}<fluent-radio value="Specify" data-t="${t=>t.specifyLocationTelemetryTag}" ${(0,W.K)("specifyLocationRadio")}>${t=>t.localizedStrings&&t.localizedStrings.locationSpecify}</fluent-radio></fluent-radio-group>`,J=E.qy` ${(0,F.z)(t=>"_1x_3y"===t.size,E.qy`<div class="section-header">${t=>t.localizedStrings.editCardText}</div>`)} ${q} ${(0,F.z)(t=>t.showInputControl,E.qy`${R}`)} ${(0,F.z)(t=>t.showSuggests&&t.hasLocationInput,E.qy`<div class="suggest-list-container" aria-live="polite" aria-expanded="${t=>!!t.suggestedLocations}" id="traffic-location-search-list" aria-label="${t=>t.localizedStrings.locationSearchPlaceholder}">${(0,F.z)(t=>t.suggestedLocations,E.qy`<ul class="suggest-list ${t=>V(t.size)}" part="suggest-list" ${(0,W.K)("selectedSuggestion")} @keydown="${(t,i)=>t.handleOnKeyDownAutoSuggestBox(i.event)}">${(0,F.z)(t=>t.showSuggests&&t.suggestedLocations&&t.suggestedLocations.length>0,E.qy`${(0,G.ux)(t=>t.suggestedLocations,N,{positioning:!0})}`)} ${(0,F.z)(t=>t.suggestedLocations&&0===t.suggestedLocations.length,E.qy`<li role="option" title="${t=>t.localizedStrings.noLocationFound}" class="suggest-item" part="suggest-item">${t=>t.localizedStrings.noLocationFound}</li>`)}</ul>`)}</div>`)}
`,Q=E.qy` ${(0,F.z)(t=>"_1x_3y"===t.size,E.qy`<div class="commute-header section-header">${t=>t.localizedStrings.editHomeWorkHeader}</div>`)}<div><div class="commute-row"><span class="commute-icon home"></span><span><msn-traffic-combobox class="commute-text-field" position="below" placeholder=${t=>t.localizedStrings.locationSearchPlaceholder} current-value=${t=>{var i;return null===(i=t.commuteLocations)||void 0===i||null===(i=i.home)||void 0===i?void 0:i.displayName}} @input=${async(t,i)=>await t.handleCommuteAutosuggest(i.event,"home")} ${(0,W.K)("homeCombobox")}>${(0,G.ux)(t=>t.homeOptions,K,{positioning:!0})}</msn-traffic-combobox></span><fluent-button aria-label=${t=>t.localizedStrings.clearText} @click=${t=>t.clearCommuteOptions("home")} class="delete-icon"></fluent-button></div><div class="commute-row"><span class="commute-icon work"></span><span><msn-traffic-combobox class="commute-text-field" position="below" placeholder=${t=>t.localizedStrings.locationSearchPlaceholder} current-value=${t=>{var i;return null===(i=t.commuteLocations)||void 0===i||null===(i=i.work)||void 0===i?void 0:i.displayName}} @input=${async(t,i)=>await t.handleCommuteAutosuggest(i.event,"work")} ${(0,W.K)("workCombobox")}>${(0,G.ux)(t=>t.workOptions,K,{positioning:!0})}</msn-traffic-combobox></span><fluent-button aria-label=${t=>t.localizedStrings.clearText} @click=${t=>t.clearCommuteOptions("work")} class="delete-icon"></fluent-button></div></div>`,X=E.qy` ${(0,F.z)(t=>"commute"!==t.scenario||"_1x_3y"===t.size,J)} ${(0,F.z)(t=>"commute"===t.scenario||"_1x_3y"===t.size&&t.isMsa&&t.isValidMsa,Q)}
`,Y=E.qy` ${(0,F.z)(t=>t.superSdData,E.qy`<responsive-sd-card responsive-sizing-enabled="true" size="${t=>t.size}" :data=${(t,i)=>{var e;const o=t.isMsa&&t.isValidMsa&&t.enableCommuteSettings&&"_1x_3y"!==t.size;return{...t.superSdData,cardSize:t.size,headerData:{...t.superSdData.headerData,titleNavigationLink:void 0,title:t.getHeaderText,isActionMenuAvailable:!1,isMoreSettingAvailable:!1,isDismissAvailable:!0,onDismissCard(){t.onDismissSettingsClick()},interestMenuData:o?{interestMenuItems:t.settingsDropdownItems,interestMenuToolTip:t.localizedStrings.dropdownTooltip}:void 0,telemetryContext:{dismissMenuTelemetryTag:t.cancelTelemetryTag}},footerData:{...null===(e=t.superSdData)||void 0===e?void 0:e.footerData,footerButton:{text:t.localizedStrings.saveLocationInfoText,ctaClick(){t.saveSetting()}}},immersiveCard:!1,darkCardFillColor:void 0,lightCardFillColor:void 0}}}><div slot="card-content"><div class="settings-inner">${X}</div>${(0,F.z)(t=>t.cardBannerData,E.qy`<cs-card-banner class="banner" :data="${t=>t.cardBannerData}" size="${t=>t.size}"></cs-card-banner>`)}</div></responsive-sd-card>`)}
`;o.m.define(s.c.registry),a.m.define(s.c.registry),n.m.define(s.c.registry),r.m.define(s.c.registry),c.m.define(s.c.registry),l.h.define(h.u.registry);const Z=$.compose({name:"msft-traffic-card-settings",template:Y,styles:j})}}]);