"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_traffic-card-settings_dist_index_js-_21390"],{121(t,i,e){e.d(i,{m(){return k}});var s=e(56911),o=e(92011),n=e(38493),a=e(60815),r=e(83781),l=e(55230),c=e(31157),h=e(42938);class d extends o.L{constructor(){super(...arguments),this.orientation=r.t.horizontal,this.radioChangeHandler=t=>{const i=t.target;i.checked&&(this.slottedRadioButtons.forEach(t=>{t!==i&&(t.checked=!1,this.isInsideFoundationToolbar||t.setAttribute("tabindex","-1"))}),this.selectedRadio=i,this.value=i.value,i.setAttribute("tabindex","0"),this.focusedRadio=i),t.stopPropagation()},this.moveToRadioByIndex=(t,i)=>{const e=t[i];this.isInsideToolbar||(e.setAttribute("tabindex","0"),e.readOnly?this.slottedRadioButtons.forEach(t=>{t!==e&&t.setAttribute("tabindex","-1")}):(e.checked=!0,this.selectedRadio=e)),this.focusedRadio=e,e.focus()},this.moveRightOffGroup=()=>{this.nextElementSibling?.focus()},this.moveLeftOffGroup=()=>{this.previousElementSibling?.focus()},this.focusOutHandler=t=>{const i=this.slottedRadioButtons,e=t.target,s=null!==e?i.indexOf(e):0,o=this.focusedRadio?i.indexOf(this.focusedRadio):-1;return(0===o&&s===o||o===i.length-1&&o===s)&&(this.selectedRadio?(this.focusedRadio=this.selectedRadio,this.isInsideFoundationToolbar||(this.selectedRadio.setAttribute("tabindex","0"),i.forEach(t=>{t!==this.selectedRadio&&t.setAttribute("tabindex","-1")}))):(this.focusedRadio=i[0],this.focusedRadio.setAttribute("tabindex","0"),i.forEach(t=>{t!==this.focusedRadio&&t.setAttribute("tabindex","-1")}))),!0},this.clickHandler=t=>{const i=t.target;if(i){const t=this.slottedRadioButtons;i.checked||0===t.indexOf(i)?(i.setAttribute("tabindex","0"),this.selectedRadio=i):(i.setAttribute("tabindex","-1"),this.selectedRadio=null),this.focusedRadio=i}t.preventDefault()},this.shouldMoveOffGroupToTheRight=(t,i,e)=>t===i.length&&this.isInsideToolbar&&e===l.bb,this.shouldMoveOffGroupToTheLeft=(t,i)=>(this.focusedRadio?t.indexOf(this.focusedRadio)-1:0)<0&&this.isInsideToolbar&&i===l.kT,this.checkFocusedRadio=()=>{null===this.focusedRadio||this.focusedRadio.readOnly||this.focusedRadio.checked||(this.focusedRadio.checked=!0,this.focusedRadio.setAttribute("tabindex","0"),this.focusedRadio.focus(),this.selectedRadio=this.focusedRadio)},this.moveRight=t=>{const i=this.slottedRadioButtons;let e=0;if(e=this.focusedRadio?i.indexOf(this.focusedRadio)+1:1,this.shouldMoveOffGroupToTheRight(e,i,t.key))this.moveRightOffGroup();else for(e===i.length&&(e=0);e<i.length&&i.length>1;){if(!i[e].disabled){this.moveToRadioByIndex(i,e);break}if(this.focusedRadio&&e===i.indexOf(this.focusedRadio))break;if(e+1>=i.length){if(this.isInsideToolbar)break;e=0}else e+=1}},this.moveLeft=t=>{const i=this.slottedRadioButtons;let e=0;if(e=this.focusedRadio?i.indexOf(this.focusedRadio)-1:0,e=e<0?i.length-1:e,this.shouldMoveOffGroupToTheLeft(i,t.key))this.moveLeftOffGroup();else for(;e>=0&&i.length>1;){if(!i[e].disabled){this.moveToRadioByIndex(i,e);break}if(this.focusedRadio&&e===i.indexOf(this.focusedRadio))break;e-1<0?e=i.length-1:e-=1}},this.keydownHandler=t=>{const i=t.key;if(i in l.Is&&this.isInsideFoundationToolbar)return!0;switch(i){case l.Mm:this.checkFocusedRadio();break;case l.bb:case l.HX:this.direction===c.O.ltr?this.moveRight(t):this.moveLeft(t);break;case l.kT:case l.I5:this.direction===c.O.ltr?this.moveLeft(t):this.moveRight(t);break;default:return!0}}}readOnlyChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{this.readOnly?t.readOnly=!0:t.readOnly=!1})}disabledChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{this.disabled?t.disabled=!0:t.disabled=!1})}nameChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{t.setAttribute("name",this.name)})}valueChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{t.value===this.value&&(t.checked=!0,this.selectedRadio=t)}),this.$emit("change")}slottedRadioButtonsChanged(t,i){this.slottedRadioButtons&&this.slottedRadioButtons.length>0&&this.setupRadioButtons()}get parentToolbar(){return this.closest('[role="toolbar"]')}get isInsideToolbar(){return this.parentToolbar??!1}get isInsideFoundationToolbar(){return!!this.parentToolbar?.$fastController}connectedCallback(){super.connectedCallback(),this.direction=(0,h.u)(this),this.setupRadioButtons()}disconnectedCallback(){super.disconnectedCallback(),this.slottedRadioButtons.forEach(t=>{t.removeEventListener("change",this.radioChangeHandler)})}setupRadioButtons(){const t=this.slottedRadioButtons.filter(t=>t.hasAttribute("checked")),i=t?t.length:0;if(i>1){t[i-1].checked=!0}let e=!1;if(this.slottedRadioButtons.forEach(t=>{void 0!==this.name&&t.setAttribute("name",this.name),this.disabled&&(t.disabled=!0),this.readOnly&&(t.readOnly=!0),this.value&&this.value===t.value?(this.selectedRadio=t,this.focusedRadio=t,t.checked=!0,t.setAttribute("tabindex","0"),e=!0):(this.isInsideFoundationToolbar||t.setAttribute("tabindex","-1"),t.checked=!1),t.addEventListener("change",this.radioChangeHandler)}),void 0===this.value&&this.slottedRadioButtons.length>0){const t=this.slottedRadioButtons.filter(t=>t.hasAttribute("checked")),i=null!==t?t.length:0;if(i>0&&!e){const e=t[i-1];e.checked=!0,this.focusedRadio=e,e.setAttribute("tabindex","0")}else this.slottedRadioButtons[0].setAttribute("tabindex","0"),this.focusedRadio=this.slottedRadioButtons[0]}}}(0,s.Cg)([(0,n.CF)({attribute:"readonly",mode:"boolean"}),(0,s.Sn)("design:type",Boolean)],d.prototype,"readOnly",void 0),(0,s.Cg)([(0,n.CF)({attribute:"disabled",mode:"boolean"}),(0,s.Sn)("design:type",Boolean)],d.prototype,"disabled",void 0),(0,s.Cg)([n.CF,(0,s.Sn)("design:type",String)],d.prototype,"name",void 0),(0,s.Cg)([n.CF,(0,s.Sn)("design:type",String)],d.prototype,"value",void 0),(0,s.Cg)([n.CF,(0,s.Sn)("design:type",String)],d.prototype,"orientation",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",Array)],d.prototype,"childItems",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",Array)],d.prototype,"slottedRadioButtons",void 0);var u=e(37180),p=e(74849),g=e(64187),m=e(74838);const b=p.A`
    ${(0,g.V)("flex")} :host {
        align-items: flex-start;
        margin: calc(${m.vR} * 1px) 0;
        flex-direction: column;
    }

    .positioning-region {
        display: flex;
        flex-wrap: wrap;
    }

    :host([orientation="vertical"]) .positioning-region {
        flex-direction: column;
    }

    :host([orientation="horizontal"]) .positioning-region {
        flex-direction: row;
    }
`;var v=e(96950),f=e(82774),$=e(10108);const x=v.qy`
        <template
            role="radiogroup"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            @click="${(t,i)=>t.clickHandler(i.event)}"
            @keydown="${(t,i)=>t.keydownHandler(i.event)}"
            @focusout="${(t,i)=>t.focusOutHandler(i.event)}"
        >
            <slot name="label"></slot>
            <div
                class="positioning-region ${t=>t.orientation===r.t.horizontal?"horizontal":"vertical"}"
                part="positioning-region"
            >
                <slot
                    ${(0,f.e)({property:"slottedRadioButtons",filter:(0,$.Y)("[role=radio]")})}
                ></slot>
            </div>
        </template>
    `,k=d.compose({name:`${u.c.prefix}-radio-group`,template:x,styles:b})},10300(t,i,e){e.d(i,{I(){return a}});var s=e(56911),o=e(98228),n=e(38493);class a extends o.a{appearanceChanged(t,i){t!==i&&(this.classList.add(i),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="outline")}}(0,s.Cg)([(0,n.CF)({mode:"fromView"}),(0,s.Sn)("design:type",String)],a.prototype,"appearance",void 0)},21082(t,i,e){e.d(i,{v(){return n}});var s=e(21743),o=e(96950);const n=(0,s.E)({indicator:o.qy`
        <svg
            class="select-indicator"
            part="select-indicator"
            viewBox="0 0 12 7"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                d="M11.85.65c.2.2.2.5 0 .7L6.4 6.84a.55.55 0 01-.78 0L.14 1.35a.5.5 0 11.71-.7L6 5.8 11.15.65c.2-.2.5-.2.7 0z"
            />
        </svg>
    `})},43774(t,i,e){e.d(i,{p4(){return m},ls(){return b},vA(){return g},nF(){return p}});var s=e(45755),o=e(68009),n=e(95239);const{create:a}=s.G,r=a("neutral-stroke-strong-hover-delta",40),l=a("neutral-stroke-strong-active-delta",16),c=a("neutral-stroke-strong-focus-delta",25);var h=e(31023);const{create:d}=s.G,u=d({name:"neutral-stroke-strong-recipe"},{evaluate(t){return function(t,i,e,s,n,a){const r=(0,o.F)(i),l=t.colorContrast(i,e),c=t.closestIndexOf(l);return{rest:l,hover:t.get(c+r*s),active:t.get(c+r*n),focus:t.get(c+r*a)}}(t(h.r),t(n.p),3,t(r),t(l),t(c))}}),p=d("neutral-stroke-strong-rest",t=>t(u).evaluate(t).rest),g=d("neutral-stroke-strong-hover",t=>t(u).evaluate(t).hover),m=d("neutral-stroke-strong-active",t=>t(u).evaluate(t).active),b=d("neutral-stroke-strong-focus",t=>t(u).evaluate(t).focus)},48785(t,i,e){e.d(i,{m(){return r}});var s=e(37180),o=e(10300),n=e(55358),a=e(21082);const r=o.I.compose({name:`${s.c.prefix}-combobox`,template:a.v,styles:n.R})},55358(t,i,e){e.d(i,{R(){return h}});var s=e(60993),o=e(73477),n=e(74849),a=e(11152),r=e(17767),l=e(41123),c=e(26920);const h=n.A`
    ${a.x9}

    :host(:empty) .listbox {
        display: none;
    }

    :host([disabled]) *,
    :host([disabled]) {
        cursor: ${s.Z};
        user-select: none;
    }

    :host(:active) .selected-value {
        user-select: none;
    }

    .selected-value {
        -webkit-appearance: none;
        background: transparent;
        border: none;
        color: inherit;
        font-size: ${l.K};
        line-height: ${l.Z};
        height: calc(100% - ${c.XA} * 1px));
        margin: auto 0;
        width: 100%;
    }

    .selected-value:hover,
    .selected-value:${o.N},
    .selected-value:disabled,
    .selected-value:active {
        outline: none;
    }
`.withBehaviors((0,r.f)("filled",a.x7))},88817(t,i,e){e.d(i,{m(){return H}});var s=e(56911),o=e(38493),n=e(60815),a=e(55230),r=e(92011),l=e(56863);class c extends r.L{}class h extends((0,l.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class d extends h{constructor(){super(),this.initialValue="on",this.proxy.setAttribute("type","radio")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}defaultCheckedChanged(){this.$fastController.isConnected&&!this.dirtyChecked&&(this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}connectedCallback(){super.connectedCallback(),this.validate(),"radiogroup"!==this.parentElement?.getAttribute("role")&&null===this.getAttribute("tabindex")&&(this.disabled||this.setAttribute("tabindex","0")),this.checkedAttribute&&(this.dirtyChecked||this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}isInsideRadioGroup(){return null!==this.closest("[role=radiogroup]")}keypressHandler(t){if(t.key!==a.gG)return!0;this.checked||this.readOnly||(this.checked=!0)}clickHandler(t){this.disabled||this.readOnly||this.checked||(this.checked=!0)}}(0,s.Cg)([(0,o.CF)({attribute:"readonly",mode:"boolean"}),(0,s.Sn)("design:type",Boolean)],d.prototype,"readOnly",void 0),(0,s.Cg)([n.sH,(0,s.Sn)("design:type",String)],d.prototype,"name",void 0),(0,s.Cg)([n.sH,(0,s.Sn)("design:type",Array)],d.prototype,"defaultSlottedNodes",void 0);var u=e(37180),p=e(74849),g=e(64187),m=e(73477),b=e(60993),v=e(22131),f=e(50882),$=e(48196),x=e(74838),k=e(26920),y=e(43774),w=e(46203),C=e(7896),_=e(48751),S=e(41123),A=e(95239),L=e(14996),T=e(79288);const D=p.A`
    ${(0,g.V)("inline-flex")} :host {
        --input-size: calc((${$.D} / 2) + ${x.vR});
        align-items: center;
        outline: none;
        margin: calc(${x.vR} * 1px) 0;
        ${""} user-select: none;
        position: relative;
        flex-direction: row;
        transition: all 0.2s ease-in-out;
    }

    .control {
        position: relative;
        width: calc(var(--input-size) * 1px);
        height: calc(var(--input-size) * 1px);
        box-sizing: border-box;
        border-radius: 50%;
        border: calc(${k.XA} * 1px) solid ${y.nF};
        background: ${w.le};
        outline: none;
        cursor: pointer;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        font-family: ${C.O};
        color: ${_.l};
        ${""} padding-inline-start: calc(${x.vR} * 2px + 2px);
        margin-inline-end: calc(${x.vR} * 2px + 2px);
        cursor: pointer;
        font-size: ${S.K};
        line-height: ${S.Z};
    }

    .control,
    .checked-indicator {
        flex-shrink: 0;
    }

    .checked-indicator {
        position: absolute;
        top: 5px;
        left: 5px;
        right: 5px;
        bottom: 5px;
        border-radius: 50%;
        display: inline-block;
        background: ${_.l};
        fill: ${_.l};
        opacity: 0;
        pointer-events: none;
    }

    :host(:enabled) .control:hover {
        background: ${w.jM};
        border-color: ${y.vA};
    }

    :host(:enabled) .control:active {
        background: ${w.RS};
        border-color: ${y.p4};
    }

    :host(:${m.N}) .control {
        box-shadow: 0 0 0 2px ${A.p}, 0 0 0 4px ${L.WN};
        border-color: ${L.WN};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${b.Z};
    }

    :host([aria-checked="true"]) .checked-indicator {
        opacity: 1;
    }

    :host([disabled]) {
        opacity: ${T.q};
    }
`.withBehaviors((0,v.mr)(p.A`
            .control {
                forced-color-adjust: none;
                border-color: ${f.A.FieldText};
                background: ${f.A.Field};
            }
            :host(:enabled) .control:hover,
            .control:active {
                border-color: ${f.A.Highlight};
                background: ${f.A.Field};
            }
            :host(:${m.N}) .control {
                border-color: ${f.A.Highlight};
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([aria-checked="true"]:${m.N}:enabled) .control {
                border-color: ${f.A.Highlight};
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([aria-checked="true"]:enabled) .control:hover,
            .control:active {
                border-color: ${f.A.Highlight};
                background: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${f.A.Highlight};
                fill: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .control:hover .checked-indicator {
                background: ${f.A.HighlightText};
                fill: ${f.A.HighlightText};
            }
            :host([disabled]) {
                forced-color-adjust: none;
                opacity: 1;
            }
            :host([disabled]) .label {
                color: ${f.A.GrayText};
            }
            :host([disabled]) .control,
            :host([aria-checked="true"][disabled]) .control:hover,
            .control:active {
                background: ${f.A.Field};
                border-color: ${f.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                fill: ${f.A.GrayText};
                background: ${f.A.GrayText};
            }
        `));var z=e(96950),I=e(82774),M=e(79109),B=e(18893);const O=function(t={}){return z.qy`
        <template
            role="radio"
            aria-checked="${t=>t.checked}"
            aria-required="${t=>t.required}"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            @keypress="${(t,i)=>t.keypressHandler(i.event)}"
            @click="${(t,i)=>t.clickHandler(i.event)}"
        >
            <div part="control" class="control">
                <slot name="checked-indicator">
                    ${(0,B.R)(t.checkedIndicator)}
                </slot>
            </div>
            <label
                part="label"
                class="${t=>["label",!t.defaultSlottedNodes?.length&&"label__hidden"].filter(Boolean).join(" ")}"
            >
                <slot
                    ${(0,I.e)({property:"defaultSlottedNodes",filter:M.g})}
                ></slot>
            </label>
        </template>
    `}({checkedIndicator:z.qy`
        <div part="checked-indicator" class="checked-indicator"></div>
    `}),H=d.compose({name:`${u.c.prefix}-radio`,template:O,styles:D})},98790(t,i,e){e.d(i,{h(){return h}});var s=e(21082),o=e(55358),n=e(56911),a=e(23429),r=e(38493),l=e(10300);class c extends l.I{constructor(){super(...arguments),this.autofocus=!1}autofocusChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.autofocus=this.autofocus,this.validate())}slottedOptionsChanged(t,i){super.slottedOptionsChanged(t,i),this.filterOptions()}connectedCallback(){super.connectedCallback(),this.autofocus&&a.L.enqueue(()=>{this.focus()}),this.focusAndScrollOptionIntoView=()=>{window.requestAnimationFrame(()=>{this.firstSelectedOption&&(this.firstSelectedOption.focus(),this.firstSelectedOption.scrollIntoView({block:"nearest"}))})}}}(0,n.Cg)([(0,r.CF)({mode:"boolean"})],c.prototype,"autofocus",void 0);const h=c.compose({name:"msn-traffic-combobox",template:s.v,styles:o.R,shadowOptions:{delegatesFocus:!0}})},99061(t,i,e){e.d(i,{msftTrafficCardSettings(){return Z}});var s=e(65636),o=e(37180),n=e(88817),a=e(121),r=e(65007),l=e(48785),c=e(98790),h=e(99900),d=e(56911),u=e(68073),p=e(16032),g=e(52875),m=e(90379),b=e(92011),v=e(38493),f=e(60815);const $=["_1x_2y","_2x_2y","_3x_2y"];class x extends b.L{get locationAutoSuggestClient(){return this._locationAutoSuggestClient||(this._locationAutoSuggestClient=(0,u.X)(this.locationAutoSuggestConfig)),this._locationAutoSuggestClient}get locationPdpClient(){return this._locationPdpClient||(this._locationPdpClient=new p.h),this._locationPdpClient}constructor(){super(),this.isValidMsa=!1,this.showSuggests=!0,this.hasLocationInput=!1,this.scenario="traffic",this.handleDocumentKeydown=t=>{!t.defaultPrevented&&this.suggestedLocations&&0!==this.suggestedLocations.length&&"Tab"===t.code&&(null==this.selectedLocation||this.selectedLocation<0||this.suggestedLocations&&this.suggestedLocations.length&&this.selectedLocation===this.suggestedLocations.length)&&(this.showSuggests=!1)},this.handleClickOutside=t=>{!t.defaultPrevented&&this.suggestedLocations&&0!==this.suggestedLocations.length&&(this.showSuggests=!1)},this.homeOptions=[],this.workOptions=[],this.radioGroup&&this.radioGroup.focus()}get getHeaderText(){return"_1x_3y"===this.size&&this.enableCommuteSettings&&this.isMsa&&this.isValidMsa?this.localizedStrings.editLocationsText:"commute"===this.scenario?this.localizedStrings.editHomeWorkHeader:this.localizedStrings.editCardText}get showInputControl(){return"Specify"===this.locationMode}get is2yHeight(){return $.includes(this.size)}makeDropdownItem(t,i){return{title:t,ariaLabel:t,onClick:()=>{this.scenario=i},isActive:this.scenario===i,telemetryTag:(0,m.i9)(i).getMetadataTag()}}get settingsDropdownItems(){return[this.makeDropdownItem(this.localizedStrings.editCardText,"traffic"),this.makeDropdownItem(this.localizedStrings.editHomeWorkHeader,"commute")]}handleInputForSuggest(t){this.showSuggests||(this.showSuggests=!0),t&&t.preventDefault(),this.selectedLocationName=void 0,this.geocodedSelectedLocation=void 0,this.inputControl&&(this.triggerLocationSuggest(this.inputControl.value),this.hasLocationInput=!!this.inputControl.value)}selectSuggestLocation(t,i){this.inputControl&&(this.inputControl.value=t),this.selectLocation(i)}chooseLocationMode(t){if(t.defaultPrevented||!t.target)return;t.preventDefault(),this.showSuggests=!1;const i=t.target.value;i!==this.locationMode&&(this.locationMode=i,window.setTimeout(()=>{this.showInputControl?this.inputControl&&this.inputControl.focus():this.detectLocationRadio&&this.detectLocationRadio.focus()},0))}async onDismissSettingsClick(){this.isUserLocationUpdated||this.isHomeUpdated||this.isWorkUpdated?this.openConfirmCancelBanner():this.cancelSetting()}cancelSetting(){this.onDismissBannerClick(),this.$emit("cancel"),this.inputControl&&(this.inputControl.value=""),this.scenario="traffic"}onDismissBannerClick(){this.cardBannerData=void 0}async openConfirmCancelBanner(){this.cardBannerData={bannerTitle:this.localizedStrings.commuteSettingStrings&&this.localizedStrings.commuteSettingStrings.bannerContentSaveChanges,bannerType:"yes-no",yesOverwriteOption:{tooltip:void 0,clickAction:()=>{this.saveSetting()}},noOverwriteOption:{tooltip:void 0,clickAction:()=>{this.cancelSetting()}},onDismissClick:()=>{this.onDismissBannerClick()}}}async saveSetting(){this.onDismissBannerClick();let t=Promise.resolve(),i=Promise.resolve(),e=Promise.resolve(),s=!1,o=!1;const n=this.isUserLocationUpdated;let a;if(n&&("Specify"===this.locationMode&&this.geocodedSelectedLocation?e=this.geocodedSelectedLocation.then(async t=>{t&&this.locationPdpClient.setHomeLocation(t)}):"AutoDetect"===this.locationMode&&(e=this.locationPdpClient.updateUserSettings("","1"))),this.homeCombobox&&(this.homeCombobox.value?(t=this.updateCommuteLocation(!0,this.homeOptions,this.homeCombobox),s=!0):t=(0,m.q$)("Home")),this.workCombobox&&(this.workCombobox.value?(i=this.updateCommuteLocation(!1,this.workOptions,this.workCombobox),o=!0):i=(0,m.q$)("Work")),await Promise.all([e,t,i]),this.localizedStrings){a=void 0;const t=this.isHomeUpdated,i=this.isWorkUpdated;t||i||!n?n?a=this.localizedStrings.generalLocationUpdatedToast:t&&i?a=this.localizedStrings.homeAndWorkSavedToast:t?a=s?this.localizedStrings.homeSavedToast:this.localizedStrings.homeRemovedToast:i&&(a=o?this.localizedStrings.workSavedToast:this.localizedStrings.workRemovedToast):"AutoDetect"===this.locationMode?a=this.localizedStrings.locationDetectedToast:this.selectedLocationName&&(a=this.localizedStrings.locationSpecifiedToast.replace("{0}",this.selectedLocationName))}this.$emit("save",{toastMessage:a,newLocationMode:this.locationMode}),this.inputControl&&(this.inputControl.value="")}async updateCommuteLocation(t,i,e){var s;if(-1===e.selectedIndex)return;const o=i[e.selectedIndex];o.displayName=(0,m.Dd)(o);const n=await(null===(s=this.commuteAutosuggestClient)||void 0===s?void 0:s.geocodeSuggestion(o));n&&await(0,m.yD)(t,n)}connectedCallback(){if(super.connectedCallback(),"_1x_1y"==this.size&&(this.size="_1x_2y"),this.inputControl){const t=this.inputControl.value.length;this.inputControl.setSelectionRange(t,t)}this.focus(),document.addEventListener("keydown",this.handleDocumentKeydown),document.addEventListener("click",this.handleClickOutside),this.loadCommuteLocations()}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this.handleDocumentKeydown),document.removeEventListener("click",this.handleClickOutside)}handleOnKeyDownSearchBox(t){if(!this.showSuggests||!this.suggestedLocations||0==this.suggestedLocations.length)return!0;switch(t.code){case"Tab":t.preventDefault(),t.shiftKey?(this.selectedLocation=-1,this.specifyLocationRadio&&this.specifyLocationRadio.focus()):(this.selectedLocation=0,this.focusSelectedElement());break;case"ArrowDown":t.preventDefault(),this.selectedLocation=0,this.focusSelectedElement()}return!0}focusSelectedElement(){if(null!=this.selectedLocation&&-1!=this.selectedLocation){var t;null===(t=this.selectedSuggestion.querySelectorAll("li")[this.selectedLocation].firstElementChild)||void 0===t||t.focus()}}handleOnKeyDownAutoSuggestBox(t){switch(t.code){case"Escape":this.showSuggests=!1,this.selectedLocation=-1,this.inputControl&&(this.inputControl.value=""),this.inputControl.focus();break;case"Enter":if(null!=this.selectedLocation){this.selectedSuggestion.querySelectorAll("li")[this.selectedLocation].click()}this.showSuggests=!1,this.selectedLocation=-1,this.inputControl.focus();break;case"Tab":null!=this.selectedLocation&&this.suggestedLocations&&(t.shiftKey?this.selectedLocation=(this.selectedLocation+this.suggestedLocations.length-1)%this.suggestedLocations.length:this.selectedLocation=(this.selectedLocation+1)%this.suggestedLocations.length,this.focusSelectedElement());break;case"ArrowDown":null!=this.selectedLocation&&this.suggestedLocations&&(this.selectedLocation=(this.selectedLocation+1)%this.suggestedLocations.length,this.focusSelectedElement());break;case"ArrowUp":null!=this.selectedLocation&&this.suggestedLocations&&(this.selectedLocation=(this.selectedLocation+this.suggestedLocations.length-1)%this.suggestedLocations.length,this.focusSelectedElement())}}selectLocation(t){if(!this.lastFetchedLocations||0===this.lastFetchedLocations.length)return;const i=this.lastFetchedLocations[t];i&&(this.geocodedSelectedLocation=this.locationAutoSuggestClient.geocodeSuggestion(i),this.selectedLocationName=(0,m.SV)(i)),this.suggestedLocations=void 0}async triggerLocationSuggest(t){let i;const e=t.trim();if(e){i=await this.locationAutoSuggestClient.getAutoSuggestResponse(e);const t=this.size;this.is2yHeight&&i&&i.length>3?i=i.slice(0,3):"_1x_1y"===t&&i&&i.length>1&&(i=i.slice(0,1)),this.lastFetchedLocations=i,null!=i&&i.length>0?this.suggestedLocations=i.map(t=>t.displayName||g.getAutoSuggestionName(t)):this.suggestedLocations=[this.localizedStrings.noLocationFound]}}async handleCommuteAutosuggest(t,i){var e,s;if(!t.data)return;const o=null===(e=t.target)||void 0===e?void 0:e.control.value;let n=await(null===(s=this.commuteAutosuggestClient)||void 0===s?void 0:s.getAutoSuggestResponse(o));"_1x_3y"!==this.size&&n&&(n=n.slice(0,4)),"home"===i&&n?this.homeOptions=n:n&&(this.workOptions=n)}clearCommuteOptions(t){"home"===t&&this.homeCombobox.value?this.homeCombobox.value="":"work"===t&&this.workCombobox.value&&(this.workCombobox.value="")}async loadCommuteLocations(){if(!this.commuteLocations){try{this.commuteLocations=await(0,m.ZX)(),this.isValidMsa=!0}catch(t){this.isValidMsa=!1}this.initialWorkName=this.commuteLocations&&this.commuteLocations.work&&this.commuteLocations.work.displayName,this.initialHomeName=this.commuteLocations&&this.commuteLocations.home&&this.commuteLocations.home.displayName}}get isWorkUpdated(){const t=this.workCombobox&&this.workCombobox.value;return!(!this.initialWorkName&&!t)&&t!==this.initialWorkName}get isHomeUpdated(){const t=this.homeCombobox&&this.homeCombobox.value;return!(!this.initialHomeName&&!t)&&t!==this.initialHomeName}get isUserLocationUpdated(){return!!("AutoDetect"===this.locationMode&&this.locationMode!==this.initialLocationMode||"Specify"===this.locationMode&&this.selectedLocationName)}}(0,d.Cg)([v.CF],x.prototype,"size",void 0),(0,d.Cg)([(0,v.CF)({attribute:"is-msa",mode:"boolean"})],x.prototype,"isMsa",void 0),(0,d.Cg)([(0,v.CF)({attribute:"enable-commute-settings",mode:"boolean"})],x.prototype,"enableCommuteSettings",void 0),(0,d.Cg)([(0,v.CF)({attribute:"valid-msa",mode:"boolean"})],x.prototype,"isValidMsa",void 0),(0,d.Cg)([(0,v.CF)({attribute:"initial-location-mode"})],x.prototype,"initialLocationMode",void 0),(0,d.Cg)([(0,v.CF)({attribute:"location-mode"})],x.prototype,"locationMode",void 0),(0,d.Cg)([(0,v.CF)({attribute:"autosuggest-state"})],x.prototype,"autoSuggestState",void 0),(0,d.Cg)([(0,v.CF)({attribute:"bottom-align",mode:"boolean"})],x.prototype,"bottomAlign",void 0),(0,d.Cg)([f.sH],x.prototype,"suggestedLocations",void 0),(0,d.Cg)([f.sH],x.prototype,"selectedLocation",void 0),(0,d.Cg)([f.sH],x.prototype,"selectedLocationName",void 0),(0,d.Cg)([f.sH],x.prototype,"showSuggests",void 0),(0,d.Cg)([f.sH],x.prototype,"hasLocationInput",void 0),(0,d.Cg)([f.sH],x.prototype,"scenario",void 0),(0,d.Cg)([f.sH],x.prototype,"detectLocationTelemetryTag",void 0),(0,d.Cg)([f.sH],x.prototype,"specifyLocationTelemetryTag",void 0),(0,d.Cg)([f.sH],x.prototype,"saveTelemetryTag",void 0),(0,d.Cg)([f.sH],x.prototype,"cancelTelemetryTag",void 0),(0,d.Cg)([f.sH],x.prototype,"suggestTelemetryTag",void 0),(0,d.Cg)([f.sH],x.prototype,"localizedStrings",void 0),(0,d.Cg)([f.sH],x.prototype,"commuteAutosuggestClient",void 0),(0,d.Cg)([f.sH],x.prototype,"homeOptions",void 0),(0,d.Cg)([f.sH],x.prototype,"workOptions",void 0),(0,d.Cg)([f.sH],x.prototype,"commuteLocations",void 0),(0,d.Cg)([f.sH],x.prototype,"superSdData",void 0),(0,d.Cg)([f.sH],x.prototype,"cardBannerData",void 0),(0,d.Cg)([f.sH],x.prototype,"locationAutoSuggestConfig",void 0),(0,d.Cg)([f.sH],x.prototype,"activeLocation",void 0),(0,d.Cg)([f.sH],x.prototype,"detectedLocation",void 0);var k=e(7896),y=e(45476),w=e(26920),C=e(36452),_=e(57416),S=e(61138),A=e(22131),L=e(4968),T=e(12640),D=e(74849);const z=(0,m.nX)("icons-wc/icons/traffic/HomeIcon.svg"),I=(0,m.nX)("icons-wc/icons/traffic/HomeSuperSVG.svg"),M=(0,m.nX)("icons-wc/icons/traffic/WorkIcon.svg"),B=(0,m.nX)("icons-wc/icons/traffic/WorkSuperSVG.svg"),O=(0,m.nX)("icons-wc/icons/traffic/SubtractCircleLight.svg"),H=(0,m.nX)("icons-wc/icons/traffic/SubtractCircleDark.svg"),R=D.A` .commute-icon.home{background:url(${z}) no-repeat center}.commute-icon.work{background:url(${M}) no-repeat center}.delete-icon{background:url(${O}) no-repeat center}.detected-location-name{color:##616161}`,F=D.A` .commute-icon.home{background:url(${I}) no-repeat center}.commute-icon.work{background:url(${B}) no-repeat center}.delete-icon{background:url(${H}) no-repeat center}.detected-location-name{color:#ADADAD}`,j=D.A` :host{font-family:${k.O}}:host([bottom-align][size="_1x_2y"]){top:var(--oneu-halfu-align-top,inherit)}.settings-inner{${L.f} position:relative}.edit-location-radio-group{inset-inline-start:8px}.detected-location-name{font-size:14px;font-weight:400;line-height:20px;margin-inline-start:36px;margin-inline-end:16px}.commute-icon{margin-inline-end:4px;width:26px;height:26px}.delete-icon{width:20px;height:20px}.commute-row{display:inline-grid;width:268px;grid-template-columns:26px auto 20px;gap:4px;margin-bottom:16px;align-items:center}.commute-text-field{width:100%;min-width:200px}.auto-suggest{width:${230..toString()}px;display:flex;border:1px solid var(--neutral-foreground-rest);border-radius:4px;height:30px;margin-inline-start:36px}.location-input{flex:1 0 0px;background:transparent;border:none;outline:none;padding-inline-start:9px;color:var(--neutral-foreground-rest);text-overflow:ellipsis;font-family:var(--body-font);font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);margin-top:auto;margin-bottom:auto;height:calc(100% - 4px);width:${230..toString()}px}.commute-text-field::part(indicator){display:none}.suggest-list-container{position:absolute}.suggest-list{display:block;position:absolute;list-style:none;background:${y.Wl};
        border: calc(${w.XA} * 1px) solid ${C.I2};
        border-radius: ${_.Pb};
        margin: 0px;
        margin-inline-start: 36px;
        padding: 0;
        z-index: 99;
        outline: none;
        width: ${230..toString()}px}.suggest-item{text-overflow:ellipsis;word-wrap:break-word;font-size:${S.k};
        line-height: ${S.F};position:relative;width:100%}.suggest-item::part(control){justify-content:flex-start}.suggest-item-text{overflow:hidden;width:${210..toString()}px;text-overflow:ellipsis;text-align:start}.suggest-item-text-2c{width:${522..toString()}px}.suggest-item-text-3c{width:${834..toString()}px}.section-header{font-weight:600;line-height:20px;font-size:14px;margin-bottom:12px;pointer-events:none}.commute-header{margin-top:20px}.location-box-2c{width:${542..toString()}px}.location-box-3c{width:${854..toString()}px;
    }
    `.withBehaviors((0,A.mr)(D.A` :host{forced-color-adjust:auto}`),new T.N(R,F));var E=e(96950),P=e(60402),U=e(69259),G=e(39957);const N=t=>{switch(t){case"_3x_2y":return"location-box-3c";case"_2x_2y":return"location-box-2c";default:return""}},V=E.qy`<fluent-option value=${(t,i)=>i.index||"0"}>${t=>(0,m.Dd)(t)}</fluent-option>`,W=E.qy`<li role="option" title="${t=>t}" aria-label="${t=>t}" @click="${(t,i)=>i.parent.selectSuggestLocation(t,i.index)}" data-t="${(t,i)=>i.parent.suggestTelemetryTag}"><fluent-button class="suggest-item" part="suggest-item" appearance="stealth" aria-hidden="true"><div class="suggest-item-text ${(t,i)=>(t=>{switch(t){case"_3x_2y":return"suggest-item-text-3c";case"_2x_2y":return"suggest-item-text-2c";default:return""}})(i.parent.size)}">${t=>t}</div></fluent-button></li>`,K=E.qy`<div class="auto-suggest ${t=>N(t.size)}"><input class="location-input ${t=>N(t.size)}" tabindex="0" title=${t=>t.localizedStrings.locationSearchPlaceholder} placeholder="${t=>t.localizedStrings.locationSearchPlaceholder}" @input=${t=>t.handleInputForSuggest()} @keydown="${(t,i)=>t.handleOnKeyDownSearchBox(i.event)}" value="${t=>"Specify"==t.initialLocationMode&&t.activeLocation?(0,m.SV)(t.activeLocation):""}" type="text" appearance="filled" autofocus="autofocus" autoComplete="off" aria-autocomplete="both" aria-controls="traffic-location-search-list" aria-owns="traffic-location-search-list" ${(0,P.K)("inputControl")} /></div>`,q=E.qy`<fluent-radio-group class="edit-location-radio-group" value="${t=>t.locationMode}" @change="${(t,i)=>t.chooseLocationMode(i.event)}" aria-labelledby="setlocationmode" name="set-location-mode" orientation="vertical" ${(0,P.K)("radioGroup")}><fluent-radio value="AutoDetect" data-t="${t=>t.detectLocationTelemetryTag}" ${(0,P.K)("detectLocationRadio")}>${t=>t.localizedStrings&&t.localizedStrings.locationDetect}</fluent-radio>${(0,U.z)(t=>"AutoDetect"===t.locationMode,E.qy`<div class="detected-location-name">${t=>t.detectedLocation&&(0,m.SV)(t.detectedLocation)}</div>`)}<fluent-radio value="Specify" data-t="${t=>t.specifyLocationTelemetryTag}" ${(0,P.K)("specifyLocationRadio")}>${t=>t.localizedStrings&&t.localizedStrings.locationSpecify}</fluent-radio></fluent-radio-group>`,J=E.qy` ${(0,U.z)(t=>"_1x_3y"===t.size,E.qy`<div class="section-header">${t=>t.localizedStrings.editCardText}</div>`)} ${q} ${(0,U.z)(t=>t.showInputControl,E.qy`${K}`)} ${(0,U.z)(t=>t.showSuggests&&t.hasLocationInput,E.qy`<div class="suggest-list-container" aria-live="polite" aria-expanded="${t=>!!t.suggestedLocations}" id="traffic-location-search-list" aria-label="${t=>t.localizedStrings.locationSearchPlaceholder}">${(0,U.z)(t=>t.suggestedLocations,E.qy`<ul class="suggest-list ${t=>N(t.size)}" part="suggest-list" ${(0,P.K)("selectedSuggestion")} @keydown="${(t,i)=>t.handleOnKeyDownAutoSuggestBox(i.event)}">${(0,U.z)(t=>t.showSuggests&&t.suggestedLocations&&t.suggestedLocations.length>0,E.qy`${(0,G.ux)(t=>t.suggestedLocations,W,{positioning:!0})}`)} ${(0,U.z)(t=>t.suggestedLocations&&0===t.suggestedLocations.length,E.qy`<li role="option" title="${t=>t.localizedStrings.noLocationFound}" class="suggest-item" part="suggest-item">${t=>t.localizedStrings.noLocationFound}</li>`)}</ul>`)}</div>`)}
`,Q=E.qy` ${(0,U.z)(t=>"_1x_3y"===t.size,E.qy`<div class="commute-header section-header">${t=>t.localizedStrings.editHomeWorkHeader}</div>`)}<div><div class="commute-row"><span class="commute-icon home"></span><span><msn-traffic-combobox class="commute-text-field" position="below" placeholder=${t=>t.localizedStrings.locationSearchPlaceholder} current-value=${t=>{var i;return null===(i=t.commuteLocations)||void 0===i||null===(i=i.home)||void 0===i?void 0:i.displayName}} @input=${async(t,i)=>await t.handleCommuteAutosuggest(i.event,"home")} ${(0,P.K)("homeCombobox")}>${(0,G.ux)(t=>t.homeOptions,V,{positioning:!0})}</msn-traffic-combobox></span><fluent-button aria-label=${t=>t.localizedStrings.clearText} @click=${t=>t.clearCommuteOptions("home")} class="delete-icon"></fluent-button></div><div class="commute-row"><span class="commute-icon work"></span><span><msn-traffic-combobox class="commute-text-field" position="below" placeholder=${t=>t.localizedStrings.locationSearchPlaceholder} current-value=${t=>{var i;return null===(i=t.commuteLocations)||void 0===i||null===(i=i.work)||void 0===i?void 0:i.displayName}} @input=${async(t,i)=>await t.handleCommuteAutosuggest(i.event,"work")} ${(0,P.K)("workCombobox")}>${(0,G.ux)(t=>t.workOptions,V,{positioning:!0})}</msn-traffic-combobox></span><fluent-button aria-label=${t=>t.localizedStrings.clearText} @click=${t=>t.clearCommuteOptions("work")} class="delete-icon"></fluent-button></div></div>`,X=E.qy` ${(0,U.z)(t=>"commute"!==t.scenario||"_1x_3y"===t.size,J)} ${(0,U.z)(t=>"commute"===t.scenario||"_1x_3y"===t.size&&t.isMsa&&t.isValidMsa,Q)}
`,Y=E.qy` ${(0,U.z)(t=>t.superSdData,E.qy`<responsive-sd-card responsive-sizing-enabled="true" size="${t=>t.size}" :data=${(t,i)=>{var e;const s=t.isMsa&&t.isValidMsa&&t.enableCommuteSettings&&"_1x_3y"!==t.size;return{...t.superSdData,cardSize:t.size,headerData:{...t.superSdData.headerData,titleNavigationLink:void 0,title:t.getHeaderText,isActionMenuAvailable:!1,isMoreSettingAvailable:!1,isDismissAvailable:!0,onDismissCard(){t.onDismissSettingsClick()},interestMenuData:s?{interestMenuItems:t.settingsDropdownItems,interestMenuToolTip:t.localizedStrings.dropdownTooltip}:void 0,telemetryContext:{dismissMenuTelemetryTag:t.cancelTelemetryTag}},footerData:{...null===(e=t.superSdData)||void 0===e?void 0:e.footerData,footerButton:{text:t.localizedStrings.saveLocationInfoText,ctaClick(){t.saveSetting()}}},immersiveCard:!1,darkCardFillColor:void 0,lightCardFillColor:void 0}}}><div slot="card-content"><div class="settings-inner">${X}</div>${(0,U.z)(t=>t.cardBannerData,E.qy`<cs-card-banner class="banner" :data="${t=>t.cardBannerData}" size="${t=>t.size}"></cs-card-banner>`)}</div></responsive-sd-card>`)}
`;s.m.define(o.c.registry),n.m.define(o.c.registry),a.m.define(o.c.registry),r.m.define(o.c.registry),l.m.define(o.c.registry),c.h.define(h.u.registry);const Z=x.compose({name:"msft-traffic-card-settings",template:Y,styles:j})}}]);