"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["weather-topsection-card-deferred"],{9299(t,e,i){i.d(e,{m(){return I}});var o=i(56911),n=i(38493),r=i(60815),a=i(55230),s=i(92011),l=i(56863);class d extends s.L{}class c extends((0,l.dx)(d)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends c{constructor(){super(),this.initialValue="on",this.indeterminate=!1,this.keypressHandler=t=>{if(!this.readOnly&&t.key===a.gG)this.indeterminate&&(this.indeterminate=!1),this.checked=!this.checked},this.clickHandler=t=>{this.disabled||this.readOnly||(this.indeterminate&&(this.indeterminate=!1),this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}}(0,o.Cg)([(0,n.CF)({attribute:"readonly",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Array)],h.prototype,"defaultSlottedNodes",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Boolean)],h.prototype,"indeterminate",void 0);var u=i(37180),p=i(74849),v=i(64187),g=i(73477),b=i(60993),m=i(22131),f=i(50882),w=i(74838),x=i(57416),y=i(26920),$=i(43774),k=i(46203),L=i(7896),C=i(48751),D=i(41123),S=i(95239),T=i(14996),z=i(79288),A=i(48196);const _=p.A`
    ${(0,v.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        margin: calc(${w.vR} * 1px) 0;
        ${""} user-select: none;
    }

    .control {
        position: relative;
        width: calc((${A.D} / 2 + ${w.vR}) * 1px);
        height: calc((${A.D} / 2 + ${w.vR}) * 1px);
        box-sizing: border-box;
        border-radius: calc(${x.Pb} * 1px);
        border: calc(${y.XA} * 1px) solid ${$.nF};
        background: ${k.le};
        outline: none;
        cursor: pointer;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        font-family: ${L.O};
        color: ${C.l};
        ${""} padding-inline-start: calc(${w.vR} * 2px + 2px);
        margin-inline-end: calc(${w.vR} * 2px + 2px);
        cursor: pointer;
        font-size: ${D.K};
        line-height: ${D.Z};
    }

    .checked-indicator {
        width: 100%;
        height: 100%;
        display: block;
        fill: ${C.l};
        opacity: 0;
        pointer-events: none;
    }

    .indeterminate-indicator {
        border-radius: calc((${x.Pb} / 2) * 1px);
        background: ${C.l};
        position: absolute;
        top: 50%;
        left: 50%;
        width: 50%;
        height: 50%;
        transform: translate(-50%, -50%);
        opacity: 0;
    }

    :host(:enabled) .control:hover {
        background: ${k.jM};
        border-color: ${$.vA};
    }

    :host(:enabled) .control:active {
        background: ${k.RS};
        border-color: ${$.p4};
    }

    :host(:${g.N}) .control {
        box-shadow: 0 0 0 2px ${S.p}, 0 0 0 4px ${T.WN};
        border-color: ${T.WN};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${b.Z};
    }

    :host([aria-checked="true"]:not([aria-checked="mixed"])) .checked-indicator,
    :host([aria-checked="mixed"]) .indeterminate-indicator {
        opacity: 1;
    }

    :host([disabled]) {
        opacity: ${z.q};
    }
`.withBehaviors((0,m.mr)(p.A`
            .control {
                forced-color-adjust: none;
                border-color: ${f.A.FieldText};
                background: ${f.A.Field};
            }
            :host(:enabled) .control:hover,
            .control:active {
                border-color: ${f.A.Highlight};
                background: ${f.A.Field};
            }
            .checked-indicator {
                fill: ${f.A.FieldText};
            }
            .indeterminate-indicator {
                background: ${f.A.FieldText};
            }
            :host(:${g.N}) .control {
                border-color: ${f.A.Highlight};
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([aria-checked="true"]:${g.N}:enabled) .control {
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([aria-checked="true"]) .control {
                background: ${f.A.Highlight};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .control:hover,
            .control:active {
                background: ${f.A.HighlightText};
            }
            :host([aria-checked="true"]) .checked-indicator {
                fill: ${f.A.HighlightText};
            }
            :host([aria-checked="true"]) .control:hover .checked-indicator {
                fill: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .indeterminate-indicator {
                background: ${f.A.HighlightText};
            }
            :host([aria-checked="true"]) .control:hover .indeterminate-indicator {
                background: ${f.A.Highlight};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .control {
                forced-color-adjust: none;
                border-color: ${f.A.GrayText};
                background: ${f.A.Field};
            }
            :host([disabled]) .indeterminate-indicator,
            :host([aria-checked="true"][disabled])
                .control:hover
                .indeterminate-indicator {
                forced-color-adjust: none;
                background: ${f.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                forced-color-adjust: none;
                fill: ${f.A.GrayText};
            }
        `));var F=i(96950),N=i(82774),W=i(18893);const R=function(t={}){return F.qy`
        <template
            role="checkbox"
            aria-checked="${t=>t.indeterminate?"mixed":t.checked}"
            aria-required="${t=>t.required}"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            tabindex="${t=>t.disabled?null:0}"
            @keypress="${(t,e)=>t.keypressHandler(e.event)}"
            @click="${(t,e)=>t.clickHandler(e.event)}"
        >
            <div part="control" class="control">
                <slot name="checked-indicator">
                    ${(0,W.R)(t.checkedIndicator)}
                </slot>
                <slot name="indeterminate-indicator">
                    ${(0,W.R)(t.indeterminateIndicator)}
                </slot>
            </div>
            <label
                part="label"
                class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,N.e)("defaultSlottedNodes")}></slot>
            </label>
        </template>
    `}({checkedIndicator:F.qy`
        <svg
            aria-hidden="true"
            part="checked-indicator"
            class="checked-indicator"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M8.143 12.6697L15.235 4.5L16.8 5.90363L8.23812 15.7667L3.80005 11.2556L5.27591 9.7555L8.143 12.6697Z"
            />
        </svg>
    `,indeterminateIndicator:F.qy`
        <div part="indeterminate-indicator" class="indeterminate-indicator"></div>
    `}),I=h.compose({name:`${u.c.prefix}-checkbox`,template:R,styles:_})},15948(t,e,i){i.d(e,{U(){return k}});var o=i(58792),n=i(15525),r=i(77367),a=i(1356),s=i(33680),l=i(51899),d=i(84177),c=i(44060),h=i(29658),u=i(71398),p=i(22341),v=i(49221),g=i(39528),b=i(74998),m=i(17958),f=i(16032),w=i(94684),x=i(10526);function y(t){return!!t&&"null"!==t&&"undefined"!==t&&"false"!==t}function $(t,e){return new Date(e.updatedDateTime).valueOf()-new Date(t.updatedDateTime).valueOf()}class k{constructor(){let t=arguments.length>0&&void 0!==arguments[0]&&arguments[0];this.PdpDefaultLocation="DefaultLocation",this.PdpFavoriteLocation="FavoriteLocation",this.locationPdpClient=new f.h,this.writeToAAD=!1,this.instance=u.d,this.writeToAAD=t}async read(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},e=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];if(!navigator.cookieEnabled)return{};!function(){const t=(0,o.rA)().UserId;let e=[];try{e=JSON.parse((0,n.Lg)().getItem(a.ZR)||"[]")}catch{e=[]}e.length&&t!==e[e.length-1]?(e.push(t),(0,n.Lg)().setItem(a.ZR,JSON.stringify(e)),null===r.YT||void 0===r.YT||r.YT.sendClientLogEvent({message:`Met unfamiliar MUID. Current MUID array is ${e}`,type:"information"})):0===e.length?(e.push(t),(0,n.Lg)().setItem(a.ZR,JSON.stringify(e))):null===r.YT||void 0===r.YT||r.YT.sendClientLogEvent({message:`MUID not churn. Current MUID array is ${e}`,type:"information"})}();let i=null;try{const o=await this.instance.readPdpWithTargetType(c.y.Location,!1,void 0,t,e),{value:n=[]}=o||{value:[]};i=this.convertPdpDataToPdpResponse(n)}catch(t){(0,p.c_)(t,v.E9,"error in library [location-service],Weather Profile graph action location Read Failed")}if(!i||!i.unit)try{const e=await this.instance.getUserPrefData(t);r.YT.addOrUpdateTmplString("getweatherpdp");const{value:o=[]}=e||{value:[]},n=this.parseUserProfileFromPdpData(o);i=i?{...i,unit:n&&n.unit}:n}catch(t){(0,p.c_)(t,v.Z9,"error in library [location-service],Weather Profile User Read Failed")}return i||{}}isWeatherAndLinked(){if(!this.writeToAAD)return!1;return"weather"===((0,o.rA)()||{}).AppType&&"AAD"==(0,x.NP)()&&(0,g.pu)()}async setDisplayUnit(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},i=!1;try{i=await this.instance.updateWeatherSettings(t.toString(),null,e),this.isWeatherAndLinked()&&this.instance.updateWeatherSettings(t.toString(),null,e,void 0,!0)}catch(t){(0,p.c_)(t,v.Lc,"error in library [location-service],Display unit Update failed."),i=!1}return i}async setEplantStatus(t){return this.instance.updateUserSettings({eplantGameJoined:t.toString()})}async setWeatherMapSetting(t){return this.instance.updateUserSettings({weatherMapSetting:JSON.stringify(t,(t,e)=>e??void 0)})}async setWeatherTheme(t){return this.instance.updateUserSettings({weatherTheme:t.toString()})}async setWeatherRunningPreference(t){return this.instance.updateUserSettings({weatherRunningPreference:JSON.stringify(t,(t,e)=>e??void 0)})}async getBLISLocation(t){return this.locationPdpClient.getUserDefaultLocation(t)}async updateUserSettings(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},o=arguments.length>3?arguments[3]:void 0;return this.locationPdpClient.updateUserSettings(t,e,i,o)}async disableWeatherCardNotification(t,e,i){let o=!1;try{const e={UserAction:{0:{UpdateTime:new Date,location:i}}};o=await this.instance.updateWeatherInterests(t||"",e)}catch(t){(0,p.c_)(t,v.Hy,"error in library [location-service],"+(e?"Hide":"Show")+" weather hide notification card failed"),o=!1}return o}async updateUserExplicitInterest(t,e){let i=!1;try{i=await this.instance.updateWeatherInterests(t,e)}catch(o){(0,p.c_)(o,v.Hy,`error in library [location-service]," + "Fail to update user explicit interest. TargetId:${t}, metadata:${e}`),i=!1}return i}async getWeatherInterest(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"",e=null;try{e=await this.instance.getWeatherInterest({},t)}catch(t){(0,p.c_)(t,v.Z9,`error in getWeatherInterest," + "Fail to update user explicit interest. type:${c.y.Weather}`),e=null}return e}async enableDisableWeatherCard(t){let e=!1;try{e=await this.instance.updateSegmentCardsEnableStatus([{cardType:h.s.WeatherCard,enabled:t}])}catch(i){(0,p.c_)(i,v.Hy,"error in library [location-service],"+(t?"Enable":"Disable")+" weather segment card failed"),e=!1}return e}async updateWeatherCardPreviewForPollbar(t,e){const i={targetType:"Notification",definitionName:e};return u.d.setUserAction(t,i,!0)}async setHomeLocation(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},i=arguments.length>2?arguments[2]:void 0;return this.isWeatherAndLinked()&&this.locationPdpClient.setHomeLocation(t,e,i,!0),this.locationPdpClient.setHomeLocation(t,e,i)}async addFavoriteLocation(t){return this.locationPdpClient.addFavoriteLocation(t)}async removeFavoriteLocation(t){return this.locationPdpClient.removeFavoriteLocation(t)}async removeHomeLocation(t){return this.isWeatherAndLinked()&&this.locationPdpClient.removeLocation(t,!0),await this.locationPdpClient.removeLocation(t)}async removeLocation(t){return this.isWeatherAndLinked()&&this.locationPdpClient.removeLocation(t,!0),await this.locationPdpClient.removeLocation(t)}convertPdpDataToPdpResponse(t){if(t&&t[0]){const e=t.filter(t=>t.degree===this.PdpDefaultLocation).sort($)[0],i=k.parseLocationFromPdpValue(e);return i&&(i.from=2,i.displayName=(0,s.Mn)(i)),{...k.parseUnitAndMode(e,t[0]),home:i,favorites:t.filter(t=>t.degree===this.PdpFavoriteLocation).map(k.parseLocationFromPdpValue).filter(t=>!!t),followedLocations:t.map(k.parseLocationFromPdpValue).filter(t=>!!t),recents:void 0}}return null}parseUserProfileFromPdpData(t){if(t&&t[0]){const e=t.find(t=>t.weatherDisplayUnit);if(!(e&&(e.weatherDisplayUnit||e.userSettings&&e.userSettings.weatherLocationSettingMode)))return null;let i,o;return"2"!==e.weatherDisplayUnit&&"1"!==e.weatherDisplayUnit||(i="2"===e.weatherDisplayUnit?w.B.Celsius:w.B.Fahrenheit),e.userSettings&&e.userSettings.weatherLocationSettingMode&&(o="2"===e.userSettings.weatherLocationSettingMode?2:1),{home:void 0,unit:i,locationMode:o,favorites:void 0,recents:void 0}}return null}static buildMetaData(t){return f.h.buildMetaData(t)}static parseUnitAndMode(t,e){const i=k.parseUnitAndModeInternal(t);return null==i.unit&&(i.unit=k.parseUnit(e)),i}static parseUnitAndModeInternal(t){const e=k.parseUnit(t);let i=2;return t&&t.metadata&&("1"!==t.metadata.locationSettingMode&&"2"!==t.metadata.locationSettingMode||(i="1"===t.metadata.locationSettingMode?1:2)),{unit:e,locationMode:i}}static parseUnit(t){let e=null;return t&&t.metadata&&("2"!==t.metadata.displayunit&&"1"!==t.metadata.displayunit||(e="2"===t.metadata.displayunit?w.B.Celsius:w.B.Fahrenheit)),e}static parseLocationFromPdpValue(t){let e=null;if(t&&t.definitionName&&t.metadata){e={latitude:t.definitionName.split(",")[0],longitude:t.definitionName.split(",")[1],addressLine:y(t.metadata.addressLine)?t.metadata.addressLine:void 0,locality:y(t.metadata.city)?t.metadata.city:void 0,subRegion:y(t.metadata.subRegion)?t.metadata.subRegion:void 0,region:y(t.metadata.state)?t.metadata.state:void 0,country:y(t.metadata.countryRegion)?t.metadata.countryRegion:void 0,displayName:"",isoCode:y(t.metadata.isoCode)?t.metadata.isoCode:void 0,locationTypeId:t.metadata.locationTypeId,postalCode:t.metadata.postalCode,language:(t.metadata.language||(0,l.u0)(t.metadata.locationTypeId)||b.Rb.Locale).toLocaleLowerCase(),definitionName:t.definitionName,readLink:y(t.metadata.readLink)?t.metadata.readLink:void 0},e.region=(0,d.abbreviateUSState)(e.region,e.language,e.isoCode),e.locationType=1,"number"!=typeof t.metadata.locationType&&void 0!==t.metadata.locationType||(e.locationType=t.metadata.locationType||1),"string"==typeof t.metadata.locationType&&y(t.metadata.locationType)&&(e.locationType=(0,m.AY)(""+t.metadata.locationType,1));const i=t.metadata.geoCoordinates;!i||0===i.latitude&&0===i.longitude||(e.latitude=""+i.latitude,e.longitude=""+i.longitude),e.addressLine||e.locality||e.region||(e=null),e&&!(0,s.fn)(e)&&(e=null),e&&"0"===e.latitude&&"0"===e.longitude&&(t.metadata.name||t.metadata.countryRegion||t.metadata.city||t.metadata.state||(e=null))}return e}}},32480(t,e,i){i.d(e,{delayLoadComponent(){return zt}});var o=i(76489),n=i(19194),r=i(88342),a=i(94684),s=i(96950),l=i(17857),d=i(67452);const c=()=>({ChangeLocation:s.qy`<img class="neutral" src="${(0,o.hk)("SwitchHome.svg")}" width="20px" />`,ManageLocation:s.qy`<img class="neutral" src="${(0,o.hk)("Manage.svg")}" width="20px" />`,SwitchUnit:s.qy`<img class="neutral" src="${(0,o.hk)("SwitchUnit.svg")}" width="20px" />`});function h(t){const{strings:e,handlers:i,telemetry:o,currentUnit:s,resetCardAction:h,locationList:u,currentLocation:p}=t;if(!e||!e.actionList||!i)return;const v=e.actionList,g=c(),b=(0,r.lC)(o,n.W_),m={glyph:g.ChangeLocation,title:v.changeLocation,id:"changeLocation",telemetryTag:b?(0,r.lC)(b,"switchHome").getMetadataTag():""},f={glyph:g.ManageLocation,title:v.manageLocation,id:"manageLocation",telemetryTag:b?(0,r.lC)(b,"manageLocation").getMetadataTag():""};m.actionType=l.X.LocationEdit,f.actionType=l.X.LocationManage;const w={glyph:(0,d.y)(s==a.B.Fahrenheit?"F":"C"),title:v.unit,id:"switchUnit",onClick(){null==i||i.switchUnit(),h&&h(!0)},telemetryTag:b?(0,r.lC)(b,"switchUnit").getMetadataTag():"",toggle:{option1:"°F",option2:"°C",isOption1Selected:s==a.B.Fahrenheit}},x={dropdownTelemetry:(0,r.lC)(t.telemetry,n.Sy),locationList:u,currentLocation:p,setHome(){return i.setPrimaryLocation},dropdownStrings:e.dropdown,settingTelemetry:(0,r.lC)(t.telemetry,n.pt),settingStrings:e.settingCard,removeLocation(){return null==i?void 0:i.removeFollowedLocation},getSuggestList(){return null==i?void 0:i.getLocationSuggestList}};t.cardActionPropsOverride={...t.cardActionPropsOverride,locationProps:x,prefixExtendMenuItems:[m,f,w]}}var u=i(56911),p=i(92011),v=i(23429),g=i(60815),b=i(85349),m=i(90242),f=i(46528),w=i(51899),x=i(52875);class y extends p.L{constructor(){super(...arguments),this.requestContext=new f.bb,this.alignLeft=!1,this.handleResize=()=>{this.checkPositioning()},this.setHomeAndResetCardAction=t=>{"function"==typeof this.resetCardAction&&this.resetCardAction(),this.setHome(t)},this.focusToLastFocusableElement=()=>{var t;const e=this.shadowRoot;if(!e)return;const i=null==e||null===(t=e.querySelectorAll)||void 0===t?void 0:t.call(e,"button:not([disabled])");if(!i)return;const o=Array.from(i).filter(t=>{const e=t;return null!==e.offsetParent||e.offsetWidth>0||e.offsetHeight>0});o.length>0&&o[o.length-1].focus()}}locationListChanged(t,e){this.generateView()}connectedCallback(){super.connectedCallback(),this.initTelemetry(),v.L.enqueue(()=>{window.setTimeout(()=>{var t;null===(t=this.backButton)||void 0===t||t.focus()},300)}),this.generateView(),window.setTimeout(()=>{this.checkPositioning()},0),window.addEventListener("resize",this.handleResize)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("resize",this.handleResize)}checkPositioning(){v.L.enqueue(()=>{var t;const e=this.closest("weather-top-section-card")||this.parentElement;if(!e)return;const i=e.getBoundingClientRect(),o=(0,f.KP)(null===(t=this.requestContext)||void 0===t||null===(t=t.data)||void 0===t?void 0:t.innerWidth,"innerWidth");i.right+290>o?this.alignLeft=!0:this.alignLeft=!1})}initTelemetry(){if(this.rootTelemetry){const t=(0,r.un)((0,r.lC)(this.rootTelemetry,"close"),b.MS.Close),e=(0,r.lC)(this.rootTelemetry,"dropdownList");this.telemetry={cancelTg:t.getMetadataTag(),setHomeTO:e}}}generateView(){const t={};for(const[e,i,o]of this.locationList){const i=(0,w.Bh)(e),n={id:i,name:x.getDisplayName(e,{skipCountry:!0,skipOldName:!0}),setHome:()=>this.setHomeAndResetCardAction(e),isActive:(0,m.gf)(this.currentLocation,e),telemetry:this.telemetry?(0,r.lC)(this.telemetry.setHomeTO,`setHome_${i}`).getMetadataTag():""};o?t.detectLocation=[n]:(t.followLocation||(t.followLocation=[]),t.followLocation.push(n))}this.currentView=t}}(0,u.Cg)([g.sH],y.prototype,"locationList",void 0),(0,u.Cg)([g.sH],y.prototype,"currentLocation",void 0),(0,u.Cg)([g.sH],y.prototype,"rootTelemetry",void 0),(0,u.Cg)([g.sH],y.prototype,"telemetry",void 0),(0,u.Cg)([g.sH],y.prototype,"currentView",void 0),(0,u.Cg)([g.sH],y.prototype,"isDarkTheme",void 0),(0,u.Cg)([g.sH],y.prototype,"alignLeft",void 0);var $=i(22131),k=i(12640),L=i(86856),C=i(74849),D=i(77558);const S=C.A`
`,T=C.A``,z=C.A` .dropdown-container{background:#1d2437;border-color:#1d2437}.dropdown-content::-webkit-scrollbar-thumb{background:#D7DEEF}.dropdown-item:focus-visible{border:2px solid #fff !important;outline:2px solid rgb(16,16,16);outline-offset:-4px}`,A=C.A` .dropdown-container{width:290px;height:322px;background:#fff;position:relative;box-sizing:border-box;border-radius:var(--smtc-corner-flyout-rest);border:1px solid #EAEDF0;z-index:${D.P.Above.toString()};padding:8px;margin-bottom:4px}.dropdown-back{box-sizing:border-box;padding:7px 4px;height:50px;display:flex;align-items:center;justify-content:start;gap:8px}.dropdown-back img{height:20px;width:20px;flex-shrink:0;margin:8px;cursor:pointer}.dropdown-back-button{background:none;border:none;padding:0;margin:0;cursor:pointer;display:flex}.dropdown-back-button:focus-visible{outline:-webkit-focus-ring-color auto 1px}.dropdown-back-text,.detect-title,.my-location-title,.dropdown-item-text{color:var(--smtc-foreground-ctrl-neutral-primary-rest);font-weight:var(--smtc-text-style-default-regular-weight)}.dropdown-back-text{font-size:var(--smtc-text-global-body3-font-size);line-height:var(--smtc-text-global-body3-line-height)}.detect-title{margin-bottom:8px}.detect-title,.my-location-title{height:var(--smtc-text-global-body1-line-height)}.detect-title,.my-location-title,.dropdown-item-text{font-size:var(--smtc-text-global-body1-font-size);line-height:var(--smtc-text-global-body1-line-height)}.dropdown-content{overflow-x:hidden;overflow-y:auto;box-sizing:border-box;padding:12px;height:252px}.dropdown-content::-webkit-scrollbar-thumb{background:#E2DDD9}.detect-section{margin-bottom:16px}.dropdown-item{display:flex;gap:4px;cursor:pointer;align-items:center;border:none;background:none;outline:none}.dropdown-item:focus-visible{border:2px solid rgb(16,16,16) !important;outline:2px solid #fff;outline-offset:-4px}.dropdown-item-v2{height:32px !important;border-radius:12px !important;width:250px !important}.dropdown-item-v2:hover{background:var(--smtc-background-ctrl-subtle-hover) !important}.dropdown-item-text{color:var(--smtc-foreground-ctrl-neutral-secondary-rest);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.location-section{display:flex;flex-direction:column;gap:8px}.my-location-list{display:flex;flex-direction:column;gap:8px}`,_=C.A`
    ${A} ::-webkit-scrollbar{width:4px}::-webkit-scrollbar-thumb{background:#A8A8A8;-webkit-border-radius:20px;cursor:pointer}::-webkit-scrollbar-track{margin-block:32px}.dropdown-img{min-width:24px;width:24px;height:24px;display:flex;align-items:center;justify-content:center}.dropdown-img img{width:16px;height:16px}`.withBehaviors(new L.t(S,T),new k.N(null,z),(0,$.G2)(C.A`${z}`),(0,$.mr)(C.A``));var F=i(69259),N=i(39957),W=i(60402),R=i(22341),I=i(49221);const O=t=>t?s.qy`<button class="dropdown-item dropdown-item-v2" role="option" aria-label="${t.name}${t.isActive?" (currently selected)":""}" aria-selected="${t.isActive}" title="${t.name}" @click="${()=>{t.setHome()}}" data-t="${t.telemetry||""}"><div class="dropdown-img">${(0,F.z)(t.isActive,s.qy`<img src="${(t,e)=>e.parent.isDarkTheme?(0,o.hk)("Check_Co_D.svg"):(0,o.hk)("Check_Co.svg")}" alt=""></img>`)}</div><div class="dropdown-item-text">${t.name}</div></button>`:((0,R.vV)(I.oo,"WeatherTopSectionDropdownTemplate empty location"),s.qy``),U=s.qy`<div class="detect-section" role="group" aria-labelledby="detect-heading"><div id="detect-heading" class="detect-title" role="heading">${t=>t.strings.detectLocation}</div><div role="listbox" aria-labelledby="detect-heading">${(0,N.ux)(t=>t.currentView.detectLocation||[],s.qy`${t=>O(t)}`,{positioning:!0})}</div></div>`,E=s.qy`<div class="location-section" role="group" aria-labelledby="my-location-heading"><div id="my-location-heading" class="my-location-title" role="heading">${t=>t.strings.myLocation}</div><div role="listbox" aria-labelledby="my-location-heading" class="my-location-list">${(0,N.ux)(t=>t.currentView.followLocation||[],s.qy`${t=>O(t)}`,{positioning:!0})}</div></div>`,M=s.qy`<div class="dropdown-back"><button class="dropdown-back-button" type="button" ${(0,W.K)("backButton")} aria-label="Back to previous view" data-t="${t=>{var e;return(null===(e=t.telemetry)||void 0===e?void 0:e.cancelTg)||""}}" @click="${t=>t.hideLocationEdit&&t.hideLocationEdit()}" title="${t=>t.strings.changeLocation||"Change location"}"><img src=${t=>t.isDarkTheme?(0,o.hk)("LeftArrow_Co_D.svg"):(0,o.hk)("LeftArrow_Co.svg")} alt=""></img></button><span class="dropdown-back-text">${t=>t.strings.changeLocation||"Change location"}</span></div>`,P=s.qy`<div class="dropdown-container" role="dialog" aria-modal="true" aria-label="Location selection" tabIndex="-1" data-t="${t=>{var e;return(null===(e=t.rootTelemetry)||void 0===e?void 0:e.getMetadataTag())||""}}"><span tabindex="0" @focus="${t=>t.focusToLastFocusableElement()}" class="focus-sentinel" aria-hidden="true"></span>${M}<div class="dropdown-content">${(0,F.z)(t=>t.currentView.detectLocation,U)} ${(0,F.z)(t=>t.currentView.followLocation&&t.currentView.followLocation.length>0,E)}</div><span tabindex="0" @focus="${t=>{var e;return null===(e=t.backButton)||void 0===e?void 0:e.focus()}}" class="focus-sentinel" aria-hidden="true"></span></div>`,H=s.qy` ${(0,F.z)(t=>t&&t.currentView,P)}
`;let B=class extends y{};B=(0,u.Cg)([(0,p.E)({name:"location-edit-dialog",template:H,styles:_,shadowOptions:{delegatesFocus:!0}})],B);var V=i(38493),j=i(25109);const J=t=>t?(0,o.hk)("Home_Co_D.svg"):(0,o.hk)("Home_Co.svg"),q=t=>t?(0,o.hk)("SetHome_Co_D.svg"):(0,o.hk)("SetHome_Co.svg"),G=t=>t?(0,o.hk)("DisableRemove_Co_D.svg"):(0,o.hk)("DisableRemove_Co.svg"),X=t=>t?(0,o.hk)("Remove_Co_D.svg"):(0,o.hk)("Remove_Co.svg");function K(t,e,i,n){let a=arguments.length>4&&void 0!==arguments[4]&&arguments[4];const[s,l,d]=t,c=(0,w.Bh)(s),h=[],u={icon:q((0,j.ud)()),tooltip:i.setHome,telemetry:n?(0,r.lC)(n,`setHome_${c}`).getMetadataTag():"",onClick(){a&&e.resetCardAction&&e.resetCardAction(),e.setHome&&e.setHome(s)}};var p;l?h.push({icon:J((0,j.ud)()),tooltip:i.primaryLocation}):d?(h.push({icon:(p=(0,j.ud)(),p?(0,o.hk)("Detect_Co_D.svg"):(0,o.hk)("Detect_Co.svg")),tooltip:i.detectLocation}),h.push({...u})):h.push({...u});const v=l||d,g={icon:v?G((0,j.ud)()):X((0,j.ud)()),tooltip:v?i.disableRemove:i.remove,telemetry:n?(0,r.lC)(n,`rmHome_${c}`).getMetadataTag():"",onClick:v?void 0:()=>e.removeFollowedLocation&&e.removeFollowedLocation(s)};return h.push(g),h}function Z(t,e,i,o,n){const{homeLocation:a,followedLocations:s}=e,l=(0,w.Bh)(t),d=[];return(0,m.gf)(a,t)?d.push({icon:J((0,j.ud)()),tooltip:o.primaryLocation}):d.push({icon:q((0,j.ud)()),tooltip:o.setHome,telemetry:n?(0,r.lC)(n,`setHome_${l}`).getMetadataTag():"",onClick(){return i.setHome&&i.setHome(t)}}),d}var Q;!function(t){t[t.LocationList=0]="LocationList",t[t.SearchList=1]="SearchList",t[t.NoResult=2]="NoResult"}(Q||(Q={}));class Y extends p.L{constructor(){super(...arguments),this.requestContext=new f.bb,this.cardState=0,this.locationListView=[],this.searchListView=[],this.alignLeft=!1,this.handleResize=()=>{this.checkPositioning()},this.removeFollowedLocation=t=>{const e=this.locationList,i=e.findIndex(e=>{let[i,o,n]=e;return(0,m.gf)(i,t)});i>-1&&(this.locationList=e.slice(0,i).concat(e.slice(i+1)),this.getLocationListView()),this.removeLocation(t)},this.setHomeAndResetCardAction=t=>{"function"==typeof this.resetCardAction&&this.resetCardAction(),this.setHome(t)},this.focusToDropdownBackButton=()=>{this.dropdownBackButton&&this.dropdownBackButton.focus()},this.focusToLastFocusableElement=()=>{var t;const e=this.shadowRoot;if(!e)return;const i=null==e||null===(t=e.querySelectorAll)||void 0===t?void 0:t.call(e,"button:not([disabled]), input:not([disabled])");if(!i)return;const o=Array.from(i).filter(t=>{const e=t;return null!==e.offsetParent||e.offsetWidth>0||e.offsetHeight>0});o.length>0&&o[o.length-1].focus()}}locationListChanged(){this.getLocationListView(),this.getSearchListView()}isDarkThemeChanged(){this.getLocationListView()}connectedCallback(){super.connectedCallback(),this.initTelemetry(),this.getLocationListView(),window.setTimeout(()=>{this.focusToDropdownBackButton()},300),window.setTimeout(()=>{this.checkPositioning()},0),window.addEventListener("resize",this.handleResize)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("resize",this.handleResize)}checkPositioning(){v.L.enqueue(()=>{var t;const e=this.closest("weather-top-section-card")||this.parentElement;if(!e)return;const i=e.getBoundingClientRect(),o=(0,f.KP)(null===(t=this.requestContext)||void 0===t||null===(t=t.data)||void 0===t?void 0:t.innerWidth,"innerWidth");i.right+336>o?this.alignLeft=!0:this.alignLeft=!1})}initTelemetry(){if(this.rootTelemetry){const t=(0,r.un)((0,r.lC)(this.rootTelemetry,"searchbox"),b.MS.TextSearch),e=(0,r.un)((0,r.lC)(this.rootTelemetry,"close"),b.MS.Close),i=(0,r.lC)(this.rootTelemetry,"locationList"),o=(0,r.lC)(this.rootTelemetry,"searchList");this.telemetry={searchTg:t.getMetadataTag(),cancelTg:e.getMetadataTag(),locationListTO:i,searchListTO:o}}}async handleInputForSuggest(t){if(this.inputControl)if(t&&t.preventDefault(),this.inputControl&&this.inputControl.value){const t=await this.getSuggestList(this.inputControl.value);t&&0!=t.length?(this.suggestList=t,this.getSearchListView(),this.cardState=Q.SearchList):this.cardState=Q.NoResult}else this.cardState=Q.LocationList}getLocationListView(){const t=this.locationList.map(t=>{var e;let[i,o,n]=t;const r={setHome:this.setHome,removeFollowedLocation:this.removeFollowedLocation,resetCardAction:this.resetCardAction};return{id:x.toLatLong(i),cityName:x.getDisplayName(i,{skipCountry:!0,skipOldName:!0}),regionName:x.getDisplayName(i,{skipAddressLine:!0,skipLocale:!0,skipOldName:!0}),actionButtons:K([i,o,n],r,this.strings,null===(e=this.telemetry)||void 0===e?void 0:e.locationListTO,!0)}});this.locationListView=t}getSearchListView(){if(!this.suggestList)return;const{homeLocation:t,followedLocations:e}=(0,m.i4)(this.locationList),i=this.suggestList.map(i=>{var o;const n=i.firstLine||x.getDisplayName(i);return{id:x.toLatLong(i),cityName:n,regionName:i.secondLine||"",actionButtons:Z(i,{homeLocation:t,followedLocations:e},{setHome:t=>this.setHomeAndResetCardAction(t)},this.strings,null===(o=this.telemetry)||void 0===o?void 0:o.searchListTO)}});this.searchListView=i}closeHandler(){this.inputControl&&(this.inputControl.value=""),this.cardState=Q.LocationList,this.toSetting&&this.toSetting()}}(0,u.Cg)([g.sH],Y.prototype,"locationList",void 0),(0,u.Cg)([g.sH],Y.prototype,"cardState",void 0),(0,u.Cg)([g.sH],Y.prototype,"rootTelemetry",void 0),(0,u.Cg)([g.sH],Y.prototype,"telemetry",void 0),(0,u.Cg)([V.CF],Y.prototype,"cardSize",void 0),(0,u.Cg)([g.sH],Y.prototype,"isDarkTheme",void 0),(0,u.Cg)([g.sH],Y.prototype,"locationListView",void 0),(0,u.Cg)([g.sH],Y.prototype,"searchListView",void 0),(0,u.Cg)([g.sH],Y.prototype,"alignLeft",void 0);var tt=i(50882);const et=C.A`
`,it=C.A`
`,ot=C.A` .location-list-v2{background:#FFFFFF0D}.setting-input-v2::placeholder{color:var(--foreground-ctrl-neutral-secondary-rest,#828BAC) !important}.setting-container-v2{background:#1d2437;border-color:#1d2437}.search-container-v2{border:1px solid rgba(255,255,255,0.05);background:rgba(75,92,146,0.25)}.name-line1-v2{color:#F2DDCC !important}.location-list-scroll::-webkit-scrollbar-thumb{background:#D7DEEF}`,nt=C.A` .setting-container-v2{box-sizing:border-box;padding:8px;width:290px;height:444px;background:#fff;position:relative;border-radius:var(--smtc-corner-flyout-rest);border:1px solid #EAEDF0;z-index:${D.P.Above.toString()};padding:8px;overflow:hidden}.dropdown-back{box-sizing:border-box;padding:7px 4px;height:50px;display:flex;align-items:center;justify-content:start;gap:8px;margin-bottom:4px}.dropdown-back img{height:20px;width:20px;flex-shrink:0;margin:8px;cursor:pointer}.name-line2-v2,.dropdown-back-text,.setting-input-v2::placeholder{font-size:var(--smtc-text-global-body3-font-size);line-height:var(--smtc-text-global-body3-line-height);font-weight:var(--smtc-text-style-default-regular-weight)}.setting-input-v2::placeholder,.location-header-v2,.name-line2-v2,.no-result-text{color:var(--smtc-foreground-ctrl-neutral-secondary-rest)}.dropdown-back-text,.setting-input-v2{color:var(--smtc-foreground-ctrl-neutral-primary-rest)}.location-header-v2,.no-result-text{font-size:var(--smtc-text-global-body1-font-size);line-height:var(--smtc-text-global-body1-line-height)}.no-result-text{font-weight:var(--smtc-text-style-default-regular-weight)}.search-container-v2{position:relative;height:48px;border-radius:12px;background:rgba(0,0,0,0.05);border:1px solid rgba(0,0,0,0.05);box-sizing:border-box;padding:8px 12px;display:flex;align-items:center;margin:0 12px;width:248px;overflow:hidden}.search-icon{height:20px;width:20px;flex-shrink:0;margin:0px 6px}.setting-input-v2{border:none;background:none;padding:0;font-size:16px;line-height:24px;max-width:168px;font-weight:400;width:100%}.setting-input-v2:focus{outline:none}.search-clear{flex-shrink:0;border-radius:100%;height:16px;width:16px;display:none;align-items:center;justify-content:center;border:none;background:transparent;cursor:pointer}.search-clear img{height:16px;width:16px}.setting-input-v2:valid + button{display:flex}.location-header-v2{padding:4px 0px;height:34px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin:0px 12px 12px 12px;box-sizing:border-box}.location-list-scroll{height:252px;overflow-x:hidden;overflow-y:scroll;padding:0 12px;box-sizing:border-box}.location-list-scroll::-webkit-scrollbar-thumb{background:#E2DDD9}.location-list-section{width:274px;height:322px;overflow:hidden;padding:12px 0px;box-sizing:border-box}.location-result-v2{width:248px}.location-list-v2{display:flex;height:54px;width:248px;padding:8px 12px;margin-bottom:12px;justify-content:space-between;align-items:center;box-sizing:border-box;border-radius:12px;background:linear-gradient(0deg,#F6F9FC 0%,#F6F9FC 100%),#FFF;cursor:auto}.name-line1-v2{color:#282523 !important;font-weight:650 !important;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;overflow:hidden;text-overflow:ellipsis;font-size:var(--smtc-text-global-body2-font-size);line-height:var(--smtc-text-global-body2-line-height)}.name-line2-v2{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;overflow:hidden;text-overflow:ellipsis;font-style:normal}@media (forced-colors:active){.location-list-scroll::-webkit-scrollbar-thumb{background:${tt.A.LinkText} !important;
            border: 1px solid ${tt.A.LinkText} !important;
        }
    }
`,rt=C.A`
    ${nt} .no-result-text{margin:12px 12px 32px}.no-result-img{width:130px;height:136px;margin-inline:auto;display:flex}::-webkit-scrollbar{width:4px}::-webkit-scrollbar-thumb{background:#A8A8A8;-webkit-border-radius:20px;cursor:pointer}.action-bottons{display:flex;gap:8px}.dropdown-back-button{background:none;border:none;padding:0;cursor:pointer;display:flex}.visually-hidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}`.withBehaviors(new L.t(et,it),new k.N(null,ot),(0,$.G2)(C.A`${ot}`),(0,$.mr)(C.A``)),at=t=>{if(t&&(t.cityName||t.regionName)){const e=t.actionButtons?t.actionButtons.length:0,i=t.cityName||"",o=t.regionName||"",n=i&&o?`${i}, ${o}`:i||o;return s.qy`<div class="location-list-v2" role="listitem" @click=${()=>{var i,o;return 1==e?null===(i=(o=t.actionButtons[0]).onClick)||void 0===i?void 0:i.call(o):void 0}} data-t="${1==e&&t.actionButtons[0].telemetry||""}" aria-label="${n}"><div class="location-name"><div class="name-line1-v2" title="${i}">${i}</div><div class="name-line2-v2" title="${o}">${o}</div></div><div class="action-bottons" role="group" aria-label="Location actions">${(0,N.ux)(t.actionButtons||[],s.qy`${t=>((t,e)=>{const i=e?`${t.tooltip}, ${e}`:t.tooltip;return s.qy`<button style="${t.onClick?"cursor: pointer; padding: 0; background: none; border: none;":"padding: 0; background: none; border: none;"}" @click=${()=>{t.onClick&&t.onClick()}} tabindex="0" data-t="${t.telemetry||""}" aria-label=${i} title=${t.tooltip} ?disabled=${!t.onClick}><img src=${t.icon} alt="" aria-hidden="true"></img></button>`})(t,n)}`,{positioning:!0})}</div></div>`}return(0,R.vV)(I.oo,"WeatherTopSectionSettingTemplate empty location"),s.qy``},st=s.qy`<div class="no-result-text">${t=>t.strings.noResult}</div><img class="no-result-img" src=${(0,o.hk)("SearchIllustration.png")} alt="" aria-hidden="true"></img>`,lt=s.qy`<div class="search-container-v2" role="search"><img class="search-icon" src=${t=>t.isDarkTheme?(0,o.hk)("Search_Co_D.svg"):(0,o.hk)("Search_Co.svg")} alt="" aria-hidden="true"></img><input class="setting-input-v2" id="weather_location_input" placeholder="${t=>t.strings.searchPlaceholder}" @input="${t=>t.handleInputForSuggest()}" @blur="${()=>{}}" type="text" role="combobox" aria-label="${t=>t.strings.searchPlaceholder}" aria-expanded="${t=>t.searchListView&&t.searchListView.length>0?"true":"false"}" aria-describedby="search-status" data-t="${t=>{var e;return null===(e=t.telemetry)||void 0===e?void 0:e.searchTg}}" autocomplete="off" aria-autocomplete="list" aria-owns="weather_location_search_list" aria-controls="weather_location_search_list" ${(0,W.K)("inputControl")} autofocus required /><button class="search-clear" aria-label="${t=>t.strings.cancel}" title="${t=>t.strings.cancel}" data-t="${t=>{var e;return null===(e=t.telemetry)||void 0===e?void 0:e.cancelTg}}" @click="${t=>{t.closeHandler&&t.closeHandler()}}"><img src=${t=>t.isDarkTheme?(0,o.hk)("DismissIcon_D.svg"):(0,o.hk)("DismissIcon.svg")} alt="" aria-hidden="true"></img></button></div><div id="search-status" class="visually-hidden" role="status" aria-live="polite" aria-atomic="true">${t=>function(t){if(t.cardState===Q.NoResult)return t.strings.noResult;if(t.searchListView&&t.searchListView.length>0)return`${t.searchListView.length} ${t.strings.suggestionsAvailable||"suggestions available"}: ${t.searchListView.map(t=>`${t.cityName}, ${t.regionName}`).join("; ")}`;return""}(t)}</div>`,dt=s.qy`<div class="setting-container-v2" role="dialog" aria-modal="true" aria-label="${t=>t.strings.manageLocation||"Manage my location list"}" data-t="${t=>{var e;return(null===(e=t.rootTelemetry)||void 0===e?void 0:e.getMetadataTag())||""}}"><span tabindex="0" @focus="${t=>t.focusToLastFocusableElement()}" class="focus-sentinel" aria-hidden="true"></span><div class="dropdown-back" data-t="${t=>{var e;return(null===(e=t.telemetry)||void 0===e?void 0:e.cancelTg)||""}}"><button class="dropdown-back-button" @click="${t=>t.hideLocationEdit&&t.hideLocationEdit()}" aria-label="${t=>t.strings.back||"Back"}" ${(0,W.K)("dropdownBackButton")}><img src=${t=>t.isDarkTheme?(0,o.hk)("LeftArrow_Co_D.svg"):(0,o.hk)("LeftArrow_Co.svg")} alt="" aria-hidden="true"></img></button><span class="dropdown-back-text">${t=>t.strings.manageLocation||"Manage my location list"}</span></div>${lt}<div class="location-list-section">${t=>((t,e)=>{if(e===Q.NoResult)return st;const i=e==Q.SearchList,{strings:o,telemetry:n,searchListView:r=[],locationListView:a=[]}=t||{},l=i?null==o?void 0:o.searchResultHeader:null==o?void 0:o.myLocationTitle,d=i?null==n?void 0:n.searchListTO.getMetadataTag():null==n?void 0:n.locationListTO.getMetadataTag(),c=i?r:a;return s.qy`<div class="location-header-v2" id="location-header-v2" title="${l||""}">${l||""}</div><div class="location-list-scroll"><div class="location-result-v2" role="list" aria-labelledby="location-header-v2" data-t="${d||""}">${(0,N.ux)(t=>c||[],s.qy`${t=>at(t)}`,{positioning:!0})}</div></div>`})(t,t.cardState)}</div><span tabindex="0" @focus="${t=>{var e;return null===(e=t.dropdownBackButton)||void 0===e?void 0:e.focus()}}" class="focus-sentinel" aria-hidden="true"></span></div>`,ct=s.qy` ${(0,F.z)(t=>t&&t.locationListView&&t.strings,dt)}
`;let ht=class extends Y{};ht=(0,u.Cg)([(0,p.E)({name:"location-manage-dialog",template:ct,styles:rt,shadowOptions:{delegatesFocus:!0}})],ht);var ut=i(9299),pt=i(37180),vt=i(58661);const gt=t=>new Map([[0,{component:void 0,loadCheck:!!B}],[1,{component:void 0,loadCheck:!!ht}]]);function bt(t){ut.m.define(pt.c.registry),vt.m.define(pt.c.registry);const e={};for(const[i,o]of gt(t))o.loadCheck&&(e[i]=o.component);return e}var mt=i(22362),ft=i(68073),wt=i(15948),xt=i(38020),yt=i(17925),$t=i(15525),kt=i(58792),Lt=i(96990),Ct=i(78178),Dt=i(97223),St=i(9206);class Tt{constructor(t){this.card=t,this.config=t.config;const e=function(t){const e=(0,mt.V)();return{autosuggest:(0,ft.X)(t&&t.autoSuggestionConfig),pdpClient:new wt.U,overviewServiceClient:(0,xt.$)(e,t,"")}}(this.config);this.weatherAutoSuggestClient=e.autosuggest,this.weatherPdpClient=e.pdpClient,this.overviewServiceClient=e.overviewServiceClient,this.initHandler()}initHandler(){this.setPrimaryLocation=this.setPrimaryLocation.bind(this),this.removeFollowedLocation=this.removeFollowedLocation.bind(this),this.getLocationSuggestList=this.getLocationSuggestList.bind(this),this.switchUnit=this.switchUnit.bind(this)}async setPrimaryLocation(t){let e=!1;return e=await this.weatherPdpClient.setHomeLocation(t),e&&((0,$t.Lg)().setItem(Lt._T,JSON.stringify(t)),window.setTimeout(()=>{this.card.refreshFeedCallback&&this.card.refreshFeedCallback(),"edgeChromium"===kt.T3.AppType&&(0,St.TI)(5)},300)),e}async removeFollowedLocation(t){const{locationList:e}=this.card;let i=!1;i=await this.weatherPdpClient.removeFavoriteLocation(t);const o=e.findIndex(e=>{let[i,o,n]=e;return(0,m.gf)(i,t)});i&&o>-1&&(this.card.locationList=e.slice(0,o).concat(e.slice(o+1)),h(this.card))}async getLocationSuggestList(t){let e=[];const i=await this.weatherAutoSuggestClient.getAutoSuggestResponse(t,!0);return i&&(e=i.map(t=>(t&&!t.displayName&&(t.displayName=t.autoSuggestionName||x.getAutoSuggestionName(t)),t)).filter(t=>!!t)),e}async switchUnit(){const t=this.card.currentUnit===a.B.Fahrenheit?a.B.Celsius:a.B.Fahrenheit;if(await this.weatherPdpClient.setDisplayUnit(t)){const e=t==a.B.Fahrenheit?Ct.Od.CTOF:Ct.Od.FTOC;if(this.card.currentUnit=t,this.card.weatherData.currentCondition){const e=(0,Dt.GF)(this.card.weatherData.currentCondition.deepLink,"weadegreetype",(0,yt.R)(t));this.card.weatherData.currentCondition.deepLink=e}this.card.updateViewByUnit(e),window.dispatchEvent(new CustomEvent("unitSwitchClick",{detail:{changeToUnit:t,tempTransMode:e}})),h(this.card),(0,$t.Lg)().setItem(Lt.F0,JSON.stringify(t)),"winWidgets"===kt.T3.AppType&&window.setTimeout(()=>{this.card.refreshFeedCallback&&this.card.refreshFeedCallback()},300)}}}function zt(t){t.handlers=new Tt(t),t.deferredComponent=bt(t.config),h(t)}},38020(t,e,i){i.d(e,{$(){return M}});var o=i(33709),n=i(1356),r=i(5739),a=i(84177),s=i(68989),l=i(58792),d=i(74998),c=i(77078),h=i(31756),u=i(34230),p=i(92869),v=i(4332),g=i(94684),b=i(49221),m=i(22341),f=i(15938),w=i(83157),x=i(51899),y=i(53964);i(48566);const $=1.609344;function k(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:0;return(arguments.length>1&&void 0!==arguments[1]?arguments[1]:g.B.Fahrenheit)===g.B.Celsius?1.8*t+32:t}function L(t){return t/$}var C=i(88893);class D{constructor(t,e,i){this.fetchImpl=t,this.config=e,this.locationHref=i,this.schemaTranslator=new C.KF(e.truncateTimezone,i)}}var S,T=i(94043);!function(t){t[t.Fahrenheit=1]="Fahrenheit",t[t.Celsius=2]="Celsius"}(S||(S={}));var z=i(82127);const A="https://assets.msn.com",_="weather/overview",F="segments/recoitems/weather";var N;!function(t){t[t.Not_Detected=1]="Not_Detected",t[t.Overview=2]="Overview",t[t.OverviewUser=3]="OverviewUser",t[t.SegmentOverview=4]="SegmentOverview"}(N||(N={}));const W={startDate:"-1",endDate:"+9",simplifyInsights:!0,fdhead:"PRG-1SW-WXWPDEL,PRG-1SW-WXWPDS,PRG-1SW-WXWPTLI,prg-1sw-wxaqif,prg-1sw-wxaqifct"};class R extends D{shouldAttachCookie(t,e){return!this.config.isFailOverHost&&("zh-cn"!==t&&!(!e||!e.readChoice&&!e.saveChoice))}async getWeather(t,e,i){t=t||{},i=i||{};const a=l.T3.LocaleContentMarket,s=a.language+"-"+a.market,{serviceUrl:u}=function(t,e){const{weatherApi:{path:i,endpoint:o}}=t;let n,r;const a=i===F?4:2;if((0,v.e3)()&&2===a)return n=A,r=_,{serviceUrl:E(n,r,e),variant:a};return n=o,r=i||_,{serviceUrl:E(n,r,e),variant:a}}(this.config,s),p=u.pathname,f=u.searchParams,w=await h.WR.getBaseRequestData("GET");(this.shouldAttachCookie(s,i)||i.includeCookie||this.config.weatherApi.includeCookie)&&(w.credentials="include"),w.referrerPolicy="no-referrer-when-downgrade";const x=function(t,e,i,o,n,a,s){const{appId:u,apiKey:p,accessStr:v,ocid:b,days:m,partialHours:f,includemapsmetadata:w,includecommentary:x,alertDistanceinkm:$,cutHour:k,features:L,fdhead:C,lifeDays:D,lifeModes:S,lifeSubTypes:A,includeLifeActivity:_,includeSwArea:F,includeActivity:N,includestorm:R,insights:I,includeUserPreference:E,startDate:M,endDate:P,simplifyInsights:H,insightCategories:B,contentcount:V}=(0,r._E)()?{...i.weatherApi,startDate:W.startDate,endDate:W.endDate,simplifyInsights:W.simplifyInsights}:i.weatherApi;h.WR.getCommonParams2(b,!1).forEach(t=>{e.set(t.key,t.value)}),s&&e.set("units",s===g.B.Fahrenheit?"F":"C"),U(e,"appId",u),e.set("apikey",v??p),e.set("wrapodata","false"),O(e,"includemapsmetadata",w),O(e,"cuthour",k),O(e,"includecommentary",x),U(e,"feature",(L||[]).join(",")),U(e,"filterRule",o.filterRule),U(e,"lifeDays",D),U(e,"contentcount",V?V.toString():""),U(e,"lifeModes",S),O(e,"includeSwArea",F),O(e,"includestorm",R),O(e,"includeLifeActivity",_),U(e,"lifeSubTypes",(A||[]).join(",")),(0,y.Ow)()&&O(e,"includeActivity",N);"ActivityPlanner"===o.lifeTopic&&(O(e,"includeActivity",!0),O(e,"includeUserPreference",!0));E&&(O(e,"includeActivity",!0),O(e,"includeUserPreference",!0));(0,r.By)()&&O(e,"agentic",!0);(0,T.S)()&&(0,r._4)()&&O(e,"includehazards",!0);((0,T.S)()||(0,r.Y5)()||(0,r.vf)()||(0,r.ep)()||(0,r.Fl)()||(0,r.S_)())&&(U(e,"insights",I),U(e,"insightCategories",o.insightCategories??B),((0,r.Y5)()||(0,r.vf)()||(0,r.ep)()||(0,r.S_)()||(0,r.Fl)())&&(U(e,"startDate",(0,z.HP)(M)),U(e,"endDate",void 0!==o.endDate?(0,z.HP)(o.endDate):(0,z.HP)(P)),O(e,"discardFutureInsightTimeseries",H)));if(t){const i=new URL(t);if(n.indexOf("private")>=0){const t=i.searchParams.get("env");e.set("env",t)}const o=i.searchParams.get("day");o&&parseInt(o)>1&&e.set("lifeDays",o)}const{disableFetchRegionData:j,experience:J,isStaleRefresh:q}=o.requestInfo||{};j||(e.set("distanceinkm",$||"0"),e.set("regionDataCount","20"),e.set("orderby","distance"));m&&(e.set("days",m),e.set("pageOcid",h.WR.getOneServiceOCID(l.T3.TrackInfo,"peregrine")),U(e,"source",J&&J+(q?"1":"0")));e.set("source",`${d.Rb.ClientSettings.verticalKey}_${(0,T.S)()?"csr":"ssr"}`);const G=(o.partialHours||f)&&o.partialHourly,X=G&&o.hourlyStartDay-1>0;(0,T.S)()||U(e,"trimhourly24",G&&(o.partialHours||f)?"true":"false");U(e,"startday",X&&(o.hourlyStartDay<=10&&o.hourlyStartDay>=1?o.hourlyStartDay-1:0)),o.hourlyDataDays&&!m&&e.set("days",o.hourlyDataDays);o.lifeDataDays&&e.set("lifeDays",o.lifeDataDays);const K=function(t,e){let i=[];if(d.Rb.CurrentFlightSet){const t="prg-dualauth";d.Rb.CurrentFlightSet.has(t)&&(i.push(t),i.push("1s-jwtuserauth")),d.Rb.CurrentFlightSet.forEach(t=>{(0,r.Ok)(t)&&i.push(t)})}((0,r.ep)()||(0,r.S_)())&&i.push("PRG-1SW-WXWPDEL","PRG-1SW-WXWPDS","PRG-1SW-WXWPTLI");if((0,r.nT)()){const t=new Set(i);t.delete("prg-1sw-wxaqifct"),i=Array.from(t)}(0,c.J5)()&&i.push("prg-1sw-wxteday");e.additionalFdHead&&i.push(...e.additionalFdHead.split(","));((0,r._E)()||(0,r.U1)())&&i.push(...W.fdhead.split(","));(0,r.S_)()&&i.push("prg-1sw-weacopilot");(0,r.TN)()&&i.push("PRG-1SW-WXINSV2","PRG-1SW-WXOIVT");(0,T.S)()&&(0,r._4)()&&i.push("prg-1sw-ntprhaz","prg-1sw-p2rhaz");if(0==i.length)return t;{const e=t?`${t},${i.join(",")}`:`${i.join(",")}`;return Array.from(new Set(null==e?void 0:e.split(","))).join(",")}}(C,o);K?e.set("fdhead",K):e.delete("fdhead");o.sfParams&&e.set("sf",o.sfParams);const Z=i.weatherApi.queries||{};for(let[t,i]of Object.entries(Z))"{market}"===i&&(i=a),e.set(t,i);return X}(this.locationHref,f,this.config,i,u.host,s,e);!function(t,e,i,o,n){t.set("region",o.market),t.set("market",(i.isoCode||o.market).toUpperCase()),t.set("locale",n),i&&i.latitude&&i.longitude&&(t.set("lat",i.latitude),t.set("lon",i.longitude));let a=n;"ru-xl"===a&&(a="en-xl");t.set("market",a),(0,r.JQ)()&&i&&i.jpAreaCode&&t.set("jpareacode",i.jpAreaCode)}(f,0,t,a,s),function(t,e,i){if(e.enableMockWeatherApiV2){const e=new URL(i).searchParams.get("testCaseId");e&&t.set("id",e)}}(f,this.config,this.locationHref);const{experience:$}=i.requestInfo||{},C=await this.sendApiRequest(u,w,$,t,i);if(null===C)return null;if(C.status&&(0,T.S)()){const t=b.bj;(0,m.c_)(Error("Request failure but retry success"),t,C.status+","+p,`Request url: [${u.href}].`)}const D={location:C.usedLocation,locStrResolver:o.l};try{const t=C.weatherSummary,e=this.schemaTranslator.TranslateToWeatherOverview(t,D,this.config,x),i=function(t){var e,i;const o={},r=t&&t.userProfile;if(!r)return o;r.default?o.home=R.convert(r.default):r.location&&(o.home=R.convert(r.location));o.followedLocations=(null===(e=r.followedLocations)||void 0===e||null===(e=e.map(t=>R.convert(t)))||void 0===e?void 0:e.filter(t=>!!t))||[],o.detectedLocation=R.convert(r.autoDetected||r.detectedLocation),o.sig=r.sig,o.mapSetting=r.mapSetting&&JSON.parse(r.mapSetting),o.theme=r.theme,o.activityProfile=r.weatherRunningPreference&&JSON.parse(r.weatherRunningPreference),o.locationMode=Number.isNaN(r.locationSettingMode)?void 0:Number(r.locationSettingMode);const a=function(t){return"°ฟาเรนไฮด์"===t||"‎°ف"===t||t===S.Fahrenheit?S.Fahrenheit:"°เซลเซียส"===t||"‎°م"===t||t===S.Celsius?S.Celsius:(""+t).includes("F")?S.Fahrenheit:S.Celsius}(null==t||null===(i=t.units)||void 0===i?void 0:i.temperature);return function(t,e){var i,o;e===g.B.Fahrenheit&&null!=(null==t||null===(i=t.activityProfile)||void 0===i?void 0:i.preference)&&(t.activityProfile.preference.tempHigh=k(t.activityProfile.preference.tempHigh,g.B.Celsius),t.activityProfile.preference.tempLow=k(t.activityProfile.preference.tempLow,g.B.Celsius),t.activityProfile.preference.windHigh=L(t.activityProfile.preference.windHigh));if(e===g.B.Fahrenheit&&null!=(null==t||null===(o=t.activityProfile)||void 0===o?void 0:o.p))for(const e in n.Si)e in t.activityProfile.p&&(t.activityProfile.p[e].th=k(t.activityProfile.p[e].th,g.B.Celsius),t.activityProfile.p[e].tl=k(t.activityProfile.p[e].tl,g.B.Celsius),t.activityProfile.p[e].wh=L(t.activityProfile.p[e].wh),t.activityProfile.p[e].wgh=L(t.activityProfile.p[e].wgh))}(o,a),o}(t);return{home:void 0,location:C.usedLocation,forecast:e,profile:i,cards:t.cards}}catch(t){return(0,m.c_)(t,C.weatherDataFetchError,"error in library [weather-shared],Failed to translate overview: "+JSON.stringify(C.weatherSummary)),null}}async sendApiRequest(t,e,i,o,r){const a={weatherSummary:void 0,weatherDataFetchError:null,status:void 0,usedLocation:void 0,isNetworkFailure:!1},l=!(0,T.S)(),d=t.pathname;let c,h;a.weatherDataFetchError="scard"===i?b.WZ:l?b.f9:b.tP;try{var g;let i;if(a.weatherSummary=await(0,u.w)(async r=>{let d;try{var u,v,g,b;const o=(0,f.gU)();(0,w.cE)(n._2.overviewRequestStart,o),(0,w.cE)(n._2.overviewRequestPathHash,I(t.pathname)),d=await this.overviewFetchImpl(l,t,e,function(t){if(!(0,T.S)()){const e=(0,s.MV)();return e.trackApiClusterInServer=!0,t&&(e.timeoutMs=t),e}}(null===(u=this.config.weatherApi)||void 0===u?void 0:u.nodeFetchTimeoutMs)),c=null===(v=d.headers)||void 0===v?void 0:v.get("Ddd-Debugid"),h=null===(g=d.headers)||void 0===g?void 0:g.get("X-Msedge-Ref");const r=null===(b=c)||void 0===b?void 0:b.split("|")[3];r&&(0,w.cE)(n._2.overviewRequestCluster,I(r)),i=(0,f.gU)()-o,(0,p.M)(t.host,t.pathname,Math.round(i)),(0,w.cE)(n._2.overviewRequestDuration,i)}catch(t){throw a.status=t&&`${t.toString()} with retry=${r}`,a.isNetworkFailure=!0,t}if(!d.ok){if(a.status=`code=${d.status}, ${d.statusText}`,d.status>=400&&d.status<=500&&408!=d.status)return{isError:!0,errorCode:d.status};throw Error(d.statusText)}if(l&&d.headers){const t=d.headers.get("onewebservicelatency"),e=t?+t:-1;-1!=e&&((0,w.cE)(n._2.overviewRequestInternal,e),(0,w.cE)(n._2.overviewRequestNetwork,i-e))}const m=await this.parseApiResponse(d,t,o);return a.usedLocation=m.usedLocation,m.weatherData},d,-1),null!==(g=a.weatherSummary)&&void 0!==g&&g.isError)throw Error(a.status)}catch(e){var x;if(r.preventLogExceptionOnFailure)return null;a.status||(a.status=e&&e.toString());const{experience:i}=r.requestInfo||{};i&&(a.status=i+":"+a.status);const n=`Request url: [${t.href}]. Error detail: [${e&&e.toString()}] debug id: [${c}] msedge ref:[${h}]`,s=l?null:navigator.userAgent;if((0,v.e3)(s))(0,m.c_)(e,b.vZ,"error in library [weather-shared],"+a.status+","+d,n);else if(this.config.enableMockWeatherApiV2)(0,m.c_)(e,b.pZ,"error in library [weather-shared],"+a.status+","+d,n);else if(422===(null===(x=a.weatherSummary)||void 0===x?void 0:x.errorCode)){const i=`Request url: [${t.href}]. Error detail: [${e&&e.toString()}]. Location: [lat=${o.latitude}, lon=${o.longitude}] debug id: [${c}]`;(0,m.c_)(e,b.p4,"error in library [weather-shared],"+a.status+","+d,i)}else a.status.indexOf("404")>-1?a.weatherDataFetchError=b.bJ:a.isNetworkFailure&&(a.weatherDataFetchError=b.Lj),(0,m.c_)(e,a.weatherDataFetchError,"error in library [weather-shared],"+a.status+","+d,n);return null}return a}async overviewFetchImpl(t,e,i,o){const n=e.href;return await this.fetchImpl(n,i,o)}async parseApiResponse(t,e,i){const o={weatherData:void 0,usedLocation:i};if(e.pathname.indexOf("segments")>-1){const e=function(t){try{const e=JSON.parse(t[0].data),i=e.userProfile.location,o="2"===e.userProfile.locationSettingMode,n=(i.Language||d.Rb.Locale).toLocaleLowerCase();return[e,{addressLine:i.AddressLine,subRegion:i.SubRegion,locality:i.City,region:(0,a.abbreviateUSState)(i.State,n,i.CountryCode),country:i.Country,postalCode:i.PostalCode,isoCode:i.CountryCode,from:o?2:void 0,language:n,latitude:""+i.Latitude,longitude:""+i.Longitude}]}catch(t){throw new Error("invalid SegmentStore api response: "+t.stack)}}(await t.json());return o.weatherData=e[0],(0,x.B1)(i)||(o.usedLocation=e[1]),o}if(o.weatherData=await t.json(),(0,r.JQ)()&&null!=i&&i.jpAreaCode){var n,s,l;const t=null===(n=o.weatherData.userProfile)||void 0===n||null===(n=n.used)||void 0===n?void 0:n.geoCoordinates,e={latitude:null==t||null===(s=t.latitude)||void 0===s?void 0:s.toString(),longitude:null==t||null===(l=t.longitude)||void 0===l?void 0:l.toString()};if((0,x.B1)(e))return o.usedLocation=e,o}if(!(0,x.B1)(i)||i.isDetected&&!i.isBlisDetected){var c;const t=R.convert(o.weatherData.userProfile&&o.weatherData.userProfile.default);if(t)return o.usedLocation=t,o;const i=null===(c=o.weatherData.userProfile)||void 0===c||null===(c=c.used)||void 0===c?void 0:c.geoCoordinates;if(null===e.searchParams.get("lat")&&null===e.searchParams.get("lon")&&i){var h,u;o.usedLocation={latitude:null===(h=i.latitude)||void 0===h?void 0:h.toString(),longitude:null===(u=i.longitude)||void 0===u?void 0:u.toString(),isDetected:!0}}else{var p,v,g;const t=null===(p=o.weatherData.responses)||void 0===p||null===(p=p[0])||void 0===p||null===(p=p.source)||void 0===p?void 0:p.coordinates;o.usedLocation={latitude:null==t||null===(v=t.lat)||void 0===v?void 0:v.toString(),longitude:null==t||null===(g=t.lon)||void 0===g?void 0:g.toString(),isDetected:!0}}}return o}static convert(t){if(t&&!t.geoCoordinates&&t.Latitude&&t.Longitude&&(t.geoCoordinates={latitude:t.Latitude,longitude:t.Longitude}),(t=(0,a.toCamelCase)(t,{ISOCode:"isoCode"}))&&t.geoCoordinates){var e,i;const o=(t.language||(0,x.u0)(t.locationTypeId)||d.Rb.Locale).toLocaleLowerCase();return{addressLine:t.addressLine,subRegion:t.subRegion,locality:t.city,region:(0,a.abbreviateUSState)(t.state,o,t.isoCode),country:t.countryRegion,postalCode:t.postalCode,isoCode:t.isoCode,locationTypeId:t.locationTypeId,definitionName:t.definitionName,from:4,locationType:t.locationType,language:o,latitude:""+t.geoCoordinates.latitude,longitude:""+t.geoCoordinates.longitude,tag:null===(e=t.properties)||void 0===e?void 0:e.tag,confirmed:null===(i=t.properties)||void 0===i?void 0:i.confirmed}}}}function I(t){let e=0;for(let i=0;i<t.length;i++)e=Math.imul(31,e)+t.charCodeAt(i)|0;return e}function O(t,e,i){return i&&t.set(e,"true"),i}function U(t,e,i){i&&t.set(e,`${i}`)}function E(t,e,i){if(!(0,T.S)())return t="https://api.msn.com",e=e.replace("service/",""),new URL(e,t);var o;(t.indexOf("assets.msn.")>=0?(e.indexOf("service/")<0&&(e="service/"+e),"zh-cn"===i&&(t=t.replace(".msn.com",".msn.cn"))):e=e.replace("service/",""),"zh-cn"===i)&&(t=(null===(o=window.location.hostname)||void 0===o?void 0:o.indexOf(".msn.cn"))>=0?t.replace(".msn.com",".msn.cn"):t.replace(".msn.cn",".msn.com"));return t=t.replace("api.msn.","assets.msn."),e=e.startsWith("service/")?e:"service/"+e,new URL(e,t)}function M(t,e,i){return e.weatherApi?new R(t,e,i):void 0}},58661(t,e,i){i.d(e,{m(){return H}});var o=i(37180),n=i(56911),r=i(38493),a=i(60815),s=i(76881),l=i(88458),d=i(92011),c=i(56863);class h extends d.L{}class u extends((0,c.rf)(h)){constructor(){super(...arguments),this.proxy=document.createElement("textarea")}}const p="none";class v extends u{constructor(){super(...arguments),this.resize=p,this.cols=20,this.handleTextInput=()=>{this.value=this.control.value}}readOnlyChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.readOnly=this.readOnly)}autofocusChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.autofocus=this.autofocus)}listChanged(){this.proxy instanceof HTMLTextAreaElement&&this.proxy.setAttribute("list",this.list)}maxlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.maxLength=this.maxlength)}minlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.minLength=this.minlength)}spellcheckChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.spellcheck=this.spellcheck)}select(){this.control.select(),this.$emit("select")}handleChange(){this.$emit("change")}validate(){super.validate(this.control)}}(0,n.Cg)([(0,r.CF)({mode:"boolean"}),(0,n.Sn)("design:type",Boolean)],v.prototype,"readOnly",void 0),(0,n.Cg)([r.CF,(0,n.Sn)("design:type",String)],v.prototype,"resize",void 0),(0,n.Cg)([(0,r.CF)({mode:"boolean"}),(0,n.Sn)("design:type",Boolean)],v.prototype,"autofocus",void 0),(0,n.Cg)([(0,r.CF)({attribute:"form"}),(0,n.Sn)("design:type",String)],v.prototype,"formId",void 0),(0,n.Cg)([r.CF,(0,n.Sn)("design:type",String)],v.prototype,"list",void 0),(0,n.Cg)([(0,r.CF)({converter:r.R$}),(0,n.Sn)("design:type",Number)],v.prototype,"maxlength",void 0),(0,n.Cg)([(0,r.CF)({converter:r.R$}),(0,n.Sn)("design:type",Number)],v.prototype,"minlength",void 0),(0,n.Cg)([r.CF,(0,n.Sn)("design:type",String)],v.prototype,"name",void 0),(0,n.Cg)([r.CF,(0,n.Sn)("design:type",String)],v.prototype,"placeholder",void 0),(0,n.Cg)([(0,r.CF)({converter:r.R$,mode:"fromView"}),(0,n.Sn)("design:type",Number)],v.prototype,"cols",void 0),(0,n.Cg)([(0,r.CF)({converter:r.R$,mode:"fromView"}),(0,n.Sn)("design:type",Number)],v.prototype,"rows",void 0),(0,n.Cg)([(0,r.CF)({mode:"boolean"}),(0,n.Sn)("design:type",Boolean)],v.prototype,"spellcheck",void 0),(0,n.Cg)([a.sH,(0,n.Sn)("design:type",Array)],v.prototype,"defaultSlottedNodes",void 0),(0,l.X)(v,s.gs);class g extends v{appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="outline")}}(0,n.Cg)([r.CF,(0,n.Sn)("design:type",String)],g.prototype,"appearance",void 0);var b=i(74849),m=i(22131),f=i(50882),w=i(64187),x=i(73477),y=i(60993),$=i(61484),k=i(48196),L=i(17767),C=i(37302),D=i(7896),S=i(48751),T=i(46203),z=i(57416),A=i(26920),_=i(36452),F=i(41123),N=i(74838),W=i(14996),R=i(79288);const I=b.A`
    :host([appearance="filled"]) .control {
        background: ${C.F7};
        border-color: transparent;
    }

    :host([appearance="filled"]:hover:not([disabled])) .control {
        background: ${C.Xt};
        border-color: transparent;
    }

    :host([appearance="filled"]:focus-within:not([disabled])) .control {
        border-color: transparent;
        box-shadow: none;
    }
    ${$.p}
`.withBehaviors((0,m.mr)(b.A`
            :host([appearance="filled"]:hover:not([disabled])) .control,
            :host([appearance="filled"]:focus-within:not([disabled])) .control {
                background: ${f.A.Field};
                border-color: ${f.A.FieldText};
            }
            :host([appearance="filled"]:not([disabled]):active)::after,
            :host(
                    [appearance="filled"]:not([disabled]):focus-within:not(:active)
                )::after {
                border-bottom-color: ${f.A.Highlight};
            }
        `)),O=b.A`
    ${(0,w.V)("inline-flex")} :host {
        font-family: ${D.O};
        outline: none;
        user-select: none;
        position: relative;
        flex-direction: column;
        vertical-align: bottom;
    }

    .control {
        box-sizing: border-box;
        position: relative;
        color: ${S.l};
        background: ${T.le};
        border-radius: calc(${z.Pb} * 1px);
        border: calc(${A.XA} * 1px) solid ${_.I2};
        height: calc(${k.D} * 2px);
        font: inherit;
        font-size: ${F.K};
        line-height: ${F.Z};
        padding: calc(${N.vR} * 1.5px) calc(${N.vR} * 2px + 1px);
        width: 100%;
        resize: none;
    }

    .control:hover:enabled {
        background: ${T.jM};
        border-color: ${_.mb};
    }

    .control:hover,
    .control:${x.N},
    .control:disabled,
    .control:active {
        outline: none;
    }

    :host(:focus-within) .control {
        border-color: ${W.WN};
        box-shadow: 0 0 0 1px ${W.WN} inset;
    }

    :host(.resize-both) .control {
        resize: both;
    }

    :host(.resize-horizontal) .control {
        resize: horizontal;
    }

    :host(.resize-vertical) .control {
        resize: vertical;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        display: block;
        color: ${S.l};
        cursor: pointer;
        $font-size: ${F.K};
        line-height: ${F.Z};
        margin-bottom: 4px;
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${y.Z};
    }
    :host([disabled]) {
        opacity: ${R.q};
    }
`.withBehaviors((0,L.f)("filled",I),(0,m.mr)(b.A`
            :host([disabled]) {
                opacity: 1;
            }
            ::placeholder,
            ::-webkit-input-placeholder {
                color: ${f.A.FieldText};
            }
            :host([disabled]) ::placeholder,
            :host([disabled]) ::-webkit-input-placeholder,
            :host([disabled]) .label {
                color: ${f.A.GrayText};
            }
        `));var U=i(96950),E=i(82774),M=i(60402);const P=U.qy`
        <label
            part="label"
            for="control"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${(0,E.e)("defaultSlottedNodes")}></slot>
        </label>
        <textarea
            part="control"
            class="control"
            id="control"
            ?autofocus="${t=>t.autofocus}"
            cols="${t=>t.cols}"
            ?disabled="${t=>t.disabled}"
            form="${t=>t.form}"
            list="${t=>t.list}"
            maxlength="${t=>t.maxlength}"
            minlength="${t=>t.minlength}"
            name="${t=>t.name}"
            placeholder="${t=>t.placeholder}"
            ?readonly="${t=>t.readOnly}"
            ?required="${t=>t.required}"
            rows="${t=>t.rows}"
            ?spellcheck="${t=>t.spellcheck}"
            :value="${t=>t.value}"
            aria-atomic="${t=>t.ariaAtomic}"
            aria-busy="${t=>t.ariaBusy}"
            aria-controls="${t=>t.ariaControls}"
            aria-current="${t=>t.ariaCurrent}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-details="${t=>t.ariaDetails}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-errormessage="${t=>t.ariaErrormessage}"
            aria-flowto="${t=>t.ariaFlowto}"
            aria-haspopup="${t=>t.ariaHaspopup}"
            aria-hidden="${t=>t.ariaHidden}"
            aria-invalid="${t=>t.ariaInvalid}"
            aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
            aria-label="${t=>t.ariaLabel}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-live="${t=>t.ariaLive}"
            aria-owns="${t=>t.ariaOwns}"
            aria-relevant="${t=>t.ariaRelevant}"
            aria-roledescription="${t=>t.ariaRoledescription}"
            @input="${(t,e)=>t.handleTextInput()}"
            @change="${t=>t.handleChange()}"
            ${(0,M.K)("control")}
        ></textarea>
    `,H=g.compose({name:`${o.c.prefix}-text-area`,template:P,styles:O,shadowOptions:{delegatesFocus:!0}})},90242(t,e,i){i.d(e,{$E(){return c},gf(){return s},i4(){return d},uU(){return l},zh(){return h}});var o=i(51899),n=i(52875),r=i(84754),a=i(27263);function s(t,e){return!(!t||!e)&&(0,o.nS)(t,e)}function l(t,e,i,o){const n=[],r=o||t;if(r&&n.push([r,!0,!1]),e&&!s(r,e)&&n.push([e,!1,!0]),i)for(const t of i)s(r,t)||s(e,t)||n.push([t,!1,!1]);return n}function d(t){let e,i;const o=[];for(const[n,r,a]of t)r?e=n:a?i=n:o.push(n);return{homeLocation:e,detectedLocation:i,followedLocations:o}}function c(t,e,i,l,d){const{home:c,followedLocations:h}=e;return t.map(t=>{const e=t.firstLine||n.getDisplayName(t),u=function(t,e){return!!t&&(null==t?void 0:t.filter(t=>(0,o.nS)(t,e)).length)>0}(h,t),p={id:n.toLatLong(t),interestName:e,interestType:t.secondLine,isFollowed:u},v=s(c,t),g=[];var b,m;v?g.push({type:"icon",image:(0,r.VG)(a.Gm)}):g.push({type:"button",image:(0,r.VG)(a.Gm),label:l.setPrimaryLocation,telemetryTag:null==d||null===(b=d.switchLocation)||void 0===b?void 0:b.getMetadataTag(),onClick(){return null==i?void 0:i.setPrimaryLocationWithToast(t,!0)}});v||u?g.push({type:"icon",image:(0,r.VG)("svg/icons-wc/weather/Checked.svg")}):p.actionButton={type:"button",image:(0,r.VG)("svg/icons-wc/weather/Add.svg"),label:l.intestListFollowNew,telemetryTag:null==d||null===(m=d.addLocation)||void 0===m?void 0:m.getMetadataTag(),onClick(){return null==i?void 0:i.followLocationWithToast(t)}};return{...p,addons:g}})}function h(t,e,i,o){return t.map(t=>{let[s,l,d]=t;const c=[],h={type:"button",image:(0,r.VG)(a.Gm),label:i.setPrimaryLocation,telemetryTag:null==o?void 0:o.switchLocation.getMetadataTag(),onClick(){return null==e?void 0:e.setPrimaryLocationWithToast(s)}};var u;if(l)c.push({type:"icon",image:(0,r.VG)(a.Gm),label:(null===(u=i.superSdCard)||void 0===u?void 0:u.interestListPrimary)||""});else if(d){var p;c.push({type:"icon",image:(0,r.VG)(a.NE),label:null===(p=i.superSdCard)||void 0===p?void 0:p.interestListDetect}),c.push({...h})}else c.push({...h});const v={type:"button",disabled:l||d,image:(0,r.VG)("svg/icons-wc/weather/Reduce.svg"),label:l||d?i.disableRemoveLocationTooltip:i.removeLocationTooltip,telemetryTag:null==o?void 0:o.removeLocation.getMetadataTag(),onClick(){return(null==e?void 0:e.removeFollowedLocation(s))||{}}};return{id:n.toLatLong(s),interestName:n.getDisplayName(s,{skipCountry:!0,skipOldName:!0}),interestType:n.getDisplayName(s,{skipAddressLine:!0,skipLocale:!0,skipOldName:!0}),isFollowed:!1,addons:c,actionButton:v}})}},92869(t,e,i){i.d(e,{M(){return a},e(){return s}});var o=i(77367),n=i(94043);const r={isVisualReady:!1,data:{}};function a(t,e,i){(0,n.S)()&&(r.data[(t+e).toLowerCase()]=i,r.isVisualReady&&s())}function s(){r.isVisualReady=!0;const t=r.data;r.data={},Object.keys(t).length>0&&o.YT.sendLoadTimeEvent({markers:t})}}}]);