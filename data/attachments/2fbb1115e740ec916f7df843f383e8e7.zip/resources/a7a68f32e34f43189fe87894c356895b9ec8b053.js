// © Microsoft Corporation. All rights reserved.
import { ExperienceIds_waterfallViewFeed } from "@msnews/experiences-constants";
import { getNativeAdHelper } from "@msnews/super-feed";
export const startFasterHydrationAds = async (resolver) => {
    if (!window.ssrAdRequest) {
        return;
    }
    const experienceId = ExperienceIds_waterfallViewFeed;
    const feedConfigRef = { experienceType: experienceId, instanceSrc: "default" };
    const feedExperienceConfig = await resolver.getConfig(feedConfigRef);
    const nativeAdHelper = getNativeAdHelper(feedExperienceConfig.properties, experienceId, true);
    nativeAdHelper.fireFastHydrationAuction(window.ssrAdRequest);
};
//# sourceMappingURL=ads.js.map