"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["travel-sd-flights-card"],{95423(r,a,e){e.r(a),e.d(a,{CardScenario(){return i},ToolingInfo(){return Pr},TravelSdCarrentalsCard(){return h},TravelSdCarrentalsCardStyles(){return Lr},TravelSdCarrentalsCardTemplate(){return Tr}});var i,l=e(56911),t=e(60815),n=e(12680),o=e(39671),d=e(33477),c=e(32657),s=e(29709),v=e(69242),u=e(22341),p=e(93552),g=e(17918);!function(r){r.CarRentalList="CarRentalList",r.Error="Error"}(i||(i={}));class h extends o.U{constructor(){super(...arguments),this.extractFeedData=()=>{try{this.mapperArgs&&(this.data=v.ov.parseDestinationDataString(this.mapperArgs.cardMetadata))}catch(r){(0,u.vV)(p.OV,`${n.gIA} - Error in transforming data = ${JSON.stringify(this.mapperArgs)}`,void 0,{...p.OV.pb,userImpacting:!0})}}}connected(){this.experienceConnected()}experienceConnected(){this.extractFeedData()}mapperArgsChanged(r,a){this.extractFeedData()}shadowDomPopulated(){this.markTtvr()}markTtvr(){var r,a;const e=new Image,i=null===(r=this.data)||void 0===r||null===(r=r.V2Data)||void 0===r?void 0:r.Data,l=null==i?void 0:i.Cars;l&&0!=l.length&&(e.src=(0,v.b7)((null==l||null===(a=l[0])||void 0===a||null===(a=a.Image)||void 0===a?void 0:a.ThumbnailId)??"",new Set(["width","height"])),e.onload=r=>{(0,g.pE)("TravelDestination")})}getExperienceType(){return n.gIA}get _cardScenario(){var r,a,e;return(null===(r=this.data)||void 0===r||null===(r=r.V2Data)||void 0===r?void 0:r.DataType)===v.ac.CarRentalList?i.CarRentalList:((0,u.vV)(p.kzh,`${n.gIA} - Unsupported card data type - ${null===(a=this.data)||void 0===a||null===(a=a.V2Data)||void 0===a?void 0:a.DataType}`,JSON.stringify(null===(e=this.mapperArgs)||void 0===e?void 0:e.cardMetadata),{...p.kzh.pb,userImpacting:!0}),i.Error)}get _cardScenarioComponent(){return this._cardScenario,i.CarRentalList,"carrentals-list-card"}get _cardScenarioTelemetry(){return this._cardScenario===i.CarRentalList?this._carRentalsCardListTelemetryTag:""}get isHalfCard(){return this.cardSize==d.uE._1x_1y||this.cardSize==d.uE._05u}get telemetryFields(){var r;return{...null===(r=this.data)||void 0===r?void 0:r.Telemetry}}getTelemetryTag(r){var a;return(0,c.U)(this.telemetryObject,this.telemetryFields,null===(a=this.parentTelemetry)||void 0===a||null===(a=a.contract)||void 0===a?void 0:a.ext,r)}get _rootTelemetry(){return this.getTelemetryTag(s.w.Root)}get _rootCarRentalTelemetry(){return this.getTelemetryTag(s.w.CarRentalBase)}get _travelItemTelemetry(){return this.getTelemetryTag(s.w.Card)}get _carRentalsCardTelemetryTag(){return this.getTelemetryTag(s.w.CarrentalsCard)}get _carRentalsCardListTelemetryTag(){return this.getTelemetryTag(s.w.CarrentalsCardList)}}(0,l.Cg)([t.sH],h.prototype,"data",void 0),(0,l.Cg)([t.sH],h.prototype,"cardSize",void 0),(0,l.Cg)([t.Jg],h.prototype,"telemetryFields",null),(0,l.Cg)([t.Jg],h.prototype,"_rootTelemetry",null),(0,l.Cg)([t.Jg],h.prototype,"_rootCarRentalTelemetry",null),(0,l.Cg)([t.Jg],h.prototype,"_travelItemTelemetry",null),(0,l.Cg)([t.Jg],h.prototype,"_carRentalsCardTelemetryTag",null),(0,l.Cg)([t.Jg],h.prototype,"_carRentalsCardListTelemetryTag",null);var x=e(96950),m=e(69259),b=e(50866),$=e(92011),y=e(31525);let f=class extends $.L{constructor(){super(...arguments),this.renderHeaderIcon=r=>`<img style="width: 16px; height: 16px;" src=${r} alt="flights-header-icon">`}get _isActionMenuAvailable(){return!0}get _actionMenuItems(){var r,a;return{Items:[],strings:{hideCardTitle:(null===(r=this.strings)||void 0===r?void 0:r.hideCardText)??"Hide travel card",moreSettingsTitle:(null===(a=this.strings)||void 0===a?void 0:a.moreSettingsText)??"More settings"},hideCardCallback:this.refreshSDCardSection,moreSettingsPersonalizeCallback:this.goToPersonalizeSettingsCallback}}};(0,l.Cg)([t.sH],f.prototype,"data",void 0),(0,l.Cg)([t.sH],f.prototype,"config",void 0),(0,l.Cg)([t.sH],f.prototype,"strings",void 0),(0,l.Cg)([t.sH],f.prototype,"telemetryObject",void 0),(0,l.Cg)([t.sH],f.prototype,"isHalfCard",void 0),(0,l.Cg)([t.sH],f.prototype,"parentTelemetry",void 0),(0,l.Cg)([t.sH],f.prototype,"refreshSDCardSection",void 0),(0,l.Cg)([t.sH],f.prototype,"goToPersonalizeSettingsCallback",void 0),(0,l.Cg)([t.Jg],f.prototype,"_isActionMenuAvailable",null),(0,l.Cg)([t.Jg],f.prototype,"_actionMenuItems",null),f=(0,l.Cg)([y.x],f);const w={CarrentalCardLink:(0,v.Yz)("CarrentalCardLink"),SeeAllSlide:(0,v.Yz)("SeeAllSlide")},k=Object.freeze({MultipleCarsPerDayPrice:"MultipleCarsPerDayPrice",SingleCarSortedPrice:"SingleCarSortedPrice",LargeCarsImgPrices:"LargeCarsImgPrices",CarAgencyTripleListPrices:"CarAgencyTripleListPrices",MultipleCarsViewDeals:"MultipleCarsViewDeals",CarsTripleListPrices:"CarsTripleListPrices"});let C=class extends f{constructor(){super(...arguments),this._slideIndex=0}get _scenario(){var r,a;return Object.values(k).includes(null===(r=this.data)||void 0===r||null===(r=r.Telemetry)||void 0===r?void 0:r.scenario)?null===(a=this.data)||void 0===a||null===(a=a.Telemetry)||void 0===a?void 0:a.scenario:k.MultipleCarsPerDayPrice}get telemetryFields(){var r;return null===(r=this.data)||void 0===r?void 0:r.Telemetry}get _ext(){var r;return null===(r=this.parentTelemetry)||void 0===r||null===(r=r.contract)||void 0===r?void 0:r.ext}get _updateTelemetryObject(){return(0,c.H)(this.telemetryObject,this.telemetryFields,this._ext)}getTelemetryTag(r,a){return(0,c.U)(this.telemetryObject,this.telemetryFields,this._ext,r,"TravelItem:CarrentalsListCard",a??this._clickUrl)}get isEstimatedPrice(){var r;return"true"==(null===(r=this.data)||void 0===r||null===(r=r.MetaData)||void 0===r||null===(r=r.EstimatedPriceAvailable)||void 0===r?void 0:r.toLowerCase())}get firstCar(){var r;return null===(r=this.data)||void 0===r||null===(r=r.Cars)||void 0===r?void 0:r[0]}get _isLastSlide(){var r;let a=(null===(r=this.data)||void 0===r||null===(r=r.Cars)||void 0===r?void 0:r.length)??0;return a+=1,this._slideIndex===a-1}get _slideAspect(){var r;let a=(null===(r=this.data)||void 0===r||null===(r=r.Cars)||void 0===r?void 0:r.length)??0;this._scenario==k.MultipleCarsPerDayPrice&&(a+=1);return{AnimationTimeInMs:300,Count:a,Width:268,Height:224,Gap:0}}get _superCardData(){var r,a,e,i;const l={CtaButton:{Text:this.cardFooterCtaButtonText(),Link:this._clickUrl}},t=v.V,n={Header:{Text:this.cardHeaderText(),Icon:this.renderHeaderIcon(t),IsActionMenuAvailable:this._isActionMenuAvailable,Link:this._clickUrl,ActionMenuData:this._actionMenuItems},Card:{Link:this._clickUrl,Size:this.isHalfCard?d.uE._1x_1y:d.uE._1x_2y,CardFillColor:this.cardFillColor(),TelemetryObject:this._updateTelemetryObject,FullBleedGradient:undefined,WpoMetadata:this.wpoMetadata,CFOptions:{CFOption1:null===(r=this.strings)||void 0===r?void 0:r.feedbackOption1,CFOption2:null===(a=this.strings)||void 0===a?void 0:a.feedbackOption2}},Slide:this._slideAspect};return this._scenario==k.SingleCarSortedPrice||this._scenario==k.CarAgencyTripleListPrices||this._scenario==k.CarsTripleListPrices?{...n,IsCarousel:!1,Footer:{...l}}:{...n,IsCarousel:!0,Footer:{...l,NextChevron:{Title:(null===(e=this.strings)||void 0===e?void 0:e.nextSlideButtonLabel)??"Next"},PreviousChevron:{Title:(null===(i=this.strings)||void 0===i?void 0:i.prevSlideButtonLabel)??"Previous"},onSlideChange:r=>{this.onSlideChange(r)}}}}onSlideChange(r){this._slideIndex=r}cardTitle(r){var a,e;return this._scenario==k.SingleCarSortedPrice||this._scenario==k.LargeCarsImgPrices||this._scenario==k.CarAgencyTripleListPrices||this._scenario==k.CarsTripleListPrices||this._scenario==k.MultipleCarsViewDeals?(null===(e=this.strings)||void 0===e||null===(e=e.rentcar)||void 0===e?void 0:e.replace("{0}",(null==r?void 0:r.City)??""))??"":(null===(a=this.strings)||void 0===a||null===(a=a.rentcartype)||void 0===a?void 0:a.replace("{1}",(null==r?void 0:r.City)??"").replace("{0}",this.carCategoryToString(r)))??""}carSimilarText(r){var a;return(null===(a=this.strings)||void 0===a||null===(a=a.carSimilar)||void 0===a?void 0:a.replace("{0}",null==r?void 0:r.Name))??""}cardFillColor(){return this._scenario==k.LargeCarsImgPrices||this._scenario==k.CarAgencyTripleListPrices||this._scenario==k.CarsTripleListPrices||this._scenario==k.MultipleCarsViewDeals?{DarkThemeColor:"#00000",LightThemeColor:"#FFFFF"}:{DarkThemeColor:b.NZ.DarkPlum,LightThemeColor:b.L9.LightBlue}}cardHeaderText(){var r;return(null===(r=this.strings)||void 0===r?void 0:r.carrentals)??""}cardFooterCtaButtonText(){var r;return(null===(r=this.strings)||void 0===r?void 0:r.seeAllOpt)??""}get _clickUrl(){var r;return this._scenario==k.SingleCarSortedPrice?this.getClickUrl(this.firstCar):(null===(r=this.data)||void 0===r?void 0:r.SeeAllUrl)??""}_carImageUrl(r){var a,e;return this._scenario==k.LargeCarsImgPrices||this._scenario==k.MultipleCarsViewDeals?(0,v.b7)((null==r||null===(e=r.Image)||void 0===e?void 0:e.ThumbnailId)??"",new Set(["width","height"])):(null==r||null===(a=r.Image)||void 0===a?void 0:a.ThumbnailId)??""}getTop3CarInfo(){const r=[];for(let e=0;e<3;e++){var a;r.push(null===(a=this.data)||void 0===a||null===(a=a.Cars)||void 0===a?void 0:a[e])}return r}isTagAvailable(r){return!1}getTag(r){var a,e;return"true"==(null==r||null===(a=r.MetaData)||void 0===a?void 0:a.RecommendedCar.toLowerCase())?(null===(e=this.strings)||void 0===e?void 0:e.recom)??"":""}getClickUrl(r){return(null==r?void 0:r.ClickUrl)??""}getSeeAllUrl(){var r;return(null===(r=this.data)||void 0===r?void 0:r.SeeAllUrl)??""}getTransmissionType(r){var a,e;return(null==r?void 0:r.Transmission)==v.hW.Manual?(null===(a=this.strings)||void 0===a?void 0:a.mancar)??"":(null===(e=this.strings)||void 0===e?void 0:e.autocar)??""}getPerDayString(r){var a;const e=null==r?void 0:r.DropDateTime;if(e){var i;const a=(0,v.kt)(null==r?void 0:r.PickupDateTime,e);var l;return this.isHalfCard||this._scenario==k.LargeCarsImgPrices||this._scenario==k.CarAgencyTripleListPrices?a.toString()+" "+((null===(l=this.strings)||void 0===l?void 0:l.days)??""):(null===(i=this.strings)||void 0===i||null===(i=i.fordays)||void 0===i?void 0:i.replace("{0}",a.toString()))??""}var t;return this._scenario==k.LargeCarsImgPrices?(null===(t=this.strings)||void 0===t?void 0:t.day)??"":(null===(a=this.strings)||void 0===a?void 0:a.perday)??""}_carAgencyImageUrl(r){var a,e;return null!=r&&null!==(a=r.AgencyLogo)&&void 0!==a&&null!==(a=a.ThumbnailId)&&void 0!==a&&a.includes("opaquecar")?"":(null==r||null===(e=r.AgencyLogo)||void 0===e?void 0:e.ThumbnailId)??""}carCategoryToString(r){var a,e,i,l,t,n,o,d,c;switch(null==r?void 0:r.Type){case v.hO.Economy:return(null===(a=this.strings)||void 0===a?void 0:a.economy)??"";case v.hO.Intermediate:return(null===(e=this.strings)||void 0===e?void 0:e.intermediate)??"";case v.hO.FullSize:return(null===(i=this.strings)||void 0===i?void 0:i.fullsize)??"";case v.hO.SUV:return(null===(l=this.strings)||void 0===l?void 0:l.suv)??"";case v.hO.PickupTruck:return(null===(t=this.strings)||void 0===t?void 0:t.pickupTruck)??"";case v.hO.Luxury:return(null===(n=this.strings)||void 0===n?void 0:n.luxury)??"";case v.hO.Coupe:return(null===(o=this.strings)||void 0===o?void 0:o.coupe)??"";case v.hO.Van:return(null===(d=this.strings)||void 0===d?void 0:d.van)??"";case v.hO.Convertible:return(null===(c=this.strings)||void 0===c?void 0:c.convertible)??"";case v.hO.UNKNOWN:default:return""}}get _carRentalScenarioTelemetryTag(){return this.getTelemetryTag((0,v.Yz)(this._scenario))}get _carRentalsCardLinkTelemetryTag(){return this.getTelemetryTag(w.CarrentalCardLink,this._clickUrl)}get _seeAllSlideTelemetryTag(){return this.getTelemetryTag(w.SeeAllSlide)}};(0,l.Cg)([t.sH],C.prototype,"_slideIndex",void 0),(0,l.Cg)([t.Jg],C.prototype,"telemetryFields",null),(0,l.Cg)([t.Jg],C.prototype,"_ext",null),(0,l.Cg)([t.Jg],C.prototype,"_updateTelemetryObject",null),(0,l.Cg)([t.Jg],C.prototype,"_isLastSlide",null),(0,l.Cg)([t.Jg],C.prototype,"_slideAspect",null),(0,l.Cg)([t.Jg],C.prototype,"_superCardData",null),C=(0,l.Cg)([y.x],C);var T=e(74849),_=e(12640);const S="\n        display: flex;\n        flex-direction: row;\n    ",z="\n        display: flex;\n        flex-direction: column;\n    ",F="\n        justify-content: center;\n        align-items: center;\n    ",D="\n        font-size: 10px;\n        line-height: 14px;\n        font-weight: 400;\n    ",I="\n        font-size: 12px;\n        line-height: 16px;\n    ",L="\n        font-size: 12px;\n        line-height: 16px;\n        font-weight: 400;\n    ",P="\n        font-weight: 600;\n        font-size: 14px;\n        line-height: 20px;\n    ",A="\n        font-size: 16px;\n        line-height: 22px;\n        font-weight: 600;\n    ",M="\n        font-size: 16px;\n        line-height: 22px;\n        font-weight: 700;\n    ",O="\n        font-size: 20px;\n        line-height: 28px;\n        font-weight: 400;\n    ",j="\n        font-size: 20px;\n        line-height: 28px;\n        font-weight: 600;\n    ",R="\n        font-size: 24px;\n        line-height: 32px;\n        font-weight: 600;\n    ",E=r=>`\n            overflow: hidden;\n            display: -webkit-box;\n            -webkit-box-orient: vertical;\n            -webkit-line-clamp: ${r};\n        `,H=T.A` .card-container{--mcpdp-car-card-background:rgba(255,255,255,0.13);--mcpdp-car-pill-background:rgba(40,134,222,1);--mcpdp-car-pill-font-color:rgba(255,255,255,1);--mcpdp-car-platform-backgroud:rgba(255,255,255,0.1);--mcpdp-see-all-background:rgba(17,94,163,1);--mcpdp-see-all-font-color:rgba(255,255,255,1);--mcpdp-secondary-font-color:#D4D8EE;--mcpdp-icon-color:invert(87%) sepia(22%) saturate(200%) hue-rotate(195deg) brightness(97%) contrast(92%);--mcpdp-border-color:rgba(255,255,255,0.2)}`,U=T.A` .card-container{--mcpdp-car-card-background:rgba(255,255,255,0.46);--mcpdp-car-pill-background:rgba(12,59,94,1);--mcpdp-car-pill-font-color:rgba(255,255,255,1);--mcpdp-car-platform-backgroud:rgba(255,255,255,0.4);--mcpdp-see-all-background:rgba(33,105,235,1);--mcpdp-see-all-font-color:rgba(255,255,255,1);--mcpdp-secondary-font-color:#767676;--mcpdp-icon-color:invert(50%) sepia(0%) saturate(1736%) hue-rotate(144deg) brightness(91%) contrast(82%);--mcpdp-border-color:rgba(0,0,0,0.05)}.rent-city{margin-bottom:46px;${R} text-align:center;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis}.rent-city.v2{margin-bottom:16px}.rent-city:hover{text-decoration:underline}.expl-city{${O} margin-bottom:31px}.expl-city:hover{text-decoration:underline}.car-platform-images{${S} justify-content:space-evenly;align-items:center;width:100%;position:absolute;top:-24px}.car-platform-image{height:52px;transform:scaleX(-1)}.car-summary{${z}
        gap: 9px;
        background: var(--mcpdp-car-card-background);
        border-radius: 8px;
        box-sizing: border-box;
        position: relative;
        margin-top: 8px;
        margin: auto;
        padding: 8px 11px 8px 12px;
        max-width: max-content;
    }
    .car-price-row{
        ${S}
        gap: 20px;
    }
    
    .car-image{
        height: 90px;
        transform: scaleX(-1);
        position: absolute;
        top: -35px;
        left: 0px;
        right: 0px;
        margin-left: auto;
        margin-right: auto;
    }
    
    .car-image-v2{
        display: block;
        height: 90px;
        transform: scaleX(-1);
        margin:auto;
    }

    .car-agency-image{
        display: flex;
        width: 100%;
        height: 100%;
    }
    .car-agency{
        background: rgba(245, 245, 245, 1);
        border-radius: 4px;
        border: 1.29px solid rgba(221, 221, 221, 1);
        padding: 2px 4px 2px 4px;
        max-height: 22px;
        box-sizing: border-box;
        max-width: 43px;
        align-self: flex-end;
    }
    
    .car-price{
        ${S}
        gap: 8px;
        align-items: baseline;
    }
    .car-price-from{
        ${M}
    }
    
    .car-price-perday{
        color: var(--mcpdp-secondary-font-color);
        ${L}
    }
    .estimated{
        color: var(--mcpdp-secondary-font-color);
        ${I}}.breakline{border:1px solid var(--mcpdp-border-color);margin-top:45px}.see-all{display:flex;flex-direction:column;${F}
        position: relative;
    }
    .car-platform{
        display: flex;
        height: 82px;
        flex-direction: column-reverse;
        background: var(--mcpdp-car-platform-backgroud);
        border-radius: 8px;
        width: 100%;
        position: relative;
    }
    .see-all-btn{
        display: flex;
        ${F}
        ${A}
        padding: 5px 0px 7px 0px;
        background: var(--mcpdp-see-all-background);
        color: var(--mcpdp-see-all-font-color);
        border-radius: 4px;
        width: -webkit-fill-available;
        height: 32px;
        box-sizing: border-box;
    }

`.withBehaviors(new _.N(null,H)),X=T.A` .card-container{--car-card-background:rgba(255,255,255,0.13);--car-pill-background:rgba(40,134,222,1);--car-pill-font-color:rgba(255,255,255,1);--car-platform-backgroud:rgba(255,255,255,0.1);--see-all-background:rgba(17,94,163,1);--see-all-font-color:rgba(255,255,255,1);--secondary-font-color:#D4D8EE;--icon-color:invert(87%) sepia(22%) saturate(200%) hue-rotate(195deg) brightness(97%) contrast(92%);--border-color:rgba(255,255,255,0.2)}`,N=T.A` .card-container{--car-card-background:rgba(255,255,255,0.46);--car-pill-background:rgba(12,59,94,1);--car-pill-font-color:rgba(255,255,255,1);--car-platform-backgroud:rgba(255,255,255,0.4);--see-all-background:rgba(33,105,235,1);--see-all-font-color:rgba(255,255,255,1);--secondary-font-color:#767676;--icon-color:invert(50%) sepia(0%) saturate(1736%) hue-rotate(144deg) brightness(91%) contrast(82%);--border-color:rgba(0,0,0,0.05)}.rent-city{margin-bottom:62px;${R} text-align:center;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis}.car-platform-images{${S} justify-content:space-evenly;align-items:center;width:100%;position:absolute;top:-24px}.car-platform-image{height:52px;transform:scaleX(-1)}.car-summary{${z}
        gap: 9px;
        background: var(--car-card-background);
        border-radius: 8px;
        box-sizing: border-box;
        position: relative;
        margin-top: 8px;
        margin: auto;
        padding: 8px 11px 8px 12px;
        max-width: max-content;
    }
    .car-price-row{
        ${S}
        gap: 20px;
    }
    
    .car-image{
        height: 130px;
        transform: scaleX(-1);
        position: absolute;
        top: -70px;
        left: 0px;
        right: 0px;
        margin-left: auto;
        margin-right: auto;
    }
    .car-agency-image{
        object-fit: cover;
        width: 100%;
        height: 100%;
    }
    .car-agency{
        background: rgba(245, 245, 245, 1);
        border-radius: 4px;
        border: 1.29px solid rgba(221, 221, 221, 1);
        padding: 2px 5px 2px 5px;
        max-height: 22px;
        box-sizing: border-box;
        max-width: 43px;
        align-self: flex-end;
    }
    
    .car-price{
        ${S}
        gap: 8px;
        align-items: baseline;
    }
    .car-price-from{
        ${M}
    }
    
    .car-price-perday{
        color: var(--secondary-font-color);
        ${L}
    }
    .estimated{
        color: var(--secondary-font-color);
        ${I}
    }
    .breakline{
        border: 1px solid var(--border-color);
        margin-top: 45px;
    }
    .car-platform{
        display: flex;
        height: 82px;
        flex-direction: column-reverse;
        background: var(--car-platform-backgroud);
        border-radius: 8px;
        width: 100%;
        position: relative;
    }

`.withBehaviors(new _.N(null,X)),B=T.A` .card-container{--car-price-pill-font-color:black;--car-price-pill-color:rgba(159,216,159,1)}`,G=T.A` .card-container{--car-price-pill-font-color:white;--car-price-pill-color:rgba(16,124,16,1)}.rent-city{${R}
        ${E(1)}}.rent-city-wrapper:hover{text-decoration:underline}.rent-city-wrapper{position:relative}.car-image{display:block;width:237px;height:158px;margin-left:auto;margin-right:auto}.car-agency-image{display:flex;width:100%;height:100%}.car-agency{position:absolute;left:0px;background:rgba(245,245,245,1);border-radius:6px;border:1.29px solid rgba(221,221,221,1);padding:2px 4px 2px 4px;max-height:27px;box-sizing:border-box;max-width:54px;align-self:flex-end}.car-similar-text{margin-bottom:8px;${E(1)}
    }
    
    .car-price{
        position: absolute;
        right: 5px;
        padding: 6px 6px 6px 8px;
        border-radius: 4px;
        ${z}
        align-items: center;
        width: fit-content;
        background-color: var(--car-price-pill-color);
        color: var(--car-price-pill-font-color);
    }
    .car-price-starting{
        ${D}}.car-price-perday{${D}
    }
    .car-price-currency{
        ${R}
    }

`.withBehaviors(new _.N(null,B)),J=T.A` .card-container{--car-agency-background:rgba(31,31,31,1);--car-agency-text-color:rgba(173,173,173,1)}`,V=T.A` .card-container{--car-agency-background:rgba(245,245,245,1);--car-agency-text-color:rgba(97,97,97,1)}.rent-city{${j}
        ${E(1)} margin-bottom:8px}.rent-city:hover{text-decoration:underline}.car-image{height:158px;margin-left:auto;margin-right:auto}.car-agency-image{display:flex;width:100%;height:100%}.car-agency{background:rgba(255,255,255,1);border-radius:6px;padding:2px 4px 2px 4px;max-height:40px;box-sizing:border-box;max-width:60px}.car-agency-wrapper{${S} gap:8px;height:57px;background-color:var(--car-agency-background);align-items:center;margin-bottom:8px;padding:8px;box-sizing:border-box;border-radius:6px}.car-chevron{width:13px;height:24px}.car-similar-text{margin-bottom:8px;${E(1)}
    }
    .car-price-starting{
        ${L} color:var(--car-agency-text-color);margin-inline-end:4px}.car-price-perday{${L} color:var(--car-agency-text-color);margin-inline-end:4px}.estimated{${L}
        color: var(--car-agency-text-color);
    }
    .car-price-currency{
        ${j}}.car-price-currency-wrapper{${E(1)}
    }

`.withBehaviors(new _.N(null,J)),W=T.A` .card-container{--car-box-background:rgba(31,31,31,1);--car-box-text-color:rgba(173,173,173,1)}`,q=T.A` .card-container{--car-box-background:rgba(245,245,245,1);--car-box-text-color:rgba(97,97,97,1)}.rent-city{${j}
        ${E(1)} margin-bottom:8px}.rent-city:hover{text-decoration:underline}.car-image{width:74px;height:50px}.car-wrapper{${S} gap:8px;align-items:baseline;height:57px;background-color:var(--car-box-background);align-items:center;margin-bottom:8px;padding:8px;box-sizing:border-box;border-radius:6px}.car-chevron{width:13px;height:24px}.car-similar-text{margin-bottom:8px;${E(1)}
    }
    .car-price-starting{
        ${D} color:var(--car-box-text-color);margin-inline-end:4px}.car-price-perday{${D} color:var(--car-box-text-color);margin-inline-end:4px}.estimated{${D}
        color: var(--car-box-text-color);
    }
    .car-price-currency{
        ${P}
    }
    .car-type{
        ${P}}.car-details-wrapper{${z} align-items:baseline;flex-grow:1}.car-price-wrapper{${E(1)}
        height: 20px;
    }

`.withBehaviors(new _.N(null,W)),K=T.A` .card-container{--car-secondary-text-color:rgba(173,173,173,1);--car-deals-button-color:rgba(17,94,163,1)}`,Q=T.A` .card-container{--car-secondary-text-color:rgba(97,97,97,1);--car-deals-button-color:rgba(15,108,189,1)}.rent-city{${R}
        ${E(1)} margin-bottom:8px}.rent-city:hover{text-decoration:underline}.rent-city-wrapper{position:relative}.car-image{display:block;width:217px;height:134px;margin-left:auto;margin-right:auto}.car-agency-image{display:flex;width:100%;height:100%}.car-agency{position:absolute;left:0px;background:rgba(245,245,245,1);border-radius:6px;border:1.29px solid rgba(221,221,221,1);padding:2px 4px 2px 4px;max-height:27px;box-sizing:border-box;max-width:54px;align-self:flex-end}.car-similar-text{color:var(--car-secondary-text-color);${E(1)}}.car-view-deals{${P} width:92px;height:32px;border-radius:4px;background-color:var(--car-deals-button-color);color:white;border:none}.car-view-deals-text{${E(1)}
    }
    .car-price{
        ${L}
        ${E(1)}}.car-details-wrapper{${S} gap:34px}.car-price-wrapper{width:150px;${z}}.car-price-from{${A} margin-inline-end:4px}.car-price-perday{${L} color:var(--car-secondary-text-color)}.estimated{${L}
    }

`.withBehaviors(new _.N(null,K)),Y=T.A` a{text-decoration:none;color:inherit}.card-container{display:block;width:300px}${r=>{switch(r._scenario){case k.MultipleCarsPerDayPrice:null==r||r.$fastController.addStyles(U);break;case k.SingleCarSortedPrice:null==r||r.$fastController.addStyles(N);break;case k.LargeCarsImgPrices:null==r||r.$fastController.addStyles(G);break;case k.CarAgencyTripleListPrices:null==r||r.$fastController.addStyles(V);break;case k.CarsTripleListPrices:null==r||r.$fastController.addStyles(q);break;case k.MultipleCarsViewDeals:null==r||r.$fastController.addStyles(Q);break;default:null==r||r.$fastController.addStyles(U)}}}
`;var Z=e(39957);const rr=x.qy`<a class="see-all" data-t=${r=>null==r?void 0:r._seeAllSlideTelemetryTag} href="${r=>null==r?void 0:r.getSeeAllUrl()}" target="_blank" aria-live="polite"><div class="expl-city">${r=>{var a;return(null==r||null===(a=r.strings)||void 0===a?void 0:a.explchoose3)??""}}</div><div class="car-platform"><div class="car-platform-images">${(0,Z.ux)(r=>(null==r?void 0:r.getTop3CarInfo())??[],x.qy`<img class="car-platform-image" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carImageUrl(r)}}" alt="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.carCategoryToString(r)}}"/>`)}</div><div class="see-all-btn"><span>${r=>{var a;return(null==r||null===(a=r.strings)||void 0===a?void 0:a.explall)??""}}</span></div></div></a>`,ar=x.qy`<a href="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getClickUrl(r)}}" target="_blank" data-t=${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carRentalsCardLinkTelemetryTag}} aria-live="polite" title="${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e?void 0:e.carCategoryToString(r))??""}}">${(0,m.z)((r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e||null===(e=e.config)||void 0===e?void 0:e.enableMcpdV2},x.qy`<img class="car-image-v2" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carImageUrl(r)}}" alt=${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e?void 0:e.carCategoryToString(r))??""}} />`)}<div class="rent-city ${(r,a)=>{var e;return null!=a&&null!==(e=a.parent)&&void 0!==e&&null!==(e=e.config)&&void 0!==e&&e.enableMcpdV2?"v2":""}}">${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.cardTitle(r)}}</div><div class="car-summary">${(0,m.z)((r,a)=>{var e;return!(null!=a&&null!==(e=a.parent)&&void 0!==e&&null!==(e=e.config)&&void 0!==e&&e.enableMcpdV2)},x.qy`<img class="car-image" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carImageUrl(r)}}" alt=${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e?void 0:e.carCategoryToString(r))??""}} /><div class="breakline"></div>`)}<div class="car-price-row"><div class="car-price"><span class="car-price-from">${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e||null===(e=e.strings)||void 0===e||null===(e=e.fromcost)||void 0===e?void 0:e.replace("{0}",(0,v.TI)(r.Price)))??""}} ${(0,m.z)((r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.isEstimatedPrice},x.qy`<span class="estimated">est.</span>`)}</span><span class="car-price-perday">${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getPerDayString(r)}}</span></div>${(0,m.z)((r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carAgencyImageUrl(r)},x.qy`<div class="car-agency"><img class="car-agency-image" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carAgencyImageUrl(r)}}" /></div>`)}</div></div></a>`,er=x.qy` ${(0,Z.ux)((r,a)=>{var e;return(null===(e=r.data)||void 0===e?void 0:e.Cars)??[]},x.qy` ${ar} `)} ${rr}
`,ir=x.qy`
${er}
`,lr=x.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var a;return null===(a=r.config)||void 0===a?void 0:a.useFeeds3Design}}">${ir}</msn-travel-sd-card>`,tr=x.qy`<a href="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getClickUrl(r)}}" target="_blank" data-t=${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carRentalsCardLinkTelemetryTag}} aria-live="polite" title="${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e?void 0:e.carCategoryToString(r))??""}}"><div class="rent-city-wrapper"><div class="car-similar-text">${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.carSimilarText(r)}}</div><div class="car-price"><span class="car-price-starting">${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e||null===(e=e.strings)||void 0===e?void 0:e.startingFrom)??""}}</span><div class="car-price-currency-wrapper"><span class="car-price-currency">${(r,a)=>(0,v.TI)(r.Price)}</span><span class="car-price-perday">/ ${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getPerDayString(r)}}</span></div></div>${(0,m.z)((r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carAgencyImageUrl(r)},x.qy`<div class="car-agency"><img class="car-agency-image" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carAgencyImageUrl(r)}}" /></div>`)}</div><img class="car-image" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carImageUrl(r)}}" alt=${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e?void 0:e.carCategoryToString(r))??""}} /></a>`,nr=x.qy` ${(0,Z.ux)((r,a)=>{var e;return(null===(e=r.data)||void 0===e?void 0:e.Cars)??[]},x.qy` ${tr} `)}
`,or=x.qy`<div slot="static-content"><a class="car-static" href="${r=>null==r?void 0:r.getSeeAllUrl()}" target="_blank" aria-live="polite" data-t=${r=>r._carRentalsCardLinkTelemetryTag}><div class="rent-city">${r=>null==r?void 0:r.cardTitle(null==r?void 0:r.firstCar)}</div></a></div>${nr}
`,dr=x.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var a;return null===(a=r.config)||void 0===a?void 0:a.useFeeds3Design}}">${or}</msn-travel-sd-card>`,cr=x.qy`<a href="${r=>null==r?void 0:r.getClickUrl(null==r?void 0:r.firstCar)}" target="_blank" data-t=${r=>null==r?void 0:r._carRentalsCardLinkTelemetryTag} aria-live="polite" title="${r=>{var a;return(null==r||null===(a=r.firstCar)||void 0===a?void 0:a.Name)??""}}"><div class="rent-city">${r=>null==r?void 0:r.cardTitle(null==r?void 0:r.firstCar)}</div><div class="car-summary"><img class="car-image" src="${r=>null==r?void 0:r._carImageUrl(null==r?void 0:r.firstCar)}" alt=${r=>{var a;return(null==r||null===(a=r.firstCar)||void 0===a?void 0:a.Name)??""}} /><div class="breakline"></div><div class="car-price-row"><div class="car-price"><span class="car-price-from">${r=>{var a,e;return(null==r||null===(a=r.strings)||void 0===a||null===(a=a.fromcost)||void 0===a?void 0:a.replace("{0}",(0,v.TI)(null==r||null===(e=r.firstCar)||void 0===e?void 0:e.Price)))??""}} ${(0,m.z)(r=>null==r?void 0:r.isEstimatedPrice,x.qy`<span class="estimated">est.</span>`)}</span><span class="car-price-perday">${r=>null==r?void 0:r.getPerDayString(null==r?void 0:r.firstCar)}</span></div>${(0,m.z)(r=>null==r?void 0:r._carAgencyImageUrl(null==r?void 0:r.firstCar),x.qy`<div class="car-agency"><img class="car-agency-image" src="${r=>null==r?void 0:r._carAgencyImageUrl(null==r?void 0:r.firstCar)}" /></div>`)}</div></div></a>`,sr=x.qy`
${cr}
`,vr=x.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var a;return null===(a=r.config)||void 0===a?void 0:a.useFeeds3Design}}">${sr}</msn-travel-sd-card>`;var ur=e(52356);const pr=x.qy`<a href="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getClickUrl(r)}}" class="car-agency-wrapper" target="_blank" aria-live="polite"><div class="car-agency"><img class="car-agency-image" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carAgencyImageUrl(r)}}" /></div><div class="car-price-currency-wrapper"><span class="car-price-starting">${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e||null===(e=e.strings)||void 0===e?void 0:e.startingFrom)??""}}</span><span class="car-price-wrapper"><span class="car-price-currency">${(r,a)=>(0,v.TI)(r.Price)}</span><span class="car-price-perday">/${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getPerDayString(r)}}</span>${(0,m.z)((r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.isEstimatedPrice},x.qy`<span class="estimated">est.</span>`)}</span></div><span class="car-chevron" style="background: url(${ur.y.appInDarkMode()?v.H1:v.c_}) no-repeat center"></span></a>`,gr=x.qy`<a href="${r=>null==r?void 0:r._clickUrl}" target="_blank" data-t=${r=>null==r?void 0:r._carRentalsCardLinkTelemetryTag} aria-live="polite"><div class="rent-city">${r=>r.cardTitle(r.firstCar)}</div>${(0,Z.ux)(r=>{var a;return(null===(a=r.data)||void 0===a||null===(a=a.Cars)||void 0===a?void 0:a.slice(0,3))??[]},x.qy` ${pr} `)}</a>`,hr=x.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var a;return null===(a=r.config)||void 0===a?void 0:a.useFeeds3Design}}">${gr}</msn-travel-sd-card>`,xr=x.qy`<a href="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getClickUrl(r)}}" class="car-wrapper" target="_blank" aria-live="polite"><div class="car"><img class="car-image" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carImageUrl(r)}}" /></div><div class="car-details-wrapper"><span class="car-type">${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.carCategoryToString(r)}}</span><div class="car-price-wrapper"><span class="car-price-starting">${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e||null===(e=e.strings)||void 0===e?void 0:e.startingFrom)??""}}</span><span class="car-price-currency">${(r,a)=>(0,v.TI)(r.Price)}</span><span class="car-price-perday">/${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getPerDayString(r)}}</span>${(0,m.z)((r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.isEstimatedPrice},x.qy`<span class="estimated">est.</span>`)}</div></div><span class="car-chevron" style="background: url(${ur.y.appInDarkMode()?v.H1:v.c_}) no-repeat center"></span></a>`,mr=x.qy`<a href="${r=>null==r?void 0:r._clickUrl}" target="_blank" data-t=${r=>null==r?void 0:r._carRentalsCardLinkTelemetryTag} aria-live="polite"><div class="rent-city">${r=>r.cardTitle(r.firstCar)}</div>${(0,Z.ux)(r=>{var a;return(null===(a=r.data)||void 0===a||null===(a=a.Cars)||void 0===a?void 0:a.slice(0,3))??[]},x.qy` ${xr} `)}</a>`,br=x.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var a;return null===(a=r.config)||void 0===a?void 0:a.useFeeds3Design}}">${mr}</msn-travel-sd-card>`,$r=x.qy`<a href="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getClickUrl(r)}}" target="_blank" data-t=${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carRentalsCardLinkTelemetryTag}} aria-live="polite" title="${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e?void 0:e.carCategoryToString(r))??""}}"><div class="rent-city-wrapper">${(0,m.z)((r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carAgencyImageUrl(r)},x.qy`<div class="car-agency"><img class="car-agency-image" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carAgencyImageUrl(r)}}" /></div>`)}</div><img class="car-image" src="${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e._carImageUrl(r)}}" alt=${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e?void 0:e.carCategoryToString(r))??""}} /><div class="car-details-wrapper"><div class="car-price-wrapper"><div class="car-price"><span class="car-price-from">${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e||null===(e=e.strings)||void 0===e||null===(e=e.fromcost)||void 0===e?void 0:e.replace("{0}",(0,v.TI)(r.Price)))??""}}</span><span class="car-price-perday">${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.getPerDayString(r)}}</span>${(0,m.z)((r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.isEstimatedPrice},x.qy`<span class="estimated">est.</span>`)}</div><div class="car-similar-text">${(r,a)=>{var e;return null==a||null===(e=a.parent)||void 0===e?void 0:e.carSimilarText(r)}}</div></div><button class="car-view-deals"><span class="car-view-deals-text">${(r,a)=>{var e;return(null==a||null===(e=a.parent)||void 0===e||null===(e=e.strings)||void 0===e?void 0:e.viewDeals)??""}}</span></button></div></a>`,yr=x.qy` ${(0,Z.ux)((r,a)=>{var e;return(null===(e=r.data)||void 0===e?void 0:e.Cars)??[]},x.qy` ${$r} `)}
`,fr=x.qy`<div slot="static-content"><a class="car-static" href="${r=>null==r?void 0:r.getSeeAllUrl()}" target="_blank" aria-live="polite" data-t=${r=>r._carRentalsCardLinkTelemetryTag}><div class="rent-city">${r=>null==r?void 0:r.cardTitle(null==r?void 0:r.firstCar)}</div></a></div>${yr}
`,wr=x.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var a;return null===(a=r.config)||void 0===a?void 0:a.useFeeds3Design}}">${fr}</msn-travel-sd-card>`,kr=x.qy`<div class="card-container ${r=>{var a;return null!==(a=r.config)&&void 0!==a&&a.useFeeds3Design?"feeds3":""}}" data-t=${r=>r._carRentalScenarioTelemetryTag}>${r=>{switch(r._scenario){case k.MultipleCarsPerDayPrice:return lr;case k.SingleCarSortedPrice:return vr;case k.LargeCarsImgPrices:return dr;case k.CarAgencyTripleListPrices:return hr;case k.CarsTripleListPrices:return br;case k.MultipleCarsViewDeals:return wr;default:return lr}}}</div>`;let Cr=class extends C{};Cr=(0,l.Cg)([(0,$.E)({name:"carrentals-list-card",template:kr,styles:Y,shadowOptions:{delegatesFocus:!0}})],Cr),e(93752).cF;const Tr=x.qy`<div class="travel-container ${r=>r.config.useFeeds3Design?"feeds3":""}"  style="${r=>r.config.travelContainerStyles}" data-t="${r=>r._rootTelemetry}"><div class="travel-telemetry" data-t="${r=>r._travelItemTelemetry}"><div class="carrentals-card" id="travel-destination-card" data-t="${r=>r._rootCarRentalTelemetry}">${(0,m.z)(r=>r._cardScenarioComponent,x.qy`${r=>(r=>{const a=r._cardScenarioComponent,e=x.qy.partial(a);return x.qy`<${e} class="travel-card" data-t=${r=>r._cardScenarioTelemetry} :data=${r=>{var a;return null===(a=r.data)||void 0===a||null===(a=a.V2Data)||void 0===a?void 0:a.Data}} :config=${r=>r.config} :strings=${r=>r.strings} :isHalfCard=${r=>r.isHalfCard} :parentTelemetry=${r=>r.parentTelemetry} :telemetryObject=${r=>r.telemetryObject} :wpoMetadata=${r=>r.wpoMetadata} :refreshSDCardSection=${r=>null==r?void 0:r.refreshSDCardSection} :goToPersonalizeSettingsCallback=${r=>null==r?void 0:r.goToPersonalizeSettingsCallback}></${e}>`})(r)}`)}</div></div></div>`;var _r=e(7896),Sr=e(64003),zr=e(86856);const Fr=T.A` .container{background:linear-gradient(323.98deg,#341F23 10.67%,#2F1C20 100%)}.body{background:rgba(255,255,255,0.07);border-radius:4px}`,Dr=T.A`
`,Ir=T.A`
`,Lr=T.A`
:host{width:auto;height:100%;box-sizing:border-box;font-family:${_r.O};
    outline: none;
    font-size: 12px;
    line-height: 16px;
    color: ${Sr.c}}a{text-decoration:none;color:inherit}.travel-container{position:relative}.travel-card{display:block;width:300px;border-radius:8px;box-sizing:border-box}.feeds3,.feeds3 .travel-destination-card,.feeds3 .travel-telemetry,.feeds3 .travel-card{height:100%}`.withBehaviors(new _.N(null,Fr),new zr.t(Dr,Ir)),Pr={experienceConfigSchema:undefined}}}]);