"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_super-container_dist_register_CsGemModule_js"],{4912(t,i,e){e.d(i,{v(){return a}});var o=e(96950),r=e(69259),n=e(60402),s=e(87656);const a=function(t){const i=o.qy.partial((0,s.g)(t.anchoredRegion));return o.qy`
        ${(0,r.z)(t=>t.tooltipVisible,o.qy`
            <${i}
                fixed-placement="true"
                auto-update-mode="${t=>t.autoUpdateMode}"
                vertical-positioning-mode="${t=>t.verticalPositioningMode}"
                vertical-default-position="${t=>t.verticalDefaultPosition}"
                vertical-inset="${t=>t.verticalInset}"
                vertical-scaling="${t=>t.verticalScaling}"
                horizontal-positioning-mode="${t=>t.horizontalPositioningMode}"
                horizontal-default-position="${t=>t.horizontalDefaultPosition}"
                horizontal-scaling="${t=>t.horizontalScaling}"
                horizontal-inset="${t=>t.horizontalInset}"
                vertical-viewport-lock="${t=>t.horizontalViewportLock}"
                horizontal-viewport-lock="${t=>t.verticalViewportLock}"
                dir="${t=>t.currentDirection}"
                ${(0,n.K)("region")}
            >
                <div class="tooltip" part="tooltip" role="tooltip">
                    <slot></slot>
                </div>
            </${i}>
        `)}
    `}({anchoredRegion:e(7927).m})},6791(t,i,e){e.d(i,{f(){return r}});var o=e(50645);class r{constructor(){this.config={},this.strings={},this.initialized=!1}async initConfig(t){var i,e;this.initialized||(this.config=await this.getConfigFromRef(t)||{},this.strings=(null===(i=this.config)||void 0===i?void 0:i.localizedStrings)||{},this.initialized=!!this.config&&!(null===(e=this.config)||void 0===e||!e.localizedStrings))}getConfig(){return this.config}getLocStrings(){return this.strings}async getConfigFromRef(t){try{const i=(null==t?void 0:t.configRef)||this.configRef,e=await o.L.getConfig(i);return null==e?void 0:e.properties}catch(t){return{}}}}},10809(t,i,e){e.d(i,{D(){return a}});var o=e(18272),r=e(2171),n=e(6791);class s extends n.f{constructor(){super(...arguments),this.configRef={experienceType:"SuperComponentData",instanceSrc:"default"}}static getInstance(){return r.vv.get("__SuperComponentDataHelper__",()=>new s)}}const a=(0,o.G)(s)},13187(t,i,e){e.d(i,{DA(){return h},EF(){return g},IU(){return u},Lv(){return m},MY(){return $},P1(){return v},Qk(){return z},Sl(){return r},TX(){return n},U9(){return s},UJ(){return x},cP(){return o},cT(){return y},dd(){return w},fI(){return c},gY(){return b},gu(){return f},gw(){return a},k9(){return d},rC(){return p},sF(){return l},tM(){return S},xD(){return k},zn(){return C}});const o="158px",r="324px",n="146px",s="462px",a="304px",l="620px",h="300px",d="612px",c="12px",p="8px",u="8",v="var(--max-width-card-adaptive-1u)",f="var(--min-width-card-adaptive-2c)",g="var(--max-width-card-adaptive-2c)",m="var(--min-width-card-adaptive)",x="var(--min-height-adaptive)",b="var(--max-height-adaptive)",y="var(--gutter-size-adaptive)",w="var(--width-card-1u)",$="var(--width-card-2c)",k="var(--width-card-3c)",z="var(--height-card-1u-px)",C="var(--height-card-15u)",S="var(--height-card-15u-px)"},14804(t,i,e){e.d(i,{c(){return E}});var o=e(56911),r=e(92011),n=e(23429),s=e(38493),a=e(60815),l=e(31157),h=e(55230),d=e(42938);const c="top",p="right",u="bottom",v="left",f="center",g="start",m="end",x="top-left",b="top-center",y="top-right",w="bottom-left",$="bottom-center",k="bottom-right",z="top-start",C="top-end",S="bottom-start",F="bottom-end";class E extends r.L{constructor(){super(...arguments),this.anchor="",this.delay=300,this.autoUpdateMode="anchor",this.anchorElement=null,this.viewportElement=null,this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.horizontalInset="false",this.verticalInset="false",this.horizontalScaling="content",this.verticalScaling="content",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition=void 0,this.tooltipVisible=!1,this.currentDirection=l.O.ltr,this.showDelayTimer=null,this.hideDelayTimer=null,this.isAnchorHoveredFocused=!1,this.isRegionHovered=!1,this.handlePositionChange=t=>{this.classList.toggle("top","start"===this.region.verticalPosition),this.classList.toggle("bottom","end"===this.region.verticalPosition),this.classList.toggle("inset-top","insetStart"===this.region.verticalPosition),this.classList.toggle("inset-bottom","insetEnd"===this.region.verticalPosition),this.classList.toggle("center-vertical","center"===this.region.verticalPosition),this.classList.toggle("left","start"===this.region.horizontalPosition),this.classList.toggle("right","end"===this.region.horizontalPosition),this.classList.toggle("inset-left","insetStart"===this.region.horizontalPosition),this.classList.toggle("inset-right","insetEnd"===this.region.horizontalPosition),this.classList.toggle("center-horizontal","center"===this.region.horizontalPosition)},this.handleRegionMouseOver=t=>{this.isRegionHovered=!0},this.handleRegionMouseOut=t=>{this.isRegionHovered=!1,this.startHideDelayTimer()},this.handleAnchorMouseOver=t=>{this.tooltipVisible?this.isAnchorHoveredFocused=!0:this.startShowDelayTimer()},this.handleAnchorMouseOut=t=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.handleAnchorFocusIn=t=>{this.startShowDelayTimer()},this.handleAnchorFocusOut=t=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.startHideDelayTimer=()=>{this.clearHideDelayTimer(),this.tooltipVisible&&(this.hideDelayTimer=window.setTimeout(()=>{this.updateTooltipVisibility()},60))},this.clearHideDelayTimer=()=>{null!==this.hideDelayTimer&&(clearTimeout(this.hideDelayTimer),this.hideDelayTimer=null)},this.startShowDelayTimer=()=>{this.isAnchorHoveredFocused||(this.delay>1?null===this.showDelayTimer&&(this.showDelayTimer=window.setTimeout(()=>{this.startHover()},this.delay)):this.startHover())},this.startHover=()=>{this.isAnchorHoveredFocused=!0,this.updateTooltipVisibility()},this.clearShowDelayTimer=()=>{null!==this.showDelayTimer&&(clearTimeout(this.showDelayTimer),this.showDelayTimer=null)},this.getAnchor=()=>{const t=this.getRootNode();return t instanceof ShadowRoot?t.getElementById(this.anchor):document.getElementById(this.anchor)},this.handleDocumentKeydown=t=>{if(!t.defaultPrevented&&this.tooltipVisible&&t.key===h.F9)this.isAnchorHoveredFocused=!1,this.updateTooltipVisibility(),this.$emit("dismiss")},this.updateTooltipVisibility=()=>{if(!1===this.visible)this.hideTooltip();else{if(!0===this.visible)return void this.showTooltip();if(this.isAnchorHoveredFocused||this.isRegionHovered)return void this.showTooltip();this.hideTooltip()}},this.showTooltip=()=>{this.tooltipVisible||(this.currentDirection=(0,d.u)(this),this.tooltipVisible=!0,document.addEventListener("keydown",this.handleDocumentKeydown),n.L.enqueue(this.setRegionProps))},this.hideTooltip=()=>{this.tooltipVisible&&(this.clearHideDelayTimer(),null!==this.region&&void 0!==this.region&&(this.region.removeEventListener("positionchange",this.handlePositionChange),this.region.viewportElement=null,this.region.anchorElement=null,this.region.removeEventListener("mouseover",this.handleRegionMouseOver),this.region.removeEventListener("mouseout",this.handleRegionMouseOut)),document.removeEventListener("keydown",this.handleDocumentKeydown),this.tooltipVisible=!1)},this.setRegionProps=()=>{this.tooltipVisible&&(this.region.viewportElement=this.viewportElement,this.region.anchorElement=this.anchorElement,this.region.addEventListener("positionchange",this.handlePositionChange),this.region.addEventListener("mouseover",this.handleRegionMouseOver,{passive:!0}),this.region.addEventListener("mouseout",this.handleRegionMouseOut,{passive:!0}))}}visibleChanged(){this.$fastController.isConnected&&(this.updateTooltipVisibility(),this.updateLayout())}anchorChanged(){this.$fastController.isConnected&&(this.anchorElement=this.getAnchor())}positionChanged(){this.$fastController.isConnected&&this.updateLayout()}anchorElementChanged(t){if(this.$fastController.isConnected){if(null!=t&&(t.removeEventListener("mouseover",this.handleAnchorMouseOver),t.removeEventListener("mouseout",this.handleAnchorMouseOut),t.removeEventListener("focusin",this.handleAnchorFocusIn),t.removeEventListener("focusout",this.handleAnchorFocusOut)),null!==this.anchorElement&&void 0!==this.anchorElement){this.anchorElement.addEventListener("mouseover",this.handleAnchorMouseOver,{passive:!0}),this.anchorElement.addEventListener("mouseout",this.handleAnchorMouseOut,{passive:!0}),this.anchorElement.addEventListener("focusin",this.handleAnchorFocusIn,{passive:!0}),this.anchorElement.addEventListener("focusout",this.handleAnchorFocusOut,{passive:!0});const t=this.anchorElement.id;null!==this.anchorElement.parentElement&&this.anchorElement.parentElement.querySelectorAll(":hover").forEach(i=>{i.id===t&&this.startShowDelayTimer()})}null!==this.region&&void 0!==this.region&&this.tooltipVisible&&(this.region.anchorElement=this.anchorElement),this.updateLayout()}}viewportElementChanged(){null!==this.region&&void 0!==this.region&&(this.region.viewportElement=this.viewportElement),this.updateLayout()}connectedCallback(){super.connectedCallback(),this.anchorElement=this.getAnchor(),this.updateTooltipVisibility()}disconnectedCallback(){this.hideTooltip(),this.clearShowDelayTimer(),this.clearHideDelayTimer(),super.disconnectedCallback()}updateLayout(){switch(this.verticalPositioningMode="locktodefault",this.horizontalPositioningMode="locktodefault",this.position){case c:case u:this.verticalDefaultPosition=this.position,this.horizontalDefaultPosition="center";break;case p:case v:case g:case m:this.verticalDefaultPosition="center",this.horizontalDefaultPosition=this.position;break;case f:this.verticalDefaultPosition="center",this.horizontalDefaultPosition="center";break;case x:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="left";break;case b:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="center";break;case $:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="center";break;case y:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="right";break;case w:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="left";break;case k:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="right";break;case z:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="start";break;case C:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="end";break;case S:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="start";break;case F:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="end";break;default:this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition="center"}}}(0,o.Cg)([(0,s.CF)({mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],E.prototype,"visible",void 0),(0,o.Cg)([s.CF,(0,o.Sn)("design:type",String)],E.prototype,"anchor",void 0),(0,o.Cg)([(0,s.CF)({attribute:"delay",converter:s.R$}),(0,o.Sn)("design:type",Number)],E.prototype,"delay",void 0),(0,o.Cg)([s.CF,(0,o.Sn)("design:type",String)],E.prototype,"position",void 0),(0,o.Cg)([(0,s.CF)({attribute:"auto-update-mode"}),(0,o.Sn)("design:type",String)],E.prototype,"autoUpdateMode",void 0),(0,o.Cg)([(0,s.CF)({attribute:"horizontal-viewport-lock"}),(0,o.Sn)("design:type",Boolean)],E.prototype,"horizontalViewportLock",void 0),(0,o.Cg)([(0,s.CF)({attribute:"vertical-viewport-lock"}),(0,o.Sn)("design:type",Boolean)],E.prototype,"verticalViewportLock",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",Object)],E.prototype,"anchorElement",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",Object)],E.prototype,"viewportElement",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",String)],E.prototype,"verticalPositioningMode",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",String)],E.prototype,"horizontalPositioningMode",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",String)],E.prototype,"horizontalInset",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",String)],E.prototype,"verticalInset",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",String)],E.prototype,"horizontalScaling",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",String)],E.prototype,"verticalScaling",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",Object)],E.prototype,"verticalDefaultPosition",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",Object)],E.prototype,"horizontalDefaultPosition",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",Boolean)],E.prototype,"tooltipVisible",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",String)],E.prototype,"currentDirection",void 0)},29783(t,i,e){e.d(i,{m(){return b}});var o=e(37180),r=e(14804),n=e(45755),s=e(68009),a=e(95239);const{create:l}=n.G,h=l("neutral-fill-inverse-rest-delta",0),d=l("neutral-fill-inverse-hover-delta",-3),c=l("neutral-fill-inverse-active-delta",7),p=l("neutral-fill-inverse-focus-delta",0);var u=e(31023);const{create:v}=n.G,f=v({name:"neutral-fill-inverse-recipe"},{evaluate(t,i){return function(t,i,e,o,r,n){const a=(0,s.F)(i),l=t.closestIndexOf(t.colorContrast(i,14)),h=l+a*Math.abs(e-o);let d,c;return(1===a?e<o:a*e>a*o)?(d=l,c=h):(d=h,c=l),{rest:t.get(d),hover:t.get(c),active:t.get(d+a*r),focus:t.get(d+a*n)}}(t(u.r),i||t(a.p),t(h),t(d),t(c),t(p))}});v("neutral-fill-inverse-rest",t=>t(f).evaluate(t).rest),v("neutral-fill-inverse-hover",t=>t(f).evaluate(t).hover),v("neutral-fill-inverse-active",t=>t(f).evaluate(t).active),v("neutral-fill-inverse-focus",t=>t(f).evaluate(t).focus);class g extends r.c{connectedCallback(){super.connectedCallback();const t=f;a.p.setValueFor(this,i=>i(t).evaluate(i,i(a.p)).rest)}}var m=e(54750),x=e(4912);const b=g.compose({name:`${o.c.prefix}-tooltip`,template:x.v,styles:m.R})},54750(t,i,e){e.d(i,{R(){return p}});var o=e(22131),r=e(74849),n=e(37998),s=e(57416),a=e(41123),l=e(95239),h=e(7896),d=e(26920),c=e(48751);const p=r.A`
    :host {
        --elevation: 11;
        position: relative;
        contain: layout;
        overflow: visible;
        height: 0;
        width: 0;
        z-index: 10000;
    }

    .tooltip {
        box-sizing: border-box;
        border-radius: calc(${s.Pb} * 1px);
        border: calc(${d.XA} * 1px) solid transparent;
        background: ${l.p};
        color: ${c.l};
        padding: 4px 12px;
        height: fit-content;
        width: fit-content;
        font-family: ${h.O};
        font-size: ${a.K};
        line-height: ${a.Z};
        white-space: nowrap;
        ${n.ET}
    }

    fluent-anchored-region {
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: visible;
        flex-direction: row;
    }

    fluent-anchored-region.right,
    fluent-anchored-region.left {
        flex-direction: column;
    }

    fluent-anchored-region.top .tooltip::after,
    fluent-anchored-region.bottom .tooltip::after,
    fluent-anchored-region.left .tooltip::after,
    fluent-anchored-region.right .tooltip::after {
        content: "";
        width: 12px;
        height: 12px;
        background: ${l.p};
        border-radius: calc(${s.Pb} * 1px);
        position: absolute;
    }

    fluent-anchored-region.top .tooltip::after {
        transform: rotate(45deg) translateX(-50%);
        bottom: 4px;
        left: 50%;
    }

    fluent-anchored-region.top .tooltip {
        margin-bottom: 12px;
    }

    fluent-anchored-region.bottom .tooltip::after {
        transform: rotate(45deg) translateX(-50%);
        top: 12px;
        left: 50%;
    }

    fluent-anchored-region.bottom .tooltip {
        margin-top: 12px;
    }

    fluent-anchored-region.left .tooltip::after {
        transform: rotate(45deg) translateY(-50%);
        top: 50%;
        right: 12px;
    }

    fluent-anchored-region.left .tooltip {
        margin-right: 12px;
    }

    fluent-anchored-region.right .tooltip::after {
        transform: rotate(45deg) translateY(-50%);
        top: 50%;
        left: 4px;
    }

    fluent-anchored-region.right .tooltip {
        margin-left: 12px;
    }
`.withBehaviors((0,o.mr)(r.A`
            :host([disabled]) {
                opacity: 1;
            }
            fluent-anchored-region.top .tooltip::after,
            fluent-anchored-region.bottom .tooltip::after,
            fluent-anchored-region.left .tooltip::after,
            fluent-anchored-region.right .tooltip::after {
                content: "";
                width: unset;
                height: unset;
            }
        `))},60239(t,i,e){e.d(i,{r(){return n}});var o=e(54996),r=e(42277);const n=e(68244).F.create({trustedType:{createHTML:t=>o.sanitize(t,{RETURN_TRUSTED_TYPE:!0})},guards:{aspects:{[r.D.property]:{innerHTML:(t,i,e,r)=>function(t,i,e){const n=o.sanitize(e,{RETURN_TRUSTED_TYPE:!0});for(var s=arguments.length,a=new Array(s>3?s-3:0),l=3;l<s;l++)a[l-3]=arguments[l];r(t,i,n,...a)}}}}})},69904(t,i,e){e.d(i,{Fr(){return c},IH(){return m},Kg(){return o},M_(){return g},Oc(){return v},TF(){return a},YO(){return h},YV(){return s},Z6(){return d},aV(){return l},bc(){return f},kS(){return r},le(){return u},tD(){return n},vr(){return p}});const o="14px",r="12px",n="10px",s="16px",a="20px",l="24px",h="28px",d="20px",c="16px",p="22px",u="24px",v="28px",f="32px",g="600",m="400"},80052(t,i,e){var o=e(56911),r=e(92011),n=e(38493),s=e(60815),a=e(85349);const l=Object.freeze({card:"GemGreeting",destination:"destination",prompt:"prompt"}),h=(t,i,e)=>{var o;return(null==t?void 0:t.addOrUpdateChild({name:l.prompt,content:{headline:i,type:a.b5.Gem},overrideDestinationUrl:e,type:a.MJ.Headline,ext:null===(o=t.contract)||void 0===o?void 0:o.ext}).getMetadataTag())||""};var d=e(10809),c=e(94043),p=e(60239),u=e(10910);class v extends r.L{connectedCallback(){this.config=d.D.getConfig(),super.connectedCallback(),(0,c.S)()&&(0,u._Z)(this).then(()=>{var t;this.setupTelemetry(),this.t(),null===(t=this.visualReadinessCallback)||void 0===t||t.call(this)})}setupTelemetry(){this.rootTelemetryObject&&(this.telemetry=((t,i,e)=>{var o;const r=null===(o=null==t?void 0:t.contract)||void 0===o?void 0:o.ext;r&&e&&(r.gemType=e);const n=t.addOrUpdateChild({name:l.card,content:{id:i,type:a.b5.Gem},ext:r}),s=n.addOrUpdateChild({name:l.prompt,content:{id:i,type:a.b5.Gem},ext:r});return{componentRoot:t,card:n,prompt:s}})(this.rootTelemetryObject,this.id,this.subType||""))}t(){this.titleRef&&this.greetingHtml&&(this.titleRef.innerHTML=p.r.createHTML(this.greetingHtml),this.i(this.titleRef))}i(t){Array.from(t.getElementsByTagName("a")).forEach(t=>{var i;if(!(null===(i=this.telemetry)||void 0===i?void 0:i.card)||!this.href||!this.id)return;const e=this.href||t.href||"",o=t.innerText||"",r=((t,i,e,o)=>{var r;return t.addOrUpdateChild({name:l.destination,content:{id:i,headline:e,type:a.b5.Gem},overrideDestinationUrl:o,type:a.MJ.Headline,ext:null===(r=t.contract)||void 0===r?void 0:r.ext}).getMetadataTag()||""})(this.telemetry.card,this.id,o,e);t.setAttribute("data-t",r),t.href=e})}greetingHtmlChanged(t,i){i&&i!==t&&this.t()}}(0,o.Cg)([(0,n.CF)({attribute:"id"})],v.prototype,"id",void 0),(0,o.Cg)([(0,n.CF)({attribute:"garnet",mode:"boolean"})],v.prototype,"garnet",void 0),(0,o.Cg)([s.sH],v.prototype,"greetingHtml",void 0),(0,o.Cg)([s.sH],v.prototype,"href",void 0),(0,o.Cg)([s.sH],v.prototype,"prompts",void 0),(0,o.Cg)([s.sH],v.prototype,"rootTelemetryObject",void 0),(0,o.Cg)([(0,n.CF)({attribute:"size"})],v.prototype,"size",void 0),(0,o.Cg)([(0,n.CF)({attribute:"sub-type"})],v.prototype,"subType",void 0),(0,o.Cg)([s.sH],v.prototype,"telemetry",void 0),(0,o.Cg)([s.sH],v.prototype,"titleRef",void 0),(0,o.Cg)([s.sH],v.prototype,"visualReadinessCallback",void 0);var f=e(58792),g=e(96950),m=e(60402),x=e(69259),b=e(39957),y=e(66591);const w=t=>g.qy`<a class=${i=>(0,y.x)("prompt-button",["square-button","square"===t.renderStyle])} href=${i=>t.prompt.url||"#"} @click=${(i,e)=>{var o,r;return null===(r=(o=t.prompt).onClick)||void 0===r?void 0:r.call(o,e.event)}} data-t="${i=>t.telemetryTag}"><span class="prompt-text">${i=>t.prompt.title}</span></a>`;var $;g.qy`<div class="prompt-container">${(0,b.ux)(t=>t.prompts||[],g.qy` ${t=>w({prompt:t,renderStyle:"pill"})} `)}</div>`;const k=`${null===($=(0,f.rA)())||void 0===$?void 0:$.StaticsUrl}latest/fluent-icons/info_12_regular.svg`,z=g.qy`<span class="ai-disclaimer" tabindex="0">${t=>{var i;return(null===(i=t.config.localizedStrings)||void 0===i?void 0:i.aiDisclaimer)||""}}<img src=${k} id="ai-disclaimer-tooltip" aria-label=${t=>{var i;return(null===(i=t.config.localizedStrings)||void 0===i?void 0:i.aiInformationIcon)||""}}></span>`,C=g.qy` ${(t,i)=>{var e,o;return w({prompt:t,renderStyle:"square",telemetryTag:h(null===(o=null===(e=i.parent)||void 0===e?void 0:e.telemetry)||void 0===o?void 0:o.prompt,t.title,t.url)})}}
`,S=g.qy`<a data-t="${t=>{var i,e;return null===(e=null===(i=t.telemetry)||void 0===i?void 0:i.card)||void 0===e?void 0:e.getMetadataTag()}}" href="${t=>t.href}" target="_blank" class="title-link"><div class="title-container"><div id="title" class="title" ${(0,m.K)("titleRef")} tabindex="0" role="heading" aria-level="3">${t=>t.greetingHtml}</div>${z}</div>${(0,x.z)(t=>{var i;return null===(i=t.prompts)||void 0===i?void 0:i.length},g.qy`<div class="prompt-button-list">${(0,b.ux)(t=>t.prompts||[],C)}</div>`)}<fluent-tooltip anchor="ai-disclaimer-tooltip">${t=>{var i;return(null===(i=t.config.localizedStrings)||void 0===i?void 0:i.aiDisclaimerTooltip)||""}}</a>`;var F=e(74849),E=e(4126),_=e(22131),T=e(87944),D=e(13187),j=e(44453),R=e(69904),M=e(24282);const A=F.A` .prompt-button{background:rgba(31,31,31,0.70);border:1px solid #5A5E63}.prompt-text{color:#C3C8CE}.prompt-button:hover{background:#26292E;border:1px solid #686C72}.prompt-button:focus{background:#0A0E12;border:1px solid #5F6469}`,U=F.A` .square-button{border-radius:4px;padding:6px 12px}.square-button .prompt-text{font-size:${R.YV};
        line-height: ${R.le};
        font-weight: ${R.M_};
    }
`,O=F.A` .prompt-button{display:flex;align-items:center;padding:6px 8px;gap:4px;border-radius:12px;border:1px solid #C6CBD1;background:${j.JC};backdrop-filter:blur(5px);text-decoration:none;width:fit-content;max-width:280px;height:32px;box-sizing:border-box;cursor:pointer}.prompt-text{color:#474B50;font-size:${M.mf};
        line-height: ${M.Fg};font-family:var(--body-font);overflow:hidden;text-overflow:ellipsis;text-decoration:none;user-select:none;white-space:nowrap}.prompt-button:hover{background:#EDF2F9}.prompt-button:focus{background:#DADEE5}${U}
`.withBehaviors((0,_.G2)(A)),H=F.A` :host([size="2c"]) .prompt-container{flex-direction:row;max-height:calc(var(--gem-prompt-height) * 2 + 12px);justify-content:start;flex-wrap:wrap;margin-top:-20px}`,P=(F.A`
    ${O} :host{display:flex}.prompt-container{--gem-prompt-height:40px;display:flex;flex-direction:column;justify-content:flex-end;gap:12px}`.withBehaviors(new E.o("size","2c",H)),F.A` :host([size="2c"]){--card-height:auto;--card-width:${(0,T.c)(624)};
        max-height: ${D.tM}}:host([size="2c"]) .prompt-button-list{flex-direction:row;flex-wrap:wrap;justify-content:start}`),Y=F.A` .title{color:${j.Ql}}.title a{color:#A7C9FC}.title a:hover{color:#6DADFF}.title a:focus{color:#0083FC}.ai-disclaimer{color:#FFF}.ai-disclaimer img{filter:invert(100%)}fluent-tooltip{--fill-color:#000;--neutral-foreground-rest:#FFF}`,L=F.A` .ai-disclaimer{font-size:${R.Kg};
        line-height: ${R.Z6};color:#666;display:flex;flex-direction:row;align-items:center}.ai-disclaimer img{filter:invert(40%);margin-inline-start:6px}fluent-tooltip{--fill-color:#FFF;--neutral-foreground-rest:#000}#ai-disclaimer-tooltip{display:flex;flex-direction:row;align-items:center;justify-content:center}#ai-disclaimer-tooltip:hover{cursor:pointer}`,B=F.A` :host{--card-height:100%;--card-width:100%;display:flex;flex-direction:column;justify-content:space-between;width:var(--card-width);height:var(--card-height);gap:0}a{text-decoration:none}.title-link{height:100%;width:100%;display:flex;flex-direction:column;justify-content:space-between}.title-container{display:flex;flex-direction:column;overflow:hidden;margin-bottom:7px;gap:12px;height:100%}.title{font-family:var(--body-font);font-size:${R.TF};
        line-height: ${R.Oc};
        color: ${j.u2};word-break:break-word;overflow:hidden;display:-webkit-box;-webkit-line-clamp:7;-webkit-box-orient:vertical;text-overflow:ellipsis}.title *{margin:0;padding:0}.title a{color:${j.I4};font-style:italic;text-decoration:underline;text-decoration-style:dotted;text-underline-position:from-font;text-underline-offset:8px}.title a:hover{color:#1A5294}.title a:focus{color:#1E344F}.prompt-button-list{display:flex;flex-direction:column;justify-content:center;gap:12px}${L}
    ${O}
`.withBehaviors(new E.o("size","2c",P),(0,_.G2)(Y));var I=e(65614),q=e(29783),V=e(37180);v.compose({name:"cx-gem-greeting",template:S,styles:B,shadowOptions:{delegatesFocus:!0}}).define(I.G.registry),q.m.define(V.c.registry)},87656(t,i,e){e.d(i,{g(){return r}});var o=e(7813);function r(t){if("string"==typeof t)return t;if("function"==typeof t&&!(t=o.I.getByType(t)))throw new Error("Missing FASTElement definition.");return t.name}}}]);