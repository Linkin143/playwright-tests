(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_super-container_dist_register_CsFeedInfopaneModule_js"],{6317(e,t,a){"use strict";a.d(t,{O(){return d}});var i=a(97653),r=a(21422),n=a(15577),o=a(12535);const l=r.y.compose({name:"cs-infopane-card",template:n.cv,styles:o.o});var s=a(65614);const d=()=>{(0,i.J)(),l.define(s.G.registry)}},12535(e,t,a){"use strict";a.d(t,{o(){return v}});var i=a(4126),r=a(74849),n=a(57416),o=a(22131),l=a(50882),s=a(29222);const d=r.A` :host([size="1u"]:hover),:host([size="_2x_2y"]:hover){box-shadow:0 8px 16px 0 rgba(0,0,0,0.14),0 0 2px rgba(0,0,0,0.12)}:host([size="1u"]:hover:not([vp-test])),:host([size="_2x_2y"]:hover:not([vp-test])){transition:transform 0.2s ease-in-out,box-shadow 0.2s ease-in-out}`,c=r.A` :host([size="1u"]:hover){transform:scale(1.05)}:host([size="_2x_2y"]:hover){transform:scale(1.02)}`,$=r.A` :host,cs-card{border-radius:calc(${s.MCQ} * ${s.MU6});
        corner-shape: squircle;
    }
`,v=r.A` :host{position:relative}:host(:focus-visible){outline:auto 2px}:host,cs-card{border-radius:calc(${n.JU} * 1px)}cs-card[dwf-height]{height:calc((156 * 2px) + (var(--card-base-gap) * 1px))}.feeds3-new-height{height:100%;width:100%}:host::part(tablist){height:14px}.image-overlay{width:300px;height:172px;position:absolute;left:0;bottom:0;background:linear-gradient(180deg,rgba(0,0,0,0),#000 28%)}.infopane{position:static}.infopane-slide[hidden]{margin-inline-start:calc(var(--stroke-width) * 4px)}:host .navigation{left:0}.hide{height:14px;width:8px}.hide::before,.small::before,.smaller::before{height:4px;width:4px}:host .infopane-hide-story,:host .infopane-report-ad{height:100%;width:100%}.no-transition{--slide-transition-duration:0}.no-nav-anim::part(dot){animation:none}.show-flippers::part(previous-flipper),.show-flippers::part(next-flipper){opacity:1}.tsp-flippers::part(previous-flipper),.tsp-flippers::part(next-flipper){opacity:0.5}:host(:hover)::part(previous-flipper),:host(:hover)::part(next-flipper){opacity:1}.adWrapper{display:grid;box-sizing:border-box}cs-native-ad-card-24::part(flex){width:auto;border-radius:0}.double{grid-template-columns:1fr 1fr}.triptych{grid-template-columns:1fr 1fr 1fr}card-flipper[size="regular"] svg{height:16px;width:16px}card-flipper[size="tall"] svg{height:20px;width:20px}card-flipper[size="extra-large"] svg{height:30px;width:30px}card-flipper[size="extra-large-2"] svg{height:34px;width:34px}:host([amplify-on-hover]){-webkit-user-select:none;-ms-user-select:none;user-select:none}`.withBehaviors((0,o.mr)(r.A` :host { outline: 1px solid ${l.A.CanvasText}; }`),new i.o("useAmpHoverEffect",!0,c),new i.o("useBoxShadowHoverEffect",!0,d),new i.o("isRubifyDashboard",!0,$))},15577(e,t,a){"use strict";a.d(t,{cv(){return m},gF(){return A},q2(){return T}});var i=a(79827),r=a(18171),n=a(32470),o=a(97873),l=a(77367),s=a(85349),d=a(96950),c=a(60402),$=a(69259),v=a(39957),u=a(69781),p=a(17857);const h=d.qy` ${(0,$.z)(e=>e.enableImmersiveInfopane,d.qy`${i.L}${r.B}`)} ${(0,$.z)(e=>!e.enableImmersiveInfopane,d.qy`${i.s}${r.W}`)} `,g=new WeakMap,m=d.qy`${(0,$.z)(e=>e.data,d.qy`${(0,v.ux)(e=>[e.data],d.qy`<cs-card class="infopaneCardWrapper ${(e,t)=>t.parent.config.isFeeds3||t.parent.config.responsiveWidth?"feeds3-new-height":""}" size="${e=>e.cardSize}" card-fill-color="${e=>e.cardFillColor}" gradient-angle="${e=>e.gradientAngle}" ?dwf-height="${(e,t)=>t.parent.config.use324HeightIfp&&t.parent.config.enableDynamicWaterfall}" ${(0,c.K)("outerCSCard")}><cs-responsive-infopane class="infopane mid-button ${e=>e.disableNavAnimation?"no-nav-anim":""} ${e=>e.enableImmersiveInfopane?"immersive-infopane":""} ${e=>e.enableFlippersOnRest?"show-flippers":""} ${e=>e.enableTransparentFlippersOnRest?"tsp-flippers":""}" duration="${e=>e.rotationDuration}" media-controls="${e=>e.enablePlayPauseButton}" navigation-position="${e=>e.navPosition}" :enableSingleRotation="${e=>e.enableSingleRotation}" :hasSlideShow="${e=>e.enableSlideShow}" :parentContentId="${e=>e.cardData.parentContentId}" size="${e=>e.cardSize}" tab-count=${e=>e.tabCount} transition-strategy=${e=>e.enableIpTransform?"transform":"position"} :restartRotationTimer="${e=>e.restartRotationTimer}" :wpoRotationDuration="${e=>e.wpoRotationDuration}" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.infopane)||void 0===t?void 0:t.getMetadataTag()}}" play-telemetry="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.playTransitionButton)||void 0===t?void 0:t.getMetadataTag()}}" pause-telemetry="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.pauseTransitionButton)||void 0===t?void 0:t.getMetadataTag()}}" tab-telemetry="${(e,t)=>{var a;return t.parent.config.enableInfopaneTabTelemetry&&(null===(a=e.telemetryContext)||void 0===a||null===(a=a.tabTelemetry)||void 0===a?void 0:a.getMetadataTag())}}" @mouseenter=${(e,t)=>{t.event&&z(t.event.currentTarget)}} @mouseleave=${(e,t)=>{t.event&&M(t.event.currentTarget)}} preload-panels=${e=>e.lazyInfopanePreloadCount} :enableVariableSpeed=${e=>e.cardData.enableVariableSpeed} :variableTransitionMap=${e=>e.cardData.enableVariableSpeed&&e.slideContentData.map(e=>({id:e.id,slideDuration:e.customTransitionSpeed}))} :lazyPanels=${e=>e.enableLazyInfopane?e.slideContentData.map(e=>({id:e.id,data:e})):void 0} :lazyPanelTemplate=${(e,t)=>(g.has(t.parent)||g.set(t.parent,d.qy`${e=>f(e,t.parent)}`),g.get(t.parent))} ${(0,c.K)("cardElement")}>${(0,$.z)(e=>!e.disableInfopaneFlippers,h)} ${(0,v.ux)(e=>e.enableLazyInfopane?[]:e.slideContentData,d.qy`${(e,t)=>f(e,t.parentContext.parent)}`)}</cs-responsive-infopane></cs-card>`)} `)}`,f=(e,t)=>{const a=0!==(e.cardActionStatus&p.J.hide)||!!e.enableHideStoryFeedback&&(0!==(e.cardActionStatus&p.J.showFewer)||0!==(e.cardActionStatus&p.J.hidden)),i=t.data;return e.isNativeAd?i.enableResponsiveInfopaneMap?t.config.useResponsiveAdInfopane?n.W:x:!i.disableInfopaneComplexAds&&e.nativeAds&&e.nativeAds.length>1?_:d.qy` ${(0,$.z)(e=>{var a;return t.config.enableInfopAdPlaceholder&&!(null!==(a=e.nativeAds)&&void 0!==a&&a.length)},x)} ${(0,v.ux)(e=>e.nativeAds&&e.nativeAds.slice(0,3),x)} `:e.showAdFeedback?A(e,t.cardActionTemplates):a?T(e,t.cardActionTemplates):e.isShoppingArticleCard?C:t.data.enableAutoPlayInfopaneVideos||t.data.enableResponsiveCards?o.t:b},b=d.qy`<cs-article-card-24 class="no-transition infopane-slide" :data=${e=>e}></cs-article-card-24>`,y=d.qy`<cs-native-ad-card-24-va-phase2 class="no-transition infopane-slide" inside-infopane :data=${e=>e}></cs-native-ad-card-24-va-phase2>`,w=d.qy`<cs-native-ad-card-24-default class="no-transition infopane-slide" inside-infopane :data=${e=>e}></cs-native-ad-card-24-default>`,x=d.qy` ${e=>e.enableVAPhase2?e.enableVAPhase2WithShimmer?w:y:d.qy`<cs-native-ad-card-24 class="no-transition infopane-slide" inside-infopane :data=${e=>e}></cs-native-ad-card-24>`}
`,_=d.qy`<cs-card class="adWrapper no-transition ${e=>2===e.nativeAds.length?"double":"triptych"}" size=${e=>e.cardSize} style="box-sizing: border-box; display: grid; ${e=>2===e.nativeAds.length?"grid-template-columns: 1fr 1fr;":"grid-template-columns: 1fr 1fr 1fr;"}">${(0,v.ux)(e=>e.nativeAds.slice(0,3),x)}</cs-card>`,C=d.qy`<cs-article-card-shopping class="no-transition infopane-slide" :data=${e=>e}></cs-article-card-shopping>`,k=d.qy.partial("style='height: 100%; width: 100%;'"),A=(e,t)=>e.cardActionStatus&p.J.hidden?d.qy`<div class="infopane-hide-story" ${k}>${t.hideStoryConfirmationCardTemplate}<div>`:e.cardActionStatus&p.J.adFeedbackSubmitted?d.qy`<div class="infopane-report-ad" ${k}>${t.hideStoryAdFeedbackConfirmationCardTemplate}</div>`:d.qy`<div class="infopane-report-ad" ${k}>${t.hideStoryReportAdCardTemplate}</div>`,T=(e,t)=>e.cardActionStatus&p.J.hidden?d.qy`<div class="infopane-hide-story" ${k}>${t.hideStoryConfirmationCardTemplate}<div>`:d.qy`<div class="infopane-hide-story" ${k}>${t.hideStoryFeedbackCardTemplate}</div>`,z=e=>{(0,u.kM)("SuperInfopaneCard",()=>l.YT.sendActionEvent(e,s.EG.Hover,s.MS.Open))},M=e=>{(0,u.pS)("SuperInfopaneCard",()=>l.YT.sendActionEvent(e,s.EG.MouseLeave,s.MS.Open))}},20828(e,t,a){"use strict";a.d(t,{C2(){return r},M3(){return n},i_(){return i},qb(){return l},vz(){return o}});const i="M6.75 10a1.75 1.75 0 1 1-3.5 0 1.75 1.75 0 0 1 3.5 0m5 0a1.75 1.75 0 1 1-3.5 0 1.75 1.75 0 0 1 3.5 0M15 11.75a1.75 1.75 0 1 0 0-3.5 1.75 1.75 0 0 0 0 3.5",r="M6.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0m5 0a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0M15 11.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5",n="M10.481 17.296c-.798.837-2.091.387-2.43-.59-.28-.807-.644-1.772-.998-2.483-1.06-2.126-1.679-3.336-3.385-4.85a2.8 2.8 0 0 0-.84-.49C1.698 8.438.637 7.269.914 5.88l.353-1.765a2.5 2.5 0 0 1 1.794-1.922l5.6-1.527A4.5 4.5 0 0 1 14.272 4.2l.684 3.762a3 3 0 0 1-2.951 3.537h-.884l.01.052c.08.408.177.97.241 1.583.065.61.099 1.284.048 1.912-.049.617-.184 1.25-.504 1.73a4 4 0 0 1-.435.519",o="M10.481.704c-.798-.837-2.091-.387-2.43.59-.28.806-.644 1.772-.998 2.483-1.06 2.126-1.679 3.335-3.385 4.849-.226.2-.518.363-.84.49-1.13.446-2.191 1.616-1.914 3.005l.353 1.765a2.5 2.5 0 0 0 1.794 1.922l5.6 1.527a4.5 4.5 0 0 0 5.611-3.537l.684-3.761A3 3 0 0 0 12.005 6.5h-.884l.01-.052c.08-.409.177-.97.241-1.583.065-.61.099-1.285.048-1.913-.049-.616-.184-1.249-.504-1.73a4 4 0 0 0-.435-.518",l="M11.14 2.53a1.5 1.5 0 0 0-2.28 0l-6.62 7.8A1 1 0 0 0 3 11.98h3V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-5.02h3a1 1 0 0 0 .76-1.65z"},32470(e,t,a){"use strict";a.d(t,{W(){return u}});var i=a(96950),r=a(60402),n=a(69259),o=a(58792),l=a(76696),s=a(17857),d=a(77793),c=a(46983);const $={_1x_2y:"1u",_2x_2y:"_2x_2y",_1x_1y:"0.5u"},v=i.qy`
    <span slot="action-row-start">
        <social-bar-wc
            config-instance-src=${e=>e.socialBarWCConfigInfo&&(0,l.v)(e.socialBarWCConfigInfo)}
            instance-id=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.instanceId}
            config-shared-ns=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.configRef&&e.socialBarWCConfigInfo.configRef.sharedNs}
            :contentId=${e=>e.id}
            :url=${e=>e.feedbackUrl}
            :destinationUrl=${e=>e.destinationUrl}
            :title=${e=>e.title}
            :imageData=${e=>e.imageData}
            :abstract=${e=>e.abstract||e.metadata&&e.metadata.abstract}
            :locale=${e=>o.T3.CurrentMarket||e.locale}
            :theme=${"ads"}
            :rootTelemetryObject=${e=>{var t;return null===(t=e.adTelemetryContext)||void 0===t?void 0:t.nativeAdCard}}
            :getReplacementCardsCallback=${e=>e.getReplacementCardsCallback}
            :reactionCallback=${e=>e.reactionCallback}
            :shareActionHandler=${e=>e.shareActionHandler}
            :cardActionHideHandler=${e=>()=>e.openAdReportDialog(e)}
            :isInfoPane=${e=>e.isInfopane}
            :socialMetadata=${e=>({...e.metadata,imageData:e.imageData,providerData:e.providerData,title:e.title})}
        ></social-bar-wc>
    </span>
`,u=i.qy`
<cs-responsive-card
    ad=true
    ${(0,d.Ib)(!1,!0)}
    ?ad-va="${e=>e.adVA}"
    ?ad-va2="${e=>e.adVA2}"
    ?ruby-va="${e=>e.enableRubyVerticalAds&&e.adVA2}"
    ?ad-pa="${e=>{var t;return null===(t=e.template)||void 0===t?void 0:t.adPA}}"
    ?enable-ad-social-bar="${e=>e.enableAdSocialBar}"
    :adAttributes=${e=>e.adAttributes}
    :abstract=${e=>e.abstract}
    ad-dts-style-key="${e=>e.adDTSStyleKey}"
    :adDTSTemplateConfig=${e=>e.adDTSTemplateConfig}
    :adDTSComponentDataMap=${e=>e.adDTSComponentDataMap}
    ?use-ad-dts-template=${e=>e.shouldUseAdDTSTemplate}
    :attributionData=${e=>e.attributionData}
    :adSelectionCriteria=${e=>e.adSelectionCriteria}
    :badgeProps="${e=>e.badgeProps}"
    :callToAction="${e=>e.callToAction}"
    :data="${e=>e}"
    data-t="${e=>{var t;return e.id?null===(t=e.adTelemetryContext)||void 0===t||null===(t=t.nativeAdCard)||void 0===t?void 0:t.getMetadataTag():""}}"
    :heading="${e=>e.title}"
    ?hide-card-actions="${e=>e.hideCardActions||!e.feedbackUrl}"
    :href="${e=>e.destinationUrl}"
    :href_adButton="${e=>(0,c.lW)(e)}"
    :href_adChoiceButton="${e=>e.adChoiceIconUrl}"
    id="${e=>e.id}"
    ?immersive="${e=>!(!("_2x_2y"==e.cardSize||"_1x_2y"==e.cardSize&&e.immersiveCard)||e.isIntraNativeAd)||void 0}"
    :intraArticle=${e=>e.isIntraNativeAd}
    :isIntraFeedAd=${e=>e.isIntraNativeAd}
    :isIntraClassicAd="${e=>e.isIntraClassicAd}"
    :mediaData=${e=>e.mediaData}
    media-type="${e=>{var t;return null!==(t=e.imageData)&&void 0!==t&&t.source?"image":""}}"
    @mouseenter="${(e,t)=>e.mouseEnterCallback(t.event.currentTarget)}"
    @mouseleave="${(e,t)=>e.mouseLeaveCallback(t.event.currentTarget)}"
    :onClickLink="${e=>e.onClickLink}"
    :onClickCardActions="${e=>e.toggleCardActionMenu}"
    :onRightClick="${e=>e.toggleCardActionMenu}"
    :onClickHideCard="${(e,t)=>()=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus^s.J.hide^s.J.hidden,"Hide",!0,null,null,null,t.event,null,"hidestory-button")}"
    :popoverData="${e=>e.popoverData}"
    size="${e=>$[e.cardSize]||e.cardSize}"
    style="grid-area:${e=>e.gridArea};"
    target="${e=>e.openLinksInCurrentTab?"_self":"_blank"}"
    :telemetryObject_card="${e=>{var t;return null===(t=e.adTelemetryContext)||void 0===t?void 0:t.nativeAdCard}}"
    :telemetryTag_adButton="${e=>(0,c.j1)(e.adTelemetryContext)}"
    :telemetryTag_adChoiceButton="${e=>{var t;return null===(t=e.adTelemetryContext)||void 0===t||null===(t=t.adChoice)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_anchor="${e=>{var t;return null===(t=e.adTelemetryContext)||void 0===t||null===(t=t.destination)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_moreActions="${e=>{var t;return null===(t=e.adTelemetryContext)||void 0===t||null===(t=t.seeMore)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_adDisclaimerButton="${e=>{var t;return null===(t=e.adTelemetryContext)||void 0===t||null===(t=t.adDisclaimer)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_callToAction="${e=>{var t;return null===(t=e.adTelemetryContext)||void 0===t||null===(t=t.callToAction)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_undoHide="${e=>{var t;return null===(t=e.adTelemetryContext)||void 0===t||null===(t=t.cancelButton)||void 0===t?void 0:t.getMetadataTag()}}"
    title="${e=>e.title}"
    :visualReadinessCallback="${e=>e.visualReadinessCallback}"
    ?wide="${e=>"_2x_2y"==e.cardSize||void 0}"
    ?ruby="${e=>e.ruby}"
    ?loading="${e=>e.loading}"
    ${(0,r.K)("cardElement")}
>
    ${(0,n.z)(e=>e.enableAdSocialBar&&e.feedbackUrl,v)}
</cs-responsive-card>`},41124(e,t,a){"use strict";a.d(t,{tB(){return f},LW(){return m},nj(){return g}});var i=a(29937),r=a(96950),n=a(69259),o=a(20828),l=a(17857),s=a(33477),d=a(86203),c=a.n(d),$=a(48493),v=a.n($),u=a(58792),p=a(61409),h=a(76696);const g=e=>{let{theme:t="default",hideComments:a=!1}=e;return r.qy`
<div style="display: flex; gap: 4px;">
    ${(0,n.z)(e=>e.optedOutOfReactions&&!e.disableOptedOutButton,r.qy`
        ${m}
        ${f}
    `)}
    <social-bar-wc
        config-instance-src=${e=>e.socialBarWCConfigInfo&&(0,h.v)(e.socialBarWCConfigInfo)}
        instance-id=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.instanceId}
        config-shared-ns=${e=>{var t;return null===(t=e.socialBarWCConfigInfo)||void 0===t||null===(t=t.configRef)||void 0===t?void 0:t.sharedNs}}
        :additionalHeaders=${e=>e.additionalHeaders}
        :hideComments=${e=>a}
        :canShowOneLineComments=${e=>!(e.isInfopane||e.cardSize!==s.uE._2x_2y||"flex-article-card"===e.childTemplateType&&e.articleTopCommentConfigInfo&&e.articleTopCommentId)}
        :contentId=${e=>e.id}
        :destinationUrl=${e=>e.destinationUrl}
        :title=${e=>e.title}
        :locale=${e=>u.T3.CurrentMarket||e.locale}
        :rootTelemetryObject=${e=>e.telemetryContext&&(e.telemetryContext.contentCardTelemetryObject||e.telemetryContext.contentCard)}
        :getReplacementCardsCallback=${e=>e.getReplacementCardsCallback}
        :reactionCallback=${e=>e.reactionCallback}
        :cardActionHideHandler=${e=>e.cardActionClickHandler&&function(){for(var t=arguments.length,a=new Array(t),i=0;i<t;i++)a[i]=arguments[i];return e.cardActionClickHandler(e.id,e.cardActionStatus^l.J.hide,...a)}}
        :shareActionHandler=${e=>e.shareActionHandler}
        :isInfoPane=${e=>e.isInfopane}
        :isRightPos=${e=>e.socialBarInRight}
        :socialMetadata=${e=>({...e.metadata,imageData:e.imageData,providerData:e.providerData,title:e.title})}
        :theme=${e=>t}
    ></social-bar-wc>
</div>
`},m=r.qy`
<msn-card-button
    class="card-button"
    data-icon=${l.J.showMore}
    style="${e=>e.isInfopane||e.optedOutOfReactions||!e.enableFilledIconOnHover?"":"display: flex;"} ${e=>e.enableAnimatedShowMoreBtn||e.optedOutOfReactions||!e.enableFilledIconOnHover?"":"margin-inline-end: 8px;"}"
    select-title=${e=>e.cardActionsTooltips&&e.cardActionsTooltips.showMore}
    unselect-title=${e=>e.cardActionsTooltips&&e.cardActionsTooltips.undoShowMore}
    animation-text=${e=>e.showMoreAnimationTitle}
    select-icon=${e=>e.useArrowIcons&&!e.optedOutOfReactions?c():'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48.7c-.8-.83-2.09-.38-2.43.6-.28.8-.64 1.77-1 2.48C6 5.9 5.37 7.1 3.67 8.63c-.23.2-.52.36-.84.49-1.13.44-2.2 1.61-1.92 3l.36 1.77a2.5 2.5 0 0 0 1.8 1.92l5.6 1.52a4.5 4.5 0 0 0 5.6-3.53l.69-3.76A3 3 0 0 0 12 6.5h-.88l.01-.05c.08-.41.18-.97.24-1.59.07-.6.1-1.28.05-1.9a3.68 3.68 0 0 0-.5-1.74 4.16 4.16 0 0 0-.44-.52Z"/></svg>'}
    unselect-icon=${e=>e.useArrowIcons&&!e.optedOutOfReactions?v():'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 1.3C8.4.31 9.68-.14 10.48.7c.16.17.33.36.44.52.32.48.45 1.12.5 1.73.05.63.02 1.3-.05 1.91-.06.62-.16 1.18-.24 1.59v.05H12a3 3 0 0 1 2.96 3.54l-.69 3.76a4.5 4.5 0 0 1-5.6 3.53l-5.6-1.52a2.5 2.5 0 0 1-1.8-1.92L.9 12.12c-.27-1.39.79-2.56 1.92-3 .32-.13.61-.3.84-.5 1.7-1.5 2.32-2.72 3.38-4.84.36-.71.72-1.68 1-2.49Zm1.96 5.58v-.01l.01-.03a9.08 9.08 0 0 0 .13-.58c.08-.4.17-.92.23-1.5s.09-1.18.04-1.73a2.73 2.73 0 0 0-.34-1.25 3.26 3.26 0 0 0-.32-.39c-.2-.2-.63-.16-.76.23-.29.82-.67 1.83-1.05 2.6-1.07 2.14-1.76 3.5-3.62 5.15-.34.3-.74.52-1.13.68-.89.34-1.45 1.14-1.3 1.87l.35 1.77c.1.56.53 1 1.07 1.15l5.6 1.53c1.98.54 4-.73 4.37-2.75l.68-3.76A2 2 0 0 0 12 7.5h-1.5a.5.5 0 0 1-.48-.62Z"/></svg>'}
    filled-icon-path=${e=>e.useArrowIcons&&!e.optedOutOfReactions?o.qb:o.vz}
    fill-color-selected=${e=>!e.enableNeutralFilledShowMoreIcon&&p.P}
    layout=${e=>(0,i.V1)(e)}
    selected=${e=>!!(e.cardActionStatus&l.J.showMore)}
    @selected-state-changed=${(e,t)=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus&l.J.showFewer?e.cardActionStatus^l.J.showMore^l.J.showFewer:e.cardActionStatus^l.J.showMore,"ShowMore",!0,e.cardActionClickHandler,null,!e.enableAnimatedShowMoreBtn,t.event)}
    select-telemetry-tag=${e=>e.telemetryContext&&e.telemetryContext.showMore&&e.telemetryContext.showMore.getMetadataTag()}
    unselect-telemetry-tag=${e=>e.telemetryContext&&e.telemetryContext.undoShowMore&&e.telemetryContext.undoShowMore.getMetadataTag()}
>
</msn-card-button>
`,f=r.qy`
<msn-card-button
    class="card-button"
    data-icon=${l.J.showFewer}
    style="${e=>!e.enableAnimatedShowMoreBtn&&e.enableFilledIconOnHover?"margin-inline-start: 8px;":""}"
    select-title=${e=>e.cardActionsTooltips&&e.cardActionsTooltips.showFewer}
    unselect-title=${e=>e.cardActionsTooltips&&e.cardActionsTooltips.undoShowFewer}
    select-icon=${e=>'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M10.48 17.3c-.8.83-2.09.38-2.43-.6-.28-.8-.64-1.77-1-2.48C6 12.1 5.37 10.9 3.67 9.37c-.23-.2-.52-.36-.84-.49C1.7 8.44.63 7.27.9 5.88l.36-1.77a2.5 2.5 0 0 1 1.8-1.92L8.66.66a4.5 4.5 0 0 1 5.6 3.54l.69 3.76A3 3 0 0 1 12 11.5h-.88l.01.05c.08.41.18.97.24 1.58.07.62.1 1.29.05 1.92a3.68 3.68 0 0 1-.5 1.73c-.11.16-.28.35-.44.52Z"/></svg>'}
    unselect-icon=${e=>'<svg width="16" height="18" viewBox="0 0 16 18"><path d="M8.05 16.7c.34.98 1.63 1.43 2.43.6.16-.17.33-.36.44-.52.32-.48.45-1.12.5-1.73.05-.63.02-1.3-.05-1.91-.06-.62-.16-1.18-.24-1.59v-.05H12a3 3 0 0 0 2.96-3.54l-.69-3.76A4.5 4.5 0 0 0 8.67.67l-5.6 1.52c-.92.25-1.62 1-1.8 1.92L.9 5.88c-.27 1.39.79 2.56 1.92 3 .32.13.61.3.84.5 1.7 1.5 2.32 2.72 3.38 4.84.36.71.72 1.68 1 2.49Zm1.96-5.58v.01l.01.03a8.94 8.94 0 0 1 .13.58c.08.4.17.92.23 1.5s.09 1.18.04 1.73c-.04.55-.16.98-.34 1.25-.05.1-.17.22-.32.39-.2.2-.63.16-.76-.23-.29-.82-.67-1.83-1.05-2.6-1.07-2.14-1.76-3.5-3.62-5.15-.34-.3-.74-.52-1.13-.68-.89-.34-1.45-1.14-1.3-1.87l.35-1.77c.1-.56.53-1 1.07-1.15l5.6-1.53a3.5 3.5 0 0 1 4.37 2.75l.68 3.76A2 2 0 0 1 12 10.5h-1.5a.5.5 0 0 0-.48.62Z"/></svg>'}
    filled-icon-path=${e=>o.M3}
    fill-color-selected=${e=>!e.enableNeutralFilledShowMoreIcon&&p.P}
    layout=${e=>(0,i.V1)(e)}
    selected=${e=>!!(e.cardActionStatus&l.J.showFewer)}
    @selected-state-changed=${(e,t)=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus&l.J.showMore?e.cardActionStatus^l.J.showMore^l.J.showFewer:e.cardActionStatus^l.J.showFewer,"ShowFewer",!0,e.cardActionClickHandler,null,!e.contentType,t.event)}
    select-telemetry-tag=${e=>e.telemetryContext&&e.telemetryContext.showMore&&e.telemetryContext.showFewer.getMetadataTag()}
    unselect-telemetry-tag=${e=>e.telemetryContext&&e.telemetryContext.undoShowFewer&&e.telemetryContext.undoShowFewer.getMetadataTag()}
>
</msn-card-button>
`},48493(e){e.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.86 2.53c.6-.7 1.68-.7 2.28 0l6.62 7.8a1 1 0 01-.76 1.65h-3V17a1 1 0 01-1 1H7a1 1 0 01-1-1v-5.02H3a1 1 0 01-.76-1.65l6.62-7.8zm1.52.65a.5.5 0 00-.76 0L3 10.98h3.5c.28 0 .5.23.5.5V17h6v-5.52c0-.27.22-.5.5-.5H17l-6.62-7.8z"></path></svg>'},61409(e,t,a){"use strict";a.d(t,{P(){return i}});const i="#0078D4"},86203(e){e.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M11.14 2.53a1.5 1.5 0 00-2.28 0l-6.62 7.8A1 1 0 003 11.98h3V17a1 1 0 001 1h6a1 1 0 001-1v-5.02h3a1 1 0 00.76-1.65l-6.62-7.8z"></path></svg>'},90252(e,t,a){"use strict";var i=a(6317),r=a(78076),n=a(87210),o=a(12628),l=a(45214);(0,i.O)(),(0,n.m)(),(0,r.m)(),(0,o.A)(),(0,l.O)()},97873(e,t,a){"use strict";a.d(t,{t(){return p}});var i=a(41124),r=a(33477),n=a(96950),o=a(60402),l=a(69259),s=a(17857),d=a(58792),c=a(76696),$=a(65055);const v=n.qy`
    ${e=>(0,$.yN)(e.publisherFollowButtonConfigInfo,{attributes:{slot:"following-button"},properties:{contentId:e.id,publisherName:e.providerData.name,publisherProfileId:e.providerData.profileId,profileId:e.providerData.id,getReplacementCardsCallback:e.getReplacementCardsCallback,enableFollowToast:!0,cardActionStatus:e.cardActionStatus,usingResponsiveCard:!0}})}
`,u=n.qy`
    <span slot="action-row-start">
    ${(0,l.z)(e=>e.useStatSocialTemplate,n.qy`
        <social-bar-wc
            config-instance-src=${e=>e.socialBarWCConfigInfo&&(0,c.v)(e.socialBarWCConfigInfo)}
            instance-id=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.instanceId}
            config-shared-ns=${e=>e.socialBarWCConfigInfo&&e.socialBarWCConfigInfo.configRef&&e.socialBarWCConfigInfo.configRef.sharedNs}
            :contentId=${e=>e.id}
            :hideComments=${e=>e.hideComments||!1}
            :canShowOneLineComments=${e=>!e.isInfopane&&e.cardSize===r.uE._2x_2y}
            :destinationUrl=${e=>e.destinationUrl}
            :title=${e=>e.title}
            :imageData=${e=>e.imageData}
            :abstract=${e=>e.abstract||e.metadata&&e.metadata.abstract}
            :locale=${e=>d.T3.CurrentMarket||e.locale}
            :theme=${e=>e.socialBarTheme||"default"}
            :rootTelemetryObject=${e=>e.telemetryContext&&(e.telemetryContext.contentCardTelemetryObject||e.telemetryContext.contentCard)}
            :getReplacementCardsCallback=${e=>e.getReplacementCardsCallback}
            :reactionCallback=${e=>e.reactionCallback}
            :shareActionHandler=${e=>e.shareActionHandler}
            :cardActionHideHandler=${e=>e.cardActionClickHandler&&function(){for(var t=arguments.length,a=new Array(t),i=0;i<t;i++)a[i]=arguments[i];return e.cardActionClickHandler(e.id,e.cardActionStatus^s.J.hide,...a)}}
            :isInfoPane=${e=>e.isInfopane}
            :socialMetadata=${e=>({...e.metadata,imageData:e.imageData,providerData:e.providerData,title:e.title})}
        ></social-bar-wc>
        `,n.qy`${e=>(0,i.nj)({theme:e.socialBarTheme,hideComments:e.hideComments})}`)}
    </span>
`,p=n.qy`
<cs-responsive-card
    :abstract=${e=>e.abstract}
    :attributionData=${e=>e.attributionData}
    :badgeProps="${e=>e.badgeProps}"
    :contentIndicator="${e=>e.renderContentIndicator}"
    :data="${e=>e}"
    :heightReadyCallback="${e=>e.heightReadyCallback}"
    :heading="${e=>e.title}"
    :href="${e=>e.destinationUrl}"
    id="${e=>e.id}"
    ?immersive="${e=>!("_2x_2y"!=e.cardSize&&("_1x_2y"!=e.cardSize&&"_1x_1y"!=e.cardSize&&"shorts"!==e.responsiveCardSize||!e.immersiveCard))||void 0}"
    :mediaData=${e=>e.mediaData}    
    media-type="${e=>e.mediaType}"
    :preventDefaultClick="${e=>e.preventDefaultClick}"
    :onClickCardActions="${e=>e.toggleCardActionMenu}"
    :onRightClick="${e=>e.toggleCardActionMenu}"
    :onClickHideCard="${(e,t)=>()=>e.cardActionClickHandler&&e.cardActionClickHandler(e.id,e.cardActionStatus^s.J.hide^s.J.hidden,"Hide",!0,null,null,null,t.event,null,"hidestory-button")}"
    :onClickLink=${(e,t)=>e.onClickLink}
    :onClickCompanionButton=${(e,t)=>e.onClickCompanionButton}
    size="${e=>e.responsiveCardSize}"
    style="${e=>e.ruby?void 0:(e=>{const t=`grid-area:${e.gridArea};`;return e.predictedHeight?`${t} --placeholder-intrinsic-height: ${e.predictedHeight-32}px;`:t})(e)}"
    :rubySocialBarData="${e=>e.rubySocialBarData}"
    target="${e=>e.openLinksInCurrentTab?"_self":"_blank"}"
    :telemetryObject_card="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t?void 0:t.contentCard}}"
    :telemetryTag_anchor="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.destination)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_hideCard="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.showFewer)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_undoHide="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.undoShowFewer)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_moreActions="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.seeMore)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_showMore="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.upvote)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_undoShowMore="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.undoUpvote)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_companion="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.companion)||void 0===t?void 0:t.getMetadataTag()}}"
    :telemetryTag_commentButton="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.commentsButton)||void 0===t?void 0:t.getMetadataTag()}}"
    title="${e=>e.title}"
    :headingPrefix="${e=>e.titlePrefix}"
    :visualReadinessCallback="${e=>e.visualReadinessCallback}"
    ?wide="${e=>"_2x_2y"==e.cardSize||void 0}"
    ?ruby="${e=>e.ruby}"
    ?segment="${e=>e.segment}"
    ?companion="${e=>e.companion}"
    :companionButtonText="${e=>e.companionButtonText}"
    ${(0,o.K)("cardElement")}
>
    ${(0,l.z)(e=>e.publisherFollowButtonConfigInfo,v)}
    ${(0,l.z)(e=>e.enableRichSocialReaction,u)}
</cs-responsive-card>
`}}]);