"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_fast-msft-web-components_dist_index_js"],{6256(t,e,o){o.d(e,{msftProng2CardWrapper(){return r.k},msftStructuredDataCard(){return i.K7}});var r=o(53822),i=o(42767)},25717(t,e,o){o.d(e,{T(){return i}});var r=o(96950);function i(){return r.qy`
        <slot></slot>
    `}},37256(t,e,o){o.d(e,{R(){return p}});var r=o(64187),i=o(22131),n=o(74849),a=o(50882),l=o(37998),d=o(57416),s=o(95239),c=o(48751);const p=n.A`
    ${(0,r.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${s.p};
        color: ${c.l};
        border-radius: calc(${d.JU} * 1px);
        ${l.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,i.mr)(n.A`
            :host {
                forced-color-adjust: none;
                background: ${a.A.Canvas};
                box-shadow: 0 0 0 1px ${a.A.CanvasText};
            }
        `))},42767(t,e,o){o.d(e,{K7(){return k}});var r=o(99900),i=o(56911),n=o(92011),a=o(38493),l=o(60815);class d extends n.L{constructor(){super(...arguments),this.pinned=!1}}(0,i.Cg)([a.CF],d.prototype,"target",void 0),(0,i.Cg)([(0,a.CF)({mode:"boolean"})],d.prototype,"pinned",void 0),(0,i.Cg)([l.sH],d.prototype,"data",void 0),(0,i.Cg)([l.sH],d.prototype,"headerTelemetryTag",void 0),(0,i.Cg)([l.sH],d.prototype,"seeMoreTelemetryTag",void 0);var s=o(64187),c=o(73477),p=o(22131),v=o(74849),u=o(50882),g=o(7896),h=o(48751),m=o(61138),f=o(45476);const x=v.A`
    ${(0,s.V)("grid")}:host{position:relative;width:auto;height:100%;box-sizing:border-box;font-family:${g.O};grid-template-rows:auto 1fr auto;padding:var(--content-padding,16px 0);outline:none}:host([pinned]){padding:var(--content-padding,0 16px 16px 16px)}:host([pinned]) .title-link{cursor:pointer}:host([pinned]) .title{cursor:var(--cursor-styles);padding:var(--title-padding,16px 0 0)}.footer{display:grid;grid-template-columns:1fr auto 1fr;padding:var(--footer-padding,0 16px)}.title{overflow:hidden;display:grid;grid-template-columns:1fr auto auto;grid-gap:8px;padding:var(--title-padding,0 16px);overflow:visible;align-items:center}.title-link{display:grid;grid-template-columns:auto 1fr;grid-gap:8px;color:${h.l};
        font-size: ${m.k};
        justify-content: flex-start;
        line-height: ${m.F};
        outline: none;
        cursor: pointer;
        text-decoration: none;
        margin-inline-end: auto;
    }

    .title-link:hover,
    .title-link:active,
    .title-link:${c.N}{text-decoration:underline}.title-link:${c.N} > .title-content{text-decoration:underline}.title-content{font-size:${m.k};
        line-height: ${m.F};margin-top:4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;-webkit-line-clamp:var(--title-max-lines,1)}::slotted([slot="title-icon"]){margin-top:4px}.sd-action{--control-corner-radius:16;grid-column:2;z-index:1}.sd-action:not([appearance="lightweight"]){font-size:${m.k};
        line-height: ${m.F}}.sd-action::part(control){width:100%;padding:var(--sd-action-padding,0px 24px)}.sd-action::part(content){-webkit-box-orient:vertical;-webkit-line-clamp:1;text-overflow:ellipsis;overflow:hidden}::slotted([slot="more-actions"]){min-width:var(--more-actions-size,24px);width:var(--more-actions-size,24px);height:var(--more-actions-size,24px);--control-corner-radius:var(--more-actions-corner-radius,16);z-index:1;grid-column:3;background-color:transparent}::slotted([slot="more-actions"]:hover){background-color:${f.oO}}::slotted([slot="more-actions"]:active){background-color:${f.wO}}::slotted([slot="pin"]){fill:${h.l};
        margin-inline-end: 6px;
    }
`.withBehaviors((0,p.mr)(v.A` .title-link{color:${u.A.CanvasText}}a[href]{color:${u.A.LinkText};
                }
            `));var $=o(96950),b=o(69259);const w=$.qy`<div class="title" part="title" role="heading" aria-level="2">${(0,b.z)(t=>{var e;return null==t||null===(e=t.data)||void 0===e?void 0:e.titleContent},$.qy`<a class="title-link" part="title-link" href="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.link}}" target=${t=>t.target} title="${t=>{var e,o;return(null===(e=t.data)||void 0===e?void 0:e.titleContentHint)??(null===(o=t.data)||void 0===o?void 0:o.titleContent)}}" data-t="${t=>t.headerTelemetryTag}"><slot name="title-icon"></slot><div class="title-content" part="title-content">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.titleContent}}</div><slot name="weather-pen-btn"></slot><slot name="weather-map-btn"></slot></a>`)}<slot name="pin"></slot><slot name="more-actions"></slot></div><slot></slot><div class="footer" part="footer"><slot name="footer-start"></slot>${(0,b.z)(t=>{var e;return null==t||null===(e=t.data)||void 0===e?void 0:e.footerContent},$.qy`<fluent-anchor class="sd-action" part="sd-action" appearance="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.actionAppearance}}" href="${t=>{var e,o,r;return null!==(e=t.data)&&void 0!==e&&e.footerLink?null===(o=t.data)||void 0===o?void 0:o.footerLink:null===(r=t.data)||void 0===r?void 0:r.link}}" target=${t=>t.target} data-t="${t=>t.seeMoreTelemetryTag}">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.footerContent}}</fluent-anchor>`)}<slot name="footer-end"></slot></div>`,k=d.compose({name:`${r.i.prefix}-structured-data-card`,template:w,styles:x})},53822(t,e,o){o.d(e,{k(){return c}});var r=o(72526),i=o(74849),n=o(25717),a=o(99900),l=o(37256),d=o(57416);const s=i.A`
        ${l.R} :host{border-radius:calc(${d.JU} * 1px);
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        }
    `,c=r.L.compose({name:`${a.i.prefix}-prong2-card-wrapper`,template:(0,n.T)(),styles:s});r.L.compose({name:`${a.i.prefix}-mstf-prong2-card-wrapper`,template:(0,n.T)(),styles:i.A`
    ${s}
    :host {
        box-shadow: 0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0, 0, 0, calc(0.11 * (2 - var(--background-luminance, 1)))), 0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0, 0, 0, calc(0.13 * (2 - var(--background-luminance, 1))));
    }`})},72526(t,e,o){o.d(e,{L(){return g}});var r=o(56911),i=o(96193),n=o(47429),a=o(60815),l=o(22870),d=o(38493),s=o(95239),c=o(31023),p=o(24458),v=o(5291),u=o(57606);class g extends i.z{cardFillColorChanged(t,e){if(e){const t=(0,l.Hs)(e);null!==t&&(this.neutralPaletteSource=e,s.p.setValueFor(this,v.q.create(t.r,t.g,t.b)))}}neutralPaletteSourceChanged(t,e){if(e){const t=(0,l.Hs)(e),o=v.q.create(t.r,t.g,t.b);c.r.setValueFor(this,u.p.create(o))}}handleChange(t,e){this.cardFillColor||s.p.setValueFor(this,t=>t(p.M3).evaluate(t,t(s.p)))}connectedCallback(){super.connectedCallback();const t=(0,n.Zo)(this);if(t){const e=a.cP.getNotifier(t);e.subscribe(this,"fillColor"),e.subscribe(this,"neutralPalette"),this.handleChange(t,"fillColor")}}}(0,r.Cg)([(0,d.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,r.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,r.Cg)([(0,d.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,r.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0)}}]);