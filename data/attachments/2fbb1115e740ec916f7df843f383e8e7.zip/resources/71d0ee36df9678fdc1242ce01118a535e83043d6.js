// © Microsoft Corporation. All rights reserved.
import { getHeadData, getLocalStorage } from "@msnews/fundamentals";
import { IsomorphicStorage, canUseDOM, createSingletonProxy, getLocationPathname } from "@msnews/isomorphic-util";
import { getCookie, trySetCookie } from "@msnews/cookie-utils";
import { Telemetry } from "@msnews/telemetry-contracts";
const isControlForceFeedFlight = getHeadData().CurrentFlightSet?.has("prg-hp-ctffed");
class HomepageFeedManager {
    constructor() {
        this.storageKey = "hpFeedView";
        this.feedViewCookieKey = "_hpFeedView";
        this.switchBannerCookieKey = "_switchBannerClosed";
        this.feedViewValue = null;
        this._isFeedView = !getHeadData().CurrentFlightSet?.has("prg-vp-sf-cv");
        this.forceFeedView = getHeadData().CurrentFlightSet?.has("prg-hp-ffeed");
        this.tmplStamped = false;
        this.init = () => {
            this.feedViewValue = this.getFeedViewTag();
            if (!this.feedViewValue) {
                return;
            }
            this._isFeedView = this.feedViewValue.isFeedView;
        };
        this.switchView = () => {
            this.setFeedViewTag({ ...this.feedViewValue, isFeedView: !this._isFeedView });
            setTimeout(() => window.location.reload(), 1);
        };
        this.wasBannerClosed = () => this.feedViewValue?.closed;
        this.toggleBanner = (closed) => {
            if (!this.feedViewValue) {
                this.feedViewValue = { isFeedView: this._isFeedView, closed };
            }
            else {
                this.feedViewValue.closed = closed;
            }
            setTimeout(() => this.setFeedViewTag(this.feedViewValue));
        };
        this.getFeedViewTag = () => {
            if (!canUseDOM()) {
                return this.getCookieStorageValue();
            }
            const cookieStorageValue = this.getCookieStorageValue();
            const localStorageValue = this.getLocalStorageValue();
            if (localStorageValue && !cookieStorageValue) {
                // Sync local storage value to cookie storage values
                const cookieUpdateSuccess = this.setCookieStorageValue(localStorageValue);
                cookieUpdateSuccess && this.removeLocalStorageValue();
                // If the status has been checked in SSR, don't directly apply the synced value
                return window.isSSREnabled ? null : localStorageValue;
            }
            // Store default value to cookie or Refresh cookie to extend expiration time.
            this.setCookieStorageValue(cookieStorageValue || { isFeedView: this._isFeedView });
            return cookieStorageValue;
        };
        this.setFeedViewTag = (value) => {
            this.setCookieStorageValue(value);
            this.feedViewValue = value;
        };
        this.getCookieStorageValue = () => {
            const feedViewValue = getCookie(this.feedViewCookieKey);
            const closedValue = getCookie(this.switchBannerCookieKey);
            if (!feedViewValue) {
                return null;
            }
            return {
                isFeedView: !feedViewValue || feedViewValue === "1",
                closed: closedValue === "1"
            };
        };
        this.setCookieStorageValue = (value) => {
            if (!canUseDOM() || !value) {
                return false;
            }
            const cookieDomain = location.hostname.toLowerCase().endsWith(".cn") ? ".msn.cn" : ".msn.com";
            const feedViewCookie = trySetCookie(this.feedViewCookieKey, value.isFeedView === false ? "0" : "1", 120, cookieDomain, "/");
            const bannerCookie = trySetCookie(this.switchBannerCookieKey, value.closed ? "1" : "0", 120, cookieDomain, "/");
            return feedViewCookie && bannerCookie;
        };
        this.removeLocalStorageValue = () => {
            getLocalStorage().removeItem(this.storageKey);
        };
        this.getLocalStorageValue = () => {
            if (!getLocalStorage().supported) {
                return null;
            }
            const value = getLocalStorage().getItem(this.storageKey);
            if (!value) {
                return null;
            }
            try {
                return JSON.parse(value);
            }
            catch (e) {
                setTimeout(() => this.setFeedViewTag(this.feedViewValue));
                return null;
            }
        };
    }
    isFeedView(checkPath) {
        if (checkPath) {
            const path = getLocationPathname();
            if (path.endsWith("/feed") || path.includes("/feed/")) {
                return true;
            }
        }
        // Stamp telemetry if user is on either flight and their _isFeedView is false
        if (!this.tmplStamped && (this.forceFeedView || isControlForceFeedFlight) && this._isFeedView === false) {
            Telemetry.addOrUpdateTmplProperty("hpCustomNoFV", "1");
            this.tmplStamped = true;
        }
        return this.forceFeedView || this._isFeedView;
    }
    static getInstance() {
        return IsomorphicStorage.get(this.homepageFeedManagerInstanceKey, () => { return new HomepageFeedManager(); });
    }
}
// singleton methods
HomepageFeedManager.homepageFeedManagerInstanceKey = Symbol("homepageFeedManager");
export const homepageFeedManager = createSingletonProxy(HomepageFeedManager, { bindMethod: true });
//# sourceMappingURL=HomepageFeedManager.js.map