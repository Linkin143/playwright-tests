"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_super-cards_dist_cards_super-native-ad-card_native-ad-card-intra-article-left--add1b9"],{6721(e,a,t){t.d(a,{X(){return s},c(){return n}});var i=t(61138),r=t(48751),d=t(55153),o=t(74849),l=t(24277);const s=o.A`
    .ad-slug, .${(0,l.nP)("ad-slug")}{align-items:center;color:${r.l};
        display: flex;
        flex-direction: row;
        line-height: ${i.F};
        max-width: calc(${d.QG} * 1px - 100px);
        opacity: 0.8;
        overflow: hidden;
    }
    
    .ad-slug .ad-label, .${(0,l.nP)("ad-slug")} .${(0,l.nP)("ad-label")}{display:flex;align-items:center;border:0.5px solid rgba(26,26,26,.3);border-radius:4px;box-sizing:border-box;font-size:11px;height:16px;margin-inline-end:6px;min-width:22px;padding:1px 4px;overflow:hidden}.ad-slug .ad-label-text:focus-visible{outline:2px solid ${r.l};
        outline-offset: -2px; 
    }        

    .ad-slug .ad-label-text, .${(0,l.nP)("ad-slug")} .${(0,l.nP)("ad-label-text")}{color:inherit;pointer-events:auto;position:relative;text-decoration:none;z-index:1}.ad-slug .ad-provider,.${(0,l.nP)("ad-slug")} .${(0,l.nP)("ad-provider")}{flex:4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ad-slug .ad-provider-text,.${(0,l.nP)("ad-slug")} .${(0,l.nP)("ad-provider-text")}{color:inherit;font-size:${i.k};
        text-decoration: none;
        text-overflow: ellipsis;
        vertical-align: bottom;
    }

    .ad-slug .ad-provider-text:focus-visible, .${(0,l.nP)("ad-slug")} .${(0,l.nP)("ad-provider-text")}:focus-visible{text-decoration:underline;outline-offset:-.79px;outline:-webkit-focus-ring-color auto 1px}.ad-slug .sponsored-text,.${(0,l.nP)("ad-slug")} .${(0,l.nP)("sponsored-text")}{border:unset !important;padding:unset !important}[size="_2x_2y"] .ad-slug,[size="_2x_2y"] .${(0,l.nP)("ad-slug")}{max-width:calc(${d.QG} * 2px - 100px);
    }

    :host(.infopane-slide) .ad-slug .ad-label, [size="_2x_2y"] .ad-slug .ad-label, :host(.infopane-slide) .${(0,l.nP)("ad-slug")} .${(0,l.nP)("ad-label")}, [size="_2x_2y"] .${(0,l.nP)("ad-slug")} .${(0,l.nP)("ad-label")}{border:0.5px solid rgba( 255,255,255,.3)}.ad-slug .ad-label.ad-label-hidden,.${(0,l.nP)("ad-slug")} .ad-label.ad-label-hidden{
        max-width: 0px;
        min-width: 0px;
        visibility: hidden;
        width: 0;
        padding: 0;
        margin: 0;
        border: 0;
    }
`,n=o.A`
    .ad-slug .ad-label, .${(0,l.nP)("ad-slug")} .${(0,l.nP)("ad-label")}{border:0.5px solid rgba(255,255,255,.3);opacity:0.9}`},61820(e,a,t){t.r(a),t.d(a,{registerCsNativeAdCardIntraArticleLeftImage(){return V}});var i=t(57415),r=t(65614),d=t(96950),o=t(69259),l=t(14475),s=t(77793),n=t(74657);const p=d.qy`<div class="ad-provider" slot="attribution">${(0,o.z)(e=>e.logoImageUrl,d.qy`${n.I}`)}<a class="ad-provider-text ad-provider-name" href="${e=>e.destinationUrl}" target="${l.z._blank}" title="${e=>e.providerName}" ${(0,s.Ib)(!0,!1)} data-t="${e=>{var a;return null===(a=e.adTelemetryContext)||void 0===a||null===(a=a.destination)||void 0===a?void 0:a.getMetadataTag()}}">${e=>e.providerName}</a></div>`;var x=t(54929),g=t(8481),c=t(3817),$=t(28160),u=t(57709),h=t(30163),b=t(36109);const v=d.qy`<span class="card-title intra-article"><span class="ad-provider-name">${e=>e.providerName}</span><span class="ad-title">${e=>e.title}</span></span>`;var m=t(24277),f=t(46983);const w=d.qy`<div class="${e=>(0,m.s4)(e.enableSafeAds,"ad-slug")}" slot="footer-start">${(0,o.z)(e=>e.showAdLabel,d.qy`<div class="${e=>_(e)} ${e=>(0,m.s4)(e.enableSafeAds,"ad-label")} ${e=>(0,m.s4)(e.enableAdSponsoredText,"sponsored-text")}"><a class="${e=>(0,m.s4)(e.enableSafeAds,"ad-label-text")}" href="${e=>(0,f.lW)(e)}" @click="${(e,a)=>!e.enableAdCardClickCbInAdSlug||!e.adCardClickCallback||e.adCardClickCallback(a.event,(0,f.lW)(e))}" target="${l.z._blank}" title="${e=>(0,f.jj)()?e.localizedStrings&&e.localizedStrings.nativeAdAdLabelText:""}" data-t="${e=>(0,f.j1)(e.adTelemetryContext)}" ${(0,s.Ib)(!0,!1)}>${e=>e.adLabelText}</a></div>`)}</div>`,_=e=>e.hideAdLabelAndAdChoice?"ad-label-hidden":"";var y=t(40331),z=t(6721),k=t(22977),I=t(62096),S=t(297),E=t(56930),U=t(33273),A=t(40073),C=t(62128),M=t(75988),L=t(2713),N=t(16077),X=t(56237),j=t(74849),q=t(22131),B=t(58914),D=t(12640),F=t(57403);const G=j.A` :host{height:144px;background:white;border:none;border-radius:12px}[size="_2x_1y"] .card-title{font-size:20px;line-height:28px;font-family:"Segoe UI","Segoe UI Midlevel",sans-serif;font-weight:600;letter-spacing:normal;text-align:start;color:var(--neutral-foreground-1-rest)}[size="_2x_1y"] .native-ad-logo{margin-inline-end:calc(var(--design-unit) * 2px)}[size="_2x_1y"] .ad-provider{margin-bottom:0px}[size="_2x_1y"] .ad-provider-name{font-family:"Segoe UI","Segoe UI Midlevel",sans-serif;text-align:start;font-size:12px;font-weight:400;line-height:16px;margin-bottom:8px;align-self:start;display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;-webkit-line-clamp:1}[size="_2x_1y"] .ad-title{display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;-webkit-line-clamp:2;margin-bottom:0.8em}[size="_2x_1y"] ::part(content){grid-template-columns:minmax(auto,96px) 1fr;grid-template-rows:79px 1fr;height:144px}:host([size="_2x_1y"]) ::slotted([slot="media"]){grid-area:1 / 1 / 1 / 2;height:112px;width:214px}[size="_2x_1y"] ::part(text){grid-area:1 / 2 / 3 / 4}[size="_2x_1y"] ::part(text) ::part(heading){margin-top:-10px}[size="_2x_1y"] ::part(media-overlay){grid-area:1 / 1 / 1 / 2;height:112px;width:214px}:host [size="_2x_1y"] .card-image{grid-area:1 / 1 / 1 / 2 !important;height:112px !important;width:214px !important}[size="_2x_1y"] ::part(action-tray){grid-area:2 / 2 / 3 / 4;height:16px;align-self:end}.ad-choice{width:16px;text-align:center}:host .card-image{height:142px !important;width:142px !important;grid-area:1 / 1 / auto / auto !important}:host .card-outer{background:white;border-radius:12px}@media screen and (forced-colors:active){:host .card-outer{border:1px solid var(--neutral-stroke-2-rest,#E0E0E0)}}${z.X}
    ${k.B}
    ${I.J}
    ${S.T}
    ${E.p}
    ${U.O}
    ${A.W}
    ${C.u}
    ${M.p}
    ${L.t}
    ${N.H}
    ${B.V}
    ${X.x}
    ${F.l}
`.withBehaviors(new D.N(null,z.c),new D.N(null,F.G),(0,q.G2)(j.A` [size="_2x_1y"] .ad-provider-name{color:white}:host .card-outer{background:#292929;border-radius:12px}:host .card-outer.card-full-size{box-shadow:0 0 0 calc(var(--stroke-width) * 1px) rgba(255,255,255,0.1),0px 2px 4px rgba(255,255,255,0.04)}`));var H=t(60018),J=t(61447);const K=d.qy`
    ${(0,o.z)(e=>e.logoImageUrl,p,x.N)}
`,O=d.qy`
    ${(0,o.z)(e=>e.logoImageUrl,g.B2,v)}
`,P=d.qy`
    ${(0,o.z)(e=>e.callToAction,J.c)}
    ${(0,o.z)(e=>!e.callToAction,c.$n)}
`,Q=d.qy`
    ${(0,o.z)(e=>e.callToAction,d.qy`${c.IK}${w}`)}
    ${(0,o.z)(e=>!e.callToAction,d.qy`${w}`)}
`;class R extends y.q{}const T=R.compose({name:"cs-native-ad-card-intra-article-left-image",styles:G,template:(0,H.qn)({provider:K,footerEnd:P,footerStart:Q,hideStory:d.qy`${$.Z}`,title:O,description:d.qy`${u.t}`,attribution:d.qy`${h.j}`,assets:d.qy`${b.i}`})}),V=()=>{(0,i.J)(),T.define(r.G.registry)}}}]);