(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["web-components_super-cards_dist_cards_super-carousel_carousel_register_js"],{5675(t,e,i){"use strict";i.d(e,{S(){return o}});var r=i(96950);function o(){return r.qy`
        <template slot="tabpanel" role="tabpanel">
            <slot></slot>
        </template>
    `}},10103(t,e,i){"use strict";i.d(e,{y(){return o}});var r=i(92011);class o extends r.L{}},10461(t,e,i){"use strict";i.d(e,{L(){return c}});var r=i(56911),o=i(92011),a=i(14475),s=i(38493),l=i(60815);const n="1.91:1";class c extends o.L{constructor(){super(...arguments),this.headingLevel=2,this.imageAspectRatio=n,this.target=a.z._blank}handleContentCardLinkClick(t){return this.$emit("link-invoked",t),!0}}(0,r.Cg)([(0,s.CF)({attribute:"heading-level",mode:"fromView",converter:s.R$}),(0,r.Sn)("design:type",Number)],c.prototype,"headingLevel",void 0),(0,r.Cg)([(0,s.CF)({attribute:"image-aspect-ratio"}),(0,r.Sn)("design:type",String)],c.prototype,"imageAspectRatio",void 0),(0,r.Cg)([s.CF,(0,r.Sn)("design:type",Object)],c.prototype,"href",void 0),(0,r.Cg)([s.CF,(0,r.Sn)("design:type",String)],c.prototype,"target",void 0),(0,r.Cg)([l.sH,(0,r.Sn)("design:type",String)],c.prototype,"anchorTelemetryTag",void 0)},10814(t){t.exports='<svg width="48" height="48" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><path d="M4 24a20 20 0 1140 0 20 20 0 01-40 0zm19.87-8.63a1.25 1.25 0 000 1.76l5.61 5.62H15.25a1.25 1.25 0 100 2.5h14.23l-5.61 5.62a1.25 1.25 0 001.76 1.76l7.75-7.75c.5-.48.5-1.28 0-1.76l-7.75-7.75a1.25 1.25 0 00-1.76 0z"></path></svg>'},26813(t,e,i){"use strict";i.d(e,{D(){return v},P(){return u}});var r=i(56911),o=i(60815),a=i(96950),s=i(92011),l=i(38493),n=i(55230),c=i(5096),d=i(50180),p=i(35106),h=i(88458);const u={vertical:"vertical",horizontal:"horizontal"};class v extends s.L{constructor(){super(...arguments),this.orientation=u.horizontal,this.hideActiveIndicator=!1,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=t=>"true"===t.getAttribute("aria-disabled"),this.isFocusableElement=t=>!this.isDisabledElement(t),this.setTabs=()=>{const t="gridColumn",e="gridRow",i=this.isHorizontal()?t:e;this.activeTabIndex=this.getActiveIndex(),this.showActiveIndicator=!1,this.tabs.forEach((r,o)=>{if("tab"===r.slot){const t=this.activeTabIndex===o&&this.isFocusableElement(r);!this.hideActiveIndicator&&this.isFocusableElement(r)&&(this.showActiveIndicator=!0);const e=this.tabIds[o],i=this.tabpanelIds[o];r.setAttribute("id",e),r.setAttribute("aria-selected",t?"true":"false"),r.setAttribute("aria-controls",i),r.addEventListener("click",this.handleTabClick),r.addEventListener("keydown",this.handleTabKeyDown),r.setAttribute("tabindex",t?"0":"-1"),t&&(this.activetab=r)}r.style[t]="",r.style[e]="",r.style[i]=`${o+1}`,this.isHorizontal()?r.classList.remove("vertical"):r.classList.add("vertical")})},this.setTabPanels=()=>{this.tabpanels?.forEach((t,e)=>{const i=this.tabIds[e],r=this.tabpanelIds[e];t.setAttribute("id",r),t.setAttribute("aria-labelledby",i),this.activeTabIndex!==e?(t.setAttribute("tabindex","-1"),t.setAttribute("hidden",""),t.setAttribute("aria-hidden","true")):(t.removeAttribute("tabindex"),t.removeAttribute("hidden"),t.removeAttribute("aria-hidden"))})},this.handleTabClick=t=>{const e=t.currentTarget;1===e.nodeType&&this.isFocusableElement(e)&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(e),this.setComponent())},this.handleTabKeyDown=t=>{if(this.isHorizontal())switch(t.key){case n.kT:t.preventDefault(),this.adjustBackward(t);break;case n.bb:t.preventDefault(),this.adjustForward(t)}else switch(t.key){case n.I5:t.preventDefault(),this.adjustBackward(t);break;case n.HX:t.preventDefault(),this.adjustForward(t)}switch(t.key){case n.kE:t.preventDefault(),this.adjust(-this.activeTabIndex);break;case n.FM:t.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1)}},this.adjustForward=t=>{const e=this.tabs;let i=0;for(i=this.activetab?e.indexOf(this.activetab)+1:1,i===e.length&&(i=0);i<e.length&&e.length>1;){if(this.isFocusableElement(e[i])){this.moveToTabByIndex(e,i);break}if(this.activetab&&i===e.indexOf(this.activetab))break;i+1>=e.length?i=0:i+=1}},this.adjustBackward=t=>{const e=this.tabs;let i=0;for(i=this.activetab?e.indexOf(this.activetab)-1:0,i=i<0?e.length-1:i;i>=0&&e.length>1;){if(this.isFocusableElement(e[i])){this.moveToTabByIndex(e,i);break}i-1<0?i=e.length-1:i-=1}},this.moveToTabByIndex=(t,e)=>{const i=t[e];this.activetab=i,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=e,i.focus(),this.setComponent()}}orientationChanged(){this.$fastController.isConnected&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}activeidChanged(t,e){this.$fastController.isConnected&&(this.tabs.length<=(this.tabpanels?.length??0)||this.tabs.length<=(this.lazyPanels?.length??0))&&(this.prevActiveTabIndex=this.tabs.findIndex(e=>e.id===t),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(){this.$fastController.isConnected&&(this.tabs.length<=(this.tabpanels?.length??0)||this.tabs.length<=(this.lazyPanels?.length??0))&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}lazyPanelsChanged(){this.$fastController.isConnected&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.handleActiveIndicatorPosition())}tabpanelsChanged(){this.$fastController.isConnected&&(this.tabpanels?.length??0)<=this.tabs.length&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):0}getTabIds(){return this.tabs.map(t=>t.getAttribute("id")??`tab-${(0,d.NF)()}`)}getTabPanelIds(){return this.lazyPanels?this.lazyPanels.map(t=>t.id):(this.tabpanels||[]).map(t=>t.getAttribute("id")??`panel-${(0,d.NF)()}`)}setComponent(){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.focusTab(),this.change())}isHorizontal(){return this.orientation===u.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&!this.hideActiveIndicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;const t=this.isHorizontal()?"gridColumn":"gridRow",e=this.isHorizontal()?"translateX":"translateY",i=this.isHorizontal()?"offsetLeft":"offsetTop",r=this.activeIndicatorRef[i];this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`;const o=this.activeIndicatorRef[i];this.activeIndicatorRef.style[t]=`${this.prevActiveTabIndex+1}`;const a=o-r;this.activeIndicatorRef.style.transform=`${e}(${a}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",()=>{this.ticking=!1,this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${e}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")})}adjust(t){const e=this.tabs.filter(t=>!this.isDisabledElement(t)),i=e.indexOf(this.activetab),r=(0,c.AB)(0,e.length-1,i+t),o=this.tabs.indexOf(e[r]);o>-1&&this.moveToTabByIndex(this.tabs,o)}focusTab(){this.tabs[this.activeTabIndex].focus()}connectedCallback(){super.connectedCallback(),this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex()}}(0,r.Cg)([l.CF,(0,r.Sn)("design:type",String)],v.prototype,"orientation",void 0),(0,r.Cg)([l.CF,(0,r.Sn)("design:type",String)],v.prototype,"activeid",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Array)],v.prototype,"tabs",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Array)],v.prototype,"lazyPanels",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",a.kc)],v.prototype,"lazyPanelTemplate",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Array)],v.prototype,"tabpanels",void 0),(0,r.Cg)([(0,l.CF)({attribute:"hide-active-indicator",mode:"boolean"}),(0,r.Sn)("design:type",Object)],v.prototype,"hideActiveIndicator",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",HTMLElement)],v.prototype,"activeIndicatorRef",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Boolean)],v.prototype,"showActiveIndicator",void 0),(0,h.X)(v,p.qw)},27550(t,e,i){"use strict";i.d(e,{w(){return r}});const r={medium:"medium",large:"large",extraLarge:"extra-large",twoExtraLarge:"extra-large-2"}},30326(t,e,i){"use strict";i.d(e,{m(){return m}});var r=i(65614),o=i(74849),a=i(64187),s=i(86856);const l=o.A`
    .scroll-prev {
        right: auto;
        left: 0;
    }

    .scroll.scroll-next::before,
    .scroll-next .scroll-action {
        left: auto;
        right: 0;
    }

    .scroll.scroll-next::before {
        background: linear-gradient(to right, transparent, var(--scroll-fade-next));
    }

    .scroll-next .scroll-action {
        transform: translate(60%, -50%);
    }
`,n=o.A`
    .scroll.scroll-next {
        right: auto;
        left: 0;
    }

    .scroll.scroll-next::before {
        background: linear-gradient(to right, var(--scroll-fade-next), transparent);
        left: auto;
        right: 0;
    }

    .scroll.scroll-prev::before {
        background: linear-gradient(to right, transparent, var(--scroll-fade-previous));
    }

    .scroll-prev .scroll-action {
        left: auto;
        right: 0;
        transform: translate(60%, -50%);
    }
`,c=o.A`
    div.scroll-view {
        overflow-x: hidden;
    }

    .scroll {
        bottom: 0;
        pointer-events: none;
        position: absolute;
        right: 0;
        top: 0;
        user-select: none;
        width: 100px;
    }

    .scroll.disabled {
        display: none;
    }

    .scroll::before,
    .scroll-action {
        left: 0;
        position: absolute;
    }

    .scroll::before {
        background: linear-gradient(to right, var(--scroll-fade-previous), transparent);
        content: "";
        display: block;
        height: 100%;
        width: 100%;
    }

    .scroll-action {
        pointer-events: auto;
        right: auto;
        top: 50%;
        transform: translate(-60%, -50%);
        transition: opacity 0.2s ease-in-out;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    :host([flippers-hidden-from-at="true"]) .scroll-action {
        opacity: 0;
    }

    :host([flippers-hidden-from-at="true"]) .scroll-area:hover .scroll-action {
        opacity: 1;
    }
`.withBehaviors(new s.t(l,n)),d=o.A`
    ${(0,a.V)("block")} :host {
        --scroll-align: center;
        --scroll-item-spacing: 4px;
        contain: layout;
        position: relative;
    }

    .scroll-area {
        position: relative;
        display: flex;
    }

    .scroll-view {
        overflow-x: auto;
        scrollbar-width: none;
        padding: var(--scroll-view-padding, 10px);
        overflow-y: clip;
    }

    ::-webkit-scrollbar {
        display: none;
    }

    .content-container {
        align-items: var(--scroll-align);
        display: inline-flex;
        flex-wrap: nowrap;
        position: relative;
        height: 100%;
    }

    .content-container ::slotted(*) {
        margin-inline-end: var(--scroll-item-spacing);
    }

    .content-container ::slotted(*:last-child) {
        margin-inline-end: 0;
    }
`;var p=i(56911),h=i(96751),u=i(38493),v=i(27550);class g extends h.I{constructor(){super(...arguments),this.flipperSize=v.w.large}connectedCallback(){super.connectedCallback(),"mobile"!==this.view&&this.$fastController.addStyles(c)}get isRTL(){return this.scrollItems.length>1&&this.scrollItems[0].offsetLeft>this.scrollItems[1].offsetLeft}getScrollStops(){return super.getScrollStops()}getCurrentScrollIndex(){const t=this.isRTL,e=this.getScrollStops(),i=this.scrollContainer.scrollLeft;return e.findIndex((r,o)=>r>=i&&(t||o===e.length-1||e[o+1]>i))}getNextScrollIndex(){const t=this.scrollContainer.scrollLeft,e=this.getScrollStops(),i=e.findIndex(e=>Math.abs(e)>=Math.abs(t)),r=e.findIndex(e=>Math.abs(t)+this.getWidth()<=Math.abs(e));let o=i;return r>i+2?o=r-2:i<e.length-2&&(o=i+1),o}getWidth(){return super.getWidth()}}(0,p.Cg)([(0,u.CF)({attribute:"next-telemetry"}),(0,p.Sn)("design:type",String)],g.prototype,"nextTelemetry",void 0),(0,p.Cg)([(0,u.CF)({attribute:"previous-telemetry"}),(0,p.Sn)("design:type",String)],g.prototype,"previousTelemetry",void 0),(0,p.Cg)([(0,u.CF)({attribute:"flipper-size"}),(0,p.Sn)("design:type",String)],g.prototype,"flipperSize",void 0),(0,p.Cg)([(0,u.CF)({attribute:"aria-label-previous"}),(0,p.Sn)("design:type",String)],g.prototype,"ariaLabelPrevious",void 0),(0,p.Cg)([(0,u.CF)({attribute:"aria-label-next"}),(0,p.Sn)("design:type",String)],g.prototype,"ariaLabelNext",void 0);var x=i(99015),b=i(96950);const f=(0,x.Y)({nextFlipper:b.qy`
            <cs-flipper
                size="${t=>t.flipperSize}"
                @click="${t=>t.scrollToNext()}"
                aria-hidden="${t=>t.flippersHiddenFromAT}"
                aria-label="${t=>t.ariaLabelNext||"next"}"
                data-t="${t=>t.nextTelemetry}"
                part="next-flipper"
            >
                <slot name="next" slot="next"></slot>
            </cs-flipper>
        `,previousFlipper:b.qy`
            <cs-flipper
                size="${t=>t.flipperSize}"
                @click="${t=>t.scrollToPrevious()}"
                direction="previous"
                aria-hidden="${t=>t.flippersHiddenFromAT}"
                aria-label="${t=>t.ariaLabelPrevious||"previous"}"
                data-t="${t=>t.previousTelemetry}"
                part="previous-flipper"
            >
                <slot name="previous" slot="previous"></slot>
            </cs-flipper>
        `}),m=g.compose({name:`${r.G.prefix}-horizontal-scroll`,styles:d,template:f})},32288(t,e,i){"use strict";i.d(e,{$w(){return r},Gn(){return c},KR(){return l},Sv(){return o},TR(){return C},U8(){return $},Ug(){return h},Uq(){return z},Wm(){return k},XA(){return f},Z7(){return w},b9(){return d},f$(){return u},g_(){return m},hA(){return a},jL(){return n},ke(){return y},o7(){return s},oB(){return x},r(){return g},ti(){return b},x3(){return p},yQ(){return v}});const r=240,o=126,a=300,s=225,l=260,n=140,c=300,d=225,p=262,h=290,u=270,v=240,g=336,x=240,b="cs-article-card-carousel",f="cs-general-carousel-card",m="cs-video-carousel-card",$="cs-article-card-carousel-no-hover",w="cs-article-card-carousel-no-hover-dense",y="cs-games-carousel-card",k="cs-games-carousel-prong2-card",C="cs-games-carousel-stripe-card",z="cs-watch-carousel-card"},42393(t){t.exports='<svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg"><path d="M7.35 2.15c.2.2.2.5 0 .7L4.21 6l3.14 3.15a.5.5 0 11-.7.7l-3.5-3.5a.5.5 0 010-.7l3.5-3.5c.2-.2.5-.2.7 0z"></path></svg>'},48620(t){t.exports='<svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg"><path d="M4.65 2.15a.5.5 0 000 .7L7.79 6 4.65 9.15a.5.5 0 10.7.7l3.5-3.5a.5.5 0 000-.7l-3.5-3.5a.5.5 0 00-.7 0z"></path></svg>'},50611(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6.25 10a1.25 1.25 0 11-2.5 0 1.25 1.25 0 012.5 0zm5 0a1.25 1.25 0 11-2.5 0 1.25 1.25 0 012.5 0zM15 11.25a1.25 1.25 0 100-2.5 1.25 1.25 0 000 2.5z"></path></svg>'},52718(t,e,i){"use strict";i.d(e,{S(){return je}});var r=i(97823),o=i(56911),a=i(10910),s=i(3065),l=i(10809),n=i(85349),c=i(52356),d=i(26813),p=i(60815),h=i(38493),u=i(13312);class v extends d.D{constructor(){super(...arguments),this.tabs=[],this.tabpanels=[],this.showTabs=!0,this.layout=u._4.C4,this.activeindicator=!1,this.hideActiveIndicator=!0}connectedCallback(){super.connectedCallback(),this.showActiveIndicator=!1,this.horizontalScroll&&(this.horizontalScroll.keyupHandler=this.horizontalScrollKeyUp)}tabpanelsChanged(){this.tabpanels&&(1!==this.tabpanels.length?this.showTabs=!0:(this.showTabs=!1,this.tabs=[])),super.tabpanelsChanged()}horizontalScrollKeyUp(t){return!1}activeidChanged(t,e){super.activeidChanged(t,e),this.horizontalScroll.scrollInView(this.activetab)}}(0,o.Cg)([p.sH,(0,o.Sn)("design:type",Array)],v.prototype,"tabs",void 0),(0,o.Cg)([p.sH,(0,o.Sn)("design:type",Array)],v.prototype,"tabpanels",void 0),(0,o.Cg)([p.sH,(0,o.Sn)("design:type",Boolean)],v.prototype,"showTabs",void 0),(0,o.Cg)([h.CF,(0,o.Sn)("design:type",String)],v.prototype,"layout",void 0),(0,o.Cg)([(0,h.CF)({attribute:"next-tab-telemetry"}),(0,o.Sn)("design:type",String)],v.prototype,"nextTabTelemetry",void 0),(0,o.Cg)([(0,h.CF)({attribute:"previous-tab-telemetry"}),(0,o.Sn)("design:type",String)],v.prototype,"previousTabTelemetry",void 0);var g=i(95718),x=i.n(g),b=i(19702),f=i.n(b),m=i(83222),$=i(94043),w=i(89064);class y extends v{constructor(){super(...arguments),this.isActionMenuOpen=!1,this.actionMenuContent=[],this.flatTelemetryTags={},this.selfTelemetryTag="",this.handleLayoutChanges=t=>{switch(t){case"c1":this.layout=u._4.C1;break;case"c2":this.layout=u._4.C2;break;case"c3":this.layout=u._4.C3;break;case"c4":default:this.layout=u._4.C4;break;case"c5":this.layout=u._4.C5}},this.handleClickForActionMenu=t=>{var e;t&&this.actionsMenuButtonElement&&this.actionsMenuButtonElement.contains((t.path||(null===(e=t.composedPath)||void 0===e?void 0:e.call(t)))[0])||this.toggleActionMenu(null)},this.handleKeyDownForActionMenu=t=>{"Escape"!==t.code||this.toggleActionMenu(!1,null)},this.getBaseActionMenuItems=()=>{var t;if(!this.data||!this.data.headerData)return[];if(this.actionMenuContent.length>0)return this.actionMenuContent;const e=null===(t=this.data.headerData)||void 0===t?void 0:t.actionMenuData,i=[],r=this.data.parentTelemetryObject,o=e.items||[];if(e){var a,s;if(e.hideCallback)i.push({id:"hide",glyph:x(),title:null===(a=this.strings)||void 0===a?void 0:a.hideCardTitle,ariaLabel:"hide-card",async onClick(){e.hideCallback()},telemetryTag:e.hideTelemtryTag||(null==r?void 0:r.addOrUpdateChild({...null==r?void 0:r.contract,name:"hidecard",action:n.EG.Click,behavior:n.MS.Hide,type:n.MJ.ActionButton}).getMetadataTag())});if(e.moreSettingsCallback)i.push({id:"more",glyph:f(),title:null===(s=this.strings)||void 0===s?void 0:s.moreSettingsTitle,ariaLabel:"more-settings",async onClick(){e.moreSettingsCallback()},telemetryTag:e.moreSettingsTelemetryTag||(null==r?void 0:r.addOrUpdateChild({...null==r?void 0:r.contract,name:"moresettings",action:n.EG.Click,behavior:n.MS.Navigate,type:n.MJ.ActionButton}).getMetadataTag())})}return o.length>0?(o.push({isDivider:!0}),this.actionMenuContent=[...o,...i]):this.actionMenuContent=[...i],this.actionMenuContent}}connectedCallback(){var t;this.config=l.D.getConfig(),this.strings=l.D.getLocStrings(),this.showAdSlugs=this.showAdSlugs||(null===(t=this.data)||void 0===t||null===(t=t.headerData)||void 0===t?void 0:t.showAdSlugs),this.selfTelemetryTag=new m.$({name:"SuperCarousel"}).getMetadataTag(),super.connectedCallback(),(0,$.S)()&&(0,a._Z)(this).then(()=>{c.y.subscribeThemeChange(this),(0,s.TU)()&&(this.handleLayoutChanges((0,s.TU)().currentColumnArrangement),(0,s.TU)().subscribe(this.handleLayoutChanges))})}disconnectedCallback(){super.disconnectedCallback(),c.y.unsubscribeThemeChange(this)}toggleActionMenu(t){let e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],i=arguments.length>2&&void 0!==arguments[2]&&arguments[2];this.isActionMenuOpen=e,e&&t?(this.actionsMenuButtonElement=t&&t.currentTarget,document.addEventListener("click",this.handleClickForActionMenu),document.addEventListener("keydown",this.handleKeyDownForActionMenu)):(this.actionsMenuButtonElement=null,document.removeEventListener("click",this.handleClickForActionMenu),document.removeEventListener("keydown",this.handleKeyDownForActionMenu)),i&&t.stopPropagation()}clickHandler(t,e){var i;return!(t.useMobile&&!t.isMsnMobile)||(t.newsXfeedNavigationHandlerCallback(e.event,null===(i=t.headerData)||void 0===i||null===(i=i.title)||void 0===i?void 0:i.displayText,"",t.enableOneLineMetadataCarousel),!1)}handleThemeChange(t){var e,i,r,o,a,s,l;if(this.data){var n,c,d,p;if((0,w._R)(t,this.data,[null===(e=this.data)||void 0===e?void 0:e.outerCSCard]),this.titleColor=null===(i=this.data)||void 0===i||null===(i=i.headerData)||void 0===i?void 0:i.titleColor,this.titleColorImmersive=null===(r=this.data)||void 0===r||null===(r=r.headerData)||void 0===r?void 0:r.titleColorImmersive,null!==(o=this.data)&&void 0!==o&&null!==(o=o.headerData)&&void 0!==o&&o.titleColorDark||null!==(a=this.data)&&void 0!==a&&null!==(a=a.headerData)&&void 0!==a&&a.titleColorLight)this.titleColor=t?null===(n=this.data)||void 0===n||null===(n=n.headerData)||void 0===n?void 0:n.titleColorDark:null===(c=this.data)||void 0===c||null===(c=c.headerData)||void 0===c?void 0:c.titleColorLight;if(null!==(s=this.data)&&void 0!==s&&null!==(s=s.headerData)&&void 0!==s&&s.titleColorDarkImmersive||null!==(l=this.data)&&void 0!==l&&null!==(l=l.headerData)&&void 0!==l&&l.titleColorLightImmersive)this.titleColorImmersive=t?null===(d=this.data)||void 0===d||null===(d=d.headerData)||void 0===d?void 0:d.titleColorDarkImmersive:null===(p=this.data)||void 0===p||null===(p=p.headerData)||void 0===p?void 0:p.titleColorLightImmersive}}getTelemetryTag(t){if(!this.data||!this.data.parentTelemetryObject)return"";if("self"===t)return this.selfTelemetryTag;if(this.flatTelemetryTags[t])return this.flatTelemetryTags[t];if(this.data.telemetry)this.flatTelemetryTags={...this.data.telemetry},this.data.content.forEach((t,e)=>{this.flatTelemetryTags[`tabNav_${e}`]=t.telemetryTag}),this.data.headerData&&this.data.headerData.actionMenuData&&(this.flatTelemetryTags.actionMenu=this.data.headerData.actionMenuData.telemetryTag);else if(this.data.parentTelemetryObject){const t=this.data.parentTelemetryObject,e=t.getMetadataTag(),i=t.contract,r=t.addOrUpdateChild({...i,name:"title",action:n.EG.Click,behavior:n.MS.Navigate,type:n.MJ.Carousel}).getMetadataTag(),o=t.addOrUpdateChild({...i,name:"seeAll",action:n.EG.Click,behavior:n.MS.Navigate,type:n.MJ.Carousel}).getMetadataTag(),a=t.addOrUpdateChild({...i,name:"seeAllCard",action:n.EG.Click,behavior:n.MS.Navigate,type:n.MJ.Carousel}).getMetadataTag(),s=t.addOrUpdateChild({...i,name:"previousSlideArrow",action:n.EG.Click,behavior:n.MS.Paginate,type:n.MJ.Carousel}).getMetadataTag(),l=t.addOrUpdateChild({...i,name:"nextSlideArrow",action:n.EG.Click,behavior:n.MS.Paginate,type:n.MJ.Carousel}).getMetadataTag(),c=t.addOrUpdateChild({...i,name:"previousTabArrow",action:n.EG.Click,behavior:n.MS.Paginate,type:n.MJ.Carousel}).getMetadataTag(),d=t.addOrUpdateChild({...i,name:"nextTabArrow",action:n.EG.Click,behavior:n.MS.Paginate,type:n.MJ.Carousel}).getMetadataTag(),p=t.addOrUpdateChild({...i,name:"cardActionEllipsis",action:n.EG.Click,behavior:n.MS.More,type:n.MJ.Carousel}).getMetadataTag();this.flatTelemetryTags={carousel:e,nextArrow:l,previousArrow:s,seeMore:o,seeMoreCard:a,tabNext:d,tabPrev:c,title:r,actionMenu:p},this.data.content.forEach((e,r)=>{this.flatTelemetryTags[`tabNav_${r}`]=t.addOrUpdateChild({...i,name:"tabNav",action:n.EG.Click,behavior:n.MS.Refresh,type:n.MJ.Carousel}).getMetadataTag()})}return this.flatTelemetryTags[t]}}(0,o.Cg)([(0,h.CF)({attribute:"show-ad-slugs"})],y.prototype,"showAdSlugs",void 0),(0,o.Cg)([p.sH],y.prototype,"data",void 0),(0,o.Cg)([p.sH],y.prototype,"isActionMenuOpen",void 0),(0,o.Cg)([p.sH],y.prototype,"strings",void 0),(0,o.Cg)([p.sH],y.prototype,"titleColor",void 0),(0,o.Cg)([p.sH],y.prototype,"titleColorImmersive",void 0),(0,o.Cg)([p.sH],y.prototype,"enableScrollPrice",void 0);var k=i(14996),C=i(28986),z=i(48751),_=i(37302),S=i(86856),M=i(41123),A=i(62198),I=i(14701),T=i(8675),F=i(12640),j=i(74849);const B=j.A` .no-hover-carousel-card{left:50%;transform:translateX(-50%)}`,L=j.A` .no-hover-carousel-card{right:50%;transform:translateX(50%)}`,O=j.A` .carouselCard{background:rgba(41,41,41,0.7)}.no-hover-see-more-card .no-hover-carousel-card:hover{box-shadow:none}`,P=j.A` cs-article-card-carousel-no-hover[size="_1x_2y"],cs-article-card-carousel-no-hover-dense[size="_1x_2y"]{width:auto}.no-hover-carousel-card .horizontal::part(part){min-width:300px}.no-hover-carousel-card{min-width:100vw;position:relative;border-radius:0px;display:flex;flex-direction:column;align-items:center}.no-hover-carousel-card .headerIcon{fill:currentColor;height:24px;width:24px}.no-hover-carousel-card .headerIcon > svg{height:24px;width:24px}.no-hover-carousel-card:hover{box-shadow:none}.no-hover-scroll-container{display:flex;flex-diretion:row;overflow-x:scroll;overflow-y:hidden;-ms-overflow-style:none;overflow:-moz-scrollbars-none;width:100%;box-sizing:content-box;padding-inline-start:calc(50% - calc(var(--feed-width)) / 2 * 1px);margin-bottom:0px}.no-hover-immersive-carousel-card .no-hover-scroll-container{margin-bottom:calc(var(--card-base-gap) * -1px)}.no-hover-carousel-spacing{width:calc((50vw - calc(var(--feed-width)) / 2) * 1px);height:100%}.no-hover-scroll-container::-webkit-scrollbar{width:0 !important;display:none}.no-hover-scroll-container.dense-carousel-card{height:282px}.no-hover-carousel-card cs-stripe{grid-template-rows:48px 1fr}.no-hover-carousel-card cs-stripe::part(tab-stripe){width:calc(var(--feed-width) * 1px);margin:0 auto;grid-template-columns:100% 0% 0%;column-gap:0px;min-height:auto}.no-hover-carousel-card cs-stripe cs-stripe-tab-panel cs-horizontal-scroll::part(scroll-view){padding:0px;overflow:auto hidden}.no-hover-carousel-card cs-stripe::part(title-container){width:100%;margin-inline-start:0px}.no-hover-carousel-card cs-stripe::part(title){margin-inline-start:12px;--type-ramp-plus-3-font-size:18px;height:24px;line-height:24px}.no-hover-carousel-card cs-stripe cs-stripe-tab-panel{padding:0px;margin:0px}.no-hover-carousel-card cs-stripe .seemore-link{height:32px;width:32px}.no-hover-carousel-card cs-stripe::part(more-actions){margin-inline-end:0px}.no-hover-carousel-card cs-stripe .seemore-link svg{fill:${z.l}}.no-hover-dark-mode cs-card.seeMoreCard{background:#262626;--neutral-foreground-rest:#FFFFFF;box-shadow:0px 2px 4px rgba(0,0,0,0.04)}.no-hover-carousel-card cs-card.seeMoreCard{border-radius:12px;margin-bottom:14px;-webkit-tap-highlight-color:transparent;outline:none;-ms-touch-action:manipulation;touch-action:manipulation;margin-right:0px;text-decoration:none}.no-hover-carousel-card cs-card.seeMoreCard:hover{text-decoration:none;box-shadow:none}.no-hover-carousel-card cs-card.seeMoreCard-col-2{margin-inline-end:12px}.no-hover-carousel-card cs-card.seeMoreCard{width:260px;height:288px}.no-hover-immersive-carousel-card cs-card.seeMoreCard{width:298px;height:223px;box-shadow:0px 2px 4px rgba(0,0,0,0.04)}.no-hover-one-line-metadata-carousel cs-card.seeMoreCard{width:240px;height:336px}.no-hover-scroll-container.dense-carousel-card cs-card.seeMoreCard{width:262px;height:270px}.no-hover-one-line-metadata-carousel .title-link{-webkit-tap-highlight-color:transparent;outline:none;-ms-touch-action:manipulation;touch-action:manipulation;-webkit-highlight:none}.no-hover-carousel-scroll-container{--scroll-item-spacing:12px;padding-inline-end:calc(100% - calc(var(--feed-width)) * 1px)}#ShoppingVideoCarouselOuterCard cs-stripe.horizontal{padding:0 calc(50% - calc(var(--feed-width)) / 2 * 1px)}#ShoppingVideoCarouselOuterCard cs-stripe.horizontal cs-stripe-tab-panel{padding-bottom:20px !important}`.withBehaviors(new S.t(B,L),new F.N(null,O));var E=i(4126);const U=j.A`
    ::part(scroll-action-next){
        transform: translate(var(--flipper-transform-next), -50%);
    }

    ::part(scroll-action-previous){
        transform: translate(var(--flipper-transform-prev), -50%);
    }
`,G=j.A`
    ::part(scroll-action-next){
        transform: translate(var(--flipper-transform-prev), -50%);
    }

    ::part(scroll-action-previous){
        transform: translate(var(--flipper-transform-next), -50%);
    }
`,N=j.A` .carouselCard{background:rgba(255,255,255,0.05)}cs-card[type="BingVideoCarousel"] .headerIcon > svg{fill:rgb(255,255,255)}.ad-label-vertical-header-text{border:0.5px solid #fff;color:#fff}:host{--carousel-card-background:#292929;--card-flipper-border-color:#666666}`,R=j.A` .super-stripe-tab-panel.has-infopane{padding-bottom:0}.infopane{height:583px;margin-bottom:var(--infopage-margin-bottom,6px)}.infopane::part(previous-flipper),.infopane::part(next-flipper){opacity:1;box-shadow:rgba(0,0,0,0.14) 0px 4px 8px}.infopane::part(previous-flipper){transform:translate(10%,-84%)}.infopane::part(next-flipper){transform:translate(-10%,-84%)}.previousFlipper,.nextFlipper{user-select:none}.previousFlipper span,.nextFlipper span{display:flex}.infopane::part(navigation){bottom:-3px;height:14px}.infopane::part(tablist){background:transparent}.infopane::part(dot){background:${k.WN}}.bottom-flipper{position:absolute;bottom:var(--bottom-flipper-bottom,7px);width:28px;height:28px;cursor:pointer;border:none;border-radius:50%;display:flex;justify-content:center;align-items:center;background:${C.v8};
        color: ${z.l}}.bottom-flipper svg{fill:currentColor}.bottom-flipper:hover{background:${C.Rg}}.bottom-flipper:active{background:${C.DK}}.bottom-flipper.previous{right:50%;transform:translateX(calc(-100% - 10px))}.bottom-flipper.next{left:50%;transform:translateX(calc(100% + 10px))}`,D=j.A` .extended-title-click-area .title-link::after{content:"";inset:0px;position:absolute}.extended-title-click-area cs-stripe::part(more-actions){z-index:0}`,X=j.A` :host{position:relative;--carousel-card-background:#FFFFFF;--card-flipper-border-color:#D1D1D1}.neutral-background{background:var(--carousel-card-background)}.neutral-background cs-horizontal-scroll::part(next-flipper),.neutral-background cs-horizontal-scroll::part(previous-flipper){border:1px solid var(--card-flipper-border-color)}cs-card.outer-cs-card{flex-direction:column}[size="_1x_2y"],[size="_2x_2y"]{height:100%;width:100%}.title-link{color:${z.l};text-decoration:none}.seemore-link{color:${z.l};
        font-size: ${M.K};
        line-height: ${A.b};text-decoration:none}.headerIcon > svg{height:inherit;width:inherit}cs-card.seeMoreCard{flex-direction:column;justify-content:center}a.seeMoreCardLink{align-items:center;display:flex;fill:currentColor;flex-direction:column;font-size:${M.K};
        gap: 14px;
        line-height: ${M.Z};text-decoration:none}.seemore-link:hover,cs-card.seeMoreCard:hover{text-decoration:underline}.carouselCard{background:rgba(255,255,255,0.7);border-radius:8px;width:240px}.articleContent{width:240px}[t-size="small"]{width:200px}[t-size="large"]{width:280px}cs-watch-carousel-card[t-size="small"]{height:246px}cs-watch-carousel-card.articleContentImmersive[t-size="small"]{height:var(--watch-carousel-small-card-height,246px);width:var(--watch-carousel-small-card-width,var(--article-content-card-width,320px))}.articleContentImmersive{border-radius:8px;height:var(--article-content-card-height,240px);width:var(--article-content-card-width,320px)}.super-horizontal-scroll{--scroll-item-spacing:12px;--flipper-transform-next:60%;--flipper-transform-prev:-60%}.super-stripe-tab-panel{margin:0px;padding-inline:0px}.super-horizontal-scroll > :last-child{margin-inline-end:var(--card-margin-inline-end,16px)}.super-horizontal-scroll > :nth-child(3){margin-inline-start:var(--card-margin-inline-start,16px)}::part(next-flipper),::part(previous-flipper){border-radius:4px;background:${_.F7}}::part(next-flipper):hover,::part(previous-flipper):hover{background:${_.Xt}}::part(next-flipper):active,::part(previous-flipper):active{background:${_.X4}}msn-actions-menu::part(menu-item){font-weight:var(--actions-menu-font-weight,600)}.border-flippers{content-visibility:visible;contain:unset}[layout="C1"]::part(tab-stripe){width:calc(var(--card-base-width,300) * 1px);grid-template-columns:50% 50%}.ad-label-vertical-header{align-items:center;display:flex;flex-flow:column nowrap;justify-content:center;left:10px;position:absolute;top:0;transform:translate(0,50%)}.ad-label-vertical-header-title{color:inherit;font-size:var(--type-ramp-plus-3-font-size);font-weight:600;margin:0;overflow:hidden;text-orientation:upright;writing-mode:vertical-rl}.ad-label-vertical-header-text{border:0.5px solid rgba(26,26,26,.5);border-radius:4px;color:#2b2b2b;font-size:11px;height:16px;margin:10px 0 0;min-width:22px;padding:1px 4px;text-align:center}.ad-info-container{display:inline-flex;gap:8px;height:16px;margin:auto}${P}
    ${D}
    ${R}
`.withBehaviors(new E.o("showAdSlugs",!0,j.A`${I.B} ${T.E}`),new S.t(U,G),new F.N(null,N));var Z=i(32288),H=i(96950),V=i(60402),K=i(39957),W=i(69259),Y=i(66591),q=i(14475),Q=i(50611),J=i.n(Q),tt=i(73182),et=i(10814),it=i.n(et),rt=i(25109),ot=i(18284),at=i(76453),st=i.n(at),lt=i(76014),nt=i.n(lt),ct=i(42393),dt=i.n(ct),pt=i(48620),ht=i.n(pt),ut=i(69781),vt=i(77367),gt=i(98515),xt=i(6637),bt=i(64240);tt.MsnActionsMenu;const ft=H.qy`<fluent-button slot="more-actions" appearance="stealth" id="${t=>t.id}ActionMenu" @click=${(t,e)=>e.parent.toggleActionMenu(e.event,!e.parent.isActionMenuOpen,t.headerData.actionMenuData.skipEventDelegate)} part="action-menu" title="${(t,e)=>e.parent.strings.actionMenuToolTip}" aria-label="${(t,e)=>e.parent.strings.actionMenuToolTip}" data-t="${(t,e)=>e.parent.getTelemetryTag("actionMenu")}">${H.qy.partial(J())}</fluent-button>`,mt=H.qy`<msn-actions-menu :referrerButton=${(t,e)=>e.parent.actionsMenuButtonElement} :menuItems=${(t,e)=>e.parent.getBaseActionMenuItems()} defaulthorizontalposition="start" @dismiss-menu=${t=>t.isActionMenuOpen=!1} data-t="${(t,e)=>e.parent.getTelemetryTag("actionMenu")}"></msn-actions-menu>`,$t=(0,ot.A)(t=>{const e=[Z.ti,Z.XA,Z.Uq],i=[Z.ti,Z.ke,Z.Uq],r=t.cardTagName;let o=e.includes(r)?"carouselCard":"";i.includes(r)&&(t.immersiveCard?o+=" articleContentImmersive":o+=" articleContent"),t.externalCss&&(o=t.externalCss);const a=H.qy.partial(r);return t.instanceSrc?H.qy`<${a} exportparts=${t=>t.exportParts} part="carousel-item" class="${o} carousel-item" t-size="${t=>t.size}" config-instance-src="${t.instanceSrc}" :data=${t=>t.cardData?t.cardData:t}></${a}>`:H.qy`<${a} exportparts=${t=>t.exportParts} part="carousel-item" class="${o} carousel-item" t-size="${t=>t.size}" :data=${t=>t.cardData?t.cardData:t}></${a}>`}),wt=H.qy`<card-flipper class="previousFlipper" slot="previous-flipper" direction="previous" aria-hidden="false" size=${t=>t.infoPaneflipperSize} data-t="${(t,e)=>e.parentContext.parent.getTelemetryTag("previousArrow")}"><span slot="previous">${H.qy.partial(nt())}</span></card-flipper>`,yt=H.qy`<card-flipper class="nextFlipper" slot="next-flipper" direction="next" aria-hidden="false" size=${t=>t.infoPaneflipperSize} data-t="${(t,e)=>e.parentContext.parent.getTelemetryTag("nextArrow")}"><span slot="next">${H.qy.partial(st())}</span></card-flipper>`,kt=H.qy`<cs-responsive-infopane ${(0,V.K)("infoPaneElement")} class="infopane" media-controls="false" :hasSlideShow=${!1} navigation-position="bottom" transition-strategy="position">${(0,K.ux)(t=>t.items,H.qy`${$t}`)} ${wt} ${yt}</cs-responsive-infopane>${(0,W.z)((t,e)=>e.parent.infoPaneBottomControl,H.qy`<button class="bottom-flipper previous" @click="${t=>{var e;return null===(e=t.infoPaneElement)||void 0===e?void 0:e.adjust(-1)}}" data-t="${t=>t.bottomPreviousTelemetry}" part="bottom-previous-flipper">${H.qy.partial(dt())}</button><button class="bottom-flipper next" @click="${t=>{var e;return null===(e=t.infoPaneElement)||void 0===e?void 0:e.adjust(1)}}" data-t="${t=>t.bottomNextTelemetry}" part="bottom-next-flipper">${H.qy.partial(ht())}</button>`)}
`,Ct=t=>{const e=t.immersiveCard,i=t.size,r=t.content;return H.qy`<cs-card class="seeMoreCard carouselCard ${()=>e?"articleContentImmersive":"articleContent"} carousel-item" ${(t,e)=>{var i;return`seeMoreCard-col-${void 0!==(null===(i=e.parent)||void 0===i||null===(i=i.displaySettings)||void 0===i?void 0:i.columnCount)&&H.qy.partial(e.parent.displaySettings.columnCount)}`}} " card-fill-color=${(t,e)=>e.parent&&e.parent.isMobile&&(0,rt.ud)()?"#333":""} part="seemore-card" t-size="${i}"><a class="seeMoreCardLink" href=${r.url} @click="${(t,e)=>{var i;return!(e.parent.useMobile&&!e.parent.isMsnMobile)||(e.parent.newsXfeedNavigationHandlerCallback(e.event,null===(i=e.parent.headerData)||void 0===i||null===(i=i.title)||void 0===i?void 0:i.displayText,"",e.parent.enableOneLineMetadataCarousel),!1)}}" target="${q.z._blank}" data-t="${(t,e)=>e.parentContext.parent.getTelemetryTag("seeMoreCard")}">${H.qy.partial(it())} ${r.displayText}</a></cs-card>`},zt=H.qy` ${(0,W.z)((t,e)=>e.parent.content.length>=2&&t.tabName,H.qy`<cs-stripe-tab data-t="${t=>t.telemetryTag}">${t=>t.tabName}</cs-stripe-tab>`)} ${(t,e)=>{return i=e,H.qy`<cs-stripe-tab-panel part="stripe-tab-panel" class="super-stripe-tab-panel ${(t,e)=>e.parent&&e.parent.useInfoPane?"has-infopane":""}">${i.parent&&i.parent.isMobile?H.qy`<div class="no-hover-scroll-container ${(t,e)=>e.parent&&e.parent.immersiveCard?"no-hover-immersive-scroll-container":""} ${(t,e)=>e.parent&&e.parent.isDarkMode?"no-hover-dark-mode":""} ${(t,e)=>e.parent&&e.parent.enableDenseCarouselCard?"dense-carousel-card":""}"><cs-horizontal-scroll exportparts="scroll-view, content-container, scroll-action-previous, scroll-action-next, carousel-item, next-flipper, previous-flipper" class="no-hover-carousel-scroll-container" speed=${(t,e)=>e.parent.scrollSpeed||4e3} next-telemetry="${(t,e)=>e.parentContext.parent.getTelemetryTag("nextArrow")}" previous-telemetry="${(t,e)=>e.parentContext.parent.getTelemetryTag("previousArrow")}" view="mobile"><slot name="previous-tab-glyph" slot="previous">${H.qy.partial(nt())}</slot><slot name="next-tab-glyph" slot="next">${H.qy.partial(st())}</slot>${(0,K.ux)(t=>t.items,H.qy`${$t}`)} ${(0,W.z)((t,e)=>e.parent.seeMore&&e.parent.seeMore.showCard,H.qy`${(t,e)=>Ct(e.parent.seeMore)}`)}<div class="no-hover-carousel-spacing"></div></cs-horizontal-scroll></div>`:H.qy` ${(t,e)=>e.parent&&e.parent.useInfoPane?kt:H.qy`<cs-horizontal-scroll exportparts="scroll-view, content-container, scroll-action-previous, scroll-action-next, carousel-item, next-flipper, previous-flipper" class="super-horizontal-scroll" speed=${(t,e)=>e.parent.scrollSpeed||4e3} next-telemetry="${(t,e)=>e.parentContext.parent.getTelemetryTag("nextArrow")}" previous-telemetry="${(t,e)=>e.parentContext.parent.getTelemetryTag("previousArrow")}"><slot name="previous-tab-glyph" slot="previous">${H.qy.partial(nt())}</slot><slot name="next-tab-glyph" slot="next">${H.qy.partial(st())}</slot>${(0,K.ux)(t=>t.items,H.qy`${$t}`)} ${(0,W.z)((t,e)=>e.parent.seeMore&&e.parent.seeMore.showCard,H.qy`${(t,e)=>Ct(e.parent.seeMore)}`)}</cs-horizontal-scroll>`} `}</cs-stripe-tab-panel>`;var i}}
`,_t=H.qy`<span slot="more-actions" class="ad-info-container">${(t,e)=>(0,gt.Q)({href:t.headerData.adLabelUrl,telemetryTag:e.parent.getTelemetryTag("adLabel"),text:t.headerData.adLabelText})} ${(t,e)=>(0,xt.$)({href:t.headerData.adChoiceUrl,telemetryTag:e.parent.getTelemetryTag("adChoice"),text:t.headerData.adChoiceText})}</span>`,St=H.qy`<cs-stripe exportparts="tab-stripe, title-container, more-actions, title, tabpanel" class="horizontal ${t=>t.enableOneLineMetadataCarousel&&"no-hover-one-line-metadata-carousel"}" orientation="horizontal" style="--feed-width: ${t=>{var e,i,r;return`calc(${(null===(e=t.displaySettings)||void 0===e?void 0:e.cardWidth)*(null===(i=t.displaySettings)||void 0===i?void 0:i.columnCount)} + (${(null===(r=t.displaySettings)||void 0===r?void 0:r.columnCount)-1} * var(--card-base-gap)))`}}" data-t="${(t,e)=>e.parent.getTelemetryTag("carousel")}" next-tab-telemetry="${(t,e)=>e.parent.getTelemetryTag("tabNext")}" previous-tab-telemetry="${(t,e)=>e.parent.getTelemetryTag("tabPrev")}" layout="${(t,e)=>e.parent.layout}"><slot slot="previous-tab-glyph" name="flipper-previous">${H.qy.partial(nt())}</slot><slot slot="next-tab-glyph" name="flipper-next">${H.qy.partial(st())}</slot>${t=>t.headerData&&t.headerData.title&&t.headerData.title.url?H.qy`<a slot="icon" class="headerIcon" id="${t=>t.id}Icon" href=${t=>t.headerData.title.url} @click="${(t,e)=>e.parent.clickHandler(t,e)}" target="${q.z._blank}" part="header-icon" style="margin-top: ${t=>t.enableOneLineMetadataCarousel&&"-8px"}" data-t="${(t,e)=>e.parent.getTelemetryTag("title")}" aria-labelledby = "${t=>t.id}Title">${t=>H.qy`${H.qy.partial(t.headerData.headerLogo)}`}</a><a class="title-link" id="${t=>t.id}Title" href=${t=>t.headerData.title.url} @click="${(t,e)=>e.parent.clickHandler(t,e)}" style="color: ${(t,e)=>t.immersiveCard?e.parent.titleColorImmersive:e.parent.titleColor}" target="${q.z._blank}" data-t="${(t,e)=>e.parent.getTelemetryTag("title")}">${t=>t.headerData.title.displayText}</a>`:H.qy`<div slot="icon" class="headerIcon" part="header-icon" style="margin-top: ${t=>t.enableOneLineMetadataCarousel&&"-8px"};" class="${t=>(null==t?void 0:t.enableNewUiInChineseMarket)&&"headerIconNone"}}" @click="${(t,e)=>{var i,r;return null===(i=t.headerData)||void 0===i||null===(i=i.title)||void 0===i||!i.titleClickOverride||(null===(r=t.headerData)||void 0===r||null===(r=r.title)||void 0===r||r.titleClickOverride(e.event),!1)}}">${t=>H.qy`${H.qy.partial(t.headerData.headerLogo)}`}</div><span class="title-link" id="${t=>t.id}Title" @click="${(t,e)=>{var i,r;return t.isMobile?(t.newsXfeedNavigationHandlerCallback(e.event,null===(i=t.headerData)||void 0===i||null===(i=i.title)||void 0===i?void 0:i.displayText,"",t.enableOneLineMetadataCarousel),!1):!t.headerData.title.titleClickOverride||(null===(r=t.headerData)||void 0===r||null===(r=r.title)||void 0===r||r.titleClickOverride(e.event),!1)}}" style="color: ${(t,e)=>t.immersiveCard?e.parent.titleColorImmersive:e.parent.titleColor};">${t=>t.headerData.title.displayText}</span>`} ${(0,W.z)(t=>{var e,i;return null!=(null===(e=t.headerData)||void 0===e||null===(e=e.adLabel)||void 0===e?void 0:e.value)&&""!=(null===(i=t.headerData)||void 0===i||null===(i=i.adLabel)||void 0===i?void 0:i.value)&&!(null!=t&&t.enableNewUiInChineseMarket)},H.qy`<div class="ad-label-supergaming" style="${t=>{var e;return null===(e=t.headerData)||void 0===e||null===(e=e.adLabel)||void 0===e?void 0:e.style}}"><span class="ad-label-text-supergaming">${t=>{var e;return null===(e=t.headerData)||void 0===e||null===(e=e.adLabel)||void 0===e?void 0:e.value}}</span></div>`)} ${(0,K.ux)(t=>t.content,H.qy`${()=>zt}`)} ${(0,W.z)(t=>t.headerData.showAdSlugs,_t)} ${(0,W.z)(t=>t.seeMore&&t.seeMore.showHeader,H.qy`<a slot="more-actions" class="seemore-link" part="seemore-link" id="${t=>t.id}SeeMoreHeader" href=${t=>t.seeMore.content&&t.seeMore.content.url} target="${q.z._blank}" data-t="${(t,e)=>e.parent.getTelemetryTag("seeMore")}">${t=>t.seeMore.content&&t.seeMore.content.displayText}</a>`)} ${(0,W.z)(t=>t.headerData.actionMenuData&&!t.isMobile,ft)} ${(0,W.z)((t,e)=>e.parent.isActionMenuOpen,mt)}</cs-stripe>${(0,W.z)(t=>null==t?void 0:t.enableNewUiInChineseMarket,H.qy`<div class="ad-label-vertical-header" :style="${(t,e)=>{var i;return`left: ${null===(i=e.parent)||void 0===i?void 0:i.textPosition}px`}}"><p class="ad-label-vertical-header-title">${t=>t.headerData.title.displayText}</p>${(0,W.z)(t=>{var e;return null===(e=t.headerData)||void 0===e||null===(e=e.adLabel)||void 0===e?void 0:e.value},H.qy`<p class="ad-label-vertical-header-text">${t=>{var e;return null===(e=t.headerData)||void 0===e||null===(e=e.adLabel)||void 0===e?void 0:e.value}}</p>`)}</div>`)}<slot name="additional-content"></slot>`,Mt=H.qy`<cs-card id="${t=>t.id}OuterCard" type="${t=>t.id}" part="outer-card" size="${t=>t.cardSize}" card-fill-color="${(t,e)=>{var i;return null!==(i=e.parent.config)&&void 0!==i&&i.useNeutralCarouselBg?void 0:t.cardFillColor}}" card-secondary-color="${(t,e)=>{var i;return null!==(i=e.parent.config)&&void 0!==i&&i.useNeutralCarouselBg?void 0:t.cardSecondaryColor}}" gradient-angle="${t=>t.gradientAngle}" class="${(t,e)=>{var i;return(0,Y.x)("outer-cs-card border-flippers",["no-hover-carousel-card",t.isMobile],["neutral-background",null===(i=e.parent.config)||void 0===i?void 0:i.useNeutralCarouselBg],["extended-title-click-area",t.headerData.extendedTitleClickArea])}}" data-t="${(t,e)=>e.parent.getTelemetryTag("self")}" @mouseenter=${(t,e)=>{e.event&&It(e.event.currentTarget)}} @mouseleave=${(t,e)=>{e.event&&Tt(e.event.currentTarget)}} ${(0,V.K)("outerCSCard")}>${St}</cs-card>`,At=H.qy`
${(0,W.z)(t=>t.data,H.qy` ${(0,K.ux)(t=>[t.data],H.qy` ${t=>t.immersiveCard?H.qy`<div class="no-hover-carousel-card no-hover-immersive-carousel-card  ${t=>t.headerData.extendedTitleClickArea&&"extended-title-click-area"}" data-t="${(t,e)=>e.parent.getTelemetryTag("self")}">${St}</div>`:Mt} `)} ${bt.$p} `)}`,It=t=>{(0,ut.kM)("SuperCarousel",()=>vt.YT.sendActionEvent(t,n.EG.Hover,n.MS.Open))},Tt=t=>{(0,ut.pS)("SuperCarousel",()=>vt.YT.sendActionEvent(t,n.EG.MouseLeave,n.MS.Open))},Ft=y.compose({name:"cs-carousel",styles:X,template:At});var jt=i(65614),Bt=i(10461),Lt=i(42792),Ot=i(7896),Pt=i(64003),Et=i(89580),Ut=i(64187),Gt=i(22131);const Nt=j.A`
    ${Lt.e}

    ${(0,Ut.V)("grid")} :host {
        grid-template-rows: auto 1fr;
        font-family: ${Ot.O};
        width: 240px;
        height: 100%;
    }

    .content {
        grid-row: 2;
        display: grid;
        grid-template-rows: 1fr auto;
        padding: 10px 16px 12px 16px;
        align-self: end;
        height: 100%;
        box-sizing: border-box;
    }

    ::slotted([slot="metadata"]) {
        color: ${Pt.c};
        font-size: ${M.K};
        line-height: ${M.Z};
        max-height: 20px;
        overflow: hidden;
        display: -webkit-box;
        text-decoration: none;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
        margin-top: 2px;
    }

    ::slotted([slot="image"]) {
        grid-row: 1;
        object-fit: cover;
        width: 100%;
    }

    :host([image-aspect-ratio="1.91:1"]) ::slotted([slot="image"]) {
        height: 126px;
    }

    :host([image-aspect-ratio="1:1"]) ::slotted([slot="image"]) {
        height: 240px;
    }

    :host([image-aspect-ratio="3:4"]) ::slotted([slot="image"]) {
        height: 320px;
    }

    .heading {
        color: ${z.l};
        fill: currentcolor;
        display: -webkit-box;
        outline: 0;
        overflow: hidden;
        text-decoration: none;
        -webkit-line-clamp: var(--heading-max-lines, 3);
        -webkit-box-orient: vertical;
        font-weight: 600;
        font-size: var(--carousel-card-heading-font-size, ${Et.Y});
        line-height: var(--carousel-card-heading-line-height, ${Et.v});
    }

    .heading:after {
        bottom: 0;
        content: "";
        height: 100%;
        left: 0;
        position: absolute;
        right: 0;
        width: 100%;
        z-index: var(--sloppy-click-z-index, 2);
    }
`.withBehaviors((0,Gt.mr)(j.A`
            :host {
                forced-color-adjust: auto;
            }
        `)),Rt=function(t={}){return H.qy`
        <template role="article">
            <div class="image" part="image">
                <slot name="image">${t.image??""}</slot>
            </div>
            <div class="content" part="content">
                <a
                    id="heading"
                    class="heading"
                    part="heading"
                    href="${t=>t.href?t.href:void 0}"
                    target="${t=>t.target?t.target:void 0}"
                    @click=${(t,e)=>t.handleContentCardLinkClick(e.event)}
                    data-t="${t=>t.anchorTelemetryTag}"
                >
                    <span role="heading" aria-level="${t=>t.headingLevel}">
                        <slot></slot>
                    </span>
                </a>
                <slot name="metadata">${t.metadata??""}</slot>
            </div>
        </template>
    `}(),Dt=Bt.L.compose({name:`${jt.G.prefix}-carousel-card`,styles:Nt,template:Rt});var Xt=i(69966),Zt=i(22272);class Ht extends Bt.L{}(0,o.Cg)([p.sH],Ht.prototype,"data",void 0);const Vt=j.A` :host,cs-carousel-card{border-radius:8px;width:100%}`,Kt=H.qy` ${(0,W.z)(t=>t.data,H.qy`${(0,K.ux)(t=>[t.data],H.qy`<cs-carousel-card href=${t=>t.clickUrl} target="${t=>t.target?t.target:q.z._blank}" image-aspect-ratio="${t=>t.imageRatio}" t-data="${t=>t.telemetryTag}"><img slot="image" src=${t=>t.imageData&&t.imageData.source} />${t=>t.title} ${(0,W.z)(t=>t.metadata1,H.qy`<span slot="metadata">${t=>t.metadata1}</span>`)} ${(0,W.z)(t=>t.metadata2,H.qy`<span slot="metadata">${t=>t.metadata2}</span>`)}</cs-carousel-card>`)}`)}
`,Wt=Ht.compose({name:"cs-general-carousel-card",styles:Vt,template:Kt});class Yt extends Bt.L{}(0,o.Cg)([p.sH],Yt.prototype,"data",void 0);const qt="165px",Qt="285px",Jt=j.A`
:host,cs-carousel-card{border-radius:12px}.videoCarousel{width:${qt};
    height: ${Qt};border-radius:12px;overflow:hidden;position:relative;img{width:${qt};
        height: ${Qt};object-fit:cover}.badge{font-weight:700;position:absolute;left:8px;top:8px;background:#E50101;border-radius:6px;color:#fff;font-size:14px;padding:2px 6px;z-index:9;transform:translateZ(10px)}.playIcon{position:absolute;top:120px;left:65px;z-index:9;background:rgba(0,0,0,0.3);width:40px;height:40px;border-radius:50%}.title-container{position:absolute;left:0;right:0;bottom:0;height:65px;padding:20px 10px 0;box-sizing:border-box;z-index:1;color:#fff;transform:translateZ(10px)}.title{height:35px;font-size:12px;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;word-wrap:break-word;font-weight:400;line-height:16px}.mask{position:absolute;inset:0px;background-image:var(--mask-gradient,linear-gradient(to top,rgba(0,0,0,0.8),rgba(0,0,0,0) 120px))}}.merchant-info{display:flex;gap:7px;align-items:center;font-size:12px;height:22px;justify-content:flex-start;.merchant-logo{width:18px;height:18px;border-radius:50%}.merchant-name{overflow:hidden;text-overflow:ellipsis;word-break:break-all;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;white-space:normal;font-weight:700}}.video-Carousel-card{border-radius:8px;.playIcon{position:absolute;top:45px;left:calc(50% - 20px)}.video-duration{position:absolute;top:105px;right:10px;background:rgba(0,0,0,0.7);border-radius:4px;text-align:center;vertical-align:middle;font-size:12px;line-height:14px;padding:0px 4px}.view-count{bottom:77px}}.video-Carousel-card__vertical{border-radius:8px;.playIcon{position:absolute;top:calc(50% - 40px);left:calc(50% - 20px)}.badge{position:absolute;bottom:75px;left:inherit;font-size:12px;background:#E10303;font-weight:600;border-radius:6px;color:#fff;padding:2px 6px}.view-count{bottom:77px}.title-container .title{-webkit-line-clamp:1}}.video-Carousel-card__vertical::part(heading),.video-Carousel-card::part(heading){display:var(--heading-display,block);white-space:var(--heading-white-space,nowrap);color:var(--heading-color,var(--neutral-foreground-rest));overflow:hidden;text-overflow:ellipsis}.video-Carousel-card__vertical .metadata,.video-Carousel-card .metadata{color:var(--metadata-color,var(--neutral-foreground-hint))}.video-Carousel-card__vertical .view-count,.video-Carousel-card .view-count{font-weight:400;font-size:14px;color:white;line-height:20px;background:rgba(0,0,0,0.65);border-radius:6px;padding:2px 6px;display:inline-block;position:absolute;left:10px}.video-Carousel-card .title-container,.video-Carousel-card__vertical .title-container{position:absolute;bottom:10px;right:16px;left:16px}.video-Carousel-card .title-container .title,.video-Carousel-card__vertical .title-container .title{overflow:hidden;text-overflow:ellipsis;word-break:break-all;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;white-space:normal}.video-Carousel-card__vertical .merchant-name,.video-Carousel-card .merchant-name{font-weight:400;font-size:14px;color:#717171;line-height:20px}.live-trailer-container{position:absolute;top:0;left:0;width:100%;height:100%}.live-trailer-container > video{width:100%;height:100%;object-fit:cover}`,te=H.qy`<svg width="16" height="9" viewBox="0 0 16 9" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.9998 2.75346C9.65662 2.75346 10.9998 4.09662 10.9998 5.75345C10.9998 7.41035 9.65662 8.75345 7.9998 8.75345C6.34292 8.75345 4.99978 7.41035 4.99978 5.75345C4.99978 4.09662 6.34292 2.75346 7.9998 2.75346ZM7.9998 3.87845C6.96428 3.87845 6.12478 4.71792 6.12478 5.75345C6.12478 6.78897 6.96428 7.62845 7.9998 7.62845C9.03533 7.62845 9.8748 6.78897 9.8748 5.75345C9.8748 4.71792 9.03533 3.87845 7.9998 3.87845ZM7.9998 0.125C11.4599 0.125 14.4469 2.48751 15.2756 5.7983C15.3511 6.09965 15.1679 6.40513 14.8666 6.48058C14.5651 6.55595 14.2597 6.37288 14.1843 6.07145C13.4801 3.25847 10.9408 1.25 7.9998 1.25C5.05748 1.25 2.51735 3.2602 1.81442 6.0749C1.73915 6.37625 1.4338 6.55955 1.1324 6.48433C0.830993 6.40903 0.647678 6.1037 0.722948 5.80228C1.55027 2.48954 4.53815 0.125 7.9998 0.125Z" fill="white"/></svg>`,ee=H.qy.partial('<svg width="40" height="40" viewBox="0 0 40 40" fill="none"><rect x=".5" y=".5" width="39" height="39" rx="19.5" fill="url(#paint0_linear_1454:59066)"/><g filter="url(#filter0_dd_1454:59066)"><path d="M27.22 18.68a1.5 1.5 0 0 1 0 2.63l-10 5.5A1.5 1.5 0 0 1 15 25.5v-11a1.5 1.5 0 0 1 2.22-1.31l10 5.5Z" fill="#fff"/></g><rect x=".5" y=".5" width="39" height="39" rx="19.5" stroke="url(#paint1_linear_1454:59066)"/><defs><linearGradient id="paint0_linear_1454:59066" x1="1" y1="1" x2="39" y2="39" gradientUnits="userSpaceOnUse"><stop stop-opacity=".5"/><stop offset="1" stop-opacity=".7"/></linearGradient><linearGradient id="paint1_linear_1454:59066" x1="20" y1="1" x2="20" y2="39" gradientUnits="userSpaceOnUse"><stop stop-color="#fff" stop-opacity=".4"/><stop offset="1" stop-color="#fff" stop-opacity=".2"/></linearGradient><filter id="filter0_dd_1454:59066" x="2.8" y="6" width="34.4" height="34.4" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB"><feFlood flood-opacity="0" result="BackgroundImageFix"/><feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset/><feGaussianBlur stdDeviation="1.9"/><feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.11 0"/><feBlend in2="BackgroundImageFix" result="effect1_dropShadow_1454:59066"/><feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/><feOffset dy="3.2"/><feGaussianBlur stdDeviation="3.6"/><feColorMatrix values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.13 0"/><feBlend in2="effect1_dropShadow_1454:59066" result="effect2_dropShadow_1454:59066"/><feBlend in="SourceGraphic" in2="effect2_dropShadow_1454:59066" result="shape"/></filter></defs></svg>'),ie=H.qy` ${(0,W.z)(t=>"LIVE"===t.status,H.qy`<div class="badge">${t=>t.status}</div>`)}
`,re=H.qy`<div class="live-trailer-container"><video class="live-trailer-video" muted="true" playsinline="true" loop type="video/mp4" poster=${t=>{var e;return null===(e=t.imageData)||void 0===e?void 0:e.source}}></video></div>`,oe=H.qy`<img slot="image" src="${t=>{var e;return null===(e=t.imageData)||void 0===e?void 0:e.source}}" alt="${t=>{var e;return null===(e=t.imageData)||void 0===e?void 0:e.title}}"/><div class="playIcon">${ee}</div>${(0,W.z)(t=>t.videoDuration,H.qy`<div class="video-duration" part="image-video-duration"><span class="label">${t=>t.videoDuration}</span></div>`)}
`,ae=H.qy` ${(0,W.z)(t=>t.data,H.qy`${(0,K.ux)(t=>[t.data],H.qy`<cs-carousel-card href="${t=>t.clickUrl}" target="${t=>t.target?t.target:q.z._blank}" part="carousel-card" exportparts="content, image-video-duration" image-aspect-ratio="${t=>t.imageRatio}" :anchorTelemetryTag="${t=>t.telemetry}" data-t="${t=>{var e;return(null===(e=t.telemetry)||void 0===e?void 0:e.destination)??""}}" @click=${t=>window.open(t.clickUrl,"_target")} class="${t=>"1:1"==t.imageRatio?"video-Carousel-card__vertical":"video-Carousel-card"}">${oe} ${(0,W.z)(t=>t.viewCount,H.qy`<div class="view-count"><span class="icon">${te}</span><span class="label">${t=>t.viewCount}</span></div>`)} ${t=>"1:1"==t.imageRatio?ie:""} ${t=>t.title} ${(0,W.z)(t=>t.provider,H.qy`<span slot="metadata" class="metadata">${t=>t.provider.name}</span>`)}</cs-carousel-card>`)}`)}
`,se=H.qy`
${(0,W.z)(t=>t.data,H.qy`${(0,K.ux)(t=>[t.data],H.qy`<cs-carousel-card href="${t=>t.clickUrl}" part="carousel-card" exportparts="content, image-video-duration" @click=${(t,e)=>{var i;return null===(i=t.handleContentCardClickOverride)||void 0===i?void 0:i.call(t,e.event)}} target="${t=>t.target?t.target:q.z._blank}" data-t="${t=>{var e;return(null===(e=t.telemetry)||void 0===e?void 0:e.destination)??""}}" class="videoCarousel">${oe} ${re} ${ie} ${(0,W.z)(t=>!t.hideTitle,H.qy`<div class="title-container"><span class="title" title="${t=>t.title}">${t=>t.title}</span></div>`)}<div class="mask"></div></cs-carousel-card>`)}`)}
`,le=H.qy` ${t=>t.data&&"custom"==t.data.metadata1?se:ae}
`,ne=Yt.compose({name:"cs-video-carousel-card",styles:Jt,template:le});var ce=i(30326),de=i(71157),pe=i(61138),he=i(45476);const ue=j.A`
    ${(0,Ut.V)("grid")} :host {
        box-sizing: border-box;
        font-family: ${Ot.O};
        font-size: ${M.K};
        line-height: ${M.Z};
        font-weight: initial;
        color: ${z.l};
        grid-template-rows: auto 1fr;
        grid-template-columns: 1fr;
        width: 100%;
        --tab-stripe-column-max-width: 50%;
        --title-column-max-width: 25%;
    }

    :host([layout="C1"]) .tab-stripe {
        margin-top: 8px;
        grid-template-columns: 1fr auto;
        grid-template-rows: auto auto;
        justify-content: flex-start;
        align-items: center;
    }

    :host([layout="C2"]) .tab-stripe {
        min-height: 56px;
    }

    :host([layout="C3"]) .tab-stripe {
        min-height: 64px;
    }

    :host([layout="C1"]) .more-actions {
        grid-row: 1;
        grid-column: 2;
    }

    :host([layout="C1"]) .tablist {
        grid-row: 2;
        grid-column: 1 / span 2;
    }

    :host([layout="C1"]) .title {
        font-size: ${M.K};
        line-height: ${M.Z};
    }

    :host([layout="C2"]) .title {
        font-size: ${Et.Y};
        line-height: ${Et.v};
    }

    :host([layout="C3"]) .title {
        font-size: ${de.T};
        line-height: ${de.O};
    }

    :host([layout="C1"]) ::slotted([slot="icon"]) {
        height: 16px;
        width: 16px;
    }

    :host([layout="C2"]) ::slotted([slot="icon"]) {
        height: 20px;
        width: 20px;
    }

    :host([layout="C3"]) ::slotted([slot="icon"]) {
        height: 24px;
        width: 24px;
    }

    .tab-stripe {
        display: grid;
        grid-template-columns:
            var(--title-column-max-width) minmax(auto, var(--tab-stripe-column-max-width))
            var(--title-column-max-width);
        justify-content: center;
        align-items: center;
        column-gap: 12px;
        min-height: 72px;
    }

    .tab-stripe.no-tabs {
        grid-template-columns: 1fr 1fr;
    }

    .more-actions {
        justify-self: end;
        margin-inline-end: 16px;
        display: grid;
        grid-auto-flow: column;
        column-gap: 8px;
        justify-content: center;
    }

    ::slotted([slot="more-actions"]) {
        font-size: ${pe.k};
        line-height: ${pe.F};
    }

    ::slotted(fluent-button[appearance="stealth"]),
    ::slotted(fluent-anchor[appearance="stealth"]) {
        background: transparent;
        --control-corner-radius: 999;
    }

    ::slotted(fluent-button[appearance="stealth"]:hover),
    ::slotted(fluent-anchor[appearance="stealth"]:hover) {
        background-color: ${he.oO};
    }

    ::slotted(fluent-button[appearance="stealth"]:active),
    ::slotted(fluent-anchor[appearance="stealth"]:active) {
        background-color: ${he.wO};
    }

    .title-container {
        margin-inline-start: 16px;
        display: flex;
        align-items: center;
    }

    .title {
        margin-inline-start: 8px;
        font-weight: 600;
        font-size: ${A.a};
        line-height: ${A.b};
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
    }

    .tablist {
        min-width: 0px;
        --scroll-view-padding: 0;
    }

    .tablist::part(scroll-area) {
        justify-content: center;
    }

    .tablist::part(scroll-view) {
        margin: 0 25px;
    }

    .tablist::part(scroll-action-previous),
    .tablist::part(scroll-action-next) {
        transform: translate(0%, -50%);
        box-shadow: none;
    }

    .tablist::part(scroll-action-previous) {
        border-inline-end: 1px solid;
        border-image: linear-gradient(
                to bottom,
                transparent 6px,
                rgba(0, 0, 0, 0.08) 6px,
                rgba(0, 0, 0, 0.08) 26px,
                transparent 26px
            )
            1;
        padding-inline-end: 8px;
    }

    .tablist::part(scroll-action-next) {
        border-inline-start: 1px solid;
        border-image: linear-gradient(
                to bottom,
                transparent 6px,
                rgba(0, 0, 0, 0.08) 6px,
                rgba(0, 0, 0, 0.08) 26px,
                transparent 26px
            )
            1;
        padding-inline-start: 8px;
    }

    .tablist::part(next-flipper),
    .tablist::part(previous-flipper) {
        background: transparent;
    }

    .tablist::part(next-flipper):hover,
    .tablist::part(previous-flipper):hover {
        background: ${C.Rg};
    }

    .tablist::part(next-flipper):active,
    .tablist::part(previous-flipper):active {
        background: ${C.DK};
    }

    .tabpanel {
        grid-row: 2;
        grid-column-start: 1;
        grid-column-end: 4;
        position: relative;
        width: inherit;
    }

    cs-flipper {
        visibility: hidden;
    }

    ::slotted([slot="icon"]) {
        height: 28px;
        width: 28px;
        display: flex;
    }

    :host(:hover) cs-flipper,
    :host(:focus-within) cs-flipper {
        visibility: visible;
    }
`;var ve=i(87656),ge=i(82774);const xe=function(t={}){const e=H.qy.partial((0,ve.g)(ce.m));return H.qy`
        <template class="${t=>t.orientation}">
            <div
                class="tab-stripe ${t=>t.showTabs?"":"no-tabs"}"
                part="tab-stripe"
            >
                <div part="title-container" class="title-container">
                    <slot name="icon">${t?.icon??""}</slot>
                    <span part="title" class="title">
                        <slot></slot>
                    </span>
                </div>
                ${(0,W.z)(t=>!!t.showTabs,H.qy`
                    <${e}
                        ${(0,V.K)("horizontalScroll")}
                        class="tablist"
                        part="tablist"
                        role="tablist"
                        flipper-size="medium"
                        flippers-hidden-from-at
                        next-telemetry="${t=>t.nextTabTelemetry}"
                        previous-telemetry="${t=>t.previousTabTelemetry}"
                    >
                        <slot name="previous-tab-glyph" slot="previous"></slot>
                        <slot name="next-tab-glyph" slot="next"></slot>
                        <slot class="tab" name="tab" part="tab" ${(0,ge.e)("tabs")}></slot>
                    </${e}>
                `)}
                <div part="more-actions" class="more-actions">
                    <slot name="more-actions">${t?.moreActions??""}</slot>
                </div>
            </div>
            <div class="tabpanel" part="tabpanel">
                <slot name="tabpanel" ${(0,ge.e)("tabpanels")}></slot>
            </div>
        </template>
    `}(),be=v.compose({name:`${jt.G.prefix}-stripe`,styles:ue,template:xe});var fe=i(99751),me=i(48196),$e=i(74838),we=i(57416),ye=i(26920),ke=i(73477),Ce=i(50882);const ze=j.A`
    ${(0,Ut.V)("inline-flex")} :host {
        box-sizing: border-box;
        white-space: nowrap;
        font-family: ${Ot.O};
        font-size: ${M.K};
        line-height: ${M.Z};
        font-weight: initial;
        height: calc((${me.D} + (${$e.vR} * 2)) * 1px);
        padding: 0 9px;
        color: ${Pt.c};
        border-radius: calc(${we.Pb} * 1px);
        border: calc(${ye.XA} * 1px) solid transparent;
        align-items: center;
        justify-content: center;
        grid-row: 1 / 3;
        cursor: pointer;
        outline: none;
    }
    :host([aria-selected="true"]) {
        z-index: 2;
        color: ${z.l};
        font-weight: 600;
    }
    :host(:hover),
    :host(:active) {
        color: ${z.l};
    }
    :host(:${ke.N}) {
        border-color: ${k.WN};
        box-shadow: 0 0 0 calc((${ye.vd} - ${ye.XA}) * 1px)
            ${k.WN} inset;
    }
    :host(.vertical) {
        justify-content: start;
        grid-column: 1 / 3;
    }
    :host(.vertical[aria-selected="true"]) {
        z-index: 2;
    }
    :host(.vertical:hover),
    :host(.vertical:active) {
        color: ${z.l};
    }
    :host(.vertical:hover[aria-selected="true"]) {
    }
`.withBehaviors((0,Gt.mr)(j.A`
            :host {
                forced-color-adjust: none;
                border-color: transparent;
                color: ${Ce.A.ButtonText};
                fill: currentcolor;
            }
            :host(:hover),
            :host(.vertical:hover),
            :host([aria-selected="true"]:hover) {
                background: transparent;
                color: ${Ce.A.Highlight};
                fill: currentcolor;
            }
            :host([aria-selected="true"]) {
                background: transparent;
                color: ${Ce.A.Highlight};
                fill: currentcolor;
            }
            :host(:${ke.N}) {
                background: transparent;
                border-color: ${Ce.A.ButtonText};
                box-shadow: none;
            }
        `)),_e=(0,i(60347).M)(),Se=fe.s.compose({name:`${jt.G.prefix}-stripe-tab`,styles:ze,template:_e});var Me=i(10103);const Ae=j.A`
    ${(0,Ut.V)("block")} :host {
        box-sizing: border-box;
        font-family: ${Ot.O};
        font-size: ${M.K};
        line-height: ${M.Z};
        font-weight: initial;
        padding: 0 16px 6px 16px;
    }

    ::slotted(cs-horizontal-scroll) {
        --scroll-view-padding: 0 0 10px 0;
    }
`,Ie=(0,i(5675).S)(),Te=Me.y.compose({name:`${jt.G.prefix}-stripe-tab-panel`,styles:Ae,template:Ie});var Fe=i(31970);const je=()=>{Dt.define(jt.G.registry),Xt.m.define(jt.G.registry),Zt.T.define(jt.G.registry),ce.m.define(jt.G.registry),be.define(jt.G.registry),Se.define(jt.G.registry),Te.define(jt.G.registry),r.r.define(jt.G.registry),Wt.define(jt.G.registry),ne.define(jt.G.registry),Ft.define(jt.G.registry),Fe.G.define(jt.G.registry)}},60347(t,e,i){"use strict";i.d(e,{M(){return a}});var r=i(96950),o=i(35106);function a(t={}){return r.qy`
        <template slot="tab" role="tab" aria-disabled="${t=>t.disabled}">
            ${(0,o.LT)(t)}
            <slot></slot>
            ${(0,o.aO)(t)}
        </template>
    `}},69966(t,e,i){"use strict";i.d(e,{m(){return z}});var r=i(65614),o=i(56911),a=i(84506),s=i(38493),l=i(27550);class n extends a.d{constructor(){super(...arguments),this.size=l.w.medium}}(0,o.Cg)([s.CF,(0,o.Sn)("design:type",String)],n.prototype,"size",void 0);var c=i(28986),d=i(57416),p=i(48751),h=i(48196),u=i(74838),v=i(79288),g=i(14996),x=i(86856),b=i(60993),f=i(73477),m=i(22131),$=i(50882),w=i(74849),y=i(64187);const k=w.A`
    ${(0,y.V)("inline-flex")} :host {
        align-items: center;
        background: ${c.v8};
        border-radius: calc(${d.Pb} * 1px);
        color: ${p.l};
        fill: currentcolor;
        height: calc(${h.D} * 1px);
        justify-content: center;
        outline: none;
        width: calc(${u.vR} * 4px);
    }

    :host([size="large"]) {
        height: calc(${u.vR} * 12px);
        width: calc(${u.vR} * 6px);
    }

    :host([size="extra-large"]) {
        height: calc(${u.vR} * 12px);
        width: calc(${u.vR} * 6.5px);
    }

    :host([size="extra-large-2"]) {
        height: calc(${u.vR} * 12px);
        width: calc(${u.vR} * 7px);
    }

    :host([size="extra-large"]) ::slotted(svg) {
        height: 30px;
        width: 30px;
    }

    :host([size="extra-large-2"]) ::slotted(svg) {
        height: 34px;
        width: 34px;
    }

    ::slotted(svg) {
        height: 16px;
        width: 16px;
    }

    :host([size="large"]) ::slotted(svg) {
        height: 20px;
        width: 20px;
    }

    :host([disabled]) {
        cursor: ${b.Z};
        opacity: ${v.q};
        pointer-events: none;
    }

    .next,
    .previous {
        display: flex;
    }

    :host(:not([disabled]):hover) {
        cursor: pointer;
        background: ${c.Rg};
    }

    :host(:not([disabled]):active) {
        background: ${c.DK};
    }

    :host(:${f.N}) {
        border-color: ${g.WN};
    }

    :host::-moz-focus-inner {
        border: 0;
    }
`.withBehaviors((0,m.mr)(w.A`
            :host {
                background: ${$.A.ButtonFace};
                border-color: ${$.A.ButtonText};
            }
            :host .next,
            :host .previous {
                color: ${$.A.ButtonText};
                fill: currentcolor;
            }
            :host(:not([disabled]):hover) {
                background: ${$.A.Highlight};
            }
            :host(:not([disabled]):hover) .next,
            :host(:not([disabled]):hover) .previous {
                color: ${$.A.HighlightText};
                fill: currentcolor;
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]),
            :host([disabled]) .next,
            :host([disabled]) .previous {
                border-color: ${$.A.GrayText};
                color: ${$.A.GrayText};
                fill: currentcolor;
            }
            :host(:${f.N}) {
                forced-color-adjust: none;
                border-color: ${$.A.Highlight};
                box-shadow: 0 0 0 2px ${$.A.ButtonFace},
                    0 0 0 4px ${$.A.ButtonText};
            }
        `),new x.t(w.A``,w.A`
            :host {
                transform: scaleX(-1);
            }
        `)),C=(0,i(60143).B)(),z=n.compose({name:`${r.G.prefix}-flipper`,styles:k,template:C})},76014(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M13 14.2a1 1 0 01-1.63.78l-4.72-3.81a1.5 1.5 0 010-2.34l4.72-3.81A1 1 0 0113 5.8v8.4z"></path></svg>'},76453(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M7 14.2a1 1 0 001.63.78l4.72-3.81a1.5 1.5 0 000-2.34L8.63 5.02A1 1 0 007 5.8v8.4z"></path></svg>'},87656(t,e,i){"use strict";i.d(e,{g(){return o}});var r=i(7813);function o(t){if("string"==typeof t)return t;if("function"==typeof t&&!(t=r.I.getByType(t)))throw new Error("Missing FASTElement definition.");return t.name}},99015(t,e,i){"use strict";i.d(e,{Y(){return d}});var r=i(96950),o=i(60402),a=i(69259),s=i(82774),l=i(10108),n=i(35106),c=i(18893);function d(t={}){return r.qy`
        <template @keyup="${(t,e)=>t.keyupHandler(e.event)}">
            ${(0,n.LT)(t)}
            <div class="scroll-area" part="scroll-area">
                <div
                    class="scroll-view"
                    part="scroll-view"
                    @scroll="${t=>t.scrolled()}"
                    ${(0,o.K)("scrollContainer")}
                >
                    <div
                        class="content-container"
                        part="content-container"
                        ${(0,o.K)("content")}
                    >
                        <slot
                            ${(0,s.e)({property:"scrollItems",filter:(0,l.Y)()})}
                        ></slot>
                    </div>
                </div>
                ${(0,a.z)(t=>"mobile"!==t.view,r.qy`
                        <div
                            class="scroll scroll-prev"
                            part="scroll-prev"
                            ${(0,o.K)("previousFlipperContainer")}
                        >
                            <div class="scroll-action" part="scroll-action-previous">
                                <slot name="previous-flipper">
                                    ${(0,c.R)(t.previousFlipper)}
                                </slot>
                            </div>
                        </div>
                        <div
                            class="scroll scroll-next"
                            part="scroll-next"
                            ${(0,o.K)("nextFlipperContainer")}
                        >
                            <div class="scroll-action" part="scroll-action-next">
                                <slot name="next-flipper">
                                    ${(0,c.R)(t.nextFlipper)}
                                </slot>
                            </div>
                        </div>
                    `)}
            </div>
            ${(0,n.aO)(t)}
        </template>
    `}},99751(t,e,i){"use strict";i.d(e,{s(){return n}});var r=i(56911),o=i(92011),a=i(38493),s=i(35106),l=i(88458);class n extends o.L{}(0,r.Cg)([(0,a.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],n.prototype,"disabled",void 0),(0,l.X)(n,s.qw)}}]);