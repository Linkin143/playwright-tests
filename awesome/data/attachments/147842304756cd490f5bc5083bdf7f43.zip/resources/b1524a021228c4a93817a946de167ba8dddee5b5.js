"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-standings-rankings"],{4968(e,r,t){t.d(r,{f(){return l}});var a=t(64187),i=t(74849),o=t(42792),n=t(99657),s=t(36452);const l=i.A.partial`position: relative; z-index: ${n.D};`;i.A`
    ${o.e}
    ${o.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},17471(e,r,t){t.r(r),t.d(r,{SportsTable(){return T}});var a=t(56911),i=t(92011),o=t(48751),n=t(62047),s=t(41123),l=t(61138),d=t(86856),c=t(74849),g=t(22131),p=t(4968),h=t(12640);const b=c.A` .table-card{color:rgba(255,255,255,1)}.card-header{color:rgba(255,255,255,1)}.card-header-tag{box-shadow:inset 0px 0px 0px 2px rgba(255,153,164,1)}.card-header-tag >span:nth-of-type(1){background:rgba(255,153,164,1);color:rgba(68,39,38,1)}.card-header-tag >span:nth-of-type(2){background:rgba(68,39,38,1);color:rgba(255,153,164,1)}.table-cell{border-top:1px solid rgba(255,255,255,0.07)}.no-border{border-top:none}.underlay{opacity:0.16}`,x=c.A` .line >img{margin-left:2px}.line >img.extra-margin{margin-left:4px}.line{padding-right:0px;padding-left:4px}.head-cell{padding-right:0px;padding-left:4px}.card-header-tag >span:nth-of-type(2){border-top-right-radius:0;border-bottom-right-radius:0;border-top-left-radius:3px;border-bottom-left-radius:3px}`,f=c.A` .table-container{text-decoration:none}.clickable{${p.f}}.table-card{margin-top:8px;width:268px;height:fit-content;background:none;color:${o.l};border-radius:8px;padding:8px 12px;box-sizing:border-box}.table-card.fill-card{margin-top:0px;padding:0px 12px;background:inherit}.card-header{display:flex;justify-content:space-between;align-items:baseline;padding:0 0 8px;color:${o.l}}.card-header >div{display:flex;font-size:12px;font-weight:600}.card-header-tag{height:18px;line-height:${n.e};box-shadow:inset 0px 0px 0px 4px rgba(196,43,28,1);border-radius:4px;padding:2px 2px;box-sizing:border-box}.card-header-tag >span{display:inline-block;font-size:${n.t};font-weight:600;box-sizing:border-box;padding:0px 2px}.card-header-tag >span:nth-of-type(1){background:rgba(196,43,28,1);color:rgba(255,255,255,1)}.card-header-tag >span:nth-of-type(2){background:rgba(255,255,255,1);color:rgba(196,43,28,1);border-top-right-radius:3px;border-bottom-right-radius:3px}.grid-table{display:grid;width:244px;grid-template-columns:minmax(20px,auto) 1fr minmax(auto,42px) minmax(auto,70px);grid-template-rows:repeat(9,28px)}.table-cell{position:relative;border-top:1px solid rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.line{font-size:${n.t};font-style:normal;font-weight:400;display:flex;align-items:center;padding:0 4px 0 0;width:100%;z-index:1}.line.large-font{font-size:${s.K}}.line > div{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.pre-text{font-size:${n.t};font-weight:600;width:14px;min-width:14px;padding-right:6px}.pre-text.large-font{font-size:${s.K};font-weight:400;width:16px}.head-cell{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;border-top:1px solid rgba(0,0,0,0.06);font-size:${l.k};font-style:normal;font-weight:600;display:flex;align-items:center;padding:0 4px 0 0}.hidden{display:none}.no-border{border-top:none}.overflow{overflow:visible}.line > sup{margin:0 0 4px 1px}.right{justify-content:end}.center{justify-content:center}.left{justify-content:start}.top{align-items:flex-start}.middle{align-items:center}.bottom{align-items:flex-end}.bold{font-weight:600}.line > img{margin-right:2px;height:16px;width:16px}.line > img.extra-margin{margin-right:4px}.iconround > img{border-radius:50%}img.icon-20{height:20px;width:20px;min-width:20px}.line > img.icon-24{height:24px;width:24px;min-width:24px}.font-xs{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.font-s{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.font-m{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.font-l{font-size:var(--smtc-text-ramp-lg-item-body-font-size,16px);line-height:var(--smtc-text-ramp-lg-item-body-line-height,26px)}.align-right{justify-content:flex-end;padding-right:0}.secondary{color:var(--smtc-foreground-ctrl-neutral-secondary-rest,#4c4642)}.underlay{position:absolute;top:-2px;height:calc(100% + 4px);width:100%;background:#0178A7;opacity:0.08}.first-column .underlay{border-radius:12px 0px 0px 12px;width:calc(100% + 4px);left:-4px}.last-column .underlay{border-radius:0px 12px 12px 0px}.no-padding .line,.no-padding .head-cell{padding:0px}.full-width .table-card{width:100%}.cplt .table-card{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320)}`.withBehaviors(new d.t(null,x),new h.N(null,b),(0,g.mr)(c.A` :host{forced-color-adjust:auto}`));var u=t(96950),v=t(39957),m=t(69259);const $=u.qy`
    ${e=>void 0!==e.viewModel.data.title?u.qy`
        <div class="card-header" style="${e=>e.viewModel.headerStyles}">
            <div style="${e=>e.viewModel.data.titleStyles}">${e=>e.viewModel.data.title}</div>
            ${e=>void 0!==e.viewModel.data.subTitle?u.qy`
                <div class="card-header-tag">
                    <span>${e=>e.viewModel.data.tagName}</span>
                    <span>${e=>e.viewModel.data.subTitle}</span>
                </div>`:""}
            ${e=>void 0!==e.viewModel.data.subTitleText?u.qy`
                <div style="${e=>e.viewModel.data.subTitleStyles}">
                    <span>${e=>e.viewModel.data.subTitleText}</span>
                </div>`:""}
        </div>
    `:""}
`,y=u.qy`
    ${(0,v.ux)(e=>e.getHeaderValues(),u.qy`
        <div class="head-cell ${e=>void 0!==e.class?e.class:""}" style="${e=>e.textStyles}">
            ${e=>void 0!==e.icon?u.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null}"
            />`:""}
            ${e=>e.value}
        </div>
    `)}
`,w=u.qy`
    ${(0,v.ux)(e=>e.getAllBodyCells(),()=>u.qy`
    <div class="table-cell ${e=>void 0!==e.cellClass?e.cellClass:""}">
        ${e=>e.isHightlighted?u.qy`<div class="underlay"></div>`:""}
        <div class="line ${e=>void 0!==e.class?e.class:""}">
            ${e=>void 0!==e.preText?u.qy`<div class="pre-text ${e=>void 0!==e.preTextClass?e.preTextClass:""}" style="${e=>e.preTextStyles}">${e.preText}</div>`:""}
            ${e=>void 0!==e.icon?u.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null} ${e=>e.icon?"":"hidden"}"
                onerror="this.style.display='none'"
            />`:""}
            ${e=>u.qy`<div style="${e=>e.textStyles}" title=${e=>e.value}>${e.value}</div>`}
            ${e=>void 0!==e.index?u.qy`<sup>${e.index}</sup>`:""}
        </div>
        <div class="line ${e=>void 0!==e.classL2?e.classL2:""}">
            ${e=>u.qy`<div>${e.valueL2}</div>`}
        </div>
    </div>
`)}
`,k=u.qy`
    <a
        class="${e=>e.viewModel.clickThroughUrl?"clickable":""} table-container ${e=>e.viewModel.tableClass}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="${e=>e.viewModel.clickThroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}" 
    >
        ${e=>e.viewModel.isHeaderAboveTheTable?$:""}
        <div
            class="table-card ${e=>e.viewModel.fillFullCard?"fill-card":""}"
            style="${e=>e.viewModel.tableStyles}"
        >
            ${e=>e.viewModel.isHeaderAboveTheTable?"":$}
            <div class="grid-table"
                style="${e=>`\n                    grid-template-columns: ${e.viewModel.columnStyle};\n                    grid-template-rows: ${e.viewModel.rowStyle};\n                    ${e.viewModel.gridStyles};\n                `}">
                ${e=>e.getHeaderValues().length>0?y:""}
                ${w}
            </div>
        </div>
    </a>
`,z=u.qy`
    ${(0,m.z)(e=>null!=e.viewModel,k)}
`;var S=t(92079);class C extends S.a{constructor(){super(...arguments),this.getKeys=()=>this.viewModel.data.keys,this.getHeaderValues=()=>{const{header:e}=this.viewModel.data;return e?this.getKeys().map(r=>e[r]):[]},this.isLarge=()=>"_1x_3y"===this.viewModel.cardSize,this.getAllBodyCells=()=>{const e=[],r=this.getKeys();return this.viewModel.data.body.forEach(t=>{r.forEach(r=>e.push(t[r]))}),e}}}let T=class extends C{};T=(0,a.Cg)([(0,i.E)({name:"sports-table",template:z,styles:f,shadowOptions:{delegatesFocus:!0}})],T)},42792(e,r,t){t.d(r,{R7(){return x},e(){return h},kc(){return b},nH(){return p}});var a=t(57416),i=t(55153),o=t(95239),n=t(26920),s=t(48751),l=t(64187),d=t(22131),c=t(74849),g=t(50882);const p=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${n.XA} * 1px) solid ${i.cu};
        border-radius: calc((${a.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${i.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${i.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${i.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${i.QG} * 1px);
        height: calc(${i.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${i.QG} * 1px);
        height: calc((${i.l8} * 2px) + (${i.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${i.QG} * 2px) + (${i.Sn} * 1px));
        height: calc((${i.l8} * 2px) + (${i.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${i.QG} * 2px) + (${i.Sn} * 1px));
        height: calc(${i.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,b=(0,d.mr)(c.A`
            :host {
                background: ${g.A.Canvas};
                color: ${g.A.CanvasText};
            }
        `),x=c.A`
    ${h}
    ${p}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(b)},61405(e,r,t){t.r(r),t.d(r,{SportsStandingsRankingsTransformer(){return c}});var a=t(49150),i=t(23587),o=t(79811),n=t(96950),s=t(58792),l=t(22341),d=t(85312);class c extends i.Bc{constructor(){super(...arguments),this.iconUrl=e=>(0,o.iK)(e,!1,this.transformerProvider.config.teamImageInfoEnhanced)}async transform(e){const{cardSize:r}=e;this.cardSize=r,this.isInDarkMode=(0,o.jJ)(),this.isStandingsTemplate=!(0,o.nD)(e.standingsData);const t=this.getCurrentViewModel(e);return{viewTemplate:n.qy`
                <sports-standings-rankings
                    :viewModel="${t}"
                ></sports-standings-rankings>
            `}}getCurrentViewModel(e){const{telemetryBuilder:r}=this.transformerProvider;return{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,telemetryTag:r.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.SportsStandingsRankingsCard}),tableViewModel:this.getTableViewModel(e)}}getTableKey(){if(this.isStandingsTemplate){const e=["i","teams"];return this.hasWins&&e.push("wins"),this.haslosses&&e.push("losses"),this.hasPoints&&e.push("points"),e}return["i","players","points"]}getTableHeader(){const{strings:e}=this.transformerProvider;if(this.isStandingsTemplate){const r={i:{value:e.teams,class:"no-border overflow"},teams:{value:"",class:"no-border"}};return this.hasWins&&(r.wins={value:e.winShortName,class:"no-border"}),this.haslosses&&(r.losses={value:e.loseShortName,class:"center no-border"}),this.hasPoints&&(r.points={value:e.points,class:"no-border align-right"}),r}return{i:{value:e.players,class:"no-border overflow"},players:{value:"",class:"no-border"},points:{value:e.points,class:"no-border"}}}getTableBody(e,r){return this.isStandingsTemplate?e.teamStandings.map((e,r)=>({i:{value:`${r+1}`,cellClass:"no-border",class:"large-font"},teams:{value:e.teamName,icon:this.iconUrl(e.teamIcon),cellClass:"no-border",iconClass:"extra-margin",class:"large-font"},wins:{value:e.wins,cellClass:"no-border",class:"large-font"},losses:{value:e.losses,cellClass:"no-border",class:"large-font"},points:{value:e.points,cellClass:"no-border",class:"large-font align-right"}})):r.participants.map((e,r)=>({i:{value:`${r+1}`,cellClass:"no-border",class:"large-font"},players:{value:e.participantName,icon:this.iconUrl(e.imageId),cellClass:"no-border",iconClass:"extra-margin",class:"large-font iconround"},points:{value:e.points,cellClass:"no-border",class:"large-font"}}))}getColumnStyle(){if(this.isStandingsTemplate){let e="22px 1fr";return e+=this.hasWins?" 36px":"",e+=this.haslosses?" 16px":"",e+=this.hasPoints?" 40px":"",e}return"22px 1fr 40px"}getRowCount(){let e=6;return this.cardSize===a.uE._1x_3y&&(e=11),e}getTableViewModel(e){const{telemetryBuilder:r}=this.transformerProvider,{standingsData:t,rankingsData:a}=e;if((0,o.nD)(t)&&(0,o.nD)(a))return void(0,l.vV)(d.Ax,"Standings rankings table data missing",`market=${s.T3.CurrentMarket}`,JSON.stringify(e));this.isStandingsTemplate&&(this.hasWins=t.teamStandings.some(e=>void 0!==e.wins),this.haslosses=t.teamStandings.some(e=>void 0!==e.losses),this.hasPoints=t.teamStandings.some(e=>void 0!==e.points));const n=this.getTableKey(),c=this.getTableHeader(),g=this.getRowCount(),p=this.getTableBody(t,a).slice(0,g),h={keys:n,header:c,body:p};return{telemetryTag:r.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.SportsStandingsRankingsTable}),cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,data:h,columnStyle:this.getColumnStyle(),rowStyle:`repeat(${p.length+1}, 31px)`,fillFullCard:!0}}}Promise.resolve().then(t.bind(t,65009)),Promise.resolve().then(t.bind(t,17471))},65009(e,r,t){t.r(r),t.d(r,{SportsStandingsRankings(){return h}});var a=t(56911),i=t(92079);class o extends i.a{}var n=t(92011);const s=t(74849).A`
`;var l=t(96950),d=t(69259);const c=l.qy`
    <sports-table
        :viewModel="${e=>e.viewModel.tableViewModel}"
    ></sports-table>
`,g=l.qy`
    <div class="standings-rankings-content ${e=>e.viewModel.cardSize}" data-t="${e=>e.viewModel.telemetryTag}">
        ${c}
    </div>
`,p=l.qy`
    ${(0,d.z)(e=>null!=e.viewModel,g)}
`;let h=class extends o{};h=(0,a.Cg)([(0,n.E)({name:"sports-standings-rankings",template:p,styles:s,shadowOptions:{delegatesFocus:!0}})],h)},92079(e,r,t){t.d(r,{a(){return n}});var a=t(56911),i=t(92011),o=t(31525);let n=class extends i.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,a.Cg)([o.x],n)},99657(e,r,t){t.d(r,{D(){return n},I(){return o}});var a=t(45755);const{create:i}=a.G,o=i("sloppy-click-z-index",1),n=i("click-z-index",1)}}]);