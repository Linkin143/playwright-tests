(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-info-market-movers"],{4968(t,e,i){"use strict";i.d(e,{f(){return l}});var r=i(64187),s=i(74849),o=i(42792),a=i(99657),n=i(36452);const l=s.A.partial`position: relative; z-index: ${a.D};`;s.A`
    ${o.e}
    ${o.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${n.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${n.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${n.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},15030(t,e,i){"use strict";i.r(e),i.d(e,{MarketMoversIndexItemTransformer(){return c},MarketMoversTransformer(){return d},MoneyInfoStockChartTransformer(){return r.M}});var r=i(89213),s=i(27208),o=i(49150),a=i(86449),n=i(30236),l=i(96950);const h=["#00809D","#5C005C","#FF7E36","#5C2D91","#029DD4"];class d extends s.IB{async transform(t){this.indexQuote=t.quoteDetails[0];const e=await this.getCurrentViewModel(t);return{viewTemplate:l.qy`
                <market-movers
                    :viewModel="${e}"
                ></market-movers>`}}getListItemColor(){return(0,a.BK)((0,a.jJ)(),this.getChangePcntNumber(),this.transformerProvider.config.swapGainLossColor)}getHasLogo(t){return t.some(t=>Boolean(t.icon))}getNoLogoBgColor(t){return h[t%5]}getChangePcntNumber(){return this.indexQuote.changePcntNumber||0}isChangePcntPositive(){return this.getChangePcntNumber()>0}async getQuotes(t){let e=t.quoteDetails;if(!e)return[];e=e.slice(1,this.getMaxQuoteItemCount(t)+1),e.sort((t,e)=>null!==t.changePcntNumber&&void 0!==t.changePcntNumber&&null!==e.changePcntNumber&&void 0!==e.changePcntNumber?e.changePcntNumber-t.changePcntNumber:0);const i=this.getHasLogo(e);this.hasLogo=i;const r=e.map((e,r)=>{e.iconUrl=e.icon;const o={widgetSize:(0,a.CP)(t.cardSize),isVertical:this.isVerticalWatchlist(t),parentTelemetryObject:t.telemetryObject,quote:e,hasLogo:i,noLogoBgColor:i?"":this.getNoLogoBgColor(r),signature:t.signature,swapGainLossColor:this.transformerProvider.config.swapGainLossColor};return this.transformerProvider.generateView(o,s.Ai.MarketMoversIndexItem)});return(await Promise.all(r)).filter(a.z2)}getMaxQuoteItemCount(t){switch(t.cardSize){case o.uE._1x_1y:return 0;case o.uE._1x_2y:return 5;default:return 10}}getChangePcnt(){const t=this.getChangePcntNumber();return`${this.isChangePcntPositive()?"+":""}${t.toFixed(2)}%`}isVerticalWatchlist(t){return t.cardSize===o.uE._1x_3y}iconUrl(){const t=this.getChangePcntNumber(),e=this.isChangePcntPositive()?s.KH.Gainer:s.KH.Loser;return(0,n.kX)(this.transformerProvider.config.urls,t,s.Ex.MarketBrief,this.transformerProvider.config.swapGainLossColor,e)}getBaseline(t){var e;return((null===(e=t.chartData)||void 0===e||null===(e=e.chartData)||void 0===e?void 0:e.series)||[])[0]}async getChartData(t){if(t.chartData){t.chartData.pricePreviousClose=this.getBaseline(t);const e={quote:this.indexQuote,chartData:{...t.chartData,pricePreviousClose:this.getBaseline(t)},width:68,height:56,isFullWidth:!0,cardSize:t.cardSize};return(await this.transformerProvider.generateView(e,s.Ai.MoneyInfoStockChart)).viewModel}}getNotificationText(){const{indexUp:t,indexDown:e}=this.transformerProvider.strings;return t&&this.isChangePcntPositive()?t:e||""}getIndexDisplayName(){const t=this.indexQuote.displayName||"";if(t.length>10){const[e="",i=""]=t.split(" "),r=e.length+1+i.length;return r>10?t.slice(0,e.length):t.slice(0,r)}return t}async getCurrentViewModel(t){var e;const i=await this.getQuotes(t);return{iconUrl:this.iconUrl(),isVerticalList:this.isVerticalWatchlist(t),listItemColor:this.getListItemColor(),chartData:await this.getChartData(t),quotes:i,hasLogo:this.hasLogo,experienceName:t.experienceName,changePcnt:this.getChangePcnt(),notificationText:this.getNotificationText(),indexSymbol:null===(e=t.chartData)||void 0===e?void 0:e.symbol,indexPrice:this.indexQuote.price,marketmoversTitleText:this.transformerProvider.strings.marketMoversTitleText,marketmoversStocksTitleText:this.transformerProvider.strings.marketMoversStocksTitleText,displayName:this.getIndexDisplayName(),telemetryTag:"",widgetSize:(0,a.CP)(t.cardSize),shortName:this.indexQuote.shortName}}}class c extends s.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getPriceColor(t,e){const i=this.getPcnt(t);return(0,a.BK)((0,a.jJ)(),parseFloat(i),e)}getPcntValue(t){const e=this.getPcnt(t);return`${this.getPriceDirection(parseFloat(e))}${e}%`}getPcnt(t){const e=(t.changePcntNumber||0).toFixed(1);return 0===Number(e)?(0).toFixed(1):e}getPriceDirection(t){return t>0?"+":""}getIconURL(t){const e=t.quote;return(0,a.Mx)(e)&&e.symbol.length>=3?(0,a.A0)(e.symbol.slice(-3)):(0,a.nZ)(e,50,50,0)}async getViewModel(t){return{widgetSize:t.widgetSize,iconUrl:this.getIconURL(t),isCurrencySecurityType:(0,a.Mx)(t.quote),isVertical:t.isVertical,displayName:t.quote.displayName||"",shortName:t.quote.shortName||"",pcntValue:this.getPcntValue(t.quote),priceColor:this.getPriceColor(t.quote,t.swapGainLossColor),symbol:t.quote.symbol,hasLogo:t.hasLogo,noLogoBgColor:t.noLogoBgColor,quoteUrl:(0,n.Xe)(this.transformerProvider.config.urls,s.Rf.Watchlist,(0,a.EL)(t.quote),void 0,!0),tooltipText:(0,a.jX)(t.quote.displayName||"",t.quote.symbol,!0,this.transformerProvider.strings),telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.parentTelemetryObject,{name:s.CD.quoteItemClick,signature:t.signature,headline:t.quote.symbol,id:t.quote.id})}}}Promise.resolve().then(i.bind(i,67538)),Promise.resolve().then(i.bind(i,75862)),Promise.resolve().then(i.bind(i,34964))},34964(t,e,i){"use strict";i.r(e),i.d(e,{MarketMoversIndexItem(){return f}});var r=i(56911),s=i(95296);class o extends s.m{}var a=i(92011),n=i(74849),l=i(48751),h=i(4968);const d=n.A` .qimg{border-radius:50%;box-sizing:border-box;object-fit:contain;border:1px solid rgba(0,0,0,0.16)}.horz .qimg{margin-bottom:3px;justify-self:center}.curr .qimg{border-radius:0}.hlstItm{display:grid;align-items:center;place-items:center;justify-content:center;justify-self:stretch;row-gap:4px;color:${l.l};
        text-decoration: none;
        ${h.f}}.horz .hlstItm > span,.horz .hlstItm > img{justify-self:center}.qps{font-weight:600;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);text-align:center}.symb{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);overflow:hidden;text-align:center;max-width:none;white-space:nowrap}.hlstItm{row-gap:0;width:40px}.vert .hlstItm .qps{margin:0}.vert .hlstItm{width:100%;gap:2px}.no-logo.horz .hlstItm{margin-bottom:12px}.disp-name{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:400}.horz .disp-name{display:none}.no-logo .symb{color:white;min-width:40px;max-width:44px;border-radius:4px;overflow:hidden}.no-logo.horz .symb{margin-bottom:4px}`;var c=i(96950),g=i(69259);const p=`${(0,i(58792).rA)().StaticsUrl}latest/money/icons/StockEmptyStateCircle.svg`,u=c.qy`<span class="qps" style="color: ${t=>t.viewModel.priceColor}">&lrm;${t=>t.viewModel.pcntValue}&lrm;</span>`,v=c.qy` ${(0,g.z)(t=>t.viewModel.hasLogo,c.qy` ${t=>t.viewModel.iconUrl?c.qy`<img class="qimg" src="${t=>t.viewModel.iconUrl}" alt="" loading=lazy width="32" height="32"/>`:c.qy`<img class="qimg qimg-empty" src=${p} alt=${t=>t.viewModel.symbol} width="32" height="32">`} `)}
`,m=c.qy` ${(0,g.z)(t=>t&&void 0!==t.viewModel,c.qy`<li class=" ${t=>t.viewModel.widgetSize} ${t=>t.viewModel.isVertical?"vert":"horz"} ${t=>t.viewModel.hasLogo?"w-logo":"no-logo"} "><a class="hlstItm ${t=>t.viewModel.isCurrencySecurityType?"curr":""}" href="${t=>t.viewModel.quoteUrl}" title="${t=>t.viewModel.tooltipText}" target="_blank" data-t="${t=>t.viewModel.telemetryTag}">${v}<div class="symb" style="background-color: ${t=>t.viewModel.noLogoBgColor}">${t=>t.viewModel.symbol}</div>${u}</a></li>`)}
`;let f=class extends o{};f=(0,r.Cg)([(0,a.E)({name:"market-movers-index-item",template:m,styles:d,shadowOptions:{delegatesFocus:!0}})],f)},42792(t,e,i){"use strict";i.d(e,{R7(){return v},e(){return p},kc(){return u},nH(){return g}});var r=i(57416),s=i(55153),o=i(95239),a=i(26920),n=i(48751),l=i(64187),h=i(22131),d=i(74849),c=i(50882);const g=d.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,p=d.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${a.XA} * 1px) solid ${s.cu};
        border-radius: calc((${r.JU} - ${a.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${n.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${s.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${s.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${a.XA} * 1px) ${s.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${s.QG} * 1px);
        height: calc(${s.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${s.QG} * 1px);
        height: calc((${s.l8} * 2px) + (${s.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${s.QG} * 2px) + (${s.Sn} * 1px));
        height: calc((${s.l8} * 2px) + (${s.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${s.QG} * 2px) + (${s.Sn} * 1px));
        height: calc(${s.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,h.mr)(d.A`
            :host {
                background: ${c.A.Canvas};
                color: ${c.A.CanvasText};
            }
        `),v=d.A`
    ${p}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},67538(t,e,i){"use strict";i.r(e),i.d(e,{MoneyInfoStockChart(){return v}});var r=i(56911),s=i(92011),o=i(60815),a=i(22341),n=i(93552),l=i(31525),h=i(26220);let d=class extends s.L{connected(){try{this.initializeChart()}catch(t){(0,a.vV)(n.npu,t?t.message:"Unknown error")}}initializeChart(){if(this.canvasEl){const t=(0,h.mZ)();this.canvasEl.width=this.width*t,this.canvasEl.height=this.height*t,this.ctx=this.canvasEl.getContext("2d"),this.ctx.scale(t,t),this.canvasEl.style.width=`${this.width}px`,this.canvasEl.style.height=`${this.height}px`,this.drawChart()}}shouldShowBaseline(){if("number"!=typeof this.baselinePrice)return!1;const t=Math.min(...this.prices),e=Math.max(...this.prices);if(t===e)return!0;const i=t>this.baselinePrice?t-this.baselinePrice:this.baselinePrice-e;return i/(i+(e-t))<.5}drawChart(){if(!this.prices)return;const t=this.prices.slice();this.shouldShowBaseline()&&t.push(this.baselinePrice);let e=Math.min(...t),i=Math.max(...t);e===i&&(e-=1,i+=1);const r=Math.round(1e4*(i-e))/1e4,s=Math.max(this.pricesMaxCount||0,this.prices.length),o=this.prices.length/s,a=this.width*(this.isFullWidth?1:o);this.ctx.beginPath(),this.ctx.moveTo(0,this.height-(this.prices[0]-e)/r*this.height);for(let t=1;t<this.prices.length;t++){const i=t/(this.prices.length-1)*a,s=this.height-(this.prices[t]-e)/r*this.height;this.ctx.lineTo(i,s)}this.ctx.lineWidth=1.2,this.ctx.strokeStyle=this.lineColor,this.ctx.stroke(),this.ctx.lineTo(this.width,this.height),this.ctx.lineTo(0,this.height),this.ctx.closePath(),this.ctx.save(),this.ctx.clip();const n=this.ctx.createLinearGradient(0,0,0,this.height);n.addColorStop(0,`${this.lineColor}4D`),n.addColorStop(1,`${this.lineColor}00`),this.ctx.fillStyle=n,this.ctx.fillRect(0,0,a,this.height),this.ctx.restore(),this.ctx.beginPath(),this.ctx.moveTo(0,this.height-(this.baselinePrice-e)/r*this.height),this.ctx.lineTo(this.width,this.height-(this.baselinePrice-e)/r*this.height),this.ctx.strokeStyle=this.baselineColor,this.ctx.setLineDash(this.lineDash||[5,5]),this.ctx.stroke()}};(0,r.Cg)([o.sH],d.prototype,"prices",void 0),(0,r.Cg)([o.sH],d.prototype,"baselinePrice",void 0),(0,r.Cg)([o.sH],d.prototype,"width",void 0),(0,r.Cg)([o.sH],d.prototype,"height",void 0),(0,r.Cg)([o.sH],d.prototype,"lineColor",void 0),(0,r.Cg)([o.sH],d.prototype,"baselineColor",void 0),(0,r.Cg)([o.sH],d.prototype,"lineDash",void 0),d=(0,r.Cg)([l.x],d);const c=i(74849).A` 
`;var g=i(96950),p=i(60402);const u=g.qy`<template><canvas ${(0,p.K)("canvasEl")}></canvas></template>`;let v=class extends d{};v=(0,r.Cg)([(0,s.E)({name:"money-info-stock-chart",template:u,styles:c,shadowOptions:{delegatesFocus:!0}})],v)},75862(t,e,i){"use strict";i.r(e),i.d(e,{MarketMovers(){return z}});var r=i(56911),s=i(92707);class o extends s.z{stockNames(t){const{shortName:e,displayName:i,indexSymbol:r}=this.viewModel;return[e||i||"",r||""][t]}}var a=i(92011),n=i(12640),l=i(74849),h=i(64003);const d=l.A` :host{--card-white:rgba(255,255,255,0.06);--return-white:rgba(255,255,255,0.78)}`,c=l.A` :host{--card-white:rgba(255,255,255,0.5)}.wli{height:100%;border-radius:8px}ul{list-style:none;padding-inline-start:0}.hlstCtr{display:grid;width:100%;grid-template-columns:repeat(5,auto);justify-content:space-between;align-items:center;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600}.card{background:var(--card-white);display:flex;flex-direction:column;justify-content:space-between;border-radius:6px;padding:12px;width:268px;height:100%;box-sizing:border-box}.hlstCtr.vert{grid-row-gap:30px;margin-bottom:25px}.hlstCtr.vert.no-logo{grid-row-gap:50px}.hlstCtr.no-logo{padding-top:12px}.vert .card{justify-content:flex-start}.top{display:flex;justify-content:space-between;align-items:flex-end;width:100%}.small .top{align-items:center}.return{display:flex;flex-direction:column}.return .text{color:var(--return-white)}.index-symbol{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-3-line-height,22px);font-weight:600;margin-right:5px}.index-name{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:400}.small .return .index-name{font-weight:600;text-align:left}.medium .return .index-name,.large .return .index-name{color:${h.c}}.price{font-size:var(--type-ramp-plus-3-font-size,24px);line-height:var(--type-ramp-plus-3-line-height,32px);font-weight:600}.index-info{display:flex;align-items:center}.small .index-info{justify-content:space-between}.index-pcnt{display:flex;justify-content:space-between;align-items:center}.pcnt{display:flex;align-items:center;width:175px}.pcnt-str{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600;margin-left:5px}.pcnt-str.index-change{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.top-stocks{text-align:left;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:400;margin-top:30px}.top-stocks.no-logo{margin-top:5px}.medium .top-stocks{margin-top:15px}.top-stocks .title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:${h.c}}.medium .top-stocks .title{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.disp-name{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.small.wli{display:flex;align-items:center}.small .return{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600}.small .return .price{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600;text-align:right}.small .return .pcnt-str{text-align:right;margin:0px}.small .top-stocks{text-align:left;width:136px;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.icon{margin-top:2px}.small .icon{margin-right:6px}.chevron svg{padding-top:5px}`.withBehaviors(new n.N(null,d));var g=i(96950),p=i(39957),u=i(69259),v=i(95256),m=i.n(v);const f=g.qy`<ul class="hlstCtr ${t=>t.viewModel.isVerticalList?"vert":""} ${t=>t.viewModel.hasLogo?"":"no-logo"}">${(0,p.ux)(t=>t.viewModel.quotes,g.qy`<market-movers-index-item :viewModel="${t=>t.viewModel}"></market-movers-index-item>`)}</ul>`,x=g.qy`<div class="return"><div class="index-info"><div class="index-symbol">${t=>t.stockNames(0)}</div><div class="index-name">${t=>t.stockNames(1)}</div></div><div class="price">${t=>t.viewModel.indexPrice}</div><div class="pcnt"><img class="icon" src="${t=>t.viewModel.iconUrl}" alt="${t=>t.viewModel.marketmoversTitleText}" width="16" height="16"><div class="pcnt-str index-change" style="color: ${t=>t.viewModel.listItemColor}">${t=>t.viewModel.notificationText}</div><div class="pcnt-str" style="color: ${t=>t.viewModel.listItemColor}">${t=>t.viewModel.changePcnt}</div><div class="chevron" style="color: ${t=>t.viewModel.listItemColor}; fill: ${t=>t.viewModel.listItemColor}">${g.qy.partial(m())}</div></div><div>`,b=g.qy`<div class="top-stocks" ${t=>t.viewModel.hasLogo?"":"no-logo"}><div class="title">${t=>t.viewModel.marketmoversStocksTitleText}</div></div>`,w=g.qy`<div class="card"><div class="return"><div class="index-info"><div class="index-name">${t=>t.viewModel.displayName}</div><div class="price">${t=>t.viewModel.indexPrice}</div></div><div class="index-pcnt"><div class="pcnt"><img class="icon" src="${t=>t.viewModel.iconUrl}" alt="${t=>t.viewModel.marketmoversTitleText}" width="16" height="16"><div class="pcnt-str index-change" style="color: ${t=>t.viewModel.listItemColor}">${t=>t.viewModel.notificationText}</div><div class="chevron" style="color: ${t=>t.viewModel.listItemColor}; fill: ${t=>t.viewModel.listItemColor}">${g.qy.partial(m())}</div></div><div class="pcnt-str" style="color: ${t=>t.viewModel.listItemColor}">${t=>t.viewModel.changePcnt}</div></div><div></div>`,y=g.qy`<div class="chart">${(0,u.z)(t=>{var e;return(null===(e=t.viewModel.chartData)||void 0===e||null===(e=e.chartSeries)||void 0===e?void 0:e.length)>0},g.qy`<money-info-stock-chart :width=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartWidth}} :height=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartHeight}} :prices=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartSeries}} :baselinePrice=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartBaseline}} :lineColor=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartFillColor}} :baselineColor=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.baselineFillColor}} :pricesMaxCount=${()=>40} :isFullWidth=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.isFullWidth}}></money-info-stock-chart>`)}</div>`,$=g.qy`<div class="card"><div class="top">${x} ${y}</div>${b} ${f}</div>`,k=g.qy` ${(0,u.z)(t=>t&&void 0!==t.viewModel,g.qy`<div class="wli ${t=>t.viewModel.widgetSize}">${t=>"small"===t.viewModel.widgetSize?w:$}</div>`)}
`;let z=class extends o{};z=(0,r.Cg)([(0,a.E)({name:"market-movers",template:k,styles:c,shadowOptions:{delegatesFocus:!0}})],z)},89213(t,e,i){"use strict";i.d(e,{M(){return a}});var r=i(27208),s=i(49150),o=i(86449);class a extends r.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getChartFillColor(t){return t?(0,o.BK)((0,o.jJ)(),t.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor):""}chartPricePreviousClose(t){return t?t.pricePreviousClose:void 0}getChartWidth(t){return t.width?t.width:t.cardSize===s.uE._1x_1y?104:32}getChartHeight(t){return t.height?t.height:t.cardSize===s.uE._1x_1y?18:28}async getViewModel(t){var e,i;return{chartId:t.quote.id,chartWidth:this.getChartWidth(t),chartHeight:this.getChartHeight(t),chartFillColor:this.getChartFillColor(t.quote),baselineFillColor:this.getChartFillColor(t.quote),isFullWidth:t.isFullWidth,lineDash:t.lineDash,chartBaseline:this.chartPricePreviousClose(null==t?void 0:t.chartData),chartBaselineLoc:null==t||null===(e=t.chartData)||void 0===e?void 0:e.pricePreviousCloseLoc,chartSeries:null==t||null===(i=t.chartData)||void 0===i||null===(i=i.chartData)||void 0===i?void 0:i.series,cardSize:t.cardSize,telemetryTag:""}}}},92707(t,e,i){"use strict";i.d(e,{z(){return l}});var r=i(56911),s=i(27208),o=i(60815),a=i(92011),n=i(31525);let l=class extends a.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return s.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const t=this.getState();t&&(t.subscribe(s.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(t){}onChartDictChange(t){}onShowNotificationTextChange(t){}onQuoteItemDictChange(t){}onCardWidthChanged(t){}};(0,r.Cg)([o.sH],l.prototype,"viewModel",void 0),l=(0,r.Cg)([n.x],l)},95256(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M5.65 3.15a.5.5 0 000 .7L9.79 8l-4.14 4.15a.5.5 0 00.7.7l4.5-4.5a.5.5 0 000-.7l-4.5-4.5a.5.5 0 00-.7 0z"></path></svg>'},95296(t,e,i){"use strict";i.d(e,{m(){return a}});var r=i(56911),s=i(60815),o=i(92011);class a extends o.L{}(0,r.Cg)([s.sH],a.prototype,"viewModel",void 0)},99657(t,e,i){"use strict";i.d(e,{D(){return a},I(){return o}});var r=i(45755);const{create:s}=r.G,o=s("sloppy-click-z-index",1),a=s("click-z-index",1)}}]);