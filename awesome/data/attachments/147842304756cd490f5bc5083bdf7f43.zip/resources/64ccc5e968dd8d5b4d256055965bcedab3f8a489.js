// © Microsoft Corporation. All rights reserved.
export const desktopTrackConfig = {
    canvas: "Browser",
    channel: "",
    msnocid: "",
    department: "",
    pageName: "homepage",
    pageVersion: "",
    pageType: "hp",
    storeocid: "",
    pageConfiguration: 11,
    pageProduct: "prime",
    vertical: "homepage"
};
//# sourceMappingURL=telemetry.js.map