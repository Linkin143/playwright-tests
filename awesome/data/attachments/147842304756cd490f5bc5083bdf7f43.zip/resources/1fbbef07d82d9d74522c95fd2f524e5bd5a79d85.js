"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["cs-core-desktop_responsive-card_dist_index_js"],{121(t,i,e){e.d(i,{m(){return y}});var o=e(56911),a=e(92011),n=e(38493),r=e(60815),s=e(83781),d=e(55230),l=e(31157),h=e(42938);class c extends a.L{constructor(){super(...arguments),this.orientation=s.t.horizontal,this.radioChangeHandler=t=>{const i=t.target;i.checked&&(this.slottedRadioButtons.forEach(t=>{t!==i&&(t.checked=!1,this.isInsideFoundationToolbar||t.setAttribute("tabindex","-1"))}),this.selectedRadio=i,this.value=i.value,i.setAttribute("tabindex","0"),this.focusedRadio=i),t.stopPropagation()},this.moveToRadioByIndex=(t,i)=>{const e=t[i];this.isInsideToolbar||(e.setAttribute("tabindex","0"),e.readOnly?this.slottedRadioButtons.forEach(t=>{t!==e&&t.setAttribute("tabindex","-1")}):(e.checked=!0,this.selectedRadio=e)),this.focusedRadio=e,e.focus()},this.moveRightOffGroup=()=>{this.nextElementSibling?.focus()},this.moveLeftOffGroup=()=>{this.previousElementSibling?.focus()},this.focusOutHandler=t=>{const i=this.slottedRadioButtons,e=t.target,o=null!==e?i.indexOf(e):0,a=this.focusedRadio?i.indexOf(this.focusedRadio):-1;return(0===a&&o===a||a===i.length-1&&a===o)&&(this.selectedRadio?(this.focusedRadio=this.selectedRadio,this.isInsideFoundationToolbar||(this.selectedRadio.setAttribute("tabindex","0"),i.forEach(t=>{t!==this.selectedRadio&&t.setAttribute("tabindex","-1")}))):(this.focusedRadio=i[0],this.focusedRadio.setAttribute("tabindex","0"),i.forEach(t=>{t!==this.focusedRadio&&t.setAttribute("tabindex","-1")}))),!0},this.clickHandler=t=>{const i=t.target;if(i){const t=this.slottedRadioButtons;i.checked||0===t.indexOf(i)?(i.setAttribute("tabindex","0"),this.selectedRadio=i):(i.setAttribute("tabindex","-1"),this.selectedRadio=null),this.focusedRadio=i}t.preventDefault()},this.shouldMoveOffGroupToTheRight=(t,i,e)=>t===i.length&&this.isInsideToolbar&&e===d.bb,this.shouldMoveOffGroupToTheLeft=(t,i)=>(this.focusedRadio?t.indexOf(this.focusedRadio)-1:0)<0&&this.isInsideToolbar&&i===d.kT,this.checkFocusedRadio=()=>{null===this.focusedRadio||this.focusedRadio.readOnly||this.focusedRadio.checked||(this.focusedRadio.checked=!0,this.focusedRadio.setAttribute("tabindex","0"),this.focusedRadio.focus(),this.selectedRadio=this.focusedRadio)},this.moveRight=t=>{const i=this.slottedRadioButtons;let e=0;if(e=this.focusedRadio?i.indexOf(this.focusedRadio)+1:1,this.shouldMoveOffGroupToTheRight(e,i,t.key))this.moveRightOffGroup();else for(e===i.length&&(e=0);e<i.length&&i.length>1;){if(!i[e].disabled){this.moveToRadioByIndex(i,e);break}if(this.focusedRadio&&e===i.indexOf(this.focusedRadio))break;if(e+1>=i.length){if(this.isInsideToolbar)break;e=0}else e+=1}},this.moveLeft=t=>{const i=this.slottedRadioButtons;let e=0;if(e=this.focusedRadio?i.indexOf(this.focusedRadio)-1:0,e=e<0?i.length-1:e,this.shouldMoveOffGroupToTheLeft(i,t.key))this.moveLeftOffGroup();else for(;e>=0&&i.length>1;){if(!i[e].disabled){this.moveToRadioByIndex(i,e);break}if(this.focusedRadio&&e===i.indexOf(this.focusedRadio))break;e-1<0?e=i.length-1:e-=1}},this.keydownHandler=t=>{const i=t.key;if(i in d.Is&&this.isInsideFoundationToolbar)return!0;switch(i){case d.Mm:this.checkFocusedRadio();break;case d.bb:case d.HX:this.direction===l.O.ltr?this.moveRight(t):this.moveLeft(t);break;case d.kT:case d.I5:this.direction===l.O.ltr?this.moveLeft(t):this.moveRight(t);break;default:return!0}}}readOnlyChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{this.readOnly?t.readOnly=!0:t.readOnly=!1})}disabledChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{this.disabled?t.disabled=!0:t.disabled=!1})}nameChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{t.setAttribute("name",this.name)})}valueChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{t.value===this.value&&(t.checked=!0,this.selectedRadio=t)}),this.$emit("change")}slottedRadioButtonsChanged(t,i){this.slottedRadioButtons&&this.slottedRadioButtons.length>0&&this.setupRadioButtons()}get parentToolbar(){return this.closest('[role="toolbar"]')}get isInsideToolbar(){return this.parentToolbar??!1}get isInsideFoundationToolbar(){return!!this.parentToolbar?.$fastController}connectedCallback(){super.connectedCallback(),this.direction=(0,h.u)(this),this.setupRadioButtons()}disconnectedCallback(){super.disconnectedCallback(),this.slottedRadioButtons.forEach(t=>{t.removeEventListener("change",this.radioChangeHandler)})}setupRadioButtons(){const t=this.slottedRadioButtons.filter(t=>t.hasAttribute("checked")),i=t?t.length:0;if(i>1){t[i-1].checked=!0}let e=!1;if(this.slottedRadioButtons.forEach(t=>{void 0!==this.name&&t.setAttribute("name",this.name),this.disabled&&(t.disabled=!0),this.readOnly&&(t.readOnly=!0),this.value&&this.value===t.value?(this.selectedRadio=t,this.focusedRadio=t,t.checked=!0,t.setAttribute("tabindex","0"),e=!0):(this.isInsideFoundationToolbar||t.setAttribute("tabindex","-1"),t.checked=!1),t.addEventListener("change",this.radioChangeHandler)}),void 0===this.value&&this.slottedRadioButtons.length>0){const t=this.slottedRadioButtons.filter(t=>t.hasAttribute("checked")),i=null!==t?t.length:0;if(i>0&&!e){const e=t[i-1];e.checked=!0,this.focusedRadio=e,e.setAttribute("tabindex","0")}else this.slottedRadioButtons[0].setAttribute("tabindex","0"),this.focusedRadio=this.slottedRadioButtons[0]}}}(0,o.Cg)([(0,n.CF)({attribute:"readonly",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],c.prototype,"readOnly",void 0),(0,o.Cg)([(0,n.CF)({attribute:"disabled",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],c.prototype,"disabled",void 0),(0,o.Cg)([n.CF,(0,o.Sn)("design:type",String)],c.prototype,"name",void 0),(0,o.Cg)([n.CF,(0,o.Sn)("design:type",String)],c.prototype,"value",void 0),(0,o.Cg)([n.CF,(0,o.Sn)("design:type",String)],c.prototype,"orientation",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Array)],c.prototype,"childItems",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Array)],c.prototype,"slottedRadioButtons",void 0);var u=e(37180),p=e(74849),g=e(64187),b=e(74838);const v=p.A`
    ${(0,g.V)("flex")} :host {
        align-items: flex-start;
        margin: calc(${b.vR} * 1px) 0;
        flex-direction: column;
    }

    .positioning-region {
        display: flex;
        flex-wrap: wrap;
    }

    :host([orientation="vertical"]) .positioning-region {
        flex-direction: column;
    }

    :host([orientation="horizontal"]) .positioning-region {
        flex-direction: row;
    }
`;var x=e(96950),m=e(82774),f=e(10108);const w=x.qy`
        <template
            role="radiogroup"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            @click="${(t,i)=>t.clickHandler(i.event)}"
            @keydown="${(t,i)=>t.keydownHandler(i.event)}"
            @focusout="${(t,i)=>t.focusOutHandler(i.event)}"
        >
            <slot name="label"></slot>
            <div
                class="positioning-region ${t=>t.orientation===s.t.horizontal?"horizontal":"vertical"}"
                part="positioning-region"
            >
                <slot
                    ${(0,m.e)({property:"slottedRadioButtons",filter:(0,f.Y)("[role=radio]")})}
                ></slot>
            </div>
        </template>
    `,y=c.compose({name:`${u.c.prefix}-radio-group`,template:w,styles:v})},3678(t,i,e){e.d(i,{c(){return h},o(){return l}});var o=e(4126),a=e(74849),n=e(32257),r=e(30664),s=e(29222);const d=a.A` :host(:not([immersive])) .call-to-action{border:unset;background-color:unset}:host(:not([immersive])) .call-to-action:hover{text-decoration:underline;text-decoration-color:#0961BB}:host(:not([immersive])) .call-to-action .call-to-action-text,:host(:not([immersive])) .call-to-action .call-to-action-text:visited{color:#006FD8;padding:unset}}`,l=a.A` .call-to-action.ruby-digest{display:flex;min-width:${n.Kjq};
        min-height: ${n.Kjq};
        padding: 0 ${n._gs};
        justify-content: center;
        align-items: center;
        gap: ${n.IOY};
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.00);
        background: #E5EBFA;
        box-shadow: ${s.XXU} ${s.QET} ${s.yf9} 0 ${s.ipd}}.call-to-action.ruby-digest .call-to-action-text,.call-to-action.ruby-digest .call-to-action-text:visited{color:#282D3E;font-family:${s.Afb};
        font-size: ${n.e1r};
        font-style: normal;
        font-weight: 410;
        line-height: ${n.HoW};
        letter-spacing: ${s.nDV};
        background-color: transparent;
        text-decoration: none;
        padding: unset;
    }
`,h=a.A` .call-to-action{display:flex;justify-content:center;align-items:center;background-color:rgba(255,255,255,0.15);border:1px solid;border-image-source:linear-gradient(180deg,rgba(0,0,0,0.0578) 90.58%,rgba(0,0,0,0.1622) 100%);border-radius:4px;font-size:12px;line-height:16px;font-family:inherit;font-weight:400;font-style:normal;z-index:${r.I}}.call-to-action-text,.call-to-action-text:visited{color:#ffffff;padding:4px 12px;text-decoration:none;display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;-webkit-line-clamp:1}:host(:not([immersive])) .call-to-action{background:none;background-color:#ffffff;border:1px solid #D1D1D1}:host(:not([immersive])) .call-to-action .call-to-action-text,:host(:not([immersive])) .call-to-action .call-to-action-text:visited{color:#242424;padding:3px 8px}@media (prefers-color-scheme:dark){:host(:not([immersive])) .call-to-action{background-color:#242424;border:1px solid #666666}:host(:not([immersive])) .call-to-action .call-to-action-text,:host(:not([immersive])) .call-to-action .call-to-action-text:visited{color:#ffffff}}`.withBehaviors(new o.o("ruby",!0,d))},8984(t,i,e){e.d(i,{RY(){return $}});var o=e(58792),a=e(74998),n=e(2171),r=e(74849),s=e(22131),d=e(62175);const l=r.A`
    :host {
        --smtc-foreground-ctrl-neutral-primary-rest: rgba(255, 255, 255, 1);
        --smtc-foreground-ctrl-neutral-secondary-rest: rgba(255, 255, 255, 1);
        --smtc-foreground-ctrl-on-brand-rest: rgba(92, 92, 92, 1);
        --smtc-foreground-ctrl-on-outline-rest: rgba(255, 255, 255, 1);
        --smtc-background-ctrl-active-brand-rest: rgba(115, 133, 255, 1);
        --smtc-background-ctrl-neutral-rest: rgba(41, 41, 41, 1);
        --smtc-background-ctrl-neutral-hover: #3d3d3d;
        --smtc-background-ctrl-subtle-hover: rgba(61, 61, 61, 1);
        --cstm-background-flyout-linear-gradient: rgba(41, 41, 41, 1);
        --smtc-ctrl-choice-switch-background-selected-rest: rgba(115, 133, 255, 1);
        --smtc-stroke-ctrl-on-neutral-rest: rgba(102, 102, 102, 1);
        --cstm-subtle-button-border-color: rgba(102, 102, 102, 1);
        --smtc-ctrl-choice-base-stroke-rest: rgba(173, 173, 173, 1);
        --smtc-status-informative-tint-background-ad: rgba(0, 0, 0, 1);
        --smtc-background-ctrl-neutral-disabled: rgba(20, 20, 20, 1);

        /* Background Enterprise Token - Dark */
        --ent-background-web-page-primary: rgba(31, 31, 31, 1);

        /* Feed Nav Enterprise Tokens - Dark */
        --ent-feed-nav-container-background: rgba(255, 255, 255, 0.08);
        --ent-feed-nav-container-border: rgba(102, 102, 102, 1);
        --ent-feed-nav-tab-background-rest: rgba(20, 20, 20, 1);
        --ent-feed-nav-tab-background-selected: rgba(41, 41, 41, 1);
        --ent-feed-nav-tab-background-hover: rgba(255, 255, 255, 0.02);
        --ent-feed-nav-tab-text-rest: rgba(173, 173, 173, 1);
        --ent-feed-nav-tab-text-selected: rgba(115, 133, 255, 1);
        --ent-feed-nav-tab-text-hover: rgba(255, 255, 255, 0.9);

        /* Ruby Card Enterprise Tokens - Dark */
        --ent-ruby-card-border: rgba(82, 82, 82, 1);
        --ent-foreground-primary: rgba(214, 214, 214, 1);
    }
`,h=r.A`
    :host {
        --smtc-foreground-ctrl-neutral-primary-rest: rgba(36, 36, 36, 1);
        --smtc-foreground-ctrl-neutral-secondary-rest: rgba(36, 36, 36, 1);
        --smtc-foreground-ctrl-on-brand-rest: rgba(189, 189, 189, 1);
        --smtc-foreground-ctrl-on-outline-rest: rgba(36, 36, 36, 1);
        --smtc-background-ctrl-active-brand-rest: rgba(70, 79, 235, 1);
        --smtc-background-ctrl-neutral-rest: rgba(255, 255, 255, 1);
        --smtc-background-ctrl-neutral-hover: #f5f5f5;
        --smtc-background-ctrl-subtle-hover: rgba(245, 245, 245, 1);
        --cstm-background-flyout-linear-gradient: rgba(255, 255, 255, 1);
        --smtc-ctrl-choice-switch-background-selected-rest: rgba(70, 79, 235, 1);
        --smtc-stroke-ctrl-on-neutral-rest: rgba(209, 209, 209, 1);
        --cstm-subtle-button-border-color: rgba(209, 209, 209, 1);
        --smtc-ctrl-choice-base-stroke-rest: rgba(97, 97, 97, 1);
        --smtc-status-informative-tint-background-ad: rgba(235, 235, 235, 1);
        --smtc-background-ctrl-neutral-disabled: rgba(240, 240, 240, 1);

        /* Background Enterprise Token - Light */
        --ent-background-web-page-primary: rgba(250, 250, 250, 1);

        /* Feed Nav Enterprise Tokens - Light */
        --ent-feed-nav-container-background: rgba(255, 255, 255, 1);
        --ent-feed-nav-container-border: rgba(209, 209, 209, 1);
        --ent-feed-nav-tab-background-rest: rgba(245, 245, 245, 1);
        --ent-feed-nav-tab-background-selected: rgba(255, 255, 255, 1);
        --ent-feed-nav-tab-background-hover: rgba(235, 235, 235, 1);
        --ent-feed-nav-tab-text-rest: rgba(96, 96, 96, 1);
        --ent-feed-nav-tab-text-selected: rgba(70, 79, 235, 1);
        --ent-feed-nav-tab-text-hover: rgba(60, 60, 60, 1);

        /* Ruby Card Enterprise Tokens - Light */
        --ent-ruby-card-border: rgba(224, 224, 224, 1);
        --ent-foreground-primary: rgba(66, 66, 66, 1);
    }
`;var c=e(21446);const u=r.A`
    :host {
        --smtc-text-style-default-regular-font-family: ${c.NZ};

        --smtc-text-style-default-header-weight: 600;
        --smtc-text-global-body1-line-height: 28px;
        --smtc-text-global-body1-font-size: 18px;

        --smtc-text-global-body2-font-size: 16px;
        --smtc-text-global-body2-line-height: 22px;

        --smtc-text-style-default-regular-weight: 400;
        --smtc-text-global-body3-font-size: 12px;
        --smtc-text-global-body3-line-height: 16px;

        --smtc-text-ramp-item-body-font-size: 12px;
        --smtc-text-ramp-item-body-line-height: 16px;

        --smtc-text-global-body4-font-size: 14px;
        --smtc-text-global-body4-line-height: 20px;
    }
`,p=r.A`
    :host {
        --smtc-corner-ctrl-rest: 8px;
        --smtc-corner-ctrl-lg-rest: 12px;
        --smtc-corner-flyout-rest: 12px;

        /* Feed Nav Corner Tokens */
        --ent-feed-nav-container-corner-radius: 8px;
    }
`,g=r.A`
    :host {
        --smtc-padding-content-xSmall: 4px;
        --smtc-ctrl-choice-padding-horizontal: 0px;

        /* Ruby Card Spacing */
        --ent-ruby-card-gap: 24px;

        /* Feed Nav Spacing Tokens */
        --ent-feed-nav-tab-padding-vertical: 6px;
        --ent-feed-nav-tab-padding-horizontal: 12px;
        --ent-feed-nav-container-border-width: 1px;
    }
`,b=r.A`
    :host {
        --smtc-size-ctrl-choice-base: 16px;
        --smtc-size-ctrl-sm-default: 32px;
        --smtc-size-ctrl-sm-icon: 18px;
        --smtc-size-ctrl-default: 24px;

        /* Ruby Card Sizes */
        --ent-ruby-card-width: 360px;
        --ent-ruby-card-height: 424px;
        --ent-ruby-card-content-height: 336px;
    }
`,v=r.A`
    :host {
        --smtc-stroke-width-ctrl-choice-rest: 2px;
    }
`,x=r.A` ${l}
`,m=r.A` ${h} ${u} ${p} ${g} ${b} ${v}
`,f=r.A` ${d.On} ${m}
`.withBehaviors((0,s.G2)(x)),w="prg-rubyent",y="isEntThemeEnabledKey";function $(){if(!n.vv.has(y)){var t,i;const e="enterprise"===(null===(t=o.T3.CurrentRequestTargetScope)||void 0===t?void 0:t.audienceMode),r=Boolean(null===(i=a.Rb.CurrentFlightSet)||void 0===i?void 0:i.has(w)),s=e&&r;n.vv.set(y,String(s))}return"true"===n.vv.get(y)?f:d.On}},19594(t,i,e){e.d(i,{M(){return u}});var o=e(4126),a=e(74849),n=e(44453),r=e(52699),s=e(30664),d=e(12640),l=e(58792);const h=a.A`
.popover-anchor[icon]{filter:var(--filter-color)}`,c=a.A`
.heading{-webkit-line-clamp:2}.popover-anchor{color:${n.T3}}:host([color="dark"]) .popover-anchor{color:${n.Nd}
}
`,u=a.A`
.popover-slot[type="dialog"]::backdrop{background-color:rgba(0,0,0,0.4)}.button-close{background:url(${(0,l.rA)().StaticsUrl}/latest/fluent-icons/dismiss_16_regular.svg);border:0;height:16px;width:16px;cursor:pointer}.dialog{border-radius:8px;border:0;cursor:auto;height:400px;width:600px;overflow:unset;padding:0}.dialog-container{height:inherit;margin:22px}.dialog-content{height:300px;display:block;overflow-y:auto;user-select:none;-webkit-user-select:none}.dialog-header{align-items:center;display:flex;justify-content:space-between;padding-bottom:22px}.dialog-title{font-size:20px;margin:0;user-select:none;-webkit-user-select:none}.popover-anchor{align-items:center;background:transparent;border:none;color:inherit;cursor:pointer;font-size:12px;max-width:195px;overflow:hidden;padding:0;text-overflow:ellipsis;-webkit-line-clamp:1;white-space:nowrap;z-index:${s.I}}.popover-anchor:hover{text-decoration:underline}.popover-anchor[icon]{background:url(${(0,l.rA)().StaticsUrl}/latest/fluent-icons/info_16_regular.svg) !important;height:16px;width:16px}.tooltip{color:inherit;background-color:var(--color-card-background);border-radius:var(--borderRadiusXLarge,${r.g4});
    box-shadow: 0px 0px 2px var(--shadow-primary-color), 0px 4px 8px var(--shadow-secondary-color);
    font-size: 12px;
    height: fit-content;
    max-height: 300px;
    padding: 12px;
    position: fixed;
    text-align: center;
    width: 150px;
    z-index: ${s.I}}.tooltip::after{content:"";position:absolute;top:100%;left:50%;transform:translateX(-50%);border-width:10px;border-style:solid;border-color:var(--color-card-background) transparent transparent transparent}`.withBehaviors(new o.o("ruby",!0,c),new d.N(null,h))},40032(t,i,e){e.d(i,{X(){return o}});const o="showOrHideCOntentBadge"},47630(t,i,e){e.d(i,{GD(){return d},Xx(){return s},Z$(){return l},r_(){return r}});var o=e(96950),a=e(60402),n=e(69259);const r="popover-feed-card-slot",s=t=>o.qy`<button class="popover-anchor" @click=${i=>"openModal"===t.popoverAction?t.renderPopoverCallback("openModal"):""} data-t=${t.telemetryTag||""} ?icon=${"show"===t.popoverAction} @mouseenter=${i=>"openModal"!==t.popoverAction?t.renderPopoverCallback("show"):""} @mouseleave=${i=>"openModal"!==t.popoverAction?t.renderPopoverCallback("hide"):""} popovertarget="${r}" ${(0,a.K)("refPopoverAnchor")} title=${t.title}>${(0,n.z)("show"!==t.popoverAction,o.qy`${t.title}`)}</button>`,d=t=>o.qy`<span class="tooltip" ${(0,a.K)("refPopoverElement")}>${t}</span>`,l=(t,i,e,r,s)=>o.qy`<dialog class="dialog" ${(0,a.K)("refPopoverElement")}><div class="dialog-container"><div class="dialog-header"><h3 class="dialog-title">${t}</h3><button class="button-close" @click=${t=>e("closeModal")}></button></div><span class="dialog-content">${i} ${(0,n.z)(Boolean(r)&&Boolean(s),o.qy`<a class="dilaog-url" href="${r}" target="_blank">${s}</a>`)}</span></div></dialog>`},53914(t,i,e){e.d(i,{c(){return r}});var o=e(14475),a=e(96950),n=e(77793);const r=t=>{const i=t.variant?` ${t.variant}`:"";return a.qy`<div class="call-to-action${i}"><a class="call-to-action-text" href=${t.href||""} target="${o.z._blank}" title="${t.callToAction||""}" ${(0,n.Ib)()} data-t=${t.telemetryTag||""}>${t.callToAction||""}</a></div>`}},54147(t,i,e){e.d(i,{registerCSResponsiveCard(){return sr}});var o=e(65614),a=e(56911),n=e(14475),r=e(60815),s=e(38493),d=e(52380),l=e(47630),h=e(78902),c=e(40032),u=e(61889),p=e(1349),g=e(22341),b=e(93552),v=e(17918),x=e(77367),m=e(45964),f=e(22760);const w=function(t){let i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"";(0,g.vV)(b.fbJ,i,`Video ID: ${t}`)};var y=e(26391),$=e(45102),k=e(58792),A=e(74998),z=e(92011),C=e(22870),F=e(10809),_=e(95239),T=e(5291),I=e(52356),B=e(15148),S=e(94043),j=e(26220),D=e(10910),V=e(2827),R=e(67689),E=e(80911),P=e(70775),L=e(83222);class M extends z.L{constructor(){super(...arguments),this.color="light",this.reportVisuallyReadyMissingRequiredData=!1,this.size="1u",this.useF3UX=!1,this.use22ptHeadings=!1,this.useGreyHoverEffect=!1,this.useAmpHoverEffect=!1,this.useBoxShadowHoverEffect=!1,this.useBgHoverEffect=!1,this.intraArticleClassic=!1,this.intraArticleDualClassic=!1,this.intraArticleBlackCTA=!1,this.popoverScrollModal=()=>{var t,i;null===(t=this.refPopoverSlot)||void 0===t||t.replaceChildren(),null===(i=this.refPopoverElement)||void 0===i||i.close(),window.removeEventListener("scroll",this.popoverScrollModal)},this.popoverScrollTooltip=()=>{var t,i;null===(t=this.refPopoverSlot)||void 0===t||t.replaceChildren(),null===(i=this.refPopoverSlot)||void 0===i||i.hidePopover(),window.removeEventListener("scroll",this.popoverScrollTooltip)}}get strings(){var t;return(null===(t=this.config)||void 0===t?void 0:t.localizedStrings)||{}}get showLikeButtonCardAction(){return"1u"===this.size}get isAdaptiveThemeEnabled(){return((0,V.is)()||(0,R.h)())&&this.ruby}get enableTallRubyCard(){var t;return Boolean((null===(t=this.config)||void 0===t?void 0:t.enableTallRubyCard)&&"1u"===this.size&&this.ruby)}get isTallOrFlexReverse(){var t;return this.enableTallRubyCard||Boolean(null===(t=(0,A.Th)())||void 0===t||null===(t=t.CurrentFlightSet)||void 0===t?void 0:t.has("prg-flex-hgt-rv"))}get enableRubyBottomSocialBar(){var t;return Boolean((null===(t=this.config)||void 0===t?void 0:t.enableRubyBottomSocialBar)&&this.enableTallRubyCard)}get isProng2(){return Boolean("winWidgets"===k.T3.AppType)}get isRubifyDashboard(){var t;return Boolean(null===(t=this.config)||void 0===t?void 0:t.enableRubifyDashboard)&&(0,S.S)()&&!(0,h.T)()}connectedCallback(){this.config=F.D.getConfig(),I.y.subscribeThemeChange(this),this.setFlightAttributes(),super.connectedCallback(),this.afterDOMRendered()}disconnectedCallback(){super.disconnectedCallback(),I.y.unsubscribeThemeChange(this)}immersiveChanged(t,i){this.mediaType&&i!==t&&this.handleThemeChange(I.y.appInDarkMode())}loadingChanged(t,i){this.mediaType&&i!==t&&this.handleThemeChange(I.y.appInDarkMode())}telemetryObject_cardChanged(t,i){var e;const o=i&&t&&i!==t,a=Boolean(null==i||null===(e=i.contract)||void 0===e||null===(e=e.ext)||void 0===e?void 0:e.height);o&&!a&&(0,E.E)(()=>this.v(!0))}afterDOMRendered(){(0,S.S)()&&(0,D._Z)(this).then(()=>{(0,B.D)(()=>this.v(),50)}),this.visualReadinessCallback&&this.visualReadinessCallback(1),this.visualReadinessCallback&&this.reportVisuallyReadyMissingRequiredData&&this.visualReadinessCallback(2)}handleThemeChange(t){this.color=t||this.immersive&&this.mediaType&&!this.ruby?"dark":"light";const i="dark"===this.color;_.p.setValueFor(this,T.q.from((0,C.Hs)(i?"#242424":"#FFFFFF")))}setFlightAttributes(){var t;(this.loadingEffect=this.config.enableShimmerEffect,this.msn=Boolean(this.msn||this.config.enableMsnCardStyle),this.responsiveHeight=this.config.responsiveHeight,this.responsiveWidth=this.config.responsiveWidth,this.responsiveHeight=Boolean(this.responsiveHeight||this.config.responsiveHeight),this.useF3UX=Boolean(this.useF3UX||this.config.useF3UX),this.use22ptHeadings=Boolean(this.use22ptHeadings||this.config.use22ptCardHeadings),this.useGreyHoverEffect=Boolean(this.config.useGreyHoverEffect),this.useAmpHoverEffect=Boolean(this.config.useAmpHoverEffect),this.useBoxShadowHoverEffect=Boolean(this.config.useBoxShadowHoverEffect),this.useBgHoverEffect=Boolean(this.config.useBgHoverEffect),(0,S.S)()&&!this.disableCntQueries)&&(this.disableCntQueries="1"===P._3.getQueryParameterByName("disableCntQueries",(0,j.iA)())||Boolean(null===(t=this.config)||void 0===t?void 0:t.disableCntQueries))}triggerPopover(t,i){var e;null===(e=this.refPopoverSlot)||void 0===e||e.replaceChildren();const o=HTMLElement.prototype.hasOwnProperty("popover");if("openModal"===i){var a;null===(a=this.refPopoverSlot)||void 0===a||a.setAttribute("type","dialog");const t=i=>{if(!this.refPopoverElement)return;const e=this.refPopoverElement.getBoundingClientRect();e.top<=i.clientY&&i.clientY<=e.top+e.height&&e.left<=i.clientX&&i.clientX<=e.left+e.width||(this.refPopoverElement.close(),this.refPopoverElement.removeEventListener("click",t))};window.requestAnimationFrame(()=>{"openModal"===i&&this.refPopoverElement&&(this.refPopoverElement.addEventListener("click",t),window.addEventListener("scroll",this.popoverScrollModal))})}else{var n,r,s,d,l,h,c,u;if("closeModal"===i)return this.title=this.k,this.k="",null===(n=this.refPopoverSlot)||void 0===n||n.removeAttribute("type"),null===(r=this.refPopoverElement)||void 0===r||r.close(),void window.removeEventListener("scroll",this.popoverScrollModal);if("show"!==i)return"hide"===i?(this.title=this.k,this.k="",null===(s=this.refPopoverSlot)||void 0===s||s.removeAttribute("type"),o&&(null===(d=this.refPopoverSlot)||void 0===d||d.hidePopover()),null===(l=this.refPopoverSlot)||void 0===l||l.removeAttribute("popover"),void window.removeEventListener("scroll",this.popoverScrollTooltip)):void 0;null===(h=this.refPopoverSlot)||void 0===h||h.setAttribute("type","tooltip"),null===(c=this.refPopoverSlot)||void 0===c||c.setAttribute("popover",""),o&&(null===(u=this.refPopoverSlot)||void 0===u||u.showPopover()),window.addEventListener("scroll",this.popoverScrollTooltip)}let p;var g;(this.k=this.title,this.title="",t)&&(p=(null===(g=t.render(this,this.refPopoverSlot))||void 0===g?void 0:g.lastChild)||void 0,p&&"openModal"===i&&p.showModal());return p}v(t){var i,e;if(null===(i=this.telemetryObject_card)||void 0===i||!i.contract)return;const o=this.offsetHeight||0,a=null==this?void 0:this.offsetTop,n=!o||void 0===a,r=this.offsetWidth||0,s=null==this?void 0:this.offsetLeft,d=!r||void 0===s;let l={};if(n||d){const i={cardId:this.id,renderedHeight:o,yPosition:a,renderedWidth:r,xPosition:s,isRelayout:t};x.YT.sendClientLogEvent({type:"warning",message:"Failed to get dimensions for card telemetry update",pb:i})}if(n&&d)return;n||(l={...l,height:o,y:a}),d||(l={...l,width:r,x:s});const h={...this.telemetryObject_card.contract,ext:{...this.telemetryObject_card.contract.ext,...l}},c=new L.$(h);this.telemetryObject_card=c,null===(e=this._)||void 0===e||e.call(this,this.id,o)}}(0,a.Cg)([(0,s.CF)({attribute:"auto-sized",mode:"boolean"})],M.prototype,"autoSized",void 0),(0,a.Cg)([s.CF],M.prototype,"color",void 0),(0,a.Cg)([(0,s.CF)({attribute:"grouped-item",mode:"boolean"})],M.prototype,"groupedItem",void 0),(0,a.Cg)([r.sH],M.prototype,"___heightReadyCallback",void 0),(0,a.Cg)([(0,s.CF)({attribute:"hide-card-type"})],M.prototype,"hideCardType",void 0),(0,a.Cg)([(0,s.CF)({mode:"fromView"})],M.prototype,"id",void 0),(0,a.Cg)([(0,s.CF)({mode:"fromView"})],M.prototype,"title",void 0),(0,a.Cg)([(0,s.CF)({mode:"boolean"})],M.prototype,"immersive",void 0),(0,a.Cg)([(0,s.CF)({mode:"boolean"})],M.prototype,"loading",void 0),(0,a.Cg)([(0,s.CF)({attribute:"loading-effect",mode:"boolean"})],M.prototype,"loadingEffect",void 0),(0,a.Cg)([(0,s.CF)({attribute:"media-type"})],M.prototype,"mediaType",void 0),(0,a.Cg)([(0,s.CF)({attribute:"no-content",mode:"boolean"})],M.prototype,"onlyRenderOuterLayer",void 0),(0,a.Cg)([r.sH],M.prototype,"refPopoverAnchor",void 0),(0,a.Cg)([r.sH],M.prototype,"refPopoverElement",void 0),(0,a.Cg)([r.sH],M.prototype,"refPopoverSlot",void 0),(0,a.Cg)([(0,s.CF)({attribute:"responsive-height",mode:"boolean"})],M.prototype,"responsiveHeight",void 0),(0,a.Cg)([(0,s.CF)({attribute:"responsive-width",mode:"boolean"})],M.prototype,"responsiveWidth",void 0),(0,a.Cg)([(0,s.CF)({attribute:"segment",mode:"boolean"})],M.prototype,"segment",void 0),(0,a.Cg)([(0,s.CF)({attribute:"size"})],M.prototype,"size",void 0),(0,a.Cg)([r.sH],M.prototype,"telemetryObject_card",void 0),(0,a.Cg)([r.sH],M.prototype,"disableCntQueries",void 0),(0,a.Cg)([r.sH],M.prototype,"visualReadinessCallback",void 0),(0,a.Cg)([(0,s.CF)({attribute:"wide",mode:"boolean"})],M.prototype,"wide",void 0),(0,a.Cg)([(0,s.CF)({attribute:"carousel-only",mode:"boolean"})],M.prototype,"carouselOnly",void 0),(0,a.Cg)([(0,s.CF)({attribute:"f3",mode:"boolean"})],M.prototype,"useF3UX",void 0),(0,a.Cg)([(0,s.CF)({attribute:"use-22-pt-headings",mode:"boolean"})],M.prototype,"use22ptHeadings",void 0),(0,a.Cg)([(0,s.CF)({attribute:"use-grey-hover-effect",mode:"boolean"})],M.prototype,"useGreyHoverEffect",void 0),(0,a.Cg)([(0,s.CF)({attribute:"use-amp-hover-effect",mode:"boolean"})],M.prototype,"useAmpHoverEffect",void 0),(0,a.Cg)([(0,s.CF)({attribute:"use-box-shadow-hover-effect",mode:"boolean"})],M.prototype,"useBoxShadowHoverEffect",void 0),(0,a.Cg)([(0,s.CF)({attribute:"use-bg-hover-effect",mode:"boolean"})],M.prototype,"useBgHoverEffect",void 0),(0,a.Cg)([(0,s.CF)({attribute:"msn",mode:"boolean"})],M.prototype,"msn",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ruby",mode:"boolean"})],M.prototype,"ruby",void 0),(0,a.Cg)([(0,s.CF)({attribute:"intraArticle",mode:"boolean"})],M.prototype,"intraArticle",void 0),(0,a.Cg)([(0,s.CF)({attribute:"isIntraFeedAd",mode:"boolean"})],M.prototype,"isIntraFeedAd",void 0),(0,a.Cg)([(0,s.CF)({attribute:"isIntraClassicAd",mode:"boolean"})],M.prototype,"isIntraClassicAd",void 0),(0,a.Cg)([(0,s.CF)({attribute:"intraFeedAdWeather",mode:"boolean"})],M.prototype,"intraFeedAdWeather",void 0),(0,a.Cg)([(0,s.CF)({attribute:"intra-article-classic",mode:"boolean"})],M.prototype,"intraArticleClassic",void 0),(0,a.Cg)([(0,s.CF)({attribute:"intra-article-dual-classic",mode:"boolean"})],M.prototype,"intraArticleDualClassic",void 0),(0,a.Cg)([(0,s.CF)({attribute:"intraArticleBlackCTA",mode:"boolean"})],M.prototype,"intraArticleBlackCTA",void 0),(0,a.Cg)([(0,s.CF)({attribute:"watchAdVideo",mode:"boolean"})],M.prototype,"watchAdVideo",void 0),(0,a.Cg)([(0,s.CF)({attribute:"watchInarticleAd",mode:"boolean"})],M.prototype,"watchInarticleAd",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ruby-right-rail-ads",mode:"boolean"})],M.prototype,"rubyRightRailAds",void 0),(0,a.Cg)([(0,s.CF)({attribute:"gem-page",mode:"boolean"})],M.prototype,"gemPage",void 0),(0,a.Cg)([(0,s.CF)({attribute:"enable-ad-social-bar",mode:"boolean"})],M.prototype,"enableAdSocialBar",void 0),(0,a.Cg)([(0,s.CF)({attribute:"linear-ad",mode:"boolean"})],M.prototype,"linearAd",void 0),(0,a.Cg)([r.Jg],M.prototype,"isAdaptiveThemeEnabled",null),(0,a.Cg)([r.Jg],M.prototype,"enableTallRubyCard",null),(0,a.Cg)([r.Jg],M.prototype,"isTallOrFlexReverse",null),(0,a.Cg)([r.Jg],M.prototype,"enableRubyBottomSocialBar",null),(0,a.Cg)([r.Jg],M.prototype,"isProng2",null),(0,a.Cg)([r.Jg],M.prototype,"isRubifyDashboard",null);var U=e(57702),H=e(17857),O=e(83273),W=e(67589);class G{get showMoreFewerCardMetadata(){return{useCommunityReactions:!0,locale:this.card.data.locale}}constructor(t){var i,e,o,a;(this.showMoreButtonSelected=!1,this.overlayType=0,this.shouldShowOverlay=!1,this.showLikeTooltip=!1,this.hideOverlay=!1,this.getShowMoreFewerCardStatus=()=>{var t,i,e;return(null===(t=U.Pi.showMoreFewerStatus)||void 0===t?void 0:t[null===(i=this.card.data)||void 0===i?void 0:i.id])??(null===(e=this.card.data)||void 0===e?void 0:e.cardActionStatus)??0},this.undo=()=>{var t,i,e,o,a;const n=this.overlayType;switch(n){case 0:(0,U.J6)().UnshowMore((null===(t=this.card.data)||void 0===t?void 0:t.id)||"",this.showMoreFewerCardMetadata,this.getShowMoreFewerCardStatus()^H.J.showMore);break;case 1:this.togglePublisherFollowState();break;case 2:(0,U.J6)().UnshowFewer((null===(i=this.card.data)||void 0===i?void 0:i.id)||"",this.showMoreFewerCardMetadata,this.getShowMoreFewerCardStatus()^H.J.showFewer);break;case 3:(0,U.J6)().Unmute((null===(e=this.card.data)||void 0===e||null===(e=e.providerData)||void 0===e?void 0:e.id)||"");break;case 6:case 7:(0,U.J6)().undoAdFeedback((null===(o=this.card.data)||void 0===o?void 0:o.id)||"");break;case 8:(0,U.J6)().unsaveContent((null===(a=this.card.data)||void 0===a?void 0:a.id)||"")}this.dismissHideCard()},this.dismissHideCard=()=>{this.card.hideCardType=void 0,this.shouldShowOverlay=!1,this.card.removeEventListener("mouseover",this.stopAutoDismiss),this.card.removeEventListener("mouseout",this.startAutoDismiss)},this.stopAutoDismiss=()=>{clearTimeout(this.dismissTimer),this.dismissTimer=void 0,this.card.addEventListener("mouseout",this.startAutoDismiss)},this.startAutoDismiss=()=>{this.dismissTimer||(this.dismissTimer=window.setTimeout(()=>{this.dismissHideCard()},1e4))},this.togglePublisherFollowState=()=>{var t,i;const e=(0,U.J6)(),o=null===(t=this.card.data)||void 0===t||null===(t=t.providerData)||void 0===t?void 0:t.profileId;if(!o)return;const a={actionPosition:"",contentId:(null===(i=this.card.data)||void 0===i?void 0:i.id)||"undefined"};this.isPublisherFollowed?e.Unfollow(o,a):e.Follow(o,a)},this.toggleShowMore=()=>{const t=(0,U.J6)(),i=this.getShowMoreFewerCardStatus();if(this.showMoreButtonSelected){var e;t.UnshowMore((null===(e=this.card.data)||void 0===e?void 0:e.id)||"",this.showMoreFewerCardMetadata,i^H.J.showMore)}else{var o;const e=i&H.J.showFewer?i^H.J.showMore^H.J.showFewer:i^H.J.showMore;t.ShowMore((null===(o=this.card.data)||void 0===o?void 0:o.id)||"",this.showMoreFewerCardMetadata,e),window.showMoreOverlayTriggered||this.hideOverlay||(this.card.hideCardType=O.j.rubyOverlay,this.overlayType=0,window.showMoreOverlayTriggered=!0)}},this.triggerIssueReporting=()=>{var t,i,e,o,a,n,r,s,d;const l=this.card.data;window.dispatchEvent(new CustomEvent("launchIssueReporting",{detail:{metaData:{},enabled:!0,article:{id:l.id,headlineTitle:l.title,href:l.destinationUrl,image:{alt:null===(t=l.mediaData)||void 0===t?void 0:t.altText,src:null===(i=l.mediaData)||void 0===i?void 0:i.src},provider:{id:null===(e=l.providerData)||void 0===e?void 0:e.id,profileId:null===(o=l.providerData)||void 0===o?void 0:o.profileId,name:null===(a=l.providerData)||void 0===a?void 0:a.name,image:{alt:null===(n=l.providerData)||void 0===n?void 0:n.name,src:null===(r=l.providerData)||void 0===r?void 0:r.logoImage}},abstract:null===(s=l.metadata)||void 0===s?void 0:s.abstract,reasons:null===(d=l.metadata)||void 0===d?void 0:d.reasons,source:"msn"},parentTelemetryObject:this.card.telemetryObject_card,enabledModerationReport:!0,updateFeedOnHide:!1,vertical:"ntp"}}))},this.shouldShowOverlayChanged=(t,i)=>{window.requestAnimationFrame(()=>{this.card.refInteractBtn&&i&&this.card.refInteractBtn.focus()})},this.launchChannelStore=()=>{window.dispatchEvent(new CustomEvent("launchChannelStore"))},this.card=t,null!==(i=this.card.data)&&void 0!==i&&i.providerData)&&(this.removeFollowStatusListener=U.Pi.registerPublisherFollowStatusListener(t=>{var i;let{profileId:e,value:o}=t;e===(null===(i=this.card.data)||void 0===i||null===(i=i.providerData)||void 0===i?void 0:i.profileId)&&(this.isPublisherFollowed=o)}),this.isPublisherFollowed=(o=this.card.data.providerData.profileId,a=null===(e=this.card.data)||void 0===e?void 0:e.cardActionStatus,void 0!==U.Pi.publisherFollowStatus[o]?U.Pi.publisherFollowStatus[o]:a&&(a&H.J.followedPublisher)>0));this.removeShowMoreFewerStatusListener=U.Pi.registerShowMoreFewerStatusListener(t=>{var i;let{contentId:e,value:o}=t;e===(null===(i=this.card.data)||void 0===i?void 0:i.id)&&(this.showMoreButtonSelected=!!(o&&(o&H.J.showMore)>0))})}dispose(){var t,i;this.dismissHideCard(),null===(t=this.removeFollowStatusListener)||void 0===t||t.call(this),null===(i=this.removeShowMoreFewerStatusListener)||void 0===i||i.call(this)}hideCardTypeChanged(t,i){i&&(this.dismissTimer=window.setTimeout(()=>{this.dismissHideCard()},1e4),this.card.addEventListener("mouseover",this.stopAutoDismiss))}get getWhyAmISeeReasons(){var t,i;const e=this.card.data,o=(null===(t=e.metadata)||void 0===t?void 0:t.reasons)&&(null===(i=e.metadata)||void 0===i?void 0:i.reasons[0]);var a;return o?{type:o.type,dynamicValue:o.follow?o.follow.name:null===(a=o.category)||void 0===a?void 0:a.name}:{type:W.QK.fallback,dynamicValue:""}}getShowMoreSelected(){return this.showMoreButtonSelected}async reportAd(t,i,e){if(t){let o=t;if(e){const i=new URL(t),a=new URL(e),n=new URLSearchParams(i.search),r=a.searchParams.get("rlink");r&&n.append("rlink",r),i.search=n.toString(),o=i.toString()}const a=o.concat(`&f=${i}`);new Image(1,1).src=a}this.overlayType=6}}(0,a.Cg)([r.sH],G.prototype,"isPublisherFollowed",void 0),(0,a.Cg)([r.sH],G.prototype,"showMoreButtonSelected",void 0),(0,a.Cg)([r.sH],G.prototype,"overlayType",void 0),(0,a.Cg)([r.sH],G.prototype,"shouldShowOverlay",void 0),(0,a.Cg)([r.sH],G.prototype,"showLikeTooltip",void 0),(0,a.Cg)([r.Jg],G.prototype,"getWhyAmISeeReasons",null);var N=e(3933),K=e(99691),q=e(76736),X=e(86240),J=e(35341);class Y extends M{constructor(){super(...arguments),this.errorAttributionImage=!1,this.errorStateMedia="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/BB10piIP.img?w=268&h=140&q=90&m=6&f=jpg&u=t",this.hasMediaFailed=!1,this.hidePreviewBadges=!1,this.renderAbstract=!1,this.showBadge=!0,this.target=n.z._blank,this.adVA=!1,this.adVA2=!1,this.rubyVA=!1,this.adPA=!1,this.ad=!1,this.adCashback=!1,this.cardAddedForOcvTracking=!1,this.titleTruncated=!1,this.disableSubmitButton=!0,this.hideCardButtons=[],this.disableHideStoryIcon=!1,this.tooltipIsSet=!1,this.canLoadHoverElements=!1,this.triggerDisclaimer=t=>{if(!this.popoverData)return;const i=this.triggerPopover("tooltip"===this.popoverData.type?(0,l.GD)(this.popoverData.data.text):(0,l.Z$)(this.popoverData.data.title,this.popoverData.data.text,this.triggerDisclaimer,this.popoverData.data.url,this.strings.adDisclaimerLearnMore),t);if(i&&"tooltip"===this.popoverData.type){var e,o;const t=null===(e=this.refPopoverAnchor)||void 0===e?void 0:e.getBoundingClientRect(),a=null===(o=this.refPopoverElement)||void 0===o?void 0:o.getBoundingClientRect();t&&a&&(i.style.top=t.y-t.height-a.height-5+"px",i.style.left=t.x-a.width/2+t.width/2+"px")}},this.showOrHideBadge=t=>{const i=t;(null==i?void 0:i.detail)==this.id&&(this.showBadge=!this.showBadge)}}get defaultCta(){var t,i;if(this.shouldUseAdDTSTemplate&&null!==(t=this.adDTSTemplateConfig)&&void 0!==t&&t.enableDefaultCta)return null===(i=this.strings)||void 0===i?void 0:i.ctaLearnMoreText}get adUniqueId(){var t;return null===(t=this.data)||void 0===t||null===(t=t.items)||void 0===t||null===(t=t[0])||void 0===t?void 0:t.uniqueId}get shouldUseInlineVideoPlayer(){var t;return"shorts"===this.size&&!(null===(t=this.config.childRefs)||void 0===t||!t.videoCardWC)}get shouldRenderVideoElement(){var t;return!this.shouldUseInlineVideoPlayer&&!this.data.isInfopane&&"0.5u"!==this.size&&((null===(t=this.videoData)||void 0===t||null===(t=t.videoFile)||void 0===t?void 0:t.url)||this.isValidMotionThumbnailUrl)}get shouldRenderInlineVideoPlayer(){return this.isTTVRMarked&&this.shouldUseInlineVideoPlayer}get videoPreviewUrl(){var t,i;return this.config.enableVideoPreview?null===(t=this.previewController)||void 0===t?void 0:t.videoPreviewUrl:null===(i=this.videoData)||void 0===i||null===(i=i.videoFile)||void 0===i?void 0:i.url}get isValidMotionThumbnailUrl(){var t;return Boolean(this.config.enableVideoPreview&&(null===(t=this.data.metadata)||void 0===t||null===(t=t.videoMetadata)||void 0===t?void 0:t.motionThumbnailUrl))}get videoData(){var t,i,e,o;if(null===(t=this.data)||void 0===t||!t.id)return;const a="shorts"===this.size&&this.config.shortsQualityIndex?this.config.shortsQualityIndex:void 0,n=(t=>{const{externalVideoFiles:i,imageUrl:e,enablePreload:o,videoId:a,videoMetadata:n,selectedVideoQualityIndex:r}=t,s=(0,m._q)(i,r);return{enablePreload:o,imageUrl:e,videoDuration:(0,f.jc)(null==n?void 0:n.playTime),videoFile:s,videoId:a}})({enablePreload:Boolean(this.data.useMobile),externalVideoFiles:(null===(i=this.data)||void 0===i?void 0:i.externalVideoFiles)||[],imageUrl:(null===(e=this.mediaData)||void 0===e?void 0:e.src)||"",videoId:this.data.id,videoMetadata:null===(o=this.data.metadata)||void 0===o?void 0:o.videoMetadata,selectedVideoQualityIndex:a});return n}get isProngCopilotOverride(){return this.config.enableProngCopilotOverride}get specialCJKYaheiFont(){return this.config.specialCJKYaheiFont}get specialCJKNtsFont(){return this.config.specialCJKNtsFont}get accessibleLabel(){var t;if(this.heading)return null!==(t=this.attributionData)&&void 0!==t&&t.name?`${this.heading}, ${this.attributionData.name}`:this.heading}get showLikeButtonCardAction(){var t;return!(null!==(t=this.data)&&void 0!==t&&t.hideLikeButton||!this.likeButtonProps)}get showDislikeButtonCardAction(){var t,i;return Boolean(!!this.dislikeButtonProps&&(null===(t=this.config)||void 0===t?void 0:t.enableRubyBottomSocialBar)&&(null===(i=this.config)||void 0===i?void 0:i.enableTallRubyCard))}get showCommentButtonCardAction(){var t,i;return Boolean(!!this.commentButtonProps&&(null===(t=this.config)||void 0===t?void 0:t.enableRubyBottomSocialBar)&&(null===(i=this.config)||void 0===i?void 0:i.enableTallRubyCard))}get isAdSocialBarEnabled(){return Boolean(this.enableAdSocialBar&&!this.ruby)}get enableShortsInlineConsumption(){var t;return(0,S.S)()&&((null===k.T3||void 0===k.T3||null===(t=k.T3.HostPage)||void 0===t?void 0:t.originalUrl)||"").includes("islinear=1")}get isTooltipResizeFixEnabled(){var t;return!(null!==A.Rb&&void 0!==A.Rb&&null!==(t=A.Rb.CurrentFlightSet)&&void 0!==t&&t.has("prg-ad-ttip-rf"))}get popoverData(){var t;return this.popoverDataField?this.popoverDataField:null===(t=this.data)||void 0===t?void 0:t.popoverData}set popoverData(t){this.popoverDataField=t}get hasStandalonePopover(){var t;if("dialog"===(null===(t=this.popoverData)||void 0===t?void 0:t.type)){const t=this.popoverData.data;return!(!t.text||!t.title)}return!1}get shouldShowStandalonePopover(){return!this.watchAdVideo&&!this.callToAction&&this.hasStandalonePopover}get shouldShowRubyAdSlug(){var t,i;if(this.watchAdVideo||this.callToAction||this.intraArticleDualClassic)return!1;if(this.hasStandalonePopover)return!1;return this.adVA2||!(null!==(t=this.popoverData)&&void 0!==t&&null!==(t=t.data)&&void 0!==t&&t.text)||!(null!==(i=this.popoverData)&&void 0!==i&&null!==(i=i.data)&&void 0!==i&&i.title)}connectedCallback(){var t;super.connectedCallback(),this.enableSpecialFWInCJK=!(null===(t=this.config)||void 0===t||!t.enableSpecialFWInCJK),this.initCanLoadHoverElements(),(0,S.S)()&&(0,h.T)()&&(this.vpTest=!0),this.onlyRenderOuterLayer||(this.prepVAAdAttributes(),this.ruby&&this.prepAdFeedback(),this.renderAbstract=Boolean(void 0===this.mediaType||this.showAbstract||this.ad),this.setContentFlightAttributes(),(0,S.S)()&&(this.ad&&this.data&&this.handleXandrVisibilityTracking(),this.waitForHydration()),this.afterContentCardDOMRendered())}disconnectedCallback(){var t,i,e,o;super.disconnectedCallback(),this.responsiveWidth&&window.removeEventListener(c.X,this.showOrHideBadge),null===(t=this.rubyOverlayController)||void 0===t||t.dispose(),null===(i=this.rubyLikeController)||void 0===i||i.dispose(),null===(e=this.rubyDislikeController)||void 0===e||e.dispose(),void 0!==this.logAdDTSRafId&&(window.cancelAnimationFrame(this.logAdDTSRafId),this.logAdDTSRafId=void 0),void 0!==this.adDTSDescClampRafId&&(window.cancelAnimationFrame(this.adDTSDescClampRafId),this.adDTSDescClampRafId=void 0),null===(o=this.adDTSDescClampResizeObserver)||void 0===o||o.disconnect(),this.adDTSDescClampResizeObserver=void 0,this.removeXandrVisibilityTracking()}adAttributesChanged(t,i){i!==t&&(i&&i.length>4&&(this.adAttributes=i.slice(0,4)),this.prepVAAdAttributes())}titleChanged(t,i){this.titleTruncated&&i&&(this.tooltipIsSet=!1,this.titleTruncated=!1)}afterContentCardDOMRendered(){var t;null!==(t=this.mediaData)&&void 0!==t&&t.src||this.ad||this.markVisuallyReady(),this.responsiveWidth&&window.addEventListener(c.X,this.showOrHideBadge),this.ad&&this.storeAdsForOcvFeedback()}handleContentCardLinkClick(t){var i;return this.$emit("link-invoked",t),null===(i=this.onClickLink)||void 0===i||i.call(this,t),!this.preventDefaultClick||!this.preventDefaultClick(t)}setAttributeForTooltip(){if(this.config.enableRemoveTooltip){if(!this.refHeading)return;if(this.isTooltipResizeFixEnabled){const t=this.refHeading.scrollHeight>this.refHeading.offsetHeight+2;this.config.enableTitleForTruncate&&t?(this.setAttribute("title",this.heading||""),this.titleTruncated=!0):(this.setAttribute("title",""),this.titleTruncated=!1)}else{if(this.tooltipIsSet)return;const t=this.refHeading.scrollHeight>this.refHeading.offsetHeight+2;(!this.config.enableTitleForTruncate||this.config.enableTitleForTruncate&&!t)&&(this.titleTruncated=!0,this.setAttribute("title","")),this.tooltipIsSet=!0}}}markVisuallyReady(){var t,i;null!==(t=this.config)&&void 0!==t&&t.enableAdImageSizeMismatch&&this.ad&&!this.responsiveWidth&&this.refCardImage&&(0,X.RG)(this.id,this.href,null===(i=this.mediaData)||void 0===i?void 0:i.src,this.refCardImage);this.visualReadinessCallback&&this.visualReadinessCallback(3)}onAttributionImageError(){var t;(0,g.vV)(b.JLI,"Error fetching attribution img source","Src: "+(null===(t=this.attributionData)||void 0===t?void 0:t.src)+", Article ID: "+this.id,{shouldSampleErrorsForTreatment1:!0}),this.errorAttributionImage=!0}onMediaError(){var t;if(this.hasMediaFailed&&this.refCardImage&&this.refCardImage.src==this.errorStateMedia)return this.immersive=!1,this.mediaType=void 0,void(this.renderAbstract=!0);if(!this.hasMediaFailed){var i;if((0,g.vV)(b.qog,"Error fetching card img source","Src: "+(null===(t=this.mediaData)||void 0===t?void 0:t.src)+", Article ID: "+this.id,{shouldSampleErrorsForTreatement1:!0}),this.ad)(0,y.T)({id:this.id,rLink:this.href,imgLink:null===(i=this.mediaData)||void 0===i?void 0:i.src});this.markVisuallyReady(),this.hasMediaFailed=!0}}setContentFlightAttributes(){var t;this.checkDisableHideStoryButton(),this.enable1UImmersive3LineTitle=this.config.enable1UImmersive3LineTitle&&"_2x_2y"!=this.size,this.gradientClass=null===(t=this.data)||void 0===t?void 0:t.lightGradientClass,this.fontTrackingStyle="",this.cjkEarnedDifferences=this.config.cjkEarnedDifferences,this.config.enableFontTrackingV1&&(this.fontTrackingStyle="v1"),this.config.enableFontTrackingV2&&(this.fontTrackingStyle="v2"),this.fontWeightStyle="",this.config.enableFontWeightNormal&&(this.fontWeightStyle="normal"),this.config.hideCardActionsIcon&&(this.hideCardActions=!0),this.immersive||(this.use1uCard2LineTitle=this.config.use1uCard2LineTitle),this.useWindowsShellCardStyle=this.config.useWindowsShellCardStyle,this.hideActionRow=Boolean(this.ruby&&!this.ad),this.hideCardActions=Boolean(this.ruby&&!this.config.enableCardActionInKumo&&!this.watchAdVideo),this.disableFollowAction=this.config.disableFollowAction,this.disableBadge=this.config.disableBadge,this.enableFlipTitleProvider=this.config.enableFlipTitleProvider,this.disableRichSocialReactions=this.config.disableRichSocialReactions,this.hoverImgZoomRatio=this.config.hoverImgZoomRatio}waitForHydration(){(0,D._Z)(this).then(async()=>{var t,i;null!==(t=this.mediaData)&&void 0!==t&&t.src&&null!==(i=this.refCardImage)&&void 0!==i&&i.complete&&this.markVisuallyReady(),this.mediaType===u.z.video&&this.setupPreviewController(),this.checkDisableHideStoryButton(),this.ruby&&(this.H(),this.rubyOverlayController=new G(this),this.rubyOverlayController.hideOverlay="0.5u"===this.size),(0,v.dT)().then(()=>{this.isTTVRMarked=!0})})}refHeadingChanged(){var t,i,e;(0,S.S)()&&"5_river"===this.adDTSStyleKey&&null!==(t=this.data)&&void 0!==t&&t.description&&null!==A.Rb&&void 0!==A.Rb&&null!==(i=A.Rb.CurrentFlightSet)&&void 0!==i&&i.has(J.kd)&&(this.setAttribute("dts-river-fix",""),null===(e=this.adDTSDescClampResizeObserver)||void 0===e||e.disconnect(),"ResizeObserver"in window&&(this.adDTSDescClampResizeObserver=new ResizeObserver(()=>{this.scheduleAdDTSDescriptionClamp()}),this.refHeading&&this.adDTSDescClampResizeObserver.observe(this.refHeading)),this.scheduleAdDTSDescriptionClamp())}scheduleAdDTSDescriptionClamp(){void 0!==this.adDTSDescClampRafId&&window.cancelAnimationFrame(this.adDTSDescClampRafId),this.adDTSDescClampRafId=window.requestAnimationFrame(()=>{this.adDTSDescClampRafId=void 0;const t=this.refHeading,i=null==t?void 0:t.querySelector(".ad-dts-title"),e=null==t?void 0:t.querySelector(".ad-dts-description");if(!t||!i||!e)return;const o=window.getComputedStyle(t);let a=parseFloat(o.lineHeight);if(!a||isNaN(a)){const t=parseFloat(o.fontSize);a=isNaN(t)||t<=0?0:1.2*t}if(!a)return;const n=Math.ceil(i.scrollHeight/a),r=Math.max(0,3-n);r>0?(e.style.setProperty("display","-webkit-box"),e.style.setProperty("-webkit-box-orient","vertical"),e.style.setProperty("overflow","hidden"),e.style.setProperty("-webkit-line-clamp",String(r))):(e.style.removeProperty("display"),e.style.removeProperty("-webkit-box-orient"),e.style.removeProperty("overflow"),e.style.removeProperty("-webkit-line-clamp"))})}H(){var t,i,e,o,a;const n={id:null===(t=this.data)||void 0===t?void 0:t.id,locale:null===(i=this.data)||void 0===i?void 0:i.locale};if(this.rubyLikeController=new N.G(n),this.likeButtonProps={id:this.id,titleText:null===(e=this.strings)||void 0===e?void 0:e.rubyLikeTitleText,likeButtonTooltip:this.ruby?null===(o=this.strings)||void 0===o?void 0:o.rubyLikeButtonTooltipV2:null===(a=this.strings)||void 0===a?void 0:a.rubyLikeButtonTooltip,telemetryTag:this.telemetryTag_showMore,telemetryTagUndo:this.telemetryTag_undoShowMore,ruby:this.ruby,renderBottomTooltip:this.enableRubyBottomSocialBar,rubyLikeController:this.rubyLikeController},this.enableRubyBottomSocialBar){var r,s,d,l,h,c,u,p;this.rubyDislikeController=new K.C(n),this.rubyCommentController=new q.c(n);const t=null===(r=this.rubySocialBarData)||void 0===r?void 0:r.disabledComments;this.likeButtonProps={...this.likeButtonProps,likeButtonTooltip:null===(s=this.strings)||void 0===s?void 0:s.rubyLikeButtonTooltipV3,likeCount:(null===(d=this.rubySocialBarData)||void 0===d?void 0:d.upvotes)||0,renderCount:!0},this.dislikeButtonProps={id:this.id,titleText:null===(l=this.strings)||void 0===l?void 0:l.rubyDislikeButtonTooltip,dislikeButtonTooltip:null===(h=this.strings)||void 0===h?void 0:h.rubyDislikeButtonTooltip,telemetryTag:this.telemetryTag_hideCard,telemetryTagUndo:this.telemetryTag_undoHide,ruby:this.ruby,renderBottomTooltip:this.enableRubyBottomSocialBar,rubyDislikeController:this.rubyDislikeController,dislikeCount:(null===(c=this.rubySocialBarData)||void 0===c?void 0:c.downvotes)||0},this.commentButtonProps={id:this.id,commentButtonTooltip:null===(u=this.strings)||void 0===u?void 0:u.rubyCommentButtonTooltip,telemetryTag:this.telemetryTag_commentButton,rubyCommentController:this.rubyCommentController,commentCount:t?0:null===(p=this.rubySocialBarData)||void 0===p?void 0:p.comments,destinationUrl:t?this.href:`${this.href}#comments`,renderCount:!0}}}handleXandrVisibilityTracking(){this.ad&&this.adUniqueId&&this.shadowRoot&&this.shadowRoot.host&&(0,$.YW)(new Map([[this.adUniqueId,this.shadowRoot.host]]))}storeAdsForOcvFeedback(){var t;if(this.cardAddedForOcvTracking)return;const i="AllAds";window[i]||(window[i]=new Map),window[i].set(this.id,null===(t=this.shadowRoot)||void 0===t?void 0:t.host),this.cardAddedForOcvTracking=!0}prepVAAdAttributes(){var t;(this.adVA||this.adVA2)&&(this.adAttributesCount=null===(t=this.adAttributes)||void 0===t?void 0:t.length)}prepAdFeedback(){const t=[{value:"RepeatedAd",text:this.strings.reportAdRepeatedAdText||"Seen this ad multiple times"},{value:"InappropriateAd",text:this.strings.reportAdInappropriateAdText||"Ad was inappropriate"},{value:"NotInterested",text:this.strings.reportAdNotInterestedText||"Not interested in this ad"},{value:"MisleadingAd",text:this.strings.reportAdMisleadingAdText||"Misleading ad or spam"}];this.adFeedbackProps={selectedFeedbackType:void 0,feedbackTypes:t,localizedStrings:{},chooseFeedbackOption:t=>{t.preventDefault(),this.adFeedbackProps&&(this.adFeedbackProps.selectedFeedbackType=t.target.value,this.disableSubmitButton&&(this.disableSubmitButton=!1))},submitFeedback(){},...this.adFeedbackProps}}get stringsAdLabel(){return"zh-cn"==k.T3.CurrentMarket?this.ruby&&this.adCashback?this.strings.adMsftLabel:this.strings.adLabel:this.ruby&&this.adCashback?this.strings.adMsftSponsored||"Microsoft Sponsored":this.ruby||this.config.enableAdSponsoredText?this.strings.adSponsored||"Sponsored":this.strings.adLabel||"Ad"}logAdDTSLineHeights(){var t;return(0,S.S)()&&null!==A.Rb&&void 0!==A.Rb&&null!==(t=A.Rb.CurrentFlightSet)&&void 0!==t&&t.has(J.IL)?(this.logAdDTSRafId=window.requestAnimationFrame(()=>{var t,i;const e=this.refHeading,o=null===(t=this.shadowRoot)||void 0===t||null===(i=t.querySelector)||void 0===i?void 0:i.call(t,".ad-dts-description");if(e&&this.data){var a;const t=window.getComputedStyle(e),i=parseFloat(t.lineHeight)||1.2*parseFloat(t.fontSize);let n,r,s,d=0;if(o){const t=window.getComputedStyle(o);r=parseFloat(t.lineHeight)||1.2*parseFloat(t.fontSize),n=o.scrollHeight,s=Math.ceil(n/r),d=o.offsetHeight}const l=e.scrollHeight,h=o?l-(n??0):l,c=Math.floor(h/i),u={adDTSStyleKey:this.adDTSStyleKey,headingText:this.heading,headingTextHeight:h,headingLineHeight:i,headingActualLines:c,descriptionText:null===(a=this.data)||void 0===a?void 0:a.description,descScrollHeight:n,descriptionHeight:d,descLineHeight:r,descActualLines:s,hasDescription:!!o};x.YT.sendClientLogEvent({message:"AdDTS card line height info",pb:u,type:"information"})}}),""):""}removeXandrVisibilityTracking(){this.ad&&this.adUniqueId&&(0,$.r6)([this.adUniqueId])}async setupPreviewController(){var t,i,e;if(!await this.shouldSetupPreviewController())return;const o=[];this.config.enableVideoCardHover&&o.push("hover"),this.shouldEnableScrollPreview()&&o.push("scroll");const a=this.config.enableClosedCaptions2C&&"2c"===this.size?null===(t=this.data.metadata)||void 0===t||null===(t=t.videoMetadata)||void 0===t?void 0:t.closedCaptions:void 0;this.previewController=new d.i({cardElement:this,config:this.config,logError:w,enablePreloadOnSetupTime:this.config.enableShortsPreload&&"shorts"===this.size,previewTriggers:o,useMobile:this.data.useMobile,videoElement:this.refVideoElement,videoData:{id:`${this.data.id}-${Date.now()}`,videoFile:null===(i=this.videoData)||void 0===i?void 0:i.videoFile,motionThumbnailUrl:null===(e=this.data.metadata)||void 0===e||null===(e=e.videoMetadata)||void 0===e?void 0:e.motionThumbnailUrl,closedCaptions:a},hidePreviewBadges:this.hidePreviewBadges??!1})}shouldEnableScrollPreview(){const t=!!this.config.disableVideoPreviewATF&&!!this.data.isFirstSectionCard,i=void 0!==this.config.maxRowToDisableAutoPreview&&void 0!==this.data.order&&this.data.order<=this.config.maxRowToDisableAutoPreview;return!t&&!i}async shouldSetupPreviewController(){var t;if(await(0,D._Z)(this),await(0,v.dT)(),!this.data||!this.config||this.previewController)return!1;if(!this.refVideoElement&&(null!==(t=this.videoData)&&void 0!==t&&t.videoFile||this.isValidMotionThumbnailUrl))return!1;return Boolean(this.config.enableVideoCardHover||this.config.enableVideoCardScroll)}async setupPreviewControllerForInlinePlayer(){const t=[];this.config.enableVideoCardHover&&t.push("hover"),this.previewController=new d.i({cardElement:this,config:this.config,isForInlinePlayer:!0,logError:w,previewTriggers:t,videoData:{id:this.data.id}})}refVideoElementChanged(){var t,i;(null===(t=this.videoData)||void 0===t?void 0:t.imageUrl)&&function(t,i){const e=new Image,o=()=>{null==i||i(),e.onload=null,e.onerror=null};e.onload=()=>o(),e.onerror=()=>o(),e.src=t}(null===(i=this.videoData)||void 0===i?void 0:i.imageUrl,()=>this.markVisuallyReady()),this.setupPreviewController()}initCanLoadHoverElements(){this.config.enableElementsLazyLoad&&!this.enableRubyBottomSocialBar||(this.canLoadHoverElements=!0)}handleContentCardMouseEnter(){this.handleContentCardMouseAction(),(0,p.O)(this,"ResponsiveContentCard")}handleContentCardMouseLeave(){this.handleContentCardMouseAction(),(0,p.J)(this,"ResponsiveContentCard")}handleContentCardMouseAction(){this.setAttributeForTooltip(),!1===this.canLoadHoverElements&&(this.canLoadHoverElements=!0)}handleContentCardLinkFocus(){!1===this.canLoadHoverElements&&(this.canLoadHoverElements=!0)}checkDisableHideStoryButton(){var t;this.disableHideStoryIcon=this.config.disableHideStoryIcon||!1===(null===(t=this.data)||void 0===t?void 0:t.enableCardHideStoryIcon)}handleContentCardRightClick(t,i,e,o){var a;return!this.config.enableOverrideRightClick||(null===(a=this.onRightClick)||void 0===a||a.call(this,t,i,e,o,!0),!1)}handleCompanionButtonClick(t){var i;t.preventDefault(),this.$emit("link-invoked",t),null===(i=this.onClickCompanionButton)||void 0===i||i.call(this,t,this.href)}}(0,a.Cg)([r.sH],Y.prototype,"abstract",void 0),(0,a.Cg)([(0,s.CF)({attribute:"abstract-lines"})],Y.prototype,"abstractLines",void 0),(0,a.Cg)([r.sH],Y.prototype,"attributionData",void 0),(0,a.Cg)([r.sH],Y.prototype,"rubySocialBarData",void 0),(0,a.Cg)([r.sH],Y.prototype,"badgeProps",void 0),(0,a.Cg)([r.sH],Y.prototype,"isTTVRMarked",void 0),(0,a.Cg)([r.sH],Y.prototype,"callToAction",void 0),(0,a.Cg)([(0,s.CF)({attribute:"cjk",mode:"boolean"})],Y.prototype,"cjkEarnedDifferences",void 0),(0,a.Cg)([(0,s.CF)({attribute:"companion",mode:"boolean"})],Y.prototype,"companion",void 0),(0,a.Cg)([(0,s.CF)({attribute:"companionButtonText"})],Y.prototype,"companionButtonText",void 0),(0,a.Cg)([r.sH],Y.prototype,"contentIndicator",void 0),(0,a.Cg)([r.sH],Y.prototype,"data",void 0),(0,a.Cg)([r.sH],Y.prototype,"errorAttributionImage",void 0),(0,a.Cg)([r.sH],Y.prototype,"hasMediaFailed",void 0),(0,a.Cg)([r.sH],Y.prototype,"heading",void 0),(0,a.Cg)([(0,s.CF)({attribute:"heading-lines"})],Y.prototype,"headingLines",void 0),(0,a.Cg)([r.sH],Y.prototype,"headingPrefix",void 0),(0,a.Cg)([(0,s.CF)({attribute:"hide-action-row",mode:"boolean"})],Y.prototype,"hideActionRow",void 0),(0,a.Cg)([(0,s.CF)({attribute:"hide-card-actions",mode:"boolean"})],Y.prototype,"hideCardActions",void 0),(0,a.Cg)([(0,s.CF)({attribute:"disable-follow-action",mode:"boolean"})],Y.prototype,"disableFollowAction",void 0),(0,a.Cg)([(0,s.CF)({attribute:"disable-badge",mode:"boolean"})],Y.prototype,"disableBadge",void 0),(0,a.Cg)([(0,s.CF)({attribute:"enable-flip-title-provider",mode:"boolean"})],Y.prototype,"enableFlipTitleProvider",void 0),(0,a.Cg)([(0,s.CF)({attribute:"disable-rich-social-reactions",mode:"boolean"})],Y.prototype,"disableRichSocialReactions",void 0),(0,a.Cg)([(0,s.CF)({attribute:"hide-preview-badges",mode:"boolean"})],Y.prototype,"hidePreviewBadges",void 0),(0,a.Cg)([r.sH],Y.prototype,"href",void 0),(0,a.Cg)([r.sH],Y.prototype,"mediaData",void 0),(0,a.Cg)([(0,s.CF)({attribute:"media-type"})],Y.prototype,"mediaType",void 0),(0,a.Cg)([(0,s.CF)({attribute:"blocked-advertiser",mode:"boolean"})],Y.prototype,"blockedAdvertiser",void 0),(0,a.Cg)([r.sH],Y.prototype,"popoverDataField",void 0),(0,a.Cg)([r.sH],Y.prototype,"refCardImage",void 0),(0,a.Cg)([r.sH],Y.prototype,"refHeading",void 0),(0,a.Cg)([r.sH],Y.prototype,"refInteractBtn",void 0),(0,a.Cg)([r.sH],Y.prototype,"renderAbstract",void 0),(0,a.Cg)([(0,s.CF)({attribute:"show-badge",mode:"boolean"})],Y.prototype,"showBadge",void 0),(0,a.Cg)([(0,s.CF)({mode:"fromView"})],Y.prototype,"target",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_anchor",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_hideCard",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_moreActions",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_showMore",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_undoShowMore",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_undoHide",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_commentButton",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ai-heading",mode:"boolean"})],Y.prototype,"aiHeading",void 0),(0,a.Cg)([r.sH],Y.prototype,"adAttributes",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ad-attr-count"})],Y.prototype,"adAttributesCount",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ad-va",mode:"boolean"})],Y.prototype,"adVA",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ad-va2",mode:"boolean"})],Y.prototype,"adVA2",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ruby-va",mode:"boolean"})],Y.prototype,"rubyVA",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ad-pa",mode:"boolean"})],Y.prototype,"adPA",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ad",mode:"boolean"})],Y.prototype,"ad",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ad-cashback",mode:"boolean"})],Y.prototype,"adCashback",void 0),(0,a.Cg)([(0,s.CF)({attribute:"casual-games-v3-ad"})],Y.prototype,"casualGamesV3Ad",void 0),(0,a.Cg)([r.sH],Y.prototype,"enableSpecialFWInCJK",void 0),(0,a.Cg)([(0,s.CF)({attribute:"ad-dts-style-key"})],Y.prototype,"adDTSStyleKey",void 0),(0,a.Cg)([r.sH],Y.prototype,"adDTSTemplateConfig",void 0),(0,a.Cg)([r.sH],Y.prototype,"adDTSComponentDataMap",void 0),(0,a.Cg)([(0,s.CF)({attribute:"use-ad-dts-template",mode:"boolean"})],Y.prototype,"shouldUseAdDTSTemplate",void 0),(0,a.Cg)([r.sH],Y.prototype,"description",void 0),(0,a.Cg)([r.sH],Y.prototype,"adFeedbackProps",void 0),(0,a.Cg)([r.sH],Y.prototype,"disableSubmitButton",void 0),(0,a.Cg)([r.sH],Y.prototype,"href_adButton",void 0),(0,a.Cg)([r.sH],Y.prototype,"href_adChoiceButton",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_adDisclaimerButton",void 0),(0,a.Cg)([r.sH],Y.prototype,"adSelectionCriteria",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_adButton",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_adChoiceButton",void 0),(0,a.Cg)([r.sH],Y.prototype,"telemetryTag_callToAction",void 0),(0,a.Cg)([r.sH],Y.prototype,"previewController",void 0),(0,a.Cg)([r.sH],Y.prototype,"refVideoElement",void 0),(0,a.Cg)([r.Jg],Y.prototype,"shouldUseInlineVideoPlayer",null),(0,a.Cg)([r.Jg],Y.prototype,"shouldRenderVideoElement",null),(0,a.Cg)([r.Jg],Y.prototype,"shouldRenderInlineVideoPlayer",null),(0,a.Cg)([r.Jg],Y.prototype,"videoPreviewUrl",null),(0,a.Cg)([r.Jg],Y.prototype,"isValidMotionThumbnailUrl",null),(0,a.Cg)([r.Jg],Y.prototype,"videoData",null),(0,a.Cg)([r.Jg],Y.prototype,"isProngCopilotOverride",null),(0,a.Cg)([r.Jg],Y.prototype,"specialCJKYaheiFont",null),(0,a.Cg)([r.Jg],Y.prototype,"specialCJKNtsFont",null),(0,a.Cg)([r.Jg],Y.prototype,"accessibleLabel",null),(0,a.Cg)([r.sH],Y.prototype,"hideCardButtons",void 0),(0,a.Cg)([r.sH],Y.prototype,"hideCardUndoButton",void 0),(0,a.Cg)([r.sH],Y.prototype,"disableHideStoryIcon",void 0),(0,a.Cg)([s.CF],Y.prototype,"use1uCard2LineTitle",void 0),(0,a.Cg)([s.CF],Y.prototype,"useWindowsShellCardStyle",void 0),(0,a.Cg)([r.sH],Y.prototype,"canLoadHoverElements",void 0),(0,a.Cg)([s.CF],Y.prototype,"enable1UImmersive3LineTitle",void 0),(0,a.Cg)([(0,s.CF)({attribute:"show-abstract",mode:"boolean"})],Y.prototype,"showAbstract",void 0),(0,a.Cg)([s.CF],Y.prototype,"gradientClass",void 0),(0,a.Cg)([s.CF],Y.prototype,"fontTrackingStyle",void 0),(0,a.Cg)([s.CF],Y.prototype,"fontWeightStyle",void 0),(0,a.Cg)([(0,s.CF)({attribute:"hover-img-zoom-ratio"})],Y.prototype,"hoverImgZoomRatio",void 0),(0,a.Cg)([(0,s.CF)({attribute:"dialog-showing",mode:"boolean"})],Y.prototype,"dialogShowing",void 0),(0,a.Cg)([(0,s.CF)({attribute:"vp-test",mode:"boolean"})],Y.prototype,"vpTest",void 0),(0,a.Cg)([r.sH],Y.prototype,"rubyOverlayController",void 0),(0,a.Cg)([r.sH],Y.prototype,"rubyLikeController",void 0),(0,a.Cg)([r.sH],Y.prototype,"rubyDislikeController",void 0),(0,a.Cg)([r.sH],Y.prototype,"rubyCommentController",void 0),(0,a.Cg)([r.sH],Y.prototype,"likeButtonProps",void 0),(0,a.Cg)([r.sH],Y.prototype,"dislikeButtonProps",void 0),(0,a.Cg)([r.sH],Y.prototype,"commentButtonProps",void 0),(0,a.Cg)([r.Jg],Y.prototype,"showLikeButtonCardAction",null),(0,a.Cg)([r.Jg],Y.prototype,"showDislikeButtonCardAction",null),(0,a.Cg)([r.Jg],Y.prototype,"showCommentButtonCardAction",null),(0,a.Cg)([r.Jg],Y.prototype,"isAdSocialBarEnabled",null),(0,a.Cg)([r.Jg],Y.prototype,"enableShortsInlineConsumption",null),(0,a.Cg)([r.Jg],Y.prototype,"isTooltipResizeFixEnabled",null);var Q=e(31662),Z=e(88635),tt=e(74849),it=e(4126),et=e(22131),ot=e(13187),at=e(35279),nt=e(32257),rt=e(77345),st=e(29222),dt=e(87204),lt=e(8984),ht=e(46028),ct=e(62175),ut=e(52699),pt=e(55023),gt=e(24816),bt=e(50882),vt=e(97062),xt=e(78222),mt=e(5111),ft=e(42495),wt=e(7896),yt=e(69904),$t=e(44453),kt=e(26248),At=e(30664),zt=e(37079),Ct=e(74838),Ft=e(87944),_t=e(14701),Tt=e(8675),It=e(19594),Bt=e(3678),St=e(75830),jt=e(77558);const Dt=tt.A`
:host(:not([wide])){[class*="ad-dts-tmpl-"] .ad-text-col{background:linear-gradient(rgba(0,0,0,0) 33%,rgba(0,0,0,0.54) 66%);padding:0 16px;display:grid;grid-template-columns:1fr auto;grid-auto-rows:auto;align-content:end;height:100%}[class*="ad-dts-tmpl-"] .ad-text-col > *{grid-column:1 / -1}[class*="ad-dts-tmpl-"] .ad-footer{display:flex;align-items:center;justify-content:space-between;padding:10px 0;height:24px}[class*="ad-dts-tmpl-"]:has(.call-to-action,.popover-anchor) .ad-footer{grid-column:1;grid-row:999;display:inline-flex;flex-direction:row-reverse;gap:5px;justify-content:flex-end}[class*="ad-dts-tmpl-"]:has(.call-to-action) .call-to-action{grid-column:2;grid-row:999;align-self:center;margin:10px 0;justify-self:end}[class*="ad-dts-tmpl-"]:has(.popover-anchor) .call-to-action{display:none}[class*="ad-dts-tmpl-"] .ad-footer .popover-anchor{margin-left:auto}}`,Vt=tt.A`
[class*="ad-dts-tmpl-"].ad-dts-row{width:100%;height:100%}:host([wide][use-ad-dts-template]){.root{padding:0}}:host([wide]) [class*="ad-dts-tmpl-"]{&.ad-dts-row{display:flex;flex-direction:row}.ad-text-col{display:flex;flex-direction:column;justify-content:center;flex:1;min-width:0;overflow:hidden}.call-to-action{align-self:flex-start;border-radius:9999px;border:none;height:20px;padding:2px 12px;font-weight:600}.call-to-action-text{padding:0 0 2px 0}.ad-footer{position:absolute;bottom:12px;inset-inline-end:16px;display:flex;align-items:center;gap:4px;max-width:200px;overflow:hidden}.ad-label{flex-shrink:0;line-height:16px}.popover-anchor{flex-shrink:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.popover-anchor::after{content:"·";margin-inline-start:4px;display:inline-block;text-decoration:none}.popover-anchor{font-size:11px;line-height:16px;font-family:inherit}.heading{display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden}}`,Rt=tt.A.partial`
content: "";
position: absolute;
top: 0;
left: 0;
right: 0;
bottom: 0;
z-index: -1;
background: linear-gradient(0deg, rgba(33, 33, 33, 0.87) 0%, rgba(33, 33, 33, 0.87) 100%), var(--ad-dts-bg-img) lightgray 50% / cover no-repeat;
filter: blur(15px);
`,Et=tt.A.partial`
.ad-label,.popover-anchor,.popover-anchor::after{color:rgba(255,255,255,0.8)}.call-to-action{background-color:rgba(255,255,255,0.8)}.call-to-action-text{color:rgba(0,0,0,0.8)}`,Pt=tt.A`
:host([wide][use-ad-dts-template]){--responsive-card-background-override:#1F1F1F0D}`,Lt=tt.A`
${Vt} :host([wide]) .ad-dts-tmpl-1{&.ad-dts-row::after{${Rt}
        left: 304px;
    }

    ${Et} .media{position:relative;aspect-ratio:1;width:304px;height:304px;z-index:1}.ad-text-col{padding:0 40px 0 20px;z-index:1}.attribution{margin-bottom:12px}.call-to-action{margin-top:20px}.heading{font-size:var(--ad-dts-title-font-size,28px);line-height:var(--ad-dts-title-line-height,36px);-webkit-line-clamp:var(--ad-dts-title-max-lines,3)}}${Dt}
`,Mt=tt.A`
${Vt} :host([wide]) .ad-dts-tmpl-2{&.ad-dts-row::after{${Rt}
    }

    ${Et} .media{position:relative;width:352px;height:235px;aspect-ratio:352/235;padding-left:32px;object-position:center center;align-self:center;border-radius:4px;z-index:1}.ad-text-col{padding:0 32px 0 16px;z-index:1}.attribution{margin-bottom:8px}.call-to-action{margin-top:16px}.heading{font-size:var(--ad-dts-title-font-size,20px);line-height:var(--ad-dts-title-line-height,28px);-webkit-line-clamp:var(--ad-dts-title-max-lines,5)}}${Dt}
`,Ut=tt.A`
${Vt} :host([wide]) .ad-dts-tmpl-3{&.ad-dts-row::after{${Rt}
    }

    ${Et} .media{position:relative;width:408px;height:213px;aspect-ratio:136/71;padding-left:40px;object-position:center center;align-self:center;border-radius:4px;z-index:1}.ad-text-col{padding:0 36px 0 16px;z-index:1}.attribution{margin-bottom:8px}.call-to-action{margin-top:16px}.heading{font-size:var(--ad-dts-title-font-size,20px);line-height:var(--ad-dts-title-line-height,28px);-webkit-line-clamp:var(--ad-dts-title-max-lines,4)}}${Dt}
`,Ht=tt.A`
${Vt} :host([wide]) .ad-dts-tmpl-1{&.ad-dts-row::after{left:304px}.media{position:relative;aspect-ratio:1;width:304px;height:304px;z-index:1}.ad-text-col{padding:0 40px 0 20px;z-index:1}.attribution{margin-bottom:8px}.call-to-action{margin-top:16px;height:28px;border:1px solid #D1D1D1;background-color:#FFFFFF}.call-to-action-text{font-size:14px;line-height:20px;color:#242424}.heading{font-size:var(--ad-dts-title-font-size,28px);line-height:var(--ad-dts-title-line-height,36px);-webkit-line-clamp:var(--ad-dts-title-max-lines,3)}.ad-footer{bottom:16px}.ad-label{line-height:12px}}${Dt}
`.withBehaviors((0,ht.U)("light",Pt)),Ot=tt.A`
${Vt} :host([wide]) .ad-dts-tmpl-2{.media{position:relative;width:376px;height:250px;aspect-ratio:188/125;padding-left:24px;object-position:center center;align-self:center;border-radius:4px;z-index:1}.ad-text-col{padding:0 24px 0 16px;z-index:1}.attribution{margin-bottom:8px}.call-to-action{margin-top:16px;border:1px solid #D1D1D1;background-color:#FFFFFF}.call-to-action-text{color:#242424}.heading{font-size:var(--ad-dts-title-font-size,20px);line-height:var(--ad-dts-title-line-height,28px);-webkit-line-clamp:var(--ad-dts-title-max-lines,5)}.ad-footer{bottom:16px}.ad-label{line-height:12px}}${Dt}
`.withBehaviors((0,ht.U)("light",Pt)),Wt=tt.A`
${Vt} :host([wide]) .ad-dts-tmpl-3{.media{position:relative;width:420px;height:219px;aspect-ratio:140/73;padding-left:28px;object-position:center center;align-self:center;border-radius:4px;z-index:1}.ad-text-col{padding:0 28px 0 16px;z-index:1}.attribution{margin-bottom:4px}.call-to-action{margin-top:16px;border:1px solid #D1D1D1;background-color:#FFFFFF}.call-to-action-text{color:#242424}.heading{font-size:var(--ad-dts-title-font-size,20px);line-height:var(--ad-dts-title-line-height,28px);-webkit-line-clamp:var(--ad-dts-title-max-lines,4)}.ad-footer{bottom:16px}.ad-label{line-height:12px}}${Dt}
`.withBehaviors((0,ht.U)("light",Pt)),Gt=`calc(${st.zkJ} * ${st.MU6})`,Nt=`calc(${st.WUG} * ${st.MU6})`,Kt=`${Gt} ${Gt} ${Nt} ${Nt}`,qt=tt.A`
:host([linear-ad][size="2c"]){--card-height:auto;max-width:${at.Mq.toString()}px;
    min-width: 632px;
    width: 100%;
    height: auto;
    background: ${nt.lHC};
    box-sizing: border-box;
    border-radius: calc(${st.tF1} * ${st.MU6});
    corner-shape: squircle;
    font-family: ${wt.O};grid-column:1 / 3;contain:content;content-visibility:auto;display:block}:host([linear-ad][size="2c"]),:host([linear-ad][size="2c"][ruby]){--card-height:auto;height:auto;max-height:none;min-height:0;aspect-ratio:unset;contain-intrinsic-height:none}:host([linear-ad][ad]),:host([linear-ad][responsive-height][ad]){--card-height:auto;height:auto}:host([linear-ad][size="2c"]) .root{height:auto;width:100%;padding:${st.$rH};
    border: ${dt.q_} solid ${nt.h7K};background:transparent;contain:none;content-visibility:visible}:host([linear-ad][size="2c"][ruby]) .root,:host([linear-ad][ruby]) .root{height:auto;contain-intrinsic-height:none}:host([linear-ad]) .content-card-container{flex-direction:column;gap:${nt.hW$};align-items:center;width:100%;height:auto}:host([linear-ad][size="2c"][media-type][ruby]) .ruby-image-container,:host([linear-ad][size="2c"][media-type][ruby]) .video-container{width:100%;height:373px;aspect-ratio:auto;border-radius:${Kt};corner-shape:squircle;overflow:hidden;position:relative;flex-shrink:0}:host([linear-ad]) .media{width:100%;height:100%;object-fit:cover;border-radius:0;aspect-ratio:inherit;transform:none !important;filter:none !important}:host([linear-ad]) .body{display:flex;flex-direction:column;align-items:flex-start;gap:${nt.LFA};width:100%;padding:0;min-height:0;height:auto;justify-content:flex-start}:host([linear-ad]) .text{padding:0;width:100%}`,Xt=tt.A` .action-row{max-width:25%;position:absolute;right:36px;bottom:54px;justify-content:space-between;align-items:center;padding:0}.action-row-sub-container{display:none}.call-to-action{background:rgba(0,0,0,0.55);border:none;border-radius:12px;min-height:40px;min-width:40px;padding:0 10px;display:inline-flex;align-items:center}.call-to-action-text,.call-to-action-text:visited{color:#e5ebfa;font-size:14px;font-weight:400;line-height:20px;text-decoration:none}`,Jt=tt.A` .action-row{display:none}`,Yt=tt.A` .action-row{display:none}`,Qt=tt.A` .action-row{display:none}`,Zt=tt.A` .action-row{display:none}`,ti=tt.A` .root{padding:0;width:536px;height:286px}.content-card-container{position:relative;border-radius:36px;overflow:hidden}.media{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;z-index:0}.image-container{position:absolute;top:0;left:0;width:100%;height:100%;z-index:0}.body{position:relative;z-index:1;background:linear-gradient(to bottom,transparent 0%,rgba(40,37,35,0.8) 70%);padding:36px;display:flex;flex-direction:column;justify-content:flex-end;min-height:200px}.text{padding:0;max-width:75%}.heading{font-size:18px;font-weight:600;line-height:26px;color:#fffbf8;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;text-decoration:none}.heading:visited{color:#fffbf8}.attribution{color:#fffbf8}.attribution-image{width:16px;height:16px;border-radius:50%}.attribution-text{color:#fffbf8}.attribution-divider{color:#fffbf8}.attribution-time{color:#fffbf8}`,ii=tt.A` .root{padding:0;width:248px;height:157px}.content-card-container{position:relative;border-radius:36px;overflow:hidden}.media{position:absolute;top:0;left:0;width:100%;height:100%;object-fit:cover;z-index:0}.image-container{position:absolute;top:0;left:0;width:100%;height:100%;z-index:0}.body{position:relative;z-index:1;background:linear-gradient(to bottom,transparent 0%,rgba(40,37,35,0.2) 27.885%,rgba(40,37,35,0.8) 70%);padding:24px;display:flex;flex-direction:column;justify-content:flex-end}.text{padding:0}.heading{font-size:18px;font-weight:600;line-height:26px;color:#fffbf8;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;text-decoration:none}.heading:visited{color:#fffbf8}.attribution{color:#fffbf8}.attribution-image{width:16px;height:16px;border-radius:6px}.attribution-text{color:#fffbf8}.attribution-divider{color:#fffbf8}.attribution-time{color:#fffbf8}`,ei=tt.A` .root{padding:0}.content-card-container{width:195px;height:267px;display:flex;flex-direction:column;justify-content:center;align-items:center;padding:12px;border-radius:36px;border:1px solid rgba(0,0,0,0.10);background:rgba(255,255,255,0.45)}.image-container{display:flex;padding:18px;align-items:flex-start;flex-shrink:0;align-self:stretch;border-radius:36px;overflow:hidden}.media{object-fit:cover;border-radius:36px;height:112px;width:195px}.body{display:flex;justify-content:center;flex-direction:column;background:none;padding:0;min-width:0;align-self:stretch;width:195px;max-width:-webkit-fill-available;padding:0px 8px 0px 8px}.text{width:100%;padding:0}.heading{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;align-self:stretch;overflow:hidden;color:#272320;font-feature-settings:'calt' off;text-overflow:ellipsis;font-size:18px;font-weight:650;line-height:26px;text-decoration:none}.heading:visited{color:#272320}.attribution{display:flex;align-items:center;gap:4px;align-self:stretch}.attribution-image{display:flex;width:16px;height:16px;justify-content:center;align-items:center;border-radius:6px;background:#F7FAFD}.attribution-text{color:#272320;text-align:center;font-feature-settings:'calt' off;font-size:14px;font-weight:480;line-height:20px}.attribution-divider{color:#272320;text-align:center;font-feature-settings:'calt' off;font-size:14px;font-weight:480;line-height:20px}.attribution-time{color:#272320;font-feature-settings:'calt' off;font-size:14px;font-weight:480;line-height:20px}`,oi=tt.A` .root{padding:0;width:265.6px;height:208px}.content-card-container{display:flex;width:265.6px;height:208px;flex-direction:column;align-items:flex-start;gap:8px}.image-container{display:flex;padding:18px;align-items:flex-start;flex:1 0 0;align-self:stretch;border-radius:36px;overflow:hidden}.media{width:100%;height:116px;object-fit:cover;border-radius:36px}.body{display:flex;flex-direction:column;background:none;padding:0;min-width:0;align-self:stretch}.text{padding:0;flex-direction:column-reverse}.heading{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;align-self:stretch;overflow:hidden;color:#272320;font-feature-settings:'calt' off;text-overflow:ellipsis;font-size:18px;font-weight:650;line-height:26px;text-decoration:none;margin-bottom:4px}.heading:visited{color:#272320}.attribution{display:flex;height:20px;align-items:center;align-self:stretch}.attribution-image{display:flex;width:16px;height:16px;justify-content:center;align-items:center;border-radius:6px;background:#F7FAFD}.attribution-text{color:#4C4642;text-align:center;font-feature-settings:'calt' off;font-size:12px;font-weight:450;line-height:16px}.attribution-divider{color:#4C4642;text-align:center;font-size:14px;font-weight:410;line-height:20px}.attribution-time{color:#4C4642;font-feature-settings:'calt' off;font-size:12px;font-weight:620;line-height:16px}`,ai=tt.A` .root{padding:0}.content-card-container{display:flex;width:731px;height:160px;padding:12px;align-items:flex-start;gap:20px;border-radius:48px;border:1px solid rgba(0,0,0,0.10);background:rgba(255,255,255,0.45);overflow:hidden;flex-direction:row}.image-container{display:flex;width:259.76px;flex-direction:column;align-items:flex-start;flex-shrink:0;align-self:stretch;border-radius:36px;overflow:hidden;background:#FFF}.media{width:260px;height:100%;object-fit:cover;aspect-ratio:191 / 100;border-radius:36px}.body{flex:1;display:flex;flex-direction:column;min-width:0;background:none;padding:8px 8px 8px 0}.text{padding:0;height:100%}.heading{flex:1 0 0;align-self:stretch;color:#272320;font-feature-settings:'calt' off;font-size:16px;font-weight:620;line-height:22px;text-decoration:none;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis}.heading:visited{color:#272320}.attribution{display:flex;height:28px;max-height:28px;align-items:center;gap:4px;flex:1 0 0;color:#272320}.attribution-image{display:flex;width:16px;height:16px;justify-content:center;align-items:center;border-radius:6px;background:#F7FAFD}.attribution-text{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;overflow:hidden;color:#272320;text-overflow:ellipsis;font-size:14px;font-weight:410;line-height:20px}.attribution-divider{color:#272320;text-align:center;font-size:14px;font-weight:410;line-height:20px}.attribution-time{color:#272320;font-size:14px;font-weight:650;line-height:20px}:host([size="1u"]) .root{height:346px}:host([size="1u"]) .content-card-container{flex-direction:column;width:auto;height:-webkit-fill-available;align-items:center;gap:0;background:rgba(255,255,255,0.80);border:1px solid var(--stroke-divider-subtle,rgba(0,0,0,0.10))}:host([size="1u"]) .image-container{width:312px;height:172px;align-self:auto;border-radius:48px 48px 32px 32px}:host([size="1u"]) .media{width:312px;height:172px;border-radius:48px 48px 32px 32px;aspect-ratio:auto}:host([size="1u"]) .body{padding:16px;width:280px}:host([size="1u"]) .heading{font-size:18px;font-weight:650;line-height:26px;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden}:host([size="1u"]) .attribution{flex:unset}:host([size="1u"]) .attribution-image{background:#FF4D00}:host([size="1u"]) .attribution-text{font-weight:450;text-align:center;font-feature-settings:'calt' off}:host([size="1u"]) .attribution-divider{font-weight:550;font-feature-settings:'calt' off}:host([size="1u"]) .attribution-time{font-weight:650;font-feature-settings:'calt' off}`,ni=tt.A` :host{--card-height:auto;border-radius:36px;overflow:hidden;box-shadow:none;background-color:inherit}`,ri=tt.A` :host{--card-height:auto;border-radius:36px;overflow:hidden;box-shadow:none;background-color:inherit}`,si=tt.A` :host{--card-height:auto;box-shadow:none !important;background-color:inherit}`,di=tt.A` :host{--card-height:auto;box-shadow:none !important;background-color:inherit}`,li=tt.A` :host{--card-height:auto;border-radius:48px;overflow:hidden;box-shadow:none !important;background-color:inherit}`,hi=tt.A` .card-actions-button-container{min-width:36px;min-height:36px;padding:0 6px;border-radius:12px;border:1px solid rgba(255,255,255,0.00);background:rgba(255,255,255,0.70);box-shadow:0 0.5px 0.5px 0.5px #FFF inset,0 1px 3px 0 rgba(0,0,0,0.15);opacity:0;transition:opacity 0.2s ease}:host(:hover) .card-actions-button-container,:host(:focus-within) .card-actions-button-container{opacity:1}.card-actions-button{background:none;border:none;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center}.card-actions-button img{width:24px;height:24px;flex-shrink:0}.card-actions-button:hover,.hide-card-button:hover{background:none}`,ci=tt.A`
    ${hi} .card-actions-button-container{top:8px;right:8px}`,ui=tt.A`
    ${hi} .card-actions-button-container{top:8px;right:8px}`,pi=tt.A`
    ${hi} .card-actions-button-container{top:25px;right:24px}`,gi=tt.A`
    ${hi} .card-actions-button-container{top:10px;right:18px}`,bi=tt.A`
    ${hi} .card-actions-button-container{top:16px;right:24px}:host([size="1u"]) .card-actions-button-container{top:32px;right:32px}`,vi=tt.A` .ad-label{font-family:${wt.O};
        font-weight: 500;
    }
`,xi=tt.A` .ad-label{font-family:${wt.O};
        font-weight: ${st.i2t};
    }
`,mi=tt.A` :host(:not([kumo])) .body{width:100%}.attribution{display:none}.text{padding-top:34px}.text .heading{-webkit-line-clamp:2}.attribution-container{font-size:${yt.Kg};
        max-width: 170px;
        display: inline-flex;
        align-items: center;
    }

    :host([intra-article-dual-classic]) {
        container-type: inline-size;
    }

    .card-actions-button-container {
        inset-inline-start: 8px;
    }

    @container (width < 430px) {
        .attribution-container {
            max-width: 160px;
        }
    }

    @container (width < 400px) {
        .attribution-container {
            max-width: 120px;
        }
    }

    @container (width < 375px) {
        .attribution-container {
            max-width: 110px;
        }
    }

    @container (width < 350px) {
        .attribution-container {
            max-width: 85px;
        }
    }

    @container (width < 340px) {
        .attribution-container {
            max-width: 70px;
        }
    }
}
`,fi=tt.A`
.cashback-badge{align-items:center;background:var(--Background-Control-On-image-Rest,rgba(0,0,0,0.60));border-radius:var(--Corner-Badge-S,6px);display:inline-flex;gap:var(--Gap-Between-Content-XS,4px);height:24px;justify-content:center;margin-inline-start:6px;padding:0px 4px;position:absolute;top:26px;z-index:${At.I}}.cashback-title{color:var(--Foreground-Static-inverted,#FFF);display:none;font-size:var(--Typography-Font-size-300,14px);line-height:var(--Typography-Line-height-300,20px);transition:all 0.2s ease;white-space:nowrap}:host(:hover) .cashback-title{align-items:center;display:flex}`,wi=tt.A`
:host([ad-va]) .va-attribute[type]::before,:host([ad-va2]) .va-attribute[type]::before{filter:invert(1)}.ad-choice{filter:var(--filter-color)}`,yi=tt.A`
.ad-label{color:${nt.C6c};
    font-size: ${st.VPb};
    font-family: ${nt.bNH};
    font-weight: 650;
    line-height: ${st.yHt};
    position: relative;
    z-index: ${jt.P.Above.toString()};
}
`,$i=tt.A`
${yi} .heading{-webkit-line-clamp:3}.action-row-sub-container{flex-direction:row}.attribution{height:auto;line-height:${nt.bfN}}.body:has(.call-to-action) .heading,.body:has(.popover-anchor) .heading{-webkit-line-clamp:2}.body:has(.call-to-action) .text,.body:has(.popover-anchor) .text{padding-bottom:${nt.yK7}}:host(:not([immersive])) .call-to-action .call-to-action-text,:host(:not([immersive])) .call-to-action .call-to-action-text:visited{color:${st.cDF};
    font-family: ${nt.bNH};
    font-size: ${nt.e1r};
    font-weight: ${st.fNx};
    line-height: ${nt.HoW};
}
`.withBehaviors(new it.o("specialCJKYaheiFont",!0,xi),new it.o("specialCJKNtsFont",!0,vi)),ki=tt.A`
:host([watchAdVideo]) .action-row-sub-container{align-items:center;width:100%}`,Ai=tt.A`
.overlay-cta-container{position:absolute;bottom:16px;right:16px;z-index:${At.I}}.overlay-cta-button{display:inline-flex;justify-content:center;align-items:center;gap:2px;flex-shrink:0;border-radius:999px;background:#2169EB;text-decoration:none;cursor:pointer;border:none;outline:none}.overlay-cta-button.fixed{padding:16px}.cta-icon-fixed{width:20px;height:20px}.overlay-cta-button.dynamic{padding:8px 16px 8px 21px;border-radius:50px}.cta-text-dynamic{color:#FFF;font-family:"Segoe UI";font-size:14px;font-style:normal;font-weight:600;line-height:20px}.cta-icon-dynamic{width:18px;height:18px;margin-top:2px}.overlay-cta-button .cta-icon-dynamic-compact{display:none}@media (max-width:500px){.overlay-cta-button.dynamic{display:inline-flex;align-items:center;justify-content:center;padding:16px;border-radius:999px}.overlay-cta-button.dynamic .cta-text-dynamic{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.overlay-cta-button.dynamic .cta-icon-dynamic{display:none}.overlay-cta-button.dynamic .cta-icon-dynamic-compact{display:inline-block;width:20px;height:20px}}`,zi=tt.A`
:host([watchinarticlead]) .action-row .ad-label{display:none}:host([watchinarticlead]) .call-to-action{z-index:0;background-color:#404040;width:48px;display:flex;align-items:center;justify-content:center;height:100%;border-radius:0px 12px 12px 0px}@media (max-width:${(0,Ft.c)(Q.YH-1)}){:host([watchinarticlead]) .action-row .ad-label{display:inline-block;color:#242424;font-family:"Segoe UI";font-size:11px;font-style:normal;font-weight:400;line-height:12px}:host([watchinarticlead]) .call-to-action{display:none}}`.withBehaviors((0,et.G2)(tt.A` :host([watchinarticlead]) .call-to-action{background-color:#F0F0F0}`)),Ci=tt.A`
:host([intraArticleBlackCTA]) .action-row .ad-label{display:none}:host([intraArticleBlackCTA]) .ad-label{font-size:${yt.Kg}}:host([intraArticleBlackCTA]) .call-to-action{z-index:0;background-color:#404040;width:48px;display:flex;align-items:center;justify-content:center;height:100%;border-radius:unset;border:none}:host([intraArticleBlackCTA]) .card-actions-button-container{margin-inline-start:calc(${ot.IU} * 1px)}:host([intraArticleBlackCTA][ad-va2]) .abstract{height:20px}:host([intraArticleBlackCTA][ad-va2]) .abstract > .va-attribute:not(:last-child)::after{content:"•";margin-inline-start:8px;opacity:1}:host([intraArticleBlackCTA][ad-va2]) .attribution{margin-block:11px 0px}${(0,Z.H5)(Z.j1.c1)}{:host([intraArticleBlackCTA]) .action-row .ad-label{display:inline-block;font-family:"Segoe UI";font-size:11px;font-style:normal;font-weight:400;line-height:12px}:host([intraArticleBlackCTA]) .call-to-action{display:none}:host([intraArticleBlackCTA]) .card-actions-button-container{margin-inline-start:unset}:host([intraArticleBlackCTA][ad-va2]) .text{flex-direction:column}:host([intraArticleBlackCTA][ad-va2]) .attribution{order:1;margin-block:0px}:host([intraArticleBlackCTA][ad-va2]) .heading{order:2;-webkit-line-clamp:1}:host([intraArticleBlackCTA][ad-va2]) .abstract{order:3;height:auto}:host([intraArticleBlackCTA][ad-va2]) .abstract > .va-attribute:not(:last-child)::after{content:none}}`.withBehaviors((0,et.G2)(tt.A` :host([intraArticleBlackCTA]) .call-to-action{background-color:#F0F0F0}`)),Fi=tt.A`
${yi}
`,_i=tt.A`
:host([ad-pa]) .ruby-image-container{aspect-ratio:1.2421 / 1}:host([ad-pa]) .ruby-image-container .media{object-fit:contain;background-color:unset}:host([ad-pa]) .body .text{gap:${st.J_f};
    padding-top: ${nt.ACF}}:host([ad-pa]) .attribution .attribution-image{margin-inline-end:${nt.IOY}}:host([ad-pa]) .attribution .attribution-text{font-size:${nt.Aps};
    font-weight: ${st.fNx};
    line-height: ${nt.LfE}}:host([ad-pa]) .product-ads-price{min-width:${nt.oED};
    padding: 0 ${nt.w97};
    margin-inline-end: ${st.iIh};
    top: calc(${st.iIh} + ${st.$rH});
    font-size: ${nt.lJ3};
    font-weight: ${st.IH6};
    line-height: ${nt.ESf};
    border-radius: ${nt.aJo};
    color: ${nt.lPe};
    background-color: ${nt.NNo};
}
`,Ti=tt.A`
:host([ad-pa]) .media{width:100%;aspect-ratio:1.3333 / 1;object-fit:contain;background-color:var(--color-card-background)}:host([ad-pa]) .body .text .attribution{height:auto;font-size:${yt.YV};
    font-weight: 700;
    line-height: ${yt.vr}}:host([ad-pa]) .product-ads-price{display:flex;align-items:center;align-self:end;gap:4px;justify-content:center;height:28px;min-width:20px;padding:0 6px;margin-inline-end:16px;position:absolute;top:14px;font-size:${yt.kS};
    font-weight: 410;
    line-height: ${yt.Fr};
    border-radius: 8px;
    color: inherit;
    background-color: var(--color-card-background);
}
`.withBehaviors(new it.o("ruby",!0,_i)),Ii=tt.A`.heading .ad-dts-description{font-size:${yt.Kg};
    line-height: ${yt.Z6};
    font-weight: ${yt.IH};
    margin-top: 2px;
}

/* Fix flight active (dts-river-fix attribute set by JS):
   Override .heading to block so title and description each get their own
   clamp. Description is hidden by default; JS shows it when title < 3 lines.
   --dts-heading-line-height captures the effective heading line-height so
   max-height stays in sync with JS (which reads getComputedStyle at runtime).
   It mirrors the hardcoded 26px override in responsive-content-card.styles.ts
   that shadows the typeRampPlus2LineHeight token. If that override changes,
   update the custom property value here to match. */
:host([dts-river-fix]) {
    --dts-heading-line-height: 26px;
}

:host([dts-river-fix]) .heading {
    display: block;
    -webkit-line-clamp: unset;
    max-height: calc(var(--dts-heading-line-height) * 3);
    overflow: hidden;
}

:host([dts-river-fix]) .heading .ad-dts-title {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
    overflow: hidden;
}

:host([dts-river-fix]) .heading .ad-dts-description {
    display: none;
}
`,Bi=tt.A`
.content-card-container .body{overflow:unset}${_t.B}
${Tt.E}
${It.M}
${Bt.c}
${Ai}
:host([immersive]) .ad-choice{filter:var(--filter-color)}:host([immersive]) .ad-label{color:white}.action-row-sub-container{display:inline-flex;gap:5px}.media{object-fit:cover}`.withBehaviors(new it.o("intraArticleDualClassic",!0,mi),new it.o("adCashback",!0,fi),new it.o("adDTSStyleKey","1_infopane",Lt),new it.o("adDTSStyleKey","1_two-square",Ht),new it.o("adDTSStyleKey","2_infopane",Mt),new it.o("adDTSStyleKey","2_two-square",Ot),new it.o("adDTSStyleKey","3_infopane",Ut),new it.o("adDTSStyleKey","3_two-square",Wt),new it.o("adDTSStyleKey","5_river",Ii),new it.o("adVA",!0,St.Ly),new it.o("adVA2",!0,St.Ly),new it.o("ruby",!0,$i),new it.o("responsiveWidth",!0,St.Lm),new it.o("watchAdVideo",!0,ki),new it.o("rubyVA",!0,St.cU),new it.o("watchInarticleAd",!0,zi),new it.o("intraArticleBlackCTA",!0,Ci),new it.o("enableAdSocialBar",!0,Fi),new it.o("adPA",!0,Ti),new it.o("linearAd",!0,qt),new it.o("casualGamesV3Ad","hero-infopane",Xt),new it.o("casualGamesV3Ad","hero",Jt),new it.o("casualGamesV3Ad","vertical-game",Yt),new it.o("casualGamesV3Ad","game",Qt),new it.o("casualGamesV3Ad","intra-feed",Zt),(0,ht.U)("dark",wi));var Si=e(79030);const ji=tt.A`
.card-actions-button,.hide-card-button{fill:${bt.A.LinkText};
}
`,Di=tt.A`
${gt.L}
.card-actions-button-container[ruby]{inset-block-start:calc(${nt.ACF} * 2);
    margin-inline-end: ${nt.ACF};
    gap: ${nt.VUD}}:host([immersive]) .card-actions-button-container[ruby]{inset-block-start:${nt.ACF}}:host([size="0.5u"]) .card-actions-button-container{inset-block-start:${nt.bJh}}.no-image-action-container[ruby]{margin-inline-end:0px;top:11px;right:11px;gap:8px}.like-card-button,.card-actions-button{position:relative;z-index:calc(${At.I} + 2);
}
`.withBehaviors(new it.o("enableRubyBottomSocialBar",!0,gt.n3)),Vi=tt.A`
:host([watchAdVideo]) .card-actions-button img{filter:invert(1)}`,Ri=tt.A`
:host([ruby][intra-article-classic][watchAdVideo]) .root{padding:0px}:host([ruby][intra-article-classic][watchAdVideo]) .text{padding:0px}:host([watchAdVideo]) .card-actions-button-container{position:inherit;margin-inline-start:auto;margin-inline-end:12px}:host([watchAdVideo]) .card-actions-button{background:none;border:none;opacity:1;padding:0;box-shadow:none;min-height:var(--card-actions-button-size);min-width:var(--card-actions-button-size);height:var(--card-actions-button-size);width:var(--card-actions-button-size)}:host([watchAdVideo]) .card-actions-button img{transform:var(--rotate-override,rotate(0deg));height:16px;width:16px}`.withBehaviors((0,et.G2)(Vi)),Ei=tt.A`
.card-actions-button-container{margin-inline-end:calc(${ot.IU} * -1px);
}
`,Pi=tt.A`
.card-actions-button img,.hide-card-button img{filter:invert(1)}`,Li=tt.A`
@media (forced-colors:active) and (prefers-color-scheme:dark){.card-actions-button img,.hide-card-button img{filter:invert(0)}}`,Mi=tt.A`
:host(:hover) .card-actions-button,:host(:hover) .hide-card-button,:host(:focus-within) .card-actions-button,:host(:focus-within) .hide-card-button{opacity:1}:host([immersive]) .card-actions-button-container{margin-inline-end:calc(${ot.IU} * 1px)}.card-actions-button,.hide-card-button{--card-actions-button-size:32px;align-items:center;background-color:#ffffff;border-radius:${ut.uk};
    border: 1px solid #d1d1d1;
    box-sizing: border-box;
    color: #242424;
    cursor: pointer;
    display: flex;
    fill: #242424;
    font-family: inherit;
    height: var(--card-actions-button-size);
    justify-content: center;
    min-width: var(--card-actions-button-size);
    opacity: 0;
    outline: none;
    transition: all 0.1s ease 0s;
    width: var(--card-actions-button-size);
    z-index: calc(${At.I} + 2)}@media (forced-colors:active) and (prefers-color-scheme:dark){.card-actions-button img,.hide-card-button img{filter:invert(1)}}.card-actions-button:hover,.hide-card-button:hover{background-color:#f5f5f5}.hide-card-button:hover{width:auto}.card-actions-button:focus-visible,.hide-card-button:focus-visible{opacity:1;outline:-webkit-focus-ring-color auto 1px;outline-offset:4px}.card-actions-button-container{align-items:center;align-self:end;display:flex;gap:4px;justify-content:center;margin-inline-end:calc(${ot.IU} * 1px);
    position: absolute;
    top: calc(${ot.IU} * 1px)}.hide-card-button::after{content:attr(title);display:-webkit-box;font-size:14px;height:20px;line-height:20px;max-width:0px;opacity:0;overflow:hidden;text-align:start;text-overflow:ellipsis;transition:all 0.2s ease-out 0s;word-break:break-all;-webkit-box-orient:vertical;-webkit-line-clamp:1}.hide-card-button:hover::after{margin-inline-start:0px;max-width:165px;opacity:1}.hide-card-button-text{text-wrap:nowrap}`.withBehaviors(new it.o("useF3UX",!0,Ei),new it.o("ruby",!0,Di),new it.o("watchAdVideo",!0,Ri),new it.o("casualGamesV3Ad","hero-infopane",ci),new it.o("casualGamesV3Ad","hero",ui),new it.o("casualGamesV3Ad","vertical-game",pi),new it.o("casualGamesV3Ad","game",gi),new it.o("casualGamesV3Ad","intra-feed",bi),(0,et.mr)(ji),new Si.l(Pi,Li)),Ui=tt.A` .like-action{border-radius:var(--CornerControl);background:rgba(27,29,31,1);border:1px solid rgba(71,75,80,1)}.action-item{color:rgba(195,200,206,1)}.body{background:rgba(33,36,41,1)}.close-btn{background:rgba(38,41,46,1);border:1px solid rgba(71,75,80,1)}.close-btn img,.action-item img{filter:invert(1)}.interact-btn img{filter:none}.interact-btn{color:rgba(35,39,43,1);background:rgba(246,249,252,1)}`,Hi=tt.A` .actions{align-self:flex-start;max-width:100%}.action-item{display:flex;align-items:center;justify-content:flex-start;padding:6px 8px;font-size:14px;margin-bottom:12px;cursor:pointer;border:none;background:none;max-width:100%}.action-item img{padding-right:4px;width:20px}.action-item span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.like-action{border-radius:var(--CornerControl);border:1px solid rgba(198,203,209,1);background:#fff}.close-btn:focus-visible,.interact-btn:focus-visible,.close-btn:focus,.interact-btn:focus{outline:-webkit-focus-ring-color auto 1px;outline-offset:4px}`,Oi=tt.A`:host{cursor:auto}.body{background:#f6f9fc;border:1px solid rgba(0,0,0,0.06);border-radius:12px;padding:16px;align-items:center;position:relative}.interact-btn{width:100%;height:40px;background:rgba(35,39,43,1);border-radius:12px;color:#fff;display:flex;justify-content:center;align-items:center;font-size:16px;cursor:pointer;text-decoration:inherit}.interact-btn:disabled{opacity:0.5}.interact-btn img{filter:invert(1)}.interact-btn span{font-size:16px;padding-left:4px}.title{font-size:20px;font-weight:500;margin:0}.close-btn{position:absolute;right:-8px;top:-8px;background:#fff;border:1px solid rgba(193,205,213,1);border-radius:8px;outline:none;width:32px;height:32px;display:flex;align-items:center;justify-content:center;cursor:pointer}${Hi} .content{width:228px}.title{align-self:start}.interests-reason{display:flex;justify-content:center;flex-direction:row}.reason-icon{width:30px;height:30px;min-width:30px;background:rgba(229,229,229,1);display:flex;align-items:center;justify-content:center;border-radius:50%;box-sizing:border-box;margin-right:10px}.reason-text{line-height:24px}.interests-summary,.ad-feedback-description{color:rgba(118,118,118,1);line-height:24px;margin-top:0px}@media (forced-colors:active){.reason-icon,.interact-btn{filter:invert(1) !important}.reason-icon img,.interact-btn img{filter:invert(0.6) !important}}.footer-button-container{width:100%}`.withBehaviors((0,ht.U)("dark",Ui));var Wi,Gi;const Ni=tt.A` :host([hide-card-type="ad-hidden"]) .content-card-container{flex-direction:row}:host([hide-card-type="ad-hidden"]) .text{-webkit-line-clamp:2;padding-top:0px;gap:4px}@media (min-width:501px) and (max-width:${(0,Ft.c)(Q.YH-1)}){:host([hide-card-type="ad-hidden"]) .heading{-webkit-line-clamp:3;font-size:14px;line-height:20px}:host([hide-card-type="ad-hidden"]) .text{max-height:calc(100% - 20px);gap:0px}:host([hide-card-type="ad-hidden"]) .abstract{max-height:40px}}@media (min-width:${(0,Ft.c)(Q.YH)}){:host([hide-card-type="ad-hidden"]) .ruby-image-container{background-color:${st.WRM};
            border-radius: calc(${st.zkJ} * ${st.MU6})}:host([hide-card-type="ad-hidden"]) .action-row{flex-direction:row;padding-bottom:0px}}@media (min-width:${(0,Ft.c)(Q.dr)}) and (max-width: ${(0,Ft.c)(Q.YH-1)}){:host([hide-card-type="ad-hidden"]) .content-card-container{flex-direction:column;gap:16px}:host([hide-card-type="ad-hidden"]) .ruby-image-container{border-radius:calc(${st.eA}*${st.MU6}) calc(${st.eA}*${st.MU6}) calc(${st.F2F}*${st.MU6}) calc(${st.F2F}*${st.MU6})}:host([hide-card-type="ad-hidden"]) .card-actions-button-container{margin-inline-start:0px;margin-inline-end:10px}:host([hide-card-type="ad-hidden"]) .body,:host([hide-card-type="ad-hidden"]) .text{gap:2px}:host([hide-card-type="ad-hidden"]) .action-row{flex-direction:row;padding-top:0px}}@media (max-width:${(0,Ft.c)(Q.dr)}){:host([hide-card-type="ad-hidden"]) .content-card-container{flex-direction:column}}`,Ki=tt.A` :host([hide-card-type="ad-hidden"]) .ruby-image-container{background:${st.JrC}}:host([hide-card-type="ad-hidden"]) .ruby-image-container img{filter:invert(100%)}:host([hide-card-type="ad-hidden"]) .undo-button{border:${nt.KUh} solid rgba(255,255,255,0.08)}.undo-button{background:#24282F}.undo-button:hover{background:#2B2E35}.undo-button:active{background:#383B43}.undo-icon{filter:invert(100%)}.undo-text{color:#FFFFFF}`,qi=tt.A` :host{cursor:auto}:host([hide-card-type="ad-hidden"]) .root{background-color:${nt.zui}}:host([hide-card-type="ad-hidden"]) .text{height:-webkit-fill-available;padding-bottom:0px;gap:8px}:host([hide-card-type="ad-hidden"]) .heading{font-size:16px;font-weight:550;line-height:24px;flex-shrink:0}:host([hide-card-type="ad-hidden"]) .heading:after{display:none}:host([hide-card-type="ad-hidden"]) .abstract{display:-webkit-box;color:${nt.Adh};flex-grow:1;font-size:14px;font-weight:400;line-height:20px;margin-top:0px;-webkit-line-clamp:2}:host([hide-card-type="ad-hidden"]) .ruby-image-container{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;border-radius:${dt.tM};
        background: ${st.JrC}}:host([hide-card-type="ad-hidden"]) .hidden-text{color:${nt.Adh};
        font-size: ${nt.e1r};font-weight:400;line-height:20px}:host([hide-card-type="ad-hidden"]) .action-row{height:32px;flex-direction:row;padding-bottom:${nt.bJh}}:host([hide-card-type="ad-hidden"]) .hidden-icon{width:${nt.Szr};
        height: ${nt.Szr};
        background-color: ${nt.Adh};
        mask: url(${(null===(Wi=(0,k.rA)())||void 0===Wi?void 0:Wi.StaticsUrl)+"latest/fluent-icons/eye_off_36_filled.svg"}) no-repeat center / contain}@media (forced-colors:active){:host([hide-card-type="ad-hidden"]) .hidden-icon{filter:invert(1)}}:host([hide-card-type="ad-hidden"]) .heading{font-size:${nt.N0T};
        line-height: ${nt.Q7d}}:host([hide-card-type="ad-hidden"]) .undo-button{height:${nt.Szr};
        line-height: ${nt.Szr};
        border-radius: ${nt.FR4};
        border: ${nt.KUh} solid rgba(0,0,0,0.08);background:transparent}:host([hide-card-type="ad-hidden"]) .undo-button::part(content){display:flex;align-items:center;gap:${nt.jiC}}:host([hide-card-type="ad-hidden"]) .undo-icon{display:inline-block;width:${nt.C6};
        height: ${nt.C6};
        background-color: ${nt.kPv};
        mask: url(${(null===(Gi=(0,k.rA)())||void 0===Gi?void 0:Gi.StaticsUrl)+"latest/fluent-icons/arrow_hook_down_left_16_regular.svg"}) no-repeat center / contain;filter:none;margin-inline-end:unset}:host([hide-card-type="ad-hidden"]) .undo-text{font-size:${nt.N0T};
        font-weight: ${st.IH6};
        line-height: ${nt.Szr};
        color:${nt.C6c}}.undo-button{width:fit-content;height:28px;line-height:28px;border-radius:10px;border:1px solid #C8CCD3;box-sizing:content-box;background:#FFFFFF}.undo-button::part(control){height:100%;padding:0px 8px}.undo-button:hover{border:2px solid #BFC4CA}.undo-button:active{border:2px solid #AFB4BA}.undo-icon{width:20px;height:20px;margin-inline-end:6px}.undo-text{font-size:12px;font-weight:400;line-height:16px}`.withBehaviors((0,ht.U)("dark",Ki),new it.o("intraArticle",!0,Ni));var Xi=e(86856);const Ji=tt.A`
:host([size="0.5u"][hide-card-type="feedback"]) #undo-button{right:0}`,Yi=tt.A`
:host([size="0.5u"][hide-card-type="feedback"]) #undo-button{left:0}`,Qi=tt.A`:host{cursor:auto}.body{justify-content:center;gap:32px}.hide-button,.hide-menu{list-style-type:none}.hide-button{border-radius:${ut.uk};
    border: 0;
    cursor: pointer;
    font-family: ${wt.O};
    font-size: ${yt.Kg};
    height: 32px;
    line-height: ${yt.Z6};overflow:hidden;padding:0 8px;text-overflow:ellipsis;white-space:nowrap;width:100%}:host([size="0.5u"][hide-card-type="spinner"]) #undo-button,.hide-button{background-color:var(--color-neutral-stroke-3);color:var(--color-neutral-foreground-1);}.hide-button:focus{border:${ut.vd} solid var(--color-neutral-stroke-1-pressed)}:host([size="0.5u"][hide-card-type="spinner"]) #undo-button:hover,.hide-button:hover{background-color:var(--color-neutral-stroke-hover)}#undo-button{background-color:transparent;color:var(--color-neutral-stroke-accessible)}#undo-button:hover{background-color:var(--color-neutral-background-1-hover)}.hide-list-item{width:88%}.hide-message{font-family:${wt.O};
    font-size: ${yt.YV};
    line-height: ${yt.vr};overflow:hidden;text-align:center;user-select:none;width:100%;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,2)}.hide-menu{align-items:center;display:flex;flex-direction:column;gap:8px;justify-content:center;margin:0;padding:0;width:100%}::slotted([slot="actions"]){margin:0 auto}.undo-button-glyph{display:none}:host([size="0.5u"]) .body{gap:0px}:host([size="0.5u"]) .hide-button{font-size:${yt.kS};
    height: 24px;
    line-height: ${yt.Fr}}:host([size="0.5u"]) #hide-item-3{display:none}:host([size="0.5u"][hide-card-type="feedback"]) #undo-button{background-color:transparent;border:${ut.vd} solid transparent;
    border-radius: ${ut.uk};cursor:pointer;display:initial;height:18px;margin-inline-end:10px;margin-top:11px;padding:0;position:absolute;top:0px;width:18px}:host([size="0.5u"][hide-card-type="feedback"]) #undo-button:focus{border:${ut.vd} solid var(--color-neutral-stroke-accessible)}:host([size="0.5u"][hide-card-type="feedback"]) #undo-button:hover{background-color:var(--color-neutral-stroke-3)}:host([size="0.5u"]) .hide-message{font-size:${yt.Kg};
    line-height: ${yt.Z6};margin:auto;width:236px}.undo-icon{display:block;height:14px;width:14px}:host([wide]) .body{margin:auto;width:262px}`.withBehaviors((0,ht.U)("dark",tt.A` .undo-icon{filter:invert(1)}`),new Xi.t(Ji,Yi)),Zi=tt.A`
${Qi}:host(:not([size="0.5u"])[hide-card-type="spinner"]) .body{gap:20px}:host([hide-card-type="spinner"]) #hide-item-2,:host([hide-card-type="spinner"]) #hide-item-3{display:none}:host([size="0.5u"][hide-card-type="spinner"]) .hide-button{width:130px}:host([size="0.5u"][hide-card-type="spinner"]) .hide-menu{flex-direction:row}`;var te,ie=e(56771);const ee=tt.A`
:host{--video-border-radius:${st.MCQ};--video-player-object-fit:cover}.video-js.vjs-msn .vjs-control{transition:opacity .4 ease}.video-js.vjs-msn.vjs-user-inactive:not(.vjs-ended):not(:hover) .vjs-control,.video-js.vjs-msn:not(.vjs-has-started) .vjs-control{opacity:0}.video-js.vjs-msn .vjs-big-play-button{display:none}.video-js.vjs-msn .vjs-control-bar{background:none}.video-js .vjs-progress-control{display:none}.video-js .vjs-play-control{position:absolute;bottom:60px;right:32px;top:unset}.video-js .vjs-volume-panel.vjs-volume-panel-vertical{bottom:28px;right:30px;top:unset}.video-js.opaque-control.control-spacing.custom-background .vjs-volume-control{margin-top:5px;top:unset;z-index:300}.video-js .vjs-text-track-display .vjs-text-track-cue{font-size:14px !important;line-height:28px !important}`,oe=tt.A`
:host([size="shorts"]:hover) .video-container:has(video-card),:host([size="shorts"]) .video-container[is-playing="true"]:has(video-card){z-index:1}video-card{width:100%}`,ae=tt.A`
:host([immersive][ruby]:not([size="2c"])){--card-height:418px;width:235px}:host([immersive][ruby]:not([size="2c"])) .heading{line-height:${kt.uG};
    font-size: ${kt.vJ};
    font-weight: ${kt.Fu}}:host([immersive][ruby][size="2c"]) .media-overlay{height:calc(var(--card-height))}`,ne=`${null===(te=(0,k.rA)())||void 0===te?void 0:te.StaticsUrlWithBuild}icons/VideoPlayIndicator_24_White.svg`,re=tt.A` :host([immersive]) .heading{font-size:${nt.Aps};
        font-weight: ${st.V6n};
        line-height: ${nt.LfE}}:host([immersive]) .body{padding-block:calc(${nt.ACF} + ${nt.YUh});
        padding-inline-start: calc(${nt.ACF} + ${nt.YUh});
        padding-inline-end: calc(${st.Gkw} + ${nt.YUh});background:linear-gradient(180deg,rgba(0,0,0,0.00) 0%,rgba(0,0,0,0.00) 20%,rgba(0,0,0,0.60) 80%,rgba(0,0,0,0.60) 100%)}:host([immersive]) .attribution{max-width:calc(var(--card-width) - (${nt.ACF} + ${nt.YUh}) * 2);
    }
`,se=tt.A`
.icon-invert-color{height:24px;width:24px}.play-indicator{min-width:36px;padding:6px;position:absolute;box-sizing:border-box;display:flex;align-items:center;justify-content:center;width:${nt.xo8};
    height: ${nt.xo8};
    border-radius: ${nt.g6L};
    border: 1px solid ${st.thz};
    background: 
        linear-gradient(0deg, ${st.iG5} 0%, ${st.iG5} 100%), 
        linear-gradient(0deg, ${st.PWf} 0%, ${st.PWf} 100%), 
        ${st.rFv};background-blend-mode:normal,luminosity,saturation}.video-indicator-icon{display:block;width:24px;height:24px;background-color:${st.b0J};
    mask: url(${ne}) no-repeat center;
    -webkit-mask: url(${ne}) no-repeat center}:host([grouped-item]) .media-overlay,:host([grouped-item]) .video-container{aspect-ratio:16 / 9;width:100%;height:100%}:host([auto-sized][responsive-width]) .media-info-container{justify-content:flex-end}@media (forced-colors:active){.play-indicator{background:highlight}}`.withBehaviors(new it.o("immersive",!0,ae),new it.o("size",ie.Go._shorts,re)),de=tt.A`
:host([immersive][wide]) .media-overlay{height:308px}:host([immersive]) .media-overlay{height:256px;top:0}:host([size="0.5u"]) .video-container{width:104px;height:84px}`,le=tt.A`
:host([size="0.5u"]) .play-indicator{background:none}.play-indicator{align-items:center;background:linear-gradient(135deg,rgba(0,0,0,0.5) 0%,rgba(0,0,0,0.7) 100%) padding-box padding-box,linear-gradient(rgba(255,255,255,0.4) 0%,rgba(255,255,255,0.2) 100%) border-box border-box;border-radius:20px;border:1px solid transparent;box-sizing:border-box;color:rgb(255,255,255);display:flex;height:40px;justify-content:center;min-width:40px;opacity:1;position:absolute;transition:opacity 0.4s ease}@media (forced-colors:active){.play-indicator{background:highlight}}.play-indicator svg path{fill:currentColor}.video-container:has(video[is-playing]) .play-indicator{opacity:0;transition-duration:1s}.video-container:has(video[display-cta]) .play-indicator{display:none}`,he=tt.A`
:host([carousel-only]) .heading{font-size:${yt.Kg};
    font-weight: 600;
    line-height: ${yt.Z6};margin-bottom:12px}:host([carousel-only]) .attribution{height:16px;margin-bottom:2px}:host([carousel-only]) .play-indicator{height:44px;width:44px;min-height:44px;min-width:44px;box-sizing:border-box;position:absolute;top:45px;border-radius:50%}:host([carousel-only]) .media-info-container{position:absolute;top:8px;left:8px}:host([carousel-only]) .media-info-container .media-info{font-size:${yt.tD};background:rgba(44,44,44,0.8)}:host([size="1u"][immersive][carousel-only]) .media{aspect-ratio:256 / 164}`,ce=tt.A`:host([immersive]) .video-container{height:100%}:host([immersive]) .media-overlay{height:175%}`,ue=tt.A`
:host(:hover:not([size="2c"])) .media-info{opacity:1}:host([immersive]) .media-info-container{margin-bottom:-5px;padding:0}.media-info{align-items:center;background:rgba(0,0,0,0.54);border-radius:4px;color:white;display:flex;font-size:${yt.tD};font-weight:600;gap:3px;opacity:0;padding:4px 6px;transition:opacity 0.4s ease;z-index:1}.media-info svg{fill:currentColor}.media-info-container{align-self:flex-end;display:flex;gap:4px;padding:2px 10px;width:100%}`,pe=tt.A`
:host([size="shorts"]) .media-overlay{height:100%;padding:0;top:0}:host([size="shorts"]) .video-inline-consumption-link{background:transparent;height:100%;width:100%;display:block}`,ge=tt.A`
:host([size="shorts"]) .root{min-width:0}:host([size="shorts"]) .play-indicator{display:none}:host([size="shorts"]) .video-container video{position:unset}:host([size="shorts"]) .video-container video[is-portrait]{object-fit:cover}:host([size="shorts"]:hover) .body{opacity:0;transition:opacity 0.3s ease}@media ( prefers-reduced-motion:reduce ){:host([size="shorts"]:hover) .body{transition:opacity 1.5s ease}}${oe}
`.withBehaviors(new it.o("enableShortsInlineConsumption",!0,pe)),be=tt.A`
:host([immersive]) .media-overlay{height:calc(var(--card-height) - 64px);top:0}:host([size="0.5u"]) .video-container{height:90px;width:90px}:host([size="2c"]) .video-container ::-webkit-media-text-track-display{transform:translateY(-112px)}:host([size="2c"]) .video-container video::cue{line-height:1.5}.end-slate-container{cursor:pointer;display:none;left:50%;position:absolute;top:50%;transform:translate(-50%,-50%);z-index:1}.end-slate-info{align-items:center;background-color:rgba(0,0,0,0.55);border-radius:50em;border:1px solid white;color:#FFF;display:flex;justify-content:space-between;margin:5px 0;padding:8px 16px;width:125px}.media-overlay{align-items:center;box-sizing:border-box;display:flex;height:100%;justify-content:center;padding:6px;position:absolute;width:100%}.video-container{align-items:center;display:flex;justify-content:center;position:relative;width:100%}.video-container video{background:black;object-fit:cover}:host .video-container video[is-portrait]{object-fit:contain}.video-container:has(video[display-cta]) .end-slate-container{display:block}${le}
${ue}
`.withBehaviors(new it.o("carouselOnly",!0,he),new it.o("ruby",!0,se),new it.o("msn",!0,de),new it.o("responsiveWidth",!0,ce),new it.o("size","shorts",ge)),ve=`${(0,k.rA)().StaticsUrl}latest/fluent-icons/arrow_trending_16_filled.svg`,xe=tt.A` #heading{font-weight:500}`,me=tt.A` #heading{font-weight:500}`,fe=tt.A` #heading{font-weight:${st.i2t};
    }
`,we=tt.A`
:host{--neutral-fill-stealth-hover:#f2f2f2;--neutral-fill-layer-rest:#f2f2f2}`,ye=tt.A`
:host([immersive]) .heading{font-size:${zt.F};
    line-height: ${zt.w};-webkit-line-clamp:2}:host([immersive][size="1u"]) .heading{font-size:${yt.TF};
    line-height: ${yt.Oc};
    -webkit-line-clamp: 2;
}
`,$e=tt.A`
:host{--neutral-fill-layer-rest:#404040;--neutral-fill-stealth-hover:#404040}:host([ruby]){--color-card-background:var(--kumo-color-card-background-override,${$t.dT})}:host([ruby][immersive]){outline-color:${$t.OF}}.badge-icon,.ai-disclaimer-icon{filter:invert(1)}:host([companion][size="1u"]) .hover-companion-button{background-color:#292929;color:#FFF}:host([companion][size="1u"]) .hover-companion-button:hover{background-color:#3D3D3D}:host([companion][size="1u"]:not([ruby])) .hover-companion-button{border:1px solid #666666}:host([companion][size="1u"]:not([ruby])) .hover-companion-button:hover{border:1px solid #757575}:host([companion][size="1u"]) .copilot-icon{filter:invert(1)}:host([ruby]) .hover-companion-button-text{color:#FFF}:host([watchAdVideo]) .attribution{color:#aeaeae}`,ke=tt.A`
:host([size="1u"][fontTrackingStyle="v1"]) .body > .text > a{letter-spacing:1.6px}`,Ae=tt.A`
:host([size="1u"][fontTrackingStyle="v2"]) .body > .text > a{letter-spacing:2.6px}`,ze=tt.A`
:host([size="1u"][fontWeightStyle="normal"]) .body > .text > a{font-weight:normal}`,Ce=tt.A`
.heading{font-size:22px;line-height:28px}`,Fe=tt.A`
.heading:hover{color:#707070}:host([immersive]) .heading:hover{color:#EBEBEB}:host(:hover) .media{filter:none}@media(prefers-color-scheme:dark){.heading:hover{color:#999999}}`,_e=tt.A`
:host([size="1u"]:hover),:host([size="_2x_2y"]:hover){box-shadow:0 8px 16px 0 rgba(0,0,0,0.14),0 0 2px rgba(0,0,0,0.12)}:host([size="1u"]:hover:not([vp-test])),:host([size="_2x_2y"]:hover:not([vp-test])){transition:transform 0.2s ease-in-out,box-shadow 0.2s ease-in-out,background 0.2s ease-in-out}`,Te=tt.A`
:host([size="1u"]:hover:not([dialog-showing])){transform:var(--infopane-child-transform-override,scale(1.05))}:host([size="_2x_2y"]:hover:not([dialog-showing])){transform:var(--infopane-child-transform-override,scale(1.02))}`,Ie=tt.A`
:host(:hover){background-color:#F0F0F0}:host([immersive]:hover){background:linear-gradient(180deg,rgba(0,0,0,0.00) 33%,rgba(0,0,0,0.54) 66%)}@media(prefers-color-scheme:dark){:host(:hover){background-color:#1F1F1F}}`,Be=tt.A`
:host([immersive][gradientClass="light-gradient-v1"]) .body{background:linear-gradient(rgba(0,0,0,0) 27%,rgba(30,30,30,0.34) 48%,rgba(0,0,0,0.49) 54%,rgba(0,0,0,0.75) 85.5%,rgba(0,0,0,0.75) 100%)}`,Se=tt.A`
:host([immersive][gradientClass="light-gradient-v2"]) .body{background:linear-gradient(rgba(0,0,0,0) 27%,rgba(30,30,30,0.34) 48%,rgba(0,0,0,0.44) 54%,rgba(0,0,0,0.54) 85.5%,rgba(0,0,0,0.54) 100%)}`,je=tt.A`
:host([immersive][gradientClass="light-gradient-v3"]) .body{background:linear-gradient(rgba(0,0,0,0) 33%,rgba(0,0,0,0.27) 66%)}`,De=tt.A`
:host([immersive][gradientClass="light-gradient-v4"]) .body{background:linear-gradient(rgba(0,0,0,0) 33%,rgba(0,0,0,0.27) 66%)}:host([immersive][gradientClass="light-gradient-v4"]) .text{text-shadow:0 0 5px black}`,Ve=tt.A`
.attribution{color:${bt.A.ButtonText};
    fill: currentcolor;
}
`,Re=tt.A`
:host(:not([size="_2x_2y"])) .video-container,.image-container{width:100%;overflow:clip;display:flex}:host([size="0.5u"]) .video-container,:host([size="0.5u"]) .image-container{width:fit-content;border-radius:var(--borderRadiusLarge,${ut.U9});
}
`,Ee=tt.A`
${Re} :host(:hover) .media{transform:scale(1.05);transition:transform 0.5s ease 0s}`,Pe=tt.A`
${Re} :host(:hover) .media{transform:scale(1.1);transition:transform 0.5s ease 0s}`,Le=tt.A`
:host([immersive]){--ruby-card-gradient:linear-gradient( to bottom,hsla(0,0%,0%,0) 0%,hsla(0,0%,0%,0.037) 16.6%,hsla(0,0%,0%,0.08) 30%,hsla(0,0%,0%,0.126) 40.4%,hsla(0,0%,0%,0.175) 48.5%,hsla(0,0%,0%,0.227) 54.6%,hsla(0,0%,0%,0.282) 59.1%,hsla(0,0%,0%,0.338) 62.5%,hsla(0,0%,0%,0.394) 65.1%,hsla(0,0%,0%,0.451) 67.5%,hsla(0,0%,0%,0.507) 70.1%,hsla(0,0%,0%,0.562) 73.2%,hsla(0,0%,0%,0.616) 77.3%,hsla(0,0%,0%,0.667) 82.9%,hsla(0,0%,0%,0.715) 90.3%,hsla(0,0%,0%,0.76) 100% );padding:${kt.lu};border:none;box-sizing:border-box}:host([immersive]) .root{padding:${kt.lu};border:unset}:host([immersive]) .ruby-image-container,:host([immersive]) .image-container,:host([immersive]) .video-container{height:100%;width:100%;overflow:hidden;position:absolute;z-index:${jt.P.Below.toString()};
    border-radius: calc(${st.MCQ} * ${st.MU6})}:host([immersive]) .media{z-index:${jt.P.Below.toString()}}:host([immersive]) .body{padding:${kt.mU};
    justify-content: end;
    border-radius: calc(${st.MCQ} * ${st.MU6});corner-shape:squircle;background:var(--ruby-card-gradient)}:host([immersive]) .text{padding:${nt.F64};
    gap: ${nt.fFM}}:host([immersive]) .attribution{font-size:${kt.ap};
    font-weight: ${kt.U7};
    margin-bottom: 6px;
    padding: ${nt.UL_} ${nt.fMx};margin-block-end:0px;height:auto}:host([immersive]) .attribution-image{border-radius:${st.cbN};
    height: ${st.p1U};
    width: ${st.p1U}}:host([immersive]) .heading{overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:2;font-size:${kt.gX};
    font-weight: ${kt.Fu};
    line-height: ${kt.jJ}}:host([size="2c"][immersive]) .body{padding:calc(${nt.YUh} + ${nt.ACF})
        calc(${nt.YUh} + ${nt.YUh})}:host([size="2c"][immersive]) .heading{font-size:${nt.YXL};
    line-height: ${nt.bfN};
}
`,Me=tt.A`
.copilot-badge{--badge-margin:20px;display:flex;align-items:center;border-radius:${nt.aJo};
    gap: 4px;
    position: absolute;
    z-index: ${jt.P.Above.toString()};
    height: ${kt.w_};
    text-decoration: none;
    inset-inline-start: calc(${st.$rH} + var(--badge-margin));
    inset-block-start: calc(${st.$rH} + var(--badge-margin));
    background: ${st.RfR};
    padding: 0 calc(${nt.w97} + 4px)}.badge-text{color:${st.kLb};
    font-size: ${nt.Lgj};
    line-height: ${nt.kyM};
    text-overflow: ellipsis;
    max-width: 180px;
    overflow: hidden;
    white-space: nowrap;
}`,Ue=tt.A` .attribution{max-width:236px}`,He=tt.A`
${Me}
:host{--color-card-background:var(--kumo-color-card-background-override,${kt.pp});
    border: unset;
    border-radius: unset;
    box-shadow: none;
    outline: none;
    --companion-heading-height: 84px;
    --companion-rest-card-height: 136.13px;
    --companion-hover-card-height: 108.33px;
    color: ${nt.C6c}}:host(:hover){border:unset;border-radius:unset;outline:none;box-shadow:none;color:${nt.C6c}}:host(:hover:not([grouped-item])) .media{filter:none;transform:scale(1.10)}:host(:not([media-type])){--heading-lines:4;--abstract-lines:4}:host(:not([media-type])) .text{padding:0}:host(:not([media-type])) .content-card-container{padding:${nt.YUh};box-sizing:border-box}:host([size="0.5u"]) .text{padding:${nt.hW$} ${nt.hW$} ${nt.LbM} ${nt.hW$}}:host([size="0.5u"][media-type][ruby]) .media{height:84px;margin-bottom:4px;width:84px}:host([size="0.5u"][media-type][ruby]) .ruby-image-container,:host([size="0.5u"][media-type][ruby]) .video-container{display:none}:host([size="1.5u"][media-type][ruby]) .ruby-image-container,:host([size="1.5u"][media-type][ruby]) .video-container{aspect-ratio:13 / 9}.root{background:${nt.lHC}}:host:has(.heading:focus-visible) .root{border-color:${nt.X2Y}}.abstract{font-size:${kt.vJ};
    line-height: ${kt.uG};
    margin-block: ${nt.LbM} ${nt.WCE}}.attribution{font-size:${kt.ap};
    line-height: ${kt.XA};
    height: auto;
    max-width: 272px;
    margin-block-end: ${nt.fFM}}.attribution-image{border-radius:${st.cbN}}.body{gap:auto;min-height:0;padding:0;justify-content:flex-start}.content-card-container{border-radius:12px}.heading{font-size:${kt.gX};
    font-weight: ${kt.Fu};
    line-height: ${kt.jJ};overflow-wrap:anywhere;word-break:break-word}.heading:focus-visible::after{outline:none}.media{aspect-ratio:inherit;border-radius:0;height:inherit;transition:transform 0.4s ease;width:inherit}.ruby-image-container,.video-container{aspect-ratio:1.8135 / 1;min-height:fit-content;width:100%;overflow:hidden;flex-shrink:0}:host([size="2c"][media-type][ruby]:not([segment])) .ruby-image-container,:host([size="2c"][media-type][ruby]:not([segment])) .video-container{aspect-ratio:2.2 / 1}.card-actions-button-container{gap:6px}.text{color:var(--smtc-foreground-ctrl-neutral-primary-rest-override,${kt.El});
    padding: ${nt.hW$} ${nt.bJh} ${nt.bJh} ${nt.bJh};box-sizing:border-box}.body:has(.action-row) .text{padding-block-end:${nt.LFA}}.action-row{padding:0 ${nt.bJh}}:host([grouped-item]) .text{padding:0px;gap:4px}:host([grouped-item]) .heading{-webkit-line-clamp:2}:host([grouped-item]) .content-card-container{gap:8px}:host([grouped-item]) .attribution{height:24px;margin:0px}:host([grouped-item]) .card-actions-button-container{top:8px}`.withBehaviors(new it.o("immersive",!0,Le),new it.o("isProngCopilotOverride",!0,Ue),new it.o("enableSpecialFWInCJK",!0,xe),new it.o("specialCJKYaheiFont",!0,fe),new it.o("specialCJKNtsFont",!0,me)),Oe=tt.A`
:host([size="0.5u"]) .heading{-webkit-line-clamp:2}:host([size="0.5u"][media-type]) .media{height:84px;width:104px}:host([immersive]:not([wide])) .heading{font-size:20px;line-height:28px}:host([size="0.5u"]) .action-row{width:170px}:host([immersive]) .heading{font-size:28px;line-height:36px}:host([immersive][wide]:hover) .heading{text-decoration:underline}:host([immersive][responsive-height]) .media{aspect-ratio:unset}.heading{font-size:14px;line-height:20px}`,We=tt.A`
:host([responsive-width][immersive]:not([auto-sized])) {
    height: 100%;
    width: 100%;
}
:host([responsive-width]:not([auto-sized])) {
    --card-height: auto;
    container-type: inline-size;
    min-height: min-content;
}
:host([responsive-width]:not([show-badge])) .badge {
    display: none;
}
:host([responsive-width]:not([show-badge])) ::slotted([slot="action-row-start"]) {
    width: -webkit-fill-available;
}
@container (width < 300px) {
    :host([size="1u"]:not([ad-va2])) .heading {
        font-size: 18px;
        line-height: 24px;
        -webkit-line-clamp: 2
    }
}
/** wide responsive width styles **/
@container (width < 612px) {
    :host([wide]) .heading {
        font-size: ${yt.TF};
        line-height: ${yt.Oc};
    }
}
`,Ge=tt.A`
.abstract{margin-top:8px}.attribution{height:20px;margin-bottom:4px}.body{gap:auto;padding:0}.content-card-container{gap:${ot.fI}}.heading{font-size:${yt.TF};
    line-height: ${yt.Oc}}.media{border-radius:${ut.U9}}.text{padding-top:0}`,Ne=tt.A`
:host([size="0.5u"][useWindowsShellCardStyle="true"]) .root{padding:16px 16px 12px 16px}:host([size="0.5u"][useWindowsShellCardStyle="true"][media-type]) .media{height:82px;width:82px}:host([size="0.5u"][useWindowsShellCardStyle="true"]) .heading{font-size:16px;line-height:22px}:host([size="1u"][useWindowsShellCardStyle="true"]) .heading{font-size:18px;line-height:24px}`,Ke=tt.A` :host([size="1u"]) .attribution{display:none}:host([size="1u"]) .body{height:unset}:host([size="1u"]) .heading{-webkit-line-clamp:1}:host([size="1u"]) .ruby-image-container{aspect-ratio:310 / 280}:host([size="0.5u"][ruby]) .heading{-webkit-line-clamp:4}`,qe=tt.A` :host([ruby][intraArticle]){display:flex}@media (min-width:${(0,Ft.c)(Q.YH)}){:host([ruby][intraArticle]) .ruby-image-container{max-width:259px}}:host([ruby][intraArticle]) .media{max-width:100%}@media (min-width:390px) and (max-width:${(0,Ft.c)(Q.YH-1)}){:host([ruby][intraArticle]),:host([ruby][intraArticle]) .root{--card-height:${ot.Qk};
            max-width: ${ot.P1}}:host([ruby][intraArticle]) .ruby-image-container{max-width:100%;width:100%;height:auto}}@media (max-width:389px){:host([ruby][intraArticle]),:host([ruby][intraArticle]) .root{--card-height:100%;max-width:100%}}`,Xe=tt.A` :host([intraArticle]){--responsive-card-background-override:${nt.r2I}}:host([intraArticle]) .root{background:unset}:host([intraArticle]) .action-row .ad-choice{padding:${st.UYK}}:host([size="_2x_2y"][intraArticle]){grid-column:1 / 3 !important}:host([size="_3x_2y"][intraArticle]){grid-column:1 / 4 !important}:host([size="_4x_2y"][intraArticle]){grid-column:1 / -1 !important}@media (min-width:${(0,Ft.c)(Q.YH)}){:host([intraArticle][ruby]) .root{padding:calc(${st.$rH} - ${dt.q_});height:inherit}:host([intraArticle]) .root{border-radius:calc(${st.tF1} * ${st.MU6})}:host([intraArticle]) .ruby-image-container{width:259px;height:136px;aspect-ratio:1.91 / 1;border-radius:${st.zkJ}}:host([intraArticle]) .heading{font-size:${nt.N0T};
            line-height: ${nt.Q7d}}:host([intraArticle]) .body{height:100%;box-sizing:border-box;justify-content:space-between;padding:${st.Gkw};padding-inline-start:0px}:host([intraArticle]) .text{padding:0px}:host([intraArticle]:not([hide-card-type="ad-hidden"])) .text{padding-inline-end:calc(${nt.Szr} + ${st.Gkw})}:host([intraArticle]) .action-row{padding:0px;flex-direction:row-reverse}:host([intraArticle]:not([hide-card-type="ad-hidden"])) .action-row{padding-inline-end:${st.Gkw}}:host([intraArticle]) .card-actions-button-container[ruby]{inset-inline-end:${nt.ZA2};
        }
    }

    @media (min-width: 390px) and (max-width: ${(0,Ft.c)(Q.YH-1)}){:host([intraArticle]:not([isIntraClassicAd])),:host([intraArticle]:not([isIntraClassicAd])) .root{max-width:336px;margin:0 auto}:host([intraArticle]) .ruby-image-container{width:312px;height:172px;aspect-ratio:1.81 / 1}:host([intraArticle]) .heading{-webkit-line-clamp:2}:host([intraArticle]) .action-row{padding-bottom:${nt.ACF};flex-direction:row-reverse}:host([intraArticle]) .action-row:has(.call-to-action){padding-bottom:${nt.ACF};flex-direction:row}:host([intraArticle]) .card-actions-button-container[ruby]{margin-inline-end:${nt.YUh};
            inset-block-start: calc(${nt.ACF} + ${nt.YUh});
        }
    }
`.withBehaviors(new it.o("isAdaptiveThemeEnabled",!0,qe)),Je=tt.A`
.heading{-webkit-line-clamp:2}@media (min-width:501px) and (max-width:620px){.heading{-webkit-line-clamp:3}}:host([ruby][intra-article-classic]) .root{border-radius:20px;padding:20px;border:none;corner-shape:unset;width:100%;height:100%}:host([ruby][intra-article-classic]) .ruby-image-container,.video-container{border-radius:0px;corner-shape:unset;aspect-ratio:auto}:host([ruby][intra-article-classic]) .body{height:100%;justify-content:space-between}:host([ruby][intra-article-classic]) .text{padding:12px 0px}:host([ruby][intra-article-classic]) .attribution{height:16px;max-width:280px}:host([ruby][intra-article-classic]) .ad-label{font-size:12px;font-weight:normal;line-height:unset;color:inherit}:host([ruby][intra-article-classic]) .action-row{padding-inline:0px}`,Ye=tt.A` .body{flex:1;overflow:hidden;text-overflow:ellipsis}.content-card-container{display:flex;flex-direction:row;gap:20px}.ruby-image-container,.video-container{height:120px;width:228px}.text{padding-top:12px}@media (min-width:${(0,Ft.c)(Q.YH)}){.card-actions-button-container[ruby]{margin-inline-start:4px;margin-inline-end:0px;top:24px}}@media (min-width:390px) and (max-width:${(0,Ft.c)(Q.YH-1)}){:host(:not([isIntraClassicAd])) .content-card-container{flex-direction:column}.ruby-image-container,.video-container{width:100%;height:unset;aspect-ratio:1.81 / 1}.heading{-webkit-line-clamp:2;line-height:${kt.jJ};
           font-size: ${kt.gX}}.text{padding-top:0px}}@media (max-width:390px){.content-card-container{flex-direction:column;gap:${nt.hW$};width:100%}.ruby-image-container,.video-container{aspect-ratio:1.81 / 1;height:100%;width:100%}:host([ruby][intraArticle]) .root{--card-height:100%}:host([ruby][intraArticle]) .body{padding:0 ${st.Gkw};
            justify-content: start;
            align-items: flex-start;
            gap: ${nt.fFM}}.text{padding:0px;gap:${nt.fFM}}:host([ruby][intraArticle]) .action-row{padding:0 0 ${nt.ACF} 0;
            flex-direction: row;
        }
    }
`.withBehaviors(new it.o("intraArticleClassic",!0,Je),new it.o("intraArticleClassic",!1,Xe)),Qe=tt.A` :host([intraArticle][isIntraFeedAd][intraFeedAdWeather]) .ad-choice{align-items:flex-end;padding:0}:host([intraArticle][isIntraFeedAd][intraFeedAdWeather]) .action-row-sub-container{height:100%}:host([intraArticle][isIntraFeedAd][intraFeedAdWeather]) .action-row{padding-inline-end:0}`,Ze=tt.A` :host([intraArticle][isIntraFeedAd]){--responsive-card-background-override:unset}:host([intraArticle][isIntraFeedAd]) .action-row{height:auto}:host([intraArticle][isIntraFeedAd]) .intra-feed-ad-cta{border-radius:${nt.lb8};
        height: 38px;
        z-index: 1;
        background: transparent;
        border: 1px solid ${st.Eaj};
        font: inherit;
        font-size: ${nt.vtK};
        line-height: ${nt.EXe};
        color: ${st.IMk};
        padding-inline: ${nt._gs};
        cursor: pointer;
    }

    /* 3,4-column layout */
    @media (min-width: ${(0,Ft.c)(Q.fh)}){:host([intraArticle][isIntraFeedAd]) .ruby-image-container,:host([intraArticle][isIntraFeedAd]) .video-container{width:400px;max-width:400px;height:209px}:host([intraArticle][isIntraFeedAd]) .heading{font-size:${st.UuT};
            line-height: ${st.d9c};
        }
    }

    /* 2+ column layout */
    @media (min-width: ${(0,Ft.c)(Q.YH)}){:host([intraArticle][isIntraFeedAd]) .body{padding-block:${nt.YUh};
            padding-inline-end: ${nt.YUh};
            padding-inline-start: ${nt.F64}}:host([intraArticle][isIntraFeedAd]) .content-card-container{gap:24px}:host([intraArticle][isIntraFeedAd]) .root{width:100%;height:100%}}@media (min-width:${(0,Ft.c)(Q.YH)}) and (max-width: ${(0,Ft.c)(Q.fh-1)}){:host([intraArticle][isIntraFeedAd]) .ruby-image-container,:host([intraArticle][isIntraFeedAd]) .video-container{aspect-ratio:348 / 182;height:100%;max-width:348px;min-width:288px;max-height:182px;min-height:151px;width:unset}}@media (min-width:${(0,Ft.c)(736)}) and (max-width: ${(0,Ft.c)(Q.fh-1)}){:host([intraArticle][isIntraFeedAd]) .heading{-webkit-line-clamp:2;font-size:${st.dGc};
            line-height: ${st.szg};
        }
    }

    /* smaller half of 2-column layout */
    @media (min-width: ${(0,Ft.c)(Q.YH)}) and (max-width: ${(0,Ft.c)(735)}){:host([intraArticle][isIntraFeedAd]) .heading{-webkit-line-clamp:2;font-size:${st.c5V};
            line-height: ${st.pai};
        }
    }

    /* Hide CTA on small screens */
    @media (max-width: ${(0,Ft.c)(735)}){:host([intraArticle][isIntraFeedAd]) .intra-feed-ad-cta{display:none}}`,to=tt.A` :host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .root{border-radius:8px;padding:0px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .body{align-items:flex-start;gap:24px;padding:20px 0px;padding-inline-end:20px;flex-direction:row}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .text{gap:6px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .heading{font-size:18px;font-style:normal;font-weight:600;line-height:24px;--heading-lines:2}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .card-actions-button-container{inset-inline-end:16px;top:16px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .abstract{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;flex:1 0 0;overflow:hidden;text-overflow:ellipsis;font-size:14px;font-style:normal;font-weight:400;line-height:20px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .attribution-text,:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .ad-label{font-size:12px;font-style:normal;font-weight:700;line-height:16px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .attribution-text{font-weight:400}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .intra-feed-ad-cta{font-size:14px;font-style:normal;font-weight:600;line-height:20px;display:flex;padding:6px 12px;justify-content:center;align-items:center;gap:6px;border-radius:4px;border:1px solid var(--colorNeutralStroke1,var(--color-neutral-stroke-1));width:max-content}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]) .action-row{align-items:self-end}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_4x_2y"]) .media,:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_5x_2y"]) .media{aspect-ratio:359 / 188;height:199px;width:380px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_3x_2y"]) .body{align-items:flex-start;gap:24px;padding:20px 0px;padding-inline-end:20px;flex-direction:column}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_3x_2y"]) .media{aspect-ratio:170 / 89;height:178px;width:340px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_3x_2y"]) .intra-feed-ad-cta,:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_2x_2y"]) .intra-feed-ad-cta{font-size:12px;font-weight:400;line-height:16px;display:flex;padding:2px 8px;justify-content:center;align-items:center;height:24px;gap:4px;border-radius:4px;border:1px solid var(--colorNeutralStroke1,var(--color-neutral-stroke-1));width:max-content}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_2x_2y"]) .body{align-items:flex-start;gap:6px;padding:20px 0px;padding-inline-end:20px;flex-direction:column;height:auto}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_2x_2y"]) .media{align-items:flex-start;aspect-ratio:153 / 80;height:160px;width:306px}`,io=tt.A` :host([ai-heading]:hover) .ai-disclaimer-icon{opacity:1}.ai-disclaimer-icon{opacity:0;display:inline-flex;padding:${st.UYK};
        margin-inline-start: ${st.UYK};
        align-items: center;
        gap: 10px;
        width: 16px;
        height: 16px;
    }
`,eo=tt.A`:host([watchAdVideo]) .content-card-container{gap:0;flex-direction:column}:host([watchAdVideo]) .body{padding:16px;padding-bottom:0}:host([watchAdVideo]) .ruby-image-container,:host([ruby][intraArticle]) .ruby-image-container,:host([watchAdVideo]) .image-container,:host([watchAdVideo]) .video-container,:host([watchAdVideo]) .media{width:100%;height:auto;aspect-ratio:auto;order:0;object-fit:cover;border-radius:24px;position:relative;display:inline-block}:host([ruby][intraArticle]) .ruby-image-container{max-width:100%}:host([watchAdVideo]:hover) .media{transform:none;transition:none}:host([watchAdVideo]) .text{display:flex;flex-direction:column;gap:4px;order:1;padding:0}:host([watchAdVideo]) .attribution{display:flex;gap:0;align-items:center;order:2;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--neutral-foreground-rest)}:host([watchAdVideo]) .attribution-text,:host([watchAdVideo]) .ad-label{text-align:right;font-family:"Segoe UI",sans-serif;font-size:12px;font-style:normal;line-height:16px}:host([ruby][intra-article-classic][watchAdVideo]) .ad-label,:host([ruby][intraarticle][watchAdVideo]) .ad-label{z-index:2;position:absolute;left:16px;bottom:16px;background:rgba(255,255,255,0.85);border-radius:4px;padding:0 4px 1px 4px;align-items:center;color:#2B2B2B;font-family:"Segoe UI",sans-serif;font-size:11px;font-style:normal;font-weight:400;line-height:normal}:host([watchAdVideo]) .attribution-divider{font-size:10.792px;font-style:normal;font-weight:400;line-height:15.417px}:host([watchAdVideo]) .heading{order:3;-webkit-line-clamp:2;display:-webkit-box;-webkit-box-orient:vertical;overflow:ellipsis;color:var(--neutral-foreground-rest);font-family:"Segoe UI",sans-serif;font-size:20px;font-style:normal;font-weight:600;line-height:28px;width:calc(100% - 40px)}:host([watchAdVideo]) .abstract{display:none}:host([watchAdVideo]) .action-row{order:5;margin-top:8px;justify-content:space-between;align-items:center;width:100%;position:absolute;bottom:0;right:0}:host([ruby][watchAdVideo]) .action-row{padding-inline:0px}:host([watchAdVideo]) .action-row-start{margin-inline-start:0;flex:0 1 auto}:host([watchAdVideo]) .action-row-end{margin-inline-start:auto;flex:0 1 auto}:host([watchAdVideo]) ::slotted([slot="action-row-start"]){z-index:1}:host([watchAdVideo]) ::slotted([slot="action-row-end"]){z-index:1}:host([watchAdVideo]) .ad-choice{position:absolute;inset-inline-start:auto;inset-inline-end:21px}`,oo=tt.A`
:host([watchinarticlead]) .content-card-container{gap:0px}:host([watchinarticlead]) .body,:host([ruby][watchinarticlead]) .body{padding:0;display:flex;flex:1;align-items:center;justify-content:center;padding:0px 16px;max-width:calc(100% - 355px)}:host([watchinarticlead]) .ruby-image-container,:host([ruby][watchinarticlead]) .ruby-image-container{width:275px;height:144px;border-top-right-radius:0px;border-bottom-right-radius:0px;border-top-left-radius:12px;border-bottom-left-radius:12px}:host([watchinarticlead]:hover) .media{transform:none;transition:none}:host([watchinarticlead]) .text,:host([ruby][watchinarticlead]) .text{padding:0px}:host([watchinarticlead]) .heading{-webkit-line-clamp:2;color:#242424;font-family:"Segoe UI",sans-serif;font-size:20px;font-style:normal;font-weight:600;line-height:28px}:host([watchinarticlead]) .attribution{margin-block-start:8px;margin-block-end:0px;height:auto;max-width:100%;color:#242424;font-family:"Segoe UI",sans-serif;font-size:14px;font-style:normal;font-weight:400;line-height:20px}:host([watchinarticlead]) .attribution-text{font-weight:600}:host([watchinarticlead]) .action-row{position:absolute;bottom:0px;right:54px;inset-block-end:0px;inset-inline-end:54px}@media (max-width:${(0,Ft.c)(Q.YH-1)}){:host([watchinarticlead]) .content-card-container{flex-direction:column}:host([watchinarticlead]) .body,:host([ruby][watchinarticlead]) .body{max-width:100%;padding:12px 16px 19px 16px}:host([watchinarticlead]) .ruby-image-container,:host([ruby][watchinarticlead]) .ruby-image-container{border-top-right-radius:12px;border-bottom-right-radius:0px;border-top-left-radius:12px;border-bottom-left-radius:0px;width:100%;height:auto;aspect-ratio:1.91 / 1}:host([watchinarticlead]) .text,:host([ruby][watchinarticlead]) .text{display:flex;flex-direction:column-reverse;margin-block-end:10px}:host([watchinarticlead]) .attribution{margin-block-start:0px;margin-block-end:4px;color:#242424;font-family:"Segoe UI";font-size:12px;font-style:normal;font-weight:400;line-height:16px}:host([watchinarticlead]) .attribution .attribution-divider{display:none}:host([watchinarticlead]) .attribution .ad-label-container{display:none}:host([watchinarticlead]) .action-row{position:inherit}}@media (max-width:390px){}`.withBehaviors((0,et.G2)(tt.A` :host([watchinarticlead]) .heading{color:#fff}:host([watchinarticlead]) .attribution{color:#f0f0f0}`)),ao=tt.A`
@media (min-width:501px) and (max-width:620px){:host([intraArticleBlackCTA]) .heading{-webkit-line-clamp:3}}:host([intraArticleBlackCTA]) .content-card-container{display:flex;flex-direction:row;gap:0px}:host([intraArticleBlackCTA]) .body{display:flex;flex:1;align-items:center;justify-content:center;padding:0px 16px;max-width:calc(100% - 355px);overflow:hidden;text-overflow:ellipsis}:host([intraArticleBlackCTA]:hover) .media{transform:none;transition:none}:host([intraArticleBlackCTA]) .text{padding:0px}:host([intraArticleBlackCTA]) .heading{-webkit-line-clamp:2;color:#242424;font-size:20px;font-style:normal;font-weight:600;line-height:28px}:host([intraArticleBlackCTA]) .attribution{margin-block-start:8px;margin-block-end:0px;height:auto;max-width:100%;color:#242424;font-size:14px;font-style:normal;font-weight:400;line-height:20px}:host([intraArticleBlackCTA]) .attribution-text{font-weight:600}:host([intraArticleBlackCTA][ad-va2]) .attribution .popover-anchor{color:#242424;font-family:"Segoe UI";font-size:14px;font-style:normal;font-weight:400;line-height:20px}:host([intraArticleBlackCTA][ad-va2]) .attribution .ad-label{border:unset;padding:unset;font-size:14px;font-weight:400;line-height:20px}:host([intraArticleBlackCTA]) .action-row{position:absolute;inset-block-end:0px;inset-inline-end:54px}:host([intraArticleBlackCTA][ad-va2]) .action-row .ad-label{display:none}:host([intraArticleBlackCTA][ad-va2]) .action-row .popover-anchor{visibility:hidden;position:absolute;width:0;overflow:hidden}${(0,Z.H5)(Z.j1.c1)}{:host([intraArticleBlackCTA]) .content-card-container{flex-direction:column}:host([intraArticleBlackCTA]) .body{max-width:100%;padding:16px 16px 10px;align-items:flex-start;justify-content:space-between}:host([intraArticleBlackCTA]) .text{display:flex;flex-direction:column-reverse}:host([intraArticleBlackCTA]) .attribution{margin-block-start:0px;margin-block-end:4px;color:#242424;font-size:12px;font-style:normal;font-weight:400;line-height:16px}:host([intraArticleBlackCTA]) .attribution .attribution-divider{display:none}:host([intraArticleBlackCTA]) .attribution .ad-label-container{display:none}:host([intraArticleBlackCTA][ad-va2]) .attribution .popover-anchor{display:none}:host([intraArticleBlackCTA]) .action-row{position:inherit}:host([intraArticleBlackCTA][ad-va2]) .action-row{display:flex;justify-content:space-between}:host([intraArticleBlackCTA][ad-va2]) .action-row .ad-label{display:inline-flex;border:unset;padding:unset}:host([intraArticleBlackCTA][ad-va2]) .action-row .popover-anchor{visibility:visible;position:static;width:auto;overflow:visible;display:inline-flex}}`.withBehaviors((0,et.G2)(tt.A` :host([intraArticleBlackCTA]) .heading{color:#fff}:host([intraArticleBlackCTA]) .attribution{color:#f0f0f0}`)),no=tt.A`
:host([ruby-va]) .abstract,:host([ruby][ruby-va]) .abstract{height:auto;margin-bottom:0px}:host([ruby-va]:not([intraarticle])) .body:has(.popover-anchor) .abstract,:host([ruby][ruby-va]:not([intraarticle])) .body:has(.popover-anchor) .abstract{height:20px}:host([ruby-va]:not([intraarticle])) .body:has(.popover-anchor) .text,:host([ruby][ruby-va]:not([intraarticle])) .body:has(.popover-anchor) .text{padding-block-end:8px}@media (max-width:${(0,Ft.c)(Q.YH-1)}){:host([ruby-va]),:host([ruby][ruby-va]),:host([ruby-va][intraarticle]),:host([ruby][ruby-va][intraarticle]){--card-height:auto}:host([ruby-va]) .root,:host([ruby][ruby-va]) .root,:host([ruby-va][intraarticle]) .root,:host([ruby][ruby-va][intraarticle]) .root{--card-height:auto}:host([ruby-va]) .root,:host([ruby][ruby-va]) .root{height:auto}:host([ruby-va]) .content-card-container,:host([ruby-va][intraarticle]) .content-card-container{gap:16px}:host([ruby-va]) .body,:host([ruby][ruby-va]) .body,:host([ruby-va][intraarticle]) .body,:host([ruby][ruby-va][intraarticle]) .body{padding:0px 20px}:host([ruby-va]) .text,:host([ruby-va][intraarticle]) .text{padding:0px}:host([ruby-va]) .abstract,:host([ruby][ruby-va]) .abstract{margin-block-end:4px}:host([ruby-va][intraarticle]) .action-row{padding-bottom:0px}:host([ruby-va]) .action-row{height:auto;padding:0px}:host([ruby-va][intraarticle]) .ad-choice{position:inherit}}`,ro=tt.A`
:host([ruby][ruby-right-rail-ads]){--card-height:600px;width:160px}:host([ruby][ruby-right-rail-ads][gem-page]){margin-top:40px}:host([ruby][ruby-right-rail-ads]) .root{padding:8px;height:600px;width:160px}:host([ruby][ruby-right-rail-ads]) .ad-label{position:absolute;left:50%;transform:translate(-50%,calc(-100% - 16px));color:#4C4642;font-feature-settings:'calt' off;font-family:"Segoe Sans";font-size:14px;font-style:normal;font-weight:620;line-height:20px}:host([ruby][ruby-right-rail-ads]) .ruby-image-container{width:144px;max-width:100%;aspect-ratio:1 / 1;margin-block-end:20px}:host([ruby][ruby-right-rail-ads]) .body{padding-left:8px;padding-right:8px}:host([ruby][ruby-right-rail-ads]) .text{max-height:calc(100% - 86px);padding:0px}:host([ruby][ruby-right-rail-ads]) .attribution,:host([ruby][ruby-right-rail-ads]) .popover-anchor{color:#4C4642;font-feature-settings:'calt' off;font-family:"Segoe Sans";font-size:10px;font-style:normal;font-weight:410;line-height:14px;}:host([ruby][ruby-right-rail-ads]) .attribution{margin-block-end:2px}:host([ruby][ruby-right-rail-ads]) .popover-anchor{margin-block-end:8px;z-index:2}:host([ruby][ruby-right-rail-ads]) .heading{color:#272320;font-family:"Segoe Sans";font-size:16px;font-style:normal;font-weight:620;line-height:22px;-webkit-line-clamp:none}:host([ruby][ruby-right-rail-ads]) .abstract{display:flex;margin-block-end:0px}:host([ruby][ruby-right-rail-ads]) .heading,:host([ruby][ruby-right-rail-ads]) .abstract{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:7;overflow:hidden;text-overflow:ellipsis}:host([ruby][ruby-right-rail-ads]) .action-row{margin-top:auto;margin-bottom:28px;height:auto;width:100%;padding:0px;margin-inline-start:auto;margin-inline-end:auto}:host([ruby][ruby-right-rail-ads]) .call-to-action{display:flex;width:112px;height:36px;min-width:36px;min-height:36px;padding:0 8px;justify-content:center;align-items:center;gap:4px;align-self:stretch;border-radius:12px;border:1px solid rgba(0,0,0,0.08);background:rgba(0,0,0,0.00)}:host([ruby][ruby-right-rail-ads]) .call-to-action-text{color:#272320;font-family:"Segoe Sans";font-size:14px;font-style:normal;font-weight:410;line-height:20px;letter-spacing:0}:host([ruby][ruby-right-rail-ads]) .card-actions-button-container{inset-block-start:20px;margin-inline-end:${nt.ACF}}:host([ruby][ruby-right-rail-ads]) .undo-button{width:100%}`.withBehaviors((0,et.G2)(tt.A` :host([ruby][ruby-right-rail-ads]) .ad-label{color:#A4ADC8;font-feature-settings:'calt' off;font-family:"Segoe Sans";font-size:14px;font-style:normal;font-weight:620;line-height:20px;}:host([ruby][ruby-right-rail-ads]) .attribution,:host([ruby][ruby-right-rail-ads]) .popover-anchor{color:#A4ADC8;font-feature-settings:'calt' off;font-family:"Segoe Sans";font-size:10px;font-style:normal;font-weight:410;line-height:14px;}:host([ruby][ruby-right-rail-ads]) .heading{color:#E5EBFA;font-feature-settings:'calt' off;font-family:"Segoe Sans";font-size:16px;font-style:normal;font-weight:620;line-height:22px;}:host([ruby][ruby-right-rail-ads]) .abstract{color:#A4ADC8;font-feature-settings:'calt' off;font-family:"Segoe Sans";font-size:14px;font-style:normal;font-weight:410;line-height:20px;}:host([ruby][ruby-right-rail-ads]) .call-to-action{border-radius:12px;border:1px solid rgba(255,255,255,0.08);background:rgba(255,255,255,0.00)}:host([ruby][ruby-right-rail-ads]) .call-to-action-text{color:#E5EBFA;font-family:"Segoe Sans";font-size:14px;font-style:normal;font-weight:410;line-height:20px;letter-spacing:0}`)),so=tt.A`
:host([size="1u"]) ::slotted([slot="action-row-start"]){position:absolute;bottom:6px}:host([size="1u"]) .text{display:flex;flex-direction:column}:host([size="_2x_2y"]) .text{display:flex;flex-direction:column;transition:padding-bottom 0.3s ease 0.1s;padding-bottom:0}:host([size="_2x_2y"]:hover) .text{padding-bottom:40px}:host([size="1u"]) .heading,:host([ruby]) .heading{height:var(--companion-heading-height,78px)}:host([size="_2x_2y"]:hover) .heading{max-height:64px}:host([ruby][size="1u"]) .heading{transition:margin-bottom 0.3s ease 0.1s;margin-bottom:0}:host([ruby][size="1u"]:hover) .heading{margin-bottom:8px}:host([size="1u"][media-type]) .media{transition:height 0.3s ease 0.1s;height:var(--companion-rest-card-height,157.062px);object-fit:cover;object-position:center top}:host([size="1u"][media-type]:hover) .media{height:var(--companion-hover-card-height,120px);object-fit:cover;object-position:center top}:host([size="_2x_2y"]) .hover-companion-button{display:flex;align-items:center;background-color:#FFFFFF;border:1px solid #D1D1D1;border-radius:16px;padding:4px 12px;margin-top:8px;font-size:12px;cursor:pointer;color:#000;box-shadow:0 2px 4px rgba(0,0,0,0.1);z-index:${At.I};position:absolute;bottom:40px;left:0;opacity:0;margin:0 16px;visibility:hidden;transition:opacity 0.5s ease 0.1s,visibility 0.5s ease 0.1s,bottom 0.5s ease 0.1s}:host([size="_2x_2y"]:hover) .hover-companion-button,:host([size="_2x_2y"]:focus-within) .hover-companion-button{opacity:1;visibility:visible;bottom:40px;margin:0 16px;transform:translateY(0)}:host([size="1u"]) .hover-companion-button{display:flex;align-items:center;background-color:#FFFFFF;border:1px solid #D1D1D1;border-radius:16px;padding:4px 12px;font-size:12px;cursor:pointer;color:#000;box-shadow:0 2px 4px rgba(0,0,0,0.1);z-index:${At.I};margin-top:8px;opacity:0;visibility:hidden;transform:translateY(0);transition:opacity 0.5s ease 0.1s,visibility 0.5s ease,transform 0.5s ease}:host(:hover) .hover-companion-button,:host(:focus-within) .hover-companion-button{opacity:1;visibility:visible;transform:translateY(0)}.hover-companion-button-icon{display:flex;align-items:center;margin-right:6px}.hover-companion-button-icon img{width:16px;height:16px}:host([size="1u"]:not([ruby])) .hover-companion-button:hover,:host([size="_2x_2y"]:not([ruby])) .hover-companion-button:hover{border:1px solid #C7C7C7;background-color:#F5F5F5}:host([ruby]) .text{padding-bottom:unset}:host([media-type][ruby]) .media{border-radius:12px}:host([media-type][ruby]:hover) .media{transform:none}:host([ruby]) .hover-companion-button{background-color:#EFF4FA;border-radius:12px;box-shadow:none;padding:6px;border:none;margin-top:0}:host([ruby]) .hover-companion-button:hover{background-color:#dee3e8}:host([ruby]) .hover-companion-button-icon{margin-right:4px}:host([ruby]) .hover-companion-button-text{font-family:"Segoe UI";font-size:12px;line-height:16px;color:#242424}.hover-companion-button:hover{background-color:#f5f5f5}`,lo=tt.A`
${Mi}
:host(:hover) .attribution{padding-inline-end:70px}:host(:hover) .media{filter:brightness(0.9)}:host(:hover[media-type]) .attribution{padding-inline-end:0}:host([immersive]) .action-row{padding:10px 0}:host([immersive]) .abstract{color:inherit}:host([immersive][media-type]) .badge{background-color:rgba(0,0,0,0.54)}:host([immersive]) .body{padding:10px 16px 0}:host([immersive]) .heading{font-size:${yt.aV};
    line-height: ${yt.bc};-webkit-line-clamp:2}:host([immersive][enable1UImmersive3LineTitle="true"]) .heading{font-size:${yt.TF};
    line-height: ${yt.Oc};-webkit-line-clamp:3}:host([immersive]) .headingPrefix{background-color:#0078d4;border-radius:3px;color:#fff;font-size:${yt.Kg};
    line-height: ${yt.Z6};padding:0 5px}:host([immersive]) .media{position:absolute;z-index:${jt.P.Below.toString()}}:host([immersive][media-type]) .badge{background-color:rgba(0,0,0,0.54)}:host([immersive][media-type]:not([ruby])) .body{background:linear-gradient(rgba(0,0,0,0) 33%,rgba(0,0,0,0.54) 66%);justify-content:end;padding:0 16px;margin-top:auto}:host([immersive][media-type]) .text{color:#ffff}:host([immersive][wide]) .media{aspect-ratio:153/76}:host([immersive]:not([wide])) .media{aspect-ratio:300/304}:host([immersive][responsive-height][responsive-width]) .media{aspect-ratio:unset}:host([media-type]) .abstract{display:none}:host([responsive-height][immersive]) .heading{-webkit-line-clamp:2}:host([responsive-height]:not([immersive])) .body{gap:${ot.rC}}:host([immersive]:not([wide])) .media{aspect-ratio:25/27}:host([size="0.5u"]) .abstract{display:none}:host([size="0.5u"]) .action-row{width:275px}:host([size="0.5u"]:not([hide-card])) .body{contain:size;margin:0 5px 0 0;padding:0;width:100%}:host([size="0.5u"]) .content-card-container{flex-direction:row-reverse;flex-wrap:nowrap}:host([size="0.5u"]) .heading{-webkit-line-clamp:3}:host([size="0.5u"][media-type]) .media{border-radius:var(--borderRadiusLarge,${ut.U9});height:90px;width:90px}:host([size="0.5u"]) .text{padding:0}:host([use1ucard2linetitle="true"]) .heading{line-height:1.4em}:host([use1ucard2linetitle="true"]:not([four-line-title])) .heading{-webkit-line-clamp:2}::slotted([slot="attribution-text"]){overflow:hidden;text-overflow:ellipsis;white-space:nowrap}::slotted([slot="action-row-start"]){z-index:${At.I}}::slotted([slot="action-row-end"]){z-index:${At.I}}::slotted([slot="following-button"]){--follow-button-height-override:20px;--follow-button-position-override:static;padding-inline-start:2px;transition:all 0.2s cubic-bezier(0,0.8,0,1) 0s;z-index:calc(${At.I} + 1)}.abstract{color:var(--color-neutral-foreground-2);display:-webkit-box;margin-top:5px;overflow:hidden;text-decoration:none;-webkit-box-orient:vertical;-webkit-line-clamp:var(--abstract-lines,3)}.action-row{align-items:center;align-self:stretch;display:flex;justify-content:space-between;height:24px}.action-row-end{align-items:flex-end;height:inherit}.action-row-start{align-items:flex-start;height:inherit}.ad-label-container{z-index:${jt.P.Above.toString()}}.attribution{align-items:center;box-sizing:border-box;display:inline-flex;font-size:${yt.kS};
    height: 16px;
    line-height: ${yt.Fr};
    font-weight: ${st.IH6};margin-bottom:4px;text-overflow:ellipsis;white-space:nowrap;width:100%}.attribution-flip{margin-bottom:unset}.attribution-divider{padding:0 calc(${Ct.vR} * 1px)}.attribution-image{border-radius:${ut.aU};
    display: flex;
    height: 16px;
    margin-inline-end: calc(${Ct.vR} * 2px);width:16px}.attribution-text{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.arrow-trending-icon{display:block;width:16px;height:16px;background-color:${nt.C6c};
    mask: url(${ve}) no-repeat center;
    -webkit-mask: url(${ve}) no-repeat center;
    margin-inline-end: calc(${Ct.vR} * 1px)}.badge{align-items:center;background-color:var(--color-card-background);border-radius:${ut.U9};
    border: none;
    color: var(--color-neutral-foreground-1);
    cursor: pointer;
    display: inline-flex;
    height: 20px;
    max-width: 130px;
    padding: 0 6px;
    margin: 0 -6px;
    z-index: ${At.I}}.badge[disabled]{z-index:0}.badge:hover{background-color:var(--color-neutral-background-1-hover)}.badge-text{font-family:${wt.O};
    font-size: ${yt.kS};margin-bottom:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.badge-icon{margin-inline-end:4px;width:13px}.body{align-items:flex-start;align-self:stretch;display:flex;flex-direction:column;gap:0px;height:-webkit-fill-available;justify-content:space-between;padding:0 16px}:host(:not([ruby])) .body{height:100%}.content-card-container{align-items:flex-start;display:flex;flex-direction:column;gap:0;height:100%;width:100%}.content-indicator{align-items:center;background-color:rgba(0,0,0,0.5);border-radius:4px;display:flex;height:20px;inset-inline-start:16px;justify-content:center;position:absolute;top:14px;width:20px;z-index:${At.I}}cs-contextual-feedback{align-self:center}.heading{color:inherit;display:-webkit-box;font-size:${yt.TF};
    font-weight: 600;
    line-height: ${yt.Oc};line-height:26px;overflow:hidden;text-decoration:none;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-lines,3);width:inherit}.heading-flip{margin-bottom:4px}.heading-content{margin-bottom:12px}.heading:focus-visible{outline:none;text-decoration:underline}.heading:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;width:100%;z-index:${At.I}}.heading:focus-visible::after{border-radius:${ut.g4};outline:var(--color-neutral-foreground-1) auto 2px}.icon-invert-color{filter:invert(1)}.media{align-self:stretch;aspect-ratio:1.91 / 1;display:flex;width:100%}.text{align-items:flex-start;color:var(--color-neutral-foreground-1);display:flex;flex-direction:column;font-family:${wt.O};
    font-size: ${yt.Kg};
    line-height: ${yt.Z6};
    padding-top: 12px;
    width: 100%;
}
`.withBehaviors(new it.o("ad",!0,Bi),new it.o("companion",!0,so),new it.o("fontTrackingStyle","v1",ke),new it.o("fontTrackingStyle","v2",Ae),new it.o("fontWeightStyle","normal",ze),new it.o("gradientClass","light-gradient-v1",Be),new it.o("gradientClass","light-gradient-v2",Se),new it.o("gradientClass","light-gradient-v3",je),new it.o("gradientClass","light-gradient-v4",De),new it.o("hideCardType","feedback",Qi),new it.o("hideCardType","spinner",Zi),new it.o("hideCardType",O.j.rubyOverlay,Oi),new it.o("hideCardType",O.j.adHidden,qi),new it.o("hoverImgZoomRatio",105,Ee),new it.o("hoverImgZoomRatio",110,Pe),new it.o("cjkEarnedDifferences",!0,ye),new it.o("use22ptHeadings",!0,Ce),new it.o("useGreyHoverEffect",!0,Fe),new it.o("useAmpHoverEffect",!0,Te),new it.o("useBoxShadowHoverEffect",!0,_e),new it.o("useBgHoverEffect",!0,Ie),new it.o("ruby",!0,He),new it.o("mediaType","video",be),new it.o("msn",!0,Oe),new it.o("segment",!0,Ke),new it.o("responsiveWidth",!0,We),new it.o("useF3UX",!0,Ge),new it.o("useWindowsShellCardStyle",!0,Ne),new it.o("intraArticle",!0,Ye),new it.o("aiHeading",!0,io),new it.o("watchAdVideo",!0,eo),new it.o("watchInarticleAd",!0,oo),new it.o("intraArticleBlackCTA",!0,ao),new it.o("rubyVA",!0,no),new it.o("rubyRightRailAds",!0,ro),new it.o("isIntraFeedAd",!0,Ze),new it.o("intraFeedAdWeather",!0,Qe),new it.o("isIntraClassicAd",!0,to),new it.o("casualGamesV3Ad","hero-infopane",ti),new it.o("casualGamesV3Ad","hero",ii),new it.o("casualGamesV3Ad","vertical-game",ei),new it.o("casualGamesV3Ad","game",oi),new it.o("casualGamesV3Ad","intra-feed",ai),(0,ht.U)("light",we),(0,ht.U)("dark",$e),(0,et.mr)(Ve)),ho=tt.A`
:host{outline:1px solid ${bt.A.CanvasText}}:host([no-content]):focus-within{outline:var(--color-neutral-foreground-1) auto 2px}`,co=tt.A`
:host([size="1u"][ruby]),:host([size="2c"][ruby]){height:100%;display:flex;--card-height:100%;contain-intrinsic-height:none;min-height:${ot.UJ};
    max-height: ${ot.gY}}:host([size="1u"][ruby]){aspect-ratio:${at.du.toString()} / ${at.C6.toString()}}:host([size="2c"][ruby]){aspect-ratio:${at.Mq.toString()} / ${at.j9.toString()}}:host([size="1u"][ruby]) .root,:host([size="2c"][ruby]) .root{height:100%;contain-intrinsic-height:none}${vt.v9}
`,uo=tt.A`
:host([size="1u"][ruby]) .heading{font-size:${nt.N0T};
    line-height: ${nt.Q7d};
}
`,po=tt.A`
@supports (container-type:size){:host([size="1u"][ruby]){container-type:size;container-name:ruby-responsive-card}@container ruby-responsive-card (max-height:${(0,Ft.c)(at.Tw)}){:host([size="1u"][ruby]) .heading{font-size:${nt.N0T};
            line-height: ${nt.Q7d};
        }
    }
}
`.withBehaviors(new it.o("isProng2",!0,uo)),go=tt.A`
:host([size="1.5u"][ruby]),:host([size="2c"][ruby]),:host([ruby]){width:100%;min-width:inherit;max-width:inherit}:host([ad]) .attribution{max-width:236px}.attribution-text{max-width:184px}`.withBehaviors(new rt.P(xt.ve,xt.Y),new rt.P(xt.NM,xt.uE),new rt.P(mt.Es,mt.t3),new rt.P(mt.gN,mt.b$)),bo=tt.A` :host([ruby][size="1u"]){--card-height:${(0,Ft.c)(at.$V)};
    }
`,vo=tt.A`
:host([ruby]){--card-height:${ot.Qk};
    box-sizing: border-box;
    contain-intrinsic-height: auto ${ot.Qk};
    width: ${ot.dd};display:grid;grid-template-columns:1fr;place-content:center;place-items:center;background-color:unset;position:relative}:host([size="1.5u"][ruby]){--card-height:${ot.tM};
    contain-intrinsic-height: auto ${ot.tM};
    width: ${ot.dd}}:host([size="0.5u"][ruby]),:host([segment][ruby][size="0.5u"]:not([responsive-height])){--card-height:${(0,Ft.c)(at.Yc)};
    contain-intrinsic-height: auto ${(0,Ft.c)(at.Yc)}}:host([no-content][size="2c"][ruby]){--card-height:${(0,Ft.c)(at.j9)};
    contain-intrinsic-height: auto ${(0,Ft.c)(at.j9)}}:host([size="2c"][ruby]){width:${ot.MY};
    --card-height: var(--height-card-2c-px, ${(0,Ft.c)(at.j9)});contain-intrinsic-height:auto var(--card-height)}:host([segment][ruby][size="2c"]:not([responsive-height])){--card-height:388px;contain-intrinsic-height:auto 388px}:host([size="0.5u"][ruby]:not([no-content])) .root{padding:${st.$rH}}:host([ruby]) .root{padding:${st.$rH};
    width: calc(100% - 2 * ${dt.q_});
    height: calc(var(--card-height) - 2 * ${dt.q_});
    contain: layout;
    content-visibility: visible;
    backdrop-filter: var(--background-card-stnp-filter, none);
    background-color: var(--responsive-card-background-override, ${nt.lHC});
    border-radius: calc(${st.MCQ} * ${st.MU6});
    border: ${dt.q_} solid ${nt.h7K};corner-shape:squircle}:host([ruby]) .root:focus-visible{outline:none}:host([immersive][ruby]) .root{padding:0;aspect-ratio:var(--card-aspect-ratio,unset);border:none}:host([ruby]) .loading-text{margin-inline-start:0px}:host([ruby][grouped-item]){--card-height:100%;width:100%;height:auto;aspect-ratio:unset;max-width:462px;background:transparent}:host([ruby][grouped-item]) .root{padding:0px;margin:0px;width:100%;height:100%}.ruby-image-container,.video-container{border-radius:${dt.tM};
    corner-shape: squircle;
}
${gt.W9}
${(0,lt.RY)()}
${ft.c}
`.withBehaviors(new it.o("isAdaptiveThemeEnabled",!0,go),new it.o("enableTallRubyCard",!0,bo),new it.o("isTallOrFlexReverse",!1,co),new it.o("disableCntQueries",!1,po),(0,ht.U)("dark",ct.VM)),xo=tt.A`
:host,.root{--borderRadiusXLarge:4px}:host([size="0.5u"]) .root{padding:8px}:host([msn][responsive-height]:not([auto-sized])){--card-height:100%;aspect-ratio:unset;width:100%}`,mo=tt.A`
:host{padding:calc(${ot.IU} * 2px)}:host([size="_1x_1y"]:not([responsive-height])),:host([size="0.5u"]:not([responsive-height])){--card-height:${ot.cP};
    contain-intrinsic-height: auto ${ot.cP}}.loading-heading1{width:100%}.loading-media{border-radius:auto}.loading-text{margin-inline-start:auto}`,fo=tt.A` :host([segment][ruby]:not([responsive-height])){--card-height:${ot.tM}; 
    }
`,wo=tt.A` :host(:not([responsive-height])){--card-height:160px;width:100%}:host(:not([responsive-height])) .root{border:${dt.q_} solid ${nt.h7K};
        background: var(--responsive-card-background-override, var(--color-card-background));
    }

    @media (min-width: ${(0,Ft.c)(Q.dr)}) and (max-width: ${(0,Ft.c)(Q.YH-1)}){:host(:not([responsive-height])){--card-height:auto}}`,yo=tt.A` :host(:not([responsive-height])){--card-height:144px;width:100%}.content-card-container{flex-direction:row}.media{height:144px;width:144px;aspect-ratio:unset}`,$o=tt.A` :host([intraArticle][isIntraFeedAd][ruby][intraFeedAdWeather]){width:var(--weather-container-width);margin-inline:auto;margin-block:0}`,ko=tt.A` :host([intraArticle][isIntraFeedAd][ruby]){margin-block:${nt.xo8}}:host([intraArticle][isIntraFeedAd][ruby]) .root{background-color:var(--responsive-card-background-override,${nt.lHC});
    }

    /* 4-column layout */
    @media (min-width: ${(0,Ft.c)(Q._$)}){:host([intraArticle][isIntraFeedAd][ruby]){--card-height:233px;margin-inline:auto;max-width:1040px;width:100%}}@media (min-width:${(0,Ft.c)(Q.fh)}) and (max-width: ${(0,Ft.c)(Q._$-1)}){:host([intraArticle][isIntraFeedAd][ruby]){--card-height:233px;max-width:944px;min-width:836px;margin-inline:46px;width:auto}}@media (min-width:${(0,Ft.c)(Q.YH)}) and (max-width: ${(0,Ft.c)(Q.fh-1)}){:host([intraArticle][isIntraFeedAd][ruby]){aspect-ratio:736 / 206;height:100%;max-height:206px;min-height:175px;width:100%}}`,Ao=tt.A` :host([isIntraClassicAd][loading]){display:none}:host([intraArticle][isIntraFeedAd][isIntraClassicAd]){border-radius:8px;margin:16px 0px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_5x_2y"]){--card-height:199px;margin-inline:254px;width:1040px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_4x_2y"]){--card-height:199px;margin-inline:98px;width:1040px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_3x_2y"]){--card-height:178px;margin-inline:96px;width:732px}:host([intraArticle][isIntraFeedAd][isIntraClassicAd][size="_2x_2y"]){height:160px;width:610px}`,zo=tt.A`:host([watchAdVideo]){--card-height:auto;width:100%;height:auto;contain-intrinsic-height:auto;border:none;outline:none;box-shadow:none}:host([watchAdVideo]) .root{padding:0}:host([watchAdVideo][ruby]) .root{border:unset;background:unset !important}`,Co=tt.A`
:host([watchinarticlead]){--card-height:146px;display:block;background:rgba(221,221,221,0.4);border:1px solid rgba(0,0,0,0.06);border-radius:12px}:host([watchinarticlead]) .root,:host([ruby][watchinarticlead]) .root{padding:0;border-radius:12px}@media (max-width:${(0,Ft.c)(Q.YH-1)}){:host([watchinarticlead]){width:100%;--card-height:auto}}`.withBehaviors((0,et.G2)(tt.A` :host([watchinarticlead]){background:rgba(0,0,0,0.2);border:1px solid rgba(255,255,255,0.12)}`)),Fo=tt.A`
:host{border-radius:calc(${st.MCQ} * ${st.MU6});corner-shape:squircle}.root{border-radius:calc(${st.MCQ} * ${st.MU6});
    corner-shape: squircle;
    padding: ${st.$rH}}.media{border-radius:${dt.tM};corner-shape:squircle}.heading{font-size:${nt.N0T};
    line-height: ${nt.Q7d};
    font-weight: ${st.fNx};
}
${ft.c}
`,_o=tt.A`
:host(:not([responsive-height])){width:100%}:host(:not([responsive-height])) .root{border:${dt.q_} solid ${nt.h7K};background:var(--responsive-card-background-override,var(--color-card-background))}.media{height:144px;width:275px;aspect-ratio:unset}:host([intraArticleBlackCTA]){--card-height:144px;display:block;background:rgba(221,221,221,0.4);box-shadow:none;border:1px solid rgba(0,0,0,0.05);border-radius:12px}:host([intraArticleBlackCTA]:hover){box-shadow:0px 2px 4px var(--shadow-primary-color),0px 0px 2px var(--shadow-secondary-color)}:host([intraArticleBlackCTA]) .root{padding:0;border-radius:12px}${(0,Z.H5)(Z.j1.c1)}{:host([intraArticleBlackCTA]){width:275px;--card-height:288px;box-shadow:0px 1px 2px var(--shadow-primary-color),0px 0px 2px var(--shadow-secondary-color);border:none}}`.withBehaviors((0,et.G2)(tt.A` :host([intraArticleBlackCTA]){background:rgba(0,0,0,0.2)}`)),To=tt.A`
${lo}
@media (prefers-color-scheme:dark){:host(:hover){box-shadow:0px 4px 8px rgba(0,0,0,0.26)}}@keyframes shimmereffect{from{transform:translateX(-100%)}to{transform:translateX(100%)}}:host{--card-height:${ot.Sl};
    --shadow-primary-color: rgba(0, 0, 0, 0.14);
    --shadow-secondary-color: rgba(0, 0, 0, 0.12);
    background-color: var(--responsive-card-background-override, var(--color-card-background));
    border-radius: var(--borderRadiusXLarge, ${ut.g4});
    box-shadow: 0px 1px 2px var(--shadow-primary-color), 0px 0px 2px var(--shadow-secondary-color);
    color: var(--color-neutral-foreground-1-override, var(--color-neutral-foreground-1));
    contain-intrinsic-height: auto var(--card-height);
    cursor: pointer;
    display: block;
    font-family: ${wt.O};
    height: var(--card-height);
    min-height: 0;
    width: var(--override-card-width, var(--card-min-width, ${ot.DA}))}:host([auto-sized]){background:none;box-shadow:none;height:auto;margin-inline:-16px;min-height:var(--card-height);min-width:${ot.DA};
    padding: 2px 16px;
    width: auto;
}
${(0,Z.H5)(Z.j1.c5)}{:host([auto-sized][size="_5x_2y"]){width:100%}}${(0,Z.H5)(Z.j1.c4)}{:host([auto-sized][size="_4x_2y"]){width:100%}}${(0,Z.H5)(Z.j1.c3)}{:host([auto-sized][size="_3x_2y"]){width:100%}}${(0,Z.H5)(Z.j1.c2)}{:host([auto-sized][size="_2x_2y"]){width:100%}}:host([auto-sized]:hover){box-shadow:none}:host(#displayAdBanner){--card-height:auto;cursor:auto;margin:0;padding:0;width:100%}:host(:hover){box-shadow:0px 2px 4px var(--shadow-primary-color),0px 0px 2px var(--shadow-secondary-color)}:host([immersive]) .root{padding:0}:host([no-content]:not([auto-sized]):not([responsive-width]):not([size="_1x_1y"])) .root,:host([no-content]:not([auto-sized]):not([responsive-width]):not([size="0.5u"])) .root{min-height:${ot.gw}}:host([no-content]:not([auto-sized])) .root{padding:0px}:host([no-content][auto-sized]) .root{contain:none;content-visibility:unset}:host([no-content]) .loading-container{height:calc(${ot.gw} - (${ot.IU} * 4));
    padding: calc(${ot.IU} * 2px)}:host([outside-content]) .root{contain:none;content-visibility:visible}:host([responsive-height]:not([immersive]):not([loading])){--card-height:auto;contain-intrinsic-height:auto var(--placeholder-intrinsic-height,${ot.Sl})}:host([responsive-height][ad]:not([immersive])){--card-height:${ot.Sl}}:host(:not([responsive-height])){--card-height:${ot.gw};
    contain-intrinsic-height: auto ${ot.gw}}:host([loading-effect]) .shimmer{position:relative;overflow:hidden;border-radius:var(--borderRadiusLarge,6px);background:var(--colorNeutralStroke2,var(--color-neutral-stroke-2))}:host([loading-effect]) .shimmer::after{animation:shimmereffect 1s infinite linear;content:"";position:absolute;top:0;left:0;width:100%;height:100%;background:linear-gradient(to right,transparent 0%,var(--colorNeutralStroke3,var(--color-neutral-stroke-3)) 50%,transparent 100%);background-size:300%;border-radius:var(--borderRadiusLarge,6px)}:host([responsive-width]) .root{height:100%;width:100%}:host([responsive-width][responsive-height]:not([auto-sized])){--card-height:100%;aspect-ratio:unset;width:100%}:host([size="_1x_1y"]:not([responsive-height])),:host([size="0.5u"]:not([responsive-height])){--card-height:${ot.TX};
    contain-intrinsic-height: auto ${ot.TX}}:host([size="_1x_1y"]) .root,:host([size="0.5u"]) .root{padding:14px}:host([wide]){aspect-ratio:153 / 76;width:var(--override-card-wide-width,${ot.k9})}.loading-attribution{width:50%}.loading-container{align-items:flex-start;align-self:stretch;display:flex;flex-direction:column;gap:${ot.fI};height:100%;width:100%}.loading-heading1{width:85%}.loading-heading2{width:40%}.loading-media{align-self:stretch;aspect-ratio:1.91 / 1;border-radius:0;display:block;width:100%}.loading-text{height:15px;margin-inline-start:16px}.root{border-radius:var(--borderRadiusXLarge,${ut.g4});box-sizing:border-box;contain:content;content-visibility:auto;height:inherit;padding:0px 0px 10px;width:inherit}.popover-slot{border:0;color:inherit;padding:0}`.withBehaviors(new it.o("segment",!0,fo),new it.o("ruby",!0,vo),new it.o("msn",!0,xo),new it.o("useF3UX",!0,mo),new it.o("intraArticle",!0,wo),new it.o("intraArticleDualClassic",!0,yo),new it.o("watchAdVideo",!0,zo),new it.o("watchInarticleAd",!0,Co),new it.o("intraArticleBlackCTA",!0,_o),new it.o("isIntraFeedAd",!0,ko),new it.o("intraFeedAdWeather",!0,$o),new it.o("isIntraClassicAd",!0,Ao),new it.o("casualGamesV3Ad","hero-infopane",ni),new it.o("casualGamesV3Ad","hero",ri),new it.o("casualGamesV3Ad","vertical-game",si),new it.o("casualGamesV3Ad","game",di),new it.o("casualGamesV3Ad","intra-feed",li),new it.o("isRubifyDashboard",!0,Fo),(0,ht.U)("light",pt.y),(0,ht.U)("dark",pt.S),(0,et.mr)(ho));var Io=e(96950),Bo=e(60402),So=e(69259),jo=e(39957),Do=e(77793),Vo=e(66591),Ro=e(6497),Eo=e(48535),Po=e(79119);const Lo=Io.qy`<button class="card-actions-button" @click=${(t,i)=>t.onClickCardActions&&t.onClickCardActions(t.data,i.event,void 0,t)} data-t="${t=>t.telemetryTag_moreActions}" title=${t=>{var i;return t.ruby?t.strings.rubyActionButtonTooltip:null===(i=t.data)||void 0===i||null===(i=i.cardActionsTooltips)||void 0===i?void 0:i.seeMore}} aria-label=${t=>{var i;return t.ruby?t.strings.rubyActionButtonTooltip:null===(i=t.data)||void 0===i||null===(i=i.cardActionsTooltips)||void 0===i?void 0:i.seeMore}} ?ruby=${t=>t.ruby}><img alt="" aria-hidden="true" loading="eager" src=${t=>t.watchAdVideo?`${(0,k.rA)().StaticsUrl}/latest/views/icons/More.svg`:`${(0,k.rA)().StaticsUrl}/latest/fluent-icons/more_horizontal_20_regular.svg`}></img></button>`,Mo=Io.qy`<button class="hide-card-button" @click=${(t,i)=>t.onClickHideCard&&t.onClickHideCard(t.data,i.event)} data-t="${t=>t.telemetryTag_hideCard}" title=${t=>{var i,e;return t.config.useUpdatedHideStoryStrings?null===(i=t.data)||void 0===i||null===(i=i.cardActionsTooltips)||void 0===i?void 0:i.notInterested:null===(e=t.data)||void 0===e||null===(e=e.cardActionsTooltips)||void 0===e?void 0:e.hide}} aria-label=${t=>{var i,e;return t.config.useUpdatedHideStoryStrings?null===(i=t.data)||void 0===i||null===(i=i.cardActionsTooltips)||void 0===i?void 0:i.notInterested:null===(e=t.data)||void 0===e||null===(e=e.cardActionsTooltips)||void 0===e?void 0:e.hide}} ?ruby=${t=>t.ruby}><img alt="" aria-hidden="true" loading="eager" src="${(0,k.rA)().StaticsUrl}/latest/fluent-icons/dismiss_20_regular.svg"></img></button>`,Uo=Io.qy` ${(0,So.z)(t=>!t.isRubifyDashboard,Mo)} ${Lo}
`,Ho=Io.qy`
${t=>(0,Ro.O)(t.likeButtonProps)}
`,Oo=Io.qy`
${t=>(0,Eo.U)(t.dislikeButtonProps)}
`,Wo=Io.qy`
${t=>(0,Po.g)(t.commentButtonProps)}
`,Go=Io.qy`<div class="ruby-social-bar">${(0,So.z)(t=>t.showLikeButtonCardAction,Ho)} ${(0,So.z)(t=>t.showDislikeButtonCardAction,Oo)} ${(0,So.z)(t=>t.showCommentButtonCardAction,Wo)}</div>`,No=Io.qy` ${(0,So.z)(t=>t.showLikeButtonCardAction,Ho)} ${Lo}
`,Ko=Io.qy`${(0,So.z)(t=>!t.ad&&!t.enableRubyBottomSocialBar,No,Lo)}`,qo=Io.qy`${(0,So.z)(t=>t.ad||t.disableHideStoryIcon,Lo,Uo)}`,Xo=Io.qy`<div class=${t=>(0,Vo.x)("card-actions-button-container",["no-image-action-container",!t.mediaType])} ?ruby=${t=>t.ruby}>${(0,So.z)(t=>t.ruby,Ko,qo)}</div>`,Jo=Io.qy` ${Go} ${Xo}
`,Yo=Io.qy` ${(0,So.z)(t=>t.enableRubyBottomSocialBar&&!t.ad,Jo,Xo)}
`,Qo=Io.qy` ${(0,So.z)(t=>!t.hideCardActions,Yo)}
`;var Zo=e(6637);const ta=Io.qy` ${t=>(0,Zo.$)({href:t.href_adChoiceButton,telemetryTag:t.telemetryTag_adChoiceButton,text:t.strings.adChoice})}
`,ia=Io.qy` ${t=>{var i,e,o;return(0,l.Xx)({popoverAction:"tooltip"===(null===(i=t.popoverData)||void 0===i?void 0:i.type)?"show":"openModal",renderPopoverCallback:t.triggerDisclaimer,title:"tooltip"===(null===(e=t.popoverData)||void 0===e?void 0:e.type)?t.strings.adDisclaimer:null===(o=t.popoverData)||void 0===o||null===(o=o.data)||void 0===o?void 0:o.title,telemetryTag:t.telemetryTag_adDisclaimerButton})}}
`;var ea=e(98515);const oa=Io.qy` ${t=>{var i;return(0,ea.Q)({href:t.href_adButton,noBorder:t.config.enableAdSponsoredText,telemetryTag:t.telemetryTag_adButton,text:t.stringsAdLabel,enableDSADialog:t.config.enableDSADialog,dsaDialogTooltip:t.config.enableDSADialog?null===(i=t.config.localizedStrings)||void 0===i?void 0:i.dsaDialogTooltip:void 0})}}
`;var aa=e(53914);const na=Io.qy` ${t=>(0,aa.c)({href:t.href,callToAction:t.callToAction||t.defaultCta,telemetryTag:t.telemetryTag_callToAction})}
`,ra=Io.qy` ${(0,jo.ux)(t=>t.adAttributes,Io.qy`<span class="va-attribute" title="${t=>t.assetValue}" style="${t=>"rating"===t.assetType?"--star-rating: "+t.assetValue+";":void 0}" type="${t=>t.assetType}">${(0,So.z)(t=>"workingHours"===t.assetType,Io.qy`<span class="working-hour-status" ?open=${t=>t.hoursOpenValue}>${t=>t.hoursStatusValue}</span>- `)} ${t=>t.assetValue} ${(0,So.z)(t=>"rating"===t.assetType,Io.qy`(${t=>t.reviewValue})`)}</span>`,{positioning:!0,recycle:!0})}
`,sa=Io.qy` ${(0,So.z)(t=>t.adVA||t.adVA2||t.isIntraClassicAd,ra,Io.qy`${t=>t.data.description}`)}
`,da=Io.qy`<div class="ad-dts-description" slot="abstract">${t=>t.data.description}</div>`,la=(0,k.rA)().StaticsUrlWithBuild,ha=`${la}views/icons/ChevronRightBlackBold.svg`,ca=`${la}views/icons/ChevronRightWhiteBold.svg`,ua=Io.qy`<div class="call-to-action" slot="abstract"><a class="call-to-action-link" href="${t=>t.href}" target="${n.z._blank}" rel="noopener noreferrer" title="${t=>t.heading}" ${(0,Do.Ib)(!0,!1)} data-t="${t=>t.telemetryTag_anchor}"><picture><!-- Dark mode --><source srcset="${ha}" media="(prefers-color-scheme: dark)"><!-- Light mode --><source srcset="${ca}" media="(prefers-color-scheme: light)"><!-- Fallback (light mode as default) --><img class="call-to-action-icon" src="${ca}" alt="call to action icon" /></picture></a></div>`,pa=Io.qy`<div class="overlay-cta-container" tabindex="0"><a class="overlay-cta-button ${t=>t.data.enableDynamicCallToAction?"dynamic":"fixed"}" href="${t=>t.href}" @click=${(t,i)=>t.handleContentCardLinkClick(i.event)} data-t="${t=>t.telemetryTag_callToAction}" target="${t=>t.target}" aria-label="${t=>t.callToAction}">${(0,So.z)(t=>t.data.enableDynamicCallToAction,Io.qy`<span class="cta-text-dynamic">${t=>t.callToAction}</span><img class="cta-icon-dynamic" src="${()=>{var t;return`${null===(t=(0,k.rA)())||void 0===t?void 0:t.StaticsUrlWithBuild}views/icons/CallToActionChevronRight.svg`}}" alt="" aria-hidden="true" /><img class="cta-icon-dynamic-compact" src="${()=>{var t;return`${null===(t=(0,k.rA)())||void 0===t?void 0:t.StaticsUrlWithBuild}views/icons/CallToActionIcon.svg`}}" alt="" aria-hidden="true" />`,Io.qy`<img class="cta-icon-fixed" src="${()=>{var t;return`${null===(t=(0,k.rA)())||void 0===t?void 0:t.StaticsUrlWithBuild}views/icons/CallToActionIcon.svg`}}" alt="" aria-hidden="true" />`)}</a></div>`,ga=Io.qy`<button class="intra-feed-ad-cta" role="button" title="${t=>t.callToAction}" aria-label="${t=>t.callToAction}" @click=${(t,i)=>{t.handleContentCardLinkClick(i.event),window.open(t.href,t.target)}} ${(0,Do.Ib)(!0,!1)} data-t="${t=>t.telemetryTag_callToAction}">${t=>{var i,e;return(null===(i=t.strings)||void 0===i?void 0:i.ctaLearnMoreText)||(null===(e=t.data)||void 0===e||null===(e=e.localizedStrings)||void 0===e?void 0:e.intraArticleCallToAction)}}</button>`,ba=Io.qy` ${(0,So.z)(t=>!t.ruby,Io.qy`<span class="action-row-sub-container">${(0,So.z)(t=>{var i;return!(t.adCashback||null!==(i=t.config)&&void 0!==i&&i.enableAdChoiceInCardActions)},ta)} ${oa}</span>`)}
`,va=Io.qy`<span class="action-row-sub-container">${(0,So.z)(t=>{var i;const e=(t=>{var i;return t.popoverData||(null===(i=t.data)||void 0===i?void 0:i.popoverData)})(t);return null==e||null===(i=e.data)||void 0===i?void 0:i.text},Io.qy` ${ia} `)} ${(0,So.z)(t=>{var i;return!t.adCashback&&!(null!==(i=t.config)&&void 0!==i&&i.enableAdChoiceInCardActions)&&(!t.ruby||t.intraArticle)},ta)}</span>`,xa=Io.qy` ${(0,So.z)(t=>!t.ruby,Io.qy`<span class="action-row-sub-container">${(0,So.z)(t=>{var i;return!(null!==(i=t.config)&&void 0!==i&&i.enableAdChoiceInCardActions)},ta)} ${(0,So.z)(t=>!t.isAdSocialBarEnabled,oa)}</span>`)} ${na} ${(0,So.z)(t=>{var i;return t.ruby&&t.intraArticle&&!(null!==(i=t.config)&&void 0!==i&&i.enableAdChoiceInCardActions)},ta)}
`,ma=Io.qy`<span class="action-row-sub-container">${na} ${(0,So.z)(t=>{var i;return!(null!==(i=t.config)&&void 0!==i&&i.enableAdChoiceInCardActions)},ta)}</span>`,fa=Io.qy`<div class="attribution-container">${(0,So.z)(t=>{var i;return(null===(i=t.attributionData)||void 0===i?void 0:i.src)&&!t.errorAttributionImage},Io.qy`<img alt="${t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.altText}}" aria-hidden="true" class="attribution-image" @error=${t=>t.onAttributionImageError()} src="${t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.src}}"></img>`)} ${(0,So.z)(t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.name},Io.qy`<span class="attribution-text">${t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.name}}</span>`)}</div><div class="action-row-sub-container">${oa} ${(0,So.z)(t=>{var i;return!(null!==(i=t.config)&&void 0!==i&&i.enableAdChoiceInCardActions)},ta)}</div>`,wa=Io.qy`<div class="cashback-badge"><img class="msft-logo" alt="Microsoft Logo" src="${(0,k.rA)().StaticsUrl}/latest/responsive-card/msftLogo16.svg"/><span class="cashback-title">${t=>t.strings.adCashbackTitle}</span></div>`,ya=Io.qy` ${(0,So.z)(t=>(!t.ruby||t.intraArticleClassic)&&!t.isAdSocialBarEnabled,oa)} ${va}
`,$a=Io.qy`<slot class="action-row-start" name="action-row-start"></slot>`,ka=Io.qy`<div class="product-ads-price">${t=>{var i;return null===(i=t.data)||void 0===i||null===(i=i.assets)||void 0===i?void 0:i.price}}</div>`,Aa=Io.qy` ${(0,So.z)(t=>t.isAdSocialBarEnabled,$a)} ${(0,So.z)(t=>t.watchAdVideo,Io.qy`<span class="action-row-sub-container">${Qo}</span>`)} ${(0,So.z)(t=>!t.watchAdVideo&&t.callToAction&&!t.isIntraClassicAd,Io.qy` ${(0,So.z)(t=>t.isAdSocialBarEnabled,ma,xa)} `)} ${(0,So.z)(t=>t.shouldShowStandalonePopover,Io.qy` ${ba} ${ia} `)} ${(0,So.z)(t=>t.intraArticleBlackCTA&&t.adVA2&&t.hasStandalonePopover&&!t.shouldShowStandalonePopover,Io.qy` ${ia} `)} ${(0,So.z)(t=>t.shouldShowRubyAdSlug&&!t.isIntraClassicAd,ya)} ${(0,So.z)(t=>t.intraArticleDualClassic,fa)} ${(0,So.z)(t=>t.isIntraFeedAd,ga)}
`;var za,Ca=e(18284),Fa=e(65055);const _a=`${null===(za=(0,k.rA)())||void 0===za?void 0:za.StaticsUrl}latest/common/icons/PlayWhite.svg`,Ta=t=>{var i;const e=(null===(i=t.videoData)||void 0===i?void 0:i.imageUrl)||"";return e&&"shorts"===t.size?function(t,i,e,o){if(t&&i&&e){const a=new URL(t);return a.searchParams.set("w",i.toString()),a.searchParams.set("h",e.toString()),o&&a.searchParams.set("c",o.toString()),a.toString()}return t}(e,235,418,3):e},Ia=Io.qy`<div class="end-slate-container"><div class="end-slate-info"><img src=${_a} aria-hidden="true" height="13px" width="12px" />${t=>{var i;return null===(i=t.strings)||void 0===i?void 0:i.keepWatchingLabel}}</div></div>`,Ba=(0,Ca.A)(t=>Io.qy`<video class="media" ?is-portrait="${t=>{var i;return null===(i=t.previewController)||void 0===i?void 0:i.isPortrait}}" ?display-cta="${t=>{var i;return null===(i=t.previewController)||void 0===i?void 0:i.displayVideoPreviewCta}}" muted playsinline="true" slot="media" poster="${t=>Ta(t)}" preload="${i=>null!=t&&t.enablePreload?"auto":"none"}" src="${t=>t.videoPreviewUrl}" type="video/mp4" @play="${(t,i)=>{var e;return null===(e=i.event)||void 0===e||null===(e=e.target)||void 0===e?void 0:e.setAttribute("is-playing","1")}}" @pause="${(t,i)=>{var e;return null===(e=i.event)||void 0===e||null===(e=e.target)||void 0===e?void 0:e.removeAttribute("is-playing")}}" @error="${()=>t&&w(t.videoId)}" @timeupdate="${t=>{var i;return null===(i=t.previewController)||void 0===i?void 0:i.onTimeUpdate()}}" ${(0,Bo.K)("refVideoElement")}></video>`,t=>null==t?void 0:t.videoId),Sa=t=>Io.qy` ${(0,So.z)(i=>i.shouldRenderInlineVideoPlayer&&t,(t=>Io.qy` ${i=>{var e,o;return(0,Fa.yN)(null===(e=i.config)||void 0===e||null===(e=e.childRefs)||void 0===e?void 0:e.videoCardWC,{memoize:!1,properties:{id:t.videoId,context:{autoplay:!1,posterUrl:Ta(i),disabledControlsByParent:["SeekBack","seekForward","qualityMenuButton","PlayBackSpeedButton","fullscreenToggle"],disableWatchMoreButtonByParent:!0,disableInViewPlayByParent:!0,enablePreviewEventsByParent:!0,eventsCallback:(o=i,(t,i)=>{"ready"===i&&o.setupPreviewControllerForInlinePlayer(),"playing"!==i&&"pause"!==i||!o.previewController||(o.previewController.isVideoPlaying="playing"===i)})},contentVideoPlayerStyleOverrides:ee}})}}
`)(t),Ba(t))}
`,ja=Io.qy`<span class="video-indicator-icon"></span>`,Da=Io.qy`<img alt="" class="icon-invert-color" src="${(0,k.rA)().StaticsUrl}/latest/fluent-icons/play_20_filled.svg">`,Va=Io.qy`<span class="play-indicator">${(0,So.z)(t=>t.ruby,ja,Da)}</span>`,Ra=t=>{var i;return(null===(i=t.previewController)||void 0===i?void 0:i.shouldRenderPreviewBadges)&&"0.5u"!==t.size||t.groupedItem},Ea=Io.qy` ${(0,So.z)(t=>{var i;return(null===(i=t.videoData)||void 0===i?void 0:i.videoDuration)&&Ra(t)},Io.qy`<div class="media-info">${(0,So.z)(t=>!t.groupedItem,Io.qy`<img alt=${t=>t.strings.adChoice} aria-hidden="true" class="icon-invert-color" src="${(0,k.rA)().StaticsUrl}/latest/fluent-icons/clock_12_filled.svg"></img>`)} ${t=>{var i;return null===(i=t.videoData)||void 0===i?void 0:i.videoDuration}}</div>`)}
`,Pa=Io.qy` ${(0,So.z)(t=>Ra(t),Io.qy`<div class="media-info">${t=>{const{previewController:i,strings:e}=t,{videoPreviewableLabel:o="Preview",videoNotPreviewableLabel:a="No preview"}=e;return null!=i&&i.isPreviewable?o:a}}</div>`)}
`,La=Io.qy`<div class="media-info-container">${Ea} ${Pa}</div>`;var Ma=e(50180);const Ua=new Map([[W.QK.local,"whyAmISeeDialogLocalReasonText"],[W.QK.trending,"whyAmISeeDialogTrendingReasonText"],[W.QK.followTopic,"whyAmISeeDialogFollowTopicReasonText"],[W.QK.followPublisher,"whyAmISeeDialogFollowPublisherReasonText"],[W.QK.interacted,"whyAmISeeDialogInteractedReasonText"],[W.QK.breakingNews,"whyAmISeeDialogBreakingNewsReasonText"],[W.QK.explore,"whyAmISeeDialogExploreReasonText"],[W.QK.contentExplore,"waistContentExplore"],[W.QK.u2u,"whyAmISeeDialogU2UReasonText"],[W.QK.cF_U2i,"waistCFU2I"],[W.QK.cF_I2i,"waistCFI2I"],[W.QK.cF_Swing_i2i,"waistCFSwingI2I"],[W.QK.cF_U2u,"waistCFU2U"],[W.QK.cF_Topic_cf,"waistCFTopic"],[W.QK.cF_Cross_domain,"waistCFCrossDomain"],[W.QK.cF_Ip,"waistCFIP"],[W.QK.default,"whyAmISeeDialogDefaultReasonText"],[W.QK.explicitLike,"waistExplicitLike"],[W.QK.userSearchSignal,"waistSearch"],[W.QK.cF_Topic_plus,"waistCFTopicPlus"],[W.QK.trending_in_company,"waistTrendingInCompany"],[W.QK.trending_in_industry,"waistTrendingInIndustry"],[W.QK.trending_in_location,"waistTrendingInLocation"],[W.QK.trending_related_comp,"waistTrendingRelatedComp"],[W.QK.fallback,"waistFallbackReason"]]),Ha=Io.qy`<button class="interact-btn" ${(0,Bo.K)("refInteractBtn")} @click=${t=>t.rubyOverlayController.launchChannelStore()}><img alt="" aria-hidden="true" src="${(0,k.rA)().StaticsUrlWithBuild}ruby-action-icons/manage_interests.svg"></img><span>${t=>t.strings.rubyManageInterestsButtonText}</span></button>`,Oa=Io.qy`<a class="interact-btn" ${(0,Bo.K)("refInteractBtn")} target="_blank" data-t="${t=>t.telemetryTag_anchor}" href="${t=>t.href}"><span>${t=>t.strings.rubyViewStoryButtonText}</span></a>`,Wa=Io.qy`<button ?disabled=${t=>t.disableSubmitButton} class="interact-btn" @click=${t=>{var i,e,o;t.rubyOverlayController.reportAd(null===(i=t.data)||void 0===i?void 0:i.feedbackUrl,null===(e=t.adFeedbackProps)||void 0===e?void 0:e.selectedFeedbackType,null===(o=t.data)||void 0===o?void 0:o.destinationUrl)}}><span>${t=>t.strings.reportAdSubmitButtonText}</span></button>`,Ga=Io.qy`<button class="interact-btn" ${(0,Bo.K)("refInteractBtn")} @click=${t=>{t.rubyOverlayController.dismissHideCard()}}><span>${t=>t.strings.reportAdButtonText}</span></button>`,Na=Io.qy`<button class="action-item" @click=${t=>t.rubyOverlayController.triggerIssueReporting()}><img alt="" aria-hidden="true" src="${(0,k.rA)().StaticsUrl}latest/fluent-icons/flag_20_regular.svg"></img><span>${t=>t.strings.rubyReportAnIssueButtonText}</span></button>`,Ka=Io.qy`<button class="action-item" @click=${t=>t.rubyOverlayController.launchChannelStore()}><img alt="" aria-hidden="true" src="${(0,k.rA)().StaticsUrl}latest/fluent-icons/star_edit_20_regular.svg"></img><span>${t=>t.strings.rubyManageInterestsButtonText}</span></button>`,qa=Io.qy`<button class="action-item" @click=${t=>{var i;return null===(i=t.rubyOverlayController)||void 0===i?void 0:i.undo()}}><img alt="" aria-hidden="true" src="${(0,k.rA)().StaticsUrlWithBuild}ruby-action-icons/undo_fill.svg"></img><span>${t=>t.strings.rubyUndoButtonText}</span></button>`,Xa=Io.qy`<div class="interests-reason"><span class="reason-icon"><img alt="" aria-hidden="true" src="${(0,k.rA)().StaticsUrl}latest/fluent-icons/cursor_click_20_regular.svg"></img></span><span class="reason-text">${t=>((t,i)=>{const{type:e,dynamicValue:o}=i,a=t[Ua.get(e)||""];return e===W.QK.followTopic||W.QK.followPublisher||W.QK.explore?a?(0,Ma.GP)(a,o):t.whyAmISeeDialogDefaultReasonText:a||t.whyAmISeeDialogDefaultReasonText})(t.strings,t.rubyOverlayController.getWhyAmISeeReasons)}</span></div><p class="interests-summary">${t=>t.strings.rubyInterestsSummaryText}</p>`,Ja=Io.qy`<p class="ad-feedback-description">${t=>t.strings.reportAdSuccessbodyText}</p>`,Ya=Io.qy`<fluent-radio-group slot="actions" value="${t=>{var i;return null===(i=t.adFeedbackProps)||void 0===i?void 0:i.selectedFeedbackType}}" @change=${(t,i)=>{var e;return null===(e=t.adFeedbackProps)||void 0===e?void 0:e.chooseFeedbackOption(i.event)}} orientation="vertical" tabindex="0" ${(0,Bo.K)("refInteractBtn")}>${(0,jo.ux)(t=>{var i;return(null===(i=t.adFeedbackProps)||void 0===i?void 0:i.feedbackTypes)??[]},Io.qy`<fluent-radio value=${t=>t.value} id=${t=>t.value} aria-label=${t=>t.text} title=${t=>t.text} class=${(t,i)=>{var e;return(null===(e=i.parent.adFeedbackProps)||void 0===e?void 0:e.selectedFeedbackType)===t.value?"checked":""}}>${t=>t.text}</fluent-radio>`)}</fluent-radio-group>`,Qa={0:Io.qy`${t=>t.strings.rubyLikeTitleText}`,1:Io.qy`${t=>{var i;return(0,Ma.GP)(t.strings.rubyFollowTitleText||"",(null===(i=t.data)||void 0===i||null===(i=i.providerData)||void 0===i?void 0:i.name)||"")}}`,2:Io.qy`${t=>t.strings.rubyDislikeTitleText}`,3:Io.qy`${t=>{var i;return(0,Ma.GP)(t.strings.rubyBlockTitleText||"",(null===(i=t.data)||void 0===i||null===(i=i.providerData)||void 0===i?void 0:i.name)||"")}}`,4:Io.qy`${t=>t.strings.rubyWhyISeeTitleText}`,5:Io.qy`${t=>t.strings.reportAdOverlayTitleText}`,6:Io.qy`${t=>t.strings.reportAdSuccessTitleText}`,7:Io.qy`${t=>t.strings.reportAdSuccessTitleText}`,8:Io.qy`${t=>t.strings.rubySaveTitleText}`},Za={0:Io.qy` ${Ka} ${qa} `,1:Io.qy` ${Ka} ${qa} `,2:Io.qy` ${Na} ${qa} `,3:Io.qy` ${Na} ${qa} `,6:Io.qy` ${qa} `,8:Io.qy` ${Ka} ${qa} `},tn={0:Oa,1:Oa,2:Ha,3:Ha,4:Ha,5:Wa,6:Ga,8:Oa},en=Io.qy`<div class="body"><p class="title" role="heading">${t=>Qa[t.rubyOverlayController.overlayType]}</p>${(0,So.z)(t=>Za[t.rubyOverlayController.overlayType],Io.qy`<div class="actions">${t=>Za[t.rubyOverlayController.overlayType]}</div>`)} ${(0,So.z)(t=>5===t.rubyOverlayController.overlayType,Ya)} ${(0,So.z)(t=>6===t.rubyOverlayController.overlayType,Ja)} ${(0,So.z)(t=>4===t.rubyOverlayController.overlayType,Xa)}<div class="footer-button-container">${t=>tn[t.rubyOverlayController.overlayType]}<button class="close-btn" title=${t=>{var i;return null===(i=t.strings)||void 0===i?void 0:i.rubyCloseOverlayButtonTooltip}} @click=${t=>t.rubyOverlayController.dismissHideCard()}><img alt="" aria-hidden="true" src="${(0,k.rA)().StaticsUrl}/latest/fluent-icons/dismiss_20_regular.svg"></img></button></div></div>`,on=Io.qy`<div class="content-card-container" @contextmenu=${(t,i)=>t.handleContentCardRightClick(t.data,i.event,void 0,t)}><div class="ruby-image-container">${(0,So.z)(t=>t.ruby,Io.qy`<div class="hidden-icon"></div>`,Io.qy`<img src="${()=>{var t;return`${null===(t=(0,k.rA)())||void 0===t?void 0:t.StaticsUrl}latest/fluent-icons/eye_off_36_filled.svg`}}" alt="${t=>t.strings.adHiddenImgPlaceholder}" aria-hidden="true" loading="eager" ${(0,Bo.K)("refCardImage")} />`)}<div class="hidden-text">${t=>t.strings.adHiddenImgPlaceholder}</div></div><div class="body"><div class="text"><div class="heading" title="${t=>t.strings.adHiddenTitle}">${t=>t.strings.adHiddenTitle}</div><div class="abstract" title="${t=>{var i;return t.blockedAdvertiser||7==(null===(i=t.rubyOverlayController)||void 0===i?void 0:i.overlayType)?t.strings.adHiddenDescriptionBlock:t.strings.adHiddenDescription}}">${t=>{var i;return t.blockedAdvertiser||7==(null===(i=t.rubyOverlayController)||void 0===i?void 0:i.overlayType)?t.strings.adHiddenDescriptionBlock:t.strings.adHiddenDescription}}</div></div><div class="action-row"><fluent-button class="undo-button" title="${t=>t.strings.adHiddenUndo}" aria-label="${t=>t.strings.adHiddenUndo}" appearance="stealth" size="small" data-t=${t=>t.telemetryTag_undoHide} @click=${t=>t.rubyOverlayController&&t.rubyOverlayController.undo()}>${(0,So.z)(t=>t.ruby,Io.qy`<div class="undo-icon"></div>`,Io.qy`<img class="undo-icon" src="${()=>{var t;return`${null===(t=(0,k.rA)())||void 0===t?void 0:t.StaticsUrl}latest/fluent-icons/arrow_hook_down_left_16_regular.svg`}}" aria-hidden="true" loading="eager" slot="start" />`)}<div class="undo-text">${t=>t.strings.adHiddenUndo}</div></fluent-button></div></div></div>`;var an;const nn=`${null===(an=(0,k.rA)())||void 0===an?void 0:an.StaticsUrl}latest/fluent-icons/arrow_undo_16_regular.svg`,rn=Io.qy`<button class="hide-button" data-t="${t=>{var i;return null===(i=t.hideCardUndoButton)||void 0===i?void 0:i.telemetry_tag}}" id="undo-button" @click=${t=>{var i,e;return(null===(i=t.hideCardUndoButton)||void 0===i?void 0:i.buttonCallback)&&(null===(e=t.hideCardUndoButton)||void 0===e?void 0:e.buttonCallback())}} role=${t=>"0.5u"!=t.size||t.hideCardType===O.j.spinner?"menuitem":"button"} title=${t=>{var i;return null===(i=t.hideCardUndoButton)||void 0===i?void 0:i.text}}>${t=>{var i;return"0.5u"!=t.size||t.hideCardType===O.j.spinner?null===(i=t.hideCardUndoButton)||void 0===i?void 0:i.text:Io.qy`<img class="undo-icon" src="${nn}"/>`}}</button>`,sn=Io.qy`<div class="body"><span class="hide-message">${t=>t.title}</span><slot name="actions"></slot>${(0,So.z)(t=>t.hideCardButtons&&t.hideCardButtons.length>0,Io.qy`<ul class="hide-menu" role="menu"><li class="hide-list-item" id="hide-item-1"><button class="hide-button" data-t="${t=>{var i;return null===(i=t.hideCardButtons[0])||void 0===i?void 0:i.telemetry_tag}}" id="hide-button1" @click=${t=>{var i;return(null===(i=t.hideCardButtons[0])||void 0===i?void 0:i.buttonCallback)&&t.hideCardButtons[0].buttonCallback()}} role="menuitem" title=${t=>{var i;return null===(i=t.hideCardButtons[0])||void 0===i?void 0:i.text}}>${t=>{var i;return null===(i=t.hideCardButtons[0])||void 0===i?void 0:i.text}}</button></li><li class="hide-list-item" id="hide-item-2"><button class="hide-button" data-t="${t=>{var i;return null===(i=t.hideCardButtons[1])||void 0===i?void 0:i.telemetry_tag}}" id="hide-button2" @click=${t=>{var i;return(null===(i=t.hideCardButtons[1])||void 0===i?void 0:i.buttonCallback)&&t.hideCardButtons[1].buttonCallback()}} role="menuitem" title=${t=>{var i;return null===(i=t.hideCardButtons[1])||void 0===i?void 0:i.text}}>${t=>{var i;return null===(i=t.hideCardButtons[1])||void 0===i?void 0:i.text}}</button></li><li class="hide-list-item" id="hide-item-3"><button class="hide-button" data-t="${t=>{var i;return null===(i=t.hideCardButtons[2])||void 0===i?void 0:i.telemetry_tag}}" id="hide-button3" @click=${t=>{var i;return(null===(i=t.hideCardButtons[2])||void 0===i?void 0:i.buttonCallback)&&t.hideCardButtons[2].buttonCallback()}} role="menuitem" title=${t=>{var i;return null===(i=t.hideCardButtons[2])||void 0===i?void 0:i.text}}>${t=>{var i;return null===(i=t.hideCardButtons[2])||void 0===i?void 0:i.text}}</button></li><li class="hide-list-item" id="hide-item-4">${(0,So.z)(t=>"0.5u"!=t.size||t.hideCardType===O.j.spinner,rn)}</li></ul>`)} ${(0,So.z)(t=>"0.5u"===t.size&&t.hideCardType===O.j.feedback,rn)}</div>`,dn=Io.qy` ${t=>t.hideCardType===O.j.rubyOverlay?en:t.hideCardType===O.j.adHidden?on:sn}
`;var ln=e(42161),hn=e(40221),cn=e(72930);const un="ResponsiveTextTemplate",pn="PATextTemplate",gn="RubyPATextTemplate",bn="TextTemplate";function vn(t){return t.groupedItem||t.watchInarticleAd||!t.adPA&&t.intraArticleBlackCTA?un:t.adPA&&!t.ruby?pn:t.adPA&&t.ruby?gn:bn}var xn;const mn=`${(0,k.rA)().StaticsUrl}latest/common/icons/copilotOutline.svg`,fn=`${null===(xn=(0,k.rA)())||void 0===xn?void 0:xn.StaticsUrl}latest/fluent-icons/info_16_regular.svg`,wn=Io.qy` ${(0,So.z)(t=>t.renderAbstract,Io.qy`<span class="abstract">${(0,So.z)(t=>t.ad,sa,Io.qy`${t=>t.abstract}`)}</span>`)}
`,yn=Io.qy` ${(0,So.z)(t=>{var i;return(null===(i=t.attributionData)||void 0===i?void 0:i.src)&&!t.errorAttributionImage&&!t.rubyRightRailAds},Io.qy`<img alt="${t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.altText}}" aria-hidden="true" class="attribution-image" @error=${t=>t.onAttributionImageError()} src="${t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.src}}"></img>`)} ${(0,So.z)(t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.name},Io.qy`<span class="attribution-text">${t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.name}}</span>`)}
`,$n=Io.qy`<span aria-hidden="true" class="attribution-divider">·</span>`,kn=Io.qy`<div class=${t=>(0,Vo.x)("attribution",["attribution-flip",!!t.enableFlipTitleProvider])}>${yn} ${(0,So.z)(t=>{var i;return!t.disableFollowAction&&(null===(i=t.attributionData)||void 0===i?void 0:i.useFollowingButton)},Io.qy`<slot class="following-button" name="following-button"></slot>`)} ${(0,So.z)(t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.publishedDateTime},Io.qy` ${$n}<span class="attribution-time">${t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.publishedDateTime}}</span>`)} ${(0,So.z)(t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.viewCount},Io.qy` ${$n}<span class="arrow-trending-icon"></span><span class="attribution-view-count">${t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.viewCount}}</span>`)} ${(0,So.z)(t=>(t.ruby&&!t.intraArticleClassic||t.watchInarticleAd||!t.ruby&&t.intraArticleBlackCTA||t.isAdSocialBarEnabled||t.isIntraClassicAd)&&!t.rubyRightRailAds&&!t.watchAdVideo&&t.ad,Io.qy` ${$n}<span class="ad-label-container">${oa}</span>`)} ${(0,So.z)(t=>t.intraArticleBlackCTA&&t.adVA2&&t.ad&&t.hasStandalonePopover,Io.qy` ${$n} ${ia} `)} ${(0,So.z)(t=>t.aiHeading&&t.ruby,Io.qy`<img class="ai-disclaimer-icon" src=${fn}>`)}</div>`,An=Io.qy`<img aria-hidden="true" class="badge-icon" src="${t=>{var i;return null===(i=t.badgeProps)||void 0===i?void 0:i.iconSrc}}"></img>`,zn=Io.qy`<span class="content-indicator"><img aria-hidden="true" src="${(0,k.rA)().StaticsUrl}/latest/views/icons/GalleryIndicator.svg"></img></span>`,Cn=Io.qy`<img alt="${t=>{var i;return t.hasMediaFailed?"":null===(i=t.mediaData)||void 0===i?void 0:i.altText}}" aria-hidden="true" class="media" @error="${t=>t.onMediaError()}" @load="${t=>t.markVisuallyReady()}" ${(0,Bo.K)("refCardImage")} slot="media" src="${t=>{var i;return t.hasMediaFailed?t.errorStateMedia:null===(i=t.mediaData)||void 0===i?void 0:i.src}}"></img>`,Fn=Io.qy` ${(0,So.z)(t=>!t.ruby&&!t.hoverImgZoomRatio||t.companion,Cn,Io.qy`<div class=${t=>t.ruby?"ruby-image-container":"image-container"}>${(0,So.z)(t=>t.adCashback,wa)} ${Cn} ${(0,So.z)(t=>t.ad&&t.watchAdVideo,Io.qy` ${oa} `)} ${(0,So.z)(t=>t.ad&&t.watchAdVideo&&t.callToAction,pa)}</div>`)}
`,_n=Io.qy` ${(0,So.z)(t=>"shorts"!==t.size&&t.canLoadHoverElements&&"video"==t.mediaType,La)}
`,Tn=Io.qy`
${(0,So.z)(t=>{var i;return null===(i=t.badgeProps)||void 0===i?void 0:i.isNonInteractive},Io.qy`<span class="badge-text">${t=>{var i;return null===(i=t.badgeProps)||void 0===i?void 0:i.text}}</span>`,Io.qy`<button aria-label="${t=>{var i;return null===(i=t.data.cardActionsTooltips)||void 0===i?void 0:i.whyAmISee}}" class="badge" @click=${(t,i)=>{var e,o;return(null===(e=t.badgeProps)||void 0===e?void 0:e.onClickBadge)&&(null===(o=t.badgeProps)||void 0===o?void 0:o.onClickBadge(t.data,i.event))}} data-t="${t=>{var i;return null===(i=t.badgeProps)||void 0===i?void 0:i.telemetryTag_badge}}" title="${t=>{var i;return null===(i=t.data.cardActionsTooltips)||void 0===i?void 0:i.whyAmISee}}">${(0,So.z)(t=>{var i;return null===(i=t.badgeProps)||void 0===i?void 0:i.iconSrc},An)}<span class="badge-text">${t=>{var i;return null===(i=t.badgeProps)||void 0===i?void 0:i.text}}</span></button>`)}
`,In=Io.qy`<div class="action-row">${(0,So.z)(t=>t.ad,Aa,Io.qy`<slot class="action-row-start" name="action-row-start"></slot>${(0,So.z)(t=>!t.disableBadge&&void 0!==t.badgeProps,Tn)} `)}</div>`,Bn=Io.qy` ${(0,So.z)(t=>t.enableShortsInlineConsumption&&"shorts"===t.size,Io.qy`<a class="video-inline-consumption-link" data-t="${t=>t.telemetryTag_anchor}" href="${t=>(0,ln.wY)(t.href)}" aria-label="${t=>t.title}"></a>`)}
`,Sn=Io.qy` ${(0,So.z)(t=>"image"===t.mediaType,Fn)} ${(0,So.z)(t=>"video"===t.mediaType,(jn=Fn,Dn=Bn,Io.qy`<div class="video-container" is-playing="${t=>{var i;return null!==(i=t.previewController)&&void 0!==i&&i.isVideoPlaying?"true":"false"}}">${(0,So.z)(t=>t.shouldRenderVideoElement||t.shouldRenderInlineVideoPlayer&&t.videoData,t=>Sa(t.videoData),jn)}<div class="media-overlay">${(0,So.z)(t=>t.enableShortsInlineConsumption&&"shorts"===t.size,Dn,Io.qy` ${(0,So.z)(t=>!t.config.disableVideoIndicator,Va)} ${(0,So.z)(t=>t.config.enableVideoPreviewCta,Ia)} ${(0,So.z)(t=>t.canLoadHoverElements&&!t.immersive||t.groupedItem,La)} `)}</div></div>`))}
`;var jn,Dn;const Vn=Io.qy`<span class="headingPrefix">${t=>t.headingPrefix}</span>`,Rn=Io.qy` ${(0,So.z)(t=>t.headingPrefix,Vn)} ${(0,So.z)(t=>"5_river"===t.adDTSStyleKey,Io.qy`<span class="ad-dts-title">${t=>t.heading}</span>`,Io.qy`${t=>t.heading}`)} ${(0,So.z)(t=>t.ad,Io.qy`${t=>t.logAdDTSLineHeights()}`)} ${(0,So.z)(t=>"5_river"===t.adDTSStyleKey,da)}
`,En=Io.qy` ${(0,So.z)(t=>t.ad,Io.qy`<a class=${t=>(0,Vo.x)("heading",["heading-flip",!!t.enableFlipTitleProvider])} @click=${(t,i)=>t.handleContentCardLinkClick(i.event)} data-t="${t=>t.telemetryTag_anchor}" @focus=${t=>t.handleContentCardLinkFocus()} href="${t=>t.href}" id="heading" aria-label="${t=>t.accessibleLabel}" ${(0,Do.Ib)(!0,!1)} ${(0,Bo.K)("refHeading")} target="${t=>t.target}" custom-context-menu="${t=>{var i;return null===(i=t.config)||void 0===i?void 0:i.enableOverrideRightClick}}">${(0,So.z)(t=>!t.adPA,Rn)}</a>`,Io.qy`<a class=${t=>(0,Vo.x)("heading",["heading-flip",!!t.enableFlipTitleProvider],["heading-content",!!t.disableRichSocialReactions])} @click=${(t,i)=>t.handleContentCardLinkClick(i.event)} data-t="${t=>t.telemetryTag_anchor}" @focus=${t=>t.handleContentCardLinkFocus()} href="${t=>t.href}" ${(0,Bo.K)("refHeading")} id="heading" aria-label="${t=>t.accessibleLabel}" target="${t=>t.target}" custom-context-menu="${t=>{var i;return null===(i=t.config)||void 0===i?void 0:i.enableOverrideRightClick}}">${Rn}</a>`)}
`,Pn=Io.qy` ${(0,So.z)(t=>{var i,e;return(null===(i=t.popoverData)||void 0===i||null===(i=i.data)||void 0===i?void 0:i.text)&&(null===(e=t.popoverData)||void 0===e||null===(e=e.data)||void 0===e?void 0:e.title)},ia)}
`,Ln=Io.qy` ${En} ${(0,So.z)(t=>t.adVA||t.adVA2,wn)} ${(0,So.z)(t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.name},kn)} `,Mn=Io.qy` ${En}<div class="attribution">${yn}</div>`,Un=Io.qy` ${oa} ${En}<div class="attribution">${yn}</div>`,Hn=Io.qy` ${(0,So.z)(t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.name},kn)} ${(0,So.z)(t=>t.rubyRightRailAds,Pn)} ${En} ${wn}
`,On=Io.qy` ${En} ${(0,So.z)(t=>t.rubyRightRailAds,Pn)} ${(0,So.z)(t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.name},kn)} ${wn}
`,Wn=Io.qy` ${(0,So.z)(t=>t.enableFlipTitleProvider,On,Hn)}
`,Gn=Io.qy`<button class="hover-companion-button" @click=${(t,i)=>t.handleCompanionButtonClick&&t.handleCompanionButtonClick(i.event)} data-t="${t=>t.telemetryTag_companion}"><span class="hover-companion-button-icon"><img aria-hidden="true" class="copilot-icon" src="${mn}" /></span><span class="hover-companion-button-text">${t=>t.companionButtonText}</span></button>`,Nn=(t,i,e)=>{if(t.componentType)return(t=>{switch(t){case hn.u.AdChoice:return ta;case hn.u.AdLabel:return oa;case hn.u.MainImage:return Io.qy`${(0,So.z)(t=>t.mediaType&&t.mediaData,Sn)}`;case hn.u.Title:return En;case hn.u.LogoProvider:return Io.qy`${(0,So.z)(t=>{var i;return null===(i=t.attributionData)||void 0===i?void 0:i.name},kn)}`;case hn.u.CallToAction:return Io.qy`${(0,So.z)(t=>t.callToAction||t.defaultCta,na)}`;case hn.u.PopupDisclaimer:return Pn;default:return Io.qy``}})(t.componentType);if(t.children){const o=(0,Vo.x)([i||"",!!i],[t.layoutType?`ad-dts-${t.layoutType.toLowerCase()}`:"",!!t.layoutType],[t.className||"",!!t.className]);return Io.qy`<div class="${o}" style="${e||""}">${t.children.reduce((t,i)=>Io.qy`${t}${Nn(i)}`,Io.qy``)}</div>`}return Io.qy``},Kn=t=>{const i=t.templateId?`ad-dts-tmpl-${t.templateId}`:"";return Nn(t.layout,i,i=>function(t,i){var e;const o=[];var a;if(null!==(e=t.cssVariables)&&void 0!==e&&e.enableBackgroundImage&&o.push(`--ad-dts-bg-img: url(${(null===(a=i.mediaData)||void 0===a?void 0:a.src)||""})`),t.fontSizing&&i.adDTSComponentDataMap){const e=i.adDTSComponentDataMap;t.fontSizing.forEach(t=>{const i=e.get(t.componentType),a=(null==i?void 0:i.text)||"";if(a){const i=(0,cn.Z)(a,t);if(i){const e=t.componentType.toLowerCase();o.push(`--ad-dts-${e}-font-size: ${i.fontSizePx}px`),o.push(`--ad-dts-${e}-line-height: ${i.lineHeightPx}px`),o.push(`--ad-dts-${e}-max-lines: ${i.maxLines}`)}}})}return o}(t,i).join("; "))},qn=Io.qy` ${(0,So.z)(t=>t.shouldUseAdDTSTemplate,Io.qy` ${t=>t.adDTSTemplateConfig?Kn(t.adDTSTemplateConfig):""} `,Io.qy` ${(0,So.z)(t=>t.contentIndicator,zn)} ${(0,So.z)(t=>t.mediaType&&t.mediaData,Sn)}<div class="body">${(0,So.z)(t=>t.immersive,_n)}<div class="text">${(0,So.z)(t=>vn(t)===un,Ln)} ${(0,So.z)(t=>vn(t)===pn,Mn)} ${(0,So.z)(t=>vn(t)===gn,Un)} ${(0,So.z)(t=>vn(t)===bn,Wn)} ${(0,So.z)(t=>t.companion,Gn)}</div>${(0,So.z)(t=>!t.hideActionRow,In)} ${(0,So.z)(t=>{var i;return t.ad&&t.watchAdVideo&&!(null!==(i=t.config)&&void 0!==i&&i.enableAdChoiceInCardActions)},ta)}</div>${(0,So.z)(t=>t.watchInarticleAd||!t.adPA&&t.intraArticleBlackCTA,ua)} `)} ${(0,So.z)(t=>t.ad&&t.adPA,ka)} ${(0,So.z)(t=>t.canLoadHoverElements&&!t.watchAdVideo,Qo)}
`,Xn=Io.qy`<div class="content-card-container" @mouseenter=${t=>t.handleContentCardMouseEnter()} @mouseleave=${t=>t.handleContentCardMouseLeave()}>${qn}</div>`,Jn=Io.qy`<div class="content-card-container" @mouseenter=${t=>t.handleContentCardMouseEnter()} @mouseleave=${t=>t.handleContentCardMouseLeave()} @contextmenu=${(t,i)=>t.handleContentCardRightClick(t.data,i.event,void 0,t)}>${qn}</div>`,Yn=Io.qy` ${(0,So.z)(t=>{var i;return null===(i=t.config)||void 0===i?void 0:i.enableOverrideRightClick},Jn,Xn)}
`,Qn=Io.qy` ${(0,So.z)(t=>null!=t.hideCardType,dn,Yn)}
`,Zn=Io.qy`<div class="loading-container"><div class="loading-media shimmer"></div><div class="loading-attribution loading-text shimmer"></div><div class="loading-heading1 loading-text shimmer"></div><div class="loading-heading2 loading-text shimmer"></div></div>`,tr=Io.qy`<div class="popover-slot" id="${l.r_}" ${(0,Bo.K)("refPopoverSlot")}></div>`,ir=Io.qy`<template data-t=${t=>{var i;return null==t||null===(i=t.telemetryObject_card)||void 0===i?void 0:i.getMetadataTag()}} role=${t=>void 0===(null==t?void 0:t.hideCardType)?"article":"group"}><div class="root">${(0,So.z)(t=>t.loading,Zn,Io.qy` ${(0,So.z)(t=>t.rubyRightRailAds,oa)} ${(0,So.z)(t=>!t.onlyRenderOuterLayer,Qn,Io.qy`<slot></slot>`)} `)}</div>${tr}</template>`;var er=e(88817),or=e(37180),ar=e(121),nr=e(29783);const rr=Y.compose({name:"cs-responsive-card",template:ir,styles:To,shadowOptions:{delegatesFocus:!0}}),sr=()=>{rr.define(o.G.registry)};er.m.define(or.c.registry),ar.m.define(or.c.registry),nr.m.define(or.c.registry)},69904(t,i,e){e.d(i,{Fr(){return c},IH(){return x},Kg(){return o},M_(){return v},Oc(){return g},TF(){return s},YO(){return l},YV(){return r},Z6(){return h},aV(){return d},bc(){return b},kS(){return a},le(){return p},tD(){return n},vr(){return u}});const o="14px",a="12px",n="10px",r="16px",s="20px",d="24px",l="28px",h="20px",c="16px",u="22px",p="24px",g="28px",b="32px",v="600",x="400"},75830(t,i,e){e.d(i,{Lm(){return h},Ly(){return d},cU(){return l}});var o=e(22131),a=e(74849),n=e(58792),r=e(44453),s=e(69904);const d=a.A`
:host([ad-attr-count="0"]:not([wide])) .abstract,
:host([ad-attr-count="1"]:not([wide])) .abstract,
:host([ad-attr-count="2"]:not([wide])) .abstract {
    height: 20px;
}
:host([ad-attr-count="3"]:not([wide])) .abstract,
:host([ad-attr-count="4"]:not([wide])) .abstract {
    height: 40px;
}
:host([ad-attr-count="3"]:not([wide])) .va-attribute,
:host([ad-attr-count="4"]:not([wide])) .va-attribute {
    max-width: 47%;
}
:host([ad-attr-count="0"]) .heading,
:host([ad-attr-count="1"]) .heading,
:host([ad-attr-count="2"]) .heading {
    -webkit-line-clamp: 2;
}
:host([ad-va]) .va-attribute[type]:not([type=price])::before,
:host([ad-va2]) .va-attribute[type]::before {
    background-repeat: round;
    content: " ";
    display: inline-block;
    height: 16px;
    margin-inline-end: 2px;
    vertical-align: text-top;
    width: 16px;
}
:host([immersive]) .va-attribute[type]::before {
    filter: invert(1);
}
:host(:not([immersive])) .working-hour-status {
    color: ${r.j$};
    font-weight: ${s.M_};
}
:host(:not([immersive])) .working-hour-status[open] {
    color: ${r.FU};
    font-weight: ${s.M_};
}
.abstract {
    color: inherit;
    column-gap: 8px;
    display: flex !important;
    flex-wrap: wrap;
    -webkit-line-clamp: 2;
    width: 100%;
}
.heading {
    -webkit-line-clamp: 1;
}
.va-attribute {
    align-items: center;
    display: inline-block;
    font-size: 12px;
    max-width: 100%;
    overflow: hidden;
    pointer-events: none;
    text-overflow: ellipsis;
    vertical-align: top;
    white-space: nowrap;
}
.va-attribute:last-child {
    flex: 1 0 30%;
}
.va-attribute[type=annualFee]::before,
.va-attribute[type=debitCardMontlyServiceFee]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/wallet_16_regular.svg);
}
.va-attribute[type=autoCondition]::before,
.va-attribute[type=bodyStyle]::before,
.va-attribute[type=condition]::before,
.va-attribute[type=trim]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/vehicle_car_16_regular.svg);
}
.va-attribute[type=transmission]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/va/light/transmission.svg);
}
.va-attribute[type=callout]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/megaphone_16_regular.svg);
}
.va-attribute[type=cardCategory]::before,
.va-attribute[type=price]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/money_16_regular.svg);
}
.va-attribute[type=category]::before,
.va-attribute[type=serviceSubCategories]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/book_20_regular.svg);
}
.va-attribute[type=city]::before,
.va-attribute[type=destinationCity]::before,
.va-attribute[type=serviceArea]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/location_16_regular.svg);
}
.va-attribute[type=co2Emissions]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/cloud_16_regular.svg);
}
.va-attribute[type=departureDestinationPort]::before,
.va-attribute[type=port]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/vehicle_ship_16_regular.svg);
}
.va-attribute[type=dealer]::before,
.va-attribute[type=dealerName]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/building_shop_16_regular.svg);
}
.va-attribute[type=debitCardCategory]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/payment_16_regular.svg);
}
.va-attribute[type=doctorClinicCategory]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/doctor_16_regular.svg);
}
.va-attribute[type=duration]::before,
.va-attribute[type=itineraryDays]::before,
.va-attribute[type=workingHours]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/clock_16_regular.svg);
}
.va-attribute[type=fuelEfficiency]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/gas_pump_20_regular.svg);
}
.va-attribute[type=fuelType]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/gas_pump_20_regular.svg);
}
.va-attribute[type=inclusion]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/add_square_20_regular.svg);
}
.va-attribute[type=interiorColor]::before,
.va-attribute[type=exteriorColor]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/paint_bucket_16_regular.svg);
}
.va-attribute[type=languages]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/local_language_16_regular.svg);
}
.va-attribute[type=mileage]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/top_speed_20_regular.svg);
}
.va-attribute[type=placeholder]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/circle_small_16_regular.svg);
}
.va-attribute[type=range]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/battery_charge_20_regular.svg);
}
.va-attribute[type=rating]::before {
    background: linear-gradient(90deg, #EC9E06 var(--percent), gray var(--percent));
    filter: invert(0) !important;
    font-family: Times;
    letter-spacing: 3px;
    line-height: 16px;
    --percent: calc(var(--star-rating) / 5 * 98%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    width: min-content !important;
}
:host(:not([responsive-width])) .va-attribute[type=rating]::before {
    content: "★★★★★" !important;
}
.va-attribute[type=services]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/briefcase_16_regular.svg);
}
.va-attribute[type=specialties]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/ribbon_star_20_regular.svg);
}
.va-attribute[type=toursActivityCategory]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/ticket_diagonal_16_regular.svg);
}
.va-attribute[type=year]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/fluent-icons/calendar_ltr_16_regular.svg);
}
.va-attribute[type=yearsOfExp]::before {
    background: url(${(0,n.rA)().StaticsUrl}/latest/va/light/person-star.svg);
}
.working-hour-status {
    margin-inline-end: 3px;
}
`.withBehaviors((0,o.G2)(a.A`
                :host([ad-va2]) .va-attribute[type]::before {
                    filter: invert(1);
                }
            `)),l=a.A`
    :host([ruby-va]) .heading {
        -webkit-line-clamp: 2;
    }
    :host([ad-attr-count="3"]:not([wide])) .va-attribute,
    :host([ad-attr-count="4"]:not([wide])) .va-attribute {
        max-width: 100%;
    }
    .action-row-sub-container {
        align-items: center;
    }
`,h=a.A`
:host(:not([wide])) .va-attribute {
    max-width: inherit !important;
}
:host([ad-va2][responsive-width]) .va-attribute[type=rating]::before {
    content: "★" !important;
    margin-inline-end: 0px;
}
@container (width < 289px) {
    :host([ad-va2][size="1u"]) .heading {
        font-size: 16px;
        line-height: 20px;
    }
}
@container (width < 288px) {
    :host([ad-va2][size="1u"]) .abstract {
        flex-wrap: nowrap;
        height: 20px;
    }
    .va-attribute:nth-child(2) {
        flex: 1 0 50%;
    }
    .va-attribute:nth-child(3), .va-attribute:nth-child(4) {
        display: none;
    }
    :host([ad-va2][size="1u"]) .heading{
        -webkit-line-clamp: 2;
    }
}
@container (width < 281px) {
    :host([ad-va2][size="1u"]) .heading {
        -webkit-line-clamp: 1;
    }
}
`},83273(t,i,e){var o;e.d(i,{j(){return a}}),function(t){t[t.Like=0]="Like",t[t.Follow=1]="Follow",t[t.Dislike=2]="Dislike",t[t.Block=3]="Block",t[t.WhyISee=4]="WhyISee",t[t.ReportAd=5]="ReportAd",t[t.AdFeedbackDone=6]="AdFeedbackDone",t[t.AdFeedbackDoneWithBlockAdvertiser=7]="AdFeedbackDoneWithBlockAdvertiser",t[t.Save=8]="Save"}(o||(o={}));const a={spinner:"spinner",feedback:"feedback",adFeedback:"ad-feedback",adHidden:"ad-hidden",rubyOverlay:"ruby-overlay"}},88817(t,i,e){e.d(i,{m(){return R}});var o=e(56911),a=e(38493),n=e(60815),r=e(55230),s=e(92011),d=e(56863);class l extends s.L{}class h extends((0,d.dx)(l)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class c extends h{constructor(){super(),this.initialValue="on",this.proxy.setAttribute("type","radio")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}defaultCheckedChanged(){this.$fastController.isConnected&&!this.dirtyChecked&&(this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}connectedCallback(){super.connectedCallback(),this.validate(),"radiogroup"!==this.parentElement?.getAttribute("role")&&null===this.getAttribute("tabindex")&&(this.disabled||this.setAttribute("tabindex","0")),this.checkedAttribute&&(this.dirtyChecked||this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}isInsideRadioGroup(){return null!==this.closest("[role=radiogroup]")}keypressHandler(t){if(t.key!==r.gG)return!0;this.checked||this.readOnly||(this.checked=!0)}clickHandler(t){this.disabled||this.readOnly||this.checked||(this.checked=!0)}}(0,o.Cg)([(0,a.CF)({attribute:"readonly",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],c.prototype,"readOnly",void 0),(0,o.Cg)([n.sH,(0,o.Sn)("design:type",String)],c.prototype,"name",void 0),(0,o.Cg)([n.sH,(0,o.Sn)("design:type",Array)],c.prototype,"defaultSlottedNodes",void 0);var u=e(37180),p=e(74849),g=e(64187),b=e(73477),v=e(60993),x=e(22131),m=e(50882),f=e(48196),w=e(74838),y=e(26920),$=e(43774),k=e(46203),A=e(7896),z=e(48751),C=e(41123),F=e(95239),_=e(14996),T=e(79288);const I=p.A`
    ${(0,g.V)("inline-flex")} :host {
        --input-size: calc((${f.D} / 2) + ${w.vR});
        align-items: center;
        outline: none;
        margin: calc(${w.vR} * 1px) 0;
        ${""} user-select: none;
        position: relative;
        flex-direction: row;
        transition: all 0.2s ease-in-out;
    }

    .control {
        position: relative;
        width: calc(var(--input-size) * 1px);
        height: calc(var(--input-size) * 1px);
        box-sizing: border-box;
        border-radius: 50%;
        border: calc(${y.XA} * 1px) solid ${$.nF};
        background: ${k.le};
        outline: none;
        cursor: pointer;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        font-family: ${A.O};
        color: ${z.l};
        ${""} padding-inline-start: calc(${w.vR} * 2px + 2px);
        margin-inline-end: calc(${w.vR} * 2px + 2px);
        cursor: pointer;
        font-size: ${C.K};
        line-height: ${C.Z};
    }

    .control,
    .checked-indicator {
        flex-shrink: 0;
    }

    .checked-indicator {
        position: absolute;
        top: 5px;
        left: 5px;
        right: 5px;
        bottom: 5px;
        border-radius: 50%;
        display: inline-block;
        background: ${z.l};
        fill: ${z.l};
        opacity: 0;
        pointer-events: none;
    }

    :host(:enabled) .control:hover {
        background: ${k.jM};
        border-color: ${$.vA};
    }

    :host(:enabled) .control:active {
        background: ${k.RS};
        border-color: ${$.p4};
    }

    :host(:${b.N}) .control {
        box-shadow: 0 0 0 2px ${F.p}, 0 0 0 4px ${_.WN};
        border-color: ${_.WN};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${v.Z};
    }

    :host([aria-checked="true"]) .checked-indicator {
        opacity: 1;
    }

    :host([disabled]) {
        opacity: ${T.q};
    }
`.withBehaviors((0,x.mr)(p.A`
            .control {
                forced-color-adjust: none;
                border-color: ${m.A.FieldText};
                background: ${m.A.Field};
            }
            :host(:enabled) .control:hover,
            .control:active {
                border-color: ${m.A.Highlight};
                background: ${m.A.Field};
            }
            :host(:${b.N}) .control {
                border-color: ${m.A.Highlight};
                box-shadow: 0 0 0 2px ${m.A.Field},
                    0 0 0 4px ${m.A.FieldText};
            }
            :host([aria-checked="true"]:${b.N}:enabled) .control {
                border-color: ${m.A.Highlight};
                box-shadow: 0 0 0 2px ${m.A.Field},
                    0 0 0 4px ${m.A.FieldText};
            }
            :host([aria-checked="true"]:enabled) .control:hover,
            .control:active {
                border-color: ${m.A.Highlight};
                background: ${m.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${m.A.Highlight};
                fill: ${m.A.Highlight};
            }
            :host([aria-checked="true"]) .control:hover .checked-indicator {
                background: ${m.A.HighlightText};
                fill: ${m.A.HighlightText};
            }
            :host([disabled]) {
                forced-color-adjust: none;
                opacity: 1;
            }
            :host([disabled]) .label {
                color: ${m.A.GrayText};
            }
            :host([disabled]) .control,
            :host([aria-checked="true"][disabled]) .control:hover,
            .control:active {
                background: ${m.A.Field};
                border-color: ${m.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                fill: ${m.A.GrayText};
                background: ${m.A.GrayText};
            }
        `));var B=e(96950),S=e(82774),j=e(79109),D=e(18893);const V=function(t={}){return B.qy`
        <template
            role="radio"
            aria-checked="${t=>t.checked}"
            aria-required="${t=>t.required}"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            @keypress="${(t,i)=>t.keypressHandler(i.event)}"
            @click="${(t,i)=>t.clickHandler(i.event)}"
        >
            <div part="control" class="control">
                <slot name="checked-indicator">
                    ${(0,D.R)(t.checkedIndicator)}
                </slot>
            </div>
            <label
                part="label"
                class="${t=>["label",!t.defaultSlottedNodes?.length&&"label__hidden"].filter(Boolean).join(" ")}"
            >
                <slot
                    ${(0,S.e)({property:"defaultSlottedNodes",filter:j.g})}
                ></slot>
            </label>
        </template>
    `}({checkedIndicator:B.qy`
        <div part="checked-indicator" class="checked-indicator"></div>
    `}),R=c.compose({name:`${u.c.prefix}-radio`,template:V,styles:I})}}]);