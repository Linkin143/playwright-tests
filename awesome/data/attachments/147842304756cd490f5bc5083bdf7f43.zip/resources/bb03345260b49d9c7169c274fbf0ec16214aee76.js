"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_recipes-sd-card_src_index_ts"],{25314(e,i,t){t.r(i),t.d(i,{RecipesSdCard(){return L},RecipesSdCardStyles(){return se},RecipesSdCardTemplate(){return Q},ToolingInfo(){return re}});var a=t(7574),n=t(4731),s=t(37180),r=t(45899),o=t(44767),l=t(73079),c=t(53755),d=t(91956),h=t(12680),p=t(56911),m=t(74998),u=t(22341),g=t(93552),v=t(38319),b=t(85349);const f="RecipesCard",w="RecipesCard_recipe",y="RecipesCard_seemore",x="RecipesCard_customization",T="RecipesCard_customization_report",C="RecipesCard_customization_hide",k="RecipesCard_customization_moresettings",R="RecipesCard_BowheadPipeline",S="RecipesCard_Customization";var U=t(29658),P=t(39671),$=t(15474);const D={Id:null,Type:"recipe-card",data:'[{"Title":"Make-Ahead Cranberry Sauce","PreperationTime":"30 min","ServingPerRecipe":"2","Rating":"4.5","RatingScale":"5","ReviewCount":"188","Calories":"676","Domain":"www.foodnetwork.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%228a03d8b3e2a54e61c6dc98aa0a986ba7%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.ed63634167eeb77a7bfce6e1654577f4","ThumbnailId":"OSK.ed63634167eeb77a7bfce6e1654577f4","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.foodnetwork.com/recipes/ina-garten/make-ahead-cranberry-sauce-3160641","DisplayName":"Food Network"},{"Title":"The Ultimate Potato Soup Recipe","PreperationTime":"30 min","ServingPerRecipe":"8","Rating":"4.98","RatingScale":"5","ReviewCount":"7","Calories":"521","Domain":"sugarspunrun.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%229030ec38b5ae70711df71d680465269c%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.ff26052e61fc8a72024fd4b53d29c47d","ThumbnailId":"OSK.ff26052e61fc8a72024fd4b53d29c47d","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://sugarspunrun.com/creamy-potato-soup-recipe/","DisplayName":"Sugar Spun Run"},{"Title":"Arancini","Rating":"0","ReviewCount":"0","Calories":"549","Domain":"www.jamieoliver.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%224e425609c043ea522fbaa3d26d9fddc4%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.4c44689e1151c802c5955998fef49e55","ThumbnailId":"OSK.4c44689e1151c802c5955998fef49e55","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.jamieoliver.com/recipes/rice/arancini/","DisplayName":"Jamie Oliver"},{"Title":"Ultimate Slow Cooker Pot Roast","PreperationTime":"8 hr 15 min","ServingPerRecipe":"8","Rating":"4.86","RatingScale":"5","ReviewCount":"344","Calories":"498","Domain":"dinnerthendessert.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%2258a799e3cf5f1360978f4a2ecca44567%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.2917be41dc5158b3dfd9de70a68a29ea","ThumbnailId":"OSK.2917be41dc5158b3dfd9de70a68a29ea","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://dinnerthendessert.com/ultimate-slow-cooker-pot-roast/","DisplayName":"Dinner Then Dessert"},{"Title":"BEST Chicken Salad","PreperationTime":"4 hr 15 min","ServingPerRecipe":"8","Rating":"4.92","RatingScale":"5","ReviewCount":"6","Calories":"360","Domain":"www.daringgourmet.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22644dc0f93ab206b3e98cd3dc637fe29c%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.f18f75d027afa0a8daea76b01c3314f3","ThumbnailId":"OSK.f18f75d027afa0a8daea76b01c3314f3","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.daringgourmet.com/classic-chicken-salad/","DisplayName":"Daring Gourmet"},{"Title":"Candied Yams Recipe","PreperationTime":"40 min","ServingPerRecipe":"6","Rating":"4.42","RatingScale":"5","ReviewCount":"48","Calories":"443","Domain":"www.lovebakesgoodcakes.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22597b08b323cf9890ba96834721503fac%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.935e2a392305c47e5bd1edfbc92520a2","ThumbnailId":"OSK.935e2a392305c47e5bd1edfbc92520a2","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.lovebakesgoodcakes.com/candied-yams-recipe/","DisplayName":"Love Bakes Good Cakes"},{"Title":"Vegan Gluten Free Cupcakes","PreperationTime":"17 min","ServingPerRecipe":"12","Rating":"5","RatingScale":"5","ReviewCount":"7","Calories":"177","Domain":"thebigmansworld.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22eec3abe61e2eae837878e4efc30f3453%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.82059e5b20aee3857abfa5c230be00bd","ThumbnailId":"OSK.82059e5b20aee3857abfa5c230be00bd","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://thebigmansworld.com/vegan-chocolate-cupcakes/","DisplayName":"The Big Man\'s World"},{"Title":"The Best Classic Zucchini Bread Recipe","PreperationTime":"1 hr 5 min","ServingPerRecipe":"12","Rating":"4.97","RatingScale":"5","ReviewCount":"15","Calories":"214","Domain":"www.thewholesomedish.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22fb2e1c1e25b956b0a1183c1c18c1fe1d%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.a36c1e1d702d33f6e46fc9776d9942f7","ThumbnailId":"OSK.a36c1e1d702d33f6e46fc9776d9942f7","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.thewholesomedish.com/the-best-classic-zucchini-bread/","DisplayName":"The Wholesome Dish"},{"Title":"One Pot Chicken Parmesan Pasta","PreperationTime":"30 min","ServingPerRecipe":"6","Rating":"4.61","RatingScale":"5","ReviewCount":"10","Calories":"582","Domain":"www.thechunkychef.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22dac84e545711b27c7564cd2eba21444d%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.3f088cfacd8e3acdf906819587e62003","ThumbnailId":"OSK.3f088cfacd8e3acdf906819587e62003","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.thechunkychef.com/one-pot-chicken-parmesan-pasta/","DisplayName":"The Chunky Chef"}]',DataType:null,Version:1,Previews:null,Badges:null,Metadata:{market:"en-us",language:"en",region:"us"},PreviewsV2:null,IsSkipped:null,PulseData:null,ClusterIds:null,AdditionalNewsContent:[],message:"",BowheadMetadata:{PipelineTag:"TEST"},debugLogs:[]};var O=t(60815),H=t(71398),z=t(58792),I=t(25109);const F=e=>`${(0,z.rA)().StaticsUrl}latest/recipes/${e}`,_=()=>F(`recipes-icon.${(0,I.ud)()?"dark":"light"}.svg`);var N=t(91224),j=t(19359),B=t(35102),K=t(41065);class L extends P.U{constructor(){super(),this.dataType="RecipesSdCard",this.isActionMenuOpen=!1,this.recipes=[],this.seeMoreUrl=new URL('https://www.bing.com/search?q=Popular Recipes&filters=userscenario:"dsb" ForceHighConfRecipe:"true"'),this.childTelemetryObjects={},this.market=(null===m.Rb||void 0===m.Rb?void 0:m.Rb.Locale)??"en-us",this.version="superSDCard",this.pageNumber=0,this.maxRecipeNumber=4}experienceConnected(){try{(0,$.uC)(this.config.cardActionWC)}catch(e){(0,u.c_)(e,g.TQ$,"Failed to load cardActionWc")}try{var e;const i=(null===(e=this.mapperArgs)||void 0===e?void 0:e.cardMetadata)??D;this.loadData(i)}catch(e){(0,u.c_)(e,g.TQ$,"Failed to load cardMetaData",e),this.recipes=null,this.pipelineName=null}this.maxRecipeNumber=this.recipes.length??0,this.dataIsValid(this.recipes)&&(this.setupTelemetryObjects(),this.initSuperSDSetting(),this.loadUI())}getLocalizedPreparationTime(e){if(!e)return"";const i=e.split(" ");if(2===i.length){const e="min"===i[1]?this.strings.minutes:this.strings.hours;return`${i[0]} ${e}`}return`${i[0]} ${this.strings.hours} ${i[2]} ${this.strings.minutes}`}loadData(e){var i;if(!e)return;const t=JSON.parse(e.data);for(let e=0;e<this.maxRecipeNumber;e++){const i=t[e].ClickThroughUrl,a=new URL(i);a.searchParams.has("setmkt")&&this.seeMoreUrl.searchParams.set("setmkt",a.searchParams.get("setmkt")),a.searchParams.has("setlang")&&this.seeMoreUrl.searchParams.set("setlang",a.searchParams.get("setlang")),a.searchParams.has("cc")&&this.seeMoreUrl.searchParams.set("cc",a.searchParams.get("cc")),a.searchParams.has("q")&&this.seeMoreUrl.searchParams.set("q",a.searchParams.get("q")),this.recipes.push({href:a.toString(),thumbnailUrl:this.getRecipeThumbnailUrl(t[e].Thumbnail),thumbnailId:t[e].Thumbnail.ThumbnailId,name:t[e].Title,hasVideo:!1,siteName:t[e].Domain,siteUrl:t[e].Domain,preparationTime:this.getLocalizedPreparationTime(t[e].PreperationTime),calorieContent:t[e].Calories,starRating:t[e].Rating,displayName:t[e].DisplayName})}this.pipelineName=(null===(i=e.BowheadMetadata)||void 0===i?void 0:i.PipelineTag)??R}loadUI(){var e,i,t,a,n,s,r,o;this.cardTelemetryObject?this.cardTelemetryObject.contract=(0,N.u)(this.dataType??"",{type:b.b5.StructuredData,vertical:"Recipe"},{ext:{...null===(t=this.parentTelemetry)||void 0===t||null===(t=t.contract)||void 0===t?void 0:t.ext,...null===(a=this.telemetryObject)||void 0===a||null===(a=a.contract)||void 0===a?void 0:a.ext,recipeList:this.recipes.map(e=>this.getSatoriId(null==e?void 0:e.href)),signature:this.getSatoriId(null===(n=this.recipes[this.pageNumber])||void 0===n?void 0:n.href)}}):this.cardTelemetryObject=(0,j.g)(this.dataType??"",{type:b.b5.StructuredData,vertical:"Recipe"},{ext:{...null===(s=this.parentTelemetry)||void 0===s||null===(s=s.contract)||void 0===s?void 0:s.ext,...null===(r=this.telemetryObject)||void 0===r||null===(r=r.contract)||void 0===r?void 0:r.ext,recipeList:this.recipes.map(e=>this.getSatoriId(null==e?void 0:e.href)),signature:this.getSatoriId(null===(o=this.recipes[this.pageNumber])||void 0===o?void 0:o.href)}});this.sdData={id:this.id,isSpotlightCard:!0,cardSize:"_1x_2y",childTemplateType:"",headerData:{headerLogo:`<img src=${_()} alt="" />`,title:this.strings.title,titleNavigationLink:this.seeMoreUrl.toString(),actionMenuData:{hideCardCallback:this.hideCardCallback.bind(this),moreSettingsPersonalizeCallback:this.moreSettingsCallback.bind(this)},telemetryContext:{headerTelemetryObject:this.getChildTelemetry({name:"header",action:b.EG.Click,behavior:b.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}),headerTitleTelemetryObject:null===(e=this.getChildTelemetry({name:"headertitle",action:b.EG.Click,behavior:b.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}))||void 0===e?void 0:e.getMetadataTag(),headerLogoTelemetryTag:null===(i=this.getChildTelemetry({name:"headerlogo",action:b.EG.Click,behavior:b.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}))||void 0===i?void 0:i.getMetadataTag(),pinTelemetryTag:this.getChildTelemetry({name:"pin",action:b.EG.Click,behavior:b.MS.Pin}),actionMenuTelemetryTag:this.getChildTelemetry({name:"actionmenu",action:b.EG.Click,behavior:b.MS.ContextMenu}),hideCard:this.getChildTelemetry({name:"hidecard",action:b.EG.Click,behavior:b.MS.Hide}),moreSettings:this.getChildTelemetry({name:"moresettings",action:b.EG.Click,behavior:b.MS.More})}},footerData:{footerLink:{text:this.strings.seeMore,navigationUrl:this.seeMoreUrl.toString()},paginationData:{currentPageIndex:this.pageNumber+1,pageCount:this.maxRecipeNumber,onFlipperClick:this.dataPaginationCallback.bind(this),onDotClick:(e,i)=>{this.pageNumber=e,this.loadUI()}},telemetryContext:{footerLink:this.getChildTelemetry({name:"footerlink",action:b.EG.Click,behavior:b.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}),previousFlipper:this.getChildTelemetry({name:"previous",action:b.EG.Click,behavior:b.MS.Paginate}),nextFlipper:this.getChildTelemetry({name:"next",action:b.EG.Click,behavior:b.MS.Paginate})}},contextualFeedbackData:this.wpoMetadata&&this.wpoMetadata.isGA?{cFId:this.wpoMetadata.cfId,cFMetadataType:this.wpoMetadata.cFMetadataType}:null,telemetryContext:{contentCard:this.getChildTelemetry({name:"SuperSDCard"})}}}isHidden(e){return e!=this.pageNumber}setupTelemetryObjects(){var e,i;if(null==this.telemetryObject)return;const t=null===(e=this.parentTelemetry)||void 0===e||null===(e=e.contract)||void 0===e?void 0:e.ext;this.recipesTelemetryObject=(0,j.g)(f,{id:f,type:b.b5.StructuredData},b.MS.View,b.EG.View,{...t,signature:this.getSatoriId(null===(i=this.recipes[this.pageNumber])||void 0===i?void 0:i.href)},{type:b.MJ.Module}),this.wholeCardTelemetryTag=this.recipesTelemetryObject.getMetadataTag();for(let e=0;e<this.maxRecipeNumber;e++)this.recipes[e].telemetryTag=(0,j.g)(w,{id:this.recipes[e].entityId,type:b.b5.StructuredData,headline:this.recipes[e].name},b.MS.Navigate,b.EG.Click,t,{type:b.MJ.ContentCard}).getMetadataTag();this.seeMoreTelemetryTag=(0,j.g)(y,{id:y,type:b.b5.StructuredData,headline:y},b.MS.Navigate,b.EG.Click,t,{type:b.MJ.Footer}).getMetadataTag(),this.actionsMenuTelemetryTag=(0,j.g)(x,{id:x,type:b.b5.StructuredData,headline:x},b.MS.More,b.EG.Click,t,{type:b.MJ.ActionButton}).getMetadataTag(),this.recipesReportTelemetryObject=(0,j.g)(T,{id:T,type:b.b5.StructuredData,headline:T},b.MS.Report,b.EG.Click,t,{type:b.MJ.ActionButton}),this.pipelineTelemetryTag=(0,j.g)(R,{id:R,type:b.b5.StructuredData,headline:this.pipelineName},b.MS.View,b.EG.View,t,{type:b.MJ.ContentCard}).getMetadataTag(),this.customizeTelemetryTag=(0,j.g)(S,{type:b.b5.StructuredData,headline:"More options"},b.MS.More,{ext:t}).getMetadataTag(),this.reportTelemetryTag=this.recipesReportTelemetryObject.getMetadataTag(),this.moreSettingTelemetryTag=(0,j.l)(k,{id:k,type:b.b5.StructuredData,headline:k},b.MS.Navigate,b.EG.Click,b.MJ.ActionButton).getMetadataTag(),this.hideCardTelemetryTags=(0,j.l)(C,{id:C,type:b.b5.StructuredData,headline:C},b.MS.Hide,b.EG.Click,b.MJ.ActionButton).getMetadataTag()}shadowDomPopulated(){try{var e,i;this.cardActionRef=null===(e=this.shadowRoot)||void 0===e||null===(i=e.querySelector)||void 0===i?void 0:i.call(e,"card-action"),this.markVisuallyReadyRaf()}catch(e){(0,u.c_)(e,g.TQ$,"Failed to get cardActionRef")}}getSatoriId(e){var i;return(null===(i=new URLSearchParams(e).get("filters"))||void 0===i||null===(i=i.split(" ")[0])||void 0===i||null===(i=i.split("sid:"))||void 0===i||null===(i=i[1])||void 0===i?void 0:i.slice(1,-1))??""}getExperienceType(){return h.Lz8}getRecipeThumbnailUrl(e){return e&&e.ThumbnailUrl?"https://www.bing.com"+e.ThumbnailUrl:"https://www.bing.com/th?id=empty"}async hideCardCallback(){try{var e;if(await H.d.updateSegmentCardsEnableStatus([{cardType:U.s.RecipesCard,enabled:!1}]))null!==(e=this.mapperArgs)&&void 0!==e&&e.refreshSDCardSection?this.mapperArgs.refreshSDCardSection():this.$emit("refreshSDCardSection")}catch(e){(0,u.c_)(e,g.fKW,"Failed to call pdp service to hide card")}}moreSettingsCallback(){var e;null!==(e=this.mapperArgs)&&void 0!==e&&e.goToPersonalizeSettingsCallback?this.mapperArgs.goToPersonalizeSettingsCallback():this.$emit("goToPersonalizeSettingsCallback")}initSuperSDSetting(){const e={moreSetting:{title:this.strings.moreSettings,telemetryTag:this.moreSettingTelemetryTag},hideSetting:{title:this.strings.hideCard,telemetryTag:this.hideCardTelemetryTags}};this.superSDSetting=new v.t(L,U.s.RecipesCard,e,this.goToPersonalizeSettingsCallback,this.refreshSDCardSection)}getChildTelemetry(e){var i,t,a;null!==(i=this.childTelemetryObjects)&&void 0!==i&&i[e.name]?this.childTelemetryObjects[e.name].contract=(0,B.C)(null==e?void 0:e.name,null==e?void 0:e.behavior,null==e?void 0:e.action,{...null===(t=this.cardTelemetryObject)||void 0===t||null===(t=t.contract)||void 0===t?void 0:t.ext,...e.ext},{destinationUrl:null==e?void 0:e.destinationUrl}):this.childTelemetryObjects[e.name]=(0,K.u)(null==e?void 0:e.name,null==e?void 0:e.behavior,null==e?void 0:e.action,{...null===(a=this.cardTelemetryObject)||void 0===a||null===(a=a.contract)||void 0===a?void 0:a.ext,...e.ext},{destinationUrl:null==e?void 0:e.destinationUrl});return this.childTelemetryObjects[e.name]}dataPaginationCallback(e){const i=this.recipes.length||1,t=(this.pageNumber+(e?1:-1)+i)%i;this.pageNumber=t,this.loadUI()}handleNext(){this.pageNumber=(this.pageNumber+1)%this.maxRecipeNumber,this.currentPage=this.recipes[this.pageNumber]}handlePrev(){this.pageNumber=(this.pageNumber+this.maxRecipeNumber-1)%this.maxRecipeNumber,this.currentPage=this.recipes[this.pageNumber]}dataIsValid(e){if(!Array.isArray(e)||e.length<this.maxRecipeNumber)return!1;for(const i of e)if(!i.href||!i.name)return!1;return e.length>=0}}(0,p.Cg)([O.sH],L.prototype,"isActionMenuOpen",void 0),(0,p.Cg)([O.sH],L.prototype,"actionMenuItems",void 0),(0,p.Cg)([O.sH],L.prototype,"superSDSetting",void 0),(0,p.Cg)([O.sH],L.prototype,"sdData",void 0),(0,p.Cg)([O.sH],L.prototype,"customizeTelemetryTag",void 0),(0,p.Cg)([O.sH],L.prototype,"reportTelemetryTag",void 0),(0,p.Cg)([O.sH],L.prototype,"moreSettingTelemetryTag",void 0),(0,p.Cg)([O.sH],L.prototype,"hideCardTelemetryTags",void 0),(0,p.Cg)([O.sH],L.prototype,"pageNumber",void 0),(0,p.Cg)([O.sH],L.prototype,"currentPage",void 0);var V=t(96950),q=t(39957),M=t(69259);const E=V.qy` ${(0,q.ux)(e=>e.recipes.slice(e.pageNumber,e.pageNumber+1),V.qy`<div class="recipe_supersd_content"><a class="recipe" href="${e=>e.href}" target="_blank" @click=${(e,i)=>i.parent.handleClickCard(i.event)} data-t="${e=>e.telemetryTag}"><div class="${e=>e.hasVideo?"video":""}"><img src="${e=>e.thumbnailUrl}" alt="${e=>e.name}" height=126px width=268px /></div><div class="metadata"><div class="site">${e=>e.displayName||e.siteName}</div><div class="name" title=${e=>e.name}>${e=>e.name}</div><div class="recipe-info">${(0,M.z)(e=>e.starRating,V.qy`<div class="rating"><img class="star-icon" src="${`${(0,z.rA)().StaticsUrl}latest/fluent-icons/star_16_filled.svg`}" alt="Star Icon"/><div>${e=>Number.isInteger(Number(e.starRating))?Number(e.starRating).toFixed(1):e.starRating}</div></div>`)} ${(0,M.z)(e=>e.calorieContent||e.preparationTime,V.qy`<div class="recipe-details">${(0,M.z)(e=>e.preparationTime,V.qy`<div class="preparation-time">${e=>e.preparationTime}</div>`)} ${(0,M.z)(e=>e.calorieContent&&e.preparationTime,V.qy`<div class="dot">·</div>`)} ${(0,M.z)(e=>e.calorieContent,V.qy`<div class="nutritional-value">${(e,i)=>{var t;return`${e.calorieContent} ${(null===(t=i.parent.strings)||void 0===t?void 0:t.calorieUnit)||"cals"}`}}</div>`)}</div>`)}</div></div></a></div>`)}
`,W=V.qy`<responsive-sd-card :data="${e=>e.sdData}" data-t=""><div class="container" slot="card-content">${E}</div></responsive-sd-card>`,Q=V.qy`<div class="root" data-t="${e=>e.wholeCardTelemetryTag}">${W}</div>`;var X=t(57416),A=t(64003),G=t(48751),Z=t(86856),J=t(74849),Y=t(22131),ee=t(4968);const ie=J.A`
    .star-icon{
        --invertStarIcon: 64.84%; // #adadad
    }
`,te=J.A`
    .star-icon{
        --invertStarIcon: 14.2%; // #242424
    }
`,ae=J.A` .more-options{right:10px}.v2 .more-options{right:16px}`,ne=J.A` .more-options{left:10px}.v2 .more-options{right:16px}`,se=J.A`
:host{border-radius:calc(${X.JU} * 1px);font-family:"Segoe UI";font-size:12px;line-height:16px}@media (prefers-color-scheme:light){.v1,.v2{h5,.site,.disclaimer{color:${A.c}}.name{color:${G.l}}}.root.rootv2{background:linear-gradient(144.59deg,rgba(200,220,243,0.1) 0%,rgba(200,220,243,0.4) 88.78%)}}@media (prefers-color-scheme:dark){.v1,.v2{.site,.disclaimer{color:${A.c}}h5,.name{color:${G.l}}}.root.rootv2{background:linear-gradient(122.3deg,rgba(28,46,68,0.4) 0%,rgba(28,46,68,0.8) 84.48%)}}h5{margin:0;margin-bottom:24px;padding:0;height:16px;font-size:12px}a{text-decoration:none}.recipe{margin:16px 0;height:90px;display:flex;column-gap:12px}img{object-fit:cover;border-radius:calc(${X.JU} * 1px);
}

.video {
    position: relative;
}

.video::after {
    content: ' ';
    position: absolute;
    top: 4px;
    left: 4px;
    height: 20px;
    width: 20px;
    z-index: 1;
    background-size: 20px 20px;
    background-image: url('data:image/svg+xml;charset=UTF-8,<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="black" fill-opacity="0.5"/><path d="M7.5 12.9694V7.03063C7.50001 6.89073 7.53762 6.7534 7.60888 6.63301C7.68014 6.51262 7.78245 6.4136 7.9051 6.34629C8.02774 6.27898 8.16622 6.24587 8.30605 6.25041C8.44587 6.25495 8.58191 6.29699 8.69993 6.37211L13.3657 9.34148C13.4766 9.41199 13.5678 9.50932 13.631 9.62446C13.6943 9.7396 13.7274 9.86884 13.7274 10.0002C13.7274 10.1316 13.6943 10.2608 13.631 10.3759C13.5678 10.4911 13.4766 10.5884 13.3657 10.6589L8.69993 13.6279C8.58191 13.703 8.44587 13.745 8.30605 13.7496C8.16622 13.7541 8.02774 13.721 7.9051 13.6537C7.78245 13.5864 7.68014 13.4874 7.60888 13.367C7.53762 13.2466 7.50001 13.1093 7.5 12.9694Z" fill="white"/></svg>');
}

.metadata {
    min-width: 0;
}

.v2 .site {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.v1 .name,
.v2 .name {
    margin: 4px 0;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}

.recipes-footer {
    display: flex;
    justify-content: center;
}

.sd-action {
    border-radius: 20px;
    height: 24px;
    font-size: 12px;
}

.toggle-button {
    position: absolute;
    top: 12px;
    right: 10px;
    --control-corner-radius: 16;
    min-width: 24px;
    width: 24px;
    height: 24px;
    z-index: 1;
}

.more-options {
    position: absolute;
    top: 12px;
    --control-corner-radius: 16;
    min-width: 24px;
    width: 24px;
    height: 24px;
    z-index: 1;
}

msn-actions-menu {
    z-index: 700;
}

.rootV2 {
    user-select: none;
    padding: 16px 16px 12px;
    background: linear-gradient(144.59deg, rgba(200, 220, 243, 0.1) 0%, rgba(200, 220, 243, 0.4) 88.78%);
}

.v2 {
    height: 276px;
}

.v2 h5 {
    margin: 0;
    margin-bottom: 8px;
    padding: 0;
    height: 16px;
    font-size: 12px;
}

.v2 a {
    text-decoration: none;
}

.v2 a:hover .name {
    text-decoration: underline;
}

.v2 .recipe {
    height: 90px;
    display: initial;
}

.v2 img {
    object-fit: cover;
    border-radius: calc(${X.JU} * 1px);
}

.v2 .video {
    position: relative;
}

.v2 .video::after {
    content: ' ';
    position: absolute;
    top: 42px;
    left: 114px;
    height: 40px;
    width: 40px;
    z-index: 1;
    background-size: 40px 40px;
    background-image: url('data:image/svg+xml;charset=UTF-8,<svg width="40" height="40" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="black" fill-opacity="0.5"/><path d="M7.5 12.9694V7.03063C7.50001 6.89073 7.53762 6.7534 7.60888 6.63301C7.68014 6.51262 7.78245 6.4136 7.9051 6.34629C8.02774 6.27898 8.16622 6.24587 8.30605 6.25041C8.44587 6.25495 8.58191 6.29699 8.69993 6.37211L13.3657 9.34148C13.4766 9.41199 13.5678 9.50932 13.631 9.62446C13.6943 9.7396 13.7274 9.86884 13.7274 10.0002C13.7274 10.1316 13.6943 10.2608 13.631 10.3759C13.5678 10.4911 13.4766 10.5884 13.3657 10.6589L8.69993 13.6279C8.58191 13.703 8.44587 13.745 8.30605 13.7496C8.16622 13.7541 8.02774 13.721 7.9051 13.6537C7.78245 13.5864 7.68014 13.4874 7.60888 13.367C7.53762 13.2466 7.50001 13.1093 7.5 12.9694Z" fill="white"/></svg>');
}

.v2 .metadata {
    min-width: 0;
    margin-top: 12px;
}

.v2 .site {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.v2 .name {
    margin: 4px 0;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}

.v2 .recipes-footer {
    position: absolute;
    bottom: 12px;
    display: flex;
    justify-content: space-between;
    width: 268px;
    height: 24px;
    line-height: 24px;
}

.v2 .recipes-footer .button {
    width: 24px;
    height: 24px;
    border-radius: 1000px;
}

.prev-button, .next-button {
    background: #00000012;
    float: left;
}

.v2 .prev-button svg {
    margin: 8px 10px 8px 9px;
}

.v2 .next-button svg {
    margin: 8px 9px 8px 10px;
}

.v2 .page-number {
    margin: 0 8px;
    float: left;
}

.v2 .sd-action {
    border-radius: 20px;
    height: 24px;
    font-size: 12px;
    background-color: transparent;
}

.v2 .see-more-text {
    float: left;
}

.v2 .recipes-footer .see-more-button {
    float: right;
    margin-left: 8px;
    background: #0078D4;
}

.v2 .recipes-footer .see-more-button svg {
    margin: 8px 7px;
}

.recipe_supersd_content {
    position: absolute;
    width: 268px;
    ${ee.f} .recipe{display:flex;flex-direction:column;row-gap:16px;margin:0;height:auto;.metadata{color:${G.l};display:flex;flex-direction:column;row-gap:6px;.name{overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:1;white-space:nowrap;font-size:14px;font-style:normal;font-weight:600;line-height:20px}.recipe-info{display:flex;column-gap:8px;align-items:center;font-size:12px;color:var(--color-neutral-foreground-3);font-family:"Segoe UI";.rating{display:flex;justify-content:space-between;height:24px;padding:0px 6px 0px 4px;align-items:center;gap:2px;background-color:var(--color-neutral-background-2);border-radius:4px;font-weight:600;.star-icon{filter:invert(var(--invertStarIcon,0))}}.recipe-details{display:flex;align-items:center;column-gap:4px;font-style:normal;font-weight:400}}}}}`.withBehaviors((0,Y.G2)(ie),(0,Y.C7)(te),new Z.t(ae,ne)),re={experienceConfigSchema:undefined},oe=h.Lz8;d.p&&c.L.registerExperience(oe,()=>Promise.resolve().then(t.bind(t,25314))),n.m.define(s.c.registry),r.m.define(s.c.registry),o.m.define(s.c.registry),l.m.define(s.c.registry),(0,a.d)()}}]);