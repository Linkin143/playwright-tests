// © Microsoft Corporation. All rights reserved.
/* eslint-disable complexity */
import "./stylex.css";
// @ts-ignore TS2882
import "@msnews/ssr-util/install-element-hydration";
import "./bundler";
import { ConnectorNamespaces_MilestoneData, ConnectorNamespaces_SmartListSharedData, ConnectorNamespaces_ExperienceTrackerHomePageData, ConnectorNamespaces_NurturingPlacementManager, ConnectorNamespaces_TopicData } from "@msnews/experiences-constants";
import { clientInitSpan, DefaultLogger, HomePageEntryPointHomePageErrorPage, logException, perfMarker, setLogger, tryGetPerfTimeline, tryGetPerfTimelineImpl, setEntityMetricCorePivotFieldValue, getPageTimings, getWebVitalsPageTimings, waitForTtvr } from "@msnews/diagnostics";
import { RequestContext, appEnvironment, getContextData, headData, initializePublicPath, localStorageExists, resolver, sessionStorageExists, trackWebWorkerErrors, CreateServerDebugInfo, getAppEnvironment, SettablePromise } from "@msnews/core";
import { initSharedStateConnector } from "@msnews/experiences-shared-state";
import { MilestoneDataConnector, MilestoneDataReducer, waitForAboveTheFoldVisuallyReadyAsync } from "@msnews/milestone-data";
import { TrackingSystemType } from "@msnews/telemetry-contracts";
import { getScope, resolveServiceWorker } from "@msnews/service-worker-window";
import { SmartListSharedDataConnector, SmartListSharedDataReducer } from "@msnews/smartlist-shared-data";
import { Telemetry } from "@msnews/telemetry-contracts";
import { setupPageTelemetry, setupTelemetryUpdateCallbacksOnAppStateChange } from "./HomePageTelemetry";
import { ConfigProcessor } from "@msnews/config-validator";
import { CookieConsentStatus } from "@msnews/cookie-contracts";
import { ExperienceTrackerHomePageDataConnector } from "@msnews/experience-tracker-homepage";
import { ExperienceTrackerReducer } from "@msnews/experience-tracker-common";
import { HomePageConfigValidator } from "./HomePageConfigValidator";
import { HomePageTelemetry } from "./HomePageTelemetry";
import { CookieManagementStateKey, cookieManagementState, initCookieManagementState, enableHttp3ForCookie } from "@msnews/cookie-utils";
import { PageBase } from "@msnews/experiences-page-base-wc";
import { direction } from "@cs-core/design-system";
import { resolveHydrationPromises, setHydrationPromiseMap, setHydrationTimeTrackingComponents, setMetaTagFromName, setMetaTagFromProperty } from "@msnews/experiences-base";
import { getTelemetryLoginState, logAppAnonFetchError, tryInitiateEarlyAuth, initAuth, updateAuthState } from "@msnews/auth";
import { getRootConfigRef } from "@msnews/web-worker-shared-utils";
import { initExperienceDiagnostics } from "@msnews/entry-point-shared-utils";
import { DesignToken } from "@cs-core/foundation";
import { adbService } from "@msnews/ad-inspector";
import { createDefaultDOMPolicy } from "@msnews/fast-msft-web-components";
import * as perfConfig from "./perf.config.json";
import { initAppState } from "@msnews/windows-shared";
import { initializeWebVitals } from "@msnews/diagnostics-web-vitals-loader";
import { loadWebComponentExperience } from "@msnews/experiences-web-component-loader";
import { adPageMetadataHub, getLocalStorage } from "@msnews/fundamentals";
import { homepageFeedManager } from "./utils/HomepageFeedManager";
import { insertManifestHeader } from "./utils/pwa";
import { getAdMetadata } from "./utils/adMetadata";
import { isResponseCached, sendPageViewIfNoLitePV } from "@msnews/lite-telemetry";
import { NurturingPlacementManagerConnector } from "@msnews/nurturing-placement-manager-connector";
import { renderRootElement } from "@msnews/page-start-shared-utils";
import { IsomorphicStorage } from "@msnews/isomorphic-util";
import { patchWCDefine, setSSRCompleteStatus, setSSREnabledStatus, waitForCanRender, preloadBundles, setupRenderModeIndicator } from "@msnews/ssr-util";
import { hydrationSubscribableComponents, hydrationTimeTrackingComponents } from "./ssr/utils/experiencesRef";
import { isMyFeedPageByUrl, fetchAndStoreMainFeed } from "@msnews/entry-point-hp-wc";
import { startAdPredictions } from "@msnews/super-feed";
import { desktopTrackConfig } from "./telemetry";
import { setupBreakpoint } from "./breakpoints";
import { startFasterHydrationAds } from "./utils/ads";
import { prefetchViewsCoreBundles } from "./utils/prefetchUtils";
if (window.isSSREnabled) {
    patchWCDefine();
}
const { end: clientInitEnd } = clientInitSpan();
const requestContext = new RequestContext();
const locationHref = getContextData(requestContext.data.locationHref, "locationHref");
initializePublicPath();
setLogger(new DefaultLogger(locationHref));
initExperienceDiagnostics(locationHref, tryGetPerfTimelineImpl, headData, appEnvironment.CurrentRequestTargetScope, perfConfig);
/**
 * use the mock configurations
 * only effective for local development
 */
// import "./mockConfigs";
const perfTimeline = tryGetPerfTimeline("entryPoint", "entryPoint");
const initEndMeasure = perfTimeline && perfTimeline.startMeasure("init").endMeasure;
const initPage = async () => {
    try {
        DesignToken.registerDefaultStyleTarget();
        direction.withDefault(document.dir);
        createDefaultDOMPolicy();
        const pageExperiments = appEnvironment.CurrentRequestTargetScope && appEnvironment.CurrentRequestTargetScope.pageExperiments || [];
        /**
        * NOTE: important!
        * app_anon: for canvas without meControl
        * anon: for canvas with meControl
        * reference doc: https://msasg.visualstudio.com/ContentServices/_wiki/wikis/News%20OneService%20Wiki/101672/Types-of-Cookies-and-Tickets
        */
        initAppState();
        initAuth();
        // Initialize telemetry
        const hydrationPromise = new SettablePromise();
        IsomorphicStorage.set("__hydrationPromise__" /* IsomorphicStorageKeys.HydrationPromise */, hydrationPromise);
        window.dispatchEvent(new CustomEvent("HydrationPromiseCreated"));
        // Initialize telemetry
        setupPageTelemetry(locationHref, requestContext, pageExperiments, window.isSSREnabled ? hydrationPromise.getResultAsync() : null);
        // Add listener for web worker errors
        trackWebWorkerErrors(Telemetry.sendAppErrorEvent.bind(Telemetry));
        // Get an instance of the SPA PageBase for this app
        const app = PageBase.getInstance();
        // Initialize cookie management state
        initCookieManagementState();
        enableHttp3ForCookie(pageExperiments, appEnvironment.IsChinaCompliance, "prg-hp-afdh3t", "prg-hp-afdh3c");
        // Create an instance of the Experiences shared state data connector
        const experienceSharedStateConnector = initSharedStateConnector(app.rootReducer, app.store, requestContext);
        const isFeedView = !pageExperiments.includes("prg-hp-fvrf");
        if (isFeedView && !pageExperiments.includes("prg-hp-rmtdc")) {
            // Register an instance of the Topic shared state data connector
            try {
                const { TopicDataConnector, TopicDataReducer } = await import("@msnews/topics-shared-state");
                new TopicDataConnector(ConnectorNamespaces_TopicData, "", app.rootReducer, new TopicDataReducer(), app.store, undefined, requestContext);
            }
            catch (e) {
                logException(e, HomePageEntryPointHomePageErrorPage, "Error during TopicDataConnector initialization");
            }
        }
        // Register an instance of the Milestone shared state data connector
        new MilestoneDataConnector(ConnectorNamespaces_MilestoneData, "", app.rootReducer, new MilestoneDataReducer(), app.store, undefined, requestContext);
        // Create smartListSharedDataConnector for me-stripe flyout
        const smartListSharedDataConnector = new SmartListSharedDataConnector(ConnectorNamespaces_SmartListSharedData, "", app.rootReducer, new SmartListSharedDataReducer(), app.store, undefined, requestContext);
        tryInitiateEarlyAuth();
        // Start the App (only after all the base data connectors are initialized, otherwise it won't work)
        app.start();
        // Registers config validator for Homepage.
        ConfigProcessor.registerAppValidator(new HomePageConfigValidator());
        perfMarker.singleMark("EntryPointHpWCConfig-start");
        // Send sendAppErrorEvent as callback to resolver since Core cannot depend on Telemetry repo.
        resolver.initialize(Telemetry.sendAppErrorEvent.bind(Telemetry));
        // Init the homepage feed manager to see if users choose to show the feed view or not.
        homepageFeedManager.init();
        // Fetch the experience configuration for the entry point. Because this is a top level page experience, it is responsible for fetching
        // the initial config document
        const appConfig = await resolver.getConfig(getRootConfigRef());
        // Validate the config document
        let entryPointConfigRef;
        let entryPointConfig;
        // check for waterfall mode
        if (appConfig.properties.childExperiences?.entryPointHpWaterfall && homepageFeedManager.isFeedView(true)) {
            entryPointConfigRef = appConfig.properties.childExperiences?.entryPointHpWaterfall?.configRef;
            entryPointConfig = (await resolver.getConfig(entryPointConfigRef)).properties;
        }
        else {
            entryPointConfigRef = appConfig.properties.rootExperience.configRef;
            entryPointConfig = (await resolver.getConfig(entryPointConfigRef)).properties;
        }
        const isWaterfallDep = entryPointConfig.enableWaterfallViewFeed;
        const disableFeed = entryPointConfig.disableFeed;
        perfMarker.singleMark("EntryPointHpWCConfig-end");
        // Create an instance of the experienceTrackerConnector
        const experienceTrackerConnector = new ExperienceTrackerHomePageDataConnector(ConnectorNamespaces_ExperienceTrackerHomePageData, "", app.rootReducer, new ExperienceTrackerReducer(), app.store, undefined, requestContext);
        experienceTrackerConnector.initialize({
            isWaterfallDep,
            disableFeed
        });
        // Initialize Telemetry
        const telemetryProperties = HomePageTelemetry.getTelemetryProperties(window, desktopTrackConfig, locationHref, isWaterfallDep);
        if (!telemetryProperties.enable) {
            Telemetry.disableTrackingSystem(TrackingSystemType.All);
        }
        const cookieConsentStatus = cookieManagementState.get(CookieManagementStateKey.CookieConsentStatus);
        if (cookieConsentStatus !== CookieConsentStatus.NotRequired) {
            Telemetry.disableTrackingSystem(TrackingSystemType.Comscore);
        }
        let static_page = false;
        if (headData && headData.ClientSettings) {
            const clientSettings = headData.ClientSettings;
            static_page = clientSettings.static_page === "true";
        }
        setupBreakpoint(entryPointConfig);
        const nurturingPlacementManagerConfig = entryPointConfig.dataConnectorConfigInfo?.nurturingPlacementManager;
        if (nurturingPlacementManagerConfig) {
            // fetch the nurturing banner config
            await resolver.getConfig(nurturingPlacementManagerConfig.configRef).then(config => {
                if (!config || !config.properties) {
                    return;
                }
                new NurturingPlacementManagerConnector(ConnectorNamespaces_NurturingPlacementManager, config.properties);
            });
        }
        // Setup listeners for changes in AppState
        setupTelemetryUpdateCallbacksOnAppStateChange();
        if (isWaterfallDep && isMyFeedPageByUrl() && !disableFeed) {
            if (window.isSSREnabled) {
                // If isSSREnabled, must wait for SSR streaming complete before calling `fetchAndStoreMainFeed`.
                waitForCanRender().then(() => fetchAndStoreMainFeed());
            }
            else {
                fetchAndStoreMainFeed();
            }
            if (entryPointConfig.enableAdPrediction) {
                // Start ad prediction for the feed
                startAdPredictions(resolver, null, isWaterfallDep);
            }
        }
        const pageTelemetryContract = HomePageTelemetry.getPageTelemetryContract(telemetryProperties, telemetryProperties.isStaticPage, false, locationHref);
        // Set custom property to investigate MUID mismatch\Auth\Market issues.
        const serverDebugInfo = CreateServerDebugInfo();
        Telemetry.addOrUpdateCustomProperty("server-debug-info", serverDebugInfo);
        Telemetry.updatePageMetadata(pageTelemetryContract);
        // Update telemetry with user sign in state
        const user = await getTelemetryLoginState();
        Telemetry.updatePageMetadata({ user }, true);
        // Make appanon call when assuming Edge Identity
        const signInStatus = (user && user.loginState !== "NA")
            ? 2 /* SignedInStatus.SignedIn */ : 0 /* SignedInStatus.Unknown */;
        updateAuthState(logAppAnonFetchError, signInStatus, true);
        const originalUrl = appEnvironment?.HostPage?.originalUrl.split("?")[0];
        const documentTitle = entryPointConfig.localizedStrings?.initialPageTitle || entryPointConfig.initialPageTitle || "MSN";
        const description = entryPointConfig.localizedStrings?.initialPageDescription || entryPointConfig.description || "Your customizable and curated collection of the best in trusted news.";
        const contentImageUrl = entryPointConfig.contentImageUrl || `${getAppEnvironment().StaticsUrl}/latest/homepage/msn-logo.svg`;
        document.title = documentTitle;
        setMetaTagFromProperty("sharing_url", originalUrl);
        setMetaTagFromProperty("og:url", originalUrl);
        setMetaTagFromProperty("og:title", documentTitle);
        setMetaTagFromProperty("twitter:card", "summary_large_image");
        setMetaTagFromProperty("og:type", "website");
        setMetaTagFromProperty("og:site_name", "MSN");
        setMetaTagFromProperty("og:image", contentImageUrl);
        setMetaTagFromName("robots", "index, follow");
        setMetaTagFromName("description", description);
        // Initialize appEnvironment.TrackInfo
        appEnvironment.TrackInfo = {
            sitePage: {
                page_product: "prime",
                page_type: headData.ClientSettings.pagetype
            }
        };
        // resolve service worker config and register/unregister accordingly
        if (!window.location.host.startsWith("localhost")) {
            resolveServiceWorker("/homepage/service-worker.js", entryPointConfig.serviceWorker, getScope(0), false, () => { });
            if (pageExperiments.includes("prg-hp-pwa")) {
                insertManifestHeader(appEnvironment.CurrentMarket);
            }
        }
        // end the 'init' measure here before we construct the connector. This will measure the total initialization cost
        // of the page before the main EntryPoint connector is created. The perf timeline will continue to get tracked from
        // within the EntryPoint connector itself.
        if (initEndMeasure) {
            initEndMeasure();
        }
        // add device memory, hardware concurrency and connection type to telemetry
        if (window && window.navigator) {
            const navigator = window.navigator;
            // @ts-ignore
            navigator.deviceMemory && Telemetry.addOrUpdateTmplProperty("edge.mem", navigator.deviceMemory + "");
            navigator.hardwareConcurrency && Telemetry.addOrUpdateTmplProperty("edge.concurrency", navigator.hardwareConcurrency + "");
            // @ts-ignore
            navigator.connection && navigator.connection.effectiveType && Telemetry.addOrUpdateTmplProperty("edge.connection", navigator.connection.effectiveType + "");
        }
        if (document.visibilityState) {
            Telemetry.addOrUpdateTmplProperty("pageVis", document.visibilityState);
        }
        // Create the EntryPoint connector, and get the connected experience
        const entryPointInitialProps = {
            experienceTrackerNamespace: ConnectorNamespaces_ExperienceTrackerHomePageData
        };
        if (appConfig.properties.childExperiences?.entryPointHpWaterfall && getLocalStorage()?.supported) {
            entryPointInitialProps.feedView = {
                shouldReturnToClassic: homepageFeedManager.isFeedView(true) !== homepageFeedManager.isFeedView(false),
                initialClosed: homepageFeedManager.wasBannerClosed() || appConfig.properties.noBannerSwitch,
                switch: homepageFeedManager.switchView,
                onBannerToggle: homepageFeedManager.toggleBanner
            };
        }
        setHydrationPromiseMap(hydrationSubscribableComponents);
        const pageTimings = getPageTimings();
        // Set the ad metadata
        const adsMetadata = getAdMetadata();
        adPageMetadataHub.setMetadatas(adsMetadata);
        if (window.isSSREnabled) {
            setSSREnabledStatus();
            // Preload entrypoint component
            requestAnimationFrame(() => setTimeout(() => {
                loadWebComponentExperience({
                    instanceId: entryPointConfigRef.experienceType,
                    configRef: entryPointConfigRef
                });
            }));
            // Preload other SSR loaded experience ( if any )
            window.ssrLoadedExperience?.subscribe((config) => {
                if (!config || !config.configRef) {
                    return;
                }
                pageTimings[`${config.configRef.experienceType}EagerLoadStart`] = Math.round(performance.now());
                // Run loadWebComponentExperience after next render to avoid blocking the main thread
                requestAnimationFrame(() => setTimeout(() => {
                    loadWebComponentExperience(config);
                }));
            });
            window.ssrLoadedBundles?.subscribe((bundles) => preloadBundles(bundles));
            pageTimings["WaitForCanRenderStart"] = Math.round(performance.now());
            await waitForCanRender();
            pageTimings["WaitForCanRenderEnd"] = Math.round(performance.now());
            setSSRCompleteStatus();
            startFasterHydrationAds(resolver);
        }
        else {
            const clientSettings = headData?.ClientSettings;
            const searchParams = new URLSearchParams(clientSettings.queryparams);
            const isSsrVp = searchParams.get("vpssr") === "1";
            if (isSsrVp) {
                const warningDiv = document.createElement("div");
                warningDiv.innerText = `SSR VP test detected but did not receive SSR response. Skip page rendering.
                Request Id: ${clientSettings.aid}`;
                // Style that readable on both dark/light mode
                warningDiv.style.cssText = "background-color: #fff; color: #000; font-size: 20px; font-weight: bold;";
                document.body.appendChild(warningDiv);
                return;
            }
        }
        setHydrationTimeTrackingComponents(hydrationTimeTrackingComponents);
        // Fire impr telemetry (too early for impr_update to be sent)
        const isAutoRefresh = location.search.includes("AR=");
        let useAidAsRid = true;
        /**
         * MSNHP have SW cache for base page. We should not use AID as RID for SW cache.
         */
        // If headData says new RID is needed or response is cached, we should not use AID as RID.
        if (headData.newRidNeeded || isResponseCached() || isAutoRefresh) {
            useAidAsRid = false;
        }
        sendPageViewIfNoLitePV({ page: { url: locationHref, isAutoRefresh: isAutoRefresh, isCorePV: isFeedView || !isAutoRefresh } }, useAidAsRid);
        const preloadCallbacks = [];
        const commonHeaderWCConfig = entryPointConfig.childExperienceConfigInfo?.commonHeaderWC;
        if (commonHeaderWCConfig) {
            // fetch the common header config, to get routing information
            const config = await resolver.getConfig(commonHeaderWCConfig.configRef);
            if (!config || !config.properties) {
                // TODO - Log Error
                return;
            }
            // CommonHeader depends on Router, initialize it early
            const commonHeaderConfig = config.properties;
            preloadCallbacks.push((rootWC) => {
                rootWC.commonHeaderConfig = commonHeaderConfig;
            });
        }
        const nurturingBannerWCConfig = entryPointConfig.childExperienceConfigInfo?.nurturingBanner;
        if (nurturingBannerWCConfig) {
            // fetch the nurturing banner config, to get routing information
            await resolver.getConfig(nurturingBannerWCConfig.configRef).then(config => {
                if (!config || !config.properties) {
                    // TODO - Log Error
                    return;
                }
                const nurturingBannerConfig = config.properties;
                preloadCallbacks.push((rootWC) => {
                    rootWC.nurturingBannerConfig = nurturingBannerConfig;
                });
            });
        }
        preloadCallbacks.push((rootWC) => {
            rootWC.initProps = entryPointInitialProps;
        });
        pageTimings["renderPageExperience"] = Math.round(performance.now());
        renderPageExperience(entryPointConfigRef, hydrationPromise, preloadCallbacks);
        // Enable ad blocker detector
        if (entryPointConfig.enableAdBlockerDetector) {
            const executeAdBlockerDetector = async () => {
                await adbService.executeDetector();
                Telemetry.updatePageMetadata({ page: { hasAdBlocker: adbService.getAdbStatus() } }, true);
            };
            if (entryPointConfig.delayAdBlockerDetector) {
                waitForTtvr().then(() => {
                    executeAdBlockerDetector();
                });
            }
            else {
                executeAdBlockerDetector();
            }
        }
        clientInitEnd();
        // Prefetch manifest bundles for views after above the fold is visually ready
        if (entryPointConfig.enableViewsBundlePrefetch) {
            prefetchViewsCoreBundles();
        }
        const { page } = Telemetry.getPageMetadata().contract;
        setEntityMetricCorePivotFieldValue("pageProduct", page.product);
        if (!headData.CurrentFlightSet.has("hp-cwebvitals")) {
            waitForAboveTheFoldVisuallyReadyAsync().then(() => { initializeWebVitals(getPageTimings(), getWebVitalsPageTimings(), false); });
        }
        waitForTtvr().then(() => {
            import(/* webpackChunkName: "msn-consent-sharing" */ "@msnews/consent-sharing").then(ConsentSharingModule => {
                ConsentSharingModule.consentSharing.uploadConsentPreferenceToProfile();
            }).catch(() => { });
        });
    }
    catch (e) {
        // Render an error page
        // TODO: need an error page from design
        logException(e, HomePageEntryPointHomePageErrorPage, "Error during app initialize.");
        clientInitEnd(true);
    }
    finally {
        // Check if localStorage and sessionStorage is not available
        localStorageExists(Telemetry.sendAppErrorEvent);
        sessionStorageExists(Telemetry.sendAppErrorEvent);
    }
};
function renderPageExperience(entryPointConfigRef, hydrationPromise, preloadCallbacks) {
    const entryPointRootConfigInfo = {
        instanceId: entryPointConfigRef.experienceType,
        configRef: entryPointConfigRef
    };
    const renderRootPromise = renderRootElement(entryPointRootConfigInfo, "fluent-design-system-provider", undefined, {
        onHydrationCallback(element) {
            if (element.markVisuallyReady) {
                element.markVisuallyReady();
            }
        }
    }, undefined, undefined, preloadCallbacks);
    const marker = "EntryPointHpWC.Render";
    perfMarker.startMark(marker);
    renderRootPromise.then(() => {
        perfMarker.startMark(marker);
    }).finally(() => {
        hydrationPromise?.set();
        window.isHydrationCompleted = true;
        resolveHydrationPromises(hydrationSubscribableComponents);
    });
}
// For Desktop, we will return ssr content and not initPage when SSRONLY is true (for WCS SEO scenarios).
// For regular users, we will return static html including nav links, so we better initPage to render full content.
const isSSROnly = location.search.toLowerCase().indexOf("ssronly=true") > -1;
if (isSSROnly || window.SSRONLY) {
    window.SSRONLY = true;
    window.initPage = initPage;
}
else {
    initPage();
}
setupRenderModeIndicator();
//# sourceMappingURL=page.js.map