(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["libs_channel-page-utils_dist_UrlUtilities_js-web-components_super-container_dist_register_CsF-1d9bff"],{1302(t,e,o){"use strict";o.d(e,{Be(){return n},WI(){return r},h(){return i},y3(){return a}});const n="TTSR.FirstSection",i=12,a=304,r=.08},12628(t,e,o){"use strict";o.d(e,{A(){return m}});var n=o(79454),i=o(31782),a=o(69329),r=o(28160),s=o(8481),l=o(5569),d=o(96950),c=o(58914),u=o(74849),v=o(75988);const p=u.A`
    ${v.p}
`,h=u.A`
    ${c.l}
    ${p}
`;var f=o(2665);const g=l.d.compose({name:"cs-article-card-no-hide-story",styles:h,template:(0,f._)({attribution:d.qy`${n.Au}`,footerStart:d.qy`${i.xZ}`,footerEnd:d.qy`${a.IL}`,hideStory:d.qy`${r.Z}`,title:d.qy`${s.B2}`})});var $=o(84056),b=o(65614);const m=()=>{(0,$.J)(),g.define(b.G.registry)}},16038(t,e,o){"use strict";o.d(e,{m(){return p}});var n=o(65614),i=o(13312),a=o(55153),r=o(7896),s=o(74849),l=o(64187);const d=s.A`
    ${(0,l.V)("grid")}

    :host {
        font-family: ${r.O};
        width: auto;
        grid-auto-columns: calc(${a.QG} * 1px);
        grid-auto-row: calc(${a.l8} * 1px);
        grid-gap: calc(${a.Sn} * 1px);
    }
`;var c=o(39957),u=o(96950);const v=u.qy`
    <template @keydown="${(t,e)=>t.handleKeyDown(e.event)}">
        ${(0,c.ux)(t=>t.childrenLayout,u.qy`
                ${(t,e)=>e.parent.selectTemplate(t)}
            `)}
    </template>
`,p=i.tA.compose({name:`${n.G.prefix}-feed-layout`,styles:d,template:v})},26831(t,e,o){"use strict";o.d(e,{Hg(){return r}});var n=o(58792),i=o(26220);const a=/[:/?#[\]@!$&'()*+,;=]/g;function r(t,e,o,r){let s=`${n.T3.NavTargetUrlWithLocale}/channel`;if(t&&o){const n="source"===o?"sr":"tp";s+="/"+[o,e?encodeURIComponent(e.replace(a,"")):"",`${n}-${t}`].filter(t=>t).join("/")}const l=new URL(s);return r||(l.search=(0,i.iA)()),(0,i.ou)().includes("localhost.msn.com")&&(l.host=(0,i.ou)()),l.toString()}},29652(t,e,o){"use strict";o.d(e,{Y(){return c}});var n=o(85349),i=o(96950),a=o(69259),r=o(17857),s=o(41938),l=o.n(s),d=o(83222);const c=i.qy` ${(0,a.z)(t=>t.enableCardHideStoryIcon,i.qy`<button aria-label="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.hide}" class="card-hide" slot="hide-story" title="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.hide}" @click=${(t,e)=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^r.J.hide^r.J.hidden,"Hide",!0,null,null,null,e.event,null,"hidestory-button")} @keypress=${t=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^r.J.hide^r.J.hidden,"Hide","Hide",!0,null,null,null,null,null,"hidestory-button")} data-t="${t=>{var e,o,i;return(null===(e=t.telemetryContext)||void 0===e?void 0:e.hide)&&(o=t.telemetryContext.hide,new d.$({...null==o?void 0:o.contract,name:"showFewer",action:n.EG.Click,behavior:n.MS.Dislike,type:n.MJ.ActionButton,content:{...null==o||null===(i=o.contract)||void 0===i?void 0:i.content}}).getMetadataTag())}}">${i.qy.partial(l())}</button>`)}
`},36355(t,e,o){"use strict";o.d(e,{v(){return h}});var n=o(50866),i=o(43922),a=o(25109),r=o(29937),s=o(52356);function l(t,e){const o=t;return function(t){t.imageData&&t.imageData.source&&(t.mediaType=["video","webcontent"].includes(t.contentType)?i.z.video:i.z.image)}(o),function(t,e){t.immersiveCard||(t.immersiveCard=t.cardSize===n.qJ._2x_2y&&t.cardLayout!==r.Sv.infoPane||t.cardSize===n.qJ._2x_2y&&t.cardLayout===r.Sv.infoPane&&e.config&&!e.config.enableImmersiveInfopane||t.cardLayout===r.Sv.infoPane&&e.config&&e.config.enableSuperInfopane&&!e.config.disable1UImmersiveInfopane)}(o,e),o}function d(t,e){if(t.immersiveCard&&t.mediaType)return t.cardFillColor="#333",t.darkCardFillColor=t.cardFillColor,void(t.lightCardFillColor=t.cardFillColor);let o=!1;if(o=t.useMobile&&!t.isMsnMobile?(0,a.r0)(t):t.useWinSystemMode||t.isMsnMobile?s.y.appInDarkMode():(0,a.ud)(),e&&e.config&&e.config.enableFeedSuperCardsSingleColor)e.config.cardColorsOverride?(t.lightCardFillColor=e.config.cardColorsOverride.lightCardFillColor,t.darkCardFillColor=e.config.cardColorsOverride.darkCardFillColor):(t.lightCardFillColor="#FFFFFF",t.lightCardSecondaryColor=void 0,t.lightGradientAngle=void 0,t.darkCardFillColor="#292929",t.darkCardSecondaryColor=void 0,t.darkGradientAngle=void 0);else{var n,i;const e=null===(n=t.colorSamples)||void 0===n?void 0:n.find(t=>!1===t.isDarkMode),o=!e||!e.hexColor&&!e.secHexColor&&!e.gradientAngle;t.lightCardFillColor=o?"#FFFFFF":e.hexColor,t.lightCardSecondaryColor=o?"#E1E1E1":e.secHexColor,t.lightGradientAngle=o?"112.05deg":e.gradientAngle;const a=null===(i=t.colorSamples)||void 0===i?void 0:i.find(t=>!0===t.isDarkMode),r=!a||!a.hexColor&&!a.secHexColor&&!a.gradientAngle;t.darkCardFillColor=r?"#565656":a.hexColor,t.darkCardSecondaryColor=r?"#272727":a.secHexColor,t.darkGradientAngle=r?"112.05deg":a.gradientAngle}t.cardFillColor=o?t.darkCardFillColor:t.lightCardFillColor,t.cardSecondaryColor=o?t.darkCardSecondaryColor:t.lightCardSecondaryColor,t.gradientAngle=o?t.darkGradientAngle:t.lightGradientAngle}function c(t,e){if(!e||!e.config)return;if(!e.config.enableFeedSuperCardsSolidColor&&!t.enableNativeAdCardsSolidColor)return;if(!t.immersiveCard&&"#000000"!==t.cardFillColor||t.cardSize===n.qJ._2x_2y&&!t.imageData){t.lightCardFillColor="#FFF",t.lightCardSecondaryColor=void 0,t.lightGradientAngle=void 0,t.darkCardFillColor="#333",t.darkCardSecondaryColor=void 0,t.darkGradientAngle=void 0;const e=s.y.appInDarkMode();t.cardFillColor=e?t.darkCardFillColor:t.lightCardFillColor,t.cardSecondaryColor=void 0,t.gradientAngle=void 0}}function u(t,e){const o=e._config,n=l(t,e);return d(n,e),n.openLinksInNewTab=n.openLinksInNewTab||n.openArticleInNewTab,n.seeMoreOverride=o.seeMoreOverride,c(n,e),n}function v(t,e,o){var n,a,r;const s=l(t,e);return s.isInfopaneComplexAd=o,d(s,e),c(s,e),function(t,e){if(e&&e.config&&e.config.nativeAdImageQuality&&t.imageData&&t.mediaType===i.z.image&&t.imageData.source){const o=new URL(t.imageData.source),n=null==o?void 0:o.searchParams;n&&(n.set("qlt",e.config.nativeAdImageQuality),o.search=n.toString(),t.imageData.source=o.toString())}}(s,e),s.enableAdShimmerEffect=null==e||null===(n=e.config)||void 0===n?void 0:n.enableAdShimmerEffect,s.useFeeds3Designs=null==e||null===(a=e.config)||void 0===a?void 0:a.enableDynamicWaterfall,s.enableResponsiveWidth=null==e||null===(r=e.config)||void 0===r?void 0:r.enableResponsiveWidth,s}var p=o(99476);class h{static createViewModel(t,e){switch(t&&t.childTemplateType){case"article-card":case"content-card":case"web-content-card":return u(t,e);case"video-card":return function(t,e){const o=l(t,e);d(o,e),o.openLinksInNewTab=o.openLinksInNewTab||o.openArticleInNewTab,c(o,e);const i=e.config;return o.immersiveCard=o.cardSize===n.qJ._2x_2y&&o.immersiveCard,o.enableSuperVideoIconLarge=i.enableSuperVideoIconLarge,o}(t,e);case"native-ad-card":case"native-top-ad-card":return v(t,e);case"super-sd-card":return l(t,e);case"content-group":return function(t,e){let o=l(t,e);const i=e._config;o.cardData=t,o.lightCardFillColor="#FFFFFF",o.darkCardFillColor="#333";const a=s.y.appInDarkMode();o.cardFillColor=a?o.darkCardFillColor:o.lightCardFillColor,t.contentGroupMetadata.subCards.forEach((t,o)=>{t.isNativeAd&&t.nativeAds.length>0?t.nativeAds.forEach(o=>{v(o,e,t.nativeAds.length>1)}):(u(t,e),i.enableFeed3Cards&&"1u"===t.cardSize&&(t.cardSize="_1x_2y"))});const r=(0,p.a)().get("vpFreeze");o={...o,...i};const d=i.autoRotateIntervalMs;o.enableFlippersOnRest=i.enableInfopaneFlippersOnRest,o.enableTransparentFlippersOnRest=i.enableTransIfpFlippersOnRest,o.enableSlideShow=!i.disableSlideShow&&!r,o.enablePlayPauseButton=!i.disableInfopanePlayPauseButton,o.disableNavAnimation=i.disableNavAnimation,o.rotationDuration=d?d/1e3:3,o.enableSuperCardMemoize=e.getEnableSuperCardMemoize(),o.disableInfopaneComplexAds=i.disableInfopaneComplexAds,o.enableIpTransform=i.enableIpTransform,o.restartRotationTimer=i.restartRotationTimer;const c=i.enableOneCInfopaneNav&&o.cardSize===n.qJ._1x_2y;return o.tabCount=i.enableMaxInfopaneSlider&&!c?99:5,o}(t,e);case"infopane-card":return function(t,e){const o=l(t,e),i=e._config;o.cardData=t,o.lightCardFillColor="#FFFFFF",o.darkCardFillColor="#333";const a=s.y.appInDarkMode();o.cardFillColor=a?o.darkCardFillColor:o.lightCardFillColor,t.slideContentData.forEach((t,o)=>{t&&(t.isNativeAd?i.enableResponsiveInfopaneMap?v(t,e):t.nativeAds.length>0&&t.nativeAds.forEach(o=>{v(o,e,t.nativeAds.length>1)}):(u(t,e),i.enableFeed3Cards&&"1u"===t.cardSize&&(t.cardSize="_1x_2y")))});const r=(0,p.a)().get("vpFreeze"),d=i.autoRotateIntervalMs??o.cardData.autoRotateIntervalMs;i.autoRotateIntervalMs||o.wpoRotationDuration||(o.wpoRotationDuration=o.cardData.autoRotateIntervalMs/1e3),o.enableSlideShow=!i.disableSlideShow&&!r,o.enablePlayPauseButton=!i.disableInfopanePlayPauseButton,o.enableResponsiveInfopaneMap=i.enableResponsiveInfopaneMap,o.enableAutoPlayInfopaneVideos=i.enableAutoPlayInfopaneVideos,o.enableResponsiveCards=i.enableResponsiveComponent,o.disableNavAnimation=i.disableNavAnimation,o.shiftIpNavToRight=i.shiftIpNavToRight,o.rotationDuration=d?d/1e3:3,o.enableSingleRotation=o.cardData.enableRotateOnlyOnce,o.enableSuperCardMemoize=e.getEnableSuperCardMemoize(),o.disableInfopaneComplexAds=i.disableInfopaneComplexAds,o.enableFlippersOnRest=i.enableInfopaneFlippersOnRest,o.enableTransparentFlippersOnRest=i.enableTransIfpFlippersOnRest,o.enableIpTransform=i.enableIpTransform,o.enableInfopaneDenseCardInteraction=i.enableInfopaneDenseCardInteraction,o.restartRotationTimer=i.infopaneRestartRotationBuffer>0?o.wpoRotationDuration+i.infopaneRestartRotationBuffer:i.restartRotationTimer,o.cardData.flipperSize=i.ipFlipperCustomSize??"large",o.cardData.flipperColorInverted=i.invertIpFlipperColor,o.seeMoreOverride=i.seeMoreOverride,o.enableLazyInfopane=!!i.enableLazyInfopane,o.lazyInfopanePreloadCount=i.lazyInfopanePreloadCount;const c=i.enableOneCInfopaneNav&&o.cardSize===n.qJ._1x_2y;return i.enableBottomNav&&!c&&(o.navPosition="bottom"),o.tabCount=i.enableMaxInfopaneSlider&&!c?99:5,o}(t,e);case"carousel":return function(t,e){return l(t,e)}(t,e);default:return null}}}},41938(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M2.4 2.55l.07-.08a.75.75 0 01.98-.07l.08.07L8 6.94l4.47-4.47a.75.75 0 111.06 1.06L9.06 8l4.47 4.47c.27.27.3.68.07.98l-.07.08a.75.75 0 01-.98.07l-.08-.07L8 9.06l-4.47 4.47a.75.75 0 01-1.06-1.06L6.94 8 2.47 3.53a.75.75 0 01-.07-.98l.07-.08-.07.08z"></path></svg>'},43922(t,e,o){"use strict";o.d(e,{z(){return n}});const n={image:"image",video:"video"}},45214(t,e,o){"use strict";o.d(e,{O(){return R}});var n=o(65614),i=o(16038),a=o(56911),r=o(92011),s=o(60815),l=o(87119);class d extends r.L{}(0,a.Cg)([l.V],d.prototype,"configProvider",void 0),(0,a.Cg)([s.sH],d.prototype,"feedLayouts",void 0),(0,a.Cg)([s.sH],d.prototype,"layout",void 0),(0,a.Cg)([s.sH],d.prototype,"placeholderFeedLayout",void 0);var c=o(96950),u=o(36355),v=o(2171);class p{static getViewTemplate(t,e){const o=e&&e.getSuperCardsTemplatesMap(),n=o&&o[t.childTemplateType];if(!n)return null;const i=()=>{const t=c.qy.partial(n);return c.qy`
            <${t}
                class="card-container"
                config-instance-src="${t=>t.configInstanceSrc||"default"}"
                :displaySettings=${t=>t.displaySettings}
                :data=${t=>u.v.createViewModel(t,e)}
                style="grid-area:${t=>t.gridArea}"
                size="${t=>t.cardSize}"
                tabIndex="${t=>t.customTabIndex??0}"
            >
            </${t}>
        `};if(!e.getEnableSuperCardMemoize())return i();const a="_SuperContainer__TagCreatorFactory_",r=v.vv.get(a)||{};return r[n]||(r[n]=i(),v.vv.set(a,r)),r[n]}}var h=o(38493);class f extends d{constructor(){super(...arguments),this.lastFeedLayoutPosition=-1}feedLayoutsChanged(){var t;if(null===(t=this.feedLayouts)||void 0===t||!t.length)return;const e=this.configProvider.getCardTemplatesMap(),o=this.configProvider.getSuperCardsTemplatesMap();for(let t=this.lastFeedLayoutPosition+1;t<this.feedLayouts.length;t++){this.feedLayouts[t].feedData.defaultLayout.forEach(t=>{if(o[t.childTemplateType]){const o=p.getViewTemplate(t,this.configProvider);o&&(e[t.childTemplateType]=o)}})}this.lastFeedLayoutPosition=this.feedLayouts.length-1}}(0,a.Cg)([(0,h.CF)({attribute:"responsive-width"})],f.prototype,"responsiveWidth",void 0);var g=o(37635),$=o(74849);const b=$.A``,m=$.A`
    ${b} :host{display:grid;flex-flow:row wrap;gap:12px;justify-content:center;--layer-corner-radius:8}cs-feed-layout{grid-auto-rows:146px;--card-base-gap:12}:host([responsive-width="true"]) cs-feed-layout{grid-auto-columns:minmax(271px,348px);grid-auto-rows:auto}`.withBehaviors(new g.X(["configProvider"],t=>{var e;let o=$.A``;if(null!==(e=t.configProvider)&&void 0!==e&&null!==(e=e.config)&&void 0!==e&&e.feedLayoutGap){var n;const e=null===(n=t.configProvider)||void 0===n||null===(n=n.config)||void 0===n?void 0:n.feedLayoutGap;o=$.A` :host{gap:${e}px}cs-feed-layout{--card-base-gap:${e}; }
                `}return o}),new g.X(["configProvider"],t=>{var e,o,n;return t.configProvider&&t.configProvider.config&&(null!==(e=t.configProvider.config)&&void 0!==e&&e.useMobileNoHoverCards||null!==(o=t.configProvider.config)&&void 0!==o&&o.useMobileNoHoverLightCards||null!==(n=t.configProvider.config)&&void 0!==n&&n.enableChannelCard)?$.A` cs-feed-layout{grid-auto-rows:auto;grid-auto-columns:auto;`:$.A``}));var w=o(69259),y=o(39957);const x=c.qy` ${(0,w.z)(t=>!!(t.feedData&&t.feedData.defaultLayout&&t.feedData.defaultLayout.length),c.qy`<cs-feed-layout :disabledKeyListeners="${(t,e)=>e.parent.configProvider.getDisabledKeyListeners()}" layout="${(t,e)=>e.parent.layout}" :isPlaceholder="${t=>t.isPlaceholder}" :data="${t=>t.feedData}" :childTemplateMap="${(t,e)=>e.parent.configProvider.getCardTemplatesMap()}" :layoutStyles="${(t,e)=>e.parent.configProvider.getLayoutTemplatesMap()[t.templateId].styles}" style="${(t,e)=>e.parent.configProvider.getOverrideStyles()}" t-card-size="${t=>t.baseCardSize}"></cs-feed-layout>`)}`,F=c.qy` ${(0,w.z)(t=>t.feedLayouts&&t.feedLayouts.length,c.qy` ${(0,y.ux)(t=>t.feedLayouts,x)}<slot name="abovePlaceholder"></slot>${(0,w.z)(t=>t.placeholderFeedLayout,c.qy` ${(0,y.ux)(t=>[t.placeholderFeedLayout],x)} `)} `)}`,C=f.compose({name:"cs-personalized-feed",styles:m,template:F});var k=o(13312),L=o(29307),M=o(96787);class S extends r.L{constructor(){super(...arguments),this.enableWFMonitor=!1,this.sentinelHeight=1}feedLayoutsChanged(){this.mutateCurrentFeedLayouts()}placeholderFeedLayoutChanged(){this.placeholderFeedLayout&&this.mutateFeedLayout(this.placeholderFeedLayout)}layoutChanged(){this.mutateCurrentFeedLayouts(),this.placeholderFeedLayout&&this.mutateFeedLayout(this.placeholderFeedLayout)}responsiveFeedLayoutsChanged(){var t;this.cardTemplateMap=null===(t=this.responsiveFeedLayouts)||void 0===t||null===(t=t[0])||void 0===t?void 0:t.childTemplateMap}disconnectedCallback(){super.disconnectedCallback()}mutateCurrentFeedLayouts(){var t;null!==(t=this.feedLayouts)&&void 0!==t&&t.length&&this.layout&&this.feedLayouts.forEach(t=>this.mutateFeedLayout(t))}mutateFeedLayout(t){var e;const o=this.configProvider.getCardTemplatesMap();o["native-ad-card-video"]||(o["native-ad-card-video"]=(0,L.A)(o["native-ad-card"])),o["native-ad-card-boost"]||(o["native-ad-card-boost"]=(0,L.A)(o["native-ad-card"]));const n=null==t?void 0:t.feedData;null==n||null===(e=n.defaultLayout)||void 0===e||e.forEach((t,e)=>{const i=n[this.layout]&&n[this.layout].find(e=>(0,M.Yd)(e)&&e.id===t.id);i&&"video-card"===i.childTemplateType?t.childTemplateType="video-card":i&&"infopane-slide-card"===i.childTemplateType&&"infopane-slide-card"!==t.childTemplateType&&(n[this.layout].find(e=>(0,M.Yd)(e)&&e.id===t.id).childTemplateType=t.childTemplateType),this.updateTemplateForNotSupportedScenario(t,o)});for(const t in k._4)n[t]&&n[t].forEach(t=>t.childDOMOrder=t.card_dom_order)}personalizedFeedElementChanged(){this.onFeedLayoutElementsChanged&&!this.personalizedFeedElementMutationObserver&&this.personalizedFeedElement&&this.personalizedFeedElement.shadowRoot&&(this.personalizedFeedElementMutationObserver=new MutationObserver(()=>{if(this.personalizedFeedElement&&this.personalizedFeedElement.shadowRoot){const t=Array.from(this.personalizedFeedElement.shadowRoot.children).filter(t=>"CS-FEED-LAYOUT"===t.tagName&&!t.isPlaceholder);this.onFeedLayoutElementsChanged(t)}}),this.personalizedFeedElementMutationObserver.observe(this.personalizedFeedElement.shadowRoot,{childList:!0}))}updateTemplateForNotSupportedScenario(t,e){if(!(t&&"native-ad-card"===t.childTemplateType))return;if(t.videoProps||t.useProng2AmplifyCardTemplate)if(t.videoProps){const o=t.childTemplateType+"-v1";e[o]||(e[o]=e["native-ad-card-video"]),t.childTemplateType=o}else if(t.useProng2AmplifyCardTemplate){const o=t.childTemplateType+"-v2";e[o]||(e[o]=e["native-ad-card-boost"]),t.childTemplateType=o}}getResponsiveCardTemplates(t){if("widgetsWaterfall"===t)return this.cardTemplateMap;const e=this.configProvider.getCardTemplatesMap();e["infopane-card"]=p.getViewTemplate({id:"infopane",childTemplateType:"infopane-card"},this.configProvider),e["native-ad-card-video"]||(e["native-ad-card-video"]=(0,L.A)(e["native-ad-card"]));return e["native-ad-card"]=p.getViewTemplate({id:"nativead",childTemplateType:"native-ad-card"},this.configProvider),e}}(0,a.Cg)([l.V],S.prototype,"configProvider",void 0),(0,a.Cg)([s.sH],S.prototype,"feedLayouts",void 0),(0,a.Cg)([s.sH],S.prototype,"responsiveFeedLayouts",void 0),(0,a.Cg)([s.sH],S.prototype,"enableWFMonitor",void 0),(0,a.Cg)([s.sH],S.prototype,"enableFirstSectionFlush",void 0),(0,a.Cg)([s.sH],S.prototype,"cardTemplateMap",void 0),(0,a.Cg)([s.sH],S.prototype,"childTemplateSizeMap",void 0),(0,a.Cg)([s.sH],S.prototype,"layout",void 0),(0,a.Cg)([s.sH],S.prototype,"personalizedFeedElement",void 0),(0,a.Cg)([s.sH],S.prototype,"sentinelHeight",void 0),(0,a.Cg)([s.sH],S.prototype,"placeholderFeedLayout",void 0),(0,a.Cg)([s.sH],S.prototype,"responsiveWidth",void 0),(0,a.Cg)([s.sH],S.prototype,"seenContentHandler",void 0),(0,a.Cg)([(0,h.CF)({attribute:"content-seen-removal-mode",converter:h.R$})],S.prototype,"contentSeenRemovalMode",void 0);const T=$.A``;var z=o(60402),_=o(1302);(0,o(50193).C)(_.Be);const E=c.qy`<cs-personalized-feed ${(0,z.K)("personalizedFeedElement")} :layout="${t=>t.layout}" :feedLayouts=${t=>t.feedLayouts} :placeholderFeedLayout=${t=>t.placeholderFeedLayout} :responsiveWidth="${t=>t.responsiveWidth}"><slot name="sentinel" slot="abovePlaceholder"></slot></cs-personalized-feed>`,H=c.qy` ${(0,y.ux)(t=>t.responsiveFeedLayouts,c.qy`<cs-responsive-feed-layout :childTemplateMap="${(t,e)=>e.parent.getResponsiveCardTemplates(t.id)}" :childTemplateSizeMap="${(t,e)=>{var o;return null===(o=e.parent)||void 0===o?void 0:o.childTemplateSizeMap}}" :wideCard="${t=>t.wideCard}" :wideCardSize="${t=>t.wideCardSize}" :onFeedElementsChanged="${(t,e)=>e.parent.onFeedLayoutElementsChanged}" :enableMonitor="${(t,e)=>e.parent.enableWFMonitor}" :onBlankMonitorResult="${t=>t.onBlankMonitorResult}" :sentinelHeight="${(t,e)=>e.parent.sentinelHeight}" :sentinelRenderedElements="${(t,e)=>e.parent.sentinelRenderedElements}" :sectionTrackerTag="${t=>t.sectionTrackerTag}" :renderingMode="${t=>t.rowRendering?"row":"column"}" :responsiveWidth="${(t,e)=>e.parent.responsiveWidth}" :columns="${t=>t.columns}" :customRowSection="${t=>t.customRowSection}" :id="${t=>t.id}" :seenContentHandler="${(t,e)=>e.parent.seenContentHandler}" content-seen-removal-mode=${(t,e)=>e.parent.contentSeenRemovalMode}>${void 0}</cs-responsive-feed-layout>`,{positioning:!0})}
`,A=c.qy` ${(0,w.z)(t=>{var e;return!t.responsiveFeedLayouts&&(null===(e=t.feedLayouts)||void 0===e?void 0:e.length)},E)} ${(0,w.z)(t=>{var e;return null===(e=t.responsiveFeedLayouts)||void 0===e?void 0:e.length},H)}
`,B=S.compose({name:"cs-super-container",styles:T,template:A}),R=()=>{C.define(n.G.registry),B.define(n.G.registry),i.m.define(n.G.registry)}},52396(t,e,o){"use strict";var n=o(87210),i=o(65614),a=o(3817),r=o(30163),s=o(28160),l=o(8481),d=o(96950),c=o(61289),u=o(40331),v=o(77793),p=o(22977),h=o(62096),f=o(56930),g=o(33273),$=o(40073),b=o(62128),m=o(75988),w=o(2713),y=o(74849),x=o(58914),F=o(12640),C=o(16548);const k=y.A`
    ${C.ll}
    ${p.B}
    ${h.J}
    ${f.p}
    ${g.O}
    ${$.W}
    ${b.u}
    ${m.p}
    ${w.t}
    ${x.V} .ad-footer[slot="footer-start"]{flex-direction:row-reverse}.ad-footer[slot="footer-start"] .ad-choice{margin-inline-end:10px;margin-inline-start:unset}.ad-choice svg{width:12px;height:12px}.ad-footer[slot="footer-start"] .disclaimer{display:flex;align-items:center}.ad-footer[slot="footer-start"] .disclaimer .popup-offset{margin-inline:unset;margin-inline-start:-40px}.ad-footer[slot="footer-start"] .disclaimer .popup-arrow{margin-inline-start:-15px}.ad-slug[slot="attribution"]{position:relative;width:fit-content;z-index:2}`.withBehaviors(new F.N(null,C.Wk));var L,M,S=o(60018),T=o(93808);c.w;const z=new d.kc(null===(L={...T.bW}.html)||void 0===L?void 0:L.replace("footer-start","attribution"),T.bW.factories),_=new d.kc(null===(M={...a.$n}.html)||void 0===M?void 0:M.replace("footer-end","footer-start"),a.$n.factories),E=d.qy`
    <msn-native-ad-call-to-action
        slot="footer-end"
        text=${t=>H(t)}
        title=${t=>H(t)}
        aria-label=${t=>H(t)}
        for-infopane=${()=>!1}
        background-color="${t=>t.layoutColor}"
        destination-url=${t=>t.destinationUrl}
        tel-metadata=${t=>{var e;return null===(e=t.adTelemetryContext)||void 0===e||null===(e=e.destination)||void 0===e?void 0:e.getMetadataTag()}}
        ${(0,v.Ib)(!0,!1)}
    ></msn-native-ad-call-to-action>
`;function H(t){var e,o,n,i,a;return t.localizedStrings?null!==(e=t.template)&&void 0!==e&&e.enableNativeAdCTALearnMoreButton?null===(i=t.localizedStrings)||void 0===i?void 0:i.nativeAdLearnMoreText:null!==(o=t.template)&&void 0!==o&&o.enableNativeAdCTAOpenButton?null===(a=t.localizedStrings)||void 0===a?void 0:a.nativeAdOpenText:null===(n=t.localizedStrings)||void 0===n?void 0:n.nativeAdLearnMoreText:"Learn more"}class A extends u.q{}const B=d.qy`${t=>function(t){const{enableNativeAdChoiceMoveLeft:e,enableNativeAdCTAOpenButton:o,enableNativeAdCTALearnMoreButton:n}=(null==t?void 0:t.template)||{};return e?o||n?E:null:a.$n}(t)}`,R=d.qy`${t=>function(t){const{enableNativeAdChoiceMoveLeft:e,enableNativeAdSlugMoveUp:o}=(null==t?void 0:t.template)||{};return e?_:o&&!e?null:T.bW}(t)}`,U=d.qy`${s.Z}`,I=d.qy`${l.B2}`,P=d.qy`${t=>function(t){var e;return null!=t&&null!==(e=t.template)&&void 0!==e&&e.enableNativeAdSlugMoveUp?z:r.j}(t)}`,W=A.compose({name:"cs-native-ad-card-cta",styles:k,template:(0,S.qn)({footerEnd:B,footerStart:R,hideStory:U,title:I,attribution:P})});var N=o(57415),V=o(12628),D=o(45214);(0,n.m)(),(0,N.J)(),W.define(i.G.registry),(0,D.O)(),(0,V.A)()},61289(t,e,o){"use strict";o.d(e,{w(){return w}});var n=o(56911),i=o(38493),a=o(60815),r=o(87259),s=o(93552),l=o(91454);let d=class extends r.t{themeChangeListener(t){this.darkMode=!(null==t||!t.matches)}constructor(){super(),this.text="",this.forInfopane=!0,this.backgroundColor="",this.defaultBackgroundColor="#FFFFFF",this.color="#2065C1",this.isHovered=!1,this.ctaMode="default",this.destinationUrl="",this.telemetryMetadata=void 0,this.darkModeQuery=window.matchMedia("(prefers-color-scheme:dark)"),this.darkMode=!!this.darkModeQuery.matches}connectedCallback(){super.connectedCallback(),this.darkModeQuery.addEventListener("change",this.themeChangeListener.bind(this))}disconnectedCallback(){super.disconnectedCallback(),this.darkModeQuery.removeEventListener("change",this.themeChangeListener.bind(this))}};(0,n.Cg)([i.CF],d.prototype,"text",void 0),(0,n.Cg)([(0,i.CF)({mode:"boolean",attribute:"for-infopane"})],d.prototype,"forInfopane",void 0),(0,n.Cg)([(0,i.CF)({attribute:"background-color"})],d.prototype,"backgroundColor",void 0),(0,n.Cg)([(0,i.CF)({attribute:"default-background-color"})],d.prototype,"defaultBackgroundColor",void 0),(0,n.Cg)([i.CF],d.prototype,"color",void 0),(0,n.Cg)([(0,i.CF)({mode:"boolean",attribute:"is-hovered"})],d.prototype,"isHovered",void 0),(0,n.Cg)([(0,i.CF)({attribute:"cta-mode"})],d.prototype,"ctaMode",void 0),(0,n.Cg)([(0,i.CF)({attribute:"destination-url"})],d.prototype,"destinationUrl",void 0),(0,n.Cg)([(0,i.CF)({attribute:"tel-metadata"})],d.prototype,"telemetryMetadata",void 0),(0,n.Cg)([a.sH],d.prototype,"darkMode",void 0),d=(0,n.Cg)([(0,l.TA)(s.PDj,"msn-native-ad-call-to-action")],d);var c=o(92011),u=o(74849),v=o(78862),p=o(37635);const h=u.A`
.call-to-action {
    background-color: #FFFFFF;
    color: #2065C1;
    font-size: 14px; 
    font-weight: 600;
    height: 32px;
    line-height: 32px;
    display: inline-block;
    border-radius: 20px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    position: relative;
}

.call-to-action-bg {
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 20px;
    opacity: 0.3;
}

.call-to-action-txt {
    position: relative;
    border-radius: 20px;
    padding-left: 12px;
    padding-right: 12px;
}

.call-to-action-icon-container {
    background-color: #C6C0BA;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    position: relative;
}

.call-to-action-icon-bg {
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    opacity: 0.3;
}

.call-to-action-icon {
    width: 9px;
    height: 15px;
    left: 12px;
    top: 8px;
    position: absolute;
    display: flex;
}

.call-to-action-mask-container {
    background: linear-gradient(180deg, rgba(43, 43, 43, 0.9) 0%, rgba(43, 43, 43, 0.35) 100%);
    position: absolute;
    width: 100%;
    height: 304px;
    bottom: 0;
    left: 0;
    animation: fadeIn 0.1s forwards;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

.call-to-action-mask-wrapper {
    width: fit-content;
    position: absolute;
    top: 113px;
    left: 50%;
    transform: translate(-50%, 0);
    display: flex;
    align-items: center;
}

.call-to-action-mask-text {
    font-size: 19px;
    font-weight: 600;
    display: inline-block;
}

.call-to-action-mask-icon{
    display: inline-block;
    width: 16px;
    height: 14px;
    margin-inline: 5px;
}

.txt-button-wrapper {
    display: inline-block;
    position: relative;
    padding: 4px 12px;
    line-height: 16px;
    font-size: 12px;
    border-radius: 100px;
    font-weight: 400;
    text-decoration: none;
}

.txt-button-wrapper::before {
    content: "";
    position: absolute;
    inset: 0px;
    border-radius: 50px;
    padding: 1px;
    -webkit-mask: linear-gradient(rgb(255, 255, 255) 0px, rgb(255, 255, 255) 0px) content-box content-box, linear-gradient(rgb(255, 255, 255) 0px, rgb(255, 255, 255) 0px);
    -webkit-mask-composite: xor;
    pointer-events: none;
}
`.withBehaviors(new v.e("layoutStyle"),new p.X(["defaultBackgroundColor","backgroundColor","color","forInfopane","darkMode"],t=>{let e=`\n                .call-to-action.dynamic-styles {\n                    background: ${t.defaultBackgroundColor};\n                }\n                .call-to-action-txt.dynamic-styles {\n                    color: ${t.color};\n                }\n                .call-to-action-bg.dynamic-styles {\n                    background: ${t.backgroundColor};\n                }\n                .call-to-action-icon-bg.dynamic-styles {\n                    background: ${t.backgroundColor};\n                }\n            `;return t.forInfopane||(e+="\n                    .txt-button-wrapper::before {\n                        background: linear-gradient(180deg, #EFEFEF 90%, #D6D6D6 100%);\n                    }\n                "),t.darkMode?e+="\n                    .txt-button-wrapper {\n                        background: linear-gradient(0deg, rgba(255, 255, 255, 0.0605), rgba(255, 255, 255, 0.0605));\n                        color: #FFFFFF;\n                    }\n                    .txt-button-wrapper::before {\n                        background: linear-gradient(180deg, rgba(255, 255, 255, 0.093) 0%, rgba(255, 255, 255, 0.0698) 9.57%);\n                    }\n                ":e+="\n                    .txt-button-wrapper {\n                        color: #1a1a1a;\n                        background: linear-gradient(0deg, #FFFFFF, #FFFFFF);\n                    }\n                    .txt-button-wrapper::before {\n                        background: linear-gradient(rgba(239, 239, 239, 0.7) 90%, rgba(214, 214, 214, 0.7) 100%);\n                    }\n                ",u.A`${e}`}));var f=o(96950),g=o(69259);const $=f.qy`
<svg width="11" height="17" viewBox="0 0 11 17" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M2.09854 16.6761L10.6426 9.25004C10.8715 9.05109 11 8.78131 11 8.5C11 8.2187 10.8715 7.94891 10.6426 7.74997L2.09854 0.323871C1.98594 0.222547 1.85126 0.141728 1.70234 0.0861287C1.55342 0.0305295 1.39326 0.0012641 1.23119 4.0055e-05C1.06912 -0.00118399 0.908396 0.0256578 0.758391 0.0789993C0.608386 0.132341 0.472105 0.211114 0.357501 0.310722C0.242897 0.41033 0.152265 0.528778 0.0908924 0.659155C0.0295204 0.789532 -0.00136224 0.929227 4.60857e-05 1.07009C0.00145442 1.21095 0.0351258 1.35016 0.0990954 1.47959C0.163065 1.60902 0.256052 1.72608 0.37263 1.82394L8.05377 8.5L0.37263 15.1761C0.256052 15.2739 0.163065 15.391 0.0990954 15.5204C0.0351258 15.6498 0.00145442 15.7891 4.60857e-05 15.9299C-0.00136224 16.0708 0.0295204 16.2105 0.0908924 16.3408C0.152265 16.4712 0.242897 16.5897 0.357501 16.6893C0.472105 16.7889 0.608386 16.8677 0.758391 16.921C0.908396 16.9743 1.06912 17.0012 1.23119 17C1.39326 16.9987 1.55342 16.9695 1.70234 16.9139C1.85126 16.8583 1.98594 16.7775 2.09854 16.6761Z" fill="black"/>
</svg>
`,b=f.qy`
<svg width="16" height="14" viewBox="0 0 16 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6.5 14C6.22386 14 6 13.7761 6 13.5C6 13.2239 6.22386 13 6.5 13H13C14.1046 13 15 12.1046 15 11V3C15 1.89543 14.1046 1 13 1H6.5C6.22386 1 6 0.776142 6 0.5C6 0.223858 6.22386 0 6.5 0H13C14.6569 0 16 1.34315 16 3V11C16 12.6569 14.6569 14 13 14H6.5ZM6.64645 3.14645C6.84171 2.95118 7.15829 2.95118 7.35355 3.14645L10.8536 6.64645C11.0488 6.84171 11.0488 7.15829 10.8536 7.35355L7.35355 10.8536C7.15829 11.0488 6.84171 11.0488 6.64645 10.8536C6.45118 10.6583 6.45118 10.3417 6.64645 10.1464L9.29289 7.5H0.5C0.223858 7.5 0 7.27614 0 7C0 6.72386 0.223858 6.5 0.5 6.5H9.29289L6.64645 3.85355C6.45118 3.65829 6.45118 3.34171 6.64645 3.14645Z" fill="white"/>
</svg>
`,m=f.qy` ${(0,g.z)(t=>"arrow"===t.ctaMode,f.qy`<a class="call-to-action-click-wrapper" target = "_blank" href = ${t=>t.destinationUrl} data-t="${t=>t.telemetryMetadata}" aria-label=${t=>t.text}><div class="call-to-action-icon-container" title="${t=>t.text}"><div class="call-to-action-icon-bg dynamic-styles"></div><div class="call-to-action-icon dynamic-styles">${$}</div></div></a>`)} ${(0,g.z)(t=>"mask"===t.ctaMode,f.qy` ${(0,g.z)(t=>t.isHovered,f.qy`<div class="call-to-action-mask-container"><div class="call-to-action-mask-wrapper"><div class="call-to-action-mask-text">${t=>t.text}</div><div class="call-to-action-mask-icon">${b}</div></div></div>`)} `)} ${(0,g.z)(t=>"default"===t.ctaMode||"button"===t.ctaMode,f.qy`<a class="txt-button-wrapper" target = "_blank" href = ${t=>t.destinationUrl} data-t="${t=>t.telemetryMetadata}">${t=>t.text}</a>`)} ${(0,g.z)(t=>"text"===t.ctaMode,f.qy` ${t=>t.text} `)} `;let w=class extends d{};w=(0,n.Cg)([(0,c.E)({name:"msn-native-ad-call-to-action",template:m,styles:h})],w)},84056(t,e,o){"use strict";o.d(e,{J(){return s}});var n=o(59836),i=o(73893),a=o(80090),r=o(65614);function s(){n.m.define(r.G.registry),i.m.define(r.G.registry),a.m.define(r.G.registry)}},87119(t,e,o){"use strict";o.d(e,{V(){return n}});const n=o(64332).DI.createContext()},87210(t,e,o){"use strict";o.d(e,{m(){return g}});var n=o(84056),i=o(79454),a=o(31782),r=o(69329),s=o(29652),l=o(28160),d=o(8481),c=o(5569),u=o(2665),v=o(96950),p=o(58914);const h=c.d.compose({name:"cs-article-card",styles:p.l,template:(0,u._)({attribution:v.qy`${i.Au}`,footerStart:v.qy`${a.xZ}`,footerEnd:v.qy`${r.IL}`,hideStory:v.qy`${s.Y}${l.Z}`,title:v.qy`${d.B2}`})});var f=o(65614);const g=()=>{(0,n.J)(),h.define(f.G.registry)}},96787(t,e,o){"use strict";function n(t){return!t.mapRawData}o.d(e,{Yd(){return n},wc(){return i}});const i=t=>({defaultLayout:t?[t]:[],C6:[],C5:[],C4:[],C3:[],C2:[],C1:[]})}}]);