(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["dev-tools"],{10300(t,e,i){"use strict";i.d(e,{I(){return r}});var n=i(56911),o=i(98228),s=i(38493);class r extends o.a{appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="outline")}}(0,n.Cg)([(0,s.CF)({mode:"fromView"}),(0,n.Sn)("design:type",String)],r.prototype,"appearance",void 0)},13988(t,e,i){"use strict";i.d(e,{m(){return I}});var n=i(56911),o=i(92011),s=i(38493),r=i(60815),a=i(55230),l=i(5096),d=i(96789);const c="single",h="multi";class u extends o.L{constructor(){super(...arguments),this.expandmode=h,this.activeItemIndex=0,this.change=()=>{this.$emit("change",this.activeid)},this.setItems=()=>{if(0!==this.accordionItems.length&&(this.accordionIds=this.getItemIds(),this.accordionItems.forEach((t,e)=>{t instanceof d.k&&(t.addEventListener("change",this.activeItemChange),this.isSingleExpandMode()&&(this.activeItemIndex!==e?t.expanded=!1:t.expanded=!0));const i=this.accordionIds[e];t.setAttribute("id","string"!=typeof i?`accordion-${e+1}`:i),this.activeid=this.accordionIds[this.activeItemIndex],t.addEventListener("keydown",this.handleItemKeyDown),t.addEventListener("focus",this.handleItemFocus)}),this.isSingleExpandMode())){(this.findExpandedItem()??this.accordionItems[0]).setAttribute("aria-disabled","true")}},this.removeItemListeners=t=>{t.forEach((t,e)=>{t.removeEventListener("change",this.activeItemChange),t.removeEventListener("keydown",this.handleItemKeyDown),t.removeEventListener("focus",this.handleItemFocus)})},this.activeItemChange=t=>{if(t.defaultPrevented||t.target!==t.currentTarget)return;t.preventDefault();const e=t.target;this.activeid=e.getAttribute("id"),this.isSingleExpandMode()&&(this.resetItems(),e.expanded=!0,e.setAttribute("aria-disabled","true"),this.accordionItems.forEach(t=>{t.hasAttribute("disabled")||t.id===this.activeid||t.removeAttribute("aria-disabled")})),this.activeItemIndex=Array.from(this.accordionItems).indexOf(e),this.change()},this.handleItemKeyDown=t=>{if(t.target===t.currentTarget)switch(this.accordionIds=this.getItemIds(),t.key){case a.I5:t.preventDefault(),this.adjust(-1);break;case a.HX:t.preventDefault(),this.adjust(1);break;case a.kE:this.activeItemIndex=0,this.focusItem();break;case a.FM:this.activeItemIndex=this.accordionItems.length-1,this.focusItem()}},this.handleItemFocus=t=>{if(t.target===t.currentTarget){const e=t.target,i=this.activeItemIndex=Array.from(this.accordionItems).indexOf(e);this.activeItemIndex!==i&&-1!==i&&(this.activeItemIndex=i,this.activeid=this.accordionIds[this.activeItemIndex])}}}accordionItemsChanged(t,e){this.$fastController.isConnected&&(this.removeItemListeners(t),this.setItems())}findExpandedItem(){for(let t=0;t<this.accordionItems.length;t++)if("true"===this.accordionItems[t].getAttribute("expanded"))return this.accordionItems[t];return null}resetItems(){this.accordionItems.forEach((t,e)=>{t.expanded=!1})}getItemIds(){return this.accordionItems.map(t=>t.getAttribute("id"))}isSingleExpandMode(){return this.expandmode===c}adjust(t){this.activeItemIndex=(0,l.Vf)(0,this.accordionItems.length-1,this.activeItemIndex+t),this.focusItem()}focusItem(){const t=this.accordionItems[this.activeItemIndex];t instanceof d.k&&t.expandbutton.focus()}}(0,n.Cg)([(0,s.CF)({attribute:"expand-mode"}),(0,n.Sn)("design:type",String)],u.prototype,"expandmode",void 0),(0,n.Cg)([r.sH,(0,n.Sn)("design:type",Array)],u.prototype,"accordionItems",void 0);var p=i(37180),g=i(74849),v=i(64187),f=i(7896),m=i(61138),x=i(48751),b=i(26920),w=i(22683);const y=g.A`
    ${(0,v.V)("flex")} :host {
        box-sizing: border-box;
        flex-direction: column;
        font-family: ${f.O};
        font-size: ${m.k};
        line-height: ${m.F};
        color: ${x.l};
        border-top: calc(${b.XA} * 1px) solid ${w.hb};
    }
`;var $=i(96950),k=i(82774),C=i(10108);const z=$.qy`
        <template>
            <slot ${(0,k.e)({property:"accordionItems",filter:(0,C.Y)()})}></slot>
        </template>
    `,I=u.compose({name:`${p.c.prefix}-accordion`,template:z,styles:y})},15183(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M9 2.5a.5.5 0 00-1 0V3c0 .4.12.77.32 1.08A3 3 0 006 7h-.5A1.5 1.5 0 014 5.5v-2a.5.5 0 00-1 0v2A2.5 2.5 0 005.5 8H6v1.5H2.5a.5.5 0 000 1H6V12h-.5A2.5 2.5 0 003 14.5v2a.5.5 0 001 0v-2c0-.83.67-1.5 1.5-1.5H6a4 4 0 008 0h.5c.83 0 1.5.67 1.5 1.5v2a.5.5 0 001 0v-2a2.5 2.5 0 00-2.5-2.5H14v-1.5h3.5a.5.5 0 000-1H14V8h.5A2.5 2.5 0 0017 5.5v-2a.5.5 0 00-1 0v2c0 .83-.67 1.5-1.5 1.5H14a3 3 0 00-2.32-2.92A2 2 0 0012 3v-.5a.5.5 0 00-1 0V3a1 1 0 11-2 0v-.5zM13 7v6a3 3 0 11-6 0V7c0-1.1.9-2 2-2h2a2 2 0 012 2z"></path></svg>'},16792(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M9 2.39a1.5 1.5 0 012 0l5.5 4.94c.32.28.5.69.5 1.12v7.05c0 .83-.67 1.5-1.5 1.5H13a1.5 1.5 0 01-1.5-1.5V12a.5.5 0 00-.5-.5H9a.5.5 0 00-.5.5v3.5c0 .83-.67 1.5-1.5 1.5H4.5A1.5 1.5 0 013 15.5V8.45c0-.43.18-.84.5-1.12L9 2.39zm1.33.74a.5.5 0 00-.66 0l-5.5 4.94a.5.5 0 00-.17.38v7.05c0 .28.22.5.5.5H7a.5.5 0 00.5-.5V12c0-.83.67-1.5 1.5-1.5h2c.83 0 1.5.67 1.5 1.5v3.5c0 .28.22.5.5.5h2.5a.5.5 0 00.5-.5V8.45a.5.5 0 00-.17-.38l-5.5-4.94z"></path></svg>'},21082(t,e,i){"use strict";i.d(e,{v(){return s}});var n=i(21743),o=i(96950);const s=(0,n.E)({indicator:o.qy`
        <svg
            class="select-indicator"
            part="select-indicator"
            viewBox="0 0 12 7"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                d="M11.85.65c.2.2.2.5 0 .7L6.4 6.84a.55.55 0 01-.78 0L.14 1.35a.5.5 0 11.71-.7L6 5.8 11.15.65c.2-.2.5-.2.7 0z"
            />
        </svg>
    `})},26629(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M4 4.09v6.41A2.5 2.5 0 006.34 13h4.57c-.2.58-.76 1-1.41 1H6a3 3 0 01-3-3V5.5c0-.65.42-1.2 1-1.41zM11.5 2c.83 0 1.5.67 1.5 1.5v7c0 .83-.67 1.5-1.5 1.5h-5A1.5 1.5 0 015 10.5v-7C5 2.67 5.67 2 6.5 2h5zm0 1h-5a.5.5 0 00-.5.5v7c0 .28.22.5.5.5h5a.5.5 0 00.5-.5v-7a.5.5 0 00-.5-.5z"></path></svg>'},32908(t,e,i){"use strict";i.r(e),i.d(e,{DevTools(){return ut},DevToolsStyles(){return ee},DevToolsTemplate(){return sn},PanelSizeType(){return at},ToolingInfo(){return rn},debugMenuStyles(){return Zt},sharedStyles(){return te}});var n=i(2958),o=i(37180),s=i(13988),r=i(49473),a=i(4731),l=i(56911),d=i(92011),c=i(23429),h=i(39957),u=i(93809),p=i(38493),g=i(60815),v=i(47429),f=i(73473),m=i(55230);const x="none",b="default",w="sticky",y="default",$="columnheader",k="rowheader",C="default",z="header",I="sticky-header",T={columnheader:"columnheader",rowheader:"rowheader",default:"gridcell"};class F extends d.L{constructor(){super(),this.noTabbing=!1,this.generateHeader=b,this.rowsData=[],this.columnDefinitions=null,this.focusRowIndex=0,this.focusColumnIndex=0,this.rowsPlaceholder=null,this.behaviorOrchestrator=null,this.generatedHeader=null,this.isUpdatingFocus=!1,this.pendingFocusUpdate=!1,this.rowindexUpdateQueued=!1,this.columnDefinitionsStale=!0,this.generatedGridTemplateColumns="",this.focusOnCell=(t,e,i)=>{if(0===this.rowElements.length)return this.focusRowIndex=0,void(this.focusColumnIndex=0);const n=Math.max(0,Math.min(this.rowElements.length-1,t)),o=this.rowElements[n].querySelectorAll('[role="cell"], [role="gridcell"], [role="columnheader"], [role="rowheader"]'),s=o[Math.max(0,Math.min(o.length-1,e))];i&&this.scrollHeight!==this.clientHeight&&(n<this.focusRowIndex&&this.scrollTop>0||n>this.focusRowIndex&&this.scrollTop<this.scrollHeight-this.clientHeight)&&s.scrollIntoView({block:"center",inline:"center"}),s.focus()},this.onChildListChange=(t,e)=>{t&&t.length&&(t.forEach(t=>{t.addedNodes.forEach(t=>{1===t.nodeType&&"row"===t.getAttribute("role")&&(t.columnDefinitions=this.columnDefinitions)})}),this.queueRowIndexUpdate())},this.queueRowIndexUpdate=()=>{this.rowindexUpdateQueued||(this.rowindexUpdateQueued=!0,c.L.enqueue(this.updateRowIndexes))},this.updateRowIndexes=()=>{let t=this.gridTemplateColumns;if(void 0===t){if(""===this.generatedGridTemplateColumns&&this.rowElements.length>0){const t=this.rowElements[0];this.generatedGridTemplateColumns=new Array(t.cellElements.length).fill("1fr").join(" ")}t=this.generatedGridTemplateColumns}this.rowElements.forEach((e,i)=>{const n=e;n.rowIndex=i,n.gridTemplateColumns=t,this.columnDefinitionsStale&&(n.columnDefinitions=this.columnDefinitions)}),this.rowindexUpdateQueued=!1,this.columnDefinitionsStale=!1}}static generateTemplateColumns(t){let e="";return t.forEach(t=>{e=`${e}${""===e?"":" "}1fr`}),e}noTabbingChanged(){this.$fastController.isConnected&&(this.noTabbing?this.setAttribute("tabIndex","-1"):this.setAttribute("tabIndex",this.contains(document.activeElement)||this===document.activeElement?"-1":"0"))}generateHeaderChanged(){this.$fastController.isConnected&&this.toggleGeneratedHeader()}gridTemplateColumnsChanged(){this.$fastController.isConnected&&this.updateRowIndexes()}rowsDataChanged(){null===this.columnDefinitions&&this.rowsData.length>0&&(this.columnDefinitions=F.generateColumns(this.rowsData[0])),this.$fastController.isConnected&&this.toggleGeneratedHeader()}columnDefinitionsChanged(){null!==this.columnDefinitions?(this.generatedGridTemplateColumns=F.generateTemplateColumns(this.columnDefinitions),this.$fastController.isConnected&&(this.columnDefinitionsStale=!0,this.queueRowIndexUpdate())):this.generatedGridTemplateColumns=""}headerCellItemTemplateChanged(){this.$fastController.isConnected&&null!==this.generatedHeader&&(this.generatedHeader.headerCellItemTemplate=this.headerCellItemTemplate)}focusRowIndexChanged(){this.$fastController.isConnected&&this.queueFocusUpdate()}focusColumnIndexChanged(){this.$fastController.isConnected&&this.queueFocusUpdate()}connectedCallback(){super.connectedCallback(),void 0===this.rowItemTemplate&&(this.rowItemTemplate=this.defaultRowItemTemplate),null===this.behaviorOrchestrator&&(this.behaviorOrchestrator=v.yF.create(this),this.$fastController.addBehavior(this.behaviorOrchestrator),this.behaviorOrchestrator.addBehaviorFactory(new h.RR((0,u.U)(t=>t.rowsData),(0,u.U)(t=>t.rowItemTemplate),{positioning:!0}),this.appendChild(this.rowsPlaceholder=document.createComment("")))),this.toggleGeneratedHeader(),this.addEventListener("row-focused",this.handleRowFocus),this.addEventListener(f.bt,this.handleFocus),this.addEventListener(f.Gh,this.handleKeydown),this.addEventListener(f.b4,this.handleFocusOut),this.observer=new MutationObserver(this.onChildListChange),this.observer.observe(this,{childList:!0}),this.noTabbing&&this.setAttribute("tabindex","-1"),c.L.enqueue(this.queueRowIndexUpdate)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("row-focused",this.handleRowFocus),this.removeEventListener(f.bt,this.handleFocus),this.removeEventListener(f.Gh,this.handleKeydown),this.removeEventListener(f.b4,this.handleFocusOut),this.observer.disconnect(),this.generatedHeader=null}handleRowFocus(t){this.isUpdatingFocus=!0;const e=t.target;this.focusRowIndex=this.rowElements.indexOf(e),this.focusColumnIndex=e.focusColumnIndex,this.setAttribute("tabIndex","-1"),this.isUpdatingFocus=!1}handleFocus(t){this.focusOnCell(this.focusRowIndex,this.focusColumnIndex,!0)}handleFocusOut(t){null!==t.relatedTarget&&this.contains(t.relatedTarget)||this.setAttribute("tabIndex",this.noTabbing?"-1":"0")}handleKeydown(t){if(t.defaultPrevented)return;let e;const i=this.rowElements.length-1,n=this.offsetHeight+this.scrollTop,o=this.rowElements[i];switch(t.key){case m.I5:t.preventDefault(),this.focusOnCell(this.focusRowIndex-1,this.focusColumnIndex,!0);break;case m.HX:t.preventDefault(),this.focusOnCell(this.focusRowIndex+1,this.focusColumnIndex,!0);break;case m.oK:if(t.preventDefault(),0===this.rowElements.length){this.focusOnCell(0,0,!1);break}if(0===this.focusRowIndex)return void this.focusOnCell(0,this.focusColumnIndex,!1);for(e=this.focusRowIndex-1;e>=0;e--){const t=this.rowElements[e];if(t.offsetTop<this.scrollTop){this.scrollTop=t.offsetTop+t.clientHeight-this.clientHeight;break}}this.focusOnCell(e,this.focusColumnIndex,!1);break;case m.f_:if(t.preventDefault(),0===this.rowElements.length){this.focusOnCell(0,0,!1);break}if(this.focusRowIndex>=i||o.offsetTop+o.offsetHeight<=n)return void this.focusOnCell(i,this.focusColumnIndex,!1);for(e=this.focusRowIndex+1;e<=i;e++){const t=this.rowElements[e];if(t.offsetTop+t.offsetHeight>n){let e=0;this.generateHeader===w&&null!==this.generatedHeader&&(e=this.generatedHeader.clientHeight),this.scrollTop=t.offsetTop-e;break}}this.focusOnCell(e,this.focusColumnIndex,!1);break;case m.kE:t.ctrlKey&&(t.preventDefault(),this.focusOnCell(0,0,!0));break;case m.FM:t.ctrlKey&&null!==this.columnDefinitions&&(t.preventDefault(),this.focusOnCell(this.rowElements.length-1,this.columnDefinitions.length-1,!0))}}queueFocusUpdate(){this.isUpdatingFocus&&(this.contains(document.activeElement)||this===document.activeElement)||!1===this.pendingFocusUpdate&&(this.pendingFocusUpdate=!0,c.L.enqueue(()=>this.updateFocus()))}updateFocus(){this.pendingFocusUpdate=!1,this.focusOnCell(this.focusRowIndex,this.focusColumnIndex,!0)}toggleGeneratedHeader(){if(null!==this.generatedHeader&&(this.removeChild(this.generatedHeader),this.generatedHeader=null),this.generateHeader!==x&&this.rowsData.length>0){const t=document.createElement(this.rowElementTag);return this.generatedHeader=t,this.generatedHeader.columnDefinitions=this.columnDefinitions,this.generatedHeader.gridTemplateColumns=this.gridTemplateColumns,this.generatedHeader.rowType=this.generateHeader===w?I:z,void(null===this.firstChild&&null===this.rowsPlaceholder||this.insertBefore(t,null!==this.firstChild?this.firstChild:this.rowsPlaceholder))}}}F.generateColumns=t=>Object.getOwnPropertyNames(t).map((t,e)=>({columnDataKey:t,gridColumn:`${e}`})),(0,l.Cg)([(0,p.CF)({attribute:"no-tabbing",mode:"boolean"}),(0,l.Sn)("design:type",Boolean)],F.prototype,"noTabbing",void 0),(0,l.Cg)([(0,p.CF)({attribute:"generate-header"}),(0,l.Sn)("design:type",String)],F.prototype,"generateHeader",void 0),(0,l.Cg)([(0,p.CF)({attribute:"grid-template-columns"}),(0,l.Sn)("design:type",String)],F.prototype,"gridTemplateColumns",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Array)],F.prototype,"rowsData",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Object)],F.prototype,"columnDefinitions",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Function)],F.prototype,"rowItemTemplate",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Function)],F.prototype,"cellItemTemplate",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Function)],F.prototype,"headerCellItemTemplate",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Number)],F.prototype,"focusRowIndex",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Number)],F.prototype,"focusColumnIndex",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Function)],F.prototype,"defaultRowItemTemplate",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",String)],F.prototype,"rowElementTag",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Array)],F.prototype,"rowElements",void 0);var A=i(74849);const M=A.A`
    :host {
        display: flex;
        position: relative;
        flex-direction: column;
    }
`;var E=i(96950),D=i(416),O=i(10108),S=i(87656);class B extends d.L{constructor(){super(...arguments),this.rowType=C,this.rowData=null,this.columnDefinitions=null,this.isActiveRow=!1,this.behaviorOrchestrator=null,this.focusColumnIndex=0,this.refocusOnLoad=!1,this.updateRowStyle=()=>{this.style.gridTemplateColumns=this.gridTemplateColumns}}gridTemplateColumnsChanged(){this.$fastController.isConnected&&this.updateRowStyle()}rowTypeChanged(){this.$fastController.isConnected&&this.updateItemTemplate()}rowDataChanged(){null!==this.rowData&&this.isActiveRow&&(this.refocusOnLoad=!0)}cellItemTemplateChanged(){this.updateItemTemplate()}headerCellItemTemplateChanged(){this.updateItemTemplate()}connectedCallback(){super.connectedCallback(),null===this.behaviorOrchestrator&&(this.updateItemTemplate(),this.behaviorOrchestrator=v.yF.create(this),this.$fastController.addBehavior(this.behaviorOrchestrator),this.behaviorOrchestrator.addBehaviorFactory(new h.RR((0,u.U)(t=>t.columnDefinitions),(0,u.U)(t=>t.activeCellItemTemplate),{positioning:!0}),this.appendChild(document.createComment("")))),this.addEventListener("cell-focused",this.handleCellFocus),this.addEventListener(f.b4,this.handleFocusout),this.addEventListener(f.Gh,this.handleKeydown),this.updateRowStyle(),this.refocusOnLoad&&(this.refocusOnLoad=!1,this.cellElements.length>this.focusColumnIndex&&this.cellElements[this.focusColumnIndex].focus())}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("cell-focused",this.handleCellFocus),this.removeEventListener(f.b4,this.handleFocusout),this.removeEventListener(f.Gh,this.handleKeydown)}handleFocusout(t){this.contains(t.target)||(this.isActiveRow=!1,this.focusColumnIndex=0)}handleCellFocus(t){this.isActiveRow=!0,this.focusColumnIndex=this.cellElements.indexOf(t.target),this.$emit("row-focused",this)}handleKeydown(t){if(t.defaultPrevented)return;let e=0;switch(t.key){case m.kT:e=Math.max(0,this.focusColumnIndex-1),this.cellElements[e].focus(),t.preventDefault();break;case m.bb:e=Math.min(this.cellElements.length-1,this.focusColumnIndex+1),this.cellElements[e].focus(),t.preventDefault();break;case m.kE:t.ctrlKey||(this.cellElements[0].focus(),t.preventDefault());break;case m.FM:t.ctrlKey||(this.cellElements[this.cellElements.length-1].focus(),t.preventDefault())}}updateItemTemplate(){this.activeCellItemTemplate=this.rowType===C&&void 0!==this.cellItemTemplate?this.cellItemTemplate:this.rowType===C&&void 0===this.cellItemTemplate?this.defaultCellItemTemplate:void 0!==this.headerCellItemTemplate?this.headerCellItemTemplate:this.defaultHeaderCellItemTemplate}}(0,l.Cg)([(0,p.CF)({attribute:"grid-template-columns"}),(0,l.Sn)("design:type",String)],B.prototype,"gridTemplateColumns",void 0),(0,l.Cg)([(0,p.CF)({attribute:"row-type"}),(0,l.Sn)("design:type",String)],B.prototype,"rowType",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Object)],B.prototype,"rowData",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Object)],B.prototype,"columnDefinitions",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",E.kc)],B.prototype,"cellItemTemplate",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",E.kc)],B.prototype,"headerCellItemTemplate",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Number)],B.prototype,"rowIndex",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Boolean)],B.prototype,"isActiveRow",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",E.kc)],B.prototype,"activeCellItemTemplate",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",E.kc)],B.prototype,"defaultCellItemTemplate",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",E.kc)],B.prototype,"defaultHeaderCellItemTemplate",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Array)],B.prototype,"cellElements",void 0);var H=i(22131),R=i(26920),V=i(22683),L=i(37302);const j=A.A`
    :host {
        display: grid;
        padding: 1px 0;
        box-sizing: border-box;
        width: 100%;
        border-bottom: calc(${R.XA} * 1px) solid ${V.hb};
    }

    :host(.header) {
    }

    :host([cell-type="sticky-header"]) {
        background: ${L.F7};
        position: sticky;
        top: 0;
    }
`.withBehaviors((0,H.mr)(A.A`
            :host {
            }
        `));var P=i(82774);const N=E.qy`
    <template>
        ${t=>null===t.rowData||null===t.columnDefinition||null===t.columnDefinition.columnDataKey?null:t.rowData[t.columnDefinition.columnDataKey]}
    </template>
`,W=E.qy`
    <template>
        ${t=>null===t.columnDefinition?null:void 0===t.columnDefinition.title?t.columnDefinition.columnDataKey:t.columnDefinition.title}
    </template>
`;class U extends d.L{constructor(){super(...arguments),this.cellType=y,this.rowData=null,this.columnDefinition=null,this.isActiveCell=!1,this.customCellView=null,this.updateCellStyle=()=>{this.style.gridColumn=this.gridColumn}}cellTypeChanged(){this.$fastController.isConnected&&this.updateCellView()}gridColumnChanged(){this.$fastController.isConnected&&this.updateCellStyle()}columnDefinitionChanged(t,e){this.$fastController.isConnected&&this.updateCellView()}connectedCallback(){super.connectedCallback(),this.addEventListener(f.ks,this.handleFocusin),this.addEventListener(f.b4,this.handleFocusout),this.addEventListener(f.Gh,this.handleKeydown),this.style.gridColumn=`${void 0===this.columnDefinition?.gridColumn?0:this.columnDefinition.gridColumn}`,this.updateCellView(),this.updateCellStyle()}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener(f.ks,this.handleFocusin),this.removeEventListener(f.b4,this.handleFocusout),this.removeEventListener(f.Gh,this.handleKeydown),this.disconnectCellView()}handleFocusin(t){if(!this.isActiveCell){if(this.isActiveCell=!0,this.cellType===$){if(null!==this.columnDefinition&&!0!==this.columnDefinition.headerCellInternalFocusQueue&&"function"==typeof this.columnDefinition.headerCellFocusTargetCallback){const t=this.columnDefinition.headerCellFocusTargetCallback(this);null!==t&&t.focus()}}else if(null!==this.columnDefinition&&!0!==this.columnDefinition.cellInternalFocusQueue&&"function"==typeof this.columnDefinition.cellFocusTargetCallback){const t=this.columnDefinition.cellFocusTargetCallback(this);null!==t&&t.focus()}this.$emit("cell-focused",this)}}handleFocusout(t){this===document.activeElement||this.contains(document.activeElement)||(this.isActiveCell=!1)}handleKeydown(t){if(!(t.defaultPrevented||null===this.columnDefinition||this.cellType===y&&!0!==this.columnDefinition.cellInternalFocusQueue||this.cellType===$&&!0!==this.columnDefinition.headerCellInternalFocusQueue))switch(t.key){case m.Mm:case m.Ac:if(this.contains(document.activeElement)&&document.activeElement!==this)return;if(this.cellType===$){if(void 0!==this.columnDefinition.headerCellFocusTargetCallback){const e=this.columnDefinition.headerCellFocusTargetCallback(this);null!==e&&e.focus(),t.preventDefault()}}else if(void 0!==this.columnDefinition.cellFocusTargetCallback){const e=this.columnDefinition.cellFocusTargetCallback(this);null!==e&&e.focus(),t.preventDefault()}break;case m.F9:this.contains(document.activeElement)&&document.activeElement!==this&&(this.focus(),t.preventDefault())}}updateCellView(){if(this.disconnectCellView(),null!==this.columnDefinition)switch(this.cellType){case $:this.customCellView=E.qy`
                    ${this.columnDefinition.headerCellTemplate??W}
                `.render(this,this);break;case void 0:case k:case y:this.customCellView=E.qy`
                    ${this.columnDefinition.cellTemplate??N}
                `.render(this,this)}}disconnectCellView(){null!==this.customCellView&&(this.customCellView.dispose(),this.customCellView=null)}}(0,l.Cg)([(0,p.CF)({attribute:"cell-type"}),(0,l.Sn)("design:type",String)],U.prototype,"cellType",void 0),(0,l.Cg)([(0,p.CF)({attribute:"grid-column"}),(0,l.Sn)("design:type",String)],U.prototype,"gridColumn",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Object)],U.prototype,"rowData",void 0),(0,l.Cg)([g.sH,(0,l.Sn)("design:type",Object)],U.prototype,"columnDefinition",void 0);var X=i(73477),G=i(50882),J=i(74838),K=i(48751),Y=i(7896),_=i(41123),q=i(57416),Q=i(14996);const Z=A.A`
    :host {
        padding: calc(${J.vR} * 1px) calc(${J.vR} * 3px);
        color: ${K.l};
        box-sizing: border-box;
        font-family: ${Y.O};
        font-size: ${_.K};
        line-height: ${_.Z};
        font-weight: 400;
        border: transparent calc(${R.XA} * 1px) solid;
        overflow: hidden;
        white-space: nowrap;
        border-radius: calc(${q.Pb} * 1px);
    }

    :host([cell-type="column-header"]) {
        font-weight: 600;
    }

    :host(:${X.N}) {
        border: ${Q.WN} calc(${R.XA} * 1px) solid;
        color: ${K.l};
    }
`.withBehaviors((0,H.mr)(A.A`
            :host {
                forced-color-adjust: none;
                border-color: transparent;
                background: ${G.A.Field};
                color: ${G.A.FieldText};
            }

            :host(:${X.N}) {
                border-color: ${G.A.FieldText};
                box-shadow: 0 0 0 2px inset ${G.A.Field};
                color: ${G.A.FieldText};
            }
        `)),tt=E.qy`
        <template
            tabindex="-1"
            role="${t=>T[t.cellType]??T.default}"
        >
            <slot></slot>
        </template>
    `,et=U.compose({name:`${o.c.prefix}-data-grid-cell`,template:tt,styles:Z}),it=(nt={dataGridCell:et},E.qy`
        <template
            role="row"
            :defaultCellItemTemplate="${function(t){const e=E.qy.partial((0,S.g)(t.dataGridCell));return E.qy`
    <${e}
        cell-type="${t=>t.isRowHeader?"rowheader":void 0}"
        grid-column="${(t,e)=>e.index+1}"
        :rowData="${(t,e)=>e.parent.rowData}"
        :columnDefinition="${t=>t}"
    ></${e}>
`}(nt)}"
            :defaultHeaderCellItemTemplate="${function(t){const e=E.qy.partial((0,S.g)(t.dataGridCell));return E.qy`
    <${e}
        cell-type="columnheader"
        grid-column="${(t,e)=>e.index+1}"
        :columnDefinition="${t=>t}"
    ></${e}>
`}(nt)}"
            ${(0,D.Y)({property:"cellElements",filter:(0,O.Y)('[role="cell"],[role="gridcell"],[role="columnheader"],[role="rowheader"]')})}
        >
            <slot ${(0,P.e)("slottedCellElements")}></slot>
        </template>
    `);var nt;const ot=B.compose({name:`${o.c.prefix}-data-grid-row`,template:it,styles:j}),st=function(t){const e=(0,S.g)(t.dataGridRow);return E.qy`
        <template
            role="grid"
            tabindex="0"
            :rowElementTag="${e}"
            :defaultRowItemTemplate="${function(t){const e=E.qy.partial((0,S.g)(t.dataGridRow));return E.qy`
    <${e}
        :rowData="${t=>t}"
        :cellItemTemplate="${(t,e)=>e.parent.cellItemTemplate}"
        :headerCellItemTemplate="${(t,e)=>e.parent.headerCellItemTemplate}"
    ></${e}>
`}(t)}"
            ${(0,D.Y)({property:"rowElements",filter:(0,O.Y)("[role=row]")})}
        >
            <slot></slot>
        </template>
    `}({dataGridRow:ot}),rt=F.compose({name:`${o.c.prefix}-data-grid`,template:st,styles:M});var at,lt=i(48785);!function(t){t.collapsed="collapsed",t.expanded="expanded",t.fullscreen="fullscreen"}(at||(at={}));var dt=i(12680),ct=i(39671),ht=i(58792);class ut extends ct.U{async experienceConnected(){if(this.panelSize=at.collapsed,this.appErrors=[],this.activeWidgetId=null,this.widgetList=Object.values(this.config.widgetConfigs),this.isActivated=!0,this.appErrorsCnt=0,this.interceptConsole(),this.markVisuallyReady(),!window.clarity){const t=await i.e("clarity").then(i.bind(i,5339));document.documentElement&&document.documentElement.setAttribute("data-clarity-unmask","true"),await t.getClarityScript("https://www.clarity.ms/tag/gcpi4k69ra"),ht.T3.ClarityEnabled=!0,t.writeBasicTags()}}disconnectedCallback(){super.disconnectedCallback()}getExperienceType(){return dt.O_p}togglePanel(){this.panelSize===at.collapsed?this.panelSize=at.expanded:this.panelSize=at.collapsed}toggleFullscreen(){this.panelSize===at.fullscreen?this.panelSize=at.expanded:this.panelSize=at.fullscreen}updateActiveWigdetId(t){this.activeWidgetId=t}interceptConsole(){var t=this;const e=window.console.error;window.console.error=function(){for(var i=arguments.length,n=new Array(i),o=0;o<i;o++)n[o]=arguments[o];e.apply(window.console,n),n.length&&"string"==typeof n[0]&&t.isAppError(n[0])&&(t.appErrors.push(n[0]),t.appErrorsCnt+=1)}}isAppError(t){return t.includes(this.config.appErrorFlag)}get panelTitle(){const t=this.widgetList.find(t=>t.id===this.activeWidgetId);return t?t.title:this.config.homeTitle}}(0,l.Cg)([g.sH],ut.prototype,"isActivated",void 0),(0,l.Cg)([g.sH],ut.prototype,"renderFeedXRay",void 0),(0,l.Cg)([g.sH],ut.prototype,"renderDevToolsPanel",void 0),(0,l.Cg)([g.sH],ut.prototype,"panelSize",void 0),(0,l.Cg)([g.sH],ut.prototype,"appErrors",void 0),(0,l.Cg)([g.sH],ut.prototype,"appErrorsCnt",void 0),(0,l.Cg)([g.sH],ut.prototype,"activeWidgetId",void 0),(0,l.Cg)([g.sH],ut.prototype,"widgetList",void 0),(0,l.Cg)([g.Jg],ut.prototype,"panelTitle",null);var pt=i(69259),gt=i(7813),vt=i(34188),ft=i(96293),mt=i(72454),xt=i(32625),bt=i(39692),wt=i(29194),yt=i(35727),$t=i(22020);class kt{constructor(t){this.directive=t,this.location=null,this.controller=null,this.view=null,this.data=null,this.dataBindingObserver=t.dataBinding.createObserver(this,t),this.templateBindingObserver=t.templateBinding.createObserver(this,t)}bind(t){if(this.location=t.targets[this.directive.targetNodeId],this.controller=t,this.data=this.dataBindingObserver.bind(t),this.template=this.templateBindingObserver.bind(t),t.onUnbind(this),(0,vt.VS)(this.template)&&(0,vt.VS)(t)&&t.hydrationStage!==$t.xW.hydrated&&!this.view){const e=t.bindingViewBoundaries[this.directive.targetNodeId];e&&(this.view=this.template.hydrate(e.first,e.last),this.bindView(this.view))}else this.refreshView()}unbind(t){const e=this.view;null!==e&&e.isComposed&&(e.unbind(),e.needsBindOnly=!0)}handleChange(t,e){e===this.dataBindingObserver&&(this.data=this.dataBindingObserver.bind(this.controller)),(this.directive.templateBindingDependsOnData||e===this.templateBindingObserver)&&(this.template=this.templateBindingObserver.bind(this.controller)),this.refreshView()}bindView(t){t.isComposed?t.needsBindOnly&&(t.needsBindOnly=!1,t.bind(this.data)):(t.isComposed=!0,t.bind(this.data),t.insertBefore(this.location),t.$fastTemplate=this.template)}refreshView(){let t=this.view;const e=this.template;null===t?(this.view=t=e.create(),this.view.context.parent=this.controller.source,this.view.context.parentContext=this.controller.context):t.$fastTemplate!==e&&(t.isComposed&&(t.remove(),t.unbind()),this.view=t=e.create(),this.view.context.parent=this.controller.source,this.view.context.parentContext=this.controller.context),this.bindView(t)}}class Ct{constructor(t,e,i){this.dataBinding=t,this.templateBinding=e,this.templateBindingDependsOnData=i}createHTML(t){return yt.VK.comment(t(this))}createBehavior(){return new kt(this)}}wt.dg.define(Ct);const zt=new Map,It={":model"(t){return t}},Tt=Symbol("RenderInstruction"),Ft="default-view",At=E.qy`
    &nbsp;
`;function Mt(t){return void 0===t?At:t.template}function Et(t,e){const i=[],n=[],{attributes:o,directives:s,content:r,policy:a}=null!=e?e:{};if(i.push(`<${t}`),o){const t=Object.getOwnPropertyNames(o);for(let e=0,s=t.length;e<s;++e){const s=t[e];0===e?i[0]=`${i[0]} ${s}="`:i.push(`" ${s}="`),n.push(o[s])}i.push('"')}if(s){i[i.length-1]+=" ";for(let t=0,e=s.length;t<e;++t){const e=s[t];i.push(t>0?"":" "),n.push(e)}}if(i[i.length-1]+=">",r&&(0,ft.Tn)(r.create))n.push(r),i.push(`</${t}>`);else{const e=i.length-1;i[e]=`${i[e]}${null!=r?r:""}</${t}>`}return E.kc.create(i,n,a)}function Dt(t){var e;const i=null!==(e=t.name)&&void 0!==e?e:Ft;let n;if((o=t).element||o.tagName){let e=t.tagName;if(!e){const i=gt.I.getByType(t.element);if(!i)throw new Error("Invalid element for model rendering.");e=i.name}t.attributes||(t.attributes=It),n=Et(e,t)}else n=t.template;var o;return{brand:Tt,type:t.type,name:i,template:n}}function Ot(t){return t&&t.brand===Tt}function St(t){let e=zt.get(t.type);void 0===e&&zt.set(t.type,e=Object.create(null));const i=Ot(t)?t:Dt(t);return e[i.name]=i}function Bt(t,e){const i=zt.get(t);if(void 0!==i)return i[null!=e?e:Ft]}function Ht(t,e){if(t)return Bt(t.constructor,e)}Object.freeze({instanceOf:Ot,create:Dt,createElementTemplate:Et,register:St,getByType:Bt,getForInstance:Ht});class Rt{constructor(t){this.node=t,t.$fastTemplate=this}get context(){return this}bind(t){}unbind(){}insertBefore(t){t.parentNode.insertBefore(this.node,t)}remove(){this.node.parentNode.removeChild(this.node)}create(){return this}hydrate(t,e){return this}}var Vt=i(45476);const Lt=A.A` :host{flex:1;display:flex;overflow:hidden;height:100%}.buttons{flex:1;display:flex;flex-direction:column;overflow:auto}.detail{flex:1;overflow:auto}.config-button::part(content){width:100%;display:grid;grid-template-columns:1fr 1fr}.active{background:${Vt.wO}}fluent-button{background:${Vt.Wl}}json-viewer{height:100%;box-sizing:border-box;font-size:14px;--string-color:#219f17}`,jt=A.A` :host{--fill-color:rgba(0,0,0,0);--color:#1A1A1A;--string-color:#3a8625;--number-color:#ca1b1b;--boolean-color:#4ba7ef;--null-color:#d871f7;--property-color:#0d89a9;--font-family:monospace;--preview-color:#f08a34cf;--highlight-color:#7b0000;display:block;background-color:var(--fill-color);color:var(--color);padding:0.5rem;font-family:var(--font-family);font-size:inherit}.preview{color:var(--preview-color)}.null{color:var(--null-color,#df9cf3)}.key{padding-left:25px;color:var(--property-color,#f9857b);display:inline-block}.collapsable:before{display:inline-block;color:var(--color);padding-right:5px;padding-left:5px;font-size:0.7rem;content:"▶";transition:transform 195ms ease-in;transform:rotate(90deg);color:var(--property-color)}.collapsable.collapsableCollapsed:before{transform:rotate(0)}.collapsable{padding-left:0px;cursor:pointer;user-select:none}.string{color:var(--string-color)}.number{color:var(--number-color)}.boolean{color:var(--boolean-color)}ul{padding:0;clear:both;margin:0}ul,li{list-style:none;position:relative}li ul > li{position:relative;margin-left:1.5rem;padding-left:0px}mark{background-color:var(--highlight-color)}`,Pt=E.qy` ${t=>t.render()}`;function Nt(t){return!!t&&!!t.nodeType}function Wt(t){return function(t){return t!==Object(t)}(t)||Nt(t)}let Ut=class extends d.L{constructor(){super(...arguments),this.expanded={}}connectedCallback(){super.connectedCallback()}toggleExpand(t){return()=>{const e=!this.expanded[t];this.expanded={...this.expanded,[t]:e}}}renderObject(t,e){return g.cP.track(this,"expanded"),E.qy`
            <ul>
                ${(0,h.ux)(()=>Object.keys(t),E.qy`${i=>{const n=t[i],o=e?`${e}.${i}`:i,s=Wt(n),r=this.expanded[o]||s;return E.qy`
                            <li
                                data-path=${o}
                                @click=${()=>this.toggleExpand(o)}
                            >
                                ${this.renderPropertyKey({isCollapsable:!s,collapsed:!this.expanded[o],key:i,onClick:this.toggleExpand(o)})}
                                ${r?this.renderNode(n,o):this.renderNodePreview(n)}
                            </li>
                        `}}`)}
            </ul>
        `}renderNode(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"";return Wt(t)?this.renderValue(t):this.renderObject(t,e)}renderNodePreview(t){return E.qy`
            <span class="preview"> ${function(t){return Array.isArray(t)?"[...]":"{...}"}(t)} </span>
        `}renderPropertyKey(t){let{isCollapsable:e,collapsed:i,onClick:n,key:o}=t;return E.qy`
            <span
                class="${function(){for(var t=arguments.length,e=new Array(t),i=0;i<t;i++)e[i]=arguments[i];return e.filter(Boolean).join(" ")}(o&&"key",e&&"collapsable",i&&"collapsableCollapsed")}"
                @click=${e?n:null}
            >
                ${o}:
            </span>
        `}renderValue(t){var e;return Nt(t)?t:E.qy`
                  <span tabindex="0" class=${e=t,null===e?"null":Array.isArray(e)?"array":typeof e}
                      >${JSON.stringify(t)}</span
                  >
              `}render(){return E.qy` ${this.renderNode(this.data)} `}};(0,l.Cg)([g.sH],Ut.prototype,"data",void 0),(0,l.Cg)([g.sH],Ut.prototype,"expanded",void 0),Ut=(0,l.Cg)([(0,d.E)({name:"json-viewer",template:Pt,styles:jt})],Ut);const Xt=E.qy`<div class="buttons">${(0,h.ux)(t=>t.configItems,E.qy`<fluent-button class="config-button ${(t,e)=>t.configRef===e.parent.activeConfig.configRef?"active":""}" appearance="outline" @click=${(t,e)=>e.parent.updateActiveConfig(t)}><div class="experience-type">${t=>t.configRef.experienceType}</div><div class="instance-src">${t=>t.configRef.instanceSrc}</div></fluent-button>`)}</div>`,Gt=E.qy`<div class="detail"><json-viewer :data=${t=>{var e;return null===(e=t.activeConfig)||void 0===e||null===(e=e.configWrapper)||void 0===e?void 0:e.properties}}></json-viewer></div>`,Jt=E.qy` ${Xt} ${Gt}
`;var Kt=i(50645);let Yt=class extends d.L{async connectedCallback(){if(super.connectedCallback(),this.updateConfigMap(),this.updateConfigItems(),0===this.configItems.length){const t={experienceType:"edgeChromium"===ht.T3.AppType?"EdgeChromiumPageWC":"WindowsPage",instanceSrc:"default"};await this.initLocalConfigs(t)}this.sortConfigItems(),!this.activeConfig&&this.configItems.length>0&&(this.activeConfig=this.configItems[0])}async initLocalConfigs(t){const e=[],i=await Kt.L.getConfig(t),n={configRef:t,configWrapper:i};e.push(n),this.activeConfig||(this.activeConfig=n);const o=i&&i.properties,s=o&&(o.childRefs||o.slots);s&&"object"==typeof s&&Object.values(s).map(async t=>{this.initLocalConfigs(t.configRef)}),this.configItems?this.configItems=[...this.configItems,...e]:this.configItems=e,this.sortConfigItems()}updateConfigMap(){const t=Kt.L.getInstance().getConfigResolver().getConfigServiceObject();this.configMap=t.getConfigMap()}updateConfigItems(){const t=[];this.configMap.forEach((e,i)=>{const n=this.getConfigRefFromKey(i),o={experienceType:n.experienceType,properties:e.properties,typeVersion:"Git",_name:i};t.push({configRef:n,configWrapper:o})}),this.configItems=t}sortConfigItems(){this.configItems.sort((t,e)=>t.configRef.experienceType>=e.configRef.experienceType?1:-1)}updateActiveConfig(t){this.activeConfig=t}getConfigRefFromKey(t){if(!t)return null;const[e,i,n]=t.split("/");return{experienceType:i,instanceSrc:n}}};(0,l.Cg)([g.sH],Yt.prototype,"configMap",void 0),(0,l.Cg)([g.sH],Yt.prototype,"configItems",void 0),(0,l.Cg)([g.sH],Yt.prototype,"activeConfig",void 0),Yt=(0,l.Cg)([(0,d.E)({name:"app-configs",template:Jt,styles:Lt})],Yt);var _t=i(92393),qt=i(95639),Qt=i(37998);const Zt=" .debug-menu{background:#FFFFFF;border-radius:6px;bottom:2px;box-shadow:0px 10px 15px -3px rgba(0,0,0,0.1),0px 0px 7px 4px rgba(0,0,0,0.1);display:flex;flex-direction:column;padding:10px 5px;position:absolute;right:0;width:max-content}fluent-switch{display:flex;flex-direction:row-reverse;gap:5px;justify-content:flex-end}@media (prefers-color-scheme:dark){.debug-menu{background:#424242}}",te=A.A` .link{font-size:inherit;font-weight:inherit;color:${_t.W_};outline:none;text-decoration:none}.link:hover{color:${_t.YL}}.link:active{color:${_t.QL}}[row-type="default"]:hover{background:${Vt.oO};
        color: ${K.l}}[role="gridcell"],[role="columnheader"]{font-size:inherit}svg{fill:${_t.W_};
        height: 20px;
        width: 20px;
    }
`,ee=A.A`
    ${te} :host{--direction:ltr;--elevation:4;--neutral-fill-stealth-rest:${qt.Ef}}.badge{position:absolute;top:-10px;z-index:auto;width:20px;height:20px;color:#fff;font-weight:400;font-size:12px;line-height:20px;white-space:nowrap;text-align:center;background:#ff4d4f;border-radius:10px;box-shadow:0 0 0 1px #fff;left:-10px}.debug-menu-toggle-button{position:fixed;z-index:999;bottom:0;text-align:center;border:1px solid rgba(0,0,0,0.15);${Qt.ET}
        border-bottom: 0;
        border-radius: 5px 5px 0 0;
        background-color: ${qt.Ef};text-align:center;height:32px;width:32px;display:flex;right:128px}.icon-button{background:rgba(0,0,0,0);overflow:hidden;border-radius:inherit}.panel{width:100%;position:fixed;bottom:0;left:0;transition:all 0.25s ease-in-out;flex-direction:column;${Qt.ET}
        align-items: center;
        border-top: 1px solid rgba(0, 0, 0, 0.15);
        background-color: ${qt.Ef};z-index:899;display:flex}.panel.collapsed{height:0}.panel.expanded{height:30vh}.panel.fullscreen{height:100vh}.panel > .header{height:40px;width:100%;display:flex;justify-content:space-between;${Qt.ET} box-sizing:border-box;padding:0 6px;flex-wrap:nowrap;z-index:1}.panel > .content{display:flex;box-sizing:border-box;width:100%;height:100%;overflow:auto;overscroll-behavior:contain}.panel > .content > .button-list{padding:8px;display:flex;flex-wrap:wrap;overflow:auto;width:100%;align-content:start}.panel > .header > .left{display:flex;height:100%;align-items:center}.panel > .header > .right{display:flex;height:100%;align-items:center}.panel > .header > .left > .title{font-size:1.4em;font-weight:600;margin-inline-start:10px;white-space:nowrap}.widget-button{${Qt.ET} display:flex;align-items:center;justify-content:center;border-radius:5px;cursor:pointer;text-align:center;height:110px;width:180px;border:none;font-size:inherit;font-weight:600;margin:8px}.app-errors-title{font-weight:500;color:rgb(233,30,30)}`,ie=A.A`
    ${te} :host{flex:1}.column-header,[role="gridcell"]{text-align:center}`,ne=E.qy`<fluent-data-grid-row row-type="sticky-header" grid-template-columns="1fr 1fr 2fr 5fr" :columnDefinitions=${t=>t.columns}></fluent-data-grid-row>${(0,h.ux)(t=>t.appErrorItems,E.qy`<fluent-data-grid-row grid-template-columns="1fr 1fr 2fr 5fr" :rowData=${t=>t} :columnDefinitions=${(t,e)=>e.parent.columns}></fluent-data-grid-row>`)}
`;let oe=class extends d.L{connectedCallback(){super.connectedCallback(),this.columns=this.config.columns,this.updateAppErrorItems()}updateAppErrorItems(){var t;const e=[];null===(t=this.appErrors)||void 0===t||t.map(t=>{const i=t.indexOf("{"),n=t.lastIndexOf("}");if(i&&n)try{const o=JSON.parse(t.slice(i,n+1));e.push(o)}catch(t){return}}),this.appErrorItems=e}attributeChangedCallback(){this.updateAppErrorItems()}};(0,l.Cg)([g.sH],oe.prototype,"appErrors",void 0),(0,l.Cg)([g.sH],oe.prototype,"appErrorItems",void 0),(0,l.Cg)([p.CF],oe.prototype,"appErrorsCnt",void 0),(0,l.Cg)([g.sH],oe.prototype,"columns",void 0),oe=(0,l.Cg)([(0,d.E)({name:"console-monitor",template:ne,styles:ie})],oe);const se=A.A`
    ${te} :host{width:100%;flex:1;display:flex}.left-container{flex:1}.left-container > [role="row"]{border-right:1px solid ${V.hb}}[grid-column="1"]{font-weight:500}.right-container{flex:1}.level-1{padding-left:30px}.level-2{padding-left:60px}`,re=E.qy`<div class="left-container">${(0,h.ux)(t=>t.leftSettingItems,E.qy`<fluent-data-grid-row grid-template-columns="1fr 1fr" :rowData=${t=>t} :columnDefinitions=${(t,e)=>e.parent.columns} class="level-${t=>t.level}"></fluent-data-grid-row>`)}</div><div class="right-container">${(0,h.ux)(t=>t.rightSettingItems,E.qy`<fluent-data-grid-row grid-template-columns="1fr 1fr" :rowData=${t=>t} :columnDefinitions=${(t,e)=>e.parent.columns} class="level-${t=>t.level}"></fluent-data-grid-row>`)}</div>`;var ae=i(74998),le=i(62044);let de=class extends d.L{connectedCallback(){super.connectedCallback(),this.clientSettings=ae.Rb.ClientSettings,this.settingItems=[],Object.entries(this.clientSettings).map(t=>{let[e,i]=t;this.generateItems(e,i)}),this.columns=this.config.columns;const t=Math.ceil(this.settingItems.length/2);this.leftSettingItems=this.settingItems.slice(0,t),this.rightSettingItems=this.settingItems.slice(t)}generateItems(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:0;if((0,le.Gv)(e)){this.settingItems.push({key:t,level:i});for(const[t,n]of Object.entries(e))this.generateItems(t,n,i+1)}else this.settingItems.push({key:t,value:e,level:i})}};(0,l.Cg)([g.sH],de.prototype,"clientSettings",void 0),(0,l.Cg)([g.sH],de.prototype,"settingItems",void 0),(0,l.Cg)([g.sH],de.prototype,"leftSettingItems",void 0),(0,l.Cg)([g.sH],de.prototype,"rightSettingItems",void 0),(0,l.Cg)([g.sH],de.prototype,"columns",void 0),de=(0,l.Cg)([(0,d.E)({name:"client-settings",template:re,styles:se})],de);const ce=A.A`
    ${te} :host{padding:8px;display:flex;flex-wrap:wrap;overflow:auto;width:100%;align-content:start}.util-button{box-shadow:rgb(255 255 255 / 20%) 0px 0px 2px 0px inset,rgb(0 0 0 / 10%) 0px 0px 10px 0px,rgb(0 0 0 / 10%) 0px 0px 5px 0px;display:flex;align-items:center;justify-content:center;border-radius:5px;text-align:center;height:110px;width:180px;border:none;font-size:inherit;font-weight:600;margin:8px}`,he=E.qy`<fluent-button class="util-button" appearance="stealth" @click=${t=>t.showPosition(document.body)}>Show Card Positions</fluent-button><fluent-button class="util-button" appearance="stealth" @click=${t=>t.showExperienceTypes(document.body)}>Show Experience Types</fluent-button>`;let ue=class extends d.L{connectedCallback(){super.connectedCallback()}showPosition(t){if(!t)return;if(t instanceof Element&&this.showPosition(t.shadowRoot),t.children&&t.children.length>0)for(let e=0;e<t.children.length;e++)this.showPosition(t.children[e]);if(t instanceof ShadowRoot)return;const e=this.getPositionInfo(t);this.addTooltip(t,e,"pos-set")}getPositionInfo(t){if(!t)return;const e=t.getAttribute&&t.getAttribute("data-t");if(!e)return;let i;try{i=JSON.parse(e).ext}catch(t){return}return i?`row: ${i.row}, col: ${i.col}`:void 0}showExperienceTypes(t){if(!t)return;if(t instanceof Element&&this.showExperienceTypes(t.shadowRoot),t.children&&t.children.length>0)for(let e=0;e<t.children.length;e++)this.showExperienceTypes(t.children[e]);if(t instanceof ShadowRoot)return;const e=null==t?void 0:t.getAttribute("instance-id");this.addTooltip(t,e,"exp-set")}addTooltip(t,e,i){if(!e||t.classList.contains(i))return;const n=document.createElement("div");n.innerHTML=e,n.title=e,n.setAttribute("style","position: absolute;\n            padding: 2px 6px;\n            border-radius: 20px;\n            background-color: #A5C4EC;\n            display: inline-block;\n            z-index: 10000;\n            font-size: 12px;\n            font-weight: 500;\n            transform: translateY(-16px);\n            color: #fff;");const o=document.createElement("div");o.setAttribute("style","position: absolute;\n            bottom: -9px;\n            left: 16px;\n            border-left: 10px solid transparent ;\n            border-right: 10px solid transparent;\n            border-top: 10px solid #A5C4EC;\n            z-index: 998;"),n.appendChild(o),t.classList.add(i),t.shadowRoot?t.shadowRoot.prepend&&t.shadowRoot.prepend(n):null!=t&&t.prepend&&(null==t||t.prepend(n))}};ue=(0,l.Cg)([(0,d.E)({name:"common-utils",template:he,styles:ce})],ue);const pe=A.A`
    ${te} :host{flex:1}[role="gridcell"]{font-size:16px}`,ge=E.qy` ${(0,h.ux)(t=>t.flightItems,E.qy`<fluent-data-grid-row grid-template-columns="1fr 1fr" :rowData=${t=>t} :columnDefinitions=${(t,e)=>e.parent.columns}></fluent-data-grid-row>`)}
`;var ve=i(50180);let fe=class extends d.L{connectedCallback(){super.connectedCallback(),this.columns=this.config.columns,this.updateFlightItems()}updateFlightItems(){this.currentFlights=ae.Rb.CurrentFlightSet;const t=[];this.currentFlights.forEach(e=>{t.push({id:e,expLink:this.getExpLink(e),flightLink:this.getFlightLink(e)})}),this.flightItems=t}getFlightLink(t){const e=new URL(window.location.origin+window.location.pathname);return e.searchParams.append("item",`flights:${t}`),E.qy`<a href=${e} class="link" target="_blank"
            >✈️ Apply single flight</a
        >`}getExpLink(t){const e=(0,ve.GP)(this.expBaseUrl,t);return E.qy`<a href=${e} class="link" target="_blank"
            >🧪 Go to exp page</a
        >`}};(0,l.Cg)([g.sH],fe.prototype,"flightItems",void 0),(0,l.Cg)([g.sH],fe.prototype,"columns",void 0),(0,l.Cg)([g.sH],fe.prototype,"expBaseUrl",void 0),fe=(0,l.Cg)([(0,d.E)({name:"current-flights",template:ge,styles:pe})],fe);const me=A.A`
    ${te} :host{width:100%;flex:1;display:flex}.container{flex:1}.container > [role="row"]{border-right:1px solid ${V.hb}}[grid-column="1"]{font-weight:500}`,xe=E.qy`<div class="container">${(0,h.ux)(t=>t.coachmarkInfo,E.qy`<fluent-data-grid-row grid-template-columns="1fr 5fr" :rowData=${t=>t} :columnDefinitions=${(t,e)=>e.parent.columns} style="padding-left: ${t=>t.indent}px"></fluent-data-grid-row>`)}</div>`;var be=i(11297),we=i(37641);let ye=class extends d.L{connectedCallback(){super.connectedCallback(),this.coachmarkInfo=[],this.columns=this.config.columns,this.prepareCoachmarkInfo().then()}async prepareCoachmarkInfo(){const t=await this.getSurface();Object.entries(t).map(t=>{let[e,i]=t;this.generateInfo(e,i)})}async getSurface(){if(this.irisDataConnector=await we.V.getInstance().rootReducer.getDataConnector(be.KR),!this.irisDataConnector)return null;return await this.irisDataConnector.tryGetSurfaceInfoInternal("88000309")}generateInfo(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:0;if((0,le.Gv)(e)){this.coachmarkInfo.push({key:t,indent:i});for(const[t,n]of Object.entries(e))this.generateInfo(t,n,i+20)}else this.coachmarkInfo.push({key:t,value:e,indent:i})}};(0,l.Cg)([g.sH],ye.prototype,"coachmarkInfo",void 0),(0,l.Cg)([g.sH],ye.prototype,"columns",void 0),ye=(0,l.Cg)([(0,d.E)({name:"coachmark-info",template:xe,styles:me})],ye);const $e=["#39FF14","#60afff","#FE4164","#EECC99","#FFD300","#FF1493","#FF34F3","#D000FF","#88FF55","#ff7373","#00FF7F","#FF6EC7","#00E5EE","#3320FF","#FFFF00","#AAF0D1","#ff7a2a","#FF9933","#c291ff"],ke=A.A` :host{left:0;position:fixed;top:0;z-index:1000;${"\n    --x-ray-accent: cyan;\n    --x-ray-accent-active: yellow;\n    --x-ray-background-rest: black;\n    --x-ray-background-hover: rgba(0, 255, 255, .4);\n    --x-ray-background-active: rgba(0, 255, 255, .7);\n"}
        ${"\n    --accent-fill-rest: var(--x-ray-accent);\n    --foreground-on-accent-rest: var(--x-ray-background-rest);\n\n    --neutral-foreground-rest: var(--x-ray-accent);\n    --neutral-foreground-hover: var(--x-ray-accent-active);\n    --neutral-foreground-active: var(--x-ray-background-rest);\n    --neutral-layer-floating: rgba(0, 0, 0, .85);\n\n    --neutral-fill-rest: var(--x-ray-background-rest);\n    --neutral-fill-hover: var(--x-ray-background-hover);\n    --neutral-fill-active: var(--x-ray-background-active);\n    --neutral-fill-focus: var(--x-ray-background-active);\n\n    --neutral-fill-input-rest: var(--x-ray-background-rest);\n    --neutral-fill-input-hover: var(--x-ray-background-rest);\n    --neutral-fill-input-active: var(--x-ray-background-rest);\n    --neutral-fill-input-focus: var(--x-ray-background-rest);\n\n    --neutral-stroke-rest: var(--x-ray-accent);\n    --neutral-stroke-hover: var(--x-ray-accent-active);\n"} --x-ray-color:white}:host svg{fill:currentColor}:host ul{list-style-type:none;margin:0 0 10px;max-width:360px;padding:0;width:max-content}div[slot="heading"]{display:flex;align-items:center}header{position:relative;display:flex;justify-content:start;z-index:10}header > *:first-child{margin-inline-end:auto}x-ray-user-badge{margin-inline-start:auto}.icon-textbox{align-items:center;display:flex;margin-right:-5px}.xray-accordion{background:black;color:var(--x-ray-color);max-height:calc(95vh - 200px);min-width:250px;overflow:auto;--neutral-stroke-divider-rest:currentColor}.xray-accordion > *::part(button){color:inherit}.xray-accordion > *::part(icon){fill:currentColor}.xray-accordion fluent-accordion-item .indicator{border:1px solid currentColor;display:none;font-size:11px;margin:0 8px;padding:2px 6px}.xray-accordion fluent-accordion-item[expanded] .expanded-indicator{display:block}.xray-accordion fluent-accordion-item:not([expanded]) .collapsed-indicator{display:block}.groups-list ul li{align-items:center;display:flex;color:white;font-size:14px;margin-bottom:5px}.groups-list ul li[disabled]{opacity:.5}.groups-list ul li output{border:1px solid gray;margin:0 4px;padding:3px 8px}.root{position:absolute}.root[is-enabled]{--x-ray-color:var(--x-ray-accent)}.xray-button{background:black;border:1px solid currentColor;border-radius:5px;color:var(--x-ray-color);height:30px}.xray-button:hover{--x-ray-color:var(--x-ray-accent-active)}.xray-button svg{height:auto;width:21px}.activate-button{background:linear-gradient(90deg,rgba(255,255,255,1) 0%,rgba(255,255,255,1) 15%,rgba(0,0,0,1) 15%)}.activate-button svg{background:radial-gradient(circle,var(--x-ray-color) 0%,var(--x-ray-color) 30%,rgba(42,32,32,0) 31%);fill:black;filter:drop-shadow(0px 0px 7px var(--x-ray-color));height:40px;margin-inline-start:-20px;scale:1.1;width:40px}.group-selection{color:var(--x-ray-color);position:relative;margin:2px 0;z-index:9}.group-selection:hover fluent-combobox::part(select-indicator){color:var(--x-ray-accent-active)}[has-tooltip]::before{position:absolute;left:0px;bottom:-60px;z-index:2;display:block;min-width:200px;padding:6px 10px;font-size:14px;color:yellow;background-color:black;border-radius:5px;box-shadow:0 0 4px 2px yellow;content:attr(tooltip-text)}`;var Ce=i(60402),ze=i(35792),Ie=i(36042);function Te(t){const e=t.length<7?`${t}${t[0]}${t[t.length-1]}`:t;let i=0;for(let t=0;t<e.length;t++)i=e.charCodeAt(t)+(i<<5)-i,i&=i;i=Math.abs(i);return $e[i%$e.length]}function Fe(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:document;const i=e.querySelector(t);if(i)return i;const n=e.querySelectorAll("*");for(const e of n)if(e instanceof HTMLElement&&e.shadowRoot){const i=Fe(t,e.shadowRoot);if(i)return i}return null}function Ae(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[];return e.querySelectorAll(t).forEach(t=>i.push(t)),e.querySelectorAll("*").forEach(e=>{e instanceof HTMLElement&&e.shadowRoot&&Ae(t,e.shadowRoot,i)}),i}function Me(t,e){const i=[];return Ee(i,t,t,e),i}function Ee(t,e,i,n){let o=arguments.length>4&&void 0!==arguments[4]?arguments[4]:null;if("string"==typeof i)t.push({indexOfType:t.length-1,type:i,follow:o,info:e});else if("boolean"==typeof i)t.push({indexOfType:t.length-1,type:i?"true":"false",follow:o,info:e});else if("number"==typeof i)t.push({indexOfType:t.length-1,type:String(i),follow:o,info:e});else if(Array.isArray(i))i.forEach(i=>{Ee(t,e,i,n)});else if(n){const o=n.split(/\.([^]*)/),s=o[0],r=o[1],a=i[s],l=i.follow;void 0!==a&&Ee(t,e,a,r,l)}}const De=t=>{var e,i;return"explore"===(null==t||null===(e=t.type)||void 0===e?void 0:e.toLowerCase())&&!(null!=t&&null!==(i=t.follow)&&void 0!==i&&i.name)},Oe=A.A`
  .popover {
    overflow: auto;
    background-color: rgba(0, 0, 0);
    border: 1px solid cyan;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    color: white;
    font-size: 12px;
    max-height: 500px;
    min-height: 50px;
    max-width: 500px;
    min-width: 100px;
    padding: 5px 10px;
  }
`,Se=E.qy`
    <div class="popover">
        ${t=>t.content}
    </div>
`;let Be=class extends d.L{};(0,l.Cg)([g.sH],Be.prototype,"content",void 0),Be=(0,l.Cg)([(0,d.E)({name:"x-ray-popover",template:Se,styles:Oe})],Be);const He=A.A`
    .badge {
        align-items: center;
        background-color: black;
        border: 1px dotted currentColor;
        border-left: 5px solid;
        box-shadow: rgb(0 0 0 / 46%) -1px 1px 2px 1px;
        color: var(--badge-color, white);
        cursor: pointer;
        display: flex;
        filter: brightness(1.1) saturate(1.5);
        flex-direction: column;
        flex-wrap: wrap;
        font-size: 14px;
        font-weight: normal;
        height: 20px;
        letter-spacing: .3pt;
        line-height: 20px;
        max-width: 250px;
        padding: 2px 6px;
        position: relative;
        overflow: hidden;
        word-break: break-all;
    }
    .badge[has-hover-content]:hover {
        drop-shadow(0px -3px 5px var(--badge-color))
    }
`,Re=E.qy`
    <div
        class="badge"
        ?has-hover-content=${t=>!!t.data}
        style="--badge-color:${t=>{var e;return t.color||Te((null===(e=t.data)||void 0===e?void 0:e.type)||t.type)}}"
    >
        ${t=>t.text}
    </div>
`;let Ve=class extends d.L{constructor(){super(...arguments),this.isPopoverVisible=!1}get text(){var t;let e=(null===(t=this.data)||void 0===t?void 0:t.type)||this.type||"MissingData";return this.data&&this.data.follow&&this.data.follow.name&&(e=`${e}: ${this.data.follow.name}`),e}connectedCallback(){super.connectedCallback(),this.registerPopover()}registerPopover(){if(!this.data)return;const t=E.qy`<pre><code>${JSON.stringify(this.data,null,2)}</code></pre>`;ze.b.registerTrigger({childrenRenderer(){return E.qy`<x-ray-popover :content="${t}"></x-ray-popover>`},childrenType:"WC",customContainerSelector:"fluent-design-system-provider",delay:50,renderOnRegister:!1,triggerElement:this})}};(0,l.Cg)([g.sH],Ve.prototype,"color",void 0),(0,l.Cg)([g.sH],Ve.prototype,"type",void 0),(0,l.Cg)([g.sH],Ve.prototype,"data",void 0),(0,l.Cg)([g.sH],Ve.prototype,"isPopoverVisible",void 0),(0,l.Cg)([g.Jg],Ve.prototype,"text",null),Ve=(0,l.Cg)([(0,d.E)({name:"x-ray-group-badge",template:Re,styles:He})],Ve);var Le=i(50149),je=i.n(Le),Pe=i(66801),Ne=i.n(Pe),We=i(26629),Ue=i.n(We),Xe=i(86664),Ge=i.n(Xe);const Je=A.A`
    :host a {
        color: #60AFFF;
        display: flex;
        margin: 5px;
        text-decoration: none;
    }
    :host a:hover {
        color: yellow;
        text-decoration: underline;
    }
    :host svg {
        fill: currentColor;
    }
    :host ul {
        list-style-type: none;
        margin: 0 0 10px;
        max-width: 360px;
        padding: 0;
        width: max-content;
    }
    .copy-button {
        border-radius: 5px;
        color: var(--x-ray-color);
        cursor: pointer;
        padding: 2px 5px;
        position: relative;
    }
    .copy-button:hover {
        --x-ray-color: yellow;
        outline: 1px solid var(--x-ray-color);
    }
    .copy-button[has-tooltip]::before {
        background-color: black;
        border-radius: 5px;
        box-shadow: inset 0 0 4px 3px yellow;
        content: "copied!";
        color: white;
        display: block;
        font-size: 12px;
        padding: 5px 10px;
        position: absolute;
        left: 0px;
        bottom: 30px;
        z-index: 2;
    }
    .debug-info li {
        align-items: center;
        display: flex;
        flex-flow: wrap;
        font-size: 12px;
        gap: 5px;
        margin-bottom: 7px;
    }
    .debug-info li:last-child {
        margin-bottom: 0;
        margin-left: auto;
    }
    .debug-info li .label {
        color: var(--x-ray-color);
        opacity: .7;
    }
    .debug-info li .value {
        color: white;
        opacity: .9;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        width: 100%;
    }
`,Ke=(t,e)=>E.qy`<a class="link" href="${t}" target="_blank">${e} ${E.qy.partial(Ge())}</a>`,Ye=t=>Ke((t=>`https://recoprobe.binginternal.com/?UserId=${t}&Anid=${t}`)(t),"RecoProbe"),_e=t=>Ke((t=>`https://sageprobe.azurewebsites.net/User/UserProfileReport?Endpoint=https%3A%2F%2FObjectStoreBingFD.Prod.WestUS.BingInternal.com%2Fsds&Table=SageUserProfileV2&UserId=${t}`)(t),"SageProbe"),qe=t=>Ke((t=>`https://stampmanager.microsoft.com/?service=ContentServices&logsources=&key=${t}`)(t),"StampManager"),Qe=E.qy`
    <span class="label">${t=>t.label}</span> 
    ${t=>{return e=t.id,E.qy`
<span
    class="copy-button"
    title="Copy to clipboard"
    @click="${(t,i)=>{var n;return null===(n=i.parent)||void 0===n?void 0:n.copyToClipboard(e,i.event.currentTarget)}}"
>
    ${E.qy.partial(Ue())}
</span>`;var e}}
    ${(0,pt.z)(t=>t.id,E.qy`${(0,h.ux)(t=>t.linkTemplates,E.qy`${t=>t}`)}`)}
    <div class="value" title=${t=>t.id}>${t=>t.id}</div>
`,Ze=E.qy`
    <div class="debug-info-container">
        <ul class="debug-info">
            ${(0,h.ux)(t=>t.idItems,E.qy`<li> ${Qe} </li>`)}
        </ul>
    </div>
`;let ti=class extends d.L{get idItems(){const{activityId:t,userId:e,userIdWithoutPrefix:i}=this.data||{};return[{label:"ActivityId",id:t,linkTemplates:[qe(t)]},{label:"DebugId",id:this.debugId,linkTemplates:[qe(this.debugId),(n=this.debugId,Ke((t=>`https://wpoqueryprobe.azurewebsites.net/OneServiceIndex?debugId=${t}&env=OneServiceProd`)(n),"WpoQueryProbe"))]},{label:"UserId",id:e,linkTemplates:[Ye(i),_e(i)]}];var n}connectedCallback(){super.connectedCallback(),this.setData()}setData(){const t=(0,ht.rA)(),{ActivityId:e,UserId:i}=t,n=i.split("-")[1];this.data={activityId:e,userId:i,userIdWithoutPrefix:n}}copyToClipboard(t,e){navigator.clipboard.writeText(t).then(()=>{this.showCopiedTooltip(e)})}showCopiedTooltip(t){t.setAttribute("has-tooltip",""),window.setTimeout(()=>{t.removeAttribute("has-tooltip")},1e3)}};(0,l.Cg)([g.sH],ti.prototype,"data",void 0),(0,l.Cg)([g.sH],ti.prototype,"debugId",void 0),(0,l.Cg)([g.Jg],ti.prototype,"idItems",null),ti=(0,l.Cg)([(0,d.E)({name:"x-ray-debug-info",template:Ze,styles:Je})],ti);var ei=i(3874),ii=i(84258),ni=i.n(ii),oi=i(44995),si=i.n(oi),ri=i(83341),ai=i.n(ri);const li=A.A`
    :host {
        color: yellow;
        fill: currentColor;
    }
    .user-badge {
        display: flex;
        align-items: center;
        gap: 3px
    }
    .user-badge label {
        border: solid 1px rgba(255, 255, 0, .5);
        font-size: 11px;
        padding: 3px 3px 2px;
    }
`,di={MSA:ni(),AAD:si(),AAD_AL:si(),ANONYMOUS:ai()},ci=E.qy`
    <div class="user-badge">
        <span>${t=>E.qy`${E.qy.partial(di[t.accountType])}`}</span>
        <label>${t=>t.accountType}</label>
    </div>
`;let hi=class extends d.L{connectedCallback(){super.connectedCallback();const t=(0,ei.Dm)();this.accountType=this.mapXRayUserAccountType(null==t?void 0:t.account_type),this.loginHint=(null==t?void 0:t.login_hint)||""}mapXRayUserAccountType(t){return[void 0,null,"UNSUPPORTED_SOVEREIGNTY","NA"].includes(t)?"ANONYMOUS":t}};(0,l.Cg)([g.sH],hi.prototype,"accountType",void 0),(0,l.Cg)([g.sH],hi.prototype,"loginHint",void 0),hi=(0,l.Cg)([(0,d.E)({name:"x-ray-user-badge",template:ci,styles:li})],hi);const ui=["reasons.type","provider.name","provider.id","source","type","category","subCategory","locale","isLocalContent","isBreaking","feed.id","recoId","debugId","adPageType","adRegion","adIndex"];var pi=i(85349),gi=i(41065),vi=i(19359);const fi=(0,gi.N)("FeedXRay"),mi=(0,gi.N)("DragWidgetButton",pi.MS.Click,pi.EG.Click,pi.MJ.ActionButton),xi={componentRoot:fi,accordionButton(t,e){return(0,vi.l)("AccordionButton",{headline:t},e?pi.MS.Show:pi.MS.Hide,pi.EG.Click,pi.MJ.ActionButton)},dragWidgetButton:mi,highlightBadgeButton(t){return(0,vi.l)("HighlightBadge",{headline:t},pi.MS.Click,pi.EG.Click,pi.MJ.ActionButton)},toggleXRayButton(t){return(0,gi.N)("ToggleXRay",t?pi.MS.Show:pi.MS.Hide,pi.EG.Click,pi.MJ.ActionButton)}};var bi=i(77367);const wi=t=>E.qy` ${(0,pt.z)(e=>(null==t?void 0:t.size)>1,E.qy`<ul><li><x-ray-group-badge :type="${t=>"Total # of Cards"}" :color="${t=>"gray"}"></x-ray-group-badge><output>${e=>t.get("All")}</output></li>${(0,h.ux)(e=>Array.from(t.keys()).filter(t=>"All"!==t),E.qy`<li ?disabled=${(t,e)=>{var i,n;return(null===(i=e.parent.groupHighlighter)||void 0===i?void 0:i.activeGroupType)&&t!==(null===(n=e.parent.groupHighlighter)||void 0===n?void 0:n.activeGroupType)}}><x-ray-group-badge :type="${t=>t}" role="button" data-t="${t=>xi.highlightBadgeButton(t).getMetadataTag()}" @click=${(t,e)=>{var i;return null===(i=e.parent.groupHighlighter)||void 0===i?void 0:i.toggleByGroupType({groupType:t,cardDataByIdMap:e.parent.cardDataByIdMap})}}></x-ray-group-badge><output>${(e,i)=>t.get(e)}</output><div>${(e,i)=>Math.ceil(100*t.get(e)/t.get("All"))}%</div></li>`)}</ul>`)}
`,yi=E.qy`<div class="group-selection"><fluent-combobox autocomplete="list" placeholder="group by..." current-value="${t=>t.group}" @change=${(t,e)=>t.group=e.event.target.control.value}>${(0,h.ux)(t=>ui,E.qy`<fluent-option aria-selected="${(t,e)=>e.parent.group==t}">${t=>t}</fluent-option>`)}</fluent-combobox><div>`,$i=t=>{var e;const i=null==t||null===(e=t.currentTarget)||void 0===e?void 0:e.expanded,n=null==t?void 0:t.currentTarget;bi.YT.sendActionEvent(n,pi.EG.Click,i?pi.MS.Hide:pi.MS.Show)},ki=E.qy`<fluent-accordion class="xray-accordion" expand-mode="multi"><fluent-accordion-item data-customhandled="1" data-t="${()=>xi.accordionButton("DebugInfo",!0).getMetadataTag()}" @change=${(t,e)=>$i(null==e?void 0:e.event)}><div slot="heading">Debug Info<x-ray-user-badge></x-ray-user-badge></div><x-ray-debug-info :debugId="${t=>t.debugId}"></x-ray-debug-info></fluent-accordion-item><fluent-accordion-item data-customhandled="1" data-t="${()=>xi.accordionButton("CustomFilter",!0).getMetadataTag()}" @change=${(t,e)=>{var i;t.group=null!==(i=e.event)&&void 0!==i&&null!==(i=i.currentTarget)&&void 0!==i&&i.expanded?t.group:"reasons.type",$i(null==e?void 0:e.event)}}><div slot="heading">Custom Filter:<span class="indicator collapsed-indicator">OFF</span><span class="indicator expanded-indicator">ON</span></div>${(0,pt.z)(t=>t.isInitialized,yi)}</fluent-accordion-item><fluent-accordion-item class="groups-list" data-customhandled="1" data-t="${()=>xi.accordionButton("InfopaneBadges",!0).getMetadataTag()}" @change=${(t,e)=>$i(null==e?void 0:e.event)}><div slot="heading">Infopane</div>${t=>wi(t.groupCounts(t=>"infopane"===t.collection))}</fluent-accordion-item><fluent-accordion-item class="groups-list" data-customhandled="1" data-t="${()=>xi.accordionButton("RiverBadges",!0).getMetadataTag()}" @change=${(t,e)=>$i(null==e?void 0:e.event)}><div slot="heading">River</div>${t=>wi(t.groupCounts(t=>"infopane"!==t.collection))}</fluent-accordion-item></fluent-accordion>`,Ci=E.qy`<div class="root" ?is-enabled=${t=>t.isInitialized} ${(0,Ce.K)("rootElementRef")}><header><fluent-button class="xray-button activate-button" data-t="${t=>xi.toggleXRayButton(t.isInitialized).getMetadataTag()}" @click=${t=>t.toggle()}><div class="icon-textbox">${E.qy.partial(je())}<span>${t=>t.isInitialized?"X-Ray Active":"Enable Feed X-Ray"}</span></div></fluent-button><fluent-button class="xray-button" data-t="${()=>xi.dragWidgetButton.getMetadataTag()}" ${(0,Ce.K)("dragButtonRef")}>${E.qy.partial(Ne())}</fluent-button></header>${(0,pt.z)(t=>{var e;return(null===(e=t.cardDataByIdMap)||void 0===e?void 0:e.size)>0},ki)}</div>`;var zi=i(77558),Ii=i(90905);const Ti=zi.P.Overlay.toString(),Fi="xray-groups";class Ai{constructor(t){this.root=t,this.scannedCards=new Map,this.overlay=this.createOverlay(),this.handleScrollResize=(0,Ii.A)(this.refreshBadgePositions.bind(this),300),window.addEventListener("resize",this.handleScrollResize)}createOverlay(){const t=document.createElement("div");return t.style.position="absolute",t.style.top="0",t.style.left="0",t.style.width="100%",t.style.height="100%",t.style.pointerEvents="none",t.style.zIndex="1",this.root.style.position="relative",this.root.appendChild(t),t}addBadge(t,e){if(this.scannedCards.has(t))return;const i=t.getBoundingClientRect();e.style.position="absolute";const n=this.root.getBoundingClientRect();e.style.top=i.top-n.top+"px",e.style.left=i.left-n.left+"px",e.style.zIndex=Ti,this.overlay.appendChild(e),this.scannedCards.set(t,e)}refreshBadgePositions(){this.scannedCards.forEach((t,e)=>{const i=e.getBoundingClientRect(),n=this.root.getBoundingClientRect();t.style.top=i.top-n.top+"px",t.style.left=i.left-n.left+"px"})}cleanupBadges(){this.scannedCards.forEach((t,e)=>{var i,n;e&&e.isConnected||((null===(i=t.parentElement)||void 0===i?void 0:i.removeChild(t))||(null===(n=t.parentNode)||void 0===n?void 0:n.removeChild(t))||t.remove(),this.scannedCards.delete(e))})}dispose(){window.removeEventListener("resize",this.handleScrollResize),this.scannedCards.forEach(t=>{t.parentNode&&t.parentNode.removeChild(t)}),this.scannedCards.clear(),this.overlay.parentNode&&this.overlay.parentNode.removeChild(this.overlay)}static getBadges(){return document.querySelectorAll(`[${Fi}]`)}static highlight(t){this.getBadges().forEach(e=>{var i;e.style.opacity=!t||null!==(i=e.getAttribute(Fi))&&void 0!==i&&i.includes(t)?"1":".2"})}}const Mi="cs-responsive-infopane",Ei=t=>{var e,i;const n=function(t,e){for(;t;){if(t.matches&&t.matches(e))return t;t=t.parentNode instanceof ShadowRoot?t.parentNode.host:t.parentNode}return null}(t,Mi),o=null==n||null===(e=n.lazyPanels)||void 0===e||null===(e=e[n.activeIndex])||void 0===e||null===(e=e.data)||void 0===e?void 0:e.cardElement;return o==t||(null==o||null===(i=o.contains)||void 0===i?void 0:i.call(o,t))},Di="fluent-design-system-provider";class Oi{constructor(){this.lastScanIndex=0,this.elementReferences=new Map,this._overlayManager=new Ai(Fe(Di)??document.body)}static getInstance(){return Oi.instance||(Oi.instance=new Oi),Oi.instance}get overlayManager(){return this._overlayManager||(this._overlayManager=new Ai(Fe(Di)??document.body)),this._overlayManager}dispose(){this._overlayManager.dispose(),this._overlayManager=null,this.elementReferences.forEach((t,e)=>{e.parentNode&&e.parentNode.removeChild(e)}),this.elementReferences.clear(),this.lastScanIndex++}render(t){if(null!=t&&t.size){this.overlayManager.cleanupBadges();for(const[e,i]of t)Si(i)&&this.addGroupBadgesToCard(i)}}addGroupBadgesToCard(t){const{cardElement:e,duplicateElements:i}=t;if(!e)return;const n=(e,i)=>{this.overlayManager.addBadge(e,this.createGroupBadges(t)),i&&(e.style.opacity=".7",e.style.border="5px dashed red",e.style.boxSizing="border-box")};n(e,!1),i.forEach(t=>n(t,!0))}createGroupBadges(t){const e=document.createElement("div");Object.assign(e.style,{display:"grid",gap:"4px",left:"6px",justifyItems:"start",maxWidth:"250px",position:"absolute",top:"6px",zIndex:"1000"}),this.elementReferences.set(e,[]);const{groups:i}=t;return i&&i.length>0&&e.setAttribute(Fi,i.map(t=>t.type).join(",")),null==i||i.forEach(t=>{const i=E.qy`<x-ray-group-badge :data=${t}></x-ray-group-badge>`;i.render({},e),this.elementReferences.get(e).push(i)}),e}}const Si=t=>{var e;if(!!(null===(e=t.groups)||void 0===e||!e.length))return!1;return!!t.cardElement&&("infopane"!==t.collection||Ei(t.cardElement))};class Bi{constructor(){this.cardHighlightMap=new Map}static getInstance(){return Bi.instance||(Bi.instance=new Bi),Bi.instance}reset(){this.activeGroupType=null,this.cardHighlightMap.clear(),this.toggleByGroupType({groupType:null})}refresh(t){this.setCardDataMap(t),this.activeGroupType&&this.toggleByGroupType({groupType:this.activeGroupType,dontToggle:!0})}setCardDataMap(t){t&&(this.cardDataByIdMap=t)}dimElement(t){t&&(t.style.opacity="0.95",t.style.filter="contrast(.2) grayscale(1) brightness(2) opacity(0.7)")}highlightElement(t,e){t&&(t.style.opacity="1",t.setAttribute("style",`${t.getAttribute("style")}; box-shadow: ${Te(e)} 0px 0px 30px 10px; scale: .9; border-radius: 10px; overflow: hidden;`))}resetElement(t){t&&(t.style.opacity="1",t.style.boxShadow="",t.style.borderRadius="unset",t.style.overflow="unset",t.style.filter="unset",t.style.scale="1")}toggleByGroupType(t){var e;let{groupType:i,dontToggle:n,cardDataByIdMap:o}=t;if(this.setCardDataMap(o),null===(e=this.cardDataByIdMap)||void 0===e||!e.size)return;const s=this.activeGroupType===i&&!n;i="All"===i||s?null:i,this.activeGroupType=i,null==Ai||Ai.highlight(this.activeGroupType),this.cardDataByIdMap.forEach(t=>{var e;let{cardElement:n,groups:o,id:r}=t;if(!n)return;if(this.cardHighlightMap.has(r)&&(s||!this.activeGroupType||this.activeGroupType&&(null===(e=this.cardHighlightMap.get(r))||void 0===e?void 0:e.higlightedGroup)!=this.activeGroupType)&&this.resetElement(n),this.activeGroupType){!o.some(t=>t.type===this.activeGroupType)?this.dimElement(n):this.highlightElement(n,i)}this.cardHighlightMap.set(r,{element:n,higlightedGroup:this.activeGroupType})})}}(0,l.Cg)([g.sH],Bi.prototype,"activeGroupType",void 0);class Hi{async init(){var t;return this.feed=null===(t=Ae("msn-channel-linear-feed",document.body))||void 0===t||null===(t=t[0])||void 0===t?void 0:t.feed,Promise.resolve(!!this.feed)}reset(){this.feed=null}getDebugId(){return""}getFeedLength(){var t;return null===(t=this.feed)||void 0===t?void 0:t.length}getFeedContentCards(){return Ae("cs-content-card[data-t*='Card']",document.body).map(t=>{const e=t.getAttribute("data-t");if(!e)return null;try{const i=JSON.parse(e);if("Card"!==i.n)return;return{cardElement:t,id:i["c.i"]}}catch(t){}return null}).filter(t=>t)}async getFeedContentCardMetadata(){if(!this.feed)return;const t=[];return this.feed.forEach(e=>{Boolean(e.cardContent)&&t.push({id:e.cardContent.id,metadata:{...e.metadata,...e.cardContent}})}),t}}class Ri{async init(){return await this.setFeedManager(),!!this.feedManager}reset(){this.feedManager=null}getDebugId(){var t;return null===(t=this.feedManager)||void 0===t||null===(t=t.lastResponse)||void 0===t?void 0:t.debugId}getFeedLength(){var t;return null===(t=this.feedManager)||void 0===t||null===(t=t._river)||void 0===t?void 0:t.length}getFeedContentCards(){return Ae("[data-t*='ContentCard'], [data-t*='NativeAd'], [data-t*='WebCard']",document.body).map(t=>{const e=t.getAttribute("data-t");if(!e)return null;try{const i=JSON.parse(e);if("ContentCard"!==i.n&&"NativeAd"!==i.n&&"WebCard"!==i.n)return;return{cardElement:t,id:i["c.i"]||t.id}}catch(t){}}).filter(t=>t)}async getFeedContentCardMetadata(){var t;this.feedManager||await this.setFeedManager();const e=null===(t=this.feedManager)||void 0===t?void 0:t._river,i=[];if(!e||!e[0])return i;for(let t=0;t<e.length;t++){var n;const o=e[t];null==o||null===(n=o.cardMetadataList)||void 0===n||n.forEach(t=>{var e,n;this.isContentCardData(t)&&i.push({...t,metadata:{...t.cardContent,...t.metadata}}),this.isAdCardData(t)&&i.push({...t,id:null===(e=t.cardContent)||void 0===e?void 0:e.id,metadata:{...t.cardContent,...this.getAdMetadata(t)}}),this.isInfoPaneCardData(t)&&(null==t||null===(n=t.subItems)||void 0===n||n.forEach(e=>{var n;e.collection="infopane",this.isContentCardData(e)&&i.push({...e,metadata:{...e.cardContent,...e.metadata}}),this.isAdCardData(t)&&i.push({...e,id:null===(n=e.cardContent)||void 0===n?void 0:n.id,metadata:{...e.cardContent,...this.getAdMetadata(e)}})}))})}return i}async setFeedManager(){const t=document.querySelector("edge-chromium-page"),{feedManager:e}=await t.getFeedDependencyPromise||{};this.feedManager=e}isContentCardData(t){return Boolean(t.cardContent)&&!this.isAdCardData(t)}isInfoPaneCardData(t){return"infopane"===t.type}isAdCardData(t){return"nativead"===t.type||"cmsad"===t.type}getAdMetadata(t){var e,i,n,o,s;return{type:t.type,provider:{name:null===(e=t.placement)||void 0===e?void 0:e.providerId,id:null===(i=t.placement)||void 0===i?void 0:i.providerId},adPageType:null===(n=t.placement)||void 0===n||null===(n=n.adServedUrls)||void 0===n||null===(n=n.find(t=>t.startsWith("https://srtb.msn.com")).match(/.*&p=(\w*)&*/))||void 0===n?void 0:n[1],adRegion:null===(o=t.placement)||void 0===o?void 0:o.region,adIndex:null===(s=t.placement)||void 0===s?void 0:s.regionIndex}}}class Vi{async init(){var t;return this.rubyFeedData=null===(t=Ae("msn-feed",document.body))||void 0===t||null===(t=t[0])||void 0===t?void 0:t.feed,Promise.resolve(!!this.rubyFeedData)}reset(){this.rubyFeedData=null}getDebugId(){return""}getFeedLength(){var t;return(null===(t=this.rubyFeedData)||void 0===t?void 0:t.length)||0}getFeedContentCards(){return Ae("[data-t*='ContentCard'], [data-t*='NativeAd']",document.body).map(t=>{const e=t.getAttribute("data-t");if(!e)return null;try{const i=JSON.parse(e);if("ContentCard"!==i.n&&"NativeAd"!==i.n)return;return{cardElement:t,id:i["c.i"]||t.id}}catch(t){}}).filter(t=>t)}async getFeedContentCardMetadata(){if(!this.rubyFeedData&&(await this.init(),!this.rubyFeedData))return[];const t=[];return(this.rubyFeedData||[]).forEach(e=>{var i;null===(i=e.rowData)||void 0===i||i.forEach(e=>{e.id&&t.push({...e,metadata:{...e.cardContent,...e.metadata}})})}),t}}var Li=i(21297);class ji{static getAdapter(){if("channel"===(0,ht.rA)().HostPage.verticalKey)return new Hi;return Li.gR.isRuby?new Vi:new Ri}}let Pi=class extends d.L{constructor(){var t;super(...arguments),t=this,this.isInitialized=!1,this.group="reasons.type",this.adapter=ji.getAdapter(),this.lastScannedRiverSectionCount=0,this.refreshXRay=(0,Ie.A)(()=>{this.scanFeed(),this.refreshTimer&&window.clearTimeout(this.refreshTimer),this.refreshTimer=window.setTimeout(()=>{this.isInitialized&&this.scanFeed(!0)},1e3)},500).bind(this),this.scanFeed=async function(){let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];try{const i=t.adapter.getFeedLength();if(t.lastScannedRiverSectionCount===i&&!e)return;t.lastScannedRiverSectionCount=i;const n=await t.scanCardData();if(!n)return void t.reset();t.cardDataByIdMap=new Map(n),t.refresh(),t.debugId=t.adapter.getDebugId()}catch(e){return t.showTooltip(t.dragButtonRef,"[X-Ray Error:2] Scanning interrupted by an error",4e3),void t.reset()}}.bind(this)}get groupCounts(){return t=>{const e={All:0};this.cardDataByIdMap&&this.cardDataByIdMap.forEach(i=>{null!=t&&t(i)&&(e.All+=1,i.groups.forEach(t=>{let{type:i}=t;e[i]=(e[i]||0)+1}))});const i=Object.entries(e).sort((t,e)=>e[1]-t[1]);return new Map(i)}}connectedCallback(){super.connectedCallback(),this.setupDragging(),this.groupBadgeRenderer=Oi.getInstance(),this.groupHighlighter=Bi.getInstance()}disconnectedCallback(){super.disconnectedCallback(),this.reset()}reset(){var t,e,i;window.removeEventListener("scroll",this.refreshXRay),this.isInitialized=!1,null===(t=this.adapter)||void 0===t||t.reset(),this.debugId=null,this.cardDataByIdMap=null,this.lastScannedRiverSectionCount=0,null===(e=this.groupBadgeRenderer)||void 0===e||e.dispose(),null===(i=this.groupHighlighter)||void 0===i||i.reset(),this.unobserveInfopane()}async init(){if(this.isInitialized)return;await this.adapter.init()?(this.isInitialized=!0,this.observeInfopane(),this.scanFeed(),window.addEventListener("scroll",this.refreshXRay)):this.showTooltip(this.dragButtonRef,"[X-Ray Error:1] Feed is not found! Please make sure it is visible on the page.",4e3)}toggle(){this.isInitialized?this.reset():this.init()}groupChanged(){this.lastScannedRiverSectionCount=0,this.isInitialized&&(this.groupBadgeRenderer.dispose(),this.groupHighlighter.reset(),this.scanFeed())}async scanCardData(){const t=new Map,e=this.adapter.getFeedContentCards(),i=(await this.adapter.getFeedContentCardMetadata()).map(t=>{var e;const i={...t};var n;return(null==i||null===(e=i.metadata)||void 0===e||null===(e=e.reasons)||void 0===e?void 0:e.some(t=>De(t)))&&(i.metadata={...i.metadata,reasons:(null===(n=i.metadata)||void 0===n||null===(n=n.reasons)||void 0===n?void 0:n.map(t=>De(t)?{...t,type:"fallback"}:t))||[]}),i});return null==i||i.forEach(i=>{var n;let{id:o,metadata:s,collection:r}=i;const a=e.filter(t=>{let{id:e}=t;return e===o}),l=Me(s,this.group),d=null===(n=a[0])||void 0===n?void 0:n.cardElement,c=a.slice(1).map(t=>{let{cardElement:e}=t;return e});t.set(o,{id:o,cardElement:d,duplicateElements:c,groups:l,collection:r})}),t}setupDragging(){!function(t){const{dragButton:e,elementToDrag:i,moveToOnSetup:n,onDragComplete:o}=t;i.style.position="absolute",e.style.cursor="move";const s=o&&(0,Ie.A)(o,500);let r=0,a=0,l=0,d=0;const c=t=>{let{x:e,y:n}=t;i.style.left=`${e}px`,i.style.top=`${n}px`},h=t=>{t.preventDefault(),r=l-t.clientX,a=d-t.clientY,l=t.clientX,d=t.clientY;let e=i.offsetLeft-r,n=i.offsetTop-a;const o=window.innerWidth,h=window.innerHeight;e=Math.max(0,Math.min(e,o-i.offsetWidth)),n=Math.max(0,Math.min(n,h-i.offsetHeight)),c({x:e,y:n}),null==s||s({x:e,y:n})},u=()=>{document.removeEventListener("mouseup",u),document.removeEventListener("mousemove",h)};n&&c(n),e.addEventListener("mousedown",t=>{t.preventDefault(),l=t.clientX,d=t.clientY,document.addEventListener("mouseup",u),document.addEventListener("mousemove",h)})}({dragButton:this.dragButtonRef,elementToDrag:this.rootElementRef,moveToOnSetup:{x:35,y:60}})}refresh(){this.groupBadgeRenderer.render(this.cardDataByIdMap),this.groupHighlighter.refresh(this.cardDataByIdMap)}observeInfopane(){this.infopaneObserver&&this.unobserveInfopane(),this.infopaneObserver=(t=>{const e=Fe(Mi);if(!e)return;const i=()=>{var i,n;const o=null===(i=e.lazyPanels)||void 0===i?void 0:i[e.activeIndex];o&&t(o.id,null===(n=o.data)||void 0===n?void 0:n.cardElement)},n=new MutationObserver(function(t){for(const n of t)"attributes"===n.type&&"activeid"===n.attributeName&&e&&i()});return n.observe(e,{attributes:!0}),window.setTimeout(()=>i(),50),n})((t,e)=>{var i;(null===(i=this.cardDataByIdMap)||void 0===i?void 0:i.has(t))?window.requestAnimationFrame(()=>window.setTimeout(()=>{this.cardDataByIdMap.get(t).cardElement=e,this.refresh()},0)):this.refresh()})}unobserveInfopane(){this.infopaneObserver&&(this.infopaneObserver.disconnect(),this.infopaneObserver=null)}showTooltip(t,e,i){t.setAttribute("has-tooltip",""),t.setAttribute("tooltip-text",e),window.setTimeout(()=>{t.removeAttribute("has-tooltip"),t.removeAttribute("tooltip-text")},i)}};(0,l.Cg)([g.sH],Pi.prototype,"cardDataByIdMap",void 0),(0,l.Cg)([g.sH],Pi.prototype,"isInitialized",void 0),(0,l.Cg)([g.sH],Pi.prototype,"debugId",void 0),(0,l.Cg)([g.sH],Pi.prototype,"group",void 0),(0,l.Cg)([g.sH],Pi.prototype,"groupHighlighter",void 0),(0,l.Cg)([g.Jg],Pi.prototype,"groupCounts",null),Pi=(0,l.Cg)([(0,d.E)({name:"feed-x-ray",template:Ci,styles:ke})],Pi);var Ni=i(16792),Wi=i.n(Ni),Ui=i(72778),Xi=i.n(Ui),Gi=i(69423),Ji=i.n(Gi),Ki=i(43382),Yi=i.n(Ki),_i=i(15183),qi=i.n(_i);E.qy`<sup class="badge">${t=>t.appErrorsCnt}</sup>`;const Qi=E.qy`<div class="button-list">${(0,h.ux)(t=>t.widgetList,E.qy`<fluent-button class="widget-button" appearance="stealth" @click=${(t,e)=>e.parent.updateActiveWigdetId(t.id)}>${(t,e)=>1===t.id?E.qy`<span class="app-errors-title">${t.icon} Errors: ${e.parent.appErrorsCnt}</span>`:E.qy`<span>${t.icon} ${t.title}</span>`}</fluent-button>`)}</div>`,Zi=E.qy` ${(0,pt.z)(t=>t.activeWidgetId===t.config.widgetConfigs.AppConfigs.id,E.qy`<app-configs :config=${t=>t.config.widgetConfigs.AppConfigs}></app-configs>`)} ${(0,pt.z)(t=>t.activeWidgetId===t.config.widgetConfigs.ClientSettings.id,E.qy`<client-settings :config=${t=>t.config.widgetConfigs.ClientSettings}></client-settings>`)} ${(0,pt.z)(t=>t.activeWidgetId===t.config.widgetConfigs.CommonUtils.id,E.qy`<common-utils :config=${t=>t.config.widgetConfigs.CommonUtils}></common-utils>`)} ${(0,pt.z)(t=>t.activeWidgetId===t.config.widgetConfigs.ConsoleMonitor.id,E.qy`<console-monitor :config=${t=>t.config.widgetConfigs.ConsoleMonitor} appErrorsCnt=${t=>t.appErrorsCnt} :appErrors=${t=>t.appErrors}></console-monitor>`)} ${(0,pt.z)(t=>t.activeWidgetId===t.config.widgetConfigs.CurrentFlights.id,E.qy`<current-flights :config=${t=>t.config.widgetConfigs.CurrentFlights} :expBaseUrl=${t=>t.config.expBaseUrl}></current-flights>`)} ${(0,pt.z)(t=>t.activeWidgetId===t.config.widgetConfigs.CoachmarkInfo.id,E.qy`<coachmark-info :config=${t=>t.config.widgetConfigs.CoachmarkInfo}></coachmark-info>`)}
`,tn=E.qy`<div class="panel ${t=>t.panelSize}"><div class="header"><div class="left"><fluent-button class="icon-button" appearance="stealth" @click=${t=>t.updateActiveWigdetId(null)}>${E.qy.partial(Wi())}</fluent-button><div class="title">${t=>t.panelTitle}</div></div><div class="right"><fluent-button class="icon-button" appearance="stealth" @click=${t=>t.toggleFullscreen()}>${(0,pt.z)(t=>t.panelSize===at.fullscreen,E.qy`${E.qy.partial(Ji())}`)} ${(0,pt.z)(t=>t.panelSize!==at.fullscreen,E.qy`${E.qy.partial(Yi())}`)}</fluent-button><fluent-button class="icon-button" appearance="stealth" @click=${t=>t.panelSize=at.collapsed}>${E.qy.partial(Xi())}</fluent-button></div></div><div class="content">${(0,pt.z)(t=>t.activeWidgetId,Zi)} ${(0,pt.z)(t=>!t.activeWidgetId,Qi)}</div></div>`,en=E.qy`<style>${Zt}</style><div class="debug-menu"><fluent-switch current-checked="${t=>t.renderFeedXRay}" @change=${t=>{t.renderFeedXRay=!t.renderFeedXRay}}>Feed X-Ray</fluent-switch><fluent-switch current-checked="${t=>t.renderDevToolsPanel}" @change=${t=>{t.renderDevToolsPanel=!t.renderDevToolsPanel,t.togglePanel()}}>Dev Tools</fluent-switch></div>`,nn=t=>E.qy`${function(t,e){let i,n;i=void 0===t?(0,xt.a)(t=>t):(0,bt.f)(t);let o=!1;if(void 0===e)o=!0,n=(0,xt.a)((t,e)=>{var n;const o=i.evaluate(t,e);return o instanceof Node?null!==(n=o.$fastTemplate)&&void 0!==n?n:new Rt(o):Mt(Ht(o))});else if((0,ft.Tn)(e))n=(0,u.U)((t,n)=>{var o;let s=e(t,n);return(0,ft.Kg)(s)?s=Mt(Ht(i.evaluate(t,n),s)):s instanceof Node&&(s=null!==(o=s.$fastTemplate)&&void 0!==o?o:new Rt(s)),s},void 0,!0);else if((0,ft.Kg)(e))o=!0,n=(0,xt.a)((t,n)=>{var o;const s=i.evaluate(t,n);return s instanceof Node?null!==(o=s.$fastTemplate)&&void 0!==o?o:new Rt(s):Mt(Ht(s,e))});else if(e instanceof mt.O){const t=e.evaluate;e.evaluate=(e,n)=>{var o;let s=t(e,n);return(0,ft.Kg)(s)?s=Mt(Ht(i.evaluate(e,n),s)):s instanceof Node&&(s=null!==(o=s.$fastTemplate)&&void 0!==o?o:new Rt(s)),s},n=e}else n=(0,xt.a)((t,i)=>e);return new Ct(i,n,o)}(t,en)}`,on=E.qy`<div class="debug-menu-toggle-button" @mouseenter=${(t,e)=>e.event&&ze.b.registerTrigger({triggerElement:e.event.currentTarget,childrenRenderer(){return nn(t)},childrenType:"WC",renderOnRegister:!0,customContainerSelector:"fluent-design-system-provider",popoverPosition:{vertical:"above",horizontal:"end"}})}><fluent-button class="icon-button" appearance="stealth">${E.qy.partial(qi())}</fluent-button></div>`,sn=E.qy` ${(0,pt.z)(t=>t.isActivated,E.qy` ${on} ${(0,pt.z)(t=>t.renderDevToolsPanel,tn)} ${(0,pt.z)(t=>t.renderFeedXRay,E.qy`<feed-x-ray></feed-x-ray>`)} `)}
`,rn={experienceConfigSchema:undefined};n.m.define(o.c.registry),s.m.define(o.c.registry),r.m.define(o.c.registry),a.m.define(o.c.registry),rt.define(o.c.registry),ot.define(o.c.registry),et.define(o.c.registry),lt.m.define(o.c.registry)},35792(t,e,i){"use strict";i.d(e,{b(){return l}});var n=i(77558),o=i(31157),s=i(90905),r=i(77367),a=i(85349);class l{static init(t){if(l.isInitialized)return;l.isInitialized=!0;const e=document.createElement("div");e.classList.add("popover-manager"),e.style.position="relative",e.style.zIndex=(n.P.Dialog+1).toString(),l.container=e;((t&&document.querySelector(t))??document.querySelector("#root")??document.body).insertAdjacentElement("afterbegin",e),["scroll","resize"].forEach(t=>l.registerTriggerListener({element:window,eventName:t,handler:(0,s.A)(()=>l.alignDismissActivePopover(),100)}))}static dispose(){l.dismissActivePopover?l.dismissActivePopover():l.removeActivePopover(),l.removeAllTriggerListeners(),l.isInitialized=!1,l.dismissActivePopover=null,l.lastTrigger=null,l.triggerListeners=[],l.container&&l.container.remove(),l.container=null,d.dispose()}static dismiss(){this.dismissActivePopover&&this.dismissActivePopover()}static registerTrigger(t){let{triggerElement:e,childrenRenderer:i,childrenType:n,renderOnRegister:o,onToggle:s,triggerMode:d,popoverPosition:c,delay:h,customContainerSelector:u}=t;l.init(u);if(!e||!i||!["WC"].includes(n)||l.triggerListeners.some(t=>t.element==e))return;e.style.cursor="pointer",e.style.pointerEvents="auto",e.tabIndex=0;const p=t=>{if(l.lastTrigger==e)return;r.YT.sendActionEvent(e,a.EG.Hover,a.MS.Show);l.renderPopover(e,{callbacks:{onDismiss(){return s&&s(!1)},onMount(t){var e;e=t,i().render({},e),s&&s(!0)}},focusBackTriggerElement:t,hideOnOutsideClick:"click"===d,position:c})},g=function(){for(var t=arguments.length,i=new Array(t),n=0;n<t;n++)i[n]=arguments[n];if(h&&h>0){const t=setTimeout(()=>p(...i),h);e.addEventListener("mouseleave",()=>clearTimeout(t),{once:!0})}else p(...i)};[{element:e,eventName:"click"===d?"click":"mouseenter",handler(){return g(!1)}},{element:e,eventName:"keyup",handler(t){"Enter"==t.key&&g(!0)}}].forEach(t=>l.registerTriggerListener(t)),o&&g()}static renderPopover(t,e){const i=e&&e.callbacks,n=e&&e.hideOnOutsideClick,o=e&&e.focusBackTriggerElement;l.removeActivePopover(),l.lastTrigger=t;const s=document.createElement("div");l.instance=s,s.style.visibility="hidden",s.style.position="absolute",s.style.zIndex="1",i&&i.onMount&&i.onMount(s);const r=l.container;r.insertAdjacentElement("afterbegin",s),l.alignDismissActivePopover(null==e?void 0:e.position),s.style.visibility="visible";const a=t=>function(t,e){if("Tab"!==t.key)return;t.preventDefault(),t.stopImmediatePropagation();const i="trapFocused",n=(t,e)=>{t&&t.classList.remove(i),e.classList.add(i),e.focus()},o=c('*[role="button"], a[href]:not([disabled]), button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])',e),s=c(`.${i}`,e),r=s&&s.length>0&&s[0];if(!r)return void n(null,o[0]);let a;o.forEach((t,e)=>{t==r&&(a=e)});const l=t.shiftKey?-1:1,d=(a+l+o.length)%o.length;n(r,o[d])}(t,l.instance);l.dismissActivePopover=()=>{l.lastTrigger===t&&(l.removeActivePopover(),d.removeEventListeners([t,s,r]),window.removeEventListener("keydown",a,{capture:!0}),o&&t.focus(),i&&i.onDismiss&&i.onDismiss())},n?d.attachDismissOnOutsideClick(s,l.dismissActivePopover):d.attachDismissOnLeave([t,s,r],l.dismissActivePopover),d.attachDismissOnKeyPress(t,l.dismissActivePopover),window.addEventListener("keydown",a,{capture:!0})}static alignDismissActivePopover(t){if(!l.instance||!l.lastTrigger)return;const e=l.lastTrigger,i=l.instance;i.style.transform="";const n=e.getBoundingClientRect(),o=i.getBoundingClientRect(),{translateX:s,translateY:r}=this.getPopoverTransform(n,o,t);i.style.transform=`translateX(${s}px) translateY(${r}px)`,function(t){const e=t.getBoundingClientRect();return e.bottom>=0&&e.left>=0&&e.top<=(window.innerHeight||document.documentElement.clientHeight)&&e.right<=(window.innerWidth||document.documentElement.clientWidth)}(i)||l.dismissActivePopover&&l.dismissActivePopover()}static getPopoverTransform(t,e,i){const{vertical:n="below",horizontal:s="start"}=i||{},r=document.dir===o.O.ltr?"left":"right";let a=t.bottom-e.top-1;"above"===n&&(a=t.top-e.bottom+1);let l=t[r]-e[r];return"end"===s&&(l=l+t.width-e.width),{translateX:l,translateY:a}}static removeActivePopover(){l.instance&&l.instance.remove(),l.instance=null,l.lastTrigger=null}static registerTriggerListener(t){let{element:e,eventName:i,handler:n}=t;l.triggerListeners.push({element:e,eventName:i,handler:n}),e.addEventListener(i,n)}static removeAllTriggerListeners(){for(;l.triggerListeners.length>0;)try{const{element:t,eventName:e,handler:i}=l.triggerListeners.pop();t.removeEventListener(e,i)}catch(t){}}}l.isInitialized=!1,l.triggerListeners=[];class d{static addEventListener(t,e,i){this.listenerMap.push({target:t,eventName:e,listener:i}),t.addEventListener(e,i)}static removeEventListeners(t){this.listenerMap.filter(e=>t.includes(e.target)).forEach(t=>t.target.removeEventListener(t.eventName,t.listener))}static attachDismissOnLeave(t,e){const i=t=>{setTimeout(()=>!d.isDismissCancelled&&e(t),250),d.isDismissCancelled=!1},n=t=>{d.isDismissCancelled=!0};t.forEach(t=>this.addEventListener(t,"mouseleave",i)),t.forEach(t=>this.addEventListener(t,"mouseenter",n))}static attachDismissOnOutsideClick(t,e){const i=n=>{t.contains(n.target)||(e(n),window.removeEventListener("click",i,{capture:!0}))};window.addEventListener("click",i,{capture:!0})}static attachDismissOnKeyPress(t,e){const i=n=>{"Escape"==n.key&&(e(n),window.removeEventListener("keyup",i,{capture:!0}),t.focus())};window.addEventListener("keyup",i,{capture:!0})}static dispose(){this.listenerMap.forEach(t=>t.target.removeEventListener(t.eventName,t.listener)),this.listenerMap=[]}}function c(t,e){e=e||document;const i=Array.from(e.querySelectorAll(t)),n=function(e){c(t,e).forEach(t=>{i.includes(t)||i.push(t)})};e.shadowRoot&&n(e.shadowRoot);for(const t of[...e.querySelectorAll("*")])t.shadowRoot&&n(t.shadowRoot);return i}d.listenerMap=[]},43382(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M4.15 12.35a.5.5 0 010-.7L9.6 6.16a.55.55 0 01.78 0l5.46 5.49a.5.5 0 01-.7.7L10 7.2l-5.15 5.16a.5.5 0 01-.7 0z"></path></svg>'},44995(t){t.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M13 14.05V14H4.25C3.01 14 2 15 2 16.25v.58c0 .89.32 1.75.9 2.43C4.47 21.1 6.85 22 10 22c.36 0 .7-.01 1.04-.03-.03-.15-.04-.31-.04-.47v-1.03c-.32.02-.65.03-1 .03-2.74 0-4.7-.74-5.96-2.21-.34-.41-.54-.93-.54-1.46v-.58c0-.41.34-.75.75-.75h6.96A2.5 2.5 0 0113 14.05zM10 2a5 5 0 110 10 5 5 0 010-10zm0 1.5a3.5 3.5 0 100 7 3.5 3.5 0 000-7zM14 15h-.5c-.83 0-1.5.67-1.5 1.5v5c0 .83.67 1.5 1.5 1.5h8c.83 0 1.5-.67 1.5-1.5v-5c0-.83-.67-1.5-1.5-1.5H21v-1.25c0-.97-.78-1.75-1.75-1.75h-3.5c-.97 0-1.75.78-1.75 1.75V15zm1.5-1.25c0-.14.11-.25.25-.25h3.5c.14 0 .25.11.25.25V15h-4v-1.25z"></path></svg>'},48785(t,e,i){"use strict";i.d(e,{m(){return a}});var n=i(37180),o=i(10300),s=i(55358),r=i(21082);const a=o.I.compose({name:`${n.c.prefix}-combobox`,template:r.v,styles:s.R})},49473(t,e,i){"use strict";i.d(e,{m(){return z}});var n=i(96789),o=i(37180),s=i(74849),r=i(64187),a=i(73477),l=i(22131),d=i(50882),c=i(7896),h=i(61138),u=i(26920),p=i(22683),g=i(74838),v=i(48751),f=i(14996),m=i(4283),x=i(48196);const b=s.A`
    ${(0,r.V)("flex")} :host {
        box-sizing: border-box;
        font-family: ${c.O};
        flex-direction: column;
        font-size: ${h.k};
        line-height: ${h.F};
        border-bottom: calc(${u.XA} * 1px) solid ${p.hb};
    }

    .region {
        display: none;
        padding: calc((6 + (${g.vR} * 2 * ${g.Br})) * 1px);
    }

    .heading {
        display: grid;
        position: relative;
        grid-template-columns: auto 1fr auto calc(${x.D} * 1px);
        z-index: 2;
    }

    .button {
        appearance: none;
        border: none;
        background: none;
        grid-column: 2;
        grid-row: 1;
        outline: none;
        padding: 0 calc((6 + (${g.vR} * 2 * ${g.Br})) * 1px);
        text-align: left;
        height: calc(${x.D} * 1px);
        color: ${v.l};
        cursor: pointer;
        font-family: inherit;
    }

    .button:hover,
    .button:active {
        color: ${v.l};
    }

    .button::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 1;
        cursor: pointer;
    }

    ${""}
    .button:${a.N}::before {
        outline: none;
        border: calc(${u.XA} * 1px) solid ${f.WN};
        box-shadow: 0 0 0 calc((${u.vd} - ${u.XA}) * 1px)
            ${f.WN};
    }

    :host([expanded]) .region {
        display: block;
    }

    .icon {
        display: flex;
        align-items: center;
        justify-content: center;
        grid-column: 4;
        z-index: 2;
        pointer-events: none;
        fill: ${m.IR};
    }

    ::slotted([name="collapsed-icon"]) {
        display: flex;
    }

    :host([expanded]) ::slotted([name="collapsed-icon"]),
    :host([expanded]) .collapsed-icon {
        display: none;
    }

    .expanded-icon,
    ::slotted([name="expanded-icon"]) {
        display: none;
    }

    :host([expanded]) ::slotted([name="expanded-icon"]),
    :host([expanded]) .expanded-icon {
        display: flex;
    }

    ::slotted([name="start"]) {
        display: flex;
        align-items: center;
        padding-inline-start: calc(${g.vR} * 1px);
        justify-content: center;
        grid-column: 1;
        z-index: 2;
    }

    ::slotted([name="end"]) {
        display: flex;
        align-items: center;
        justify-content: center;
        grid-column: 3;
        z-index: 2;
    }
`.withBehaviors((0,l.mr)(s.A`
            ${""}
            .button:${a.N}::before {
                border-color: ${d.A.Highlight};
                box-shadow: 0 0 0 calc((${u.vd} - ${u.XA}) * 1px)
                    ${d.A.Highlight};
            }
            .icon {
                fill: ${d.A.ButtonText};
            }
        `));var w=i(96950),y=i(60402),$=i(35106),k=i(18893);const C=function(t={}){return w.qy`
        <div
            class="heading"
            part="heading"
            role="heading"
            aria-level="${t=>t.headinglevel}"
        >
            <button
                class="button"
                part="button"
                ${(0,y.K)("expandbutton")}
                aria-expanded="${t=>t.expanded}"
                aria-controls="${t=>t.id}-panel"
                id="${t=>t.id}"
                @click="${(t,e)=>t.clickHandler(e.event)}"
            >
                <span class="heading-content" part="heading-content">
                    <slot name="heading"></slot>
                </span>
            </button>
            ${(0,$.LT)(t)}
            ${(0,$.aO)(t)}
            <span class="icon" part="icon" aria-hidden="true">
                <slot name="expanded-icon">
                    ${(0,k.R)(t.expandedIcon)}
                </slot>
                <slot name="collapsed-icon">
                    ${(0,k.R)(t.collapsedIcon)}
                </slot>
            <span>
        </div>
        <div
            class="region"
            part="region"
            id="${t=>t.id}-panel"
            role="region"
            aria-labelledby="${t=>t.id}"
        >
            <slot></slot>
        </div>
`}({collapsedIcon:w.qy`
        <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
            class="collapsed-icon"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M16.22 3H3.78a.78.78 0 00-.78.78v12.44c0 .43.35.78.78.78h12.44c.43 0 .78-.35.78-.78V3.78a.78.78 0 00-.78-.78zM3.78 2h12.44C17.2 2 18 2.8 18 3.78v12.44c0 .98-.8 1.78-1.78 1.78H3.78C2.8 18 2 17.2 2 16.22V3.78C2 2.8 2.8 2 3.78 2zM11 9h3v2h-3v3H9v-3H6V9h3V6h2v3z"
            />
        </svg>
    `,expandedIcon:w.qy`
        <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
            class="expanded-icon"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M3.78 3h12.44c.43 0 .78.35.78.78v12.44c0 .43-.35.78-.78.78H3.78a.78.78 0 01-.78-.78V3.78c0-.43.35-.78.78-.78zm12.44-1H3.78C2.8 2 2 2.8 2 3.78v12.44C2 17.2 2.8 18 3.78 18h12.44c.98 0 1.78-.8 1.78-1.78V3.78C18 2.8 17.2 2 16.22 2zM14 9H6v2h8V9z"
            />
        </svg>
    `}),z=n.k.compose({name:`${o.c.prefix}-accordion-item`,template:C,styles:b})},50149(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M11 13.5a.5.5 0 111 0 .5.5 0 01-1 0zM7.5 13a.5.5 0 100 1 .5.5 0 000-1zM3 4.5A2.5 2.5 0 015.5 2h8A2.5 2.5 0 0116 4.5v11a2.5 2.5 0 01-2.5 2.5h-8A2.5 2.5 0 013 15.5v-11zm7 1a.5.5 0 00-1 0V6H7.5a.5.5 0 000 1H9v1H6.5a.5.5 0 000 1H9v1H6.5a.5.5 0 000 1H9v1H7.5a1.5 1.5 0 101.41 1h1.18a1.5 1.5 0 101.41-1H10v-1h2.5a.5.5 0 000-1H10V9h2.5a.5.5 0 000-1H10V7h1.5a.5.5 0 000-1H10v-.5z"></path></svg>'},55358(t,e,i){"use strict";i.d(e,{R(){return c}});var n=i(60993),o=i(73477),s=i(74849),r=i(11152),a=i(17767),l=i(41123),d=i(26920);const c=s.A`
    ${r.x9}

    :host(:empty) .listbox {
        display: none;
    }

    :host([disabled]) *,
    :host([disabled]) {
        cursor: ${n.Z};
        user-select: none;
    }

    :host(:active) .selected-value {
        user-select: none;
    }

    .selected-value {
        -webkit-appearance: none;
        background: transparent;
        border: none;
        color: inherit;
        font-size: ${l.K};
        line-height: ${l.Z};
        height: calc(100% - ${d.XA} * 1px));
        margin: auto 0;
        width: 100%;
    }

    .selected-value:hover,
    .selected-value:${o.N},
    .selected-value:disabled,
    .selected-value:active {
        outline: none;
    }
`.withBehaviors((0,a.f)("filled",r.x7))},66801(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M9.65 2.15c.2-.2.5-.2.7 0l2 2a.5.5 0 01-.7.7L10.5 3.71V6.5a.5.5 0 01-1 0V3.7L8.35 4.86a.5.5 0 11-.7-.7l2-2zM10 12a2 2 0 100-4 2 2 0 000 4zm0-1a1 1 0 110-2 1 1 0 010 2zm5.85 1.35l2-2a.5.5 0 000-.7l-2-2a.5.5 0 00-.7.7l1.14 1.15H13.5a.5.5 0 000 1h2.8l-1.15 1.15a.5.5 0 00.7.7zm-5.5 5.5l2-2a.5.5 0 00-.7-.7l-1.15 1.14V13.5a.5.5 0 00-1 0v2.8l-1.15-1.15a.5.5 0 00-.7.7l2 2c.2.2.5.2.7 0zm-8.2-7.5a.5.5 0 010-.7l2-2a.5.5 0 11.7.7L3.71 9.5H6.5a.5.5 0 010 1H3.7l1.15 1.15a.5.5 0 01-.7.7l-2-2z"></path></svg>'},69423(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M15.85 7.65c.2.2.2.5 0 .7l-5.46 5.49a.55.55 0 01-.78 0L4.15 8.35a.5.5 0 11.7-.7L10 12.8l5.15-5.16c.2-.2.5-.2.7 0z"></path></svg>'},72778(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10 2a8 8 0 110 16 8 8 0 010-16zm0 1a7 7 0 100 14 7 7 0 000-14zM7.8 7.11l.08.06L10 9.3l2.12-2.12a.5.5 0 01.64-.06l.07.06c.17.18.2.44.06.64l-.06.07L10.7 10l2.12 2.12c.17.17.2.44.06.64l-.06.07a.5.5 0 01-.64.06l-.07-.06L10 10.7l-2.12 2.12a.5.5 0 01-.64.06l-.07-.06a.5.5 0 01-.06-.64l.06-.07L9.3 10 7.17 7.88a.5.5 0 01-.06-.64l.06-.07a.5.5 0 01.64-.06z"></path></svg>'},83341(t){t.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M17.5 12a5.5 5.5 0 110 11 5.5 5.5 0 010-11zm0 7.75a.62.62 0 100 1.25.62.62 0 000-1.25zm0-5.88c-1.05 0-1.86.82-1.85 1.96a.5.5 0 001-.01c0-.58.36-.95.85-.95.47 0 .85.4.85.95 0 .2-.05.35-.22.57l-.1.11-.1.11-.26.3-.14.15c-.38.46-.53.8-.53 1.31a.5.5 0 101 0c0-.2.06-.36.24-.59l.08-.1.1-.12.27-.29.14-.15c.37-.45.52-.79.52-1.3 0-1.1-.82-1.95-1.85-1.95zm-5.48.13c-.3.46-.53.97-.7 1.5H4.24a.75.75 0 00-.75.75v.58c0 .53.2 1.05.54 1.46C5.3 19.76 7.26 20.5 10 20.5c.6 0 1.16-.03 1.68-.1.25.49.55.95.91 1.36-.8.16-1.66.24-2.59.24-3.15 0-5.53-.9-7.1-2.74a3.75 3.75 0 01-.9-2.43v-.58C2 15 3.01 14 4.25 14h7.77zM10 2a5 5 0 110 10 5 5 0 010-10zm0 1.5a3.5 3.5 0 100 7 3.5 3.5 0 000-7z"></path></svg>'},84258(t){t.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M17.75 14C19 14 20 15 20 16.25v.57c0 .9-.32 1.76-.9 2.44C17.53 21.1 15.15 22 12 22c-3.15 0-5.53-.9-7.1-2.74a3.75 3.75 0 01-.9-2.43v-.58C4 15 5.01 14 6.25 14h11.5zm0 1.5H6.25a.75.75 0 00-.75.75v.58c0 .53.2 1.05.54 1.46C7.3 19.76 9.26 20.5 12 20.5c2.74 0 4.7-.74 5.96-2.21.35-.41.54-.93.54-1.47v-.57a.75.75 0 00-.75-.75zM12 2a5 5 0 110 10 5 5 0 010-10zm0 1.5a3.5 3.5 0 100 7 3.5 3.5 0 000-7z"></path></svg>'},86664(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M4.5 3C3.67 3 3 3.67 3 4.5v7c0 .83.67 1.5 1.5 1.5h7c.83 0 1.5-.67 1.5-1.5V9.27a.5.5 0 011 0v2.23a2.5 2.5 0 01-2.5 2.5h-7A2.5 2.5 0 012 11.5v-7A2.5 2.5 0 014.5 2h2.23a.5.5 0 010 1H4.5zm4.27-.5c0-.28.22-.5.5-.5h4.23c.28 0 .5.22.5.5v4.23a.5.5 0 01-1 0V3.71L9.62 7.08a.5.5 0 11-.7-.7L12.29 3H9.27a.5.5 0 01-.5-.5z"></path></svg>'},87656(t,e,i){"use strict";i.d(e,{g(){return o}});var n=i(7813);function o(t){if("string"==typeof t)return t;if("function"==typeof t&&!(t=n.I.getByType(t)))throw new Error("Missing FASTElement definition.");return t.name}},96789(t,e,i){"use strict";i.d(e,{k(){return l}});var n=i(56911),o=i(92011),s=i(38493),r=i(35106),a=i(88458);class l extends o.L{constructor(){super(...arguments),this.headinglevel=2,this.expanded=!1,this.clickHandler=t=>{this.expanded=!this.expanded,this.change()},this.change=()=>{this.$emit("change")}}}(0,n.Cg)([(0,s.CF)({attribute:"heading-level",mode:"fromView",converter:s.R$}),(0,n.Sn)("design:type",Number)],l.prototype,"headinglevel",void 0),(0,n.Cg)([(0,s.CF)({mode:"boolean"}),(0,n.Sn)("design:type",Boolean)],l.prototype,"expanded",void 0),(0,n.Cg)([s.CF,(0,n.Sn)("design:type",String)],l.prototype,"id",void 0),(0,a.X)(l,r.qw)}}]);