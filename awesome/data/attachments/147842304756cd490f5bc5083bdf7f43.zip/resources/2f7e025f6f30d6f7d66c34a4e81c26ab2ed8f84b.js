"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-medal"],{4968(e,t,r){r.d(t,{f(){return s}});var i=r(64187),a=r(74849),o=r(42792),l=r(99657),n=r(36452);const s=a.A.partial`position: relative; z-index: ${l.D};`;a.A`
    ${o.e}
    ${o.nH}

    ${(0,i.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${s}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${n.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${n.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${n.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},17471(e,t,r){r.r(t),r.d(t,{SportsTable(){return _}});var i=r(56911),a=r(92011),o=r(48751),l=r(62047),n=r(41123),s=r(61138),d=r(86856),c=r(74849),p=r(22131),g=r(4968),h=r(12640);const x=c.A` .table-card{color:rgba(255,255,255,1)}.card-header{color:rgba(255,255,255,1)}.card-header-tag{box-shadow:inset 0px 0px 0px 2px rgba(255,153,164,1)}.card-header-tag >span:nth-of-type(1){background:rgba(255,153,164,1);color:rgba(68,39,38,1)}.card-header-tag >span:nth-of-type(2){background:rgba(68,39,38,1);color:rgba(255,153,164,1)}.table-cell{border-top:1px solid rgba(255,255,255,0.07)}.no-border{border-top:none}.underlay{opacity:0.16}`,b=c.A` .line >img{margin-left:2px}.line >img.extra-margin{margin-left:4px}.line{padding-right:0px;padding-left:4px}.head-cell{padding-right:0px;padding-left:4px}.card-header-tag >span:nth-of-type(2){border-top-right-radius:0;border-bottom-right-radius:0;border-top-left-radius:3px;border-bottom-left-radius:3px}`,u=c.A` .table-container{text-decoration:none}.clickable{${g.f}}.table-card{margin-top:8px;width:268px;height:fit-content;background:none;color:${o.l};border-radius:8px;padding:8px 12px;box-sizing:border-box}.table-card.fill-card{margin-top:0px;padding:0px 12px;background:inherit}.card-header{display:flex;justify-content:space-between;align-items:baseline;padding:0 0 8px;color:${o.l}}.card-header >div{display:flex;font-size:12px;font-weight:600}.card-header-tag{height:18px;line-height:${l.e};box-shadow:inset 0px 0px 0px 4px rgba(196,43,28,1);border-radius:4px;padding:2px 2px;box-sizing:border-box}.card-header-tag >span{display:inline-block;font-size:${l.t};font-weight:600;box-sizing:border-box;padding:0px 2px}.card-header-tag >span:nth-of-type(1){background:rgba(196,43,28,1);color:rgba(255,255,255,1)}.card-header-tag >span:nth-of-type(2){background:rgba(255,255,255,1);color:rgba(196,43,28,1);border-top-right-radius:3px;border-bottom-right-radius:3px}.grid-table{display:grid;width:244px;grid-template-columns:minmax(20px,auto) 1fr minmax(auto,42px) minmax(auto,70px);grid-template-rows:repeat(9,28px)}.table-cell{position:relative;border-top:1px solid rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.line{font-size:${l.t};font-style:normal;font-weight:400;display:flex;align-items:center;padding:0 4px 0 0;width:100%;z-index:1}.line.large-font{font-size:${n.K}}.line > div{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.pre-text{font-size:${l.t};font-weight:600;width:14px;min-width:14px;padding-right:6px}.pre-text.large-font{font-size:${n.K};font-weight:400;width:16px}.head-cell{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;border-top:1px solid rgba(0,0,0,0.06);font-size:${s.k};font-style:normal;font-weight:600;display:flex;align-items:center;padding:0 4px 0 0}.hidden{display:none}.no-border{border-top:none}.overflow{overflow:visible}.line > sup{margin:0 0 4px 1px}.right{justify-content:end}.center{justify-content:center}.left{justify-content:start}.top{align-items:flex-start}.middle{align-items:center}.bottom{align-items:flex-end}.bold{font-weight:600}.line > img{margin-right:2px;height:16px;width:16px}.line > img.extra-margin{margin-right:4px}.iconround > img{border-radius:50%}img.icon-20{height:20px;width:20px;min-width:20px}.line > img.icon-24{height:24px;width:24px;min-width:24px}.font-xs{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.font-s{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.font-m{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.font-l{font-size:var(--smtc-text-ramp-lg-item-body-font-size,16px);line-height:var(--smtc-text-ramp-lg-item-body-line-height,26px)}.align-right{justify-content:flex-end;padding-right:0}.secondary{color:var(--smtc-foreground-ctrl-neutral-secondary-rest,#4c4642)}.underlay{position:absolute;top:-2px;height:calc(100% + 4px);width:100%;background:#0178A7;opacity:0.08}.first-column .underlay{border-radius:12px 0px 0px 12px;width:calc(100% + 4px);left:-4px}.last-column .underlay{border-radius:0px 12px 12px 0px}.no-padding .line,.no-padding .head-cell{padding:0px}.full-width .table-card{width:100%}.cplt .table-card{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320)}`.withBehaviors(new d.t(null,b),new h.N(null,x),(0,p.mr)(c.A` :host{forced-color-adjust:auto}`));var f=r(96950),v=r(39957),$=r(69259);const m=f.qy`
    ${e=>void 0!==e.viewModel.data.title?f.qy`
        <div class="card-header" style="${e=>e.viewModel.headerStyles}">
            <div style="${e=>e.viewModel.data.titleStyles}">${e=>e.viewModel.data.title}</div>
            ${e=>void 0!==e.viewModel.data.subTitle?f.qy`
                <div class="card-header-tag">
                    <span>${e=>e.viewModel.data.tagName}</span>
                    <span>${e=>e.viewModel.data.subTitle}</span>
                </div>`:""}
            ${e=>void 0!==e.viewModel.data.subTitleText?f.qy`
                <div style="${e=>e.viewModel.data.subTitleStyles}">
                    <span>${e=>e.viewModel.data.subTitleText}</span>
                </div>`:""}
        </div>
    `:""}
`,y=f.qy`
    ${(0,v.ux)(e=>e.getHeaderValues(),f.qy`
        <div class="head-cell ${e=>void 0!==e.class?e.class:""}" style="${e=>e.textStyles}">
            ${e=>void 0!==e.icon?f.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null}"
            />`:""}
            ${e=>e.value}
        </div>
    `)}
`,w=f.qy`
    ${(0,v.ux)(e=>e.getAllBodyCells(),()=>f.qy`
    <div class="table-cell ${e=>void 0!==e.cellClass?e.cellClass:""}">
        ${e=>e.isHightlighted?f.qy`<div class="underlay"></div>`:""}
        <div class="line ${e=>void 0!==e.class?e.class:""}">
            ${e=>void 0!==e.preText?f.qy`<div class="pre-text ${e=>void 0!==e.preTextClass?e.preTextClass:""}" style="${e=>e.preTextStyles}">${e.preText}</div>`:""}
            ${e=>void 0!==e.icon?f.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null} ${e=>e.icon?"":"hidden"}"
                onerror="this.style.display='none'"
            />`:""}
            ${e=>f.qy`<div style="${e=>e.textStyles}" title=${e=>e.value}>${e.value}</div>`}
            ${e=>void 0!==e.index?f.qy`<sup>${e.index}</sup>`:""}
        </div>
        <div class="line ${e=>void 0!==e.classL2?e.classL2:""}">
            ${e=>f.qy`<div>${e.valueL2}</div>`}
        </div>
    </div>
`)}
`,k=f.qy`
    <a
        class="${e=>e.viewModel.clickThroughUrl?"clickable":""} table-container ${e=>e.viewModel.tableClass}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="${e=>e.viewModel.clickThroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}" 
    >
        ${e=>e.viewModel.isHeaderAboveTheTable?m:""}
        <div
            class="table-card ${e=>e.viewModel.fillFullCard?"fill-card":""}"
            style="${e=>e.viewModel.tableStyles}"
        >
            ${e=>e.viewModel.isHeaderAboveTheTable?"":m}
            <div class="grid-table"
                style="${e=>`\n                    grid-template-columns: ${e.viewModel.columnStyle};\n                    grid-template-rows: ${e.viewModel.rowStyle};\n                    ${e.viewModel.gridStyles};\n                `}">
                ${e=>e.getHeaderValues().length>0?y:""}
                ${w}
            </div>
        </div>
    </a>
`,z=f.qy`
    ${(0,$.z)(e=>null!=e.viewModel,k)}
`;var S=r(92079);class T extends S.a{constructor(){super(...arguments),this.getKeys=()=>this.viewModel.data.keys,this.getHeaderValues=()=>{const{header:e}=this.viewModel.data;return e?this.getKeys().map(t=>e[t]):[]},this.isLarge=()=>"_1x_3y"===this.viewModel.cardSize,this.getAllBodyCells=()=>{const e=[],t=this.getKeys();return this.viewModel.data.body.forEach(r=>{t.forEach(t=>e.push(r[t]))}),e}}}let _=class extends T{};_=(0,i.Cg)([(0,a.E)({name:"sports-table",template:z,styles:u,shadowOptions:{delegatesFocus:!0}})],_)},42792(e,t,r){r.d(t,{R7(){return b},e(){return h},kc(){return x},nH(){return g}});var i=r(57416),a=r(55153),o=r(95239),l=r(26920),n=r(48751),s=r(64187),d=r(22131),c=r(74849),p=r(50882);const g=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,s.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${l.XA} * 1px) solid ${a.cu};
        border-radius: calc((${i.JU} - ${l.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${n.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${l.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${l.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${l.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,x=(0,d.mr)(c.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),b=c.A`
    ${h}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(x)},92079(e,t,r){r.d(t,{a(){return l}});var i=r(56911),a=r(92011),o=r(31525);let l=class extends a.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};l=(0,i.Cg)([o.x],l)},95861(e,t,r){r.r(t),r.d(t,{SportsMedalTransformer(){return p}});var i=r(49150),a=r(23587),o=r(85312),l=r(22341),n=r(58792),s=r(79811),d=r(54229),c=r(96950);class p extends a.Bc{constructor(){super(...arguments),this.dividerIndex=-1}async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,s.jJ)(),this.isHeroCard=!!e.isHeroCard;const r=await d.aC.safeExecuteAsync(async()=>this.getTableData(e),void 0,o.Ax,`SportsMedalTransformer - error getting tableData, ${JSON.stringify(e)}`);return{viewTemplate:c.qy`
                <sports-table
                    :viewModel="${r}"
                ></sports-table>
            `}}getTableHeader(){let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];const{strings:t}=this.transformerProvider,r=`${(0,n.rA)().StaticsUrl}latest/sports/icons/`,i=e?" no-border":"",a=this.isInDarkMode?"border-color: rgba(255, 255, 255, 0.1);":void 0;return{player:{value:t.team,class:`${i} ${this.isHeroCard?"font-s":"font-xs"}`,textStyles:a},follow:{value:"",class:`${i}`,textStyles:a},gold:{value:"",icon:`${r}OlympicGold.svg`,class:`center${i}`,textStyles:a},silver:{value:"",icon:`${r}OlympicSilver.svg`,class:`center${i}`,textStyles:a},bronze:{value:"",icon:`${r}OlympicBronze.svg`,class:`center${i}`,textStyles:a},total:{value:t.total,class:`center${i} ${this.isHeroCard?"font-s":"font-xs"}`,textStyles:a}}}iconUrl(e){return e?(0,s.iK)(e,!1,this.transformerProvider.config.teamImageInfoEnhanced):this.getTeamImageFallback()}getTeamImageFallback(){return`${(0,n.rA)().StaticsUrl}latest/sports/icons/TeamFlagFallback.svg`}getMedalColumn(e,t){let r=!(arguments.length>2&&void 0!==arguments[2])||arguments[2],i=arguments.length>3&&void 0!==arguments[3]&&arguments[3];return{value:`${t.medalsWon[e]??"-"}`,cellClass:(r?"":"no-border")+" middle",class:`center ${i?"large-font":"font-s"} ${"Total"!==e||this.isHeroCard?"":"bold"}`}}getTableBody(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1];return e.map((e,r)=>{const i=this.dividerIndex===r;return{player:{preText:`${e.overallRank}`,preTextClass:""+(t?"large-font":"font-s bold"),value:e.team.shortName||"-",icon:this.iconUrl(e.team.imageId),iconClass:"icon-24",textStyles:`margin-inline-start: ${this.isHeroCard?"4px":"6px"};`,cellClass:""+(i?"":"no-border"),class:""+(t?"large-font":"font-s bold")},follow:{value:"",icon:(0,s.Hn)(e.team.hasExplicitInterest)?`${(0,n.rA)().StaticsUrl}latest/sports/icons/OlympicFollow.svg`:void 0,cellClass:""+(i?"":"no-border")},gold:this.getMedalColumn("Gold",e,i,t),silver:this.getMedalColumn("Silver",e,i,t),bronze:this.getMedalColumn("Bronze",e,i,t),total:this.getMedalColumn("Total",e,i,t)}})}getColumnStyle(){return"minmax(30px, 1fr) 20px repeat(4, 32px)"}getRowStyle(e){return this.cardSize===i.uE._1x_1y?"24px 16px":this.cardSize===i.uE._1x_2y?`repeat(${e}, ${this.isHeroCard?"31px":"32px"})`:`18px repeat(${e-1}, 30px)`}getLocalTeamIndex(e){return e.findIndex(e=>(0,s.Hn)(e.team.isUserLocalTeam))}getFilteredData(e){if(this.cardSize===i.uE._1x_1y)return e.slice(0,1);const t=this.cardSize===i.uE._1x_2y?5:11,r=this.getLocalTeamIndex(e);return-1===r||r<t?e.slice(0,t):(this.dividerIndex=t-1,e.slice(0,t-1).concat(e[r]))}getDividerIndex(e){if(e.length<2)return-1;for(let t=1;t<e.length;t++){const r=e[t],i=e[t-1];if(r&&i&&Number(r.overallRank)-Number(i.overallRank)>1)return t}return-1}getHeaderSubTitleText(e){const{strings:t}=this.transformerProvider,r=(0,s.yn)(e),a=(0,s.AL)(r,n.T3.CurrentMarket||"en-us"),o=this.cardSize===i.uE._1x_3y?"-":"•",l=(0,s.yn)("2026-02-06T09:00:00"),d=Math.floor((r.getTime()-l.getTime())/864e5),c=d>0?d:0;return`${t.nthDay.replace("{0}",`${c}`)} ${o} ${a}`}getBackground(){return this.isHeroCard?"none":this.isInDarkMode?"rgba(26, 26, 26, 0.5)":"rgba(255, 255, 255, 0.5)"}getTablePadding(){if(arguments.length>0&&void 0!==arguments[0]&&arguments[0])return"0px;";switch(this.cardSize){case i.uE._1x_1y:return"4px 12px;";case i.uE._1x_2y:return"6px 8px;";default:return"6px 8px 2px;"}}tableStyles(){let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];const t=this.getTablePadding(e);return`background: ${this.getBackground()}; margin-top: 0px; padding: ${t}`}headerStyles(){return this.cardSize===i.uE._1x_2y?"padding: 0px; margin-bottom: 6px;":"padding: 0px; margin-bottom: 4px;"}gridStyles(){return""+(arguments.length>0&&void 0!==arguments[0]&&arguments[0]?"width: 268px":"width: 100%")}getTitleStyle(){switch(this.cardSize){case i.uE._1x_1y:return"font-size: 10px; line-height: 14px;";case i.uE._1x_2y:return"font-size: 12px; line-height: 16px;";default:return"font-size: 14px; line-height: 20px;"}}getSubtitleStyle(){switch(this.cardSize){case i.uE._1x_1y:case i.uE._1x_2y:return"font-size: 10px; line-height: 14px;";default:return"font-size: 12px; line-height: 16px;"}}getTableData(e){const{telemetryBuilder:t,strings:r}=this.transformerProvider,{medalData:s}=e;if(!s||!s.topRankedTeamStandings||0===s.topRankedTeamStandings.length)return void(0,l.vV)(o.Ax,"Medal table data missing",`market=${n.T3.CurrentMarket}`,JSON.stringify(e));const d=this.isHeroCard?void 0:r.medalTableHeader,c=this.getHeaderSubTitleText(s.eventDate),p=this.getTitleStyle(),g=this.getSubtitleStyle(),h=this.getTableHeader(this.isHeroCard||this.cardSize===i.uE._1x_3y),x=this.getFilteredData(s.topRankedTeamStandings),b=this.getTableBody(x,this.isHeroCard),u={title:d,titleStyles:p,subTitleText:c,subTitleStyles:g,keys:["player","follow","gold","silver","bronze","total"],header:h,body:b};return{telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:`${a.BP.SportsMedalCard}Table`}),isHeaderAboveTheTable:this.cardSize===i.uE._1x_3y,cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,data:u,clickThroughUrl:e.clickThroughUrl,columnStyle:this.getColumnStyle(),rowStyle:this.getRowStyle(b.length+1),tableStyles:this.tableStyles(this.isHeroCard),headerStyles:this.headerStyles(),gridStyles:this.gridStyles(this.isHeroCard)}}}Promise.resolve().then(r.bind(r,17471))},99657(e,t,r){r.d(t,{D(){return l},I(){return o}});var i=r(45755);const{create:a}=i.G,o=a("sloppy-click-z-index",1),l=a("click-z-index",1)}}]);