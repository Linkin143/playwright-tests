"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-tournaments-list"],{26807(e,t,n){n.r(t),n.d(t,{SportsTournamentsList(){return y}});var a=n(56911),i=n(92079);class r extends i.a{}var o=n(92011),s=n(74849),l=n(22131),d=n(48751);const u=s.A` .sports-tournament-list-content{color:${d.l};
    }
`,m=(0,l.G2)(u),c=s.A` .sports-tournament-list-content{text-decoration:none;color:${d.l};
        display: flex;
        flex-direction: column;
        position: relative;
        height: 100%;
        gap: 10px;
    }
`.withBehaviors(m);var v=n(96950),p=n(39957);const h=v.qy`
    <a
        class="sports-tournament-list-content ${e=>e.viewModel.cardSize}"
        href="${e=>e.viewModel.clickThroughUrl}"
        target="_blank"
        data-t="${e=>e.viewModel.telemetryTag}"
        >
        ${(0,p.ux)(e=>e.viewModel.tournaments,v.qy`
            <tournament-status-row
                :viewModel="${e=>e.viewModel}"
            ></tournament-status-row>
        `)}
    </a>
`,g=v.qy`
    ${e=>null!=e.viewModel?h:null}
`;let y=class extends r{};y=(0,a.Cg)([(0,o.E)({name:"sports-tournaments-list",template:g,styles:c,shadowOptions:{delegatesFocus:!0}})],y)},61469(e,t,n){n.r(t),n.d(t,{TournamentStatusRow(){return T}});var a=n(56911),i=n(92011),r=n(48751);const o="\n    font-size: var(--type-ramp-minus-1-font-size, 12px);\n    font-weight: 600;\n    line-height: var(--type-ramp-minus-1-line-height, 16px);\n",s="\n    overflow: hidden;\n    text-overflow: ellipsis;\n    white-space: nowrap;\n",l=n(74849).A`
.tournament-container{display:flex;flex-direction:column;gap:2px;padding:5px 8px;border-radius:8px;background:var(--sports-item-background);position:relative;max-width:252px;text-decoration:none;color:${r.l};z-index:1}.tournament-container:hover{background:var(--sports-item-hover-background)}.winner-image-container{height:16px;width:16px;display:flex;justify-content:center;align-items:flex-end}.live-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);color:#D13438;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.pregame-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.postgame-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.inprogress-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);color:#D13438;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.tournament-location{${s} font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px);max-width:260px;height:100%}.tournament-title-container{display:flex;flex-direction:row;height:100%;align-items:flex-start;gap:6px;align-self:stretch}.tournament-details-container{display:flex;flex-direction:column;height:100%;gap:2px}.tournament-image{height:20px;width:20px}.tournament-title{font-size:var(--type-ramp-base-font-size,14px);font-weight:${"600"};
    line-height: var(--type-ramp-base-line-height, 20px);
    ${s} max-width:260px;height:100%}.winner-details-container{display:flex;justify-content:space-between;align-items:center}.winner-name-container{display:flex;flex-direction:row;align-items:center}.winner-score{${o}
    ${s} max-width:19px}.winner-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-weight:400;margin-right:2px}.winner-name{${o}
    ${s} max-width:128px}.winner-image{height:12px;width:12px}`;var d=n(96950),u=n(69259);Object.freeze({unknown:"unknown",preGame:"pre-game",inprogressGame:"inprogress-game",postGame:"post-game",tba:"tba"});const m=Object.freeze({unknown:"Unknown",preGame:"PreGame",inProgress:"InProgress",inProgressBreak:"InProgressBreak",postponed:"Postponed",suspended:"Suspended",cancelled:"Cancelled",forfeited:"Forfeited",delayed:"Delayed",final:"Final",bye:"Bye",abandoned:"Abandoned",live:"Live"});Object.freeze({Unknown:"Unknown",Invalid:"Invalid",PreGame:"PreGame",AboutToStart:"AboutToStart",ParticipantsAreNotKnownYet:"ParticipantsAreNotKnownYet",InProgress:"InProgress",InProgressBreak:"InProgressBreak",Postponed:"Postponed",Suspended:"Suspended",Cancelled:"Cancelled",Unscheduled:"Unscheduled",ForfeitedByBothTeams:"ForfeitedByBothTeams",ForfeitedByAwayTeam:"ForfeitedByAwayTeam",ForfeitedByHomeTeam:"ForfeitedByHomeTeam",ForfeitedByAwayTeamVacatedByHome:"ForfeitedByAwayTeamVacatedByHome",ForfeitedByHomeTeamVacatedByAway:"ForfeitedByHomeTeamVacatedByAway",VacatedByBothTeams:"VacatedByBothTeams",VacatedByAwayTeam:"VacatedByAwayTeam",VacatedByHomeTeam:"VacatedByHomeTeam",Delayed:"Delayed",StartDelayed:"StartDelayed",Final:"Final",Bye:"Bye",Retired:"Retired",Abandoned:"Abandoned",Unnecessary:"Unnecessary",Tea:"Tea",Lunch:"Lunch",InningsBreak:"InningsBreak",Stumps:"Stumps",RainDelay:"RainDelay",BadLight:"BadLight",CrowdTrouble:"CrowdTrouble",PitchCondition:"PitchCondition",FloodlightFailure:"FloodlightFailure",Drinks:"Drinks",SuperOver:"SuperOver",BadGroundCondition:"BadGroundCondition",BadWeatherCondition:"BadWeatherCondition",Dinner:"Dinner",Fog:"Fog",PlayHalted:"PlayHalted",StrategicTimeout:"StrategicTimeout",SuperOverInProgress:"SuperOverInProgress",WetGroundCondition:"WetGroundCondition",WetPitchCondition:"WetPitchCondition",DayWashedOut:"DayWashedOut",Toss:"Toss",MatchAbandonedWithoutToss:"MatchAbandonedWithoutToss",MatchAbandonedWithoutSingleBallBeingBowled:"MatchAbandonedWithoutSingleBallBeingBowled",MatchConceded:"MatchConceded",MatchAwarded:"MatchAwarded",Maintenance:"Maintenance"}),Object.freeze({full:"full",extendedBoxscore:"extended_boxscore",boxscore:"boxscore"}),Object.freeze({Unknown:"Unknown",PreGame:"PreGame",LiveGame:"LiveGame",PostGame:"PostGame"});const c=d.qy`
    <div class="live-tournament-status-title">
            ${e=>{var t,n;return`${null===(t=e.viewModel)||void 0===t||null===(t=t.strings)||void 0===t?void 0:t.sportsLive} • ${null===(n=e.viewModel)||void 0===n||null===(n=n.gameState)||void 0===n?void 0:n.name}`}}
    </div>
`,v=d.qy`
    <div class="pregame-tournament-status-title">
            ${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.gameScheduleString}}
    </div>
`,p=d.qy`
    <div class="postgame-tournament-status-title">
            ${e=>{var t,n;return`${null===(t=e.viewModel)||void 0===t?void 0:t.gameScheduleString} • ${null===(n=e.viewModel)||void 0===n||null===(n=n.strings)||void 0===n?void 0:n.sportsStateFinal}`}}
    </div>
`,h=d.qy`
    <div class="inprogress-tournament-status-title">
            ${e=>{var t;return null===(t=e.viewModel)||void 0===t||null===(t=t.strings)||void 0===t?void 0:t.inProgress}}
    </div>
`,g=d.qy`
    <div class="winner-details-container">
        <div class="winner-name-container">
            <span class="winner-text">${e=>{var t;return null===(t=e.viewModel)||void 0===t||null===(t=t.strings)||void 0===t?void 0:t.winner}}</span>
            <div class="winner-image-container">
                <img class="winner-image" src=${e=>{var t;return null===(t=e.viewModel)||void 0===t||null===(t=t.winnerDetails)||void 0===t?void 0:t.imageUrl}} alt=${e=>{var t;return null===(t=e.viewModel)||void 0===t||null===(t=t.winnerDetails)||void 0===t?void 0:t.name}}></img>
            </div>
            <span class="winner-name">${e=>{var t;return null===(t=e.viewModel)||void 0===t||null===(t=t.winnerDetails)||void 0===t?void 0:t.name}}</span>
        </div>
        <div class="winner-score">
            ${e=>{var t;return null===(t=e.viewModel)||void 0===t||null===(t=t.winnerDetails)||void 0===t?void 0:t.score}}
        </div>
    </div>
`,y=d.qy`
    <div class="tournament-location">
        ${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.locationName}}
    </div>
`,w=d.qy`
    <div class="tournament-details-container">
        <div class="tournament-title-container">
            <img class="tournament-image" src=${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.imageUrl}} alt=${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.name}}></img>
            <span class="tournament-title" title=${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.name}}>
                ${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.name}}
            </span>
        </div>
        ${(0,u.z)(e=>{var t;return(null===(t=e.viewModel)||void 0===t||null===(t=t.gameState)||void 0===t?void 0:t.state)!==m.final},y)}
        ${(0,u.z)(e=>{var t,n;return(null===(t=e.viewModel)||void 0===t||null===(t=t.gameState)||void 0===t?void 0:t.state)===m.final&&(null===(n=e.viewModel)||void 0===n?void 0:n.winnerDetails)},g)}
    </div>
`,x=d.qy`
<a
    class="tournament-container"
    href="${e=>e.viewModel.gameCenterUrl}"
    target="_blank"
    data-t="${e=>e.viewModel.telemetryTag}"
    tabindex="0"
    >
    ${e=>{var t;return(e=>{switch(e){case m.live:return c;case m.preGame:return v;case m.final:return p;case m.inProgress:return h;default:return v}})((null===(t=e.viewModel)||void 0===t||null===(t=t.gameState)||void 0===t?void 0:t.state)||"")}}
    ${w}
</a>
`,f=d.qy`
    ${(0,u.z)(e=>null!=e.viewModel,x)}
`;var $=n(92079);class B extends $.a{}let T=class extends B{};T=(0,a.Cg)([(0,i.E)({name:"tournament-status-row",template:f,styles:l})],T)},90095(e,t,n){n.r(t),n.d(t,{SportsTournamentStatusRowTransformer(){return m._},SportsTournamentsListTransformer(){return u}});var a=n(49150),i=n(23587),r=n(22341),o=n(85312),s=n(58792),l=n(79811),d=n(96950);class u extends i.Bc{async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,l.jJ)();const n=await this.getCurrentViewModel(e);return{viewTemplate:d.qy`
                <sports-tournaments-list
                    :viewModel="${n}"
                ></sports-tournaments-list>
            `}}async getCurrentViewModel(e){try{if(!e.data)return void(0,r.vV)(o.Ax,"Tournaments data missing",`market=${s.T3.CurrentMarket}`,e);e.data;const{telemetryBuilder:t}=this.transformerProvider,n=null==e?void 0:e.gameCenterUrl,a=n&&(0,l.Ot)(n),d=await this.getTournamentsData(e);return{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.SportsTournamentsListCard}),tournaments:d,clickThroughUrl:a}}catch(t){return void(0,r.vV)(o.Ax,"Error in transforming tournament list data",`market=${s.T3.CurrentMarket}`,e)}}async getTournamentsData(e){const{strings:t}=this.transformerProvider,n=this.getEndIndex(this.cardSize),a=e.data.slice(0,n).map(async n=>{var a,r,o,s;(n.imageUrl=n.imageId?(0,l.iK)(n.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced):null,!n.winnerDetails||null!==(a=n.winnerDetails)&&void 0!==a&&a.imageUrl)||(n.winnerDetails.imageUrl=null!==(o=n.winnerDetails)&&void 0!==o&&o.imageId?(0,l.iK)(null===(s=n.winnerDetails)||void 0===s?void 0:s.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced):null);n.gameCenterUrl&&(n.gameCenterUrl=(0,l.Ot)(n.gameCenterUrl)),n.gameScheduleString=n.gameStartDateTime?this.getScheduleString(n.gameStartDateTime,n.gameEndDateTime,null===(r=n.gameState)||void 0===r?void 0:r.state):null,n.strings=t;const d={parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,...n};return this.transformerProvider.generateView(d,i.hi.SportsTournamentStatusRow)});return(await Promise.all(a)).filter(l.z2)}getScheduleString(e,t,n){const a=(0,l.yn)(e),r=t?(0,l.yn)(t):null,o=a.toLocaleString(s.T3.CurrentMarket||"en-us",{month:"short"}),d=r?r.toLocaleString(s.T3.CurrentMarket||"en-us",{month:"short"}):null,u=`${o} ${a.getDate()}`;let m="";return r&&(r.getDate()===a.getDate()&&o===d||(m=o===d?` - ${r.getDate()}`:` - ${d} ${r.getDate()}`),n!==i.T0.PreGame.toString()&&"Pre-game"!==n||(m+=`, ${r.getUTCFullYear()}`)),`${u}${m}`}getEndIndex(e){switch(e){case a.uE._1x_1y:return 1;case a.uE._1x_2y:return 3;case a.uE._1x_3y:return 5;default:return 1}}}var m=n(91014);Promise.resolve().then(n.bind(n,26807)),Promise.resolve().then(n.bind(n,61469))},91014(e,t,n){n.d(t,{_(){return i}});var a=n(23587);class i extends a.Bc{async transform(e){return{viewModel:await this.getViewModel(e)}}async getViewModel(e){const t={...e.telemetryConstants,name:a.BP.SportsTournamentStatusRow};return{telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,t),...e}}}},92079(e,t,n){n.d(t,{a(){return o}});var a=n(56911),i=n(92011),r=n(31525);let o=class extends i.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};o=(0,a.Cg)([r.x],o)}}]);