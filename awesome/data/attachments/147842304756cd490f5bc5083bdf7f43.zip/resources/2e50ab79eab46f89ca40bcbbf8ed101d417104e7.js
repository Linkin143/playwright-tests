"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["stripe-wc"],{1540(t,e,i){i.d(e,{rX(){return x}});var r=i(94407),o=i(96950),s=i(82774);const a=o.qy`<span class="icon-container" part="icon-container" aria-hidden="true"><slot name="icon"></slot></span><span class="label-container" part="label-container"><span class="label" part="label"><slot ${(0,s.e)({property:"defaultItems",filter(t){var e;return t instanceof HTMLElement&&null!==t.offsetParent||t instanceof Text&&!(null===(e=t.textContent)||void 0===e||!e.trim().length)}})}></slot></span></span>`;var n=i(7896),l=i(61138),d=i(86856),c=i(57416),h=i(64187),p=i(22131),u=i(74849),g=i(12640),m=i(50882);const f=u.A` :host::after{transform:translateX(-100%) translateX(20px)}:host([animate]) .label{transform:translateX(-100%)}`,v=u.A` :host::after{transform:translateX(100%) translateX(-20px)}:host([animate]) .label{transform:translateX(100%)}`,y=u.A` :host{color:#000}:host::after{background:rgba(255,255,255,0.46)}`,C=u.A` :host{color:#fff}:host::after{background:rgba(0,0,0,0.54)}`,b=u.A`
        ${(0,h.V)("inline-flex")} :host{align-items:center;box-sizing:border-box;contain:content;overflow:hidden}.label-container{overflow:hidden}:host,:host::after{${""} border-radius:4px}:host::after{content:"";height:100%;position:absolute;width:100%;z-index:-1}.icon-container,.label{min-height:20px;min-width:20px;display:flex;align-items:center;justify-content:center;fill:currentcolor}:host([animate])::after,.label{transition:transform 250ms cubic-bezier(0.17,0.17,0,1)}.label{font-family:${n.O};
            font-size: ${l.k};
            font-weight: 600;
            line-height: ${l.F};text-overflow:ellipsis;padding:0 4px}:host([expanded][animate])::after,:host([expanded][animate]) .label{transform:translateX(0%)}.label{transform:translateX(-100%)}::slotted([slot="icon"]){display:block;fill:currentcolor}`.withBehaviors(new d.t(f,v),new g.N(y,C),(0,p.mr)(u.A` :host{forced-color-adjust:auto}::slotted([slot="icon"]){color:${m.A.ButtonText};fill:currentcolor}.icon-container,:host([expanded][animate]) .label,:host::after{background:${m.A.ButtonFace};
                    color: ${m.A.ButtonText};
                    fill: currentcolor;
                    border-radius: calc(${c.Pb} * 10px)}.label{background:transparent}`));var w=i(99900);const x=r.L.compose({name:`${w.i.prefix}-content-indicator`,template:a,styles:b})},2499(t,e,i){i.d(e,{u(){return s}});var r=i(89167),o=i(77367);class s extends r.X9{static buildAbsoluteUrl(t){let{market:e,pid:i,title:s,clickSource:a,trafsrc:n,ocid:l,formCode:d,isBing:c,isBWM:h,campaignCode:p,addEntrypoint:u=!0}=t;if(c){const t=new URLSearchParams;if(s){const e=s.split(" ");s=e.length>2?e.slice(0,-2).join(" "):e.join(" "),t.set("q",s??"")}i&&(u&&t.set("entrypoint","buydirect"),t.set("productpage","true"),t.set("browse","true"),t.set("filters",`scenario:"17" gType:"12" gId:"${i}" gGlobalOfferIds:"${i}"`)),e&&t.set("setmkt",e),n&&t.set("trafsrc",n),l&&t.set("ocid",l),d&&t.set("FORM",d),p&&t.set("CBC",p),t.set("msnrid",o.YT?o.YT.getRequestId():"Telemetry not initialized"),t.set("adunitId","378983"),t.set("propertyId","316966");const a=(0,r.wW)(t);return i?"https://www.bing.com/shop/productpage"+(a?"?"+a:""):"https://www.bing.com/shop/buywithmicrosoft"+(a?"?"+a:"")}{const t=new URLSearchParams;i&&t.set("pid",i),a&&t.set(r.Ts.ClickSourceQueryParam,a),s&&t.set("title",s),l&&t.set("ocid",l),n&&t.set("trafsrc",n),d&&t.set("FORM",d);const o=(0,r.wW)(t);return i?`${this.getSchemeAndDomain()}/${e}/shopping/buydirect/product${o?"?"+o:""}`:`${this.getSchemeAndDomain()}/${e}/shopping/buydirect/superdeals${o?"?"+o:""}`}}static addSearchParams(t,e){let{url:i,pid:o,title:s,clickSource:a,trafsrc:n,ocid:l,formCode:d}=t;if(!i)return i;const c=new URLSearchParams;s&&c.set("title",s),o&&c.set("pid",o),a&&c.set(r.Ts.ClickSourceQueryParam,a),l&&c.set("ocid",l),n&&c.set("trafsrc",n),d&&c.set("FORM",d);const[h,p]=i.split("?"),u=(0,r.$c)(new URLSearchParams(p),c),g=(0,r.wW)(u);if(e&&!o){const t=h.indexOf("/buydirect");if(-1!==t){return`https://www.bing.com/shop/buywithmicrosoft${h.slice(t+10)}${g?`?${g}`:""}`}}return h+(g?`?${g}`:"")}}},4332(t,e,i){i.d(e,{e3(){return s},fR(){return o}});var r=i(26220);function o(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,r.$t)();return/^python-requests|^CriteoBot|^ias-|GrapeshotCrawler/.test(t)}function s(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,r.$t)();if(!t)return!1;const e=(0,r.iA)(),i=e&&e.includes("reqsrc=vp");return-1!==t.indexOf("Yahoo")||-1!==t.indexOf("Yandex")||-1!==t.indexOf("Baiduspider")||-1!==t.indexOf("Bingbot")||-1!==t.indexOf("Googlebot")||-1!==t.indexOf("Google-InspectionTool")||-1!==t.indexOf("msnbot")||!i&&-1!==t.indexOf("HeadlessChrome")}},6011(t,e,i){i.d(e,{E(){return s}});var r=i(89167),o=i(29853);class s extends r.dN{static buildAbsoluteUrl(t,e,i,r){let s=!(arguments.length>4&&void 0!==arguments[4])||arguments[4],a=arguments.length>5?arguments[5]:void 0;i=(0,o.yA)(i);const n=new URL(this.bingBaseUrl);return this.updateBingShoppingQueryParameters(n,"msnembedded",e,s),n.searchParams.append("filters",this.getFiltersQueryParam(i,a)),n.searchParams.append("q",t),n.searchParams.append("productpage","true"),r&&n.searchParams.set("overlay","true"),n.href}static getFiltersQueryParam(t,e){var i;const r=new URLSearchParams((null===(i=window)||void 0===i||null===(i=i.location)||void 0===i?void 0:i.search)||"");let o=`pdprecocache:"true" scenario:"17" gType:"12" gId:"${t}" gGlobalOfferIds:"${t}"`;return e&&(o+=' brqenabled:"true"'),t?o:r.get("filters")||""}}s.bingBaseUrl="https://www.bing.com/shop/productpage"},6637(t,e,i){i.d(e,{$(){return a}});var r=i(14475),o=i(96950),s=i(58792);const a=t=>o.qy`<a class="ad-choice" data-t=${t.telemetryTag||""} href=${t.href||""} target="${r.z._blank}" title=${t.text||""}><img alt=${t.text||""} aria-hidden="true" src="${(0,s.rA)().StaticsUrl}/latest/responsive-card/adChoiceIcon.svg"></img></a>`},7642(t,e,i){i.d(e,{T(){return p}});var r=i(93475),o=i(41124),s=i(1840),a=i(22162),n=i(96950),l=i(69259),d=i(58792),c=i(76696);const h=n.qy`      
    <msft-attribution slot="attribution">
    ${(0,l.z)(t=>t.providerData.logoImage,n.qy`
        <img 
            slot="image" 
            src="${t=>t.providerData.logoImage}" 
            alt="${t=>t.providerData.name}" 
            @load=${t=>{t.imageData&&t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback(1,a.j.provider)}} />
    `)}
    <div class="attribution_container_${t=>t.id}" id="attribution_container">
        <div class="attribution_Content_${t=>t.id}" style="${t=>"rtl"===t.dir?"right":"left"}:0px;">
            ${(0,l.z)(t=>t.providerData&&t.providerData.name,n.qy`<span style="unicode-bidi: embed;">${t=>t.providerData.name}</span>`)}
            ${(0,l.z)(t=>t.providerData&&t.providerData.name&&t.publishedDateTime,n.qy` · `)}
            ${(0,l.z)(t=>t.publishedDateTime,n.qy`<span style="unicode-bidi: embed;">${t=>t.publishedDateTime}</span>`)}
            ${(0,l.z)(t=>t.isWebContent&&t.crawledContentLabel,n.qy` · `)}
            ${(0,l.z)(t=>t.isWebContent&&t.crawledContentLabel,n.qy`${t=>t.crawledContentLabel}`)}
        </div>
    </div>
    </msft-attribution>

`,p=n.qy`
    <style>
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-content-card.msft-content-card-preview {
            height: 100px;
        }
        msft-content-card.msft-content-card-preview::part(body) {
            height: 100%;
        }
        msft-content-card.msft-content-card-preview .card-button:not(:hover) {
            background: transparent;
        }
        msft-content-card.msft-content-card-preview fluent-button::part(control) {
            padding: 0;
        }
        msft-content-card.msft-content-card-preview::part(footer) {
            padding: 0 16px 4px;
            margin-bottom: 0;
            height: 40px;
        }
        msft-content-card.msft-content-card-preview msft-attribution {
            position: relative;
            overflow: hidden;
            margin-top: 0;
            margin-bottom: 0;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper.attribution-rtl msft-attribution {
            margin-right: 5px;
        }
        msft-content-card.msft-content-card-preview::part(heading-container) {
            padding: 8px;
            display: flex;
            flex-flow: column-reverse;
            height: 100%;
            box-sizing: border-box;
            justify-content: space-between;
        }
        msft-content-card.msft-content-card-preview::part(heading-container) {
            height: 100%;
        }

        ${t=>"end"===t.imagePosition?'\n            msft-content-card.msft-content-card-preview::part(media-wrapper) {\n                float: right;\n                margin-top: unset;\n                margin: 8px 8px 8px 0px;\n            }\n            :host([direction="rtl"]) msft-content-card.msft-content-card-preview::part(media-wrapper) {\n                float: left;\n                margin: 8px 0px 8px 8px;\n            }\n            ':'        \n            msft-content-card.msft-content-card-preview::part(media-wrapper) {\n                float: left;\n                margin-top: unset;\n                margin: 8px 0 8px 8px;\n            }\n            :host([direction="rtl"]) msft-content-card.msft-content-card-preview::part(media-wrapper) {\n                float: right;\n                margin: 8px 8px 8px 0;\n            }\n            '}
        msft-content-card.msft-content-card-preview::part(media),
        msft-content-card.msft-content-card-preview::part(media) img {
            border-radius: unset;
        }
        msft-content-card.msft-content-card-preview::part(heading) {
            font-size: 14px;
            line-height: 20px;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper {
            display: flex;
            gap: 8px;
        }

        msft-content-card.msft-content-card-preview .attribution-wrapper .social-bar-wrapper {
            position: relative;
            z-index: 99999;
        }
        msft-content-card.msft-content-card-preview .attribution-wrapper.attribution-rtl .social-bar-wrapper::before {
            left: unset;
            right: 0px;
            transform: translateX(100%);
        }
        msft-content-card.msft-content-card-preview .title-attribution-wrapper {
            height: 100%;
            position: absolute;
            top: 0;
            right: 0;
            width: calc(100% - 120px);
            padding: 8px 0;
            box-sizing: border-box;
            display: flex;
            flex-flow: column;
            justify-content: space-between;
            z-index: 2;
        }
        msft-content-card.msft-content-card-preview .title-attribution-wrapper.image-end {
            right: unset;
            left: 0;
            padding-left: 8px;
        }

        msft-content-card.msft-content-card-preview .title-attribution-wrapper.no-image {
            width: 100%; 
            padding-left: 8px;
        }

        msft-content-card.msft-content-card-preview .title-container {
            padding-right: 8px;
            height: 60px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            text-decoration: none;
            color: var(--neutral-foreground-rest);
        }
        msft-content-card.msft-content-card-preview .image-end .title-container {
            padding-right: 0;
        }
            
        msft-content-card.msft-content-card-preview .provider-top .title-container {
            height:40px;
            -webkit-line-clamp: 2;
            padding-top: 4px;
        }  

        msft-content-card.msft-content-card-preview .title-container:hover {
            text-decoration: underline;
        }
        msft-content-card.msft-content-card-preview .title-container:focus {
            outline: none;
            text-decoration: underline;
        }
        /* 
         *  Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution, msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_container_${t=>t.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_Content_${t=>t.id} {
            position: absolute;
            transition: all 0.5s ease-out;
            text-decoration: none;
            color: var(--neutral-foreground-rest);
        }

    /**
    *  To support high contrast mode for accessibility
    **/
    @media (forced-colors: active) {
        msft-content-card.msft-content-card-preview .title-container {
            color: linktext;
        }
    }
    </style>
    <fluent-card
        style="grid-area:${t=>t.gridArea}"
        class="${t=>t.cardSize} msft-content-card-preview-wrapper"
    >
        <msft-content-card
            exportparts="heading"
            id="contentcard_${t=>t.id}"
            href=${t=>t.destinationUrl}
            target=${t=>t.openLinksInNewTab?"_blank":"_self"}
            title=${t=>t.disableCardTitleTooltip?"":t.title}
            style="--heading-max-lines: 2;"
            class="msft-content-card-preview"
            data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.contentCard)||void 0===e?void 0:e.getMetadataTag()}}"
            :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}
            @mouseenter="${(t,e)=>t.setDisplacementHandler&&t.setDisplacementHandler(e,t.dir)}"
            @mouseleave="${(t,e)=>t.removeDisplacementHandler&&t.removeDisplacementHandler(e,t.dir)}"
        >
            ${(0,l.z)(t=>t.imageData,n.qy`
                <img
                    slot="media"
                    src="${t=>t.imageData.source}"
                    alt="${t=>t.imageData.altText}"
                    height="${s.L._104x84.height}"
                    width="${s.L._104x84.width}"
                    @load="${t=>{t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback(3,a.j.image)}}"
                />
            `)}
            ${t=>{!t.imageData&&t.visualReadinessCallback&&t.visualReadinessCallback()}}
            <div class="title-attribution-wrapper ${t=>{var e;return null!==(e=t.imageData)&&void 0!==e&&e.source?"":"no-image"}} ${t=>"end"===t.imagePosition?"image-end":""} ${t=>t.providerAboveHeader?"provider-top":""}">
                ${(0,l.z)(t=>t.providerData&&t.providerAboveHeader,h)}
                <div class="title-wrapper">
                    <div class="title-container" tabindex="0" role="link" @keypress="${(t,e)=>"Enter"==e.event.key&&e.event.target.click()}">${n.qy`${t=>t.title}`}</div>
                    ${(0,l.z)(t=>t.abstract,n.qy`
                        <p slot="abstract" style="color: var(--neutral-foreground-rest);">${t=>t.abstract}</p>
                    `)}
                </div>
                <div class="attribution-wrapper ${t=>"rtl"===t.dir?"attribution-rtl":""}">
                    ${(0,l.z)(t=>t.providerData&&!t.providerAboveHeader,h)}
                    ${(0,l.z)(t=>t.enableRichSocialReaction,t=>n.qy`
 <div class="social-bar-wrapper" style="display: flex; gap: 4px; margin-right: 5px;">
     ${(0,l.z)(t=>t.optedOutOfReactions,n.qy`
         ${o.LW}
         ${o.tB}
     `)}
     <social-bar-wc
         config-instance-src=${t=>t.socialBarWCConfigInfo&&(0,c.v)(t.socialBarWCConfigInfo)}
         instance-id=${t=>t.socialBarWCConfigInfo&&t.socialBarWCConfigInfo.instanceId}
         config-shared-ns=${t=>{var e;return null===(e=t.socialBarWCConfigInfo)||void 0===e||null===(e=e.configRef)||void 0===e?void 0:e.sharedNs}}
         :contentId=${t=>t.id}
         :destinationUrl=${t=>t.destinationUrl}
         :locale=${t=>d.T3.CurrentMarket||t.locale}
         :rootTelemetryObject=${t=>t.telemetryContext&&(t.telemetryContext.contentCardTelemetryObject||t.telemetryContext.contentCard)}
         :hideComments=${()=>!0}
         :isRightPos=${t=>t.socialBarInRight}
         :socialMetadata=${t=>({...t.metadata,imageData:t.imageData,providerData:t.providerData,title:t.title})}
        theme="superappListCard"
    ></social-bar-wc>
 </div>
 `)}
                </div>
            </div>
            ${(0,l.z)(t=>t.enableHoverCardAction&&!t.optedOutOfReactions,r.p)}
        </msft-content-card>
    </fluent-card>
`},8675(t,e,i){i.d(e,{E(){return n}});var r=i(4126),o=i(74849),s=i(30664);const a=o.A`
.ad-label{font-size:12px;border:unset;padding:unset}`,n=o.A`
.ad-label{align-items:center;border-radius:4px;border:0.5px solid var(--color-neutral-stroke-1,var(--neutral-foreground-rest));color:inherit;display:flex;font-size:11px;padding:0 4px 1px 4px;text-decoration:none;z-index:${s.I}}a[no-border]{border:unset;padding:unset;display:inline-flex}.dsa:hover{text-decoration:underline}`.withBehaviors(new r.o("ruby",!0,a))},10699(t,e,i){i.d(e,{Ob(){return w}});var r=i(70635),o=i(96950),s=i(82774),a=i(69259);const n=o.qy`<template><slot ${(0,s.e)({property:"items",filter(t){return t instanceof HTMLElement&&null!==t.offsetParent}})}></slot>${(0,a.z)(t=>t.layout===r.Y.list,o.qy` <span class="topic">${t=>t.topic}</span> `)} ${t=>t.dividerTemplate}</template>`;var l=i(7896),d=i(41123),c=i(48751),h=i(95239),p=i(89580),u=i(86856),g=i(74849),m=i(64187),f=i(22131);const v=g.A` :host([layout="double"]) .divider-1{left:0}:host([layout="triple"]) .divider-1{left:0}:host([layout="triple"]) .divider-2{left:0}:host([layout="mosaic"]) .divider-1{left:0}:host([layout="mosaic"]) .divider-2{left:1px}`,y=g.A` :host([layout="double"]) .divider-1{right:0}:host([layout="triple"]) .divider-1{right:0}:host([layout="triple"]) .divider-2{right:0}:host([layout="mosaic"]) .divider-1{right:0}:host([layout="mosaic"]) .divider-2{right:1px}`,C=g.A`
        ${(0,m.V)("grid")} :host{box-sizing:border-box;font-family:${l.O};
            font-size: ${d.K};
            line-height: ${d.Z};
            color: ${c.l};height:100%;width:100%;position:relative}:host([layout="single"]){grid-template-columns:1fr}:host([layout="double"]){grid-template-columns:1fr 1fr}:host([layout="split"]){grid-template-rows:1fr 1fr}:host([layout="triple"]){grid-template-columns:1fr 1fr 1fr}:host([layout="mosaic"]){grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr}:host([layout="mosaic"]) ::slotted(:first-child){grid-row:1 / span 2;grid-column:1}:host([layout="mosaic"]) ::slotted(msft-content-card:not(:first-child)){--mask-gradient:linear-gradient(rgba(0,0,0,0),${h.p})}:host([layout="list"]){grid-template-rows:auto 1fr 1fr 1fr;grid-template-columns:3fr 2fr}:host([layout="list"]) ::slotted(:first-child){grid-row:1 / span 4;grid-column:1}:host([layout="list"]) ::slotted(msft-content-card:not(:first-child)){background:${h.p};
            --heading-font-size: ${d.K};
            --heading-line-height: ${d.Z}}.topic{grid-row:1;grid-column:2;font-size:${p.Y};
            line-height: ${p.v};
            background: ${h.p};padding:6px 12px}.divider{background:rgba(255,255,255,0.4);position:absolute;left:20px;right:20px;top:20px;bottom:20px;z-index:1;pointer-events:none;opacity:0}:host([layout="double"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="split"]) .divider-1{grid-row:2;height:1px;top:0;opacity:1}:host([layout="triple"]) .divider-1{grid-column:2;width:1px;opacity:1}:host([layout="triple"]) .divider-2{grid-column:3;width:1px;opacity:1}:host([layout="mosaic"]) .divider-1{grid-column:2;grid-row:1 / span 2;width:1px;opacity:1}:host([layout="mosaic"]) .divider-2{grid-column:2;grid-row:2;height:1px;top:0;opacity:1}`.withBehaviors(new u.t(v,y),(0,f.mr)(g.A` .divider{background:none}`));var b=i(99900);const w=r.s.compose({name:`${b.i.prefix}-info-pane-slide`,template:n,styles:C})},10809(t,e,i){i.d(e,{D(){return n}});var r=i(18272),o=i(2171),s=i(6791);class a extends s.f{constructor(){super(...arguments),this.configRef={experienceType:"SuperComponentData",instanceSrc:"default"}}static getInstance(){return o.vv.get("__SuperComponentDataHelper__",()=>new a)}}const n=(0,r.G)(a)},12097(t,e,i){i.d(e,{g(){return v}});var r=i(92687),o=i(87993),s=i(32368),a=i(1050),n=i(8969),l=i(93475),d=i(41124),c=i(91884),h=i(33477),p=i(96950),u=i(69259),g=i(17857),m=i(27160),f=i(5819);r.m,o.m;const v=p.qy`
    <style>
        :host fluent-card {
            content-visibility: auto;
        }
        ${(0,u.z)(t=>t.contentType===m.pL.Video,p.qy`
            msft-content-card msft-content-indicator {
                color: transparent;
            }
            msft-content-card msft-content-indicator::after{
                background: transparent;
            }

            fluent-card._1x_1y msft-content-card msft-content-indicator{
                left: 130px;
                top: 88px;
            }
        `)}
        .card-see-more {
            box-sizing: border-box;
            align-items: center;
            background-color: rgb(255, 255, 255);
            border-radius: 100%;
            border: 1px solid rgb(229, 229, 229);
            cursor: pointer;
            display: flex;
            fill: currentcolor;
            font-family: var(--body-font);
            font-size: var(--type-ramp-base-font-size);
            height: 28px;
            justify-content: center;
            line-height: var(--type-ramp-base-line-height);
            margin-inline-start: 4px;
            min-width: 28px;
            outline: none;
            padding: 0px;
            position: relative;
        }
        .card-see-more: hover {
            background-color: rgb(242, 242, 242);
        }
        msft-content-card span.infopane-title {
            font-size: var(--infopane-title-font-size, 28px);
        }
        msft-content-card.narrowTitleGap::part(body) {
            row-gap: 7px;
        }
        msft-content-card.narrowTitleGap::part(footer) {
            padding: 0 16px 18px;
            margin-bottom: 0;
            height: 14px;
        }
        ${t=>C(t)}

        /* 
         * Here about 'from the web' attribution style
         */
        msft-content-card[id="contentcard_${t=>t.id}"]::part(start-actions) {
            flex:1;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(image){
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution, msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution::part(content){
            width: calc(100%);
        }
        msft-content-card[id="contentcard_${t=>t.id}"] msft-attribution {
            display: flex;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_container_${t=>t.id} {
            width: calc(100%);
            min-height: var(--type-ramp-minus-1-line-height);
            position: relative;
            overflow: hidden;
            white-space: nowrap;
        }
        msft-content-card[id="contentcard_${t=>t.id}"] .attribution_Content_${t=>t.id} {
            position:absolute;
            transition: all 0.5s ease-out;
        }
    </style>
    <fluent-card
        style="grid-area:${t=>t.gridArea};"
        class="${t=>t.cardSize}"
    >
        <fluent-design-system-provider
            fill-color="#333333"
            style="display: flex; padding: 0; height: 100%;"
        >
            <msft-content-card
                id="contentcard_${t=>t.id}"
                class="${t=>(0,f.dU)(t)}"
                href=${t=>t.destinationUrl}
                target=${t=>t.openLinksInNewTab?"_blank":"_self"}
                title=${t=>t.disableCardTitleTooltip?"":t.title}
                layout="infoPane"
                style="${t=>y(t)}"
                data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.contentCard)||void 0===e?void 0:e.getMetadataTag()}}"
                :anchorTelemetryTag=${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}
                @mouseenter="${(t,e)=>t.setDisplacementHandler&&t.setDisplacementHandler(e,t.dir)}"
                @mouseleave="${(t,e)=>t.removeDisplacementHandler&&t.removeDisplacementHandler(e,t.dir)}"
            >
            ${(0,u.z)(t=>t.contentIndicator,t=>(0,c.Z)(t.contentIndicator))}
            ${(0,u.z)(t=>!t.isAnaheimDesign,p.qy`${t=>t.title}`)}
            ${(0,u.z)(t=>t.isAnaheimDesign,p.qy`<span class="infopane-title">${t=>t.title}</span>`)}
                <img
                    slot="background-image"
                    alt="${t=>t.imageData&&t.imageData.altText}"
                    src="${t=>t.imageData&&t.imageData.source}"
                    @load="${t=>t.imageData&&t.imageData.visualReadinessCallback&&t.imageData.visualReadinessCallback()}"
                />
                ${t=>(0,s.fn)(t.isProviderInFooter?"start-actions":"attribution")}
                ${(0,u.z)(t=>t.cardActionStatus&g.J.enabled,a.K)}
                ${(0,u.z)(t=>!t.isAnaheimDesign,p.qy`
                    <div slot="start-actions" style="gap:0">
                        ${(0,u.z)(t=>t.cardActionStatus&g.J.enabled&&!t.enableRichSocialReaction,p.qy`
                            ${d.LW}
                            ${d.tB}
                        `)}
                    </div>
                `)}
                <div slot="${t=>t.isProviderInFooter?"end-actions":"start-actions"}" style="gap:0">
                    <style>
                        .card-button:not(:hover) {
                            background: transparent;
                        }
                        msft-content-card fluent-button::part(control) {
                            padding: 0;
                        }
                    </style>
                    ${(0,u.z)(t=>t.enableRichSocialReaction,(0,d.nj)({}))}
                    ${(0,u.z)(t=>t.cardActionStatus&g.J.enabled,p.qy`
                        ${(0,u.z)(t=>t.enableRichSocialReaction&&t.enableWCSaveButton,p.qy`
                            ${(0,u.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&g.J.showMore,d.LW)}
                            ${(0,u.z)(t=>!t.optedOutOfReactions&&t.cardActionStatus&g.J.showFewer,d.tB)}
                        `)}
                        ${(0,u.z)(t=>t.enableWCCardAction,n.L)}
                    `)}
                </div>
                ${(0,u.z)(t=>t.enableHoverCardAction&&!t.optedOutOfReactions,l.p)}
            </msft-content-card>
        </fluent-design-system-provider>
    </fluent-card>
`,y=t=>{let e="width: 100%;";return t.cardSize!==h.uE._2x_2y&&t.cardSize!==h.uE._2x_3y||(e+=" --heading-font-size: 20px; --heading-line-height: 28px;"),t.cardSize!==h.uE._1x_1y&&t.cardSize!==h.uE._1x_2y||!t.useInfopaneSlideTemplate||(e+=" --infopane-title-font-size: 20px;"),e},C=t=>{let e="";return t.cardSize!==h.uE._1x_1y&&t.cardSize!==h.uE._1x_2y||!t.useInfopaneSlideTemplate||(e+='\n            msft-content-card[layout="infoPane"]::part(footer) {\n                padding: 0 16px 4px;\n                margin-bottom: 0;\n                height: 40px;\n            }\n        '),e}},13025(t,e,i){i.d(e,{A(){return F}});var r=i(6574),o=function(t){return function(e){return null==t?void 0:t[e]}}({À:"A",Á:"A",Â:"A",Ã:"A",Ä:"A",Å:"A",à:"a",á:"a",â:"a",ã:"a",ä:"a",å:"a",Ç:"C",ç:"c",Ð:"D",ð:"d",È:"E",É:"E",Ê:"E",Ë:"E",è:"e",é:"e",ê:"e",ë:"e",Ì:"I",Í:"I",Î:"I",Ï:"I",ì:"i",í:"i",î:"i",ï:"i",Ñ:"N",ñ:"n",Ò:"O",Ó:"O",Ô:"O",Õ:"O",Ö:"O",Ø:"O",ò:"o",ó:"o",ô:"o",õ:"o",ö:"o",ø:"o",Ù:"U",Ú:"U",Û:"U",Ü:"U",ù:"u",ú:"u",û:"u",ü:"u",Ý:"Y",ý:"y",ÿ:"y",Æ:"Ae",æ:"ae",Þ:"Th",þ:"th",ß:"ss",Ā:"A",Ă:"A",Ą:"A",ā:"a",ă:"a",ą:"a",Ć:"C",Ĉ:"C",Ċ:"C",Č:"C",ć:"c",ĉ:"c",ċ:"c",č:"c",Ď:"D",Đ:"D",ď:"d",đ:"d",Ē:"E",Ĕ:"E",Ė:"E",Ę:"E",Ě:"E",ē:"e",ĕ:"e",ė:"e",ę:"e",ě:"e",Ĝ:"G",Ğ:"G",Ġ:"G",Ģ:"G",ĝ:"g",ğ:"g",ġ:"g",ģ:"g",Ĥ:"H",Ħ:"H",ĥ:"h",ħ:"h",Ĩ:"I",Ī:"I",Ĭ:"I",Į:"I",İ:"I",ĩ:"i",ī:"i",ĭ:"i",į:"i",ı:"i",Ĵ:"J",ĵ:"j",Ķ:"K",ķ:"k",ĸ:"k",Ĺ:"L",Ļ:"L",Ľ:"L",Ŀ:"L",Ł:"L",ĺ:"l",ļ:"l",ľ:"l",ŀ:"l",ł:"l",Ń:"N",Ņ:"N",Ň:"N",Ŋ:"N",ń:"n",ņ:"n",ň:"n",ŋ:"n",Ō:"O",Ŏ:"O",Ő:"O",ō:"o",ŏ:"o",ő:"o",Ŕ:"R",Ŗ:"R",Ř:"R",ŕ:"r",ŗ:"r",ř:"r",Ś:"S",Ŝ:"S",Ş:"S",Š:"S",ś:"s",ŝ:"s",ş:"s",š:"s",Ţ:"T",Ť:"T",Ŧ:"T",ţ:"t",ť:"t",ŧ:"t",Ũ:"U",Ū:"U",Ŭ:"U",Ů:"U",Ű:"U",Ų:"U",ũ:"u",ū:"u",ŭ:"u",ů:"u",ű:"u",ų:"u",Ŵ:"W",ŵ:"w",Ŷ:"Y",ŷ:"y",Ÿ:"Y",Ź:"Z",Ż:"Z",Ž:"Z",ź:"z",ż:"z",ž:"z",Ĳ:"IJ",ĳ:"ij",Œ:"Oe",œ:"oe",ŉ:"'n",ſ:"s"}),s=i(57842),a=/[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,n=RegExp("[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]","g"),l=function(t){return(t=(0,s.A)(t))&&t.replace(a,o).replace(n,"")},d=/[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,c=function(t){return t.match(d)||[]},h=/[a-z][A-Z]|[A-Z]{2}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,p=function(t){return h.test(t)},u="\\ud800-\\udfff",g="\\u2700-\\u27bf",m="a-z\\xdf-\\xf6\\xf8-\\xff",f="A-Z\\xc0-\\xd6\\xd8-\\xde",v="\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",y="["+v+"]",C="\\d+",b="["+g+"]",w="["+m+"]",x="[^"+u+v+C+g+m+f+"]",$="(?:\\ud83c[\\udde6-\\uddff]){2}",k="[\\ud800-\\udbff][\\udc00-\\udfff]",P="["+f+"]",S="(?:"+w+"|"+x+")",_="(?:"+P+"|"+x+")",A="(?:['’](?:d|ll|m|re|s|t|ve))?",D="(?:['’](?:D|LL|M|RE|S|T|VE))?",R="(?:[\\u0300-\\u036f\\ufe20-\\ufe2f\\u20d0-\\u20ff]|\\ud83c[\\udffb-\\udfff])?",T="[\\ufe0e\\ufe0f]?",I=T+R+("(?:\\u200d(?:"+["[^"+u+"]",$,k].join("|")+")"+T+R+")*"),M="(?:"+[b,$,k].join("|")+")"+I,O=RegExp([P+"?"+w+"+"+A+"(?="+[y,P,"$"].join("|")+")",_+"+"+D+"(?="+[y,P+S,"$"].join("|")+")",P+"?"+S+"+"+A,P+"+"+D,"\\d*(?:1ST|2ND|3RD|(?![123])\\dTH)(?=\\b|[a-z_])","\\d*(?:1st|2nd|3rd|(?![123])\\dth)(?=\\b|[A-Z_])",C,M].join("|"),"g"),z=function(t){return t.match(O)||[]},B=function(t,e,i){return t=(0,s.A)(t),void 0===(e=i?void 0:e)?p(t)?z(t):c(t):t.match(e)||[]},U=RegExp("['’]","g"),F=function(t){return function(e){return(0,r.A)(B(l(e).replace(U,"")),t,"")}}},13790(t,e,i){i.d(e,{g8(){return a},gq(){return l},wg(){return o}});var r=i(46528);function o(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"";const i=new URLSearchParams(window.location.search).get(t);return i&&""!==i?String(i):e}i(1577);const s=(new r.bb).data;function a(t,e,i){if(t&&t.length>0){let o=(0,r.KP)(s.devicePixelRatio,"devicePixelRatio");o=o&&o>0?o:1;const a=i*o;let n=1;if(a<100?n=1.5:a<350&&(n=1.2),t.startsWith("https://www.bing.com/th?id=")||t.startsWith("https://bing.com/th?id=")||t.startsWith("https://th.bing.com/th?id=")){const r=new URLSearchParams(t.substring(t.indexOf("?")+1)).get("id");t=`${t=t.substring(0,t.indexOf("?"))}?id=${r}&${e}=${Math.floor(i*o*n)}&p=0`}else if(t.startsWith("https://img-s-msn-com.akamaized.net/tenant/amp/entityid/")){t.includes("?")&&(t=t.substring(0,t.indexOf("?")));const r=Math.floor(i*o*n);t=`${t}?${e}=${Math.floor(r)}`}}return t}const n="ABT748875623C1C490A64E339BEF5741D0A4D98E2E4B21323BED0D12971212C1C24";function l(t,e,i,r){return t&&""!==t||(t=n),t.startsWith("https://www.bing.com/th?id=")||t.startsWith("https://bing.com/th?id=")||t.startsWith("https://th.bing.com/th?id=")?`${t}${e?"&w="+e:""}${i?"&h="+i:""}${r}`:`https://www.bing.com/th?id=${t}${e?"&w="+e:""}${i?"&h="+i:""}${r||""}`}},13959(t,e,i){i.d(e,{Id(){return b}});var r=i(56911),o=i(92011),s=i(38493);class a extends o.L{constructor(){super(...arguments),this.appearance="primary"}}(0,r.Cg)([s.CF],a.prototype,"appearance",void 0),(0,r.Cg)([(0,s.CF)({attribute:"fill"})],a.prototype,"fill",void 0),(0,r.Cg)([(0,s.CF)({attribute:"color"})],a.prototype,"color",void 0),(0,r.Cg)([s.CF],a.prototype,"download",void 0),(0,r.Cg)([s.CF],a.prototype,"href",void 0),(0,r.Cg)([s.CF],a.prototype,"hreflang",void 0),(0,r.Cg)([s.CF],a.prototype,"ping",void 0),(0,r.Cg)([s.CF],a.prototype,"referrerpolicy",void 0),(0,r.Cg)([s.CF],a.prototype,"rel",void 0),(0,r.Cg)([s.CF],a.prototype,"target",void 0),(0,r.Cg)([s.CF],a.prototype,"type",void 0);const n=i(96950).qy`<a class="control" part="control" download="${t=>t.download}" href="${t=>t.href}" hreflang="${t=>t.hreflang}" ping="${t=>t.ping}" referrerpolicy="${t=>t.referrerpolicy}" rel="${t=>t.rel}" target="${t=>t.target}" type="${t=>t.type}" style="${t=>t.fill&&t.color?`background-color: var(--ad-label-fill-${t.fill}); color: var(--ad-label-color-${t.color})`:void 0}"><slot></slot></a>`;var l=i(74849),d=i(64187),c=i(73477),h=i(22131),p=i(7896),u=i(62047),g=i(57416),m=i(26920),f=i(48751),v=i(14996);const y=l.A`
    ${(0,d.V)("inline-block")} :host{box-sizing:border-box;font-family:${p.O};
        font-size: ${u.t};
        font-weight: 400;
        ${""} z-index:4}.control{text-align:center;border-radius:calc(${g.Pb} * 1px);
        padding: 0 6px;
        min-width: 24px;
        text-decoration: none;
        height: 16px;
        border: calc(${m.XA} * 1px) solid ${f.l};
        color: ${f.l};
    }

    .control:${c.N}{outline:none;border:calc(${m.XA} * 1px) solid ${v.WN};
    }
`.withBehaviors((0,h.mr)(l.A` :host{forced-color-adjust:auto}`));var C=i(99900);const b=a.compose({name:`${C.i.prefix}-ad-label`,template:n,styles:y,shadowOptions:{delegatesFocus:!0}})},14097(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M7.73 4.2a.75.75 0 0 1 1.06.03l5 5.25c.28.3.28.75 0 1.04l-5 5.25a.75.75 0 1 1-1.08-1.04L12.2 10l-4.5-4.73a.75.75 0 0 1 .02-1.06Z" fill="currentcolor"/></svg>'},14701(t,e,i){i.d(e,{B(){return n}});var r=i(74849),o=i(30664),s=i(12640);const a=r.A`
.ad-choice{filter:var(--filter-color)}`,n=r.A`
:host{--filter-color:invert(99%) sepia(10%) saturate(0%) hue-rotate(244deg) brightness(120%) contrast(100%)}.ad-choice{align-items:center;display:flex;width:12px;z-index:${o.I}}@media (forced-colors:active){.ad-choice{filter:invert(1) !important}}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice{filter:var(--filter-color) !important}}`.withBehaviors(new s.N(null,a))},16038(t,e,i){i.d(e,{m(){return u}});var r=i(65614),o=i(13312),s=i(55153),a=i(7896),n=i(74849),l=i(64187);const d=n.A`
    ${(0,l.V)("grid")}

    :host {
        font-family: ${a.O};
        width: auto;
        grid-auto-columns: calc(${s.QG} * 1px);
        grid-auto-row: calc(${s.l8} * 1px);
        grid-gap: calc(${s.Sn} * 1px);
    }
`;var c=i(39957),h=i(96950);const p=h.qy`
    <template @keydown="${(t,e)=>t.handleKeyDown(e.event)}">
        ${(0,c.ux)(t=>t.childrenLayout,h.qy`
                ${(t,e)=>e.parent.selectTemplate(t)}
            `)}
    </template>
`,u=o.tA.compose({name:`${r.G.prefix}-feed-layout`,styles:d,template:p})},16841(t,e,i){i.d(e,{E(){return l}});var r=i(73526),o=i(35639),s=i(74998),a=i(1577);function n(t){var e;const{configOptions:i={},cardMetadata:r}=t,n=function(t){var e,i;return!(null!==(e=(0,s.Th)().CurrentFlightSet)&&void 0!==e&&e.has("prg-hp-fvrf"))&&t.isWaterfallFeed&&"hp"===(null===(i=(0,s.Th)().ClientSettings)||void 0===i?void 0:i.pagetype)}(i),l=r.instanceId||(n?"rectangle1":void 0),d=n?"waterfall":"default",c=(0,a.$q)(window.location.href);let h="hp2";(0,a._f)(c)?h="hp2lock":(0,a.AO)(c)&&(h="winweb");const p={id:"DisplayAdBanner"===r.type?"displayAdBanner":"displayAdCard",type:r.type,enableSafeAds:!!i.enableSafeAds,childTemplateType:"display-ad-card",configInstanceSrc:r.configInstanceSrc||d,instanceId:l,pageTypeOverride:n?h:void 0,shimmerIdOverride:n?"rectangle1":void 0,batchCallAdCountOverride:i.displayAdBatchCountOverride,enableExtraAdSlug:!("rectangle1"!==l||!n)||void 0};return(0,o.bw)({id:"DisplayAdBanner"===r.type?"displayAdBanner":"displayAdCard",experienceType:null==i||null===(e=i.configRef)||void 0===e?void 0:e.experienceType,mapperArgs:t},p)}const l={getFeedDataForCard(t){return n(t)},viewTemplate:r.s}},18573(t,e,i){i.d(e,{A(){return n}});var r=i(34054),o=i(16670),s=i(18267),a=i(57842),n=function(t){return function(e){e=(0,a.A)(e);var i=(0,o.A)(e)?(0,s.A)(e):void 0,n=i?i[0]:e.charAt(0),l=i?(0,r.A)(i,1).join(""):e.slice(1);return n[t]()+l}}("toUpperCase")},19256(t,e,i){i.d(e,{Lm(){return o},Yd(){return s}});var r=i(75307);function o(){let t=arguments.length>0&&void 0!==arguments[0]&&arguments[0];return function(){const t=new Date,e=t.getUTCDay(),i=t.getUTCHours();return!(1==e&&i>=18||5==e&&i<22||e>=2&&e<=4)||(0,r.kg)()}()||t?30:20}function s(t){return t.toString()+"%"}},22272(t,e,i){i.d(e,{T(){return $}});var r=i(56911),o=i(92011),s=i(38493);const a="next",n="medium";class l extends o.L{constructor(){super(...arguments),this.direction=a,this.disabled=!1,this.size=n,this.ariaLabel=null}handleActivate(t){if(this.disabled)return!0;if(t instanceof KeyboardEvent){if("Enter"!==t.key&&" "!==t.key)return!0;t.preventDefault()}return t.stopPropagation(),this.click(),!1}}(0,r.Cg)([s.CF],l.prototype,"caretIcon",void 0),(0,r.Cg)([s.CF],l.prototype,"direction",void 0),(0,r.Cg)([(0,s.CF)({mode:"boolean"})],l.prototype,"disabled",void 0),(0,r.Cg)([s.CF],l.prototype,"size",void 0),(0,r.Cg)([(0,s.CF)({attribute:"aria-label"})],l.prototype,"ariaLabel",void 0);var d=i(28986),c=i(57416),h=i(48751),p=i(79288),u=i(48196),g=i(74838),m=i(74849),f=i(12640);const v=m.A` .flipper-caret{filter:invert(var(--flipperInvert,100%))}:host([invert-color="true"]) .flipper-caret{filter:invert(var(--flipperInvert,22%))}`,y=m.A` :host{align-items:center;background:${d.v8};
        border-radius: calc(${c.Pb} * 1px);
        color: ${h.l};display:grid;fill:currentcolor;justify-content:center;outline:none}:host([invert-color="true"]){background:var(--neutral-foreground-rest)}:host([direction="next"]) .flipper-caret{transform:rotate(180deg)}:host([disabled]){cursor:none;opacity:${p.q};pointer-events:none}:host([size="medium"]){height:calc(${u.D} * 1px);
        width: calc(${g.vR} * 4px)}:host([size="large"]){height:calc(${g.vR} * 12px);
        width: calc(${g.vR} * 6px)}:host([size="tall"]){height:calc(${g.vR} * 18px);
        width: calc(${g.vR} * 5.5px);
        border-radius: calc(${c.Pb} * 2px)}:host([size="square"]){height:calc(${g.vR} * 6px);
        width: calc(${g.vR} * 6px)}:host([size="extra-large"]){height:calc(${g.vR} * 12px);
        width: calc(${g.vR} * 6.5px)}:host([size="extra-large-2"]){height:calc(${g.vR} * 12px);
        width: calc(${g.vR} * 7px)}:host([size="extra-large-3"]){height:calc(${g.vR} * 14px);
        width: calc(${g.vR} * 7.5px);border-radius:0px}:host([size="large"]) .flipper-caret{height:24px;width:24px}:host([size="extra-large"]) .flipper-caret{height:30px;width:30px}:host([size="extra-large-2"]) .flipper-caret{height:34px;width:34px}:host([size="extra-large-3"]) .flipper-caret{height:24px;width:24px}.flipper-caret{filter:invert(var(--flipperInvert,15%));height:16px;width:16px}:host([invert-color="true"]) .flipper-caret{filter:invert(var(--flipperInvert,100%))}.flipper-container{display:flex}:host(:not([disabled]):hover){cursor:pointer;background:${d.Rg}}:host([invert-color="true"]:hover){background:var(--neutral-foreground-rest)}:host(:not([disabled]):active){background:${d.DK}}:host([invert-color="true"]:active){background:var(--neutral-foreground-rest)}:host([invert-color="true"]:hover){cursor:pointer}:host::-moz-focus-inner{border:0}`.withBehaviors(new f.N(null,v));var C,b=i(96950);const w=`${null===(C=(0,i(58792).rA)())||void 0===C?void 0:C.StaticsUrl}latest/fluent-icons/caret_left_16_filled.svg`,x=b.qy`<span role="button" class="flipper-container" tabindex="0" aria-label="${t=>t.ariaLabel}" @click="${(t,e)=>t.handleActivate(e.event)}" @keydown="${(t,e)=>{const i=e.event;return!!i.repeat||t.handleActivate(i)}}"><img alt="" class="flipper-caret" src="${t=>t.caretIcon?t.caretIcon:w}"/></span>`,$=l.compose({name:"card-flipper",styles:y,template:x})},25717(t,e,i){i.d(e,{T(){return o}});var r=i(96950);function o(){return r.qy`
        <slot></slot>
    `}},26813(t,e,i){i.d(e,{D(){return g},P(){return u}});var r=i(56911),o=i(60815),s=i(96950),a=i(92011),n=i(38493),l=i(55230),d=i(5096),c=i(50180),h=i(35106),p=i(88458);const u={vertical:"vertical",horizontal:"horizontal"};class g extends a.L{constructor(){super(...arguments),this.orientation=u.horizontal,this.hideActiveIndicator=!1,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=t=>"true"===t.getAttribute("aria-disabled"),this.isFocusableElement=t=>!this.isDisabledElement(t),this.setTabs=()=>{const t="gridColumn",e="gridRow",i=this.isHorizontal()?t:e;this.activeTabIndex=this.getActiveIndex(),this.showActiveIndicator=!1,this.tabs.forEach((r,o)=>{if("tab"===r.slot){const t=this.activeTabIndex===o&&this.isFocusableElement(r);!this.hideActiveIndicator&&this.isFocusableElement(r)&&(this.showActiveIndicator=!0);const e=this.tabIds[o],i=this.tabpanelIds[o];r.setAttribute("id",e),r.setAttribute("aria-selected",t?"true":"false"),r.setAttribute("aria-controls",i),r.addEventListener("click",this.handleTabClick),r.addEventListener("keydown",this.handleTabKeyDown),r.setAttribute("tabindex",t?"0":"-1"),t&&(this.activetab=r)}r.style[t]="",r.style[e]="",r.style[i]=`${o+1}`,this.isHorizontal()?r.classList.remove("vertical"):r.classList.add("vertical")})},this.setTabPanels=()=>{this.tabpanels?.forEach((t,e)=>{const i=this.tabIds[e],r=this.tabpanelIds[e];t.setAttribute("id",r),t.setAttribute("aria-labelledby",i),this.activeTabIndex!==e?(t.setAttribute("tabindex","-1"),t.setAttribute("hidden",""),t.setAttribute("aria-hidden","true")):(t.removeAttribute("tabindex"),t.removeAttribute("hidden"),t.removeAttribute("aria-hidden"))})},this.handleTabClick=t=>{const e=t.currentTarget;1===e.nodeType&&this.isFocusableElement(e)&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(e),this.setComponent())},this.handleTabKeyDown=t=>{if(this.isHorizontal())switch(t.key){case l.kT:t.preventDefault(),this.adjustBackward(t);break;case l.bb:t.preventDefault(),this.adjustForward(t)}else switch(t.key){case l.I5:t.preventDefault(),this.adjustBackward(t);break;case l.HX:t.preventDefault(),this.adjustForward(t)}switch(t.key){case l.kE:t.preventDefault(),this.adjust(-this.activeTabIndex);break;case l.FM:t.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1)}},this.adjustForward=t=>{const e=this.tabs;let i=0;for(i=this.activetab?e.indexOf(this.activetab)+1:1,i===e.length&&(i=0);i<e.length&&e.length>1;){if(this.isFocusableElement(e[i])){this.moveToTabByIndex(e,i);break}if(this.activetab&&i===e.indexOf(this.activetab))break;i+1>=e.length?i=0:i+=1}},this.adjustBackward=t=>{const e=this.tabs;let i=0;for(i=this.activetab?e.indexOf(this.activetab)-1:0,i=i<0?e.length-1:i;i>=0&&e.length>1;){if(this.isFocusableElement(e[i])){this.moveToTabByIndex(e,i);break}i-1<0?i=e.length-1:i-=1}},this.moveToTabByIndex=(t,e)=>{const i=t[e];this.activetab=i,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=e,i.focus(),this.setComponent()}}orientationChanged(){this.$fastController.isConnected&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}activeidChanged(t,e){this.$fastController.isConnected&&(this.tabs.length<=(this.tabpanels?.length??0)||this.tabs.length<=(this.lazyPanels?.length??0))&&(this.prevActiveTabIndex=this.tabs.findIndex(e=>e.id===t),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(){this.$fastController.isConnected&&(this.tabs.length<=(this.tabpanels?.length??0)||this.tabs.length<=(this.lazyPanels?.length??0))&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}lazyPanelsChanged(){this.$fastController.isConnected&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.handleActiveIndicatorPosition())}tabpanelsChanged(){this.$fastController.isConnected&&(this.tabpanels?.length??0)<=this.tabs.length&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):0}getTabIds(){return this.tabs.map(t=>t.getAttribute("id")??`tab-${(0,c.NF)()}`)}getTabPanelIds(){return this.lazyPanels?this.lazyPanels.map(t=>t.id):(this.tabpanels||[]).map(t=>t.getAttribute("id")??`panel-${(0,c.NF)()}`)}setComponent(){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.focusTab(),this.change())}isHorizontal(){return this.orientation===u.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&!this.hideActiveIndicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;const t=this.isHorizontal()?"gridColumn":"gridRow",e=this.isHorizontal()?"translateX":"translateY",i=this.isHorizontal()?"offsetLeft":"offsetTop",r=this.activeIndicatorRef[i];this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`;const o=this.activeIndicatorRef[i];this.activeIndicatorRef.style[t]=`${this.prevActiveTabIndex+1}`;const s=o-r;this.activeIndicatorRef.style.transform=`${e}(${s}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",()=>{this.ticking=!1,this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${e}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")})}adjust(t){const e=this.tabs.filter(t=>!this.isDisabledElement(t)),i=e.indexOf(this.activetab),r=(0,d.AB)(0,e.length-1,i+t),o=this.tabs.indexOf(e[r]);o>-1&&this.moveToTabByIndex(this.tabs,o)}focusTab(){this.tabs[this.activeTabIndex].focus()}connectedCallback(){super.connectedCallback(),this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex()}}(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],g.prototype,"orientation",void 0),(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],g.prototype,"activeid",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Array)],g.prototype,"tabs",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Array)],g.prototype,"lazyPanels",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",s.kc)],g.prototype,"lazyPanelTemplate",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Array)],g.prototype,"tabpanels",void 0),(0,r.Cg)([(0,n.CF)({attribute:"hide-active-indicator",mode:"boolean"}),(0,r.Sn)("design:type",Object)],g.prototype,"hideActiveIndicator",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",HTMLElement)],g.prototype,"activeIndicatorRef",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Boolean)],g.prototype,"showActiveIndicator",void 0),(0,p.X)(g,h.qw)},28986(t,e,i){i.d(e,{DK(){return f},Rg(){return m},v8(){return g}});var r=i(45755),o=i(64183),s=i(95239);function a(t,e){return r.G.create({name:t},e)}const n=a("neutral-fill-secondary-rest-delta",3),l=a("neutral-fill-secondary-hover-delta",2),d=a("neutral-fill-secondary-active-delta",1),c=a("neutral-fill-secondary-focus-delta",3);var h=i(31023);const{create:p}=r.G,u=a("neutral-fill-secondary-recipe",{evaluate(t,e){return(0,o.t)(t(h.r),e||t(s.p),t(n),t(l),t(d),t(c))}}),g=p("neutral-fill-secondary-rest",t=>t(u).evaluate(t).rest),m=p("neutral-fill-secondary-hover",t=>t(u).evaluate(t).hover),f=p("neutral-fill-secondary-active",t=>t(u).evaluate(t).active);p("neutral-fill-secondary-focus",t=>t(u).evaluate(t).focus)},29853(t,e,i){i.d(e,{KA(){return A},Y6(){return T},nt(){return D},rF(){return R},HU(){return y},eJ(){return P},B(){return S},os(){return k},py(){return C},VN(){return _},z7(){return $},yA(){return b},Cb(){return I}});var r,o=i(58792),s=i(27233),a=i(54837),n=i(12420),l=i(93653),d=i(61782),c=i(87827),h=i(78285),p=i(96118),u=i(9790),g=i(6809),m=i(54249),f=function(t,e,i){var r=(0,h.A)(t),o=r||(0,p.A)(t)||(0,m.A)(t);if(e=(0,d.A)(e,4),null==i){var s=t&&t.constructor;i=o?r?new s:[]:(0,g.A)(t)&&(0,u.A)(s)?(0,n.A)((0,c.A)(t)):{}}return(o?a.A:l.A)(t,function(t,r,o){return e(i,t,r,o)}),i},v=i(41587);function y(t){if(!t)return"";const e=t.split("-");return 2===e.length?e[1]:t}function C(t){const e=y(t);return!isNaN(Number(e))}function b(t){if(!t)return"";const e=t.split("-");return 2===e.length?e[1]:t}function w(t,e){return t?(t=function(t){return o.T3.CurrentMarket===s.DX.JAJP&&(t+"").indexOf(".00")>-1?(t+"").replace(".00",""):t+""}(t),e&&-1==t.indexOf(e)?e+t:t):""}function x(t){const e=t.length;return t.slice(0,e-3)+t.slice(e-2,e)}function $(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:s.DX.ENUS;if(t){let r;r=-1!==(t+="").indexOf(e)?t.replace(e,""):t;const o=r.replace(/,/g,""),a=parseFloat(o);return a+"00"!==x(o)&&a+""!==o?t:i===s.DX.JAJP?w(a.toLocaleString(i),e):w(a.toLocaleString(i,{minimumFractionDigits:2,maximumFractionDigits:2}),e)}return t}function k(t,e){if(t&&e){return String(t)+"+"+e}return""}function P(t,e,i){if(t&&e&&t>=e){const r=(t-e)/1e3;let o=String(parseInt(String(r/60/60%24)));o=Number(o)<10?"0"+o:o;let s=String(parseInt(String(r/60%60)));s=Number(s)<10?"0"+s:s;let a=String(parseInt(String(r%60)));return a=Number(a)<10?"0"+a:a,i+String(o+":"+s+":"+a)}return""}function S(t){const e=[],i=[];return t&&t.length>0&&t.forEach(t=>{var r;if(t&&t.id&&null!=t&&null!==(r=t.imageInfo)&&void 0!==r&&r.sourceImageUrl){const r=new URLSearchParams(new URL(t.imageInfo.sourceImageUrl).search);r.has("id")&&(e.push(y(t.id)),i.push(r.get("id")))}}),[e,i]}function _(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(new Date).getHours(),e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:(new Date).toLocaleDateString(),i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:72e5;return new Date(e+(t>=10?" "+t:" 0"+t)+":00:00").getTime()+i}function A(t){const e=(new TextEncoder).encode(t),i=Array.from(e).map(t=>String.fromCharCode(t)).join("");return btoa(i)}function D(t,e,i){if(!t||!e||!i)return;const r=+t.replace(i,"").replace(",",""),o=+e.replace(i,"").replace(",","");if(!r||!o)return;const s=r-o;return s<=0?void 0:s}function R(t,e,i){let r=arguments.length>3&&void 0!==arguments[3]&&arguments[3];const o=D(t,e,i);if(!o)return;const s=100*o/+t.replace(i,"").replace(",","");return(r?Math.ceil(s):Math.floor(s))+"%"}function T(t,e){if(t){let i=t;return null==e||e.forEach(t=>{i=i.replace(new RegExp(t+"$"),"")}),i=i.replace(/[^a-z0-9]/gi,"").toLowerCase(),i}return t}function I(t){return f(t,function(e,i,r){e[Array.isArray(t)?r:(0,v.A)(""+r)]=(0,g.A)(i)?I(i):i})}!function(t){t.el="el",t.es="es",t.da="da",t.fi="fi",t.fr="fr",t.hu="hu",t.it="it",t.ja="ja",t.nl="nl",t.pl="pl",t.pt="pt"}(r||(r={}))},30581(t,e,i){i.d(e,{yr(){return F}});var r=i(87993),o=i(96950),s=i(60402),a=i(69259),n=i(416),l=i(10108),d=i(82774),c=i(58792);const h=(0,i(75307).Eo)("MicrosoftLogoWithText","4806176","icons-wc/icons/shopping"),p=o.qy`<div class="footer ${t=>t.hasAbstract?"has-abstract-footer":""}" part="footer"><span part="start-actions" ${(0,s.K)("startActionsContainer")}><slot name="start-actions" ${(0,s.K)("startActions")} @slotchange=${t=>t.handleStartActionsContentChange()}></slot></span><span part="end-actions" ${(0,s.K)("endActionsContainer")}><slot name="end-actions" ${(0,s.K)("endActions")} @slotchange=${t=>t.handleEndActionsContentChange()}></slot></span></div>`,u=o.qy`<div style=" background: linear-gradient(265deg, rgb(18, 113, 3) 0%, rgb(69, 153, 3) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><img class="delivery-icon" loading="lazy" src="${(0,c.rA)().StaticsUrl}pr-3980746/shopping/deliveryTruckIcon.svg"><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">Free shipping</span></div>`,g=/\d+% cash ?back/i,m=o.qy`<div style=" background: linear-gradient(270deg, rgb(21, 61, 219) 0%, rgb(0, 113, 246) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">${t=>{var e;return(t.title&&(null===(e=t.title.match(g))||void 0===e?void 0:e[0]))??"Earn cash back"}}</span></div>`,f=(t,e)=>o.qy`<div style=" background: #424242; display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding: 0px 2px; padding-top: 0px; align-items:center; "><img src="${e}" aria-hidden="true" onerror="this.style.display='none'"/><span style=" ${t.includes("Holiday Deals")?"font-weight: 600;":"text-transform: uppercase; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size));"} color: white; padding:2px; align-items: center; ">${t}</span></div>`,v=o.qy`<div style="display: flex;">${t=>t.id.includes("__")?o.qy` ${(0,a.z)(t=>t.id.includes("_Christmas"),f("Holiday Deals","https://www.bing.com/th?id=OSS.BT4443E8F9A2BBD34313F790F7FC3FD09DD960AF1BCACA6A40544E8EBF98066A80"))} ${(0,a.z)(t=>t.id.includes("_BlackFriday"),f("Black Friday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))} ${(0,a.z)(t=>t.id.includes("_CyberMonday"),f("Cyber Monday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))}`:o.qy` ${(0,a.z)(t=>t&&!t.id.includes("_NoCashback"),m)} ${(0,a.z)(t=>t,u)} `}</div>`,y=o.qy`<div style="background: no-repeat center url('${t=>t.querySelector("img").src}');background-size: cover;filter: blur(40px); height: 100%; width:100%;position: absolute;"></div>`,C=o.qy`<div class="logo-container"><img src=${h} alt="Microsoft Logo" aria-hidden="true" /></div>`,b=o.qy`<template ${(0,n.Y)({property:"mediaNodes",filter:(0,l.Y)("[slot='media'], [slot='icon']")})}><span part="background-image" class='${t=>t.id.includes("contentcard_InfoBuyDirectCard")?"bd-background-image":"background-image"}'>${(0,a.z)(t=>t.id.includes("contentcard_tripleCashback"),C)} ${(0,a.z)(t=>t.id.includes("contentcard_edgeReclaim"),C)} ${(0,a.z)(t=>t.id.includes("contentcard_InfoBuyDirectCard"),y)}<slot name="background-image" ${(0,s.K)("backgroundImage")}></slot></span>${(0,a.z)(t=>t.id.includes("BuyDirectCard"),v)}<div class="mask" part="mask"></div><div class="body ${t=>t.hasAbstract?"has-abstract":""} ${t=>t.isGrid?"grid":""}" part="body">${(0,a.z)(t=>{var e;return(null==t||null===(e=t.mediaNodes)||void 0===e?void 0:e.length)>0},o.qy`<div class="media-wrapper" part="media-wrapper"><div part="media" ${(0,s.K)("mediaContainer")}><slot name="media" ${(0,s.K)("media")} @slotchange=${t=>t.handleMediaContentChange()}></slot><slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot><span part="icon" ${(0,s.K)("iconContainer")} class="${t=>t.iconSlottedNodes&&t.iconSlottedNodes.length?"icon":"icon__hidden"}"><slot name="icon" ${(0,s.K)("icon")} ${(0,d.e)("iconSlottedNodes")}></slot></span></div></div>`)}<div class="heading-container" part="heading-container">${(0,a.z)(t=>{var e;return 0===(null==t||null===(e=t.mediaNodes)||void 0===e?void 0:e.length)},o.qy`<slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot>`)}<slot name="attribution"></slot><span class="heading-wrapper" part="heading-wrapper" role="heading" aria-level=${t=>t.headinglevel} name="heading"><a class="heading" part="heading" href=${t=>t.href?t.href:void 0} target=${t=>t.target?t.target:void 0} @click=${(t,e)=>t.handleContentCardLinkClick(e.event)} data-t="${t=>t.anchorTelemetryTag}"><slot></slot></a></span></div><div class="abstract" part="abstract"><slot name="abstract" ${(0,d.e)("abstract")}></slot></div>${(0,a.z)(t=>t.layout!==r.S.default,p)}</div>${(0,a.z)(t=>t.layout===r.S.default,p)}<span part="hover-actions" class="${t=>t.hoverActionsSlottedNodes&&t.hoverActionsSlottedNodes.length?"hover-actions":"hover-actions__hidden"}"><slot name="hover-actions" ${(0,d.e)("hoverActionsSlottedNodes")}></slot></span><slot name="call-to-action"></slot></template>`;var w=i(64187),x=i(73477),$=i(22131),k=i(74849),P=i(50882),S=i(7896),_=i(61138),A=i(64003),D=i(41123),R=i(48751),T=i(89580),I=i(95239),M=i(86856);const O=k.A` :host([layout="default"]) .media-wrapper{float:right}`,z=k.A` :host([layout="default"]) .media-wrapper{float:left}`,B=k.A`
    ${(0,w.V)("flex")} :host{--icon-size:24px;position:relative;width:auto;box-sizing:border-box;font-family:${S.O};flex-direction:column;outline:none;height:100%;overflow:hidden}:host(:hover) .hover-actions{opacity:1;transition:opacity 0.2s ease-in-out}.body{display:grid;justify-content:center;row-gap:8px;column-gap:10px;grid-template-columns:1fr auto;grid-template-rows:auto}:host([layout="default"]) .body .abstract{display:none}:host([layout="default"]) .body{display:block}:host([layout="default"]) .body.grid{display:grid}:host([layout="default"]) .body.grid .media-wrapper{float:none}:host([layout="default"]) .has-abstract .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([layout="default"]) .has-abstract .media-wrapper{margin-inline-start:16px}:host([image-priority]) .has-abstract .media-wrapper{margin-inline-start:0}.footer{padding-inline-start:var(--footer-start-padding,16px);padding-inline-end:var(--footer-start-padding,16px);padding-top:var(--footer-padding-top,0);padding-bottom:var(--footer-padding-bottom,4px);margin-top:auto;font-size:var(--footer-font-size,${_.k});
        line-height: var(--footer-line-height, ${_.F})}.logo-container{display:flex;align-items:center;position:fixed;bottom:16px;z-index:1000;left:17px}.footer,.start-actions,.end-actions{display:flex;flex-direction:row;align-items:center;justify-content:space-between;color:${A.c};
        fill: ${A.c}}.footer__hidden{display:none}.hover-actions{display:flex;flex-direction:column;position:absolute;top:8px;z-index:2;opacity:0}.hover-actions__hidden{display:none}.hover-actions:focus-within{opacity:1}.heading-container{grid-row:1;display:flex;flex-direction:column;padding-inline-start:var(--heading-start-padding,16px);padding-inline-end:var(--heading-end-padding,16px);padding-bottom:0;padding-top:16px}.heading-wrapper a:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;top:0;width:100%;z-index:1}:host([layout="condensed"]) .body{gap:0}:host([layout="condensed"]) .footer{grid-row:2;grid-column-start:1;grid-column-end:var(--footer-grid-column-end,auto);padding-inline-start:16px}:host([layout="condensed"]) .media-wrapper{position:relative;grid-row:1 / span 2;margin-top:5px}:host([layout="condensed"]) .heading-container{padding-top:0px;--heading-end-padding:12px}:host([layout="condensed"]) ::slotted([slot="attribution"]){margin-bottom:0px}.icon{position:absolute;display:inline-flex;top:auto;bottom:0;justify-content:center;align-items:center;margin:0 0 4px 0;margin-inline-start:4px}.hover-actions{inset-inline-end:8px}.icon{inset-inline-start:0}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){inset-inline-start:8px}.icon__hidden{display:none}::slotted([slot="icon"]){width:var(--icon-size);height:var(--icon-size);fill:#FFF}::slotted([slot="attribution"]){margin-bottom:6px}::slotted([slot="abstract"]){margin:2px 0}.media-wrapper{grid-row:1;grid-column:2;margin-inline-end:var(--media-inline-padding,16px);margin-top:16px}.media{display:flex;position:relative}:host([image-priority]) .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([image-priority]) .body{grid-template-columns:1}:host([image-priority]) .media-wrapper{grid-row:1;grid-column:span 2;margin:0}:host([image-priority]) .heading-container{grid-row:2;grid-column:span 2;padding-top:10px;padding-inline-start:var(--heading-start-padding,16px)}:host([image-priority]) ::slotted([slot="media"]),:host([layout="infoPaneSplitHorizontal"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPane"]) .media-wrapper,:host([layout="infoPane1x3y"]) .media-wrapper{grid-row:1;grid-column:1;margin-top:0;width:fit-content;height:fit-content}:host([layout="infoPane"]) .icon,:host([layout="infoPaneSplitVertical"]) .icon,:host([layout="infoPane1x3y"]) .icon{display:inline;left:0;top:0;margin:4px 0 0;margin-inline-start:4px}:host([layout="infoPaneSplitVertical"]) .icon{display:block}:host([layout="infoPaneSplitHorizontal"]) .icon{bottom:0px}:host([layout="infoPaneSplitHorizontal"]) .heading-container,:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{align-self:end}:host([layout="infoPaneSplitHorizontal"]) .body,:host([layout="infoPane"]) .body,:host([layout="infoPane1x3y"]) .body{height:100%;grid-template-rows:1fr auto}::slotted([slot="call-to-action"]){width:calc(100% - 32px);grid-row:3;z-index:1;grid-column:1 / span 2;margin:0 16px}::slotted([slot="media"]){border-radius:calc(var(--content-card-corner-radius,2) * 2px)}:host([layout="default"]) .grid .heading-container{grid-area:initial !important}:host([layout="default"]) .has-abstract .abstract{display:block;padding:0 16px 16px 16px}.abstract{position:relative;margin:0;font-size:var(--abstract-font-size,${D.K});
        line-height: var(--abstract-line-height, ${D.Z});
        font-weight: 400;
        grid-column: span 2;
        box-sizing: content-box;
        color: ${A.c};padding:0 16px}::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){z-index:2;display:grid;gap:5px;align-items:center;grid-auto-flow:column}::slotted([slot="call-to-action"]){z-index:2}::slotted(fluent-button[slot="start-actions"]),::slotted(fluent-button[slot="end-actions"]){color:${A.c};
        fill: ${A.c}}::slotted(fluent-button[appearance="stealth"]:not(:hover)),:slotted([slot="hover-actions"]:not(:hover)){background:transparent}.heading{text-decoration:none;outline:none;color:${R.l};
        font-size: var(--heading-font-size, ${T.Y});
        line-height: var(--heading-line-height, ${T.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,3);white-space:initial}.mask{display:none}.heading:hover,.heading:${x.N}{text-decoration:underline}.heading::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}:host([layout="infoPane"]),:host([layout="infoPane1x3y"]){justify-content:flex-end;border:none}:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{position:absolute;bottom:0;right:0;left:0;background:${I.p};
        box-shadow: 0px -25px 15px ${I.p}}:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{grid-column:1 / 3;z-index:1}:host([layout="infoPane"]) .has-abstract .heading-container,:host([layout="infoPane1x3y"]) .has-abstract .heading-container{grid-area:2/ 1 / span 2 / auto;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:8px;align-self:flex-start}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{grid-row:2;grid-column:2;color:${R.l};padding:8px 16px 0 16px;align-self:end;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:4}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract{display:none}:host([layout="infoPane"]) .has-abstract,:host([layout="infoPane1x3y"]) .has-abstract{grid-template-columns:1fr 1fr;gap:0 10px}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer{min-height:calc(40px - 4px)}:host([layout="infoPane"]) .has-abstract .abstract,:host([layout="infoPane1x3y"]) .has-abstract .abstract{display:-webkit-box;align-self:flex-end}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{display:flex;position:absolute;top:0;left:0;right:0;bottom:0;background-image:var(--mask-gradient,linear-gradient(to top,rgba(0,0,0,1),rgba(0,0,0,0) 176px))}:host([layout="infoPane1x3y"]) .mask{background-image:var(--mask-gradient,linear-gradient(rgba(0,0,0,0),rgba(0,0,0,1) 69px,rgba(0,0,0,1)));top:257px}:host([layout="infoPane"]) .has-abstract .has-abstract-footer,:host([layout="infoPane1x3y"]) .has-abstract .has-abstract-footer{grid-row:3;grid-column:2;position:inherit;align-self:flex-end;max-height:40px}:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer{margin-top:unset;grid-row:2;grid-column:1 / span 2;padding-inline-start:16px;padding-inline-end:16px}:host([layout="infoPane"]) ::slotted(msft-attribution[slot="attribution"]),:host([layout="infoPane1x3y"]) ::slotted(msft-attribution[slot="attribution"]){color:${R.l};text-shadow:0px 0.4px 0.9px rgba(0,0,0,0.13),0px 0px 2.22px rgba(0,0,0,0.11)}:host([layout="infoPaneSplitVertical"]){grid-template-columns:304px 1fr;grid-template-rows:auto;background:${I.p}}:host([layout="infoPaneSplitVertical"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPaneSplitVertical"]) .media-wrapper{grid-row:1 / span 2;grid-column:1;margin:0}:host([layout="infoPaneSplitVertical"]) .heading-container{grid-row:1;grid-column:2;--heading-start-padding:4px;--heading-end-padding:16px;padding-bottom:0;padding-top:16px}:host([layout="infoPaneSplitVertical"]) .footer{grid-row:2;grid-column:2;padding-inline-start:0;padding-inline-end:16px;padding-top:0}:host([layout="infoPaneSplitHorizontal"]) .body{grid-template-columns:1fr 1fr;grid-template-rows:326px auto auto;row-gap:4px;background:${I.p}}:host([layout="infoPaneSplitHorizontal"]) .media-wrapper{grid-column:1 / span 2;margin:0}:host([layout="infoPaneSplitHorizontal"]) .heading-container{grid-column:1;grid-row:2 / span 2;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:12px}:host([layout="infoPaneSplitHorizontal"]) .footer{grid-column:2;grid-row:3;box-shadow:none}:host([layout="infoPaneSplitHorizontal"]) .abstract{color:inherit;align-self:inherit;padding:12px 16px 0 16px}.background-image{position:absolute;top:0;left:0;right:0;bottom:0}:host([layout="infoPane1x3y"]) .background-image{position:absolute;top:0;left:0;right:0;bottom:136px}.background-image ::slotted(img){width:100%;height:100%;object-fit:cover}.bd-background-image ::slotted(img){width:100%;height:100%;object-fit:contain;position:absolute;top:0px}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){position:absolute;top:8px;z-index:1}::slotted([slot="content-indicator"]){margin-bottom:26px;align-self:flex-start}`.withBehaviors(new M.t(O,z),(0,$.mr)(k.A` .heading{color:${P.A.LinkText};
                    background: ${P.A.ButtonFace}}.abstract{color:${P.A.ButtonText}}.icon{background-color:#000;height:fit-content}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{color:${P.A.ButtonText};
                    background: ${P.A.ButtonFace}}.footer,.start-actions,.end-actions,::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){background:${P.A.ButtonFace};
                    color: ${P.A.ButtonText};fill:currentcolor}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{background-image:none}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer,:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer,:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{background:${P.A.ButtonFace};box-shadow:none}::slotted(fluent-button[appearance="stealth"]:not(:hover)){background:${P.A.ButtonFace};
                }
            `));var U=i(99900);const F=r.m.compose({name:`${U.i.prefix}-content-card`,template:b,styles:B,shadowOptions:{delegatesFocus:!0}})},30664(t,e,i){i.d(e,{I(){return r}});const r="1"},30758(t,e,i){i.d(e,{A(){return o}});var r=i(76696);const o=i(96950).qy`
<fluent-card
    style="grid-area:${t=>t.gridArea};"
    class="${t=>t.cardSize}"
>
    <trending-now-card
        config-instance-src=${t=>t.trendingNowCardConfigInfo&&(0,r.v)(t.trendingNowCardConfigInfo)}
        config-shared-ns=${t=>t.trendingNowCardConfigInfo&&t.trendingNowCardConfigInfo.configRef&&t.trendingNowCardConfigInfo.configRef.sharedNs}
        instance-id=${t=>t.trendingNowCardConfigInfo&&t.trendingNowCardConfigInfo.instanceId}
        :feedLayoutCardSize=${t=>t.cardSize}
        :parentTelemetry=${t=>t.parentTelemetryObject}
        :trendingNowCardMetadata=${t=>t.trendingNowCardMetadata}
        :visualReadinessCallback="${t=>t.visualReadinessCallback}"
    >
    </trending-now-card>
</fluent-card>
`},36467(t,e,i){i.d(e,{o(){return p}});var r=i(55619),o=i(1840),s=i(41150),a=i(68002),n=i(27160),l=i(35639),d=i(96787),c=i(18442),h=i(79187);const p={getFeedDataForCard(t){return function(t){var e,i;const{cardSlot:r,configOptions:p,parentTelemetryObject:u,cardMetadata:g,openLinksInNewTab:m,visualReadinessCallback:f,isAnaheimDesign:v,isProviderInFooter:y,enableArticleTimestamps:C,localizedStrings:b,enableNewTimestampFormatForJAJP:w}=t;if(!g||!g.subItems||0===g.subItems.length)return(0,d.wc)();const x=(null==g||null===(e=g.subItems[0])||void 0===e?void 0:e.type)===n.pL.WebContent,$=p&&p,k=g.subItems[0].cardContent,{id:P,destinationUrl:S,title:_,provider:A,type:D}=k;$&&($.instanceId=`denseCard-${P}`);const R={id:P,destinationUrl:S,openLinksInNewTab:m,title:_,ariaLabel:(0,c.yL)(_,A,null==p?void 0:p.localizedStrings),imagePriority:!1,providerData:(0,c.p_)(A,x),isProviderInFooter:y,imageData:(0,a.po)(g.subItems[0],o.L._240x129,f,v),publishedDateTime:C&&`${(0,a.fL)(w,new Date(k.publishedDateTime),k.locale,b)}`},T=g.subItems.slice(1),I={heroNews:R,newsList:null==T?void 0:T.map(t=>{var e;const i=t.type===n.pL.NativeAd||t.type===n.pL.CmsAd,r=null==t?void 0:t.cardContent;if(!i){const e=t.type===n.pL.WebContent;return{abstract:t.cardContent.abstract,imageData:(0,a.po)(t,o.L._240x129,f,v),destinationUrl:t.cardContent.destinationUrl,title:t.cardContent.title,ariaLabel:(0,c.yL)(t.cardContent.title,t.cardContent.provider,null==p?void 0:p.localizedStrings),providerData:(0,c.p_)(t.cardContent.provider,e),isNativeAd:i,telemetryContext:(0,s.dj)(u,t.cardContent,t.metadata,null,e),isNarrowNewsItem:null==p?void 0:p.isNarrowNewsItem,publishedDateTime:C&&`${(0,a.fL)(w,new Date(r.publishedDateTime),r.locale,b)}`}}const l=(null===(e=t.placement)||void 0===e?void 0:e.items[0])||{},{beaconsJson:d,privacyUrl:g,adLabelText:m,isGreyAdsLabelEnabled:y,geminiViewabilityDataJson:x}=t.placement||{};return{...l,beaconsJson:d,privacyUrl:g,adLabelText:m,geminiViewabilityDataJson:x,isNativeAd:i,adTelemetryContext:(0,h.u)(t,u,"river",0),isNarrowNewsItem:null==p?void 0:p.isNarrowNewsItem,isGreyAdsLabelEnabled:y}})},M={id:null==$?void 0:$.instanceId,childTemplateType:"dense-card",telemetryObject:u,denseConfigInfo:$,denseData:I,visualReadinessCallback:f};return(0,l.bw)({id:"denseCard",experienceType:null==$||null===(i=$.configRef)||void 0===i?void 0:i.experienceType,mapperArgs:t},M,(t,e)=>{const i=e.telemetryExt;return I.newsList.forEach((t,e)=>{var r,o;if(!t.isNativeAd&&null!==(r=t.telemetryContext)&&void 0!==r&&r.destination&&(null===(o=t.telemetryContext.destination)||void 0===o||null===(o=o.contract)||void 0===o||!o.ext)){const r=T[e],{traceIdIndex:o}=r||{},{recoId:s,ri:a}=(null==r?void 0:r.metadata)||{},n={...i,recoId:s,ri:a,traceIdIndex:o};t.telemetryContext.destination=t.telemetryContext.contentCard.addOrUpdateChild({...t.telemetryContext.destination.contract,ext:n})}}),{denseData:I}})}(t)},viewTemplate:r.e}},37256(t,e,i){i.d(e,{R(){return h}});var r=i(64187),o=i(22131),s=i(74849),a=i(50882),n=i(37998),l=i(57416),d=i(95239),c=i(48751);const h=s.A`
    ${(0,r.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${d.p};
        color: ${c.l};
        border-radius: calc(${l.JU} * 1px);
        ${n.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,o.mr)(s.A`
            :host {
                forced-color-adjust: none;
                background: ${a.A.Canvas};
                box-shadow: 0 0 0 1px ${a.A.CanvasText};
            }
        `))},37725(t,e,i){i.d(e,{H8(){return n},RD(){return s},Wr(){return l},qK(){return d}});var r=i(93552),o=i(22341);const s=(t,e,i)=>{var o;return null!=t&&t.title?(null!=t&&null!==(o=t.thumbnail)&&void 0!==o&&o.image||l(r.r5T,`Video ID [${n(null==t?void 0:t.id,e,i)}] has an empty headline image but the content is valid.`),a(t,e,i)):(l(r.Ta7,`Video ID [${n(null==t?void 0:t.id,e,i)}] has an empty headline.`),!1)},a=(t,e,i)=>{var o;if(null!=t&&null!==(o=t.videoMetadata)&&void 0!==o&&null!==(o=o.externalVideoFiles)&&void 0!==o&&o.length){const o=t.videoMetadata.externalVideoFiles;return!(null==o?void 0:o.find(t=>!t.url&&!t.format))||(l(r.WWk,`Video ID [${n(t.id,e,i)}] has an invalid 1pp video file.`),!1)}return!1},n=(t,e,i)=>`${t??e??"N/A"}${i?" (playlist) ":""}`,l=(t,e)=>{(0,o.vV)(t,"Data returned by content view does not contain expected video data.",e,{...t.pb})},d=t=>{var e;const{cardContent:i,metadata:r}=t;return{id:t.id,title:null==i?void 0:i.title,thumbnail:{image:null==i||null===(e=i.images)||void 0===e?void 0:e[0]},videoMetadata:{playTime:null==r?void 0:r.videoMetadata.playTime,externalVideoFiles:null==i?void 0:i.videoFiles},sourceId:(null==i?void 0:i.sourceId)||""}}},38380(t,e,i){i.d(e,{v(){return r}});const r=(0,i(25717).T)()},39317(t,e,i){i.d(e,{Av(){return r},ez(){return n},sr(){return c}});const r=(t,e,i)=>{t.addEventListener("touchstart",l,{signal:i}),t.addEventListener("touchmove",d,{signal:i}),t.addEventListener("touchend",e,{signal:i})};let o,s,a=!1;const n=Object.freeze({Left:"left",Right:"right"}),l=t=>{const e=t.touches[0];return o={x:e.clientX,y:e.clientY,time:t.timeStamp},s=setTimeout(()=>!0,500),!0},d=t=>{const e=t.touches[0].clientX-o.x;Math.abs(e)>5&&(a=!0),clearTimeout(s)},c=(t,e,i)=>{if(!a)return!0;clearTimeout(s);const r=t.changedTouches[0],l=r.clientX,d=r.clientY,c=t.timeStamp,h=l-o.x,p=d-o.y;if(Math.abs(h)>Math.abs(p)){const r=c-o.time,s=e??(i?.15*i:45),a=450;if(Math.abs(h)>s&&r<a)return t.cancelable&&t.preventDefault(),h>0?n.Right:n.Left}return o={x:0,y:0,time:0},a=!1,!0}},40315(t,e,i){i.d(e,{J(){return y}});var r,o=i(58792),s=i(70775),a=i(2827),n=i(26363);!function(t){t[t.ntp=0]="ntp",t[t.dhp=1]="dhp"}(r||(r={}));const l="v1";var d,c=i(22341),h=i(93552),p=i(27659);!function(t){t.MIT="MIT",t.Topic="Topic",t.Category="category"}(d||(d={}));var u=i(77367),g=i(68136),m=i(31756),f=i(6011);const v="XGP6bGECtXattHPaMTSEtXAJpanIfDLqAumdUN8Bpi";class y{constructor(t,e,i,r,o){this.fetchImpl=t,this.ocid="Peregrine",this.serviceClientSettings=e,this.APISettings=i,this.formCodes=r,this.generateServiceClientSettings(o)}generateServiceClientSettings(t){const e=(0,o.rA)(),i=((0,g.ab)(),s._3.getQueryParameterByName("userid",t)),r=s._3.getQueryParameterByName("testhooks",t),{enableLocalization:a,addFlightParam:n,queryParamsToForward:d}=this.APISettings;if(this.ocid="Peregrine",this.serviceClientSettings.queryParams){if(this.queryParamsMap=new Map(Object.entries(this.serviceClientSettings.queryParams)),this.queryParamsMap.set("apikey",this.serviceClientSettings.queryParams.apiKey||e.OneServiceApiKey),this.queryParamsMap.set(e.OneServiceContentMarketQspKey,e.CurrentMarket),this.queryParamsMap.set("ocid",this.ocid),this.queryParamsMap.set("trackingid",e.ActivityId),this.queryParamsMap.set("testhooks",r),"1"===r&&i&&this.queryParamsMap.set("userid",i),a&&e.Latitude&&e.Longitude&&(this.queryParamsMap.set("lat",e.Latitude),this.queryParamsMap.set("long",e.Longitude)),e.ShouldUseFdheadQsp){const t=n&&e.CurrentRequestTargetScope&&e.CurrentRequestTargetScope.pageExperiments,i=t&&t.join(",");this.queryParamsMap.set("fltids",i)}if(d){const e=new Set(d),i=new URL(t);if(i&&i.search){new URLSearchParams(i.search).forEach((t,i)=>{e.has(i)&&this.queryParamsMap.set(i,t)})}}}this.serviceClientSettings.pathComponents?this.pathComponentsMap=new Map(Object.entries(this.serviceClientSettings.pathComponents)):this.pathComponentsMap=new Map,this.pathComponentsMap.set(e.OneServiceContentMarketQspKey,e.CurrentMarket),this.pathComponentsMap.set("version",l)}async getShoppingEntitiesData(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:null,e=null;return await this.getShoppingEntitiesDataJson(t).then(t=>{e=this.TryGetShoppingEntitiesData(t)}).catch(t=>{(0,c.c_)(t,h.xkP,"Failed to fetch Shopping entities response")}),e}async getShoppingEntitiesDataJson(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:null;const e={method:"GET",headers:{accept:"application/json"}};let{pathComponents:i,queryParams:r,serviceBaseUrl:o,servicePath:a}=this.serviceClientSettings;const n=[];if(r)for(const t of this.queryParamsMap.entries())n.push({key:t[0],value:t[1]});if(i)for(const t of this.pathComponentsMap.entries())a=a.replace(`{${t[0]}}`,t[1]);const l=new URL(a,o);if(l.search=s._3.keyValueArrayToQueryString(n),this.serviceClientSettings.additionalUrlAugmentations&&(l.search=l.search.concat(this.serviceClientSettings.additionalUrlAugmentations)),!t||!t.data){const t=await this.fetchImpl(l.href,e);return t.ok?t.json():(u.YT.sendAppErrorEvent({...h.xkP,message:"Shopping carousel response not ok.",pb:{...h.xkP.pb,customMessage:`Shopping carousel response not ok. Status: ${t.status}, StatusText: ${t.statusText}`}}),null)}try{const e=JSON.parse(t.data);return p.v.log("shoppingEntitiesData provided by parent in serviceContextMetadata"),e}catch(t){return(0,c.c_)(t,h.ECJ,"Error in getShoppingEntitiesDataJson, unable to parse serviceContextMetadata"),null}}convertBlackJackDealsDataToShoppingEntitiesData(t){const e=t.shoppingEntities.map(t=>{var e;return{...t,communityInfo:this.ensureSocialBarDataForBlackjackDealsCommunityInfo(t.communityInfo,t.title,t.id),viewsCount:null===(e=t.productInsightsData.uxInsightDecoration.find(t=>t.startsWith("ViewCountInsight")))||void 0===e||null===(e=e.match(/--(.+)/))||void 0===e?void 0:e[1]}}).filter(t=>0!==Object.keys(t).length);return e.length>0?{shoppingEntities:e}:null}ensureSocialBarDataForBlackjackDealsCommunityInfo(t,e,i){const{itemId:r,itemUrl:o}=t??{};if(r&&o)return t;const s=f.E.buildAbsoluteUrl(e,void 0,i),a={itemId:s,itemUrl:s};return t?{...t,...a}:a}TryGetShoppingEntitiesData(t){var e,i,r,o,s;const{enablemsnsdcardcms:a}=this.APISettings;if(!t)return u.YT.sendAppErrorEvent({...h.Fjq,message:"Received empty ShoppingEntitiesData response.",pb:{...h.Fjq.pb,customMessage:JSON.stringify(t)}}),null;if(t.prongCards&&t.prongCards.length>0)return this.GetProngCardItems(t);if(t.productCards&&t.productCards.length>0)return t;if(t.shopping&&t.shopping.length>0)return JSON.parse(t.shopping[0].data);if(t.length>0&&"ShoppingCard"==(null===(e=t[0])||void 0===e?void 0:e.type))return JSON.parse(t[0].data);if(t.length>0&&"ShoppingCarousel"==(null===(i=t[0])||void 0===i?void 0:i.type)){const e=JSON.parse(t[0].data);if(e.topics&&e.topics.some(t=>{var e;return"Blackjack"===t.title&&(null===(e=t.shoppingEntities)||void 0===e?void 0:e.length)>0}))return this.convertBlackJackDealsDataToShoppingEntitiesData(e.topics.find(t=>"Blackjack"===t.title))}let n,l=[];if("ShoppingBuyDirectCard"==(null===(r=t[0])||void 0===r?void 0:r.type))n=t[0].type,l=JSON.parse(t[0].data),l.forEach(t=>{t&&t.imageInfo&&""==t.imageInfo.sourceImageUrl&&t.imageInfo.images&&(t.imageInfo.sourceImageUrl=t.imageInfo.images[0].url)});else if("ShoppingFeedResponse"==(null===(o=t[0])||void 0===o?void 0:o.type)&&a){var d;n=t[0].type,l=null===(d=JSON.parse(t[0].data))||void 0===d?void 0:d.categories,l.forEach(t=>{t&&t.backgroundImage&&null==t.imageInfo&&(t.imageInfo=t.backgroundImage,t.clickUrl=t.backgroundImage.clickUrl)})}else if("ShoppingFeedResponse"==(null===(s=t[0])||void 0===s?void 0:s.type)){var c;l=null===(c=JSON.parse(t[0].data))||void 0===c?void 0:c.trendingProducts}else l=t.shoppingEntities;if(!l||0==l.length)return u.YT.sendAppErrorEvent({...h.dMO,message:"Missing required fields in ShoppingEntitiesData response.",pb:{...h.dMO.pb,customMessage:JSON.stringify(t)}}),null;const{enbaleFirstCarouselItems:p,enbaleSecondCarouselItems:g,minCarouselItems:m,maxCarouselItems:f,randomizeCarouselItems:v}=this.APISettings;if(v&&(l=l.sort(()=>.5-Math.random())),l.length<m)return u.YT.sendAppErrorEvent({...h.c7V,message:"Insufficient shoppingEntities items in shoppingEntitiesData response.",pb:{...h.c7V.pb,customMessage:`MinimumRequired=${m}, shoppingEntitiesCount=${l.length}`}}),null;l.length>f&&(l=l.slice(0,f)),l.length>1&&p&&(l=l.slice(0,Math.ceil(l.length/2))),l.length>1&&g&&(l=l.slice(Math.ceil(l.length/2)));const y=this.GetFormCode("shoppingEntities");return l.forEach(t=>{t&&t.clickUrl&&(t.clickUrl=`${t.clickUrl}&FORM=${y}`)}),t.shoppingEntities=l,t.type=n,t}GetFormCode(t){const e=a.U0.isDhpPage()?r.dhp:r.ntp;return this.formCodes&&this.formCodes[t]&&this.formCodes[t][r[e]]}GetProngCardItems(t){if(!this.serviceClientSettings.usingPreviewTable&&!this.serviceClientSettings.usingProductionTable){const e=t.prongCards.filter(t=>t.type===d.Category).sort(()=>.5-Math.random()),i=t.prongCards.filter(t=>t.type!==d.Category).sort(()=>.5-Math.random());t.prongCards=e.concat(i).slice(0,10)}return t}getDealsSDCardRequestBody(){return JSON.stringify({categoryId:"All",getProductDeals:!0,skip:0,take:this.serviceClientSettings.queryParams.take||30,userMuid:(0,g.ab)()})}async getShoppingEntitiesDataUsing1S(){let t=!(arguments.length>0&&void 0!==arguments[0])||arguments[0],e=arguments.length>1?arguments[1]:void 0,i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:h.xkP,r=null;const o="shopping/blackjack/getblackjackdeals"===this.serviceClientSettings.servicePath?await this.fetchFrom1S(e,"POST",this.getDealsSDCardRequestBody()):await this.fetchFrom1S(e,"GET");var s;o?r=this.TryGetShoppingEntitiesData(o):t&&(0,c.c_)(new Error("Failed to fetch Shopping entities response"),i,`Failed to fetch Shopping entities response, with filter ${null===(s=this.serviceClientSettings)||void 0===s||null===(s=s.queryParams)||void 0===s?void 0:s.filter}`);return r}async fetchFrom1S(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"GET",i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null;const r=(0,o.rA)(),a={method:e,headers:await m.WR.getOneServiceHeaders(),body:i,timeoutMs:t},l=[];if((0,g.ab)()&&!this.APISettings.skipUserMUID&&(l.push({key:"user",value:"m-"+(0,g.ab)()}),a.headers||(a.headers={MUID:(0,g.ab)()}),a.headers.MUID=(0,g.ab)()),this.serviceClientSettings.queryParams){var d;l.push({key:"apikey",value:this.serviceClientSettings.queryParams.apikey||v}),l.push({key:r.OneServiceContentMarketQspKey,value:r.CurrentMarket}),this.serviceClientSettings.queryParams.ocid&&l.push({key:"ocid",value:this.serviceClientSettings.queryParams.ocid}),this.serviceClientSettings.queryParams.top&&l.push({key:"$top",value:this.serviceClientSettings.queryParams.top}),this.serviceClientSettings.queryParams.contentType&&l.push({key:"contentType",value:this.serviceClientSettings.queryParams.contentType});let t="";r.ShouldUseFdheadQsp&&null!==(d=r.CurrentRequestTargetScope)&&void 0!==d&&d.pageExperiments&&(t=r.CurrentRequestTargetScope.pageExperiments.join()),r.ShouldUseFdheadQsp&&this.serviceClientSettings.queryParams.fdhead&&(t=t+","+this.serviceClientSettings.queryParams.fdhead),t&&l.push({key:"fdhead",value:t}),this.serviceClientSettings.queryParams.select&&l.push({key:"$select",value:this.serviceClientSettings.queryParams.select}),this.serviceClientSettings.queryParams.filter&&l.push({key:"$filter",value:this.serviceClientSettings.queryParams.filter}),this.serviceClientSettings.queryParams.setactivityid&&l.push({key:"activityId",value:(0,n.G)()})}else l.push({key:"apikey",value:v});const p=new URL(this.serviceClientSettings.servicePath,this.serviceClientSettings.serviceBaseUrl);p.search=s._3.keyValueArrayToQueryString(l);try{const t=await this.fetchImpl(p.href,a);if(t.ok){return await t.json()}}catch(t){(0,c.c_)(t,h.F6z,`MSN homepage shopping carousel fetch data failed, request url: ${p.href}`)}l.pop(),p.search=s._3.keyValueArrayToQueryString(l);try{const t=await this.fetchImpl(p.href,a);if(t.ok){return await t.json()}}catch(t){return(0,c.c_)(t,h.F6z,`MSN homepage shopping carousel second call fetch data failed, request url: ${p.href}`),null}}async hasBuyDirectInterest(){const t=await this.getShoppingEntitiesDataUsing1S(!0);if(!t||!t.shoppingEntities||!t.shoppingEntities.length)return!1;const e=t.shoppingEntities[0];return!(!e.id||!e.id.startsWith("Reco-"))}}},41298(t,e,i){i.d(e,{j(){return s}});var r=i(96950),o=i(65055);const s=r.qy`
    ${t=>(0,o.yN)(t.shoppingCarouselCardConfigInfo,{attributes:{style:`grid-area:${t.gridArea}`,class:`${t.cardSize}`,tabindex:t.customTabIndex??0},properties:{parentTelemetry:t.parentTelemetryObject,openLinksInNewTab:t.openLinksInNewTab,sdCardActionClickHandler:t.sdCardActionClickHandler,goToPersonalizeCallback:t.goToPersonalizeSettingsCallback,refreshFeedCallback:t.refreshFeedCallback,shoppingCardMetadata:t.shoppingCardMetadata,useInlineSvgIcons:t.useInlineSvgIcons,cardSize:t.cardSize}})}
`},41587(t,e,i){i.d(e,{A(){return a}});var r=i(57842),o=i(18573),s=function(t){return(0,o.A)((0,r.A)(t).toLowerCase())},a=(0,i(13025).A)(function(t,e,i){return e=e.toLowerCase(),t+(i?s(e):e)})},43252(t,e,i){i.r(e),i.d(e,{StripeWC(){return Rr},StripeWCFlippersStyles(){return hr},StripeWCRiverStyles(){return pr},StripeWCStyles(){return nr},StripeWCTemplate(){return Kr},ToolingInfo(){return Xr},templateDarkStyles(){return cr},templateStyles(){return dr},topStripeStyles(){return lr}});var r=i(2958),o=i(37180),s=i(75003),a=i(99564),n=i(65614),l=i(10699),d=i(99900),c=i(13959),h=i(71608),p=i(30581),u=i(1540),g=i(56911),m=i(38493),f=i(60815),v=i(55230),y=i(56863),C=i(92011);class b extends C.L{}class w extends((0,y.rf)(b)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class x extends w{onTitleClicked(){this.$emit("action-title-clicked")}handleTextInput(){this.inputControl&&(this.value=this.inputControl.value,this.$emit("action-text-input",this.inputControl.value))}addToWatchlist(t){this.inputControl&&(this.inputControl.value="",this.value=""),this.$emit("action-add-to-watchlist",t)}handleOnKeyDownSearchBox(t){if(!this.moneyCardContentData.showSuggestions)return!0;switch(t.key){case v.I5:t.preventDefault(),this.activeSuggestion=this.searchSuggestions.length-1,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId,this.focusSelectedElement();break;case v.HX:t.preventDefault(),this.activeSuggestion=0,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId,this.focusSelectedElement();break;default:return!0}return!0}focusSelectedElement(){this.selectedSuggestion.querySelectorAll("li").forEach(t=>{if(t.id===this.activeId){t.focus()}})}handleOnKeyDownAutoSuggestBox(t){switch(t.key){case v.HX:t.preventDefault(),this.searchSuggestions.length>0&&(this.activeSuggestion=(this.activeSuggestion+1)%this.searchSuggestions.length,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId);break;case v.I5:t.preventDefault(),this.searchSuggestions.length>0&&(this.activeSuggestion=(this.activeSuggestion+this.searchSuggestions.length-1)%this.searchSuggestions.length,this.activeId=this.searchSuggestions[this.activeSuggestion].quoteId);break;case v.gG:case v.Mm:if(t.preventDefault(),this.searchSuggestions.length>0){this.inputControl.value="",this.activeSuggestion=-1;this.selectedSuggestion.querySelectorAll("li").forEach(t=>{if(t.id===this.activeId){t.click()}})}break;case v.F9:t.preventDefault(),this.activeSuggestion=-1,this.inputControl.value="",this.$emit("action-text-input",this.inputControl.value);break;default:return}}getSuggestionClass(t,e,i){return t===this.activeId?i:e}}(0,g.Cg)([(0,m.CF)({attribute:"layout"})],x.prototype,"layout",void 0),(0,g.Cg)([f.sH],x.prototype,"moneyCardContentData",void 0),(0,g.Cg)([f.sH],x.prototype,"searchSuggestions",void 0),(0,g.Cg)([f.sH],x.prototype,"goBackTelemetryTag",void 0),(0,g.Cg)([f.sH],x.prototype,"addToWatchlistTelemetryTag",void 0),(0,g.Cg)([f.sH],x.prototype,"activeSuggestion",void 0),(0,g.Cg)([f.sH],x.prototype,"activeId",void 0);var $=i(96950),k=i(60402),P=i(69259),S=i(39957);const _=$.qy`<li id="${t=>t.quoteId}" tabindex="0" active=${(t,e)=>t.quoteId===e.parent.activeId||null} class="${(t,e)=>e.parent.getSuggestionClass(t.quoteId,"suggestion-entry","suggestion-entry-selected")}" part="${(t,e)=>e.parent.getSuggestionClass(t.quoteId,"suggestion-entry","suggestion-entry-selected")}" aria-label="${t=>t.longName} ${t=>t.exchangeName}" @click="${(t,e)=>e.parent.addToWatchlist(t.quoteId)}" data-t="${(t,e)=>e.parent.addToWatchlistTelemetryTag}"><div class="suggestion-item" part="suggestion-item"><div class="suggestion-company" part="suggestion-company"><span class="suggestion-symbol" part="suggestion-symbol">${t=>t.equitySymbol}</span><span class="suggestion-name" part="suggestion-name">${t=>t.longName}</span></div><div class="suggestion-market" part="suggestion-market"><span class="suggestion-market-str">${t=>t.exchangeName}</span></div><div class="suggestion-add-icon"><svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M17 9.53v.94h-6.53V17h-.94v-6.53H3v-.94h6.53V3h.94v6.53H17z" /></svg></div></div></li>`,A=$.qy`<div class="search-area" part="search-area"><div class="search-icon" part="search-icon"><svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 3a5.5 5.5 0 014.23 9.02l4.12 4.13a.5.5 0 01-.63.76l-.07-.06-4.13-4.12A5.5 5.5 0 118.5 3zm0 1a4.5 4.5 0 100 9 4.5 4.5 0 000-9z" /></svg></div><input class="search-input" part="search-input" type="search" autofocus="autofocus" @input=${t=>t.handleTextInput()} @keydown="${(t,e)=>t.handleOnKeyDownSearchBox(e.event)}" aria-label="${t=>{var e;return null===(e=t.moneyCardContentData)||void 0===e?void 0:e.searchPlaceholder}}" placeholder="${t=>{var e;return null===(e=t.moneyCardContentData)||void 0===e?void 0:e.searchPlaceholder}}" :value="${t=>t.value}" ${(0,k.K)("inputControl")} />${(0,P.z)(t=>{var e;return!0===(null===(e=t.moneyCardContentData)||void 0===e?void 0:e.showSuggestions)},$.qy`<ul class="suggestions-list" part="suggestions-list" tabindex="-1" @keydown="${(t,e)=>t.handleOnKeyDownAutoSuggestBox(e.event)}" ${(0,k.K)("selectedSuggestion")}>${(0,S.ux)((t,e)=>t.searchSuggestions,_)}</ul>`)} ${(0,P.z)(t=>{var e;return!0===(null===(e=t.moneyCardContentData)||void 0===e?void 0:e.noSuggestion)},$.qy`<div class="suggestions-list" part="suggestions-list"><div class="no-suggestion-str">${t=>{var e;return null===(e=t.moneyCardContentData)||void 0===e?void 0:e.noSuggestionHint}}</div></div>`)}</div>`,D=$.qy`<div class="title" part="title"><button class="title-button" part="title-button" @click="${t=>t.onTitleClicked()}" aria-label="${t=>{var e;return null===(e=t.moneyCardContentData)||void 0===e?void 0:e.goBackLabel}}" data-t="${t=>t.goBackTelemetryTag}"><span class="title-content">&lrm;${t=>{var e;return null===(e=t.moneyCardContentData)||void 0===e?void 0:e.titleContent}}</span></button></div>${A}
`;var R=i(74849),T=i(64187),I=i(22131),M=i(73477),O=i(61138),z=i(64003),B=i(48196),U=i(36452),F=i(48751),L=i(41123),E=i(45476),N=i(37998),q=i(7896),H=i(37302),W=i(86856),j=i(50882);const J=R.A` .suggestion-add-icon{padding-left:10px}`,G=R.A` .suggestion-add-icon{padding-right:10px}`,V=R.A`
        ${(0,T.V)("grid")} :host{box-sizing:border-box;position:relative;width:100%;outline:none;padding:12px 16px;height:100%;grid-template-rows:auto 1fr}:host([layout="full"]) .title{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:1fr auto;height:24px;margin-bottom:11px}:host([layout="half"]) .title{align-items:center;display:grid;grid-template-columns:1fr auto;grid-column-gap:8px;margin-bottom:8px;height:16px}.title-button{border:none;display:flex;font-size:${O.k};
            line-height: ${O.F};
            font-weight: 500;
            color: ${z.c};background-color:transparent;outline:none;cursor:pointer;padding:0px}.title-button:focus{text-decoration:underline}.title-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding-inline-end:12px}.search-area{display:grid;grid-template-columns:auto 1fr;height:calc(${B.D} * 1px);
            position: relative;
            border: 1px solid ${U.I2}}.search-icon{width:20px;padding:6px 10px}svg path{fill:${F.l}}.search-input{color:${F.l};
            background: transparent;
            font-size: ${L.K};
            line-height: ${L.Z};
            height: calc(${B.D} * 1px);border:none;outline:none}input[type="search"]::-webkit-search-decoration,input[type="search"]::-webkit-search-cancel-button,input[type="search"]::-webkit-search-results-button,input[type="search"]::-webkit-search-results-decoration{display:none}.suggestion-add-icon{padding-left:10px}.suggestions-list{margin:0px;display:block;position:absolute;box-sizing:border-box;top:40px;width:100%;padding:4px;background:${E.Wl};
            --elevation: 10;
            ${N.ET};z-index:9999;border:1px solid transparent}.no-suggestion-str{margin:3px 9px;font-size:${L.K};
            line-height: ${L.Z}}.suggestion-entry-selected{font-family:${q.O};
            outline: none;
            list-style: none;
            border: none;
            width: 258px;
            height: 47px;
            padding: 0px;
            background: ${H.Xt};text-decoration:none;cursor:pointer}.suggestion-entry{border:none;outline:none;list-style:none;width:258px;height:47px;padding:0px;background:${E.Wl};text-decoration:none;cursor:pointer}.suggestion-entry:hover .suggestion-item{background:${H.Xt}}.suggestion-entry,.search-input,.title-button{font-family:${q.O}}.suggestion-item{display:grid;grid-template-columns:140px 66px 32px;grid-column-gap:2px;height:40px;padding:5px 8px 2px 8px}.suggestion-company{display:grid;text-align:start;grid-template-rows:20px 20px}.suggestion-add-icon{padding-top:9px}.suggestion-symbol{display:block;font-weight:800;font-size:${L.K};
            line-height: ${L.Z};
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: ${F.l}}.suggestion-name{display:block;font-weight:600;font-size:${O.k};
            line-height: ${O.F};
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: ${F.l}}.suggestion-market{display:flex;position:relative;padding-top:8px}.suggestion-market-str{position:absolute;right:0px;font-weight:600;text-align:end;font-size:${O.k};
            line-height: ${O.F};
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: ${F.l};
        }
    `.withBehaviors(new W.t(J,G),(0,I.mr)(R.A` :host{forced-color-adjust:auto}svg path{fill:${j.A.ButtonText};
            }
            .suggestion-entry:hover .suggestion-item,
            .suggestion-entry:${M.N} .suggestion-item{forced-color-adjust:none;background:${j.A.Highlight};
            }
            .suggestion-entry:hover .suggestion-item *,
            .suggestion-entry:hover .suggestion-item svg path,
            .suggestion-entry:${M.N} .suggestion-item *,
            .suggestion-entry:${M.N} .suggestion-item svg path{color:${j.A.HighlightText};
                fill: currentcolor;
            }
        `)),K=x.compose({name:`${d.i.prefix}-add-watchlist-money-card`,template:D,styles:V});var X,Q,Z=i(93866),Y=i(16038),tt=i(47879),et=i(54147),it=i(60569),rt=i(22272),ot=i(12680),st=i(11297),at=i(3180);!function(t){t.AutosEntityList="AutosEntityList",t.AutosCarousel="AutosCarousel"}(X||(X={})),function(t){t.AnaheimNtpFeeds="anaheim-ntp-feeds",t.MSNArticle="articles-startshop-feeds",t.MSNHomePage="hponeservicefeed"}(Q||(Q={}));var nt=i(22341),lt=i(93552),dt=i(58792),ct=i(27233),ht=i(31756),pt=i(10526),ut=i(34230);const gt='{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-us/autos/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';async function mt(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:Q.AnaheimNtpFeeds,i=arguments.length>2?arguments[2]:void 0,r=arguments.length>3?arguments[3]:void 0;const o=function(t){switch(t){case Q.AnaheimNtpFeeds:return"0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM";case Q.MSNArticle:return"TUvfxJjXdl3YnnSTtb4nTd6OHIbDUzhvcgJt26A7Bi";case Q.MSNHomePage:return"0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM";default:return""}}(e),s=new URL(`https://assets.msn.com/service/news/feed/segments/autosMarketplace?apikey=${o}&ocid=${e}`),a=2===await(0,pt.XK)()?ht.WR.getOneServiceParamsWithAuth((0,dt.rA)().UserId,e):ht.WR.getOneServiceParamsWithoutAuth((0,dt.rA)().UserId,e),n=new Set(["apikey","ocid"]);var l;r&&a.push({key:"contentId",value:r}),(l=a)&&l.forEach(t=>{t.value&&!n.has(t.key)&&s.searchParams.set(t.key,t.value)});let d=await(0,ut.w)(()=>fetch(s.href),"GetAutosEntityList"),c=3;if(!d.ok&&!t)return"{}";if(!d.ok&&t)switch(dt.T3.CurrentMarket){case ct.DX.ENUS:return gt;case ct.DX.ENCA:return'{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-ca/autos/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';case ct.DX.ENGB:return'{"nearbyCarAmount":0,"autosEntity":[{"detail":{"year":2023,"make":"Jaguar","model":"F-Pace","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.65f505fb6865b9112c766ce40155bd08&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_jaguar_f-pace"},"price":{"msrpMin":52400.0,"msrpMax":89500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Land Rover Range Rover","model":"Velar","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.2bb79feed84214c559f20a482cec2f88&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_land_rover_range_rover_velar"},"price":{"msrpMin":60300.0,"msrpMax":79200.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"GMC Sierra","model":"3500HD","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c974679b75d407cfa6f15727d948446c&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_gmc_sierra_3500hd"},"price":{"msrpMin":42400.0,"msrpMax":67000.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Kia","model":"Stinger","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.379988643129a6dc8586257b1305ec3d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_kia_stinger"},"price":{"msrpMin":36590.0,"msrpMax":53990.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2023,"make":"Cadillac","model":"XT5","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.8e0637e0b9bca752d8e3b7d4d08da268&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2023_cadillac_xt5"},"price":{"msrpMin":44195.0,"msrpMax":57095.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron GT","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_90ba088e5e8a578890ac33cf6f154e7d&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_e-tron_gt"},"price":{"msrpMin":99900.0,"msrpMax":107100.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"e-tron","mileage":0,"imageUrl":"https://bing.com/th?id=AMMS_14daf24bcc8c32b3fbb3045c9dfba16a&w=50&h=50&c=7&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_e-tron"},"price":{"msrpMin":65900.0,"msrpMax":83400.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"BMW","model":"2 Series","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.c64885f1c53ce791803f2cb4ff91bac5&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_bmw_2_series"},"price":{"msrpMin":35700.0,"msrpMax":48500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Audi","model":"A6","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.5e8ffabc17231ebd3d163baf8b0a0666&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_audi_a6"},"price":{"msrpMin":55900.0,"msrpMax":69500.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Subaru","model":"Ascent","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.774c97f4faccd16b2721b47b74430b46&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_subaru_ascent"},"price":{"msrpMin":32795.0,"msrpMax":45945.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Ford","model":"Bronco 2-Door","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.3376596ea1c3a9d39d6b568cacbc0e22&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_ford_bronco_2-door"},"price":{"msrpMin":31300.0,"msrpMax":49780.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0},{"detail":{"year":2022,"make":"Kia","model":"Carnival","mileage":0,"imageUrl":"https://bing.com/th?id=OAID.270d54a3f3149fb3ee7a05e0267e2e47&w=50&h=50&c=2&rs=1&qlt=80&cdv=1&pid=16.1&w=400&h=316","detailPageUrl":"https://www.msn.com/en-gb/cars/marketplace/v/2022_kia_carnival"},"price":{"msrpMin":32300.0,"msrpMax":46300.0,"originalPrice":0.0},"nearbyAmount":84,"hasPriceDrop":false,"hasAccident":false,"isPopular":false,"geoDistance":0.0,"daysOnMarketCount":0}],"cardTitle":"Recommended cars for sale"}';default:return gt}for(;c>0&&200!==(null===(h=d)||void 0===h?void 0:h.status);){var h;try{d=await(0,ut.w)(()=>fetch(s.href),"GetAutosEntityList")}catch(t){(0,nt.c_)(Error("Response Fetch Error"),lt.uqN,"send request to segments api failed")}c--}if(!d.ok)throw new Error(d.statusText);const p=await d.json();let u=p&&p[0]&&p[0].data;if(i&&p.length>0){const t=p.filter(t=>t.type==i);u=t&&t[0]&&t[0].data}return u}var ft,vt=i(15938),yt=i(15148),Ct=i(67911),bt=i(91043),wt=i(17918),xt=i(3065),$t=i(89167),kt=i(2499),Pt=i(19256),St=i(94288);!function(t){t.casualGamesCard="casual-games-card",t.casualGamesStripeCarouselCard="casual-games-stripe-carousel-card",t.contentCard="content-card",t.contentCardPreview1x="content-card-preview-1x",t.denseCard="dense-card",t.displayAdCard="display-ad-card",t.infopaneCard="infopane-card",t.infopaneSlideCard="infopane-slide-card",t.moneyInfoCardWC="money-info-card",t.healthArticlesCardWC="health-articles-card",t.nativeAdCard="native-ad-card",t.placeholderCard="placeholder-card",t.pollsCard="polls-card",t.shoppingCarouselCard="shopping-carousel-card",t.shoppingVideoCarousel="shopping-video-carousel-card",t.superappUpsellCard="superapp-upsell-card",t.trendingNowCard="trending-now-card",t.weatherCard="weather-card",t.webContentCard="web-content-card",t.videoCard="video-card",t.travelDestinationCard="travel-destination"}(ft||(ft={}));var _t=i(27160);const At={[_t.pL.Article]:ft.contentCard,[_t.pL.CasualGamesStripeCarousel]:ft.casualGamesStripeCarouselCard,[_t.pL.EsportsCasualGames]:ft.casualGamesCard,[_t.pL.Slideshow]:ft.contentCard,[_t.pL.ExternalLink]:ft.contentCard,[_t.pL.Video]:ft.contentCard,[_t.pL.WebContent]:ft.contentCard,[_t.pL.Infopane]:ft.infopaneCard,[_t.pL.ShoppingCarousel]:ft.shoppingCarouselCard,[_t.pL.Dense]:ft.denseCard,[_t.pL.TrendingInTenMinutes]:ft.trendingNowCard,[_t.pL.NativeAd]:ft.nativeAdCard};var Dt=i(33477);const Rt=R.A`

:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
    grid-auto-rows: 150px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),Tt={cardCount:4,rowHeightPx:{C4:[150,150],C3:[150,150],C2:[150,150]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y,C1:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y,C1:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y,C1:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y,C1:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:Rt},It=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
  
`.withBehaviors(),Mt={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:It},Ot=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot6"
        "slot1 slot2 slot4 slot6"
        "slot1 slot2 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),zt={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:Ot},Bt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot6"
        "slot1 slot2 slot4 slot7"
        "slot1 slot2 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Ut={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:Bt},Ft=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot6"
        "slot1 slot3 slot5 slot6"
        "slot1 slot4 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Lt={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:Ft},Et=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot6"
        "slot1 slot3 slot5 slot7"
        "slot1 slot4 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Nt={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:Et},qt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot8"
        "slot1 slot3 slot6 slot8"
        "slot1 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Ht={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:qt},Wt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot10"
        "slot2 slot5 slot8 slot10"
        "slot3 slot6 slot9 slot10";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),jt={cardCount:10,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot9",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot10",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:Wt},Jt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot5 slot8"
        "slot1 slot3 slot6 slot9"
        "slot1 slot4 slot7 slot10";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot10"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),Gt={cardCount:10,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot9",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot10",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:Jt},Vt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),Kt={cardCount:3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y}},{grid_area:"slot3",layouts:{C4:Dt.uE._2x_3y,C3:Dt.uE._2x_3y,C2:Dt.uE._2x_3y}}],styles:Vt},Xt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot3"
        "slot1 slot2 slot3 slot3 slot3"
        "slot1 slot2 slot3 slot3 slot3";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),Qt={cardCount:3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y}},{grid_area:"slot3",layouts:{C4:Dt.uE._3x_3y,C3:Dt.uE._3x_3y,C2:Dt.uE._3x_3y}}],styles:Xt},Zt=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot2 slot2 slot2"
        "slot1 slot2 slot2 slot2"
        "slot1 slot2 slot2 slot2";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}
`.withBehaviors(),Yt={cardCount:2,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y,C1:Dt.uE._1x_3y}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y,C1:Dt.uE._1x_3y}}],styles:Zt},te=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot5";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),ee={cardCount:5,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._2x_3y,C3:Dt.uE._2x_3y,C2:Dt.uE._2x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:te},ie=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot6"
        "slot1 slot1 slot2 slot4 slot6"
        "slot1 slot1 slot2 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),re={cardCount:6,cardSlots:[{grid_area:"slot1",layouts:{C5:Dt.uE._2x_3y,C4:Dt.uE._2x_3y,C3:Dt.uE._2x_3y,C2:Dt.uE._2x_3y}},{grid_area:"slot2",layouts:{C5:Dt.uE._1x_3y,C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y}},{grid_area:"slot3",layouts:{C5:Dt.uE._1x_1y,C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y}},{grid_area:"slot4",layouts:{C5:Dt.uE._1x_1y,C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y}},{grid_area:"slot5",layouts:{C5:Dt.uE._1x_1y,C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y}},{grid_area:"slot6",layouts:{C5:Dt.uE._1x_3y,C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y}}],styles:ie},oe=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5"
        "slot1 slot1 slot3 slot6"
        "slot1 slot1 slot4 slot7";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),se={cardCount:7,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._2x_3y,C3:Dt.uE._2x_3y,C2:Dt.uE._2x_3y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:oe},ae=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot8"
        "slot1 slot1 slot3 slot6 slot8"
        "slot1 slot1 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),ne={cardCount:8,cardSlots:[{grid_area:"slot1",layouts:{C5:Dt.uE._2x_3y,C4:Dt.uE._2x_3y,C3:Dt.uE._2x_3y,C2:Dt.uE._2x_3y}},{grid_area:"slot2",layouts:{C5:Dt.uE._1x_1y,C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y}},{grid_area:"slot3",layouts:{C5:Dt.uE._1x_1y,C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y}},{grid_area:"slot4",layouts:{C5:Dt.uE._1x_1y,C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y}},{grid_area:"slot5",layouts:{C5:Dt.uE._1x_1y,C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y}},{grid_area:"slot6",layouts:{C5:Dt.uE._1x_1y,C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y}},{grid_area:"slot7",layouts:{C5:Dt.uE._1x_1y,C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y}},{grid_area:"slot8",layouts:{C5:Dt.uE._1x_3y,C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y}}],styles:ae};var le=i(88635);const de=R.A`
:host,
:host(.stripe-river-section) {
    grid-template-areas: 
        "slot1 slot1 slot1 slot2"
        "slot1 slot1 slot1 slot2";
    grid-auto-rows: 150px;
    grid-auto-columns: 306px;
    gap: 0 16px;
}

${(0,le.H5)(le.j1.c3)} {
    :host,
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1 slot2"
            "slot1 slot1 slot2";
    };
}

${(0,le.H5)(le.j1.c2)} {
    :host,
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot2"
            "slot1 slot2";
    }
}
`.withBehaviors(),ce={cardCount:2,rowHeightPx:{C4:[150,150],C3:[150,150],C2:[150,150]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._3x_2y,C3:Dt.uE._2x_2y,C2:Dt.uE._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_2y,C3:Dt.uE._1x_2y,C2:Dt.uE._1x_2y},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[1,2]}}],styles:de},he=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 300px;
    gap: 0 12px;
    margin-right: var(--stripe-river-section-margin-right,24px) !important;
    margin-left: var(--stripe-river-section-margin-left,16px) !important;
}
${(0,le.H5)(le.j1.c3)} {
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1 slot1"
            "slot1 slot1 slot1"
            "slot1 slot1 slot1";
    };
}

${(0,le.H5)(le.j1.c2)} {
    :host(.stripe-river-section) {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot1 slot1";
    }
}
`.withBehaviors(),pe={cardCount:1,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._4x_2y,C3:Dt.uE._3x_2y,C2:Dt.uE._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}}],styles:he},ue=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 300px;
    gap: 0 12px;
    margin-right: var(--stripe-river-section-margin-right,24px) !important;
    margin-left: var(--stripe-river-section-margin-left,16px) !important;
}
`.withBehaviors(),ge={cardCount:1,cardSlots:[{grid_area:"slot1",layouts:{C5:Dt.uE._5x_2y,C4:Dt.uE._4x_2y,C3:Dt.uE._3x_2y,C2:Dt.uE._2x_2y}}],styles:ue},me=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot6"
        "slot2 slot4 slot5 slot6"
        "slot3 slot4 slot5 slot6";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),fe={cardCount:6,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:me},ve=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot6"
        "slot2 slot4 slot5 slot7"
        "slot3 slot4 slot5 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),ye={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:ve},Ce=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot5 slot8"
        "slot2 slot4 slot6 slot8"
        "slot3 slot4 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
    
:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot7"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),be={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:Ce},we=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot8"
        "slot2 slot5 slot7 slot8"
        "slot3 slot6 slot7 slot8";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
    
:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),xe={cardCount:8,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_3y,C3:Dt.uE._1x_3y,C2:Dt.uE._1x_3y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}}],styles:we},$e=R.A`
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot4 slot7 slot10"
        "slot2 slot5 slot8 slot11"
        "slot3 slot6 slot9 slot12";
    grid-auto-rows: 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 0px 16px;
}

:host fluent-card[style^="grid-area:slot1"],
:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot4"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot7"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot10"],
:host fluent-card[style^="grid-area:slot11"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host fluent-card[style^="grid-area:slot2"],
:host fluent-card[style^="grid-area:slot3"],
:host fluent-card[style^="grid-area:slot5"],
:host fluent-card[style^="grid-area:slot6"],
:host fluent-card[style^="grid-area:slot8"],
:host fluent-card[style^="grid-area:slot9"],
:host fluent-card[style^="grid-area:slot11"],
:host fluent-card[style^="grid-area:slot12"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot1"],
:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot4"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot7"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot10"],
:host cs-responsive-card[style^="grid-area:slot11"] {
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;
}

:host cs-responsive-card[style^="grid-area:slot2"],
:host cs-responsive-card[style^="grid-area:slot3"],
:host cs-responsive-card[style^="grid-area:slot5"],
:host cs-responsive-card[style^="grid-area:slot6"],
:host cs-responsive-card[style^="grid-area:slot8"],
:host cs-responsive-card[style^="grid-area:slot9"],
:host cs-responsive-card[style^="grid-area:slot11"],
:host cs-responsive-card[style^="grid-area:slot12"] {
    border-top-right-radius: 0;
    border-top-left-radius: 0;
}
`.withBehaviors(),ke={cardCount:12,rowHeightPx:{C4:[100,100,100],C3:[100,100,100],C2:[100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,1],C3:[2,1],C2:[2,1]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,2],C3:[2,2],C2:[2,2]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,3]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,3],C3:[2,3],C2:[2,3]}},{grid_area:"slot9",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[3,3]}},{grid_area:"slot10",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[1,4],C3:[1,4],C2:[1,4]}},{grid_area:"slot11",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[2,4],C3:[2,4],C2:[2,4]}},{grid_area:"slot12",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},telemetryRowCol:{C4:[3,4],C3:[3,4],C2:[3,4]}}],styles:$e},Pe=R.A`
:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot6 slot7"
        "slot1 slot1 slot11 slot7"
        "slot2 slot3 slot12 slot7"
        "slot4 slot5 slot13 slot7";
    grid-auto-rows: 256px 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 16px;
}

:host([layout="C4"]) fluent-card[style^="grid-area:slot8"],
:host([layout="C4"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C4"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot6"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot8"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot13"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot3"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot5"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot9"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot8"],
:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C4"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot6"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot8"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot13"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot3"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot5"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot9"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot13"] {
    display: none;
}
    
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot7"
        "slot1 slot1 slot7"
        "slot2 slot3 slot7"
        "slot4 slot5 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot6 slot7"
        "slot2 slot7"
        "slot4 slot7"
        "slot8 slot7";
    grid-auto-rows: 256px 100px 256px 100px 100px 100px;
}
`.withBehaviors(),Se={cardCount:13,rowHeightPx:{C4:[256,100,100,100],C3:[256,100,100,100],C2:[256,100,256,100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._2x_2y,C3:Dt.uE._2x_2y,C2:Dt.uE._2x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:2},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[4,1]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:3},telemetryRowCol:{C4:[3,2],C3:[3,2]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:4},telemetryRowCol:{C4:[4,1],C3:[4,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:5},telemetryRowCol:{C4:[4,2],C3:[4,2]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:6},telemetryRowCol:{C4:[1,3],C2:[3,1]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_4y,C3:Dt.uE._1x_4y,C2:Dt.uE._1x_4y},cardDomOrder:{C3:7},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:8},telemetryRowCol:{C2:[6,1]}},{grid_area:"slot9",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:9}},{grid_area:"slot10",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:10}},{grid_area:"slot11",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:11},telemetryRowCol:{C4:[2,3]}},{grid_area:"slot12",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:12},telemetryRowCol:{C4:[3,3]}},{grid_area:"slot13",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:13},telemetryRowCol:{C4:[4,3]}}],styles:Pe},_e=R.A`
:host,
:host(.stripe-river-section) {
    grid-template-areas:
        "slot1 slot1 slot6 slot7"
        "slot1 slot1 slot11 slot8"
        "slot2 slot3 slot12 slot9"
        "slot4 slot5 slot13 slot10";
    grid-auto-rows: 256px 100px 100px 100px;
    grid-auto-columns: 306px;
    gap: 16px;
}

:host([layout="C3"]) fluent-card[style^="grid-area:slot6"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C3"]) fluent-card[style^="grid-area:slot13"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot10"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot11"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot12"],
:host([layout="C2"]) fluent-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot6"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C3"]) cs-responsive-card[style^="grid-area:slot13"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot10"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot11"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot12"],
:host([layout="C2"]) cs-responsive-card[style^="grid-area:slot13"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot7"
        "slot1 slot1 slot8"
        "slot2 slot3 slot9"
        "slot4 slot5 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot6 slot7"
        "slot2 slot3"
        "slot4 slot5"
        "slot8 slot9";
    grid-auto-rows: 256px 100px 256px 100px 100px 100px;
}
`.withBehaviors(),Ae={"msn-home-page-river-section-1111":Tt,"msn-home-page-river-section-1113":Mt,"msn-home-page-river-section-1131":zt,"msn-home-page-river-section-1133":Ut,"msn-home-page-river-section-1311":Lt,"msn-home-page-river-section-1313":Nt,"msn-home-page-river-section-1331":Ht,"msn-home-page-river-section-1333":Gt,"msn-home-page-river-section-3331":jt,"msn-home-page-river-section-1W13":ee,"msn-home-page-river-section-1W131":re,"msn-home-page-river-section-1WWW":pe,"msn-home-page-river-section-1WWWW":ge,"msn-home-page-river-section-1WW1":ce,"msn-home-page-river-section-1W33":se,"msn-home-page-river-section-1W331":ne,"msn-home-page-river-section-3111":fe,"msn-home-page-river-section-3113":ye,"msn-home-page-river-section-3131":be,"msn-home-page-river-section-3333":ke,"msn-home-page-river-section-3311":xe,"msn-home-page-river-section-111W":Kt,"msn-home-page-river-section-111WW":Qt,"msn-home-page-river-section-11WW":Yt,"msn-home-page-top-stripe-view-no-segment":{cardCount:13,rowHeightPx:{C4:[256,100,100,100],C3:[256,100,100,100],C2:[256,100,256,100,100,100]},colWidthPx:Dt.KF,gutterPx:Dt.R3,cardSlots:[{grid_area:"slot1",layouts:{C4:Dt.uE._2x_2y,C3:Dt.uE._2x_2y,C2:Dt.uE._2x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:2},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[4,1]}},{grid_area:"slot3",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:3},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[4,2]}},{grid_area:"slot4",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:4},telemetryRowCol:{C4:[4,1],C3:[4,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:5},telemetryRowCol:{C4:[4,2],C3:[4,2],C2:[5,2]}},{grid_area:"slot6",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:6},telemetryRowCol:{C4:[1,3],C2:[3,1]}},{grid_area:"slot7",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:7},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2]}},{grid_area:"slot8",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:8},telemetryRowCol:{C4:[2,4],C3:[2,3],C2:[6,1]}},{grid_area:"slot9",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:9},telemetryRowCol:{C4:[3,4],C3:[3,3],C2:[6,2]}},{grid_area:"slot10",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:10},telemetryRowCol:{C4:[4,4],C3:[4,3]}},{grid_area:"slot11",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:11},telemetryRowCol:{C4:[2,3]}},{grid_area:"slot12",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:12},telemetryRowCol:{C4:[3,3]}},{grid_area:"slot13",layouts:{C4:Dt.uE._1x_1y,C3:Dt.uE._1x_1y,C2:Dt.uE._1x_1y},cardDomOrder:{C3:13},telemetryRowCol:{C4:[4,3]}}],styles:_e},"msn-home-page-top-stripe-view-big-forth-col-no-segment":Se};var De=i(18442),Re=i(67111),Te=i(7642),Ie=i(12097),Me=i(28929),Oe=i(55619),ze=i(36467),Be=i(73526),Ue=i(16841),Fe=i(66736),Le=i(49662),Ee=i(8974),Ne=i(52938),qe=i(15523),He=i(71041),We=i(47209),je=i(87514),Je=i(69488),Ge=i(78986),Ve=i(41298),Ke=i(70536),Xe=i(99278),Qe=i(57503),Ze=i(30758),Ye=i(76844),ti=i(28803),ei=i(8401),ii=i(11045),ri=i(11991),oi=i(8100),si=i(37088),ai=i(97873),ni=i(97331),li=i(65055);const di=$.qy`
<fluent-card
    id="health-articles-card"
    style="grid-area:${t=>t.gridArea};border-radius:6px"
    class="${t=>t.cardSize}"
>
    ${t=>t.healthArticlesConfigInfo&&(0,li.yN)(t.healthArticlesConfigInfo,{includeTelemetryTag:!1,properties:{parentTelemetryObject:t.parentTelemetryObject,telObjectBase:t.parentTelemetryObject,healthArticleData:t.healthArticleData,refreshSDCardSection:t.refreshSDCardSection,sdCardActionClickHandler:t.sdCardActionClickHandler,refreshFeed:t.refreshFeed,cardSize:t.cardSize},events:{goToPersonalizeSettingsCallback:t.goToPersonalizeSettingsCallback}})}

</fluent-card>
`;var ci=i(96951),hi=i(35639),pi=i(7074);function ui(t){try{var e;const{configOptions:i,parentTelemetryObject:r,cardMetadata:o,refreshSDCardSection:s,sdCardActionClickHandler:a,refreshFeedCallback:n,goToPersonalizeSettingsCallback:l}=t,d=i&&i,c={id:"healthArticlesCard",childTemplateType:"health-articles-card",parentTelemetryObject:r,telObjectBase:r,healthArticlesConfigInfo:d,healthArticleData:o&&o.data&&function(t){let e=null;if(!t)return e;const i=JSON.parse(t);if(!i)return e;let r=[],o=[];if(i.items)for(let t=0;t<i.items.length;t++)i.items[t].imageUrl&&r.push(i.items[t]);if(i.randomItems)for(let t=0;t<i.randomItems.length;t++)o.push(i.randomItems[t]);r=vi(r),o=vi(o),(r.length>0||o.length>0)&&(e=[]);for(let t=0;t<r.length&&t<2;t++)e.push(mi(r[t]));for(let t=0;t<o.length&&e.length<4;t++)e.push(fi(o[t]));return e}(o.data),sdCardActionClickHandler:a,refreshFeed:s||n,goToPersonalizeSettingsCallback:l,refreshSDCardSection:s};return(0,hi.bw)({id:"healthArticlesCard",experienceType:null==d||null===(e=d.configRef)||void 0===e?void 0:e.experienceType,mapperArgs:t},c)}catch(e){(0,nt.vV)(ci.NZ,`Error in feed layout: ${e}, mapperargs = ${JSON.stringify(t)}`)}return null}function gi(t){try{if(!t)throw new Error(`Invalid color string = ${t}`);const e=null==t?void 0:t.substr(1),i=parseInt(null==e?void 0:e.substr(0,2),16),r=parseInt(null==e?void 0:e.substr(2,2),16),o=parseInt(null==e?void 0:e.substr(4,2),16);if(!(0,pi.A)(i)||!(0,pi.A)(r)||!(0,pi.A)(o))throw new Error(`Could not extract color from = ${t}`);return`${i}, ${r}, ${o}`}catch(t){return"58, 52, 45"}}function mi(t){return{title:t.title,clickUrl:t.url,mainImageUrl:t.imageUrl,brandLogoUrl:t.additionalAttributes.find(t=>"ProviderLogo"==t.key).value,brandName:t.additionalAttributes.find(t=>"ProviderName"==t.key).value,gradientColor:gi(t.additionalAttributes.find(t=>"DarkModeColor"==t.key).value),category:"recommendation"}}function fi(t){return{title:t.title,clickUrl:t.url,mainImageUrl:t.imageUrl,brandLogoUrl:t.additionalAttributes.find(t=>"ProviderLogo"==t.key).value,brandName:t.additionalAttributes.find(t=>"ProviderName"==t.key).value,gradientColor:gi(t.additionalAttributes.find(t=>"DarkModeColor"==t.key).value),category:"suggestion"}}function vi(t){let e,i=t.length;for(;0!=i;)e=Math.floor(Math.random()*i),i--,[t[i],t[e]]=[t[e],t[i]];return t}const yi={getFeedDataForCard(t){return ui(t)},viewTemplate:di},Ci={"casual-games-card":Ge.H,"casual-games-stripe-carousel-card":Je.K,"content-card":Re.K,"content-card-preview-1x":Te.T,"infopane-card":oi.P,"infopane-slide-card":Ie.g,"dense-card":Oe.e,"display-ad-card":Be.s,"money-info-card":Fe.P,"health-articles-card":di,"native-ad-card":Ee.DO,"placeholder-card":qe.u,"polls-card":We.d,"shopping-carousel-card":Ve.j,"weather-card":ii.p,"web-content-card":Te.T,"video-card":ti.Q,"trending-now-card":Ze.A,"travel-destination-card":Xe.T,"responsive-card":ai.t},bi={[ft.casualGamesCard]:Ge.D,[ft.casualGamesStripeCarouselCard]:Je.O,[ft.contentCard]:ni.v,[ft.contentCardPreview1x]:ni.v,[ft.denseCard]:ze.o,[ft.infopaneCard]:si.V,[ft.infopaneSlideCard]:ni.v,[ft.displayAdCard]:Ue.E,[ft.moneyInfoCardWC]:Le.j,[ft.healthArticlesCardWC]:yi,[ft.nativeAdCard]:Ne.$,[ft.placeholderCard]:He.M,[ft.pollsCard]:je.N,[ft.shoppingCarouselCard]:Ke.f,[ft.trendingNowCard]:Ye.Q,[ft.weatherCard]:ri.j,[ft.webContentCard]:Me.m,[ft.videoCard]:ei.O,[ft.travelDestinationCard]:Qe.t};var wi=i(50645),xi=i(74998),$i=i(90366),ki=i(38260),Pi=i(35290),Si=i(49305),_i=i(61804),Ai=i(77367),Di=i(85349),Ri=i(90905);const Ti=(t,e)=>{const i=t.split(" ");let r=e;const o=()=>{var t,e,s,a;const n=i.shift();return r=(null===(t=r)||void 0===t||null===(t=t.shadowRoot)||void 0===t||null===(e=t.querySelector)||void 0===e?void 0:e.call(t,n))||(null===(s=r)||void 0===s||null===(a=s.querySelector)||void 0===a?void 0:a.call(s,n)),i.length&&r?o():r};return o()},Ii=(t,e)=>{const i=(null==t?void 0:t.shadowRoot)||t;if(!i||i.querySelector("style.stripe-style"))return;const r=document.createElement("style");r.className="stripe-style",Object.keys(e).forEach(t=>{r.innerHTML+=`${t} { ${e[t]} }\n`}),i.prepend(r)},Mi=(t,e)=>{const i=document.createElement("style");i.innerHTML=e,t.prepend(i)};var Oi=i(87440),zi=i(63456),Bi=i(29307),Ui=i(99476);const Fi=600,Li="local",Ei="promotions",Ni="fromOurPartners",qi="bannerAd",Hi="quizCardWC",Wi={"ar-ae":"BBlFCyr","ar-eg":"BBlmAAj","ar-sa":"BBlFPtc","bn-in":"BBU7Qw4","da-dk":"BBlrVvd","de-at":"BBlROe9","de-ch":"BBZ1dPy","de-de":"BB19Lup4","el-gr":"BBlpx0F","en-ae":"BBlFzXn","en-au":"BB12Wlad","en-ca":"BB15zxqh","en-gb":"BB131KqR","en-ie":"BBlSybW","en-in":"BBlJDWj","en-my":"BBnmzKF","en-nz":"BBloYCJ","en-ph":"BBpkImc","en-sg":"BBnkfV1","en-xl":"BBJLSPs","en-za":"BBlq660","es-ar":"BBnlJDa","es-cl":"BBlrlMA","es-co":"BBloOIy","es-es":"BB12XBRm","es-mx":"BBu6hpo","es-pe":"BBlqzW8","es-us":"BBlsKCT","es-ve":"BBloH3J","es-xl":"BBlsFUm","fi-fi":"BBltzSJ","fr-be":"BBltAia","fr-ca":"BBHSUQ1","fr-ch":"BBm7onJ","fr-fr":"BB1fEVKT","he-il":"BBlrTD9","hi-in":"BBH8j5q","id-id":"BBqRsFe","it-it":"BB1334rQ","ja-jp":"CChcKo","ko-kr":"AAfBokA","mr-in":"AAEnx4n","nb-no":"BBlG6uP","nl-be":"BBltzP7","nl-nl":"BBlpya4","pl-pl":"BBls505","pt-br":"BBlrUUd","pt-pt":"AAg0WfA","sv-se":"BBlu2g8","te-in":"AAEns3L","th-th":"BBot3Jh","tr-tr":"BBlppGp","vi-vn":"BBov02b","zh-cn":"AAFsW17","zh-hk":"BBlBHZI"};function ji(t,e,i,r,o,s,a){if(!a)return;const n=t.indexOf(a);if(-1===n)return;const l=new Date,d=l.getDay(),c="#"+Math.trunc(l.getHours()).toString()+"#";if(r){d>=1&&d<=5&&r.includes(c)||(o=-1)}if(i&&d>=1&&d<=5&&i.includes(c)&&(o=1),!(null==o||o<0||o>=t.length||o>=e.length))if("1"===s)for(let i=o;i<n;i++){const r=e[i],{cardProviderConfig:o}=r||{},{initialRequest:s}=o||{},{feedId:a,_:l}=s||{};if(a===qi||a===Ei||a===Ni);else{const r=t[i];t[i]=t[n],t[n]=r;const o=e[i];e[i]=e[n],e[n]=o}}else if("2"===s){const i=t[o];t[o]=t[n],t[n]=i;const r=e[o];e[o]=e[n],e[n]=r}else{const i=t.splice(n,1)[0];t.splice(o,0,i);const r=e.splice(n,1)[0];e.splice(o,0,r)}}function Ji(t,e){var i;return null===(i=t.personalizedStripeConfig)||void 0===i?void 0:i[e]}var Gi=i(68264),Vi=i(36297),Ki=i(13790),Xi=i(4332);const Qi=(0,Ki.wg)("debugalert");class Zi{static getServiceUrl(t,e,i){const r=(0,Xi.e3)()?new URL(this.baseUrlForBot):new URL(this.baseUrl),o=new Vi.m;return o.set(dt.T3.OneServiceContentMarketQspKey,e),o.set("ocid","health-verthp-feeds"),o.set("apikey","FywQv6H345wNCU4yKWraF2esI9qiMQFx90v53mMHrm"),o.set("$top","20"),null!==dt.T3&&void 0!==dt.T3&&dt.T3.UserId&&o.set("user",dt.T3.UserId),dt.T3.ShouldUseFdheadQsp&&o.set("fdhead","prg-wpo-healthcs"),o.set("noCache","true"),o.set("$select",t),!1===i&&o.set("ranid",`${Math.random().toString().replace("0.","")}`),r.search=o.toString(),r.href}static async getDataFromOneService(t,e,i){try{if(!e)throw new Error("Null or empty market");if("1"===Qi)throw new Error("this is a test alert");const r={method:"GET",headers:{accept:"application/json"}};let o="en";e&&5===e.length&&(o=e.substr(0,2));const s=this.getServiceUrl(t,e,i),a=await(0,ut.w)(async()=>{const t=await fetch(s,r);if(!t)throw Error(`Null response. Url = ${s}`);if(!t.ok)throw Error(`Status:${t.status} Url = ${s}`);return t.json()},"getContentFromOneService");if(!(a&&a.length&&a[0]&&a[0].data))throw new Error(`Null, empty or invalid response Json. Url = ${s}`);return JSON.parse(a[0].data)}catch(t){let e;throw"object"==typeof t?e=t.message:"string"==typeof t&&(e=t),new Error(`Error in one service call. ${e}`)}}}Zi.baseUrl="https://api.msn.com/news/feed/segments/health",Zi.baseUrlForBot="https://assets.msn.com/service/news/feed/segments/health";var Yi=i(40315),tr=i(26220),er=i(68989),ir=i(94043);const rr=(()=>{if((0,ir.S)())return window.fetch.bind(window);{const t=800;return(e,i)=>(0,er.hv)(e,t,i)}})();class or{async getUserPreferences(){const t=dt.T3.CurrentMarket||"en-us",e=dt.T3.UserId,i=`/api/v1/getpref/${e}?market=${t}`;let r;try{if(r=await rr(this.getFalconServiceUrl("userpreferencefetcher","bing-shopping",i),this.getFalconRequestInit("GET")),!r||!r.ok)return[];const t=await r.json();if(!t||!t.orderedVerticals)return[];const e=t&&t.orderedVerticals&&{orderedVerticals:t.orderedVerticals.map(t=>({...t,name:t.name}))};return e.orderedVerticals.map(t=>t.name)}catch(t){return(0,nt.c_)(t,lt.QyC,"Error fetching user preference data",`usermuid: ${e}`),[]}}getFalconServiceUrl(t,e,i){let r;return r=(0,tr.ou)().startsWith("localhost.msn.com")?`https://${t}.${e}.microsoft-testing-falcon.io`:`https://services.bingapis.com/${e}.${t}`,r+i}getFalconRequestInit(t){return{method:t}}}const sr=R.A`
.stripe-slider-container{left:-52px}`,ar=R.A`
.title-arrow{-moz-transform:scale(-1,1);-webkit-transform:scale(-1,1);-o-transform:scale(-1,1);-ms-transform:scale(-1,1);transform:scale(-1,1)}.stripe-slider-container{right:-52px}.scrollDownButtonContainerRight{right:inherit;left:25px}`,nr=R.A`
:host{--border-color:#e6e6e6;--heading-font-size:14px;--heading-font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;--heading-line-height:20px;--heading-start-padding:8px;--abstract-start-padding:8px;--dense-card-hero-width:300px;--dense-card-news-list-width:263px;--dense-list-item-height:39px;--dense-list-item-title-opacity:1;--dense-list-item-title-line-height:19px;--dense-card-new-layout1-margin-top:2px;--dense-card-new-layout1-width:280px;--dense-card-new-layout1-margin:0 11px;--dense-new-layout1-list-item-height:36px;--dense-new-layout1-list-item-max-width:261px;--dense-new-layout1-list-item-font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;--dense-new-layout1-list-item-font-size:15px;--fill-color:#fff;--heading-max-lines:2}.stripe-feed{height:100%;padding:0px 0px 60px;box-sizing:border-box}.river-section{margin-bottom:8px;display:flex;flex-flow:column;position:relative}.progress-ring-wrapper{display:flex;justify-content:center}.river-section-header-group{align-items:baseline;border-top:2px solid var(--border-color,#e6e6e6);display:flex;width:100%}.river-section-footer-group{align-items:baseline;display:flex;justify-content:space-between;width:100%}.stripe-title{padding-top:5px}.stripe-title h2{font-size:20px;font-weight:600;margin-top:unset;margin-bottom:20px;white-space:nowrap;display:inline-flex;align-items:center}msft-ad-label{min-width:32px;height:13px;margin-right:8px}.stripe-title h2 a{border-bottom:none;color:${F.l};position:relative;text-decoration:none}.stripe-title h2 a:hover{text-decoration:underline}.stripe-title h2 a span{position:absolute;top:.29rem}.stripe-title svg path{stroke:currentColor;stroke-width:1px}.sub-nav{display:grid;grid-template-columns:minmax(0,1fr);margin-inline-start:33px;writing-mode:horizontal-tb}.see-more{min-width:max-content;margin-top:5px;position:absolute;right:0;bottom:-4px}.see-more a{color:#0070c9;font-size:12px;font-weight:600;letter-spacing:0.64px;font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;text-decoration:none}.in-stripe-banner-ad{width:auto;height:auto;display:flex;justify-content:center;overflow:hidden}.pagination-sentinel{position:absolute;bottom:0;left:0;right:0;z-index:-1;height:200px}.stripe-slider-container{box-sizing:border-box;width:calc(100% + 106px);padding:0px 50px 0px}.stripe-slider-container.more-space{padding-bottom:16px}.stripe-slider-container-rail{padding-right:49px !important;padding-left:49px !important}.stripe-river-section{margin-right:3px}cs-feed-layout:part(heading){font-family:var(--heading-font-family)}msft-ad-label{--ad-label-fill-green:#1E6525;--ad-label-color-white:#FFF}msft-ad-label::part(control){box-sizing:border-box;display:inline-block;border-radius:2px;border-color:transparent;vertical-align:bottom}#liveshopping{display:none}#secondaryStripe{margin-top:-12px}`.withBehaviors(new W.t(sr,ar),(0,I.G2)(R.A` :host{--fill-color:#2b2b2b}`)),lr="\n:host{--heading-start-padding:16px;--heading-max-lines:2;--heading-line-height:28px}",dr=' fluent-card,fluent-card msn-info-pane{position:relative}fluent-card .placeholder-card{animation:placeholder-animation 1s linear infinite;background-image:linear-gradient(90deg,#fafafa 0%,white 50%,#fafafa 100%);background-size:100px 100%;background-color:#fafafa;background-repeat:no-repeat;background-position:-50%}fluent-card msn-info-pane::part(previous-flipper),fluent-card msn-info-pane::part(next-flipper){opacity:1}@keyframes placeholder-animation{to{background-position:150%}}:host([data-section="finance"]) fluent-card[class="full"]:nth-of-type(1){background:none}:host([data-section="weather"]) fluent-card money-info-card::part(money-card),:host([data-section="tools"]) fluent-card money-info-card::part(money-card),:host([data-section="finance"]) fluent-card money-info-card::part(money-card){height:100%;width:100%;border-radius:4px;display:flex;justify-content:center}:host(cs-feed-layout[data-section="liveshopping"]){width:1271px;margin-right:0px !important;margin-left:0px !important}:host([data-section="partners"]) fluent-card msft-content-card img[slot="media"],:host([data-section="promotions"]) fluent-card msft-content-card img[slot="media"]{width:306px;height:200px;object-fit:cover}#displayAdCard{--elevation:4;display:flex;justify-content:center;height:var(--card-height,100%);width:var(--card-width,100%);padding-top:3px;box-sizing:border-box;background:var(--fill-color);border-radius:calc(var(--layer-corner-radius) * 1px);box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(0.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(0.13 * (2 - var(--background-luminance,1))))}.info-pane-slide-title{-webkit-line-clamp:2 !important}',cr=" @media (prefers-color-scheme:dark){fluent-card .placeholder-card{background:#2b2b2b !important}}",hr=' .next-arrow,.previous-arrow{height:45px;width:45px}.next::part(next),.previous::part(previous){height:45px;width:45px}.next-arrow:before,.previous-arrow:before{content:"";opacity:0;position:absolute;inset:0px;transition:all 0.1s ease-in-out 0s}',pr="\n.msft-horizontal-card-slider{box-sizing:border-box;width:calc(100% + 100px);padding:0px 50px}.msft-horizontal-card-slider::part(arrow-container){padding:5px 10px}.msft-horizontal-card-slider::part(container){gap:0;display:flex;flex-flow:row;transition:transform 1s ease-in-out}";var ur=i(41065);const gr={topStripe:{name:"today.Hero",action:Di.EG.View,behavior:Di.MS.Show,type:Di.MJ.Section},secondaryStripe:{name:"today.Hero.standaloneEP",action:Di.EG.View,behavior:Di.MS.Show,type:Di.MJ.Section},headlineItemViewModel:{name:"HeadlineItemViewModel",action:Di.EG.View,behavior:Di.MS.Show,type:Di.MJ.Headline},todayHeadlines:{name:"todayHeadlines",action:Di.EG.View,behavior:Di.MS.Show,type:Di.MJ.Headline},todayStripeHeadlines:{name:"todayStripeHeadlines",action:Di.EG.View,behavior:Di.MS.Show,type:Di.MJ.Headline},title:{name:"title",action:Di.EG.Click,behavior:Di.MS.Navigate,type:Di.MJ.NavBar},seeMore:{name:"seeMore",action:Di.EG.Click,behavior:Di.MS.Navigate}};class mr{getSectionTelemetryTag(t,e){return t in gr?this.getTelemetryTag(gr[t]):this.getTelemetryTag({name:e||`stripe.${t}`,action:Di.EG.View,behavior:Di.MS.Show,type:Di.MJ.Section})}getTelemetryTag(t){return(0,ur.N)(t.name,t.behavior,t.action,t.type).getMetadataTag()}}var fr=i(39671),vr=i(81583),yr=i(15474),Cr=i(69242),br=i(37725);const wr=(t,e)=>{const i=e.findIndex(t=>(0,br.RD)((0,br.qK)(t)));if(-1!==i){const t=[...e],r=t[i];return t.splice(i,1),t.unshift(r),{backfillMetadata:t,backfillTemplateId:void 0,backfillCardTypeSlot:void 0}}return{backfillMetadata:e,backfillTemplateId:null==t?void 0:t.templateId,backfillCardTypeSlot:[]}},xr=new Map([["video",wr],["video_stripe",wr]]),$r=(t,e,i)=>{const r={backfillMetadata:void 0,backfillTemplateId:void 0,backfillCardTypeSlot:void 0};try{const o=xr.get(t);return o&&i?o(i,e):r}catch{return r}};var kr=i(10809);const Pr=(0,Ui.a)().get("vptest"),Sr=(0,vt.ZF)(),_r="AdServiceCall.StripeWC",Ar="inserted-card";function Dr(t){return`stripewc.${t}`}class Rr extends fr.U{constructor(){super(...arguments),this.isFetchingStripes=!1,this.riverSectionLayoutData=[],this.ttvrFired=!1,this.isFeedExhausted=!1,this.enableRail=!1,this.visualReadinessCallbackSet=!1,this.appliedStyles=[],this.defaultLoadCount=2,this.infopaneSubItems=[],this.loadedWebComponents=[],this.nativeAdPlacementsMap={},this.pollsData={poll:{fallbackToContentCard:!1,fetchingTriggered:!1,isFetching:!1,data:null},quiz:{fallbackToContentCard:!1,fetchingTriggered:!1,isFetching:!1,data:null}},this.autosData={fallbackToContentCard:!1,data:null,enableStaticResponse:!1},this.riverSectionIndex=0,this.riverSectionResponses={},this.retryCountRecord={},this.nativeAdIsLoaded={},this.nativeAdIndiceRegionFilters=[],this.ttvrLogInfo={topStripeStartAt:[],topStripeFetchedAt:[],topStripeRetryAt:[],topStripeRenderedAt:void 0,topStripeAdsReadyAt:void 0,aboveThefoldReadyAt:void 0,ttvrFiredAt:void 0,ttvrBoundedImage:[]},this.hasSectionInterest={},this.dynamicRankingInterests=[],this.dynamicInterestsFetched=!1,this.shoppingCarouselData={data:[],fallbackToContentCard:!1},this.replacementInfopaneCards={},this.shouldOverrideInfopaneCards=!1,this.customInsertedCards={},this.overrideHasSlideShow=!1,this.dependencies=new Set,this.onBreakpointCallback=t=>{this.columnArrangement=t.toUpperCase(),window.setTimeout(()=>{this.updateShowDot(),this.updateStripes()})},this.initCardAction=t=>{var e,i,r;this.cardActionRef||(this.cardActionRef=null===(i=(r=this.shadowRoot).querySelector)||void 0===i?void 0:i.call(r,"card-action"));null===(e=this.cardActionRef)||void 0===e||e.updateCardActionProps({...t})},this.getVisualReadinessCallback=(t,e,i)=>{var r;const o=e===ft.infopaneCard?ft.infopaneCard:null==t||null===(r=t.cardContent)||void 0===r?void 0:r.id,s=this.riverSectionIds[0];return this.getSectionAdPlacementIndices(s).includes(i)||this.dependencies.add(o),()=>{this.dependencies.has(o)&&this.dependencies.delete(o),0===this.dependencies.size&&this.setVisuallyReadyMarkers()}},this.getSectionAdPlacementIndices=t=>{var e,i;const r=[...(null===(e=this.config)||void 0===e||null===(e=e.adPlacements)||void 0===e||null===(e=e[t])||void 0===e?void 0:e.placements)||[],...(null===(i=this.config)||void 0===i||null===(i=i.cmsAdPlacements)||void 0===i||null===(i=i[t])||void 0===i?void 0:i.placements)||[]],o=[];return r.forEach(t=>{var e;t.region!==_t.pL.Infopane&&null!==(e=t.indices)&&void 0!==e&&e.length&&o.push(...t.indices)}),o},this.setVisuallyReadyMarkers=()=>{this.ttvrFired||(this.ttvrFired=!0,(0,yt.D)(()=>{this.markVisuallyReady(),this.ttvrLogInfo.ttvrFiredAt=performance.now(),this.config.enableBulkFetch?this.updateStripes():this.updateStripes(this.riverSectionIds[this.riverSectionLayoutData.findIndex(t=>void 0!==t)]),this.initTopStripeNativeAds().then(()=>{var t;const e=(0,Pi.Kl)();e&&(null===Si.m||void 0===Si.m||null===(t=Si.m.updateVisuallyReadyTiming)||void 0===t||null===(t=t.getActionSender(e))||void 0===t||t.send((0,Pi.ez)(ot.p_1,void 0,void 0,void 0,window.performance.now())))})}))},this.setPaginationObserver=()=>{"IntersectionObserver"in window&&this.paginationSentinelRef&&(this.sentinelObserver=new IntersectionObserver(this.onSentinelChange),window.requestAnimationFrame(()=>{this.sentinelObserver.observe(this.paginationSentinelRef)}))},this.onSentinelChange=t=>{if(!t||t.length<1||!this.ttvrFired)return;t[0].isIntersecting&&this.onUserPaginate()},this.onUserPaginate=()=>{this.riverSectionIndex<this.riverSections.length?this.fetchStripes(this.config.lazyLoadCount):this.isFeedExhausted=!0},this.isPaginationVisible=()=>{if(!this.paginationSentinelRef)return!1;const{y:t,height:e}=this.paginationSentinelRef.getBoundingClientRect();return t-e<Math.max(document.documentElement.clientHeight,window.innerHeight)},this.processLayoutStyles=()=>{const{stripeStyles:t={}}=this.config;Object.keys(t).forEach(e=>{if(!this.appliedStyles.includes(e)){const i=((t,e,i)=>{const r=Ti(t,i);return Ii(r,e),r})(e,t[e],this);i&&this.appliedStyles.push(e)}})},this.onDisplayAdHeightChange=t=>{const{htmlId:e,height:i}=(null==t?void 0:t.detail)||{};if(null!=e&&e.startsWith("rectangle1")&&i&&!this.enableRail){const{longDisplayAdLayoutTemplate:t}=this.config,e=this.riverSectionIds[0];if(!t)return;this.riverSectionLayoutData[0].templateId=i===Fi?t:this.riverSections[0].riverSectionTemplate,this.updateStripes(e)}}}isFeedExhaustedChanged(t,e){var i,r,o;if(!e)return;null===(i=this.sentinelObserver)||void 0===i||i.disconnect();const s=(null===(r=this.config)||void 0===r||null===(r=r.cardProviderConfig)||void 0===r||null===(r=r.initialRequest)||void 0===r?void 0:r.count)||30;null===(o=this.onFeedEndCb)||void 0===o||o.call(this,{cardCount:s})}async enableRailChanged(t){var e;if("boolean"!=typeof t||!this.config)return;await new Promise(t=>window.setTimeout(t));const{longDisplayAdLayoutTemplate:i}=this.config;this.enableRail&&i&&(null===(e=this.riverSectionLayoutData[0])||void 0===e?void 0:e.templateId)===i&&(this.riverSectionLayoutData[0].templateId=this.riverSections[0].riverSectionTemplate,this.updateStripes(this.riverSectionIds[0]))}async experienceConnected(){var t,e;this.stripeWCTelemetry||(this.stripeWCTelemetry=new mr),await kr.D.initConfig(),(0,et.registerCSResponsiveCard)(),(0,it.C8)(),rt.T.define(n.G.registry),this.initRiverSectionAndId(),Pr&&(this.riverSectionIds.forEach(t=>(0,Ct.cX)(Dr(t))),(0,Ct.gR)().then(()=>{Object.assign(Sr,{vpready:performance.now()}),performance.mark("vpready")})),this.initFeedLayoutData(),this.topStripeCardProvider=new _i.f(this.config.cardProviderConfig),this.config.paginationSentinelHeight&&(this.sentinelHeight=`height: ${this.config.paginationSentinelHeight}px;`);const{nativeAdIndiceRegionFilters:i=[]}=this.config;if(this.nativeAdIndiceRegionFilters=i.map(t=>t.toLowerCase()),this.fetchStripes(this.config.initialLoadCount),null!==(t=this.config.buyDirectInfopaneCard)&&void 0!==t&&t.primaryServiceClientSettings&&null!==(e=this.config.buyDirectInfopaneCard)&&void 0!==e&&e.shoppingCarouselAPISettings)try{this.shoppingPrimaryServiceClient=this.shoppingPrimaryServiceClient||new Yi.J(window.fetch.bind(window),this.config.buyDirectInfopaneCard.primaryServiceClientSettings,this.config.buyDirectInfopaneCard.shoppingCarouselAPISettings,null,location.href)}catch(t){Ai.YT.sendAppErrorEvent({...lt.PxO,message:"Failed to initialize buy direct infopane service client",pb:{...lt.PxO.pb,customMessage:`Failed with exception : ${JSON.stringify(t)}`}})}}async initFinanceUserService(){try{const e={experienceType:ot.ahW,instanceSrc:"default"};if(this.moneyInfoCardWCConfig=(await wi.L.getConfig(e)).properties,!this.financeUserService){var t;const{FinanceServices:e,getFinanceDataConnector:r}=await Promise.all([i.e("node_modules_crypto-js_index_js"),i.e("libs_finance-service-library_dist_common_FinanceRoute_js"),i.e("experiences_spotlight-card-wc_dist_ContentTemplates_DailyQuiz_DailyQuizCard_styles_js-libs_fi-fbe3c0")]).then(i.bind(i,36915));r().config.enableUnsignedWatchlist=null===(t=this.moneyInfoCardWCConfig)||void 0===t?void 0:t.enableUnsignedWatchlist,this.financeUserService=e.getFinanceUserService(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)}}catch(t){(0,nt.vV)(lt.yIP,`Failed to initialize finance services: ${t.message}`)}}async initBuyDirectUserService(){try{const t={experienceType:ot.Yeu,instanceSrc:"index_Buydirect"};this.buyDirectConfig=(await wi.L.getConfig(t)).properties,this.buyDirectServiceClient||(this.buyDirectServiceClient=new Yi.J(window.fetch.bind(window),this.buyDirectConfig.primaryServiceClientSettings,this.buyDirectConfig.shoppingCarouselAPISettings,null,location.href))}catch(t){(0,nt.vV)(lt.$oH,`Failed to initialize buy direct services: ${t.message}`)}}async initUserPreferenceFetcherService(){try{this.userPreferenceFetcherService||(this.userPreferenceFetcherService=new or)}catch(t){(0,nt.vV)(lt.QyC,`Failed to initialize user reference service: ${t.message}`)}}initRiverSectionAndId(){if(this.config.stripePlacementOverwrite){const t=new Set(this.config.stripePlacementOverwrite);Object.entries(this.config.childExperienceReferencesWC).forEach(e=>{let[i,{hide:r}]=e;r||t.has(i)||Ai.YT.sendAppErrorEvent({...lt.nlb,message:"stripe key from childExperienceReferencesWC does not exist in stripePlacementOverwrite",pb:{...lt.nlb.pb,customMessage:`stripe key: ${i}`}})});const e=[];for(const t of this.config.stripePlacementOverwrite){const i=this.config.childExperienceReferencesWC[t];i?i.hide||e.push(t):Ai.YT.sendAppErrorEvent({...lt.nlb,message:"stripe key from stripePlacementOverwrite does not exist in childExperienceReferencesWC",pb:{...lt.nlb.pb,customMessage:`stripe key: ${t}`}})}this.riverSectionIds=e}else{const t=[];Object.keys(this.config.childExperienceReferencesWC).forEach(e=>{this.config.childExperienceReferencesWC[e].hide||t.push(e)}),this.riverSectionIds=t}const t=this.config.riverSectionCardProviderConfig;this.riverSections=this.riverSectionIds.map(e=>{const i=this.config.childExperienceReferencesWC[e];return{...i,riverCardProvider:new _i.f((0,Oi.A)({},t,i.cardProviderConfig))}})}getExperienceType(){return ot.p_1}shadowDomPopulated(){this.columnArrangement=(0,xt.TU)().currentColumnArrangement.toUpperCase(),(0,xt.TU)().subscribe(this.onBreakpointCallback),this.updateShowDot(),window.addEventListener("stripeFeedDisplayAdHeight",this.onDisplayAdHeightChange),this.config&&this.config.adCookieSyncConfig&&this.config.adCookieSyncConfig.isCookieSyncEnabled&&(this.cookieSyncService=new Gi.n(this.config.adCookieSyncConfig||{}),this.cookieSyncService.processCookieSync()),this.setPaginationObserver()}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("stripeFeedDisplayAdHeight",this.onDisplayAdHeightChange)}updateShowDot(){const t=this.getDisplayedColumnLayout();this.isShowDot=["C2","C3"].includes(t)||"C4"===t&&this.config.isC5Enabled}async refreshFeed(){this.riverSections.forEach(t=>{let{riverCardProvider:e}=t;return e.clearCache()}),this.nativeAdPlacementsMap={},this.riverSectionIndex=0,this.initFeedLayoutData(),this.fetchStripes(this.config.initialLoadCount)}initFeedLayoutData(){this.riverSectionLayoutData=new Array(this.riverSectionIds.length).fill(void 0)}async fetchStripes(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:this.defaultLoadCount;if(this.isFetchingStripes)return;let e=0;this.isFetchingStripes=!0;const i=()=>{this.isFetchingStripes=!1,(this.isPaginationVisible()||this.config.enableBulkFetch)&&this.riverSectionIndex<this.riverSections.length&&this.fetchStripes(this.config.lazyLoadCount),this.riverSectionIndex>=this.riverSections.length&&(bt.M.singleMark("StripeWC-FullPageLoaded"),this.isFeedExhausted=!0)},r=Ji(this.config,"finance"),o=Ji(this.config,"buydirect"),s=Ji(this.config,"dynamicStripe"),a=[];if((null!=r&&r.moveStripePosition||null!=r&&r.personalizeInsertCard)&&a.push(this.fetchFinanceInterests()),null!=s&&s.enabled&&a.push(this.fetchDynamicInterests()),await Promise.all(a),null!=s&&s.runBeforeFinanceRanking&&this.updateDynamicSectionRanking(s),null!=s&&s.skipFinanceRanking&&0!=this.dynamicRankingInterests.length||this.updateFinanceSectionRanking(r),null!=s&&s.runBeforeFinanceRanking||this.updateDynamicSectionRanking(s),null!=o&&o.moveStripePosition&&(await this.initBuyDirectUserService(),this.buyDirectServiceClient&&(null==this.hasSectionInterest.buydirect&&await this.updateUserBuyDirectInterest(),this.hasSectionInterest.buydirect>0&&(ji(this.riverSectionIds,this.riverSections,void 0,void 0,o.newStripePositionIndex,"1","buydirect"),Ai.YT.addOrUpdateTmplString("BuyDirectStripeMovedToTop")))),this.riverSectionIndex>0&&this.config.enableBulkFetch){const e=[],r=this.riverSectionIndex;for(let i=r;i<Math.min(this.riverSections.length,r+t);i++){const t=this.riverSectionIds[i],r=this.riverSections[i],{feedId:o,count:s}=r.cardProviderConfig.initialRequest;o===qi||o===Ei||o===Ni?e.push(new Promise(t=>t(void 0))):o===Li?e.push(this.fetchLocalNewsRiverContent(s)):e.push(this.fetchRiverContent(t,r))}Promise.all(e).then(async e=>{for(let i=r;i<Math.min(this.riverSections.length,r+t);i++){const t=this.riverSectionIds[i];this.riverSectionResponses[t]=e[i-r],await this.fetchStripe(this.riverSectionIndex++)}this.isFetchingStripes=!1}).catch(async t=>{console.error(t)}).finally(()=>{i()})}else{const r=async()=>{if(this.riverSectionIndex<this.riverSections.length&&e<t){try{await this.fetchStripe(this.riverSectionIndex++),this.riverSectionLayoutData[this.riverSectionIndex-1]&&e++}catch(t){console.error(t)}!this.ttvrFired&&this.riverSectionLayoutData[this.riverSectionIndex-1]?((0,Pi.Qc)().then(async()=>{this.ttvrLogInfo.aboveThefoldReadyAt=performance.now(),this.ttvrFired||(this.setVisuallyReadyMarkers(),Ai.YT.sendAppErrorEvent({...lt.HR1,message:"TTVR is blocked due to the first image is not available.",pb:{...lt.HR1.pb,customMessage:JSON.stringify(this.ttvrLogInfo)}}))}),await(0,wt.dT)(),await r()):await r()}};await r(),i()}}async fetchFinanceInterests(){await this.initFinanceUserService(),this.financeUserService&&(null!=this.hasSectionInterest.finance&&null!=this.hasSectionInterest.casualGames||await this.updateUserFinanceInterest())}async fetchDynamicInterests(){await this.initUserPreferenceFetcherService(),this.userPreferenceFetcherService&&(this.dynamicInterestsFetched||this.updateDynamicRankingInterests())}updateFinanceSectionRanking(t){null!=t&&t.moveStripePosition&&this.hasSectionInterest.finance>t.financeInterestScore&&ji(this.riverSectionIds,this.riverSections,t.moveStripeToTopHours,t.moveStripeToIndexHours,t.newStripePositionIndex,t.adsLocStrategy,"finance")}updateDynamicSectionRanking(t){if(this.dynamicRankingInterests.length>0){let e=t.newStripePositionIndex;for(let i=0;i<this.dynamicRankingInterests.length;i++){const r=this.dynamicRankingInterests[i];ji(this.riverSectionIds,this.riverSections,void 0,void 0,e,t.adsLocStrategy,r),-1!=this.riverSectionIds.indexOf(r)&&(e=this.riverSectionIds.indexOf(r)+1)}}}async getWeatherData(t){const e={};e.requestInfo={isStaleRefresh:t};const{PageBase:r}=await i.e("RubyFeedbackCoachMark").then(i.bind(i,28186));this.weatherDataConnector=await r.getInstance().rootReducer.getDataConnector(st.ni),this.weatherDataConnector&&(this.activeLocation=await this.weatherDataConnector.fetchActiveStateforWeather(null,null,e))}async fetchAutosData(t){try{const e=await mt(this.autosData.enableStaticResponse,Q.MSNHomePage);e.includes("Listing")?(this.autosData.data=e,this.updateStripes(t)):this.autosData.fallbackToContentCard=!0}catch(t){this.autosData.fallbackToContentCard=!0,(0,nt.c_)(t,lt.uqN,"send request to segments api failed")}}async fetchStripe(t){const e=this.riverSections[t],i=this.riverSectionIds[t],{feedId:r,count:o}=e.cardProviderConfig.initialRequest;let s,a=!1,n=[];if(0===t&&this.ttvrLogInfo.topStripeStartAt.push(performance.now()),this.hasMoneyInfoCardWC(i)&&!this.loadedWebComponents.includes[ft.moneyInfoCardWC]?this.fetchMoneyInfoCardData(i):this.hashealthArticleInfoCardWC(i)&&!this.loadedWebComponents.includes[ft.healthArticlesCardWC]?this.fetchHealthInfoCardData(i):this.hasTravelDestinationCardWC(i)&&!this.loadedWebComponents.includes[ft.travelDestinationCard]&&this.fetchTravelDestinationCardData(i),r===qi)n=Array(o).fill({type:_t.pL.Article});else if(r===Ei||r===Ni){var l;n=this.createStripeAdCardDefaultMetadata(o),null!==(l=this.config.cmsAdPlacements)&&void 0!==l&&l[i]&&this.loadNativeAd(i,!0),this.loadNativeAd(i),a=!0}else if(r===Li){await this.getWeatherData(),s=this.riverSectionResponses[i]||await this.fetchLocalNewsRiverContent(o);const t=xi.Rb.Locale;if(xi.Rb.ClientSettings.locale.market===this.activeLocation.isoCode.toLowerCase()){const{locality:i,displayName:r}=this.activeLocation;(0,zi.A)(s,"value[0].subCards[0].feed.feedName",i);e.riverSectionTitle=r,"es-ar"!=t&&(e.seeMoreUrl+="local"),n=s.subCards||[]}}else{var d;s=this.riverSectionResponses[i]||await this.fetchRiverContent(i,e),null!==(d=s)&&void 0!==d&&null!==(d=d.cardMetadata)&&void 0!==d&&d.length?(ht.WR.removeOcidFromRiverCardProviderResponse(s),n=s.cardMetadata,this.loadNativeAd(i),0===t&&this.ttvrLogInfo.topStripeFetchedAt.push(performance.now())):this.retryFetchingStripe(t),a=!0}this.addRiverSection(t,e,n,a)}async retryFetchingStripe(t){const e=this.config.retryTimeOutMs&&this.config.retryTimeOutMs>=0?this.config.retryTimeOutMs:1e3,i=this.config.maxRetryTimes&&this.config.maxRetryTimes>=0?this.config.maxRetryTimes:0,r=this.riverSectionIds[t];this.retryCountRecord[r]||(this.retryCountRecord[r]=0),this.retryCountRecord[r]>=i||(this.retryCountRecord[r]++,Ai.YT.sendAppErrorEvent({...lt.sOF,message:`Start retrying to fetch [${r}] in ${e}ms.`,pb:{...lt.sOF.pb,customMessage:`Retry count: ${this.retryCountRecord[r]}`}}),window.setTimeout(async()=>{0===t&&this.ttvrLogInfo.topStripeRetryAt.push(performance.now()),await this.fetchStripe(t),0===t&&await this.initTopStripeNativeAds()},e))}addRiverSection(t,e){var i,r,o,s,a;let n=!(arguments.length>3&&void 0!==arguments[3])||arguments[3];const l=(arguments.length>2&&void 0!==arguments[2]?arguments[2]:[]).filter(t=>{if(At[t.type])return t;Ai.YT.sendAppErrorEvent({...lt.vES,message:"Unsupported content card type in OneService metadata.",pb:{...lt.vES.pb,customMessage:`Card type [${t.type}] needs to be added to MSNHomepageOneServiceMetadataTypeToCardTypeMap`}})});if(null==l||!l.length)return;const d=this.riverSectionIds[t];let c=e.riverSectionTemplate,h=l,p=[];const{adPlacements:u={},cmsAdPlacements:g={},insertCardInSlot:m={}}=this.config,f=this.config.slotToCardType||{};let v=(0,Bi.A)(f[d])||[];const{backfillMetadata:y,backfillCardTypeSlot:C,backfillTemplateId:b}=$r(d,h,null===(i=this.config.childExperienceReferencesWC)||void 0===i||null===(i=i[d])||void 0===i?void 0:i.backfillConfigs);h=y||h,v=C||v,c=b||c;const w=Ae[c]||{},x=Ji(this.config,d);null!=x&&x.personalizeInsertCard&&this.hasSectionInterest[d]>0&&(m[d]=m[d].filter(t=>(null==t?void 0:t.cardType)!==x.cardToDisable));const $=[...(null===(r=u[d])||void 0===r?void 0:r.placements)||[],...(null===(o=g[d])||void 0===o?void 0:o.placements)||[]],k=[...v||[],...m[d]||[]];$.forEach(t=>{t&&t.region!==_t.pL.Infopane&&(null==t||t.indices.forEach(t=>{const e=t-1;p.includes(e)||p.push(e)}))});const P=[];k.forEach(t=>{var e,i;t&&(null==t?void 0:t.cardType)!==ft.contentCard&&(null==t?void 0:t.cardType)!==ft.videoCard&&(null==t?void 0:t.cardType)!==ft.pollsCard&&((null==t?void 0:t.cardType)!==ft.denseCard?null===(e=t.positions)||void 0===e||e.forEach(t=>{let e=parseInt(t.slot.replace("slot",""))-1;P.forEach(t=>{t.index<e&&(e+=t.count-1)}),p.includes(e)||p.push(e)}):null===(i=t.positions)||void 0===i||i.forEach(e=>{var i;const r=parseInt(e.slot.replace("slot",""))-1;P.push({index:r,count:(null===(i=t.args)||void 0===i?void 0:i.denseListSize)||0})}))}),p=p.sort((t,e)=>t>e?1:t<e?-1:0),p.forEach(t=>{const e=h.pop();h.splice(t,0,e)}),this.riverSectionLayoutData[t]={cardMetadataList:h,feedData:this.mapFeedData(d,h,w,this.config.openLinksInNewTab,this.telemetryObject,v,t),hasPlaceHolderAds:n,insertBannerAd:null==e?void 0:e.insertBannerAd,pivotsNav:null==e?void 0:e.pivotsNav,riverSectionTitle:null==e?void 0:e.riverSectionTitle,riverSectionTitleUrl:(0,$i.bI)(null!=e&&e.riverSectionTitleUrl?e.riverSectionTitleUrl:null==e?void 0:e.seeMoreUrl),riverSectionTitleColor:null==e?void 0:e.riverSectionTitleColor,seeMoreUrl:(0,$i.bI)(null==e?void 0:e.seeMoreUrl),seeMoreText:null==e?void 0:e.seeMoreText,adLabel:null==e?void 0:e.adLabel,sectionId:d,telemetryName:null==e?void 0:e.telemetryName,templateId:c,adSlugGA:this.config.adSlugGA,isMsnHPAdSlug:this.config.isMsnHPAdSlug,enableSafeAds:!(null===(s=this.config)||void 0===s||!s.enableSafeAds),disableSlider:this.config.disableStripeSlider,leftArrow:this.config.localizedStrings.previousArrow,rightArrow:this.config.localizedStrings.nextArrow,disableStripeTheme:this.config.disableStripeTheme,isC5Enabled:this.config.isC5Enabled,isDVEnabled:null===(a=this.config)||void 0===a?void 0:a.isDVEnabled},0===t&&((0,wt.yi)(`${this.getExperienceType()}TopStripeRendered`),this.ttvrLogInfo.topStripeRenderedAt=performance.now()),"shopping"===d&&this.config.overrideBingUrlsAugmentations&&(this.riverSectionLayoutData[t].riverSectionTitleUrl=$t.dN.updateUrlIfBingShopping(this.riverSectionLayoutData[t].riverSectionTitleUrl,"msn"),this.riverSectionLayoutData[t].seeMoreUrl=$t.dN.updateUrlIfBingShopping(this.riverSectionLayoutData[t].seeMoreUrl,"msn")),this.riverSectionLayoutData=[...this.riverSectionLayoutData]}async addFlipperStyles(){const t=await(e="msft-horizontal-card-slider",i=this.shadowRoot,new Promise(t=>{const r=(0,Ri.A)(()=>{t(i.querySelectorAll(e)),o.disconnect()}),o=new MutationObserver(r);o.observe(i,{childList:!0,subtree:!0})}));var e,i;if(null!=t&&t.length&&t[0].shadowRoot)for(let e=0;e<t.length-1;e++)Mi(t[e].shadowRoot,hr)}async fetchRiverContent(t,e){var i;let r;const o=this.riverSectionIds[0];let s="";t===o&&(s=` TTVR log: ${JSON.stringify(this.ttvrLogInfo)}`);try{if(t===o){var a;if(ki.WD&&e.enableWebWorker&&!this.config.disableWWForTopStripe){var n;const t=(null===(n=this.config)||void 0===n||null===(n=n.cardProviderConfig)||void 0===n||null===(n=n.initialRequest)||void 0===n?void 0:n.timeoutMs)||1e3;r=await e.riverCardProvider.fetchFromWebWorker("myfeed",t)}else window.enableEarlyRiverRequest&&window.topStripeResponse&&(window.enableEarlyRiverRequest=!1,r=window.topStripeResponse);null!==(a=r)&&void 0!==a&&null!==(a=a.cardMetadata)&&void 0!==a&&a.length||(r=await this.topStripeCardProvider.fetch())}else r=await e.riverCardProvider.fetch({})}catch(e){Ai.YT.sendAppErrorEvent({...lt.sOF,message:`Content fetch failed for Stripe WC river section when loading ${t}`,pb:{...lt.sOF.pb,customMessage:`Failed with exception : ${JSON.stringify(e)} ${s}`}})}if(null!==(i=r)&&void 0!==i&&null!==(i=i.cardMetadata)&&void 0!==i&&i.length){var l,d,c;if(t!==o&&(null===(l=r.cardMetadata[0])||void 0===l?void 0:l.type)===_t.pL.Infopane)r.cardMetadata=r.cardMetadata.filter(t=>t.type!==_t.pL.Infopane);else if(t===o&&(null===(d=r.cardMetadata[0])||void 0===d?void 0:d.type)===_t.pL.Infopane){var h;const t=null===(h=this.config.cardProviderConfig)||void 0===h||null===(h=h.initialRequest)||void 0===h?void 0:h.infopaneItemCount;t&&r.cardMetadata[0].subItems.length>t&&(r.cardMetadata[0].subItems=r.cardMetadata[0].subItems.slice(0,t))}"esports"===t&&(null===(c=r)||void 0===c||null===(c=c.cardMetadata)||void 0===c?void 0:c.length)<8&&Ai.YT.sendAppErrorEvent({...lt.nZM,message:`Content fetch content is less than 8 for Stripe WC river section when loading ${t}`,pb:{...lt.nZM.pb,customMessage:`Returned response: ${JSON.stringify(r)} ${s}`}})}else Ai.YT.sendAppErrorEvent({...lt.uIm,message:`Content fetch failed for invalid empty Stripe WC river section when loading ${t}`,pb:{...lt.uIm.pb,customMessage:`Returned response: ${JSON.stringify(r)} ${s}`}});return r}async fetchLocalNewsRiverContent(t){var e;let r,o;const{PageBase:s}=await i.e("RubyFeedbackCoachMark").then(i.bind(i,28186));this.weatherDataConnector=await s.getInstance().rootReducer.getDataConnector(st.ni);const a=this.weatherDataConnector.getCurrentState().currentLocation||this.activeLocation,{latitude:n,longitude:l}=a,d=`${n}|${l}`,{apikey:c}=this.config,{ocid:h}=this.config.riverSectionCardProviderConfig.initialRequest,p=dt.T3.CurrentMarket;o=`${dt.T3.AssetsUrl}/service/MSN/Feed/me?$top=${t}&cm=${p}&location=${d}&ocid=${h}&apikey=${c}&cipenabled=false&DisableTypeSerialization=true&query=localnews&queryType=myfeed&wrapodata=false&responseSchema=cardview`,this.has1SFlight("1s-viewurldomain")&&(o=`${o}&fdhead=1s-viewurldomain`);try{r=await fetch(o)}catch(t){Ai.YT.sendAppErrorEvent({...lt.sOF,message:"Content fetch failed for Local News River section.",pb:{...lt.sOF.pb,url:o,customMessage:`Failed with exception : ${JSON.stringify(t)}`}})}return null===(e=r)||void 0===e?void 0:e.json()}async fetchShoppingCarouselData(t){try{var e;null!==(e=this.shoppingCarouselData.data)&&void 0!==e&&e.length?this.updateStripes(t):this.shoppingCarouselData.fallbackToContentCard=!0}catch(t){this.shoppingCarouselData.fallbackToContentCard=!0}}async fetchShoppingCarouselBDData(t){const e=await t.getShoppingEntitiesDataUsing1S(!0,1e3);return e||null}async getBuyDirectCard(){var t,e,i,r;const o=await this.fetchShoppingCarouselBDData(this.shoppingPrimaryServiceClient);if(!o||!o.shoppingEntities||!o.shoppingEntities.length)return Ai.YT.sendAppErrorEvent({...lt.ca0,message:"No buy direct infopane card data from 1S.",pb:{...lt.ca0.pb,customMessage:"No buy direct infopane card data from 1S."}}),null;const s=o.shoppingEntities[0];if(!s.globalOfferId||!s.title||!s.imageInfo.sourceImageUrl)return Ai.YT.sendAppErrorEvent({...lt.ca0,message:"Invalid buy direct infopane card data data from 1S.",pb:{...lt.ca0.pb,customMessage:"Invalid buy direct infopane card data from 1S."}}),null;const a=this.config.buyDirectInfopaneCard.formcode,n=this.config.buyDirectInfopaneCard.trafsrc,l=this.config.bwmCampaignCode??"";let d=this.config.bdBlurredBackground?"InfoBuyDirectCard":"BuyDirectCard";d+=this.config.buyDirectEventDecoration?this.config.buyDirectEventDecoration:"",d+=this.config.disableBuyDirectCashback?"_NoCashback":"";const c=kt.u.buildAbsoluteUrl({market:dt.T3.CurrentMarket,pid:s.globalOfferId,title:s.title,trafsrc:n,ocid:n,formCode:a,isBing:this.config.bdDirectToBing,isBWM:this.config.isBWM,campaignCode:l}),h=null!==(t=s.cashbackInfo)&&void 0!==t&&t.cashbackPercentage&&(null===(e=s.cashbackInfo)||void 0===e?void 0:e.cashbackPercentage)>0?`${s.cashbackInfo.cashbackPercentage}%`:void 0;null!==(i=this.config)&&void 0!==i&&i.enableForumCashback&&!h&&Ai.YT.sendAppErrorEvent({...lt.LOQ,message:"Buy Direct stripe offer failed to fetch dynamic cashback",pb:{...lt.LOQ.pb,customMessage:"Empty cashback info"}});const p=(0,Pt.Yd)((0,Pt.Lm)()),u=h||p;let g=u?`Buy with Microsoft - ${u} Cash back and free shipping on all orders`:"Buy with Microsoft - Earn Cash back";g=this.config.disableBuyDirectCashback?"Buy with Microsoft - Free shipping on all orders":g;return{type:"link",cardContent:{abstract:g,destinationUrl:`${c}`,id:`${s.id}`,kicker:`${s.title}`,title:`${null!==(r=s.priceInfo)&&void 0!==r&&r.price?s.priceInfo.price+" ":""}${s.title}`,type:"link",category:{product:"news"},images:[{id:`${s.globalOfferId}`,url:`${s.imageInfo.sourceImageUrl}`}]},id:d}}getInfopaneCardOverride(t,e,i,r,o,s){return{type:"link",cardContent:{destinationUrl:r,title:o,type:"link",category:{product:"news"},images:[{url:(0,St.Je)(s,i,e)}]},id:t}}mapFeedData(t,e,i,r,o,s,a){if(!e||!e.length||!i)return null;const n={defaultLayout:[],C6:[],C5:[],C4:[],C3:[],C2:[],C1:[]},{rowHeightPx:l,colWidthPx:d,gutterPx:c,cardSlots:h=[]}=i,p=a>2?a-2:a-1,u="topStripe"===t?{C5:0,C4:0,C3:0,C2:0}:{C5:4+3*p,C4:4+3*p,C3:4+3*p,C2:6+3*p},g=this.columnArrangement.toLowerCase(),{slotToCardType:m={},insertCardInSlot:f={}}=this.config,v={...this.config.infopaneConfig||{}},y={};return f[t]&&f[t].forEach(i=>{let{cardType:r,positions:o,args:s}=i;const a=o.find(t=>!t.column||t.column===g);if(a){const i=h.findIndex(t=>t.grid_area===a.slot);if(y[a.slot]=r,i>-1){var n;const o={type:Ar,cardContent:{insertedCardType:r,insertedCardArgs:s},id:`${r}-slot-${i+1}`};if((null===(n=e[i])||void 0===n?void 0:n.id)===o.id)return;if(r===ft.pollsCard){const r=s.pollsCardConfigInfo.instanceId===Hi,a=r?this.pollsData.quiz:this.pollsData.poll;a.fallbackToContentCard||(a.fetchingTriggered?a.data&&(e[i]&&e.push(e[i]),e[i]=o):this.fetchQuizData(t,r))}else if(r===ft.denseCard){const{denseListSize:t,denseDataConfigOptions:r}=s,a=e.splice(i,t);null!=r&&r.enableDenseLayout1&&a.unshift(a[0]),o.subItems=a,e.splice(i,0,o)}else if(r===ft.shoppingCarouselCard){var l,d;const r=["index_LiveShopping_Shopping","index_LiveShopping_Lifestyle"];var c;if(r.includes(s.configOptions.configRef.instanceSrc)&&(null===(l=this.shoppingCarouselData)||void 0===l||!l.fallbackToContentCard))null!==(c=this.shoppingCarouselData.data)&&void 0!==c&&c.length?(e[i]&&e.push(e[i]),e[i]=o):this.fetchShoppingCarouselData(t);(null!==(d=this.shoppingCarouselData.data)&&void 0!==d&&d.length||!r.includes(s.configOptions.configRef.instanceSrc))&&(e[i]&&e.push(e[i]),e[i]=o)}else e[i]&&(e.push(e[i]),this.customInsertedCards[r]={metadataIndex:i,cardData:e[i],backupIndex:e.length-1}),e[i]=o}}else if(this.customInsertedCards[r]){const{metadataIndex:t,cardData:i,backupIndex:o}=this.customInsertedCards[r];e.splice(o,1),e[t]=i,this.customInsertedCards[r]=void 0}}),h.forEach((i,a)=>{var h,p,f,C,b,w,x,$;const k=e[a];if(!k)return;let P=(null===(h=k.cardContent)||void 0===h?void 0:h.insertedCardType)||At[k.type];const S=s||m[t],_=S?S.find(t=>{let{positions:e}=t;return e.some(t=>(!t.column||t.column&&t.column===g)&&t.slot===(null==i?void 0:i.grid_area))}):null;if(_&&(P=_.cardType),!P)return;const A=parseFloat(null==i||null===(p=i.grid_area)||void 0===p?void 0:p.replace("slot",""));let D=null;const R=()=>this.config.enableNewTTVR?this.getVisualReadinessCallback(k,P,A):this.setVisuallyReadyMarkers;if(!this.ttvrFired){const e=this.riverSectionIds[0];var T;if(t===e)if(this.visualReadinessCallbackSet&&!this.config.enableNewTTVR||P!==ft.infopaneCard){if((!this.visualReadinessCallbackSet||this.config.enableNewTTVR)&&P===ft.contentCard){this.visualReadinessCallbackSet=!0;const t=(0,De.Ie)(k);t&&(this.ttvrLogInfo.ttvrBoundedImage.push(`today hero content: ${t.url}`),D=R())}}else this.visualReadinessCallbackSet=!0,D=R(),k.subItems=k.subItems.map(t=>({...t,visualReadinessCallback:D})),this.ttvrLogInfo.ttvrBoundedImage.push(`today hero infopane: ${null===(T=k.subItems[0])||void 0===T||null===(T=T.cardContent)||void 0===T||null===(T=T.images[0])||void 0===T?void 0:T.url}`);else if(P===ft.contentCard){const t=(0,De.Ie)(k);t&&(this.ttvrLogInfo.ttvrBoundedImage.push(`river content: ${t.url}`),D=this.setVisuallyReadyMarkers)}}const I={...this.config,...this.config.childExperienceReferencesWC[t],isMsnHpExternalLinkCard:"link"===k.type},M=this.nativeAdPlacementsMap[t];var O;P!==ft.nativeAdCard&&P!==ft.infopaneCard||null==M||!M.length||(I.isGreyAdsLabelEnabled=null===(O=M[0])||void 0===O?void 0:O.isGreyAdsLabelEnabled);k.type===_t.pL.Infopane&&(I.useMsnHomepageCardTemplate=!0,this.ttvrFired||(v.disableAutoRotate=!0));const z=(null==k||null===(f=k.cardContent)||void 0===f||null===(f=f.insertedCardArgs)||void 0===f||null===(f=f.pollsCardConfigInfo)||void 0===f?void 0:f.instanceId)===Hi?this.pollsData.quiz:this.pollsData.poll;(!this.ttvrFired&&k.type===Ar||this.getSectionAdPlacementIndices(t).includes(A)&&!this.nativeAdIsLoaded[t]||y[null==i?void 0:i.grid_area]===ft.pollsCard&&z.isFetching)&&(P=ft.placeholderCard);const B=((null==k||null===(C=k.cardContent)||void 0===C?void 0:C.type)||(null==k?void 0:k.type))===_t.pL.WebContent;let U={cardMetadata:k,cardSlot:i,parentTelemetryObject:o,openLinksInNewTab:r||I.isMsnHpExternalLinkCard,openLinksInCurrentTab:!r&&!I.isMsnHpExternalLinkCard,isAnaheimDesign:!0,refreshFeedCallback:()=>this.refreshFeed(),visualReadinessCallback:D,localizedStrings:this.config.localizedStrings||{},isProviderInFooter:!0,hideComments:B,enableRichSocialReaction:!(null===(b=this.config.childExperienceReferences)||void 0===b||!b.socialBarWC),initCardAction:this.initCardAction,configOptions:{...I,disableOptedOutButton:!0,enableWCCardAction:!0,enableHoverCardAction:!(null===(w=this.config.childExperienceReferences)||void 0===w||!w.cardAction),useSmallFontSize:P!==ft.infopaneCard,isImage32:!0,useHomepageTelemetry:!0,enableWebContentSocialReactions:!0,socialBarInRight:!0,providerOnTop:!0,providerOnTopInfopane:!0,hideCommentsInHalfUCards:!0,disableSlideShow:!this.overrideHasSlideShow&&this.config.disableSlideShow},isIASEnabled:this.config.isIASEnabled,appendIdxForId:this.config.appendIdxForId,rowHeightPx:l,colWidthPx:d,gutterPx:c,rowCount:u};var F,L,E,N;if(null!==(x=k.cardContent)&&void 0!==x&&x.insertedCardArgs&&(U=(0,Oi.A)({},U,k.cardContent.insertedCardArgs)),_&&(U=(0,Oi.A)({},U,_.args)),U.configOptions.useInfopaneSlideTemplate&&(U.immersiveCard=!0),P===ft.infopaneCard)if(null!==(F=this.infopaneSubItems)&&void 0!==F&&F.length||null==k||null===(L=k.subItems)||void 0===L||!L.length||(this.infopaneSubItems=k.subItems.slice()),this.ttvrFired||(this.config.enableDenseSlide&&this.config.denseListSize?k.subItems=k.subItems.slice(0,this.config.denseListSize+1):k.subItems=k.subItems.slice(0,1)),U=(0,Oi.A)({},U,v),this.config.enableDenseSlide&&this.config.denseListSize){const t=this.config.denseCardCount||1,e=this.config.denseListSize+1,i=U.cardMetadata.subItems,r=[];for(let o=0;o<t;o++){const t=o*e,s=(o+1)*e,a={size:0,subItems:i.slice(t,s).map(t=>({...t,visualReadinessCallback:void 0})),type:"densetab",visualReadinessCallback:i&&i[0].visualReadinessCallback};a.subItems.length>0&&r.push(a)}i.splice(t*e).forEach(t=>{r.push(t)}),U.cardMetadata.subItems=r}else if(null!==(E=U.cardMetadata)&&void 0!==E&&null!==(E=E.subItems)&&void 0!==E&&E.length){const t=U.cardMetadata.subItems;U.cardMetadata.subItems=t.map(t=>null!=t&&t.subItems&&(null==t?void 0:t.subItems.length)>0?t.subItems[0]:t)}P!==ft.contentCard&&P!==ft.infopaneCard||!this.ttvrFired||(null===(N=this.config.childExperienceReferences)||void 0===N?void 0:N.socialBarWC)&&(0,yr.uC)(this.config.childExperienceReferences.socialBarWC);if("video"===t&&P===ft.contentCard&&k.type===_t.pL.WebContent){const t=U.cardMetadata&&U.cardMetadata.cardContent;if(t){const{destinationUrl:e,title:i,id:r}=t;U.cardMetadata.cardContent.destinationUrl=(0,vr.CW)(r,e,i)}}if(this.ttvrFired&&P===ft.trendingNowCard&&!this.loadedWebComponents.includes(ft.trendingNowCard))try{(0,yr.uC)(U.configOptions),this.loadedWebComponents.push(ft.trendingNowCard)}catch(t){Ai.YT.sendAppErrorEvent({...lt.oUl,message:"Failed to load Trending Now WC",pb:{...lt.oUl.pb,errorMessage:JSON.stringify(t)}})}if(this.ttvrFired&&P===ft.pollsCard){const t=k.cardContent.insertedCardArgs.pollsCardConfigInfo.instanceId===Hi;U.cardMetadata.data=t?this.pollsData.quiz.data:this.pollsData.poll.data}if(this.ttvrFired&&P===ft.moneyInfoCardWC&&(this.moneyInfoCardWCData?U.cardMetadata.data=this.moneyInfoCardWCData:U.cardMetadata.data="{}",this.loadedWebComponents.includes(ft.moneyInfoCardWC)||((0,yr.uC)(U.configOptions),this.loadedWebComponents.push(ft.moneyInfoCardWC))),this.ttvrFired&&P===ft.healthArticlesCardWC&&(U.cardMetadata.data=this.healthInfoCardWCData||"{}",this.loadedWebComponents.includes(ft.healthArticlesCardWC)||((0,yr.uC)(U.configOptions),this.loadedWebComponents.push(ft.healthArticlesCardWC))),this.ttvrFired&&P===ft.travelDestinationCard){var q,H;U.cardMetadata={...U.cardMetadata,...this.travelDestinationCardWCData};const t=null===(q=this.travelDestinationCardWCData)||void 0===q?void 0:q.dataType;let e;e=["HotelList","HotelListingResult"].includes(t)?ot.S6:e,e=["FlightPriceTrends","FlightPriceTrendsList"].includes(t)?ot.aJb:e,e=["ThemeCardList","ThemeInspiration"].includes(t)?ot.znl:e,e=["DestinationList","Destination"].includes(t)?ot.Qs5:e,e&&null!==(H=U.configOptions.configRef)&&void 0!==H&&H.experienceType&&(U.configOptions.configRef.experienceType=e),this.loadedWebComponents.includes(ft.travelDestinationCard)||((0,yr.uC)(U.configOptions),this.loadedWebComponents.push(ft.travelDestinationCard))}const W=bi[P].getFeedDataForCard(U);var j;P===ft.denseCard&&null!==($=k.cardContent.insertedCardArgs)&&void 0!==$&&$.denseDataConfigOptions&&(W.defaultLayout[0].denseData.configOptions=null===(j=k.cardContent.insertedCardArgs)||void 0===j?void 0:j.denseDataConfigOptions);Object.keys(W).forEach(t=>{n[t]&&(n[t]=n[t].concat(W[t]))})}),n}async fetchQuizData(t,e){let r;r=this.config.disableQuizCard?e?null:this.config.pollsCardWCConfig:e?this.config.quizCardWCConfig:this.config.pollsCardWCConfig;const o=e?"quiz":"poll";if(this.pollsData[o].fetchingTriggered=!0,this.pollsData[o].isFetching=!0,r)try{const{contentId:s,timezoneDiffToUTC:a}=r,{PollsCardWCActionServiceClient:n}=await i.e("polls-service").then(i.bind(i,1309)),l=new n(window.fetch.bind(window)),d=await l.getPollsData(s,e,a);(null==d?void 0:d.length)>0?this.pollsData[o].data=d:this.pollsData[o].fallbackToContentCard=!0,bt.M.singleMark("StripeWC-PollsCardLoadEnd"),this.pollsData[o].isFetching=!1,this.updateStripes(t)}catch(t){this.pollsData[o].fallbackToContentCard=!0;const e={...lt.V9L,message:"Failed fetching Poll/Quiz data for stripe wc",pb:{...lt.V9L.pb,customMessage:t.message}};Ai.YT.sendAppErrorEvent(e)}else this.pollsData[o].fallbackToContentCard=!0}async initTopStripeNativeAds(){const t=this.riverSectionIds[0];try{if(!this.ttvrFired||!this.riverSectionLayoutData[0])return;await this.initNativeAdService();const e=[this.fetchNativeAdsContent(t),this.fetchNativeAdsContent(t,!0)];Promise.all(e).then(e=>{const[i=[],r=[]]=e;this.updateAdPlacementData(t,[...i,...r]),bt.M.singleMark("StripeWC-topStripeReady"),this.startInfopaneAutoRotation(),this.ttvrLogInfo.topStripeAdsReadyAt=performance.now()})}catch(e){return Ai.YT.sendAppErrorEvent({...lt.sHf,message:"Error when fetching top stripe nativeAds data",pb:{...lt.sHf.pb,errorMessage:JSON.stringify(e)}}),this.updateStripes(t),void this.startInfopaneAutoRotation()}}hasTravelDestinationCardWC(t){var e;const i=(null===(e=this.config.insertCardInSlot)||void 0===e?void 0:e[t])||[];let r=!1;return i.forEach(t=>{(null==t?void 0:t.cardType)===ft.travelDestinationCard&&(r=!0)}),r}hashealthArticleInfoCardWC(t){var e;const i=(null===(e=this.config.insertCardInSlot)||void 0===e?void 0:e[t])||[];let r=!1;return i.forEach(t=>{(null==t?void 0:t.cardType)===ft.healthArticlesCardWC&&(r=!0)}),r}hasMoneyInfoCardWC(t){var e;const i=(null===(e=this.config.insertCardInSlot)||void 0===e?void 0:e[t])||[];let r=!1;return i.forEach(t=>{(null==t?void 0:t.cardType)===ft.moneyInfoCardWC&&(r=!0)}),r}async updateUserFinanceInterest(){const t=await this.financeUserService.getFinanceInterest();var e,i;t&&(this.hasSectionInterest.finance=0,(null===(e=t.explicit)||void 0===e?void 0:e.length)>0&&(this.hasSectionInterest.finance+=1e3),(null===(i=t.implicit)||void 0===i?void 0:i.length)>0&&(this.hasSectionInterest.finance+=1))}async updateDynamicRankingInterests(){this.dynamicRankingInterests=await this.userPreferenceFetcherService.getUserPreferences(),this.dynamicInterestsFetched=!0}async updateUserBuyDirectInterest(){await this.buyDirectServiceClient.hasBuyDirectInterest()&&(this.hasSectionInterest.buydirect=1)}async fetchTravelDestinationCardData(t){await Cr.Iw.GetSDCardData().then(e=>{e&&Array.isArray(e)&&e.length>0&&(this.travelDestinationCardWCData=e[0],this.travelDestinationCardWCData&&this.travelDestinationCardWCData.length>0&&this.updateStripes(t))})}async fetchHealthInfoCardData(t){const e=dt.T3.CurrentMarket,i=`recommendations|articleData|1|${e}`;await Zi.getDataFromOneService(i,e,!0).then(e=>{e&&(this.healthInfoCardWCData=JSON.stringify(e),this.healthInfoCardWCData&&this.healthInfoCardWCData.length>0&&this.updateStripes(t))})}async fetchMoneyInfoCardData(t){const e={experienceType:ot.ahW,instanceSrc:"default"};this.moneyInfoCardWCConfig=(await wi.L.getConfig(e)).properties;try{if(!this.financeUserService||!this.financeAutoSuggestService||!this.financeService){const{FinanceServices:t,getFinanceDataConnector:e}=await Promise.all([i.e("node_modules_crypto-js_index_js"),i.e("libs_finance-service-library_dist_common_FinanceRoute_js"),i.e("experiences_spotlight-card-wc_dist_ContentTemplates_DailyQuiz_DailyQuizCard_styles_js-libs_fi-fbe3c0")]).then(i.bind(i,36915));var r;if(!this.financeUserService)e().config.enableUnsignedWatchlist=null===(r=this.moneyInfoCardWCConfig)||void 0===r?void 0:r.enableUnsignedWatchlist,this.financeUserService=t.getFinanceUserService(this.moneyInfoCardWCConfig.enableUnsignedWatchlist);this.financeAutoSuggestService=t.getAutoSuggestService(),this.financeService=t.getCachedFinanceService()}const e={userSignedIn:!1,dataFrom:"watchlist",dataTimestamp:null,data:null,fullWatchlistQuoteIds:null};if(this.moneyInfoCardWCConfig.enableUnsignedWatchlist)e.userSignedIn=!0;else{const{getUserSignInState:t}=await i.e("tcfConsentBanner").then(i.bind(i,64295));e.userSignedIn=2===await t()}let o=[];(e.userSignedIn||this.moneyInfoCardWCConfig.enableUnsignedWatchlist)&&(o=await this.financeUserService.getWatchlist(!1),e.fullWatchlistQuoteIds=o),o&&0!==o.length||this.moneyInfoCardWCConfig.enableUnsignedWatchlist?e.dataFrom="watchlist":e.dataFrom="market";const s="watchlist"===e.dataFrom?o:this.moneyInfoCardWCConfig.apiConfig.marketQuoteIds;this.financeService.cleanCache();const a=await this.financeService.getRecommendation(),n=[s,a||this.moneyInfoCardWCConfig.apiConfig.recommendedQuoteIds],l=[].concat(...n),d=await this.financeService.getQuoteSummary(l),c={};d.forEach(t=>{null!=t&&t.id&&(c[t.id]=t)});const h=n.map(t=>t.map(t=>c[t]).filter(t=>t)),[p,u]=h;e.data={recommend:{quoteItems:u,quoteIds:u.map(t=>t.id)},[e.dataFrom]:{quoteItems:p,quoteIds:p.map(t=>t.id)}},e.data.watchlist||(e.data.watchlist={quoteItems:[],quoteIds:[]}),e.dataTimestamp=(new Date).getTime();const g=[...this.moneyInfoCardWCConfig.defaultTabs];"watchlist"!==e.dataFrom&&g.splice(g.indexOf("watchlist"),1);const m={userSignedIn:e.userSignedIn,dataFrom:e.dataFrom,fullWatchlistQuoteIds:"watchlist"===e.dataFrom?s:[],recommendQuoteItems:u,tabListDetails:e.data,notifications:null,tabs:g};this.moneyInfoCardWCData=JSON.stringify(m),this.updateStripes(t)}catch(t){Ai.YT.sendAppErrorEvent({...lt.B0w,message:"MoneyInfoCard content fetch failed",pb:{...lt.B0w.pb,customMessage:`Failed with exception : ${JSON.stringify(t)}`}})}}getDisplayedColumnLayout(){const t=this.columnArrangement;if(!this.enableRail||!t)return t;const e=parseInt(t.replace("C",""),10);return Number.isNaN(e)?t:"C"+(e-1)}updateStripes(t){this.updateRiverSections(t),this.config.stripeStyles&&this.processLayoutStyles(),Pr&&t&&(0,Ct.CI)(Dr(t))}updateRiverSections(t){this.riverSectionLayoutData=this.riverSectionLayoutData.map((e,i)=>{var r,o;if(!e)return;const{templateId:s,sectionId:a}=e;let n=Ae[s];if(void 0!==t&&t!==a)return e;let l=(0,Bi.A)((null===(r=this.config.slotToCardType)||void 0===r?void 0:r[a])||[])||[],d=e.cardMetadataList;const{backfillCardTypeSlot:c,backfillMetadata:h,backfillTemplateId:p}=$r(a,d,null===(o=this.config.childExperienceReferencesWC)||void 0===o||null===(o=o[a])||void 0===o?void 0:o.backfillConfigs);if(d=h||d,l=c||l,n=p?Ae[p]:n,e.hasPlaceHolderAds||t===a){var u;const r=this.nativeAdPlacementsMap[a];if(r&&(null==e||null===(u=e.cardMetadataList)||void 0===u?void 0:u.length)===r.length){let t=!1;var g,m;if(r.forEach(e=>t=t||this.hasAdsContent(e)),!t)return void(0,nt.vV)(lt.Koy,"No ads content for entire stripe",`sectionId: ${a}, adsConfig: ${null===(g=this.config.adPlacements)||void 0===g?void 0:g[a]}, cmsConfig: adsConfig: ${null===(m=this.config.adPlacements)||void 0===m?void 0:m[a]}`)}const o=null==r?void 0:r.filter(t=>t.region===_t.pL.Infopane),s=null==r?void 0:r.filter(t=>t.region!==_t.pL.Infopane),c=d.map((i,r)=>{if(i.type===_t.pL.Infopane){if(!this.ttvrFired||!this.nativeAdIsLoaded[t])return i;if(i.subItems=this.infopaneSubItems.slice(),null!=o&&o.length){const t=o.sort((t,e)=>t.regionIndex>e.regionIndex?1:t.regionIndex<e.regionIndex?-1:0),e=[];t.forEach(t=>{const r=t.regionIndex-1;!e.includes(r)&&i.subItems[r]&&this.hasAdsContent(t)&&(e.push(r),i.subItems.splice(r,0,this.createNativeAdCardMetadata(t)))})}if(this.shouldOverrideInfopaneCards&&this.ttvrFired&&"topStripe"==t)for(let t=0;t<(null==i||null===(a=i.subItems)||void 0===a?void 0:a.length);t++){var a;const e=i.subItems[t];if(null!=e&&e.id&&this.replacementInfopaneCards[e.id]){const r=this.replacementInfopaneCards[e.id];i.subItems[t]=r.card,r.tmplStringPrefix&&Ai.YT.addOrUpdateTmplString(`${r.tmplStringPrefix}-${e.cardContent.id}`)}}return i}{var n;let t,o=0;for(let t=0;t<r;t++){var l;e.cardMetadataList[t].type===Ar&&null!==(l=e.cardMetadataList[t].subItems)&&void 0!==l&&l.length?o+=e.cardMetadataList[t].subItems.length-1:o++}return(null===(n=i.cardContent)||void 0===n?void 0:n.insertedCardType)===ft.denseCard?null==s||s.forEach(t=>{if(this.hasAdsContent(t)&&t.regionIndex>o){var e;const r=t.regionIndex-o,s=null===(e=i.subItems)||void 0===e?void 0:e[r];s&&s.type!==_t.pL.NativeAd&&(i.subItems[r]=this.createNativeAdCardMetadata(t))}}):t=null==s?void 0:s.find(t=>t.regionIndex===o+1),t&&this.hasAdsContent(t)?this.createNativeAdCardMetadata(t):i}});return{...e,feedData:this.mapFeedData(a,c,n,this.config.openLinksInNewTab,this.telemetryObject,l,i),hasPlaceHolderAds:!1,cardMetadataList:(0,Bi.A)(c)}}return{...e,feedData:this.mapFeedData(a,e.cardMetadataList,n,this.config.openLinksInNewTab,this.telemetryObject,l,i)}})}updateAdPlacementData(t,e){const i=this.nativeAdPlacementsMap[t];null!=i&&i.length&&null!=e&&e.length&&i.forEach((t,r)=>{var o;const s=e.filter(e=>e.region===t.region&&e.regionIndex===t.regionIndex)[0];null!=s&&null!==(o=s.items)&&void 0!==o&&o.length&&(i[r]=s)}),this.updateStripes(t)}async fetchNativeAdsContent(t,e){let i=this.getAdRequestForRiver(t,e);const r=xi.Rb.Locale,o=Wi[r]||at.F3[r];if(!i)return;r&&(i.locale=r);const s=[];try{var a;await this.initNativeAdService(),null!==(a=i.placements)&&void 0!==a&&a.length&&(i=(0,Bi.A)(i),i.placements.forEach(t=>{this.nativeAdIndiceRegionFilters.length&&!this.nativeAdIndiceRegionFilters.includes(t.region.toLowerCase())&&(t.indices=t.indices.map((t,e)=>e+1))})),bt.M.startMark(_r);const r=e?await this.nativeAdService.fetchCmsAds(i,o,[]):await this.nativeAdService.fetchNativeAds(i),{placements:n,adLabelText:l,isGreyAdsLabelEnabled:d}=r;null!=n&&n.length&&n.forEach(i=>{if(t!==this.riverSectionIds[0]&&!this.nativeAdIndiceRegionFilters.includes(i.region.toLowerCase())){var r,o;(e?null===(r=this.config.cmsAdPlacements)||void 0===r?void 0:r[t]:null===(o=this.config.adPlacements)||void 0===o?void 0:o[t]).placements.forEach(t=>{t.region===i.region&&(i.regionIndex=t.indices[i.regionIndex-1])})}const a=i;a.adLabelText=l,a.isGreyAdsLabelEnabled=d,this.config.isMsnHPAdSlug&&(a.isGreyAdsLabelEnabled=!1),s.push(a)})}catch(e){this.nativeAdIsLoaded[t]=!0,(0,nt.c_)(e,lt.sHf,"Call to Ad Service failed")}finally{bt.M.endMark(_r),this.nativeAdIsLoaded[t]=!0}return s}async initNativeAdService(){if(!this.nativeAdService){const{NativeAdService:t}=await i.e("MarketRoamingCoachMark").then(i.bind(i,98124));this.nativeAdService=new t(void 0,this.config&&this.config.adServiceConfig)}}loadNativeAd(t,e){this.ttvrFired&&this.fetchNativeAdsContent(t,e).then(e=>{this.updateAdPlacementData(t,e)})}createStripeAdCardDefaultMetadata(t){const e=[];for(let i=1;i<=t;i++)e.push({type:_t.pL.NativeAd,regionIndex:i,placement:{items:[]}});return e}createNativeAdCardMetadata(t){var e;if(null==t||null===(e=t.items)||void 0===e||!e.length)return;return{type:_t.pL.NativeAd,id:`${_t.pL.NativeAd}-${t.regionIndex}`,placement:t}}hasAdsContent(t){return Object.keys((null==t?void 0:t.items[0])||{}).length>0}getAdRequestForRiver(t,e){var i,r;const o=e?null===(i=this.config.cmsAdPlacements)||void 0===i?void 0:i[t]:null===(r=this.config.adPlacements)||void 0===r?void 0:r[t];if(!o)return;let s;if(null!=o&&o.placements){const e=[];if(o.placements.forEach(t=>{if(t.region.indexOf(_t.pL.Infopane)>=0){var i;e.push({...t,img:null===(i=this.config.adTemplateConfig)||void 0===i||null===(i=i.imageSizeConfig)||void 0===i?void 0:i.infopane})}else{const i=t.indices;if(i.length){const r={...t,indices:i};e.push(r)}}}),e.length){const i=this.getDefaultAdPlaceholderPlacements(e);this.nativeAdPlacementsMap[t]?this.nativeAdPlacementsMap[t].push(...i):this.nativeAdPlacementsMap[t]=i,s={placements:e,pageType:o.pageType}}}return s}getDefaultAdPlaceholderPlacements(t){let e=[];return t&&t.forEach(t=>{const i=t.indices.map(e=>({...t,regionIndex:e,items:[{}]}));e=e.concat(i)}),e}getNavigationButonTelemetryTag(t){return(0,ur.N)(t,Di.MS.Paginate,Di.EG.Click,Di.MJ.ActionButton).getMetadataTag()}startInfopaneAutoRotation(){const t=this.config.infopaneConfig||{};if(t.autoRotate&&!t.disableAutoRotate){var e,i;const t=this.riverSectionIds[0],r=null===(e=(i=this.shadowRoot).querySelector)||void 0===e||null===(e=e.call(i,`#${t} cs-feed-layout`))||void 0===e?void 0:e.shadowRoot,o=null==r?void 0:r.querySelector("cs-responsive-infopane");o&&window.setTimeout(()=>{o.hasSlideShow=!0,this.overrideHasSlideShow=!0},1e3)}}has1SFlight(t){const e=dt.T3.CurrentRequestTargetScope&&dt.T3.CurrentRequestTargetScope.pageExperiments;if(e){const t="1s-viewurldomain";return e.includes(t)}return!1}handleContentOverlap(t,e){const i=t.target.getBoundingClientRect();i.top<160&&window.scrollBy(0,i.top-160)}overrideInfopaneSlideCardToElectionCard(t){t.cardMetadata={id:"electionCard",cardContent:{abstract:"US Elections: Latest news, results and more",destinationUrl:"https://www.msn.com/en-us/channel/topic/US%20Elections/tp-Y_cc072da4-ecb2-413a-9ffe-5ec5ad54ca41",id:"electionCard",images:[{id:"USElectionCard",caption:"US Elections: Latest news, results and more",url:"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1sKqsZ.img"}],type:"ArticlePreview",title:"US Elections: Latest news, results and more"},metadata:{},type:"article"}}}(0,g.Cg)([f.sH],Rr.prototype,"columnArrangement",void 0),(0,g.Cg)([f.sH],Rr.prototype,"isShowDot",void 0),(0,g.Cg)([f.sH],Rr.prototype,"isFetchingStripes",void 0),(0,g.Cg)([f.sH],Rr.prototype,"requestContext",void 0),(0,g.Cg)([f.sH],Rr.prototype,"riverSectionLayoutData",void 0),(0,g.Cg)([f.sH],Rr.prototype,"ttvrFired",void 0),(0,g.Cg)([f.sH],Rr.prototype,"cardActionRef",void 0),(0,g.Cg)([f.sH],Rr.prototype,"isFeedExhausted",void 0),(0,g.Cg)([f.sH],Rr.prototype,"onFeedEndCb",void 0),(0,g.Cg)([f.sH],Rr.prototype,"enableRail",void 0);var Tr=i(66591),Ir=i(14097),Mr=i(72691),Or=i(31157),zr=i(36042);const Br=R.A` .container{left:3px}`,Ur=R.A` .container{right:3px}`,Fr=R.A`
.arrow-container-rail{display:none}${(0,le.H5)(le.j1.c3)}{.arrow-container.arrow-container-rail{width:697px}}${(0,le.H5)(le.j1.c4)}{.arrow-container.arrow-container-rail{width:1019px}}${(0,le.H5)(le.j1.c5)}{.arrow-container.arrow-container-rail{width:1341px}}`,Lr=R.A`
:host{--viewport-width:auto;--viewport-height:auto;--element-gap:16px;height:var(--viewport-height);width:var(--viewport-width);position:relative;display:flex}.arrow-container{position:absolute;display:flex;justify-content:space-between;align-items:flex-end;align-self:end;pointer-events:none;z-index:0;right:20px;bottom:4px}${(0,le.H5)(le.j1.c2)}{.arrow-container{width:697px}}${(0,le.H5)(le.j1.c3)}{.arrow-container{width:1019px}}${(0,le.H5)(le.j1.c4)}{.arrow-container{width:1341px}}.viewport{height:303px;overflow-x:hidden;scroll-behavior:smooth;width:303px;width:var(--viewport-width);overflow:hidden}.viewport-weather{height:303px;scroll-behavior:smooth;width:303px;width:var(--viewport-width);overflow:hidden}.disable-overflow-hidden{overflow:visible;height:var(--viewport-height)}.page-indicator{font-size:var(--page-number-font-size,12px);color:var(--page-number-color);line-height:16px;pointer-events:all}.page-indicator span{background:#c2c2c2;border-radius:50%;height:6px;width:6px;display:inline-block;margin:0 4px;cursor:pointer}.page-indicator span.active{background:#333;cursor:default}.container{display:flex;flex-direction:row;gap:var(--element-gap);width:max-content;height:100%;left:3px;position:relative}.slider-arrow{pointer-events:all;z-index:2;outline:none;background:var(--flipper-background,transparent);width:var(--flipper-width,20px);height:var(--flipper-height,20px);display:flex;align-items:center;justify-content:center;border-radius:50%;cursor:pointer;border:none;margin-bottom:162px;width:28px}.slider-arrow.hide{pointer-events:none;visibility:hidden}.slider-arrow svg{width:var(--flipper-icon-width);color:var(--flipper-icon-color,buttonText);fill:#9b9b9b}${Fr}
`.withBehaviors(new W.t(Br,Ur)),Er=$.qy`<svg width="24" height="24" viewBox="0 0 5 8" style="transform: scale(-1, 1);" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.646447 0.146447C0.451184 0.341709 0.451184 0.658291 0.646447 0.853553L3.79289 4L0.646447 7.14645C0.451185 7.34171 0.451185 7.65829 0.646447 7.85355C0.841709 8.04882 1.15829 8.04882 1.35355 7.85355L4.85355 4.35355C5.04882 4.15829 5.04882 3.84171 4.85355 3.64645L1.35355 0.146447C1.15829 -0.0488155 0.841709 -0.0488155 0.646447 0.146447Z"/></svg>`,Nr=$.qy`<svg width="24" height="24" viewBox="0 0 5 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.646447 0.146447C0.451184 0.341709 0.451184 0.658291 0.646447 0.853553L3.79289 4L0.646447 7.14645C0.451185 7.34171 0.451185 7.65829 0.646447 7.85355C0.841709 8.04882 1.15829 8.04882 1.35355 7.85355L4.85355 4.35355C5.04882 4.15829 5.04882 3.84171 4.85355 3.64645L1.35355 0.146447C1.15829 -0.0488155 0.841709 -0.0488155 0.646447 0.146447Z"/></svg>`,qr=$.qy` ${(0,S.ux)(t=>t.pageIndicatorData,$.qy`<span class="${t=>t.active?"active":""}" id=${t=>t.pageIndex} @click=${(t,e)=>e.parent.handlePageIndicatorClick(e.event)} data-t="${(t,e)=>e.parent.pageIndicatorTelemetryTag}"></span>`)}
`,Hr=$.qy`<div ${(0,k.K)("viewport")} class="${t=>"weather"==t.sectionId?"viewport-weather":"viewport"}" part="viewport" direction="${t=>t.direction?t.direction:"ltr"}"><div class="container" part="container" ${(0,k.K)("container")}><slot ${(0,k.K)("viewportSlot")} @slotchange=${t=>t.setCurrentSlotWidth()}></slot></div></div><div class="${t=>(0,Tr.x)("arrow-container",["arrow-container-rail",t.isRailEnabled])}" part="arrow-container"><slot ${(0,k.K)("previousArrow")} name="previous-arrow"><button class="slider-arrow previous-arrow" @mousedown="${(t,e)=>e.event&&t.mouseDownHandler(e.event)}" @click="${t=>t.slideKeyPressHandler(-1)}" aria-label="${t=>t.leftArrow}" data-t="${t=>t.previousArrowTelemetryTag}" hidden tabindex="-1">${(0,P.z)(t=>t.renderSlider&&"ltr"===t.direction,Er)} ${(0,P.z)(t=>t.renderSlider&&"rtl"===t.direction,Nr)}</button></slot><div class="page-indicator">${(0,P.z)(t=>t.renderSlider,qr)}</div><slot ${(0,k.K)("nextArrow")} name="next-arrow"><button class="slider-arrow next-arrow" @mousedown="${(t,e)=>e.event&&t.mouseDownHandler(e.event)}" @click="${t=>t.slideKeyPressHandler(1)}" aria-label="${t=>t.rightArrow}" data-t="${t=>t.nextArrowTelemetryTag}" hidden tabindex="-1">${(0,P.z)(t=>t.renderSlider&&"ltr"===t.direction,Nr)} ${(0,P.z)(t=>t.renderSlider&&"rtl"===t.direction,Er)}</button></slot></div>`;let Wr=class extends C.L{columnArrangementChanged(t,e){t&&this.container&&this.handleBreakpointChange()}constructor(){super(),this.direction=Or.O.ltr,this.nextArrowTelemetryTag="",this.previousArrowTelemetryTag="",this.pageIndicatorTelemetryTag="",this.columnArrangement="C4",this.currentPageIndex=1,this.totalNumPages=1,this.pageIndicatorData=[],this.currentSlotElementWidth=0,this.currentContentGapSize=0,this.handleBreakpointChange=()=>{this.setSliderStates(),this.refreshSliderControls(this.viewport.scrollLeft)},this.handleBreakpointChange=(0,zr.A)(this.handleBreakpointChange,200)}connectedCallback(){super.connectedCallback(),this.direction=Mr.o.getValueFor(this),this.setSliderStates(),this.refreshSliderControls(0)}setCurrentSlotWidth(){const t=window.getComputedStyle(this.container).rowGap;this.currentContentGapSize=t?Number(t.replace(/px/,"")):0;this.viewportSlot.assignedElements().length>0&&("C4"===this.columnArrangement&&this.isC5Enabled?this.currentSlotElementWidth=1273:"C3"===this.columnArrangement?this.currentSlotElementWidth=951:"C2"===this.columnArrangement?this.currentSlotElementWidth=629:this.currentSlotElementWidth=0)}slideKeyPressHandler(t){var e;if(this.disableSliderInColumnArrangement())return;const i=this.viewport.clientWidth,r=this.container.clientWidth;if(i<=0||r<=0)return;const o="rtl"!==this.direction,s=this.viewport.scrollLeft;if(o||(t*=-1),!o&&t>0&&0===s)return;if(o&&t<0&&0===s)return;const a=t*this.getScrollDistance();if(s+a>r)return;this.currentPageIndex=Math.floor(Math.abs(s+a)/i)+1,this.currentPageIndex<=0&&(this.currentPageIndex=1),null===(e=this.onSlideIndexChange)||void 0===e||e.call(this,this.currentPageIndex-1);const n=s+a;window.requestAnimationFrame(()=>{this.viewport.scrollTo(n,0),this.refreshSliderControls(n)})}mouseDownHandler(t){t.preventDefault(),t.stopPropagation()}setArrowVisibility(t){const e=t*("ltr"===this.direction?1:-1);e<=0?this.setArrowsHiddenVisibility(!0,!1):this.viewport.clientWidth+e>this.container.clientWidth?this.setArrowsHiddenVisibility(!1,!0):this.setArrowsHiddenVisibility(!1,!1)}hideNextArrow(t){t?this.nextArrow.children[0].classList.add("hide"):this.nextArrow.children[0].classList.remove("hide")}hidePreviousArrow(t){t?this.previousArrow.children[0].classList.add("hide"):this.previousArrow.children[0].classList.remove("hide")}setArrowsHiddenVisibility(t,e){this.hidePreviousArrow(t),this.hideNextArrow(e)}getScrollDistance(){return this.currentSlotElementWidth+this.currentContentGapSize}refreshSliderControls(t){this.setPageIndicator(),this.setArrowVisibility(t)}setSliderStates(){this.calculateTotalNumPages(),this.setCurrentSlotWidth(),this.setSliderVisibility()}calculateTotalNumPages(){return"C4"===this.columnArrangement&&this.isC5Enabled||["C2","C3"].includes(this.columnArrangement)?this.totalNumPages=2:this.totalNumPages=0}setSliderVisibility(){this.renderSlider=!(this.disableSlider||"C5"===this.columnArrangement||"C4"===this.columnArrangement&&!this.isC5Enabled||["topStripe","buydirect","shopping"].includes(this.sectionId)),"topStripe"!==this.sectionId&&this.disableSliderInColumnArrangement?this.viewport.classList.remove("disable-overflow-hidden"):this.viewport.classList.add("disable-overflow-hidden")}disableSliderInColumnArrangement(){const t=["C2","C3"];return this.isC5Enabled&&t.push("C4"),this.disableSlider||!t.includes(this.columnArrangement)}setPageIndicator(){this.pageIndicatorData=[];for(let t=1;t<=this.totalNumPages;t++){const e={active:this.currentPageIndex===t,pageIndex:t};this.pageIndicatorData.push(e)}}handlePageIndicatorClick(t){if(this.disableSliderInColumnArrangement())return;const e="ltr"===this.direction?1:-1,i=Number(null==t?void 0:t.target.id),r=(i-1)*this.getScrollDistance();this.currentPageIndex=i,window.requestAnimationFrame(()=>{this.viewport.scrollTo(r*e,0),this.refreshSliderControls(r)})}};(0,g.Cg)([f.sH],Wr.prototype,"direction",void 0),(0,g.Cg)([f.sH],Wr.prototype,"nextArrowTelemetryTag",void 0),(0,g.Cg)([f.sH],Wr.prototype,"previousArrowTelemetryTag",void 0),(0,g.Cg)([f.sH],Wr.prototype,"pageIndicatorTelemetryTag",void 0),(0,g.Cg)([f.sH],Wr.prototype,"columnArrangement",void 0),(0,g.Cg)([f.sH],Wr.prototype,"currentPageIndex",void 0),(0,g.Cg)([f.sH],Wr.prototype,"totalNumPages",void 0),(0,g.Cg)([f.sH],Wr.prototype,"sectionId",void 0),(0,g.Cg)([f.sH],Wr.prototype,"disableSlider",void 0),(0,g.Cg)([f.sH],Wr.prototype,"isC5Enabled",void 0),(0,g.Cg)([f.sH],Wr.prototype,"leftArrow",void 0),(0,g.Cg)([f.sH],Wr.prototype,"rightArrow",void 0),(0,g.Cg)([f.sH],Wr.prototype,"renderSlider",void 0),(0,g.Cg)([f.sH],Wr.prototype,"pageIndicatorData",void 0),(0,g.Cg)([f.sH],Wr.prototype,"isRailEnabled",void 0),Wr=(0,g.Cg)([(0,C.E)({name:"stripe-slider",template:Hr,styles:Lr,shadowOptions:{delegatesFocus:!0}})],Wr);const jr=$.qy` ${(t,e)=>(0,li.yN)(t.pivotsNav,{properties:{parentTelemetry:e.parent.telemetryObject}})}
`,Jr=$.qy`<div class="river-section-header-group" style="${t=>t.riverSectionTitleColor&&!t.disableStripeTheme?`border-color: ${t.riverSectionTitleColor};`:""} ${t=>t.seeMoreText?"border-width: 1px;":""}"><div class="stripe-title"><h2>${(0,P.z)(t=>t.adLabel,$.qy`<msn-native-ad-ad-label type="${t=>t.adSlugGA?"defaultLabel":"greenLabel"}" ad-label-text=${t=>t.adLabel} ad-label-text-opacity="${t=>t.adSlugGA?"0.81":"0.7"}" should-adjust-gap is-msn-hp-ad-slug=${t=>t.isMsnHPAdSlug} enable-safe-ads=${t=>t.enableSafeAds}></msn-native-ad-ad-label>`)}<a href="${t=>t.riverSectionTitleUrl}" target="${(t,e)=>e.parent.config.openLinksInNewTab?"_blank":"_self"}" style="${t=>t.riverSectionTitleColor&&!t.disableStripeTheme?`color: ${t.riverSectionTitleColor}`:""};${t=>t.riverSectionTitleUrl?"":"text-decoration: none;"}" data-t="${(t,e)=>e.parent.stripeWCTelemetry.getTelemetryTag(gr.title)}" title="${t=>t.seeMoreText}" aria-label="${t=>t.seeMoreText}">${t=>t.riverSectionTitle} ${(0,P.z)(t=>t.riverSectionTitleUrl||t.adLabel,$.qy`<span class="title-arrow">${$.qy.partial(Ir.A)}</span>`)}</a></h2></div><div class="sub-nav">${(0,P.z)(t=>t.pivotsNav,jr)}</div></div>`,Gr=$.qy`<div class="feed-section">${(0,S.ux)(t=>t.riverSectionLayoutData.filter(t=>null!=t),$.qy` ${(0,P.z)(t=>t.insertBannerAd,$.qy`<div class="in-stripe-banner-ad" id="${(t,e)=>t.sectionId}"><display-ads config-instance-src="default" instance-id="banner2"></display-ads></div>`)} ${(0,P.z)(t=>!t.insertBannerAd,$.qy`<div class="river-section" data-t="${(t,e)=>e.parent.stripeWCTelemetry.getSectionTelemetryTag(t.sectionId,t.telemetryName)}" id="${(t,e)=>t.sectionId}" @focusin="${(t,e)=>e.parent.handleContentOverlap(e.event,t.sectionId)}">${(0,P.z)(t=>t.riverSectionTitle,Jr)}<stripe-slider class="${(t,e)=>(0,Tr.x)("stripe-slider-container",["stripe-slider-container-rail",e.parent.enableRail],["more-space","topStripe"===t.sectionId||e.parent.isShowDot])}" part="stripe-slider-container" :isRailEnabled=${(t,e)=>e.parent.enableRail} :previousArrowTelemetryTag=${(t,e)=>e.parent.getNavigationButonTelemetryTag("leftarrow")} :nextArrowTelemetryTag=${(t,e)=>e.parent.getNavigationButonTelemetryTag("rightarrow")} :pageIndicatorTelemetryTag=${(t,e)=>e.parent.getNavigationButonTelemetryTag("pageIndicator")} :leftArrow=${t=>t.leftArrow||{}} :rightArrow=${t=>t.rightArrow||{}} :columnArrangement=${(t,e)=>e.parent.getDisplayedColumnLayout()} :disableSlider=${t=>t.disableSlider} :isC5Enabled=${t=>t.isC5Enabled} :sectionId=${t=>t.sectionId}><cs-feed-layout class="stripe-river-section" data-section=${t=>t.sectionId} layout=${(t,e)=>e.parent.getDisplayedColumnLayout()} :data=${t=>t.feedData} :childTemplateMap=${t=>Ci} :layoutStyles=${t=>(t=>{const e=Ae[t].styles,i=cr+dr;return t.indexOf("top-stripe-view")>=0?R.A`${e}${i}${lr}`:R.A`${e}${i}`})(t.templateId)} data-t="${(t,e)=>"topStripe"===t.sectionId?e.parent.stripeWCTelemetry.getTelemetryTag(gr.todayHeadlines):null}"></cs-feed-layout></stripe-slider></div>`)} `)}<div ${(0,k.K)("paginationSentinelRef")} style=${t=>t.sentinelHeight} class="pagination-sentinel"></div></div>`,Vr=$.qy` ${t=>{var e;return(null===(e=t.config.childExperienceReferences)||void 0===e?void 0:e.cardAction)&&(0,li.yN)(t.config.childExperienceReferences.cardAction)}}
`,Kr=$.qy`<fluent-design-system-provider id="sf-design-system" style="background: transparent" fill=""><div class="stripe-feed" style="${t=>t.config.noPaddingEnd&&t.isFeedExhausted?"padding-bottom: 4px":null}">${(0,P.z)(t=>t.riverSectionLayoutData,Gr)} ${(0,P.z)(t=>t.isFetchingStripes&&t.ttvrFired,$.qy`<div class="progress-ring-wrapper"><fluent-progress-ring></fluent-progress-ring></div>`)}</div>${(0,P.z)(t=>t.ttvrFired,Vr)}</fluent-design-system-provider>`;r.m.define(o.c.registry),s.m.define(o.c.registry),a.m.define(o.c.registry),Y.m.define(n.G.registry),l.Ob.define(d.i.registry),c.Id.define(d.i.registry),h.Af.define(d.i.registry),p.yr.define(d.i.registry),u.rX.define(d.i.registry),K.define(d.i.registry),Z.Bb.define(d.i.registry),tt.L.define(d.u.registry);const Xr={experienceConfigSchema:undefined}},46028(t,e,i){i.d(e,{U(){return o}});var r=i(4126);function o(t,e){return new r.o("color",t,e)}},55023(t,e,i){i.d(e,{S(){return o},y(){return s}});var r=i(74849);const o=r.A`
:host{--color-card-background:#333333;--color-brand-background-2:#082338;--color-brand-background-2-hover:#0c3b5e;--color-neutral-background-2:#1f1f1f;--color-neutral-background-1-hover:#3d3d3d;--color-neutral-background-1:#292929;--color-neutral-background-2-hover:#292929;--color-neutral-background-2:#141414;--color-neutral-background-alpha-2:rgba(31,31,31,0.7);--color-neutral-foreground-1:#ffffff;--color-neutral-foreground-2:#d6d6d6;--color-neutral-foreground-3:#adadad;--color-neutral-stroke-1:#666666;--color-neutral-stroke-2:#525252;--color-neutral-stroke-3:#3d3d3d;--color-neutral-stroke-hover:#757575;--color-neutral-stroke-accessible-hover:#bdbdbd;--color-neutral-stroke-accessible:#adadad;--color-neutral-stroke-alpha:rgba(255,255,255,0.1);--color-neutral-stroke-1-pressed:#6b6b6b;--color-neutral-fill-secondary:#3b3b3b;--color-neutral-fill-secondary-hover:#383838}`,s=r.A`
:host{--color-card-background:#ffffff;--color-brand-background-2:#ebf3fc;--color-brand-background-2-hover:#cfe4fa;--color-neutral-background-2:#fafafa;--color-neutral-background-1-hover:#f5f5f5;--color-neutral-background-1:#ffffff;--color-neutral-background-2-hover:#ebebeb;--color-neutral-background-2:#f5f5f5;--color-neutral-background-alpha-2:rgba(255,255,255,0.8);--color-neutral-foreground-1:#242424;--color-neutral-foreground-2:#424242;--color-neutral-foreground-3:#616161;--color-neutral-stroke-1:#d1d1d1;--color-neutral-stroke-2:#e0e0e0;--color-neutral-stroke-3:#f0f0f0;--color-neutral-stroke-hover:#c7c7c7;--color-neutral-stroke-accessible-hover:#575757;--color-neutral-stroke-accessible:#616161;--color-neutral-stroke-alpha:rgba(0,0,0,0.05);--color-neutral-stroke-1-pressed:#b3b3b3;--color-neutral-fill-secondary:#f7f7f7;--color-neutral-fill-secondary-hover:#fcfcfc}`},55619(t,e,i){i.d(e,{e(){return s}});var r=i(96950),o=i(65055);const s=r.qy`
<fluent-card
    style="grid-area:${t=>t.gridArea};contain:unset"
    class="${t=>t.cardSize}"
>
    ${t=>(0,o.yN)(t.denseConfigInfo,{properties:{denseData:t.denseData,telemetryObject:t.telemetryObject},memoize:!1,includeTelemetryTag:!1})}
</fluent-card>
`},60569(t,e,i){i.d(e,{Vw(){return j},C8(){return J}});var r=i(56911),o=i(26813),s=i(96950),a=i(5096),n=i(23429),l=i(55230),d=i(74849),c=i(38493),h=i(60815),p=i(22341),u=i(93552),g=i(15938),m=i(83157),f=i(75674),v=i(39317),y=i(903),C=i(10809),b=i(94043),w=i(36067),x=i(10910),$=i(15525);class k extends o.D{durationChanged(t,e){void 0!==e&&this.changeLoadingAnimation(e)}hasSlideShowChanged(){this.autoScrollHandler()}tabCountChanged(){this.activeid&&this.activeidChanged("0",this.activeid)}disableHoverPauseChanged(){this.hoverSuspended=this.disableHoverPause}constructor(){super(),this.duration=5,this.hasSlideShow=!0,this.hasMediaControls=this.hasSlideShow,this.tabCount=5,this.isTouchDisabled=!1,this.disableHoverPause=!1,this.tabs=[],this.tabpanels=[],this.hasFocusIn=!1,this.isWindowFocused=!0,this.slidesFullyLoaded=new w.e,this.activeindicator=!1,this.hideActiveIndicator=!0,this.slidesChanged=0,this.hasNavigation=!1,this.navigationPosition="top",this.hoverSuspended=!1,this.adjustSuspended=!1,this.userAutoPlaySetting=!0,this.observeViewport=!0,this.resumeAfterVisibilityChange=!1,this.resumeAfterWindowBlur=!1,this.endOfSequenceIndex=void 0,this.startOfSequenceIndex=void 0,this.handleAutoPlayPreferenceChanged=t=>{const e=t.detail;e&&"boolean"==typeof e.enabled&&this.applyUserAutoPlayPreference(e.enabled)},this.play=!1,this.currentActiveIndexRendered=!1,this.lazyPanelTemplatePerSlide={},this.setVariableSpeedTransitionHandler=()=>{var t;this.clearVariableSpeedTransitionHandler();const e=this.variableTransitionMap[null!==(t=this.activeIndex)&&void 0!==t?t:0],i=null==e?void 0:e.slideDuration;this.changeLoadingAnimation(i||this.duration||5),this.variableTimeout=window.setTimeout(()=>{this.adjustWithoutFocus(),this.setVariableSpeedTransitionHandler()},1e3*(i||this.duration||5))},this.togglePlay=t=>{if(this.hoverSuspended=!0,this.activetab&&(this.activetab.children[0].style.animationPlayState="running"),null==t?void 0:t.detail){if(t.detail.playRotation&&!this.userAutoPlaySetting)return;this.play=t.detail.playRotation}else{if(!this.play&&!this.userAutoPlaySetting)return;this.play=!this.play}},this.restartRotationAfterTimeout=t=>{void 0!==t&&"number"==typeof t&&!this.disabledPlayAfterOneRotation&&this.userAutoPlaySetting&&(this.restartRotationHandler&&clearTimeout(this.restartRotationHandler),this.restartRotationHandler=window.setTimeout(()=>{this.isWindowFocused&&!this.isWindowHidden&&this.isInfopaneInViewport&&!this.isMouseOver?this.play=!0:this.resumeRotationTimerRanOut=!0},1e3*t))},this.handleMouseEnter=t=>{var e,i;!this.hoverSuspended&&(null===(i=null===(e=this.activetab)||void 0===e?void 0:e.children)||void 0===i?void 0:i.length)>0&&(this.isMouseOver=!0,clearInterval(this.slideshowHandler),this.clearVariableSpeedTransitionHandler(),this.animationTiming=this.animationTiming?(Date.now()-this.animationTiming)/1e3:0,this.activetab.children[0].style.animationPlayState="paused")},this.handleMouseLeave=t=>{var e,i;!this.hoverSuspended&&(void 0!==this.slideshowHandler||void 0!==this.variableTimeout)&&(null===(i=null===(e=this.activetab)||void 0===e?void 0:e.children)||void 0===i?void 0:i.length)>0&&this.isMouseOver&&(this.resume(),this.isMouseOver=!1,this.resumeRotationTimerRanOut&&(this.restartRotationAfterTimeout(0),this.resumeRotationTimerRanOut=!1)),this.hoverSuspended=this.disableHoverPause},this.touchEndHandler=t=>{const e=this.clientWidth,i=(0,v.sr)(t,.35,e);return i===v.ez.Right?(this.adjust(-1),t.stopPropagation(),!1):i!==v.ez.Left||(this.adjust(1),t.stopPropagation(),!1)},this.handleVisibilityChange=t=>{this.isWindowHidden="hidden"===document.visibilityState,"hidden"===document.visibilityState?(this.resumeAfterVisibilityChange=document===t.composedPath()[0]||!t.composedPath().includes(this),this.play=!1):"visible"===document.visibilityState&&this.resumeAfterVisibilityChange&&(this.play=this.userAutoPlaySetting,this.resumeAfterVisibilityChange=!1)},this.handleWindowBlur=t=>{this.isWindowFocused=!1,t&&"hidden"!==document.visibilityState&&this.play&&(this.play=!1,this.resumeAfterWindowBlur=!0)},this.handleWindowFocus=t=>{t&&(this.isWindowFocused=!0,!t.composedPath().includes(this.mediaControl)&&this.resumeAfterWindowBlur?(this.play=!0,this.resumeAfterWindowBlur=!1):this.resumeRotationTimerRanOut&&(this.restartRotationAfterTimeout(0),this.resumeRotationTimerRanOut=!1))},this.eventsAbortController=new AbortController}activeIndexChanged(t,e){this.tabs&&this.activeid&&null!==this.activeIndex&&void 0!==this.activeIndex&&(this.activeid=this.tabs[Math.min(Math.max(0,this.activeIndex),this.tabs.length-1)].id)}tabsChanged(){var t,e;super.tabsChanged(),this.tabs.length>0&&(this.tabs.length>1&&!this.slidesFullyLoaded.wasSet()&&this.slidesFullyLoaded.set(),this.tabs.forEach(t=>t._focus=t.focus),this.setTabClasses(-1,0),this.activeid=null!==(e=this.activeid)&&void 0!==e?e:null===(t=this.tabs[0])||void 0===t?void 0:t.id,this.activeIndexChanged(-1,this.activeIndex))}lazyPanelsChanged(){var t,e;this.hasNavigation=(null!==(e=null===(t=this.lazyPanels)||void 0===t?void 0:t.length)&&void 0!==e?e:0)>1,this.hasNavigation||(this.tabs=[]),this.lazyPanelTemplatePerSlide={},super.lazyPanelsChanged()}tabpanelsChanged(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[];e&&e.length&&!e.every(e=>null==t?void 0:t.includes(e))&&(this.tabpanels=e.reduce((t,e)=>t.concat(e instanceof HTMLSlotElement?Array.from(e.assignedNodes()):e),[])),this.hasNavigation=this.tabpanels.length>1,this.hasNavigation||(this.tabs=[]),super.tabpanelsChanged()}activeidChanged(t,e){var i,r;super.activeidChanged(t,e);const{tabs:o}=this,s=this.getIndexById(o,t);let a=this.getIndexById(o,e);this.lazyPanels&&a<0&&(a=0);const n=this.isForwardTransition(s,a,o.length),l=n?"left":"right";t&&(this.activeIndex=a),this.updateTabPanels(a,s,l),this.enableSingleRotation&&this.handleSingleRotation(),this.setTabClasses(n?a-1:a+1,a);const d=null===(r=null===(i=this.lazyPanels)||void 0===i?void 0:i[a])||void 0===r?void 0:r.id;this.dispatchInfopaneChangeEvent(d)}getIndexById(t,e){return e?t.findIndex(t=>t.id===e):0}isForwardTransition(t,e,i){return t===i-1&&0===e||t<e&&(e!==i-1||0!==t)}updateTabPanels(t,e,i){this.tabpanels.forEach((r,o)=>{r.classList.remove("unload-left","unload-right"),o===t?(r.classList.add(`load-${i}`),r.classList.remove("load-left","load-right")):o===e?r.classList.add(`unload-${i}`):o<t?r.classList.add("load-right"):r.classList.remove("load-right")})}handleSingleRotation(){this.slidesChanged++,this.slidesChanged===this.tabs.length+1&&(this.play=!1,this.disabledPlayAfterOneRotation=!0)}dispatchInfopaneChangeEvent(t){const e={detail:{activeIndex:this.activeIndex,isLastPanel:this.activeIndex===this.tabs.length-1,contentId:this.parentContentId,activeCardId:t}},i=new CustomEvent("infopane-change",e);document.dispatchEvent(i)}setIntersectionObserver(){if(this.intersectionObserver)return;this.intersectionObserver=new IntersectionObserver(t=>{const e=t[t.length-1],i=this.observeViewport&&!!e&&e.intersectionRatio>0,r=this.userAutoPlaySetting&&i;this.isInfopaneInViewport=i,this.play=r,this.resumeAfterWindowBlur&&(this.resumeAfterWindowBlur=r),this.resumeRotationTimerRanOut&&this.isInfopaneInViewport&&(this.restartRotationAfterTimeout(0),this.resumeRotationTimerRanOut=!1)},{threshold:[0]}),this.intersectionObserver.observe(this)}disconnectIntersectionObserver(){this.intersectionObserver&&(this.intersectionObserver.disconnect(),this.intersectionObserver=void 0)}applyUserAutoPlayPreference(t){this.userAutoPlaySetting!==t&&(this.userAutoPlaySetting=t,t?this.play||(this.play=this.observeViewport&&this.isInfopaneInViewport):this.play&&(this.play=!1))}getUserAutoPlaySetting(){const t=(0,$.Lg)().getItem("autoSettings");if(null==t)return!0;try{const e=JSON.parse(t);if("boolean"==typeof e)return e}catch(t){}return"false"!==t}setTabClasses(t,e){const{tabs:i}=this,{length:r}=i,o=this.isForward(t,e,r),{before:s,after:a}=this.calculateBeforeAfter(e,o,r);this.shouldSkipClassUpdate(o,e)||(this.resetSequenceIndices(),i.forEach((t,i)=>{this.updateTabClass(t,i,e,s,a,o,r)}))}isForward(t,e,i){return void 0===t||t===i-1&&0===e||t<e&&(e!==i-1||0!==t)}calculateBeforeAfter(t,e,i){const r=Math.floor(this.tabCount/2),o=e?2+Math.min(t,r):this.tabCount-Math.min(i-t,3);return{before:o,after:this.tabCount-o+1}}shouldSkipClassUpdate(t,e){return!t&&this.endOfSequenceIndex&&e+1===this.endOfSequenceIndex?(this.endOfSequenceIndex=void 0,!0):!(!t||!this.startOfSequenceIndex||e!==this.startOfSequenceIndex)&&(this.startOfSequenceIndex=void 0,!0)}resetSequenceIndices(){this.endOfSequenceIndex=void 0,this.startOfSequenceIndex=void 0}updateTabClass(t,e,i,r,o,s,a){const n=i-r,l=i+o;t.classList.remove("hide","small","smaller"),a>this.tabCount&&(this.updateTabClassVisibility(t,e,n,l),this.updateTabClassSize(t,e,n,l),this.updateTabClassSequence(t,e,i,s,a,n,l))}updateTabClassVisibility(t,e,i,r){(e<i||e>r)&&t.classList.add("hide")}updateTabClassSize(t,e,i,r){e===i||e===r?t.classList.add("smaller"):e!==i+1&&e!==r-1||t.classList.add("small")}updateTabClassSequence(t,e,i,r,o,s,a){r&&i>=1&&i<o-1&&e===a-2?this.endOfSequenceIndex=e:!r&&i>=1&&i<o-1&&e===s+2&&(this.startOfSequenceIndex=e)}playChanged(t,e){e||(this.adjustSuspended=!0),this.autoScrollHandler()}autoScrollHandler(){clearInterval(this.slideshowHandler),this.clearVariableSpeedTransitionHandler(),this.play&&this.hasSlideShow&&this.userAutoPlaySetting&&(this.adjustSuspended||this.adjustWithoutFocus(),this.adjustSuspended=!1,this.animationTiming=Date.now(),this.enableVariableSpeed&&this.variableTransitionMap?this.setVariableSpeedTransitionHandler():(this.slideshowHandler=window.setInterval(this.adjustWithoutFocus.bind(this),1e3*(this.duration||5)),this.wpoRotationDuration&&this.wpoRotationDuration!==this.duration&&((0,p.vV)(u.tFD,"Infopane rotation duration mismatch.","WpoDuration: "+this.wpoRotationDuration+"; ActualDuration: "+this.duration),this.wpoRotationDuration=this.duration)))}lazyPanelTemplateChanged(){this.lazyPanelTemplatePerSlide={}}getLazyPanelTemplateForSlide(t){return this.currentActiveIndexRendered=!!this.lazyPanelTemplatePerSlide[t],this.currentActiveIndexRendered||(this.lazyPanelTemplatePerSlide[t]=s.qy`
                ${this.lazyPanelTemplate}
            `),this.lazyPanelTemplatePerSlide[t]}adjust(t){const e=this.tabs.findIndex(t=>t.id===this.activeid),i=(0,a.Vf)(0,this.tabs.length-1,e+t),r=this.tabs[i];r&&(this.activeid=r.id,r.focus(),this.$emit("change",{nextTab:r,adjustment:t}))}adjustWithoutFocus(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:1;this.config.enableInfopaneFocusCheck&&this.hasFocusIn||this.tabs&&this.tabs.length>0&&(this.animationTiming=Date.now(),this.tabs.forEach(t=>{t.focus=()=>!1}),this.adjust(t),this.activetab.children[0].style.animationPlayState="running",this.tabs.forEach(t=>t.focus=t._focus))}clearVariableSpeedTransitionHandler(){this.variableTimeout&&window.clearTimeout(this.variableTimeout),this.variableTimeout=null}resume(){if(!this.userAutoPlaySetting)return;const{duration:t,animationTiming:e=0}=this;this.activetab.children[0].style.animationPlayState="running",clearInterval(this.slideshowHandler),this.clearVariableSpeedTransitionHandler(),this.slideshowHandler=window.setTimeout(this.playChanged.bind(this,!1,!0),1e3*(t-e)),this.animationTiming=Date.now()-1e3*(this.animationTiming||0)}handleMediaClick(t){this.hoverSuspended=!0,this.activetab.children[0].style.animationPlayState="running";const e=!this.play;e?n.L.enqueue(()=>{this.observeViewport=!0}):this.observeViewport=!1,this.play=e}handleKeydown(t){return t.key===l.gG&&this.togglePlay(),this.observeViewport=!1,!0}handleFocusIn(t){return t&&this.play&&(this.play=!1),!0}handleClick(t){const e=t.composedPath();return e.find(t=>{var e;return null===(e=t.classList)||void 0===e?void 0:e.contains("media-control")})||(this.play=!1,clearInterval(this.slideshowHandler),this.clearVariableSpeedTransitionHandler(),this.restartRotationAfterTimeout(this.restartRotationTimer)),e.find(t=>"A"===t.tagName)&&window.dispatchEvent(new CustomEvent("infopaneAnchorTagClicked")),e.find(t=>{var e,i,r;return(null===(e=t.classList)||void 0===e?void 0:e.contains("next-flipper"))||(null===(i=t.classList)||void 0===i?void 0:i.contains("previous-flipper"))||(null===(r=t.classList)||void 0===r?void 0:r.contains("tab"))})&&window.dispatchEvent(new CustomEvent("infopaneFlipperTabClicked")),this.observeViewport=void 0!==this.restartRotationTimer,!0}changeLoadingAnimation(t){void 0!==this.styles&&this.$fastController.removeStyles(this.styles),this.styles=d.A`
            :host {
                --loading-duration: ${t}s;
            }
        `,this.$fastController.addStyles(this.styles)}disconnectedCallback(){super.disconnectedCallback(),this.slideshowHandler&&clearInterval(this.slideshowHandler),this.clearVariableSpeedTransitionHandler(),this.disconnectIntersectionObserver(),this.eventsAbortController.abort()}connectedCallback(){var t,e;if(super.connectedCallback(),this.config=C.D.getConfig(),this.setFlightAttributes(),(null===(t=this.config)||void 0===t?void 0:t.enableUserAutoPlaySettings)&&(this.userAutoPlaySetting=this.getUserAutoPlaySetting()),this.setIntersectionObserver(),(0,y.D)(this),!(0,b.S)()){const t=(0,g.gU)();return(0,m.cE)(g.gB,t),void(0,f.up)({name:g.gB,time:t})}(0,b.S)()&&this.hasAttribute(x.G4)&&(0,x._Z)(this).then(()=>{var t;window.isSSREnabled&&(this.config=C.D.getConfig(),(null===(t=this.config)||void 0===t?void 0:t.enableUserAutoPlaySettings)&&(this.userAutoPlaySetting=this.getUserAutoPlaySetting()),this.togglePlay(),window.setTimeout(()=>{this.config.enableInfopaneRotationFix?this.slidesFullyLoaded.getResultAsync().then(()=>{this.togglePlay({detail:{playRotation:!1}}),this.togglePlay({detail:{playRotation:!0}})}):this.togglePlay()},1e3*(this.duration||5)-1500))});const i=this.eventsAbortController.signal;window.addEventListener("blur",this.handleWindowBlur,{signal:i}),window.addEventListener("focus",this.handleWindowFocus,{signal:i}),window.addEventListener("toggleInfopaneRotation",this.togglePlay,{signal:i}),(null===(e=this.config)||void 0===e?void 0:e.enableUserAutoPlaySettings)&&window.addEventListener("auto-play-changed",this.handleAutoPlayPreferenceChanged,{signal:i}),window.addEventListener("onFeedRefreshed",()=>{var t;this.activeid=null===(t=this.tabs[0])||void 0===t?void 0:t.id},{signal:i}),document.addEventListener("visibilitychange",this.handleVisibilityChange,{signal:i}),this.addEventListener("mouseenter",this.handleMouseEnter,{signal:i}),this.addEventListener("mouseleave",this.handleMouseLeave,{signal:i}),this.isTouchDisabled||(0,v.Av)(this,this.touchEndHandler,i)}setFlightAttributes(){this.msn=this.config.enableMsnCardStyle,this.useAmpHoverEffect=this.config.useAmpHoverEffect}}(0,r.Cg)([(0,c.CF)({converter:c.R$})],k.prototype,"duration",void 0),(0,r.Cg)([h.sH],k.prototype,"hasSlideShow",void 0),(0,r.Cg)([h.sH],k.prototype,"restartRotationTimer",void 0),(0,r.Cg)([(0,c.CF)({attribute:"media-controls",converter:c.Bs})],k.prototype,"hasMediaControls",void 0),(0,r.Cg)([(0,c.CF)({attribute:"tab-count"})],k.prototype,"tabCount",void 0),(0,r.Cg)([(0,c.CF)({mode:"boolean",attribute:"touch-disabled",converter:c.Bs})],k.prototype,"isTouchDisabled",void 0),(0,r.Cg)([(0,c.CF)({attribute:"play-telemetry"})],k.prototype,"playTelemetry",void 0),(0,r.Cg)([(0,c.CF)({attribute:"pause-telemetry"})],k.prototype,"pauseTelemetry",void 0),(0,r.Cg)([(0,c.CF)({attribute:"tab-telemetry"})],k.prototype,"tabTelemetry",void 0),(0,r.Cg)([(0,c.CF)({mode:"boolean",attribute:"disable-hover-pause",converter:c.Bs})],k.prototype,"disableHoverPause",void 0),(0,r.Cg)([h.sH],k.prototype,"tabs",void 0),(0,r.Cg)([h.sH],k.prototype,"tabpanels",void 0),(0,r.Cg)([h.sH],k.prototype,"mediaControl",void 0),(0,r.Cg)([h.sH],k.prototype,"wpoRotationDuration",void 0),(0,r.Cg)([h.sH],k.prototype,"enableSingleRotation",void 0),(0,r.Cg)([h.sH],k.prototype,"variableTransitionMap",void 0),(0,r.Cg)([h.sH],k.prototype,"enableVariableSpeed",void 0),(0,r.Cg)([h.sH],k.prototype,"hasFocusIn",void 0),(0,r.Cg)([h.sH],k.prototype,"parentContentId",void 0),(0,r.Cg)([(0,c.CF)({attribute:"active-index"})],k.prototype,"activeIndex",void 0),(0,r.Cg)([(0,c.CF)({attribute:"preload-panels",converter:c.R$})],k.prototype,"preloadPanels",void 0),(0,r.Cg)([(0,c.CF)({attribute:"msn",mode:"boolean"})],k.prototype,"msn",void 0),(0,r.Cg)([(0,c.CF)({attribute:"use-amp-hover-effect",mode:"boolean"})],k.prototype,"useAmpHoverEffect",void 0),(0,r.Cg)([h.sH],k.prototype,"hasNavigation",void 0),(0,r.Cg)([(0,c.CF)({attribute:"navigation-position"})],k.prototype,"navigationPosition",void 0),(0,r.Cg)([(0,c.CF)({mode:"boolean",converter:c.Bs})],k.prototype,"play",void 0),(0,r.Cg)([h.sH],k.prototype,"currentActiveIndexRendered",void 0);var P=i(82774),S=i(10108),_=i(39957),A=i(69259),D=i(416),R=i(60402);const T=s.qy`<slot class="panels" part="panels" ${(0,P.e)({property:"tabpanels",filter:(0,S.Y)()})}></slot>`,I=s.qy` ${t=>s.qy` ${(0,_.ux)(t=>{var e,i;return t.lazyPanels[null!==(e=t.activeIndex)&&void 0!==e?e:0]?[t.lazyPanels[null!==(i=t.activeIndex)&&void 0!==i?i:0].data]:[]},e=>{var i;return t.getLazyPanelTemplateForSlide(null!==(i=t.activeIndex)&&void 0!==i?i:0)})} `} ${(0,A.z)(t=>{var e;return(null===(e=t.lazyPanels)||void 0===e?void 0:e.length)>1},s.qy`<div class="preload-panels">${(0,_.ux)(t=>{var e,i,r,o,s;const a=null!==(r=t.activeIndex)&&void 0!==r?r:0,n=Math.min(a+(null!==(o=t.preloadPanels)&&void 0!==o?o:0),(null===(e=t.lazyPanels)||void 0===e?void 0:e.length)-1);return null!==(s=null===(i=t.lazyPanels)||void 0===i?void 0:i.slice(a+1,n+1))&&void 0!==s?s:[]},s.qy` ${(0,_.ux)(t=>[t.data],(t,e)=>e.parent.lazyPanelTemplate)} `)}</div>`)}
`,M=s.qy`<template @click="${(t,e)=>t.handleClick(e.event)}" @focusin="${(t,e)=>t.handleFocusIn(e.event)}" @mouseover="${t=>t.hasFocusIn=!0}" @mouseout="${t=>t.hasFocusIn=!1}" @keydown="${(t,e)=>t.handleKeydown(e.event)}" ?data-nopartialcontentview="${t=>t.currentActiveIndexRendered}">${(0,A.z)(t=>t.hasNavigation,s.qy`<div class="navigation ${t=>t.hasSlideShow&&t.hasMediaControls?"with-controls":""} ${t=>t.play&&t.hasSlideShow?"playing":""} ${t=>t.navigationPosition}" part="navigation"><div class="tablist" part="tablist" role="tablist" ${(0,D.Y)({property:"tabs",filter:(0,S.Y)()})}>${(0,_.ux)(t=>t.lazyPanels||t.tabpanels,s.qy`<div class="tab" part="tab" slot="tab" role="tab" data-t="${(t,e)=>e.parent.tabTelemetry}"><div class="dot" part="dot"></div></div>`,{positioning:!0})}</div>${(0,A.z)(t=>!!t.hasSlideShow&&!!t.hasMediaControls,s.qy`<div class="media-control" part="media-control" @click="${(t,e)=>t.handleMediaClick(e.event)}" ${(0,R.K)("mediaControl")}>${(0,A.z)(t=>!!t.play,s.qy`<slot name="pause-icon" data-t="${t=>t.pauseTelemetry}">⏸&#xFE0E;</slot>`,s.qy`<slot name="play-icon" data-t="${t=>t.playTelemetry}">⏵&#xFE0E;</slot>`)}</div>`)}</div><slot name="previous-flipper" class="previous-flipper" part="previous-flipper" @click="${t=>t.adjust(-1)}"></slot><slot name="next-flipper" class="next-flipper" part="next-flipper" direction="next" @click="${t=>t.adjust(1)}"></slot>`)} ${(0,A.z)(t=>t.lazyPanels,I,T)}</template>`;var O=i(4126),z=i(26920),B=i(74838),U=i(62047),F=i(57416),L=i(86856),E=i(13187);const N=d.A` :host{border-radius:4px;width:100%}`,q=d.A` :host{--infopane-child-transform-override:none}`,H=d.A` :host{align-items:center;display:inline-block;overflow:hidden;position:relative;height:var(--card-height,100%);width:var(--override-card-wide-width,${E.k9});border-radius:8px;box-shadow:0px 1px 2px rgba(0,0,0,0.14),0px 0px 2px rgba(0,0,0,0.12);--dot-active-hover-size:3px;--dot-hover-size:5px;--dot-selected-height:6px;--dot-selected-width:16px;--dot-size:4px;--dot-small-size:3px;--dot-smaller-size:2px;--slide-transition-duration:0s}:host([size="1u"]),:host([size="_1x_2y"]){width:var(--override-card-width,var(--card-min-width,${E.DA}))}:host(:hover){box-shadow:0px 2px 4px rgba(0,0,0,0.14),0px 0px 2px rgba(0,0,0,0.12)}.navigation{align-items:center;display:inline-flex;gap:calc(${z.XA} * 1px);
        left: 50%;
        position: absolute;
        top: calc(${B.vR} * 2px);transform:translateX(-50%);z-index:calc(var(--sloppy-click-z-index,2) + 1)}.navigation.bottom{bottom:calc(${B.vR} * 3px);top:auto}.tablist{background:rgba(0,0,0,0.72);border-radius:9px;min-height:14px;padding:0 6px;font-size:0;min-width:52px}.with-controls .tablist{border-radius:0;border-end-start-radius:9px;border-start-start-radius:9px}.tab,.trail-start + .tab ~ .tab{cursor:pointer;display:inline-block;height:14px;position:relative;transition:width 0.3s ease-in-out;width:8px}.tab:focus-visible{outline:none}.tab:focus-visible .dot{box-shadow:0 0 0 1px rgba(0,0,0,0.72),0 0 0 3px rgba(255,255,255,0.42)}.dot{background:rgba(255,255,255,0.42);border-radius:3px;display:inline-block;height:var(--dot-size);left:50%;position:absolute;top:50%;transform:translate(-50%,-50%);transition:width 0.3s ease-in-out,height 0.3s ease-in-out;width:var(--dot-size)}@media screen and (prefers-contrast:more){.dot{filter:invert(1)}}.tab:hover .dot,.tab[aria-selected="true"] .dot{background:rgba(255,255,255,0.786)}.small .dot{height:var(--dot-small-size);width:var(--dot-small-size)}.smaller .dot{height:var(--dot-smaller-size);width:var(--dot-smaller-size)}.tab[aria-selected="false"]:hover .dot{height:var(--dot-hover-size);width:var(--dot-hover-size)}.tab[aria-selected="false"]:active:hover .dot{height:var(--dot-active-hover-size);width:var(--dot-active-hover-size)}.hide,.hide .dot{height:0;width:0;transition:none}.tab[aria-selected="true"]{width:20px}.tab[aria-selected="true"] .dot{height:var(--dot-selected-height);width:var(--dot-selected-width)}.link{display:inline-block}.playing .tab[aria-selected="true"] .dot{animation:loading var(--loading-duration) linear;background:linear-gradient(90deg,#fff 50%,rgba(255,255,255,0.42) 50%);background-size:200% 100%}:host(.no-nav-anim) .tab[aria-selected="true"] .dot{animation:none}.media-control{background:rgba(0,0,0,0.72);border-end-end-radius:9px;border-start-end-radius:9px;color:#fff;cursor:pointer;display:inline-block;fill:#fff;font-family:"Segoe UI Symbol",monospace;font-size:${U.t};height:14px;line-height:13px;text-align:center;user-select:none;width:14px}.media-control:hover{background:rgba(0,0,0,0.92)}:host slot.panels::slotted([id^="panel"]){left:0;position:relative;transition:left var(--slide-transition-duration,0.3s) ease-out}:host slot.panels::slotted([hidden]){display:inline-block;position:absolute;top:0}:host slot.panels::slotted(.dense-card-container){width:100%;height:100%;overflow:hidden;background:var(--fill-color);--heading-font-size:20px;--heading-line-height:28px}.previous-flipper,.next-flipper{display:block;opacity:0;position:absolute;text-align:center;top:50%;transform:translateY(-50%);transition:opacity linear 0.3s;z-index:calc(var(--sloppy-click-z-index,2) + 1)}.previous-flipper{inset-inline-start:2px}.next-flipper{inset-inline-end:2px}:host(.tsp-flippers) .previous-flipper,:host(.tsp-flippers) .next-flipper{opacity:0.5}:host(.no-margin-flippers) .previous-flipper,:host(.no-margin-flippers) .next-flipper{right:0px}.previous-flipper::before,.next-flipper::before{border-radius:calc(${F.Pb} * 1px)}:host(:hover) .previous-flipper,:host(:hover) .next-flipper{opacity:1}.preload-panels{display:none}@media (forced-colors:active) and (prefers-color-scheme:dark){:host{--flipperInvert:100%}}@media (forced-colors:active){:host{border:1px solid}}`.withBehaviors(new O.o("msn",!0,N),new O.o("useAmpHoverEffect",!0,q),new L.t(d.A` :host(.no-margin-flippers) .previous-flipper{left:0px;right:auto}:host slot.panels::slotted([hidden]){left:100%;margin-inline-start:8px}:host slot.panels::slotted(.unload-left),:host slot.panels::slotted(.load-right){left:-100%;margin-inline-start:-8px}:host slot.panels::slotted(.unload-right){left:100%;margin-inline-start:8px}@keyframes loading{0%{background-position:100% 0}100%{background-position:0 0}}`,d.A` :host(.no-margin-flippers) .next-flipper{left:0px;right:auto}:host slot.panels::slotted([hidden]){left:-100%;margin-inline-end:-8px}:host slot.panels::slotted(.unload-left),:host slot.panels::slotted(.load-right){left:100%;margin-inline-end:8px}:host slot.panels::slotted(.unload-right){left:-100%;margin-inline-end:-8px}@keyframes loading{0%{background-position:-100% 0}100%{background-position:0 0}}::slotted(.previousFlipper),::slotted(.nextFlipper){transform:scaleX(-1)}`));var W=i(65614);const j=k.compose({name:"cs-responsive-infopane",template:M,styles:H,shadowOptions:{delegatesFocus:!0}}),J=()=>{j.define(W.G.registry)}},62745(t,e,i){i.d(e,{KU(){return l},LY(){return c},_u(){return h},vB(){return p}});var r=i(77809);const o=3600,s=120,a=new RegExp("\\:([\\d]{2})");function n(){return new Date}function l(t){return(n().getTime()-t.getTime())/1e3}function d(t,e){return new Date(t.getFullYear(),t.getMonth(),t.getDate()+e,t.getHours(),t.getMinutes(),t.getSeconds(),t.getMilliseconds())}function c(t,e){return new Date(t.valueOf()+60*e*60*1e3)}function h(t,e){const i=parseInt(e),r=parseInt(a.exec(e)[1]),o=i<0?-1:1,s=new Date(t.getTime()+60*(60*i+o*r)*1e3),n=`0${Math.abs(i)}`.substr(-2)+":"+`0${Math.abs(r)}`.substr(-2);return s.toISOString().replace("Z",(o<0?"-":"+")+n)}function p(t){const e=l(t),i=function(){const t=n();return t.setHours(0,0,0,0),t}(),a=d(i,-1),c=d(i,-6),h=function(){const t=n();return new Date(t.getFullYear(),0,0,0,0,0,0)}();return e>=-3300&&e<-60?r.H.InMinutes:e<0?r.H.None:e<s?r.H.JustNow:e<o?r.H.LessThanOneHour:t>=i?r.H.Today:t>=a?r.H.Yesterday:t>=c?r.H.ThisWeek:t>=h?r.H.ThisYear:r.H.FullDate}},64183(t,e,i){i.d(e,{o(){return a},t(){return s}});var r=i(68009),o=i(49399);function s(t,e,i,o,s,a,n){const l=t.closestIndexOf(e);return null==n&&(n=(0,r.F)(e)),{rest:t.get(l+n*i),hover:t.get(l+n*o),active:t.get(l+n*s),focus:t.get(l+n*a)}}function a(t,e,i,r,a,n,l=void 0,d,c,h,p,u=void 0){return(0,o.H)(e)?s(t,e,d,c,h,p,u):s(t,e,i,r,a,n,l)}},69488(t,e,i){i.d(e,{K(){return a},O(){return n}});var r=i(96950),o=i(65055),s=i(89780);const a=r.qy`
    ${t=>t.configInfo&&(0,o.yN)(t.configInfo,{properties:{mapperArgs:t.mapperArgs,parentTelemetry:t.telemetryObject,feedLayoutCardSize:t.cardSize},attributes:{style:`grid-area:${t.gridArea}`,class:`${t.cardSize}`},telemetryObject:t.telemetryObject})}
`,n={getFeedDataForCard(t){return(0,s.BQ)(t)},viewTemplate:a}},70536(t,e,i){i.d(e,{f(){return n}});var r=i(41298),o=i(22341),s=i(93552),a=i(35639);const n={getFeedDataForCard(t){return function(t){try{var e;const{configOptions:i,cardMetadata:r,parentTelemetryObject:o,openLinksInNewTab:s,sdCardActionClickHandler:n,useInlineSvgIcons:l,refreshFeedCallback:d,goToPersonalizeSettingsCallback:c}=t,h="shopping-carousel",p={id:h,childTemplateType:"shopping-carousel-card",openLinksInNewTab:s,sdCardActionClickHandler:n,refreshFeedCallback:d,goToPersonalizeSettingsCallback:c,parentTelemetryObject:o,shoppingCardMetadata:r,shoppingCarouselCardConfigInfo:i&&i,useInlineSvgIcons:l};return(0,a.bw)({id:h,experienceType:null===(e=p.shoppingCarouselCardConfigInfo)||void 0===e||null===(e=e.configRef)||void 0===e?void 0:e.experienceType,mapperArgs:t},p)}catch(t){(0,o.c_)(t,s.Odo,"Error in Shopping Carousel Mapper")}}(t)},viewTemplate:r.j}},70635(t,e,i){i.d(e,{Y(){return r},s(){return c}});var r,o=i(56911),s=i(60815),a=i(96950),n=i(92011),l=i(38493);!function(t){t.single="single",t.double="double",t.split="split",t.triple="triple",t.mosaic="mosaic",t.list="list"}(r||(r={}));const d=new Map;class c extends n.L{constructor(){super(...arguments),this.dividerTemplate=null,this.layout=r.single}itemsChanged(t,e){this.$fastController.isConnected&&(this.dividerTemplate=function(t){if(d.has(t))return d.get(t);if(t<1)return d.set(t,null),null;const e=new Array(t).fill("").map((t,e)=>a.qy`<div class="divider divider-${e+1}" part="divider"></div>`).reduce((t,e)=>a.qy`${t}${e}`);return d.set(t,e),e}(this.items.length-1))}}(0,o.Cg)([s.sH],c.prototype,"items",void 0),(0,o.Cg)([s.sH],c.prototype,"dividerTemplate",void 0),(0,o.Cg)([l.CF],c.prototype,"layout",void 0),(0,o.Cg)([l.CF],c.prototype,"topic",void 0)},71608(t,e,i){i.d(e,{Af(){return v}});var r=i(92687),o=i(96950),s=i(60402);const a=o.qy`<span part="image" ${(0,s.K)("imageContainer")}><slot name="image" ${(0,s.K)("image")} @slotchange=${t=>t.handleImageContentChange()}></slot></span><span part="content" class="content"><slot></slot></span>`;var n=i(74849),l=i(64187),d=i(22131),c=i(7896),h=i(61138),p=i(64003),u=i(74838),g=i(50882);const m=n.A`
        ${(0,l.V)("inline-flex")} :host{box-sizing:border-box;font-family:${c.O};
            font-size: ${h.k};
            font-weight: 400;
            line-height: ${h.F};
            align-items: center;
            color: ${p.c};min-height:16px}.content{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.image{display:flex;margin-inline-end:calc(${u.vR} * 2px);
        }
    `.withBehaviors((0,d.mr)(n.A` :host,.content{color:${g.A.CanvasText};
                    fill: currentcolor;
                }
            `));var f=i(99900);const v=r.m.compose({name:`${f.i.prefix}-attribution`,template:a,styles:m})},72526(t,e,i){i.d(e,{L(){return g}});var r=i(56911),o=i(96193),s=i(47429),a=i(60815),n=i(22870),l=i(38493),d=i(95239),c=i(31023),h=i(24458),p=i(5291),u=i(57606);class g extends o.z{cardFillColorChanged(t,e){if(e){const t=(0,n.Hs)(e);null!==t&&(this.neutralPaletteSource=e,d.p.setValueFor(this,p.q.create(t.r,t.g,t.b)))}}neutralPaletteSourceChanged(t,e){if(e){const t=(0,n.Hs)(e),i=p.q.create(t.r,t.g,t.b);c.r.setValueFor(this,u.p.create(i))}}handleChange(t,e){this.cardFillColor||d.p.setValueFor(this,t=>t(h.M3).evaluate(t,t(d.p)))}connectedCallback(){super.connectedCallback();const t=(0,s.Zo)(this);if(t){const e=a.cP.getNotifier(t);e.subscribe(this,"fillColor"),e.subscribe(this,"neutralPalette"),this.handleChange(t,"fillColor")}}}(0,r.Cg)([(0,l.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,r.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,r.Cg)([(0,l.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,r.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0)},73526(t,e,i){i.d(e,{s(){return r}});const r=i(96950).qy`
<div 
    id="${t=>t.id}"
    style="grid-area:${t=>t.gridArea};
    ${t=>"DisplayAdBanner"===t.type?"display: flex; justify-content: center; overflow: hidden;":""}
    ${t=>"DisplayAdBanner"===t.type&&"_1x_2y"===t.cardSize?"max-width: 300px;":""}
    ${t=>"DisplayAdBanner"===t.type&&"_2x_2y"===t.cardSize?"max-width: 612px;":""}"
    class="${t=>t.cardSize}"
> 
    <display-ads 
        config-instance-src="${t=>t.configInstanceSrc}" 
        instance-id="${t=>t.instanceId}" 
        :enableExtraAdSlug="${t=>t.enableExtraAdSlug}"
        :shimmerIdOverride="${t=>t.shimmerIdOverride}"
        :batchCallAdCountOverride="${t=>t.batchCallAdCountOverride}"
        :pageTypeOverride="${t=>t.pageTypeOverride}"
    >
    
    </display-ads>
</div>
`},75003(t,e,i){i.d(e,{m(){return n}});var r=i(37180),o=i(72526),s=i(37256),a=i(38380);const n=o.L.compose({name:`${r.c.prefix}-card`,template:a.v,styles:s.R})},75261(t,e,i){i.d(e,{t(){return n}});var r=i(56911),o=i(60815),s=i(92011),a=i(38493);class n extends s.L{constructor(){super(...arguments),this.percentComplete=0}valueChanged(){this.updatePercentComplete()}minChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}maxChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}connectedCallback(){super.connectedCallback(),this.updatePercentComplete()}updatePercentComplete(){const t="number"==typeof this.min?this.min:0,e="number"==typeof this.max?this.max:100,i="number"==typeof this.value?this.value:0,r=e-t;this.percentComplete=0===r?0:Math.fround((i-t)/r*100)}}(0,r.Cg)([(0,a.CF)({converter:a.R$}),(0,r.Sn)("design:type",Object)],n.prototype,"value",void 0),(0,r.Cg)([(0,a.CF)({converter:a.R$}),(0,r.Sn)("design:type",Number)],n.prototype,"min",void 0),(0,r.Cg)([(0,a.CF)({converter:a.R$}),(0,r.Sn)("design:type",Number)],n.prototype,"max",void 0),(0,r.Cg)([(0,a.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],n.prototype,"paused",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Number)],n.prototype,"percentComplete",void 0)},75307(t,e,i){i.d(e,{Bl(){return p},Eo(){return d},KN(){return l},LG(){return c},Mj(){return u},kg(){return n},x8(){return h}});var r=i(58792),o=i(99476),s=i(26363),a=i(77367);function n(){const t=(0,o.a)();return!!t&&("1"===t.get("vptest")||"true"===t.get("vptest")||"vp"===t.get("reqsrc"))}function l(t,e){return d(t,e,"shopping/product-tracking")}function d(t,e,i){if("local"===e&&window.location.origin.indexOf("localhost")>-1)return`http://127.0.0.1:3000/shopping/${t}.svg`;if(t){const o=e?`pr-${e}`:"latest",s=i?`${i}`:"shopping";return`${(0,r.rA)().StaticsUrl}${o}/${s}/${t}.svg`}return""}function c(t){return t&&t.href&&(t.href=h(t.href)),!0}function h(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;const i=(new Date).getTime()+e,r=(0,s.G)(),o=new URL(t);return o.searchParams.set("ts",i.toString()),o.searchParams.set("m_clk",`sid-${r}`),o.toString()}function p(t){return!!t&&/p4psearch\.1688\.com/.test(t)}function u(t,e){if(t&&t.href){const i=new URL(t.href);i.searchParams.set("m_ac","176674350"),i.searchParams.set("PageId",a.YT.getRequestId()),i.searchParams.set("ct",e),t.href=h(i.toString())}return!0}},76844(t,e,i){i.d(e,{Q(){return a}});var r=i(30758),o=i(35639),s=i(89780);const a={getFeedDataForCard(t){return function(t){var e;const{cardMetadata:i,configOptions:r,parentTelemetryObject:a,visualReadinessCallback:n}=t;if(r&&r.useSharedTelemetry)return(0,s.BQ)(t,"trending-now-card");const l=r&&r,d={id:"trendingNowCard",childTemplateType:"trending-now-card",parentTelemetryObject:a,visualReadinessCallback:n,trendingNowCardConfigInfo:l,trendingNowCardMetadata:i};return(0,o.bw)({id:"trendingNowCard",experienceType:null==l||null===(e=l.configRef)||void 0===e?void 0:e.experienceType,mapperArgs:t},d,null,!0)}(t)},viewTemplate:r.A}},77809(t,e,i){var r;i.d(e,{H(){return r}}),function(t){t[t.None=0]="None",t[t.JustNow=1]="JustNow",t[t.LessThanOneHour=2]="LessThanOneHour",t[t.Today=3]="Today",t[t.Yesterday=4]="Yesterday",t[t.ThisWeek=5]="ThisWeek",t[t.ThisYear=6]="ThisYear",t[t.FullDate=7]="FullDate",t[t.InMinutes=8]="InMinutes"}(r||(r={}))},87993(t,e,i){i.d(e,{S(){return r},m(){return d}});var r,o=i(56911),s=i(60815),a=i(92011),n=i(38493),l=i(94407);!function(t){t.default="default",t.condensed="condensed",t.infoPane="infoPane",t.infoPane1x3y="infoPane1x3y",t.infoPaneSplitVertical="infoPaneSplitVertical",t.infoPaneSplitHorizontal="infoPaneSplitHorizontal"}(r||(r={}));class d extends a.L{constructor(){super(...arguments),this.layout=r.default,this.headinglevel=3}handleStartActionsContentChange(){this.startActionsContainer.classList.toggle("start-actions",this.startActions.assignedNodes().length>0)}handleEndActionsContentChange(){this.endActionsContainer.classList.toggle("end-actions",this.endActions.assignedNodes().length>0)}abstractChanged(){this.$fastController.isConnected&&(this.hasAbstract=this.abstract.length>0)}handleMediaContentChange(){this.mediaContainer.classList.toggle("media",this.media.assignedNodes().length>0)}handleContentCardLinkClick(t){return this.handleContentCardClickOverride?this.handleContentCardClickOverride(t):(this.$emit("link-invoked",t),!0)}connectedCallback(){super.connectedCallback(),this.addEventListener("mouseover",this.mouseOver),this.addEventListener("mouseout",this.mouseOut),this.addEventListener("focusin",this.focusIn),this.addEventListener("focusout",this.focusOut)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mouseover",this.mouseOver),this.removeEventListener("mouseout",this.mouseOut),this.removeEventListener("focusin",this.focusIn),this.removeEventListener("focusout",this.focusOut)}mouseOver(){this.setExpanded(!0),this.hasHover=!0}mouseOut(){this.hasFocus||this.setExpanded(!1),this.hasHover=!1}focusIn(){this.setExpanded(!0),this.hasFocus=!0}focusOut(){this.hasHover||this.setExpanded(!1),this.hasFocus=!1}filteredContentIndicator(){return this.contentIndicatorNodes.filter(t=>t instanceof l.L)}setExpanded(t){this.filteredContentIndicator().forEach(e=>e.expanded=t)}}(0,o.Cg)([n.CF],d.prototype,"layout",void 0),(0,o.Cg)([(0,n.CF)({attribute:"heading-level",mode:"fromView",converter:n.R$})],d.prototype,"headinglevel",void 0),(0,o.Cg)([(0,n.CF)({mode:"fromView"})],d.prototype,"href",void 0),(0,o.Cg)([s.sH],d.prototype,"isGrid",void 0),(0,o.Cg)([s.sH],d.prototype,"anchorTelemetryTag",void 0),(0,o.Cg)([s.sH],d.prototype,"mediaNodes",void 0),(0,o.Cg)([s.sH],d.prototype,"hasAbstract",void 0),(0,o.Cg)([s.sH],d.prototype,"abstract",void 0),(0,o.Cg)([s.sH],d.prototype,"iconSlottedNodes",void 0),(0,o.Cg)([(0,n.CF)({attribute:"image-priority",mode:"boolean"})],d.prototype,"imagePriority",void 0),(0,o.Cg)([n.CF],d.prototype,"target",void 0),(0,o.Cg)([s.sH],d.prototype,"hoverActionsSlottedNodes",void 0),(0,o.Cg)([s.sH],d.prototype,"handleContentCardClickOverride",void 0),(0,o.Cg)([s.sH],d.prototype,"contentIndicatorNodes",void 0)},89167(t,e,i){i.d(e,{$c(){return u},DH(){return w},F7(){return b},Ts(){return r},X9(){return g},dN(){return f},eA(){return m},h3(){return C},wA(){return c},wQ(){return x},wW(){return p},zt(){return v}});var r,o=i(26220),s=i(77367),a=i(58792),n=i(27233),l=i(75307),d=i(29853);function c(t){return new URLSearchParams((0,o.iA)()).get(t)}function h(t){const e=["modal-offer-ids","modal-image-ids","pid","title","clksrc","modal-ec-ids"];for(let i=0;i<e.length;i++){const r=e[i];t.delete(r)}}function p(t){let e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],i=arguments.length>2&&void 0!==arguments[2]&&arguments[2];const r=new URLSearchParams(location.search);e&&h(r),i&&r.delete("disableheader"),t&&t.forEach((t,e)=>{r.set(e,t)});const o=new URLSearchParams;return r.getAll("item").forEach(t=>o.append("item",t)),r.delete("item"),`${r}${o.getAll("item").length>0?"&"+decodeURIComponent(o.toString()):""}`}function u(t,e){const i=new URLSearchParams(t);return e&&e.forEach((t,e)=>{i.set(e,t)}),i}!function(t){t.ClickSourceQueryParam="clksrc",t.ModalCarouselOfferIdsQueryParam="modal-offer-ids",t.ModalCarouselImageIdsQueryParam="modal-image-ids",t.ModalCarouselECIdsQueryParam="modal-ec-ids",t.gameFirstPositionQueryParam="game-first-position",t.itemQueryParam="item",t.AutoShowEdgeSidePane="auto_show_edge_shopping_pane",t.FeaturedComponentKey="featc",t.FeaturedComponentIndex="feati"}(r||(r={}));class g{static getSchemeAndDomain(){return window.location.origin.indexOf("localhost")>-1?window.location.origin:`https://${a.T3.NavTargetHostName}`}}const m=Object.freeze({NtpSdCard:"SDPDP1",NtpEventCard:"NTPMIT",NtpEventCard2:"NTPMIF",NtpCarousel:"CARPDP",NtpToL2Overlay:"STPDPI",NtpToL2OverlayWithoutOfferIds:"STPDPF",NtpToL2OverlayWithBRQ:"STPDPK",NtpAugmentCard:"SHAUG1",NtpSdCardControl:"STPDPG",NtpCarouselControl:"STPDPH",NtpToL2OverlayControl:"STPDPJ",Bing:"SHOPHP",Start:"SSPD01",FullPage:"ANNTS2",BingSDCardclick:"bhshpc",MeStripe:"msmstb",TopNav:"mstntb",AtfTitle:"mscatft",AtfCard:"msatfc",ShoppingTopSpan:"TOPARC",ShoppingViewsCarousel:"arcarc",ShoppingViewsCarousel2:"SHCAR2",ShoppingViewsCarousel1:"SHCAR1",Prong2Pivot:"P2SHPV",Prong2:"P2SHOP",Prong2Fashion:"P2SHFS",Prong2BGPremium:"P2BGPM",Prong2BGPremiumProduct:"P2BGPD",Prong1:"PRSHOP",Prong1BGPremium:"P1BGPM",Prong1BGPremiumProduct:"P1BGPD",MITSHP:"MITSHP",BuyingGuide1:"BGPDP1",BuyingGuideRelatedSearch:"BGLIRS",BuyingGuideInfoPane:"INFOBG",BuyingGuideAds:"SSBG01"});class f{static getBingShoppingQueryParameters(t,e){let i=!(arguments.length>2&&void 0!==arguments[2])||arguments[2];const r=new URLSearchParams;return r.set("entryPoint",t),e&&r.set("FORM",e),"msn"!==t||(0,l.kg)()||r.set("msnrid",s.YT.getRequestId()),i&&a.T3.CurrentMarket!==n.DX.FRFR&&(r.set("adunitId","378983"),r.set("propertyId","316966")),r}static updateBingShoppingQueryParameters(t,e,i){let r=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],o=arguments.length>4?arguments[4]:void 0;t.searchParams.delete("adunitid"),t.searchParams.delete("propertyid");return this.getBingShoppingQueryParameters(e,i,r).forEach((e,i)=>t.searchParams.set(i,e)),o&&t.searchParams.set("ocid",o),t.toString()}static updateUrlIfBingShopping(t,e){return null!=t&&t.startsWith("https://www.bing.com/shop")?f.updateBingShoppingQueryParameters(new URL(t),e):t}}function v(t){return t?t.replace("?id=/th?","?"):""}const y="isembedded";function C(){return"1"===c(y)||"1"===c("disableheader")}function b(t){return!t.find(t=>t&&!(0,d.py)(t))}function w(t,e){const i=new URL(t);return Object.keys(e).forEach(t=>{i.searchParams.set(t,e[t])}),i.toString()}function x(t,e,i){let r=!(arguments.length>3&&void 0!==arguments[3])||arguments[3];const o=new URL(t);o.searchParams.delete("adunitid"),o.searchParams.delete("propertyid");const d=new URLSearchParams;return d.set("entryPoint",e),i&&d.set("FORM",i),"msn"!==e||(0,l.kg)()||d.set("msnrid",s.YT.getRequestId()),r&&a.T3.CurrentMarket!==n.DX.FRFR&&(d.set("adunitId","378983"),d.set("propertyId","316966")),d.forEach((t,e)=>o.searchParams.set(e,t)),o.toString()}},92687(t,e,i){i.d(e,{m(){return o}});var r=i(92011);class o extends r.L{handleImageContentChange(){this.imageContainer.classList.toggle("image",this.image.assignedNodes().length>0)}}},93866(t,e,i){i.d(e,{Bb(){return _}});var r=i(56911),o=i(92011),s=i(38493),a=i(60815);class n extends o.L{moneyCardContentDataChanged(){"Default"!==this.cardStyle&&void 0===this.moneyCardContentData.actionAppearance&&(this.moneyCardContentData.actionAppearance="outline")}getQuoteColor(t,e,i,r,o){return e?o:this.moneyCardContentData.swapGainLossColor?t?i:r:t?r:i}changeShowingValue(){this.showChangeValue=!this.showChangeValue}connectedCallback(){super.connectedCallback(),this.showChangeValue=!1}}(0,r.Cg)([(0,s.CF)({attribute:"layout"})],n.prototype,"layout",void 0),(0,r.Cg)([s.CF],n.prototype,"cardStyle",void 0),(0,r.Cg)([s.CF],n.prototype,"target",void 0),(0,r.Cg)([a.sH],n.prototype,"moneyCardContentData",void 0),(0,r.Cg)([a.sH],n.prototype,"quoteItems",void 0),(0,r.Cg)([a.sH],n.prototype,"showChangeValue",void 0),(0,r.Cg)([a.sH],n.prototype,"headerTelemetryTag",void 0),(0,r.Cg)([a.sH],n.prototype,"switchValueTelemetryTag",void 0),(0,r.Cg)([a.sH],n.prototype,"seeMoreTelemetryTag",void 0);var l=i(96950),d=i(69259),c=i(39957);const h=l.qy`<a class="quote-row" part="quote-row" href="${t=>t.quoteHref}" target=${(t,e)=>e.parent.target} aria-label="${t=>t.displayName} ${t=>t.symbol} ${t=>t.price} ${t=>t.changePcnt}" data-t="${t=>t.telemetryTag}"><div class="quote-view" part="quote-view"><div class="quote-title-container" part="quote-title-container"><span class="quote-title" part="quote-title"><p class="quote-title-content" part="quote-title-content" title="${t=>t.displayName} (${t=>t.symbol})">${t=>t.symbol}</p></span><span class="sec-title" part="sec-title"><p class="sec-title-str" part="sec-title-str" title="${t=>t.displayName} (${t=>t.symbol})">${t=>t.displayName}</p></span></div><div class="quote-title-container" part="quote-title-container"><div class="price" part="price"><span class="price-str" part="price-str">${t=>t.price}</span></div></div><button class="change-values ${(t,e)=>e.parent.getQuoteColor(t.gain,t.unchanged,"quote-red","quote-green","quote-grey")}" part="change-values ${(t,e)=>e.parent.getQuoteColor(t.gain,t.unchanged,"quote-red","quote-green","quote-grey")}" @click="${(t,e)=>e.parent.changeShowingValue()}" aria-label="${(t,e)=>e.parent.showChangeValue?`${t.changeValue} ${t.displayName} ${t.changePcnt}`:`${t.changePcnt} ${t.displayName} ${t.changeValue}`}" data-t="${(t,e)=>e.parent.switchValueTelemetryTag}">${(0,d.z)((t,e)=>e.parent.showChangeValue,l.qy`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${t=>t.changeValue}</span></span>`)} ${(0,d.z)((t,e)=>!e.parent.showChangeValue,l.qy`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${t=>t.changePcnt}&lrm;</span></span>`)}</button></div></a>`,p=l.qy`<msft-structured-data-card target=${t=>t.target} :headerTelemetryTag=${t=>t.headerTelemetryTag} :seeMoreTelemetryTag=${t=>t.seeMoreTelemetryTag} :data=${t=>t.moneyCardContentData}><slot name="more-actions" slot="more-actions"></slot><slot name="pin" slot="pin"></slot><slot name="title-icon" slot="title-icon"></slot><div class="quote-list" part="quote-list">${(0,c.ux)(t=>t.quoteItems,h)}</div><slot name="footer-start" slot="footer-start"></slot><slot name="footer-end" slot="footer-end"></slot></msft-structured-data-card>`;var u=i(48751),g=i(89580),m=i(41123),f=i(64003),v=i(61138),y=i(45476),C=i(14996),b=i(26920),w=i(74849),x=i(64187),$=i(22131),k=i(50882);const P=w.A`
        ${(0,x.V)("flex")} :host{height:100%;--quote-grid-columns:111px 81px 56px}:host(:focus){outline:none}msft-structured-data-card::part(title-link)::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}.price-str{color:${u.l};
            font-weight: 600;
            text-align: end;
            width: 100%;
            font-size: var(--price-content-font-size, ${g.Y});
            line-height: var(--price-content-line-height, ${g.v})}.quote-list{margin-top:var(--quote-list-margin-top,12px);display:grid;grid-template-rows:var(--quote-list-grid-rows,repeat(auto-fill,52px));row-gap:var(--quote-list-grid-gap,2px);z-index:1}.quote-title-content{color:${u.l};
            font-weight: 600;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            margin: 0;
            font-size: var(--quote-title-font-size, ${m.K});
            line-height: var(--quote-title-line-height, ${m.Z})}.sec-title-str{color:${f.c};
            margin: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: ${v.k};
            line-height: ${v.F}}.quote-row{cursor:pointer;text-decoration:none;padding:var(--quote-row-padding,8px 8px);margin:var(--quote-row-margin,0px 8px)}.quote-row:hover{background:${y.oO}}.change-values{height:24px;font-family:var(--body-font);border-radius:4px;border:0;padding:0;cursor:pointer;outline:none}.change-values:focus-visible{outline-color:${C.WN};outline-width:2px;outline-style:auto}.change-button-area{display:flex;flex-direction:column;justify-content:flex-end}.change-values-percentage{margin-top:4px;margin-bottom:4px;margin-inline-end:8px;display:block;font-size:${v.k};
            font-weight: 600;
            line-height: ${v.F};text-align:end}.price{align-items:center;display:flex}.quote-title-container{text-decoration:none}.quote-view{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:var(--quote-grid-columns)}.quote-green{color:#ffffff;background:#107c10}.quote-red{color:#ffffff;background:#d33e3e}.quote-grey{color:#ffffff;background:#808080}`.withBehaviors((0,$.mr)(w.A` :host{forced-color-adjust:auto}.title-link:hover{text-decoration:underline}.change-values,.quote-row:hover{forced-color-adjust:none;background:${k.A.ButtonFace};
                    box-shadow: 0 0 0 calc((${b.vd} - ${b.XA}) * 1px)
                        ${k.A.LinkText};
                    color: ${k.A.ButtonText}}::slotted(*[slot="option-button"]){fill:${k.A.ButtonText}}::slotted([slot="option-button"]:hover){background:${k.A.Highlight};
                    fill: ${k.A.HighlightText}}.change-values:focus-visible{outline-color:${k.A.Highlight};
                }
            `));var S=i(99900);const _=n.compose({name:`${S.i.prefix}-show-quotes-money-card`,template:p,styles:P})},94288(t,e,i){i.d(e,{AO(){return d},Ep(){return g},Je(){return l},iD(){return h}});var r=i(89167),o=i(93552),s=i(22341);const a=50;function n(t,e){(0,s.c_)(t,o.Wbw,`url: ${e}`)}function l(t,e,i,r,o){try{if(!t)return"";if(!e&&!i||0===e||0===i)return"";const s=new URL(t),a=s.searchParams.get("bw"),n=a?parseInt(a):0;n&&(e=e?e-2*n:e,i=i?i-2*n:i),e&&s.searchParams.set("h",e.toString()),i&&s.searchParams.set("w",i.toString()),void 0===r||s.searchParams.get("c")||s.searchParams.set("c",r),null!=o&&""!==o?s.searchParams.set("rs",o):s.searchParams.set("rs","1");const l=s.toString();e&&s.searchParams.set("h",(2*e).toString()),i&&s.searchParams.set("w",(2*i).toString()),n&&s.searchParams.set("bw",(2*n).toString());return`${l} 1x, ${s.toString()} 2x`}catch(e){return n(e,t),`${t} 1x`}}function d(t){var e;const i=null===(e=t.imageInfo)||void 0===e?void 0:e.images;if(!i)return;if(i.length>1){const e=i.map(t=>({...t,sourceImageUrl:(0,r.zt)(t.url)}));t.imageInfo.sourceImageUrl||(t.imageInfo.sourceImageUrl=e[0].sourceImageUrl),t.images=e.filter(e=>e.sourceImageUrl!==t.imageInfo.sourceImageUrl)}}function c(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:a;const i=new URL(t);return i.searchParams.set("w",e.toString()),i.searchParams.delete("h"),i.toString()}function h(t){var e;let i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;const r=null===(e=t.imageInfo)||void 0===e?void 0:e.sourceImageUrl;r&&(t.imageInfo.sourceImageUrl=p(u(r,i),"17"))}function p(t,e){try{const i=new URL(t);return i.searchParams.set("c",e.toString()),i.toString()}catch(e){return n(e,t),t}}function u(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0,i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"FFFFFF";if(!e||!i)return t;try{const r=new URL(t);return r.searchParams.set("bw",e.toString()),r.searchParams.set("bc",i),r.toString()}catch(e){return n(e,t),t}}async function g(t){var e;let i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"",r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"",o=arguments.length>3&&void 0!==arguments[3]?arguments[3]:1,s=arguments.length>4&&void 0!==arguments[4]?arguments[4]:0;if(!i&&!r)return;if(null===(e=t.imageInfo)||void 0===e||!e.sourceImageUrl)return;const a=await async function(t){try{var e;const i=!0,r=null===(e=t.imageInfo)||void 0===e?void 0:e.sourceImageUrl;if(!r)return i;const o=await m(c(r)),s=o.naturalWidth,a=o.naturalHeight,n=s/a;return s&&a?(t.imageInfo.ratio=n,f(o)):i}catch(t){return!0}}(t);let l="";a&&i&&(l=i),!a&&r&&(o=function(t){try{const e=new URL(t),i=e.searchParams.get("w"),r=e.searchParams.get("h"),o=i?parseInt(i):0,s=r?parseInt(r):0;if(!o||!s)return;return o/s}catch(e){return void n(e,t)}}(t.imageInfo.sourceImageUrl)||o,t.imageInfo.ratio&&Math.abs(t.imageInfo.ratio-o)<.2&&(l=r)),t.imageInfo.hasWhiteBackground=a,l&&(t.imageInfo.sourceImageUrl=p(t.imageInfo.sourceImageUrl,l),s&&a&&(t.imageInfo.sourceImageUrl=u(t.imageInfo.sourceImageUrl,s)))}async function m(t){const e=new Image;return e.crossOrigin="anonymous",e.src=t,await e.decode(),e}function f(t){try{t.crossOrigin="anonymous";const e=document.createElement("canvas"),i=t.naturalWidth,r=t.naturalHeight;e.width=i,e.height=r;const o=e.getContext("2d");null==o||o.drawImage(t,0,0);const s=null==o?void 0:o.getImageData(0,0,e.width,e.height),a=null==s?void 0:s.data;if(!a)return!0;const n=function(t,e,i){let r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:5,o=arguments.length>4&&void 0!==arguments[4]?arguments[4]:20,s=0;const a=2*r*(e+i-2*r);for(let a=0;a<i;a++)for(let n=0;n<e;n++)if(n<r||n>=e-r||a<r||a>=i-r){const i=4*(a*e+n),r=t[i],l=t[i+1],d=t[i+2],c=255-o;r>c&&l>c&&d>c&&s++}return s/a*100}(a,i,r);return n>=25}catch(e){return n(e,t.src),!0}}},94407(t,e,i){i.d(e,{L(){return n}});var r=i(56911),o=i(60815),s=i(92011),a=i(38493);class n extends s.L{constructor(){super(...arguments),this.expanded=!1}defaultItemsChanged(){this.$fastController.isConnected&&(this.shouldanimate=this.defaultItems.length>0)}}(0,r.Cg)([(0,a.CF)({mode:"boolean"})],n.prototype,"expanded",void 0),(0,r.Cg)([o.sH],n.prototype,"defaultItems",void 0),(0,r.Cg)([(0,a.CF)({mode:"boolean",attribute:"animate"})],n.prototype,"shouldanimate",void 0)},96193(t,e,i){i.d(e,{z(){return o}});var r=i(92011);class o extends r.L{}},98515(t,e,i){i.d(e,{Q(){return c}});var r=i(14475),o=i(96950),s=i(69259),a=i(77793),n=i(46983);const l=(t,e)=>{e.event.preventDefault(),window.dispatchEvent(new CustomEvent("dsaClick",{detail:{adSelectionCriteria:t.adSelectionCriteria,anchorElement:e.event.target,strings:t.config.localizedStrings},bubbles:!0,composed:!0}))},d=(t,e)=>("Enter"===e.event.key&&l(t,e),!0),c=t=>o.qy` ${(0,s.z)(!!t.enableDSADialog,o.qy`<a class="ad-label dsa" data-t=${t.telemetryTag||""} title=${t.dsaDialogTooltip||""} ?no-border=${Boolean(t.noBorder)} @click=${l} @keydown=${d} tabindex="0">${t.text||"Ad"}</a>`)} ${(0,s.z)(!t.enableDSADialog,o.qy`<a class="ad-label" data-t=${t.telemetryTag||""} href=${t.href||""} target="${r.z._blank}" title=${(0,n.jj)()&&t.text||""} ?no-border=${Boolean(t.noBorder)} ${!(0,n.jj)()&&(0,a.Ib)(!0,!1)}>${t.text||"Ad"}</a>`)} `},99564(t,e,i){i.d(e,{m(){return C}});var r=i(75261);class o extends r.t{}var s=i(37180),a=i(74849),n=i(64187),l=i(22131),d=i(50882),c=i(48196),h=i(37302),p=i(4283),u=i(64003);const g=a.A`
    ${(0,n.V)("flex")} :host {
        align-items: center;
        outline: none;
        height: calc(${c.D} * 1px);
        width: calc(${c.D} * 1px);
        margin: calc(${c.D} * 1px) 0;
    }

    .progress {
        height: 100%;
        width: 100%;
    }

    .background {
        stroke: ${h.F7};
        fill: none;
        stroke-width: 2px;
    }

    .determinate {
        stroke: ${p.IR};
        fill: none;
        stroke-width: 2px;
        stroke-linecap: round;
        transform-origin: 50% 50%;
        transform: rotate(-90deg);
        transition: all 0.2s ease-in-out;
    }

    .indeterminate-indicator-1 {
        stroke: ${p.IR};
        fill: none;
        stroke-width: 2px;
        stroke-linecap: round;
        transform-origin: 50% 50%;
        transform: rotate(-90deg);
        transition: all 0.2s ease-in-out;
        animation: spin-infinite 2s linear infinite;
    }

    :host([paused]) .indeterminate-indicator-1 {
        animation-play-state: paused;
        stroke: ${h.F7};
    }

    :host([paused]) .determinate {
        stroke: ${u.c};
    }

    @keyframes spin-infinite {
        0% {
            stroke-dasharray: 0.01px 43.97px;
            transform: rotate(0deg);
        }
        50% {
            stroke-dasharray: 21.99px 21.99px;
            transform: rotate(450deg);
        }
        100% {
            stroke-dasharray: 0.01px 43.97px;
            transform: rotate(1080deg);
        }
    }
`.withBehaviors((0,l.mr)(a.A`
            .indeterminate-indicator-1,
            .determinate {
                stroke: ${d.A.FieldText};
            }
            .background {
                stroke: ${d.A.Field};
            }
            :host([paused]) .indeterminate-indicator-1 {
                stroke: ${d.A.Field};
            }
            :host([paused]) .determinate {
                stroke: ${d.A.GrayText};
            }
        `));var m=i(96950),f=i(69259),v=i(18893);const y=function(t={}){return m.qy`
        <template
            role="progressbar"
            aria-valuenow="${t=>t.value}"
            aria-valuemin="${t=>t.min}"
            aria-valuemax="${t=>t.max}"
        >
            ${(0,f.z)(t=>"number"==typeof t.value,m.qy`
                    <svg
                        class="progress"
                        part="progress"
                        viewBox="0 0 16 16"
                        slot="determinate"
                    >
                        <circle
                            class="background"
                            part="background"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                        <circle
                            class="determinate"
                            part="determinate"
                            style="stroke-dasharray: ${t=>44*t.percentComplete/100+"px 44px"}"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                    </svg>
                `,m.qy`
                    <slot name="indeterminate">
                        ${(0,v.R)(t.indeterminateIndicator)}
                    </slot>
                `)}
        </template>
    `}({indeterminateIndicator:m.qy`
        <svg class="progress" part="progress" viewBox="0 0 16 16">
            <circle
                class="background"
                part="background"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
            <circle
                class="indeterminate-indicator-1"
                part="indeterminate-indicator-1"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
        </svg>
    `}),C=o.compose({name:`${s.c.prefix}-progress-ring`,template:y,styles:g})}}]);