// © Microsoft Corporation. All rights reserved.
// HomePage SPA Constants
export const HomePageConstants = {
    /**
     * The Telemetry name for this experience
     */
    experienceTelemetryName: "HomePage",
    /**
     * SPA specific OCID
     */
    ocid: "Peregrine"
};
//# sourceMappingURL=HomePage.constants.js.map