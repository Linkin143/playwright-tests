"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["social-report-menu"],{121(t,e,o){o.d(e,{m(){return y}});var i=o(56911),r=o(92011),n=o(38493),a=o(60815),s=o(83781),l=o(55230),d=o(31157),c=o(42938);class h extends r.L{constructor(){super(...arguments),this.orientation=s.t.horizontal,this.radioChangeHandler=t=>{const e=t.target;e.checked&&(this.slottedRadioButtons.forEach(t=>{t!==e&&(t.checked=!1,this.isInsideFoundationToolbar||t.setAttribute("tabindex","-1"))}),this.selectedRadio=e,this.value=e.value,e.setAttribute("tabindex","0"),this.focusedRadio=e),t.stopPropagation()},this.moveToRadioByIndex=(t,e)=>{const o=t[e];this.isInsideToolbar||(o.setAttribute("tabindex","0"),o.readOnly?this.slottedRadioButtons.forEach(t=>{t!==o&&t.setAttribute("tabindex","-1")}):(o.checked=!0,this.selectedRadio=o)),this.focusedRadio=o,o.focus()},this.moveRightOffGroup=()=>{this.nextElementSibling?.focus()},this.moveLeftOffGroup=()=>{this.previousElementSibling?.focus()},this.focusOutHandler=t=>{const e=this.slottedRadioButtons,o=t.target,i=null!==o?e.indexOf(o):0,r=this.focusedRadio?e.indexOf(this.focusedRadio):-1;return(0===r&&i===r||r===e.length-1&&r===i)&&(this.selectedRadio?(this.focusedRadio=this.selectedRadio,this.isInsideFoundationToolbar||(this.selectedRadio.setAttribute("tabindex","0"),e.forEach(t=>{t!==this.selectedRadio&&t.setAttribute("tabindex","-1")}))):(this.focusedRadio=e[0],this.focusedRadio.setAttribute("tabindex","0"),e.forEach(t=>{t!==this.focusedRadio&&t.setAttribute("tabindex","-1")}))),!0},this.clickHandler=t=>{const e=t.target;if(e){const t=this.slottedRadioButtons;e.checked||0===t.indexOf(e)?(e.setAttribute("tabindex","0"),this.selectedRadio=e):(e.setAttribute("tabindex","-1"),this.selectedRadio=null),this.focusedRadio=e}t.preventDefault()},this.shouldMoveOffGroupToTheRight=(t,e,o)=>t===e.length&&this.isInsideToolbar&&o===l.bb,this.shouldMoveOffGroupToTheLeft=(t,e)=>(this.focusedRadio?t.indexOf(this.focusedRadio)-1:0)<0&&this.isInsideToolbar&&e===l.kT,this.checkFocusedRadio=()=>{null===this.focusedRadio||this.focusedRadio.readOnly||this.focusedRadio.checked||(this.focusedRadio.checked=!0,this.focusedRadio.setAttribute("tabindex","0"),this.focusedRadio.focus(),this.selectedRadio=this.focusedRadio)},this.moveRight=t=>{const e=this.slottedRadioButtons;let o=0;if(o=this.focusedRadio?e.indexOf(this.focusedRadio)+1:1,this.shouldMoveOffGroupToTheRight(o,e,t.key))this.moveRightOffGroup();else for(o===e.length&&(o=0);o<e.length&&e.length>1;){if(!e[o].disabled){this.moveToRadioByIndex(e,o);break}if(this.focusedRadio&&o===e.indexOf(this.focusedRadio))break;if(o+1>=e.length){if(this.isInsideToolbar)break;o=0}else o+=1}},this.moveLeft=t=>{const e=this.slottedRadioButtons;let o=0;if(o=this.focusedRadio?e.indexOf(this.focusedRadio)-1:0,o=o<0?e.length-1:o,this.shouldMoveOffGroupToTheLeft(e,t.key))this.moveLeftOffGroup();else for(;o>=0&&e.length>1;){if(!e[o].disabled){this.moveToRadioByIndex(e,o);break}if(this.focusedRadio&&o===e.indexOf(this.focusedRadio))break;o-1<0?o=e.length-1:o-=1}},this.keydownHandler=t=>{const e=t.key;if(e in l.Is&&this.isInsideFoundationToolbar)return!0;switch(e){case l.Mm:this.checkFocusedRadio();break;case l.bb:case l.HX:this.direction===d.O.ltr?this.moveRight(t):this.moveLeft(t);break;case l.kT:case l.I5:this.direction===d.O.ltr?this.moveLeft(t):this.moveRight(t);break;default:return!0}}}readOnlyChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{this.readOnly?t.readOnly=!0:t.readOnly=!1})}disabledChanged(){void 0!==this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{this.disabled?t.disabled=!0:t.disabled=!1})}nameChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{t.setAttribute("name",this.name)})}valueChanged(){this.slottedRadioButtons&&this.slottedRadioButtons.forEach(t=>{t.value===this.value&&(t.checked=!0,this.selectedRadio=t)}),this.$emit("change")}slottedRadioButtonsChanged(t,e){this.slottedRadioButtons&&this.slottedRadioButtons.length>0&&this.setupRadioButtons()}get parentToolbar(){return this.closest('[role="toolbar"]')}get isInsideToolbar(){return this.parentToolbar??!1}get isInsideFoundationToolbar(){return!!this.parentToolbar?.$fastController}connectedCallback(){super.connectedCallback(),this.direction=(0,c.u)(this),this.setupRadioButtons()}disconnectedCallback(){super.disconnectedCallback(),this.slottedRadioButtons.forEach(t=>{t.removeEventListener("change",this.radioChangeHandler)})}setupRadioButtons(){const t=this.slottedRadioButtons.filter(t=>t.hasAttribute("checked")),e=t?t.length:0;if(e>1){t[e-1].checked=!0}let o=!1;if(this.slottedRadioButtons.forEach(t=>{void 0!==this.name&&t.setAttribute("name",this.name),this.disabled&&(t.disabled=!0),this.readOnly&&(t.readOnly=!0),this.value&&this.value===t.value?(this.selectedRadio=t,this.focusedRadio=t,t.checked=!0,t.setAttribute("tabindex","0"),o=!0):(this.isInsideFoundationToolbar||t.setAttribute("tabindex","-1"),t.checked=!1),t.addEventListener("change",this.radioChangeHandler)}),void 0===this.value&&this.slottedRadioButtons.length>0){const t=this.slottedRadioButtons.filter(t=>t.hasAttribute("checked")),e=null!==t?t.length:0;if(e>0&&!o){const o=t[e-1];o.checked=!0,this.focusedRadio=o,o.setAttribute("tabindex","0")}else this.slottedRadioButtons[0].setAttribute("tabindex","0"),this.focusedRadio=this.slottedRadioButtons[0]}}}(0,i.Cg)([(0,n.CF)({attribute:"readonly",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,i.Cg)([(0,n.CF)({attribute:"disabled",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],h.prototype,"disabled",void 0),(0,i.Cg)([n.CF,(0,i.Sn)("design:type",String)],h.prototype,"name",void 0),(0,i.Cg)([n.CF,(0,i.Sn)("design:type",String)],h.prototype,"value",void 0),(0,i.Cg)([n.CF,(0,i.Sn)("design:type",String)],h.prototype,"orientation",void 0),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",Array)],h.prototype,"childItems",void 0),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",Array)],h.prototype,"slottedRadioButtons",void 0);var p=o(37180),u=o(74849),m=o(64187),f=o(74838);const b=u.A`
    ${(0,m.V)("flex")} :host {
        align-items: flex-start;
        margin: calc(${f.vR} * 1px) 0;
        flex-direction: column;
    }

    .positioning-region {
        display: flex;
        flex-wrap: wrap;
    }

    :host([orientation="vertical"]) .positioning-region {
        flex-direction: column;
    }

    :host([orientation="horizontal"]) .positioning-region {
        flex-direction: row;
    }
`;var g=o(96950),v=o(82774),$=o(10108);const x=g.qy`
        <template
            role="radiogroup"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            @click="${(t,e)=>t.clickHandler(e.event)}"
            @keydown="${(t,e)=>t.keydownHandler(e.event)}"
            @focusout="${(t,e)=>t.focusOutHandler(e.event)}"
        >
            <slot name="label"></slot>
            <div
                class="positioning-region ${t=>t.orientation===s.t.horizontal?"horizontal":"vertical"}"
                part="positioning-region"
            >
                <slot
                    ${(0,v.e)({property:"slottedRadioButtons",filter:(0,$.Y)("[role=radio]")})}
                ></slot>
            </div>
        </template>
    `,y=h.compose({name:`${p.c.prefix}-radio-group`,template:x,styles:b})},33895(t,e,o){o.r(e),o.d(e,{SocialReportMenu(){return D},SocialReportMenuConfig(){return A},SocialReportMenuStyles(){return te},SocialReportMenuTemplate(){return Ht},ToolingInfo(){return ee}});var i=o(4731),r=o(37180),n=o(69400),a=o(98264),s=o(88817),l=o(121),d=o(58661),c=o(19249),h=o(2958),p=o(56911),u=o(83397),m=o(8176),f=o(27659);const b="report-comment";var g=o(12680),v=o(11297),$=o(64332),x=o(25109),y=o(30860),k=o(85349),w=o(77367),C=o(19359);const T=function(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:k.EG.Click,o=arguments.length>2?arguments[2]:void 0;w.YT.sendActionEvent(t,e,o)},F=function(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:k.EG.Click,o=arguments.length>2&&void 0!==arguments[2]?arguments[2]:k.MS.Close;w.YT.sendActionEvent(t,e,o)};var M=o(93557),R=o(38493),S=o(60815),z=o(55230),E=o(37641);const A=$.DI.createContext();var I=o(97004),B=o(48566),N=o(39671),P=o(17918),V=o(41065);class D extends N.U{constructor(){super(...arguments),this.darkModeQuery=window.matchMedia("(prefers-color-scheme:dark)"),this.menuType="comment",this.reportModalStep="intro",this.isFreeFormResponse=!1,this.selectedReportReason=null,this.shouldRenderReportModal=!0,this.isBootstrapped=!1,this.setTheme=()=>{this.backgroundColor=(0,x.ud)()?y.py:y.z4,this.baseLayerLuminance=(0,x.ud)()?I.y.DarkMode:I.y.LightMode},this.onOutsideClick=t=>{var e,o,i;null!==(e=this.actionsMenuButtonElement)&&void 0!==e&&e.contains(null===(o=t.composedPath())||void 0===o?void 0:o[0])||("thankyou"===this.reportModalStep&&this.finishReportingFlow(t),null===(i=this.onHide)||void 0===i||i.call(this,t))},this.onKeydown=t=>{if(t.key===z.F9){var e;if(this.config.renderAsModal)this.closeReportModal(t);else null===(e=this.onHide)||void 0===e||e.call(this,t);this.focusReportButton()}},this.openReportModal=()=>{this.shouldRenderReportModal=!0},this.handleTabOnCancelButtonKeyDown=t=>{var e;u.y.handleOnKeyType(t,null===(e=this.reportModalActionButtons)||void 0===e||null===(e=e.cancel.onclick)||void 0===e?void 0:e.bind(this),z.Mm),u.y.handleOnKeyType(t,()=>{var t;return null===(t=this.closeButtonRef)||void 0===t?void 0:t.focus()},z.J9)}}getExperienceType(){return g._07}experienceConnected(){$.DI.getOrCreateDOMContainer().register($.cH.instance(A,this.config)),this.setTheme(),this.renderInPopover&&!this.config.renderAsModal&&document.addEventListener("click",this.onOutsideClick),document.addEventListener("keydown",this.onKeydown),this.darkModeQuery.addEventListener("change",this.setTheme),this.bootstrap()}disconnectedCallback(){super.disconnectedCallback(),this.renderInPopover&&!this.config.renderAsModal&&document.removeEventListener("click",this.onOutsideClick),document.removeEventListener("keydown",this.onKeydown),this.darkModeQuery.removeEventListener("change",this.setTheme),this.isBootstrapped=!1}shadowDomPopulated(){this.markTtvr?this.markTtvr():(0,P.yi)(g._07)}reportingTraitsChanged(){this.bootstrap()}bootstrap(){var t,e;if((null===(t=this.reportingTraits)||void 0===t||!t.length)&&!this.isFreeFormResponse||!this.strings||this.isBootstrapped)return;this.isBootstrapped=!0;let o=(null===(e=this.reportingTraits)||void 0===e?void 0:e.filter(t=>this.strings[t]))||[];this.config.renderAsModal&&!o.includes("misinformation")&&o.filter(t=>t.startsWith("misinformation-")).length>0&&(o=[...o,"misinformation"]),this.filteredReportingTraits=o.sort(),this.telemetryContext=((t,e,o,i)=>{const r=e.reduce((t,e)=>{const i=`${e[0].toUpperCase()}${e.slice(1)}`;return t[e]=(0,C.l)(i,{id:o,headline:i},k.MS.Report,k.EG.Click,k.MJ.ActionButton),t},{}),n="comment"===i?"ReportCommentPopup":"ReportPostPopup",a=(0,C.l)(n+"Close",{headline:n+"Close"},k.MS.Cancel,k.EG.Click,k.MJ.ActionButton),s=(0,C.l)(n+"IntroCancel",{headline:"ReportReason"},k.MS.Cancel,k.EG.Click,k.MJ.ActionButton),l=(0,C.l)(n+"NonViolationOkay",{headline:"ReportNonViolation"},k.MS.More,k.EG.Click,k.MJ.ActionButton),d=(0,C.l)(n+"NonViolationGoBack",{headline:"ReportNonViolation"},k.MS.Cancel,k.EG.Click,k.MJ.ActionButton),c=(0,C.l)(n+"ViolationGoBack",{headline:"ReportViolation"},k.MS.Cancel,k.EG.Click,k.MJ.ActionButton);return{componentRoot:t,reportModalClose:a,reportItem:r,reportNonViolationCancel:d,reportNonViolationOkay:l,reportReasonCancel:s,reportReasonContinue:t=>(0,C.l)(n+"IntroContinue",{headline:t},k.MS.More,k.EG.Click,k.MJ.ActionButton),reportViolationCancel:c,reportViolationSubmit:t=>(0,C.l)(n+"ViolationSubmit",{id:o,headline:t},k.MS.Report,k.EG.Click,k.MJ.ActionButton)}})((0,V.N)("SocialReportMenu"),this.filteredReportingTraits,this.targetId,this.menuType),this.fetchData(),this.isFreeFormResponse&&(this.reportModalStep="freeform"),this.reportModalActionButtons=this.getActionButtons(this.reportModalStep),this.shouldRenderReportModal=!0}get localizedMenuType(){return this.strings[this.menuType]}get reportMenuOptions(){var t,e,o;return null!==(t=this.selectedReportTrait)&&void 0!==t&&t.startsWith("misinformation")?null===(e=this.filteredReportingTraits)||void 0===e?void 0:e.filter(t=>t.startsWith("misinformation-")):(null===(o=this.filteredReportingTraits)||void 0===o?void 0:o.filter(t=>!t.startsWith("misinformation-")))||[]}reportModalStepChanged(t,e){var o;t!==e&&null!==(o=this.config)&&void 0!==o&&o.renderAsModal&&(this.reportModalActionButtons=this.getActionButtons(e))}shouldRenderReportModalChanged(t,e){var o,i,r;t!==e&&null!==(o=this.config)&&void 0!==o&&o.renderAsModal&&(!1===e?null===(i=this.actionsMenuButtonElement)||void 0===i||i.addEventListener("click",this.openReportModal):null===(r=this.actionsMenuButtonElement)||void 0===r||r.removeEventListener("click",this.openReportModal))}getActionButtons(t){switch(t){case"intro":return{primary:{title:this.strings.reportModalContinueButton,disabled:()=>null===this.selectedReportReason,onclick:()=>{this.selectedReportReason&&(this.reportModalStep=this.selectedReportReason)},telemetryTag:()=>this.telemetryContext.reportReasonContinue(this.selectedReportReason||"").getMetadataTag()},cancel:{title:this.strings.reportModalCancelButton,disabled:!1,onclick:t=>this.closeReportModal(t),telemetryTag:this.telemetryContext.reportReasonCancel.getMetadataTag()}};case"nonViolation":return{primary:{title:this.strings.reportModalOkayButton,disabled:!1,onclick:t=>{"poll"==this.menuType?this.reportHandler("nonViolation",t):this.closeReportModal(t)},telemetryTag:this.telemetryContext.reportNonViolationOkay.getMetadataTag()},cancel:{title:this.strings.reportModalGoBackButton,disabled:!1,onclick:()=>{this.reportModalStep="intro"},telemetryTag:this.telemetryContext.reportNonViolationCancel.getMetadataTag()}};case"violation":return{primary:{title:this.strings.reportModalSubmitReportButton,disabled:()=>void 0===this.selectedReportTrait||"misinformation"===this.selectedReportTrait,onclick:t=>{this.selectedReportTrait&&this.reportHandler(this.selectedReportTrait,t)},telemetryTag:()=>this.selectedReportTrait?this.telemetryContext.reportViolationSubmit(this.selectedReportTrait).getMetadataTag():""},cancel:{title:this.strings.reportModalGoBackButton,disabled:!1,onclick:()=>{var t;null!==(t=this.selectedReportTrait)&&void 0!==t&&t.startsWith("misinformation")?this.selectedReportTrait=void 0:this.reportModalStep="intro"},telemetryTag:this.telemetryContext.reportViolationCancel.getMetadataTag()}};case"freeform":return{primary:{title:this.strings.reportModalSubmitReportButton,disabled:!1,onclick:t=>{this.reportHandler("inappropriate",t)},telemetryTag:()=>this.telemetryContext.reportViolationSubmit("freeForm").getMetadataTag()},cancel:{title:this.strings.reportModalCancelButton,disabled:!1,onclick:()=>this.closeReportModal(),telemetryTag:this.telemetryContext.reportViolationCancel.getMetadataTag()}};case"thankyou":return{primary:{title:"",onclick:null,disabled:!0,telemetryTag:""},cancel:{title:this.strings.reportModalCloseButtonTitle,disabled:!1,onclick:t=>this.finishReportingFlow(t),telemetryTag:this.telemetryContext.reportModalClose.getMetadataTag()}}}}async fetchData(){this.me||(this.me=await M.l.fetchMe(!1))}focusReportButton(){const t=this.parentElement;window.requestAnimationFrame(()=>{var e;return null==t||null===(e=t.querySelector("[role='button']"))||void 0===e?void 0:e.focus()})}finishReportingFlow(t,e){"copyright"!==(e||this.selectedReportTrait)&&(this.onReport&&this.onReport(this.selectedReportTrait||"",t),this.popupConnector&&this.popupConnector.closePopup()),this.config.renderAsModal&&this.closeReportModal(t)}reportHandler(t,e){if(this.config.renderAsModal||T(e.currentTarget),"copyright"==t){if(this.renderInPopover&&this.config.renderAsModal)return void(this.isCopyright=!0);this.popupConnector.closePopup({disableBridge:!0}),this.me.state!=m.v.userStateType.anonymous||this.doNotOpenMultiLoginPage?this.popupConnector.openPopup("copyrightform",{id:this.targetId,fullScreen:!1,onReport:this.onReport}):this.popupConnector.openPopup("multiLoginPage")}else"poll"==this.menuType||"sentimentPicker"==this.menuType?(M.l.reportPoll(this.targetId,t,this.freeFormResponse),this.reportModalStep="thankyou"):E.V.getInstance().rootReducer.getDataConnector(v.eX).then(e=>{e&&(e.reportComment(this.targetId,t),function(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};try{document.dispatchEvent(new CustomEvent(t,{detail:{eventName:t,data:e}}))}catch(t){f.v.logError(t)}}(b,{commentId:this.targetId}))});"thankyou"!==this.reportModalStep&&this.finishReportingFlow(e,t)}handleKeyDown(t){const e=t.key,o=t.target;if(e===z.F9){const e=window.document.getElementById(`reportMenu_${this.targetId}`);e&&window.setTimeout(()=>{e.focus()},50),t.stopPropagation(),t.preventDefault()}else if(e===z.I5){t.preventDefault(),t.stopPropagation();let e=o.previousElementSibling;var i;if(!e)e=null===(i=o.parentElement)||void 0===i?void 0:i.lastElementChild;e.focus(),this.reportHandler(e.value,t)}else if(e===z.HX){let e=o.nextElementSibling;var r;if(!e)e=null===(r=o.parentElement)||void 0===r?void 0:r.firstElementChild;t.preventDefault(),t.stopPropagation(),e.focus(),this.reportHandler(e.value,t)}}onReportTraitChange(t){t.preventDefault();const e=t.target;e.disabled||(this.selectedReportTrait=e.value)}onReportReasonSelection(t){t.preventDefault();const e=t.target;if("a"===e.nodeName.toLowerCase()){const t=e.attributes.getNamedItem("href");return void(null!=t&&t.textContent&&window.open(t.textContent))}!e.disabled&&e.value&&(this.selectedReportReason=e.value)}dismissModal(t){F(this.closeButtonRef),this.closeReportModal(t)}closeReportModal(t){var e;this.shouldRenderReportModal=!1,null===(e=this.onHide)||void 0===e||e.call(this,t),this.selectedReportReason=null,this.selectedReportTrait=void 0,this.reportModalStep="intro",this.closeCopyrightModal()}closeCopyrightModal(){this.isCopyright=!1}isEnterEvent(t){return"Enter"==t.key}get reportModalHeaderTitle(){var t;return"thankyou"===this.reportModalStep?this.strings.reportModalThankYouTitle:B.Qf.Format(null===(t=this.strings)||void 0===t?void 0:t.reportModalHeaderTitle,{menuType:this.localizedMenuType})}onFreeFormReportChange(t){const e=t.target;this.freeFormResponse=e.value}get actionsMenuButtonElement(){return this.reportButtonRef?this.reportButtonRef:window.document.getElementById(`reportMenu_${this.targetId}`)}getReportingTraitString(t){return t in this.strings?this.strings[t]:"misuse-for-influencing-political-process"==t?this.strings["influencing-political-process"]:"medical-financial-legal-advice"==t?this.strings["med-financial-legal-advice"]:t}get actionsMenuProps(){return{menuItems:this.filteredReportingTraits.map(t=>({id:t,title:this.strings[t],onClick:e=>{this.reportHandler(t,e)},telemetryTag:this.telemetryContext.reportItem[t].getMetadataTag()}))}}}(0,p.Cg)([R.CF],D.prototype,"targetId",void 0),(0,p.Cg)([R.CF],D.prototype,"commentBody",void 0),(0,p.Cg)([R.CF],D.prototype,"me",void 0),(0,p.Cg)([R.CF],D.prototype,"reportingTraits",void 0),(0,p.Cg)([R.CF],D.prototype,"markTtvr",void 0),(0,p.Cg)([R.CF],D.prototype,"popupConnector",void 0),(0,p.Cg)([R.CF],D.prototype,"onReport",void 0),(0,p.Cg)([R.CF],D.prototype,"onHide",void 0),(0,p.Cg)([R.CF],D.prototype,"theme",void 0),(0,p.Cg)([(0,R.CF)({mode:"boolean"})],D.prototype,"renderInPopover",void 0),(0,p.Cg)([R.CF],D.prototype,"responsiveClass",void 0),(0,p.Cg)([(0,R.CF)({mode:"boolean"})],D.prototype,"isCopyright",void 0),(0,p.Cg)([R.CF],D.prototype,"reportButtonRef",void 0),(0,p.Cg)([R.CF],D.prototype,"defaultVerticalPosition",void 0),(0,p.Cg)([R.CF],D.prototype,"defaultHorizontalPosition",void 0),(0,p.Cg)([(0,R.CF)({mode:"boolean"})],D.prototype,"doNotOpenMultiLoginPage",void 0),(0,p.Cg)([S.sH],D.prototype,"filteredReportingTraits",void 0),(0,p.Cg)([R.CF],D.prototype,"backgroundColor",void 0),(0,p.Cg)([R.CF],D.prototype,"baseLayerLuminance",void 0),(0,p.Cg)([S.sH],D.prototype,"menuType",void 0),(0,p.Cg)([S.sH],D.prototype,"telemetryContext",void 0),(0,p.Cg)([S.sH],D.prototype,"closeButtonRef",void 0),(0,p.Cg)([S.sH],D.prototype,"reportModalStep",void 0),(0,p.Cg)([S.sH],D.prototype,"freeFormResponse",void 0),(0,p.Cg)([S.sH],D.prototype,"isFreeFormResponse",void 0),(0,p.Cg)([S.sH],D.prototype,"selectedReportTrait",void 0),(0,p.Cg)([S.sH],D.prototype,"selectedReportReason",void 0),(0,p.Cg)([S.sH],D.prototype,"shouldRenderReportModal",void 0),(0,p.Cg)([S.sH],D.prototype,"reportModalActionButtons",void 0),(0,p.Cg)([S.Jg],D.prototype,"localizedMenuType",null),(0,p.Cg)([S.Jg],D.prototype,"reportMenuOptions",null),(0,p.Cg)([S.Jg],D.prototype,"reportModalHeaderTitle",null);var L=o(96950),H=o(39957),O=o(93809),U=o(69259),_=o(60402),q=o(66591),j=o(53697),W=o.n(j),G=o(92011),Y=o(70394),K=o.n(Y);const Z="waiting",Q="uploading",J="uploaded",X="failed",tt="size",et="format",ot="count",it="other",rt={MaxFileSize:10485760,MaxFileCount:10,AcceptedAttachmentTypes:[".pdf",".txt",".docx",".msg",".xlsx",".xls"]},nt=L.qy`<fluent-text-field class="${t=>t.error?"input-box-error":""}" type="text" name=${t=>t.inputName} :value=${t=>t.inputValue} @change=${(t,e)=>e.parent.handleContactInfoOnChange(e.event)}>${t=>t.label}<span class="input-label-asterisk">${(0,U.z)(t=>t.error,L.qy`<span class="required-text">${(t,e)=>{var o;return null===(o=e.parent.strings)||void 0===o?void 0:o.coprFormRequiredField}}</span>`)}</span></fluent-text-field>`,at=L.qy`<div class="container"><div class="header-container"><h3 class="main-title">${t=>t.strings.coprFormCheckTxt}</h3><p class="sub-text">${t=>t.strings.coprFormCheckSubTxt}</p></div><fluent-divider class="separator"></fluent-divider><div class="input-container"><fluent-text-field ?disabled=${()=>!0} class="input-disabled" type="text" name="reportType" value="Copyright">${t=>t.strings.coprFormContentIssueTitle}</fluent-text-field><fluent-text-field class="input-disabled" type="text" name="commentId" ?disabled=${()=>!0} :value=${t=>t.targetId}>${t=>t.reportItemType?t.strings.coprFormUserIDTitle:t.strings.coprFormCommentIDTitle}</fluent-text-field></div><div class="button-container"><fluent-button appearance="accent" class="button" title=${t=>t.strings.coprFormContinueButtonTitle} @click=${t=>t.proceedToStep1()}>${t=>t.strings.coprFormContinueButtonTitle}</fluent-button><fluent-button appearance="outline" class="button" title=${t=>t.strings.coprFormCancelButtonTitle} @click=${t=>t.$emit("close-popup")}>${t=>t.strings.coprFormCancelButtonTitle}</fluent-button></div></div>`,st=L.qy`<div class="container"><div class="header-container"><h3 class="main-title">${t=>t.strings.coprFormMainTxt}</h3><p class="main-subtitle">${t=>t.strings.coprFormMainSubTxt}</p></div><fluent-divider class="separator"></fluent-divider><header class="header-section">${t=>t.strings.coprFormContactInfoTitle}</header><div><div class="input-container">${(0,H.ux)(t=>t.step1InputFields,nt)}<div>${(0,U.z)(t=>t.validationErrors.emailSyntaxError,L.qy`<span class="required-text">${t=>t.strings.coprFormEmailValidation}</span>`)}<fluent-divider class="separator"></fluent-divider><header class="header-section">${t=>t.strings.coprFormDetailsTitle}</header><div class="input-container"><fluent-text-field class="${t=>""!==t.validationErrors.authorizedError?"input-box-error":""}" type="text" name="authorizedExample" :value=${t=>t.details.authorizedExample} @change=${(t,e)=>t.onChangeAuthorizedExample(e.event)}>${t=>t.strings.coprFormAuthorizedExample}<span class="input-label-asterisk">${(0,U.z)(t=>t.validationErrors.authorizedError,L.qy`<span class="required-text">${t=>t.strings.coprFormRequiredField}</span>`)}</span><div class="sub-text">${t=>t.strings.coprFormAuthorizedExSubTxt}</div></fluent-text-field><fluent-text-area class="${t=>t.validationErrors.descriptionError?"input-box-error":""}" rows=${7} name="description" :value=${t=>t.details.description} @change=${(t,e)=>t.onChangeDescription(e.event)}>${t=>t.strings.coprFormDescription}<span class="input-label-asterisk">${(0,U.z)(t=>t.validationErrors.descriptionError,L.qy`<span class="required-text">${t=>t.strings.coprFormRequiredField}</span>`)}</span><div class="sub-text">${t=>t.strings.coprFormDescriptionSubTxt}</div></fluent-text-area><fluent-text-field class="media-input">${t=>t.strings.coprFormAttachments}<p class="sub-text">${t=>t.strings.coprFormAttachmentsSubTxt}</p></fluent-text-field><input ${(0,_.K)("fileUploadActionRef")} type="file" @change=${(t,e)=>t.fileSelectHandler(e.event)} @drop=${(t,e)=>t.fileSelectHandler(e.event)} style="display: none;" accept=${rt.AcceptedAttachmentTypes} title=${t=>t.strings.coprFormUploadFileButton} multiple /><div class="media-container"><fluent-button appearance="accent" class="button" title=${t=>t.strings.coprFormUploadFileButton} @click=${t=>t.fileUploadActionRef.click()}>${t=>t.strings.coprFormUploadFileButton}</fluent-button>${(0,U.z)(t=>t.fileCount>0,L.qy` ${(0,H.ux)(t=>Object.entries(t.files),L.qy`<span class=" media ${t=>t[1].uploadState===X?"upload-failed":""} ${t=>t[1].uploadState===J?"upload-succeed":""} "><span>${t=>t[1].fileName} ∙<span class="media-status">${(t,e)=>e.parent.getFileUploadStateString(t[1].uploadState)} ${(0,U.z)(t=>t[1].uploadState===X,L.qy` ${(t,e)=>e.parent.getFileUploadFailureString(t[1].uploadFailureReason)} `)}></span></span><button class="media-remove-button" @click=${(t,e)=>e.parent.removeFile(t[0])}>${L.qy.partial(K())}</button></span>`)} `)} ${(0,U.z)(t=>0===t.fileCount,L.qy`<span class="media-span">${t=>t.strings.coprFormNoFileChosen}</span>`)}</div></div><p class="sub-text">${t=>t.strings.coprFormAttachmentsInfoTxt}</p></div><div class="button-container"><fluent-button appearance="accent" :disabled=${t=>t.waitingOrUploadingFileCount>0} title=${t=>t.strings.coprFormSubmitButton} class="button" @click=${(t,e)=>t.submitForm(e.event)}>${t=>t.strings.coprFormSubmitButton}</fluent-button><fluent-button appearance="outline" class="button" title=${t=>t.strings.coprFormResetButton} @click=${t=>t.resetForm()}>${t=>t.strings.coprFormResetButton}</fluent-button></div></div>`,lt=L.qy` ${(0,U.z)(t=>!!t.strings,L.qy` ${(0,U.z)(t=>0===t.currentStep,at)} ${(0,U.z)(t=>1===t.currentStep,st)} `)}
`;var dt=o(74849),ct=o(22131),ht=o(62047),pt=o(64003),ut=o(61138),mt=o(41123),ft=o(48751),bt=o(62198),gt=o(89580),vt=o(36452);const $t=dt.A` .sub-text{color:#D9D9D9}.input-label-asterisk{color:#FFCCCC}.required-text{color:#FFCCCC}fluent-text-field.input-box-error::part(root),fluent-text-area.input-box-error::part(control) border-color:#FFCCCC;box-shadow:0px 1px 1px #FFCCCC}.media{background-color:#4D4D4D;margin-inline:0 12px;padding-inline:10px 0}.upload-failed{background-color:#FF493E}.upload-succeed:{background-color:#576F3C}.media-span{color:#D9D9D9}`,xt=dt.A` .container{box-sizing:border-box;max-width:100vw;display:flex;flex-direction:column;padding:19px;padding-bottom:20px;max-height:85vh;overflow-y:auto;font-size:${ht.t};
        line-height: ${ht.e}}.input-container{display:flex;flex-direction:column}.separator{margin:20px 0}.sub-text{margin:4px 0;color:${pt.c};
        font-size: ${ut.k};
        line-height: ${ut.F}}.main-subtitle{margin:0;color:${pt.c};
        font-size: ${ut.k};
        line-height: ${ut.F};text-align:center}.header-container{display:flex;flex-direction:column;align-items:center}fluent-text-field{margin-bottom:20px}fluent-text-field.input-box-error::part(root),fluent-text-area.input-box-error::part(control){border-color:#B30000;box-shadow:0px 1px 1px #B30000}fluent-text-area{margin-bottom:20px}fluent-text-area::part(label){font-size:${mt.K}}.main-title{margin:0;margin-bottom:8px;color:${ft.l};
        font-weight: 600;
        font-size: ${bt.a};
        line-height: ${bt.b}}.button-container{display:flex;justify-content:center;margin-top:20px}.button{min-width:134px}.button:not(:last-child){margin-inline:0 8px}.input-label{display:flex;justify-content:space-between;font-weight:600;color:${ft.l}}.input-label-asterisk{color:#B30000}.input-label-asterisk::before{content:'*'}.required-text{color:#B30000}.input-disabled{font-weight:400;color:${ft.l}}.header-section{margin-bottom:8px;color:${ft.l};
        font-weight: 600;
        font-size: ${gt.Y};
        line-height: ${gt.v}}.media-container{position:relative;min-height:36px;display:flex;flex-wrap:wrap;align-items:center;border:1px solid;padding:4px;box-shadow:0px 4px 4px rgba(0,0,0,0.02);border-color:${vt.MY}}.media-input{margin-bottom:0}.media-input::part(root){position:absolute;height:100%;opacity:0;width:100%}.media-input:hover{cursor:pointer}.media-container .button{margin:4px 0px 4px;margin-inline:0 12px;z-index:1}.media{margin:4px 0px 4px;display:flex;z-index:10;align-items:center;border-radius:4px;background-color:#C2C2C2;color:${ft.l}}.upload-failed{background-color:#FF7970}.upload-succeed:{background-color:#A4BE87}.media-remove-button{display:flex;padding:0;border:0;cursor:pointer;outline:1px outset buttonborder}.media-status{font-style:italic}.media-span{z-index:10;color:${pt.c};
    }
`.withBehaviors((0,ct.G2)($t));function yt(t){const e=t.split(".");return 1===e.length||""===e[0]&&2===e.length?"":e.pop().toLowerCase()}class kt extends G.L{constructor(){super(...arguments),this.currentStep=0,this.formIsValid=!1,this.files={},this.contactInfo={firstName:"",lastName:"",email:""},this.details={authorizedExample:"",description:""},this.validationErrors={firstNameError:"",lastNameError:"",emailError:"",emailSyntaxError:"",authorizedError:"",descriptionError:""}}getFileUploadStateString(t){return{[Z]:this.strings.coprFormFileWaiting||"Waiting",[Q]:this.strings.coprFormFileUploading||"Uploading",[J]:this.strings.coprFormFileUploaded||"Uploaded",[X]:this.strings.coprFormFileUploadFailed||"Failed"}[t]}getFileUploadFailureString(t){return{[tt]:this.strings.coprFormFileSizeFailure||"File size exceeds 10MB",[et]:this.strings.coprFormFileFormatFailure||"File format is not supported",[ot]:this.strings.coprFormFileCountFailure||"Maximum 10 files can be uploaded",[it]:this.strings.coprFormFileOtherFailure||"Something went wrong, try again"}[t]}async fileSelectHandler(t){const e=t.target,o=null==e?void 0:e.files;if(!o||0===o.length)return;const i=t=>`${t.name}-${t.lastModified}-${t.size}`;Object.values(o).forEach(t=>{const e=i(t);this.files[e]||this.updateFileState(i(t),t.name,Z)});for(let t=0;t<o.length;t++){const e=o[t],r=i(e),n=yt(e.name),a=this.files[r]&&this.files[r].uploadState!==Z,s=Object.values(this.files).filter(t=>t.uploadState===J).length,l=this.updateFileState.bind(this,r,e.name);if(!a)if(e.size>rt.MaxFileSize)l(X,void 0,tt);else if(rt.AcceptedAttachmentTypes.includes(`.${n}`))if(s>=rt.MaxFileCount)l(X,void 0,ot);else try{l(Q);const t=await M.l.uploadCopyrightFile(e);l(J,t)}catch(t){l(X,void 0,it)}else l(X,void 0,et)}e.value=null}updateFileState(t,e,o,i,r){const n=this.files[t]||{};this.files={...this.files,[t]:{fileName:e,uploadState:o||n.uploadState,fileId:i||n.fileId,uploadFailureReason:r||n.uploadFailureReason}}}handleValidation(){const t=this.strings.coprFormRequiredField||"",e=e=>e?"":t,{contactInfo:o,details:i}=this,r={firstNameError:e(o.firstName),lastNameError:e(o.lastName),emailError:e(o.email),emailSyntaxError:(n=o.email,void 0!==n&&n&&/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(n)?"":this.strings.coprFormEmailValidation||""),authorizedError:e(i.authorizedExample),descriptionError:e(i.description)};var n;const a=Object.values(r).some(t=>""!=t);return this.validationErrors=r,this.formIsValid=!a,!a}proceedToStep1(){this.currentStep=1}submitForm(t){if(t.preventDefault(),!this.handleValidation())return;const e={reportMessage:this.details.description,intellectualPropertyDetails:{FirstName:this.contactInfo.firstName,LastName:this.contactInfo.lastName,EmailAddress:this.contactInfo.email,AuthorizedExample:this.details.authorizedExample,AttachedFiles:Object.values(this.files).filter(t=>t.uploadState===J).map(t=>t.fileId)}};this.reportItemType&&this.reportType?M.l.reportUser(this.targetId,this.reportItemType,this.reportType,e):M.l.reportComment(this.targetId,this.reportType||"Copyright",e),this.$emit("on-report"),this.$emit("close-popup")}onChangeAuthorizedExample(t){const e=t.target;this.details={...this.details,[e.name]:e.value},this.validationErrors={...this.validationErrors,authorizedError:""}}onChangeDescription(t){const e=t.target;this.details={...this.details,[e.name]:e.value},this.validationErrors={...this.validationErrors,descriptionError:""}}handleContactInfoOnChange(t){const e=t.target,o=e.name;this.contactInfo={...this.contactInfo,[o]:e.value},this.validationErrors={...this.validationErrors,[o+"Error"]:"",emailSyntaxError:"email"===o?"":this.validationErrors.emailSyntaxError}}removeFile(t){const e={...this.files};delete e[t],this.files=e}resetForm(){this.files={},this.contactInfo={firstName:"",lastName:"",email:""},this.details={authorizedExample:"",description:""},this.validationErrors={firstNameError:"",lastNameError:"",emailError:"",emailSyntaxError:"",authorizedError:"",descriptionError:""}}get step1InputFields(){const{firstName:t,lastName:e,email:o}=this.contactInfo,{firstNameError:i,lastNameError:r,emailError:n}=this.validationErrors;return[{label:this.strings.coprFormContactInfoFirstName||"",inputName:"firstName",inputValue:t,error:!!i},{label:this.strings.coprFormContactInfoLastName||"",inputName:"lastName",inputValue:e,error:!!r},{label:this.strings.coprFormContactInfoEmail||"",inputName:"email",inputValue:o,error:!!n}]}get fileCount(){return Object.keys(this.files).length}get waitingOrUploadingFileCount(){return Object.values(this.files).filter(t=>t.uploadState===Z||t.uploadState===Q).length}get config(){return this.experienceConfig}get strings(){return this.experienceConfig&&this.experienceConfig.localizedStrings}}(0,p.Cg)([R.CF],kt.prototype,"reportType",void 0),(0,p.Cg)([R.CF],kt.prototype,"reportItemType",void 0),(0,p.Cg)([R.CF],kt.prototype,"targetId",void 0),(0,p.Cg)([R.CF],kt.prototype,"currentStep",void 0),(0,p.Cg)([R.CF],kt.prototype,"formIsValid",void 0),(0,p.Cg)([S.sH],kt.prototype,"markTtvr",void 0),(0,p.Cg)([S.sH],kt.prototype,"files",void 0),(0,p.Cg)([S.sH],kt.prototype,"contactInfo",void 0),(0,p.Cg)([S.sH],kt.prototype,"details",void 0),(0,p.Cg)([S.sH],kt.prototype,"validationErrors",void 0),(0,p.Cg)([A],kt.prototype,"experienceConfig",void 0);let wt=class extends kt{};wt=(0,p.Cg)([(0,G.E)({name:"copyright-form",template:lt,styles:xt})],wt);var Ct=o(73182),Tt=o(60239);Ct.MsnActionsMenu;const Ft=L.qy`
${(0,H.ux)(t=>t.filteredReportingTraits,L.qy`<li role="option" class="cwt-access-li" @click=${(t,e)=>e.parent.reportHandler(t,e.event)} @keydown=${(t,e)=>e.parent.handleKeyDown(e.event)} tabIndex="0">${(t,e)=>e.parent.getReportingTraitString(t)}</li>`)}`,Mt=L.qy`<msn-actions-menu :referrerButton=${t=>t.actionsMenuButtonElement} :menuItems=${t=>t.actionsMenuProps.menuItems} :defaultVerticalPosition=${t=>t.defaultVerticalPosition} :defaultHorizontalPosition=${t=>t.defaultHorizontalPosition} class="report-menu-actions"></msn-actions-menu>`,Rt=L.qy`<ul role="listbox" aria-label=${t=>t.strings.AriaLabelsOpenReportCommentMenu} class=${t=>(0,q.x)("socialReportMenuContainer","socialReportMenuSuperAppContainer",t.responsiveClass)}><i class="cwt-icon cwt-menu-header" id="cwt-menu-header-username"><span class="cwt-icon-label">${t=>t.strings.CommentReportText}</span></i>${Ft}</ul>`;function St(t){return"function"==typeof t?t():t}const zt=t=>`<a class="link" href="${m.v.externalUrls.guidelinePage}" target="_blank">${t}</a>`,Et=L.qy`<div class="modal-header"><h2 class="modal-header-title">${t=>t.reportModalHeaderTitle}</h2><p aria-live="assertive" class="modal-header-body" :innerHTML="${(0,O.U)(t=>{const e="thankyou"===t.reportModalStep?t.strings.reportModalThankYouSubtitle:t.strings.reportModalHeaderSubtitle;return B.Qf.Format(e,{guidelinesLink:zt(t.strings.reportModalSeeFullGuidelinesText),menuType:t.localizedMenuType})},Tt.r)}"></p><div class="modal-separator"></div>${(0,U.z)(t=>"comment"===t.menuType,L.qy`<div class="modal-comment-body">${t=>t.commentBody}</div>`)}</div>`,At=L.qy` ${(0,U.z)(t=>"thankyou"!==t.reportModalStep,L.qy`<div class="modal-separator"></div>`)}<div class="modal-action-buttons">${(0,U.z)(t=>!!t.reportModalActionButtons,L.qy` ${(0,U.z)(t=>{var e;return null===(e=t.reportModalActionButtons)||void 0===e||null===(e=e.primary)||void 0===e?void 0:e.title},L.qy`<fluent-button appearance="accent" aria-label=${t=>{var e;return null===(e=t.reportModalActionButtons)||void 0===e?void 0:e.primary.title}} ?disabled=${t=>{var e;return St(null===(e=t.reportModalActionButtons)||void 0===e?void 0:e.primary.disabled)}} @click=${(t,e)=>{var o;return null===(o=t.reportModalActionButtons)||void 0===o||null===(o=o.primary.onclick)||void 0===o?void 0:o.bind(t)(e.event)}} @keypress=${(t,e)=>{var o;return u.y.handleOnKeyType(e.event,null===(o=t.reportModalActionButtons)||void 0===o||null===(o=o.primary.onclick)||void 0===o?void 0:o.bind(t),z.Mm)}} data-t=${t=>{var e;return St(null===(e=t.reportModalActionButtons)||void 0===e?void 0:e.primary.telemetryTag)}}>${t=>{var e;return null===(e=t.reportModalActionButtons)||void 0===e?void 0:e.primary.title}}</fluent-button>`)}<fluent-button appearance="neutral" aria-label=${t=>{var e;return null===(e=t.reportModalActionButtons)||void 0===e?void 0:e.cancel.title}} ?disabled=${t=>{var e;return St(null===(e=t.reportModalActionButtons)||void 0===e?void 0:e.cancel.disabled)}} @click=${(t,e)=>{var o;return null===(o=t.reportModalActionButtons)||void 0===o||null===(o=o.cancel.onclick)||void 0===o?void 0:o.bind(t)(e.event)}} @keydown=${(t,e)=>t.handleTabOnCancelButtonKeyDown(e.event)} data-t=${t=>{var e;return St(null===(e=t.reportModalActionButtons)||void 0===e?void 0:e.cancel.telemetryTag)}}>${t=>{var e;return null===(e=t.reportModalActionButtons)||void 0===e?void 0:e.cancel.title}}</fluent-button>`)}</div>`,It=L.qy`<div><h3 aria-live="assertive" id="reportTitle">${t=>B.Qf.Format(t.strings.reportModalIntroTitle,{menuType:t.localizedMenuType})}</h3><fluent-radio-group value="${t=>t.selectedReportReason}" @change="${(t,e)=>t.onReportReasonSelection(e.event)}" required="true" orientation="vertical" class="report-reason-radio-group" aria-labelledby="reportTitle"><fluent-radio tabIndex="0" value="nonViolation" id="non-violation" aria-label=${t=>B.Qf.Format(t.strings.reportModalIntroNonViolation,{menuType:t.localizedMenuType})} class=${t=>"nonViolation"===t.selectedReportReason?"radio-button-selected":""}>${t=>B.Qf.Format(t.strings.reportModalIntroNonViolation,{menuType:t.localizedMenuType})}</fluent-radio><fluent-radio tabIndex="0" value="violation" id="violation" aria-label=${t=>B.Qf.Format(t.strings.reportModalIntroViolation,{guidelinesLink:t.strings.reportModalCommunityGuidelinesText,menuType:t.localizedMenuType})} class=${t=>"violation"===t.selectedReportReason?"radio-button-selected":""} :innerHTML=${(0,O.U)(t=>B.Qf.Format(t.strings.reportModalIntroViolation,{guidelinesLink:zt(t.strings.reportModalCommunityGuidelinesText),menuType:t.localizedMenuType}),Tt.r)}></fluent-radio></fluent-radio-group></div>`,Bt=L.qy`<div><h3 aria-live="assertive">${t=>B.Qf.Format(t.strings.reportModalNonViolationTitle,{menuType:t.localizedMenuType})}</h3><p class="modal-non-violation-body">${t=>B.Qf.Format(t.strings.reportModalNonViolationBody,{menuType:t.localizedMenuType})}</p></div>`,Nt=L.qy`<div><h3 aria-live="assertive" id="reportTitle">${t=>B.Qf.Format(t.strings.reportModalViolationReasonTitle,{menuType:t.localizedMenuType})}</h3>${(0,U.z)(t=>{var e;return null===(e=t.reportMenuOptions)||void 0===e?void 0:e.length},L.qy`<fluent-radio-group value="${t=>t.selectedReportTrait}" @change="${(t,e)=>t.onReportTraitChange(e.event)}" required="true" orientation="vertical" class="report-traits-radio-group ${t=>{var e;return null!==(e=t.selectedReportTrait)&&void 0!==e&&e.startsWith("misinformation")?"":"two-columns"}}" aria-labelledby="reportTitle">${(0,H.ux)(t=>t.reportMenuOptions,L.qy`<fluent-radio value=${t=>t} id=${t=>t} aria-label=${(t,e)=>{var o;return null===(o=e.parent)||void 0===o?void 0:o.strings[t]}} class=${(t,e)=>{var o;return(null===(o=e.parent)||void 0===o?void 0:o.selectedReportTrait)===t?"radio-button-selected":""}}>${(t,e)=>{var o;return null===(o=e.parent)||void 0===o?void 0:o.strings[t]}}</fluent-radio>`)}</fluent-radio-group>`)}</div>`,Pt=L.qy`<input value="${t=>t.freeFormResponse}" @input="${(t,e)=>t.onFreeFormReportChange(e.event)}" placeholder="${t=>t.strings.freeformResponsePlaceholder}" aria-label="${t=>t.strings.freeformResponsePlaceholder}" class="modal-comment-body freeform-response-input"></input>`,Vt=L.qy` ${Et} ${(0,U.z)(t=>"intro"===t.reportModalStep,It)} ${(0,U.z)(t=>"nonViolation"===t.reportModalStep,Bt)} ${(0,U.z)(t=>"violation"===t.reportModalStep,Nt)} ${(0,U.z)(t=>"freeform"===t.reportModalStep,Pt)} ${At}
`,Dt=L.qy`<copyright-form targetId=${t=>t.targetId} @close-popup=${t=>t.closeCopyrightModal()} @on-report=${t=>t.closeReportModal()}></copyright-form>`,Lt=L.qy`
${(0,U.z)(t=>t.shouldRenderReportModal,L.qy`<div class="modal-outer-container"><fluent-dialog class="modal-container" @dismiss=${(t,e)=>t.dismissModal(e.event)} modal><div class="modal-content"><fluent-button ${(0,_.K)("closeButtonRef")} class="modal-close-button" title="${t=>t.strings.reportModalCloseButtonTitle}" appearance="stealth" aria-label="${t=>t.strings.reportModalCloseButtonTitle}" data-t=${t=>t.telemetryContext.reportModalClose.getMetadataTag()} @click="${(t,e)=>t.closeReportModal(e.event)}" @keypress=${(t,e)=>u.y.handleOnKeyType(e.event,()=>{t.closeReportModal(),t.focusReportButton()},z.Mm)}>${L.qy.partial(W())}</fluent-button>${(0,U.z)(t=>!t.isCopyright,Vt,Dt)}</div></fluent-dialog></div>`)}
`,Ht=L.qy`
${(0,U.z)(t=>!!t.filteredReportingTraits,L.qy`<fluent-design-system-provider fill-color="${t=>t.backgroundColor}" direction="${()=>document.dir}" base-layer-luminance="${t=>t.baseLayerLuminance}">${(0,U.z)(t=>!t.renderInPopover,Rt)} ${(0,U.z)(t=>t.renderInPopover&&t.config.renderAsModal,Lt)} ${(0,U.z)(t=>t.renderInPopover&&!t.config.renderAsModal,Mt)}</fluent-design-system-provider>`)}
`;var Ot=o(92393),Ut=o(70246),_t=o(45476),qt=o(10735),jt=o(4283),Wt=o(86856),Gt=o(77558),Yt=o(77078),Kt=o(50882),Zt=o(38001);const Qt=dt.A` .socialReportMenuContainer{letter-spacing:-0.012em}.socialReportMenuContainer:-moz-any(#content,#appcontent) browser{margin-right:-14px !important}.socialReportMenuPopover{right:0}`,Jt=dt.A` .socialReportMenuContainer{letter-spacing:0}.socialReportMenuContainer:-moz-any(#content,#appcontent) browser{margin-left:-14px !important}.socialReportMenuPopover{left:0}`,Xt=dt.A` fluent-dialog::part(control){background-color:${(0,Zt.DK)()?"#242424":"#f7f7f7"}}.modal-close-button{background:${(0,Zt.DK)()?"#242424":"#f7f7f7"}}.modal-close-button::part(control){filter:${(0,Zt.DK)()?"invert(1)":""}}.modal-header-title{color:${(0,Zt.DK)()?"#f5f5f5":"#262626"}}.modal-header-body{color:${(0,Zt.DK)()?"#f5f5f5":"#262626"}}.modal-comment-body{color:${(0,Zt.DK)()?"#f5f5f5":"#262626"};
    }

    .modal-container h3{
        color: ${(0,Zt.DK)()?"#f5f5f5":"#262626"}}.report-reason-radio-group fluent-radio::part(control){border:${(0,Zt.DK)()?"calc(var(--stroke-width) * 1px) solid #6e6e6e":"calc(var(--stroke-width) * 1px) solid #8f8f8f"};
        background: ${(0,Zt.DK)()?"#242424":"#f7f7f7"}}.report-reason-radio-group fluent-radio::part(label){color:${(0,Zt.DK)()?"#f5f5f5":"#262626"}}.report-traits-radio-group fluent-radio::part(control){border:${(0,Zt.DK)()?"calc(var(--stroke-width) * 1px) solid #6e6e6e":"calc(var(--stroke-width) * 1px) solid #8f8f8f"};
        background: ${(0,Zt.DK)()?"#242424":"#f7f7f7"}}.report-traits-radio-group fluent-radio::part(label){color:${(0,Zt.DK)()?"#f5f5f5":"#262626"}}.modal-action-buttons fluent-button:last-child{background-color:${(0,Zt.DK)()?"#363636":"#e5e5e5"};
        color: ${(0,Zt.DK)()?"#f5f5f5":"#262626"}}.modal-non-violation-body{color:${(0,Zt.DK)()?"#f5f5f5":"#262626"}}fluent-radio.radio-button-selected::part(control){border-color:${Ot.QL};
    }
`,te=dt.A` .socialReportMenuContainer{width:140px;height:190px;padding:4px 0 !important;font-size:14px;background:${Ut.k};border-radius:8px;box-shadow:0px 0px 5.6px rgba(0,0,0,0.11),0px 6.4px 14.4px rgba(0,0,0,0.13);overflow-y:scroll;-ms-overflow-style:none}.socialReportMenuContainer li{padding:8px 14px !important;color:${ft.l}}.socialReportMenuContainer li:hover{background:${_t.oO};cursor:pointer}.socialReportMenuContainer::-webkit-scrollbar{display:none}.socialReportMenuContainer:-moz-any(#content,#appcontent) browser{overflow-y:scroll;margin-bottom:-14px !important;overflow-x:scroll}.socialReportMenuPopover{top:10px}.socialReportMenuSuperAppContainer{max-height:75vh;max-width:100vw;width:500px;height:100%;font-size:16px;background:${_t.oO};border-radius:12px 12px 0 0;margin:0;padding-top:0 !important;padding-bottom:70px !important;min-height:450px}.socialReportMenuSuperAppContainer .cwt-menu-header{display:flex;align-items:center;padding:20px 27px;border-bottom:1px solid;border-color:${vt.MY};
        background: ${qt.T};margin-bottom:24px;position:sticky;top:0;font-weight:bold;font-style:normal}.socialReportMenuSuperAppContainer .cwt-menu-header .cwt-icon-label{font-size:22px;font-style:inherit;color:${ft.l};padding:0 5px;margin-top:-.12em}.socialReportMenuSuperAppContainer li{cursor:pointer;padding:14px 24px !important;background:${qt.T};font-size:16px;line-height:20px}.socialReportMenuSuperAppContainer li:hover{background:${_t.oO}}.report-menu-actions::part(menu)::-webkit-scrollbar{display:none}.report-menu-actions::part(menu){width:140px;height:199px;overflow:hidden scroll;min-width:unset;border:unset;border-radius:8px;background:${_t.Wl}}.report-menu-actions::part(menu-item){display:flex;padding:5px 0px;font-size:12px;word-break:keep-all;white-space:inherit;grid-template-columns:max-content;height:unset;min-height:calc((var(--base-height-multiplier) + var(--density)) * var(--design-unit) * 1px);border-radius:unset;margin:unset;color:${ft.l}}.report-menu-actions::part(menu-item):hover{background:${_t.oO}}h2,h3,p{margin:0}.modal-outer-container{position:fixed;width:100%;height:100%;top:0px;left:0px;right:0px;bottom:0px;background-color:rgba(0,0,0,0.5);z-index:${Gt.P.Banner.toString()}}fluent-dialog::part(control){width:633px;height:unset;border-radius:12px}fluent-radio.radio-button-selected::part(control){border-color:${jt.am}}.modal-container fluent-radio::part(checked-indicator){border-color:${jt.am};
        background-color: ${jt.am}}.freeform-response-input{width:85%}.freeform-response-input:focus{max-height:unset;min-height:33px}.modal-container a{text-decoration:none;color:${Ot.W_}}.modal-container a:hover{text-decoration:underline}.modal-content{position:relative;padding:32px}.modal-close-button{position:absolute;top:14px;right:12px;width:16px;height:16px}.modal-close-button:hover{background:none}.modal-header-title{margin-bottom:6px;font-weight:600;font-size:18px;line-height:20px;color:${ft.l}}.modal-header-body{margin-bottom:12px;padding-right:60px;font-weight:400;font-size:12px;line-height:18px;color:${ft.l}}.modal-separator{margin-bottom:20px;width:100%;height:1px;background-color:rgba(143,158,205,0.2)}.modal-comment-body{color:${ft.l};border-radius:8px;padding:10px 46px 10px 16px;font-size:14px;font-weight:400;line-height:20px;margin-bottom:16px;white-space:pre-line}@media (prefers-color-scheme:dark){.modal-comment-body{background:#212D3D}}@media (prefers-color-scheme:light){.modal-comment-body{background:#ECF4FF}}.modal-action-buttons{width:100%;display:flex;flex-direction:row;justify-content:center}.modal-action-buttons fluent-button{border-radius:20px;width:131px;height:36px}.modal-action-buttons fluent-button:first-child{margin-right:16px}fluent-button::part(control){letter-spacing:inherit}.modal-container h3{font-weight:600;font-size:14px;line-height:20px;color:${ft.l};margin-bottom:12px}.modal-non-violation-body{font-weight:400;font-size:14px;line-height:20px;color:${ft.l};margin-bottom:12px}.report-reason-radio-group{margin-bottom:12px}.report-traits-radio-group{margin-bottom:20px}.two-columns::part(positioning-region){display:grid;grid-template-columns:50% 50%;width:100%}.link:hover,.link:focus{text-decoration:underline}${(0,Yt.RH)()?Xt:""}
`.withBehaviors(new Wt.t(Qt,Jt),(0,ct.mr)(dt.A` @media (-ms-high-contrast:active){.report-menu-actions::part(menu){border:1px solid ${Kt.A.ButtonText};
                }
                .report-menu-actions::part(menu-item){
                    color: ${Kt.A.ButtonText};
                    fill: ${Kt.A.ButtonText};
                }
                .report-menu-actions::part(menu-item):hover{
                    color: ${Kt.A.HighlightText};
                    background: ${Kt.A.Highlight};
                }
            }
        `)),ee={experienceConfigSchema:undefined,mockConfig:{localizedStrings:{AriaLabelsOpenReportCommentMenu:"Report",CommentReportText:"Report",freeformResponsePlaceholder:"Tell us more about what you're reporting",spam:"Spam",profanity:"Profanity",copyright:"Copyright","child-related":"Child Sexual Exploitation or Abuse",violence:"Violence",danger:"Danger to self or others","public-threats":"Public Threats",illegal:"Illegal",terrorism:"Terrorism or violent extremism",privacy:"Privacy",inappropriate:"Inappropriate for this Community",impersonation:"Impersonation","bullying-and-harassment":"Bullying and Harassment","hate-speech":"Hate Speech",suicide:"Suicide and self-harm",trademark:"Trademark",misinformation:"Misinformation","misinformation-us-2020":"Misinformation US 2020 Elections","misinformation-brazil-election":"Misinformation Brazil Election","misinformation-school-shooting":"Misinformation School Shooting","misinformation-russia-ukraine":"Misinformation Russia Ukraine","misinformation-covid":"Misinformation Covid","misinformation-qanon":"Misinformation QAnon","misinformation-monkeypox":"Misinformation Monkeypox","harmful-content":"Harmful Content","influencing-political-process":"Misuse for Influencing Political Process","med-financial-legal-advice":"Medical, Financial, or Legal Advice",stereotyping:"Stereotyping","reinforcement-of-bias":"Reinforcement of Bias","encouraging-harmful-actions":"Encouraging Harmful Actions","innacurate-or-misleading":"Inaccurate or Misleading",reportModalHeaderTitle:"Report this {menuType}",reportModalHeaderSubtitle:"Thanks for helping keep our community safe. Please give us some more information on why you are reporting this {menuType}. {guidelinesLink}",reportModalIntroTitle:"Why are you reporting this {menuType}?",reportModalIntroNonViolation:"I don’t like or agree with the {menuType}",reportModalIntroViolation:"I believe the {menuType} violates the {guidelinesLink}",reportModalNonViolationTitle:"Why are you reporting this {menuType}?",reportModalNonViolationBody:"Thank you for your feedback, we will use it to improve our experiences. We only review {menuType}s that people believe to be violating our community guidelines. If you think this {menuType} does violate our guidelines, please go back to report it.",reportModalViolationReasonTitle:"Which guideline does this {menuType} violate?",reportModalSubmitReportButton:"Submit report",reportModalGoBackButton:"Go back",reportModalOkayButton:"Okay",reportModalContinueButton:"Continue",reportModalCancelButton:"Cancel",reportModalCommunityGuidelinesText:"community guidelines",reportModalSeeFullGuidelinesText:"See full guidelines & policies",reportModalCloseButtonTitle:"Close",reportModalThankYouTitle:"Thank you for your feedback",reportModalThankYouSubtitle:"Thanks for helping keep our community safe by reporting this {menuType}. {guidelinesLink}",coprFormCheckTxt:"File a report",coprFormCheckSubTxt:"We appreciate your feedback. We can only accept requests for content removal from the copyright owner or authorized agent on concerns about copyright infringement.",coprFormMainTxt:"Possible copyright infringement",coprFormMainSubTxt:"This form is provided to report a possible copyright violation. For your submission to proceed, all required fields must be filled in completely.  A complaint cannot be investigated if the form is incomplete or missing relevant data.",coprFormContentIssueTitle:"Content issue",coprFormCommentIDTitle:"Comment ID",coprFormUserIDTitle:"User ID",coprFormContactInfoTitle:"Your contact information",coprFormContactInfoFirstName:"First name",coprFormContactInfoLastName:"Last name",coprFormContactInfoEmail:"Email address",coprFormDetailsTitle:"Details",coprFormAuthorizedExample:"Authorized example of copyrighted work",coprFormAuthorizedExSubTxt:"Page specific URL where we can view the work (if available online, e.g., http://www.contoso.com/specificpage.html)",coprFormDescription:"Description",coprFormDescriptionSubTxt:"Please provide a detailed description of the work and/or upload an example of the work so that we can identify it. If you are reporting infringement of multiple works, please submit a different notice for each work.",coprFormAttachments:"Attachments",coprFormAttachmentsSubTxt:"You may upload a file containing your copyrighted work:",coprFormAttachmentsInfoTxt:"To upload multiple attachments, please click 'Choose file' and press 'Ctrl' to select files. Supported file formats (.pdf, .txt, .docx, .msg, .xlsx, .xls), 10MB maximum.",coprFormRequiredField:"Please fill out this field",coprFormEmailValidation:"Please enter a valid email",coprFormContinueButtonTitle:"Yes, continue",coprFormUploadFileButton:"Choose files",coprFormNoFileChosen:"No file Chosen",coprFormSubmitButton:"Submit",coprFormResetButton:"Reset",coprFormFileWaiting:"Waiting",coprFormFileUploading:"Uploading",coprFormFileUploaded:"Uploaded",coprFormFileUploadFailed:"Failed",coprFormFileSizeFailure:"File size exceeds 10MB",coprFormFileFormatFailure:"File format is not supported",coprFormFileCountFailure:"Maximum 10 files can be uploaded",coprFormFileOtherFailure:"Something went wrong, try again",coprFormCancelButtonTitle:"Cancel",sentimentPicker:"sentiment picker",poll:"poll",comment:"comment"},renderAsModal:!0}};i.m.define(r.c.registry),n.m.define(r.c.registry),a.m.define(r.c.registry),s.m.define(r.c.registry),l.m.define(r.c.registry),d.m.define(r.c.registry),c.m.define(r.c.registry),h.m.define(r.c.registry)},43774(t,e,o){o.d(e,{p4(){return f},ls(){return b},vA(){return m},nF(){return u}});var i=o(45755),r=o(68009),n=o(95239);const{create:a}=i.G,s=a("neutral-stroke-strong-hover-delta",40),l=a("neutral-stroke-strong-active-delta",16),d=a("neutral-stroke-strong-focus-delta",25);var c=o(31023);const{create:h}=i.G,p=h({name:"neutral-stroke-strong-recipe"},{evaluate(t){return function(t,e,o,i,n,a){const s=(0,r.F)(e),l=t.colorContrast(e,o),d=t.closestIndexOf(l);return{rest:l,hover:t.get(d+s*i),active:t.get(d+s*n),focus:t.get(d+s*a)}}(t(c.r),t(n.p),3,t(s),t(l),t(d))}}),u=h("neutral-stroke-strong-rest",t=>t(p).evaluate(t).rest),m=h("neutral-stroke-strong-hover",t=>t(p).evaluate(t).hover),f=h("neutral-stroke-strong-active",t=>t(p).evaluate(t).active),b=h("neutral-stroke-strong-focus",t=>t(p).evaluate(t).focus)},58661(t,e,o){o.d(e,{m(){return U}});var i=o(37180),r=o(56911),n=o(38493),a=o(60815),s=o(76881),l=o(88458),d=o(92011),c=o(56863);class h extends d.L{}class p extends((0,c.rf)(h)){constructor(){super(...arguments),this.proxy=document.createElement("textarea")}}const u="none";class m extends p{constructor(){super(...arguments),this.resize=u,this.cols=20,this.handleTextInput=()=>{this.value=this.control.value}}readOnlyChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.readOnly=this.readOnly)}autofocusChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.autofocus=this.autofocus)}listChanged(){this.proxy instanceof HTMLTextAreaElement&&this.proxy.setAttribute("list",this.list)}maxlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.maxLength=this.maxlength)}minlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.minLength=this.minlength)}spellcheckChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.spellcheck=this.spellcheck)}select(){this.control.select(),this.$emit("select")}handleChange(){this.$emit("change")}validate(){super.validate(this.control)}}(0,r.Cg)([(0,n.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],m.prototype,"readOnly",void 0),(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],m.prototype,"resize",void 0),(0,r.Cg)([(0,n.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],m.prototype,"autofocus",void 0),(0,r.Cg)([(0,n.CF)({attribute:"form"}),(0,r.Sn)("design:type",String)],m.prototype,"formId",void 0),(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],m.prototype,"list",void 0),(0,r.Cg)([(0,n.CF)({converter:n.R$}),(0,r.Sn)("design:type",Number)],m.prototype,"maxlength",void 0),(0,r.Cg)([(0,n.CF)({converter:n.R$}),(0,r.Sn)("design:type",Number)],m.prototype,"minlength",void 0),(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],m.prototype,"name",void 0),(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],m.prototype,"placeholder",void 0),(0,r.Cg)([(0,n.CF)({converter:n.R$,mode:"fromView"}),(0,r.Sn)("design:type",Number)],m.prototype,"cols",void 0),(0,r.Cg)([(0,n.CF)({converter:n.R$,mode:"fromView"}),(0,r.Sn)("design:type",Number)],m.prototype,"rows",void 0),(0,r.Cg)([(0,n.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],m.prototype,"spellcheck",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Array)],m.prototype,"defaultSlottedNodes",void 0),(0,l.X)(m,s.gs);class f extends m{appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="outline")}}(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],f.prototype,"appearance",void 0);var b=o(74849),g=o(22131),v=o(50882),$=o(64187),x=o(73477),y=o(60993),k=o(61484),w=o(48196),C=o(17767),T=o(37302),F=o(7896),M=o(48751),R=o(46203),S=o(57416),z=o(26920),E=o(36452),A=o(41123),I=o(74838),B=o(14996),N=o(79288);const P=b.A`
    :host([appearance="filled"]) .control {
        background: ${T.F7};
        border-color: transparent;
    }

    :host([appearance="filled"]:hover:not([disabled])) .control {
        background: ${T.Xt};
        border-color: transparent;
    }

    :host([appearance="filled"]:focus-within:not([disabled])) .control {
        border-color: transparent;
        box-shadow: none;
    }
    ${k.p}
`.withBehaviors((0,g.mr)(b.A`
            :host([appearance="filled"]:hover:not([disabled])) .control,
            :host([appearance="filled"]:focus-within:not([disabled])) .control {
                background: ${v.A.Field};
                border-color: ${v.A.FieldText};
            }
            :host([appearance="filled"]:not([disabled]):active)::after,
            :host(
                    [appearance="filled"]:not([disabled]):focus-within:not(:active)
                )::after {
                border-bottom-color: ${v.A.Highlight};
            }
        `)),V=b.A`
    ${(0,$.V)("inline-flex")} :host {
        font-family: ${F.O};
        outline: none;
        user-select: none;
        position: relative;
        flex-direction: column;
        vertical-align: bottom;
    }

    .control {
        box-sizing: border-box;
        position: relative;
        color: ${M.l};
        background: ${R.le};
        border-radius: calc(${S.Pb} * 1px);
        border: calc(${z.XA} * 1px) solid ${E.I2};
        height: calc(${w.D} * 2px);
        font: inherit;
        font-size: ${A.K};
        line-height: ${A.Z};
        padding: calc(${I.vR} * 1.5px) calc(${I.vR} * 2px + 1px);
        width: 100%;
        resize: none;
    }

    .control:hover:enabled {
        background: ${R.jM};
        border-color: ${E.mb};
    }

    .control:hover,
    .control:${x.N},
    .control:disabled,
    .control:active {
        outline: none;
    }

    :host(:focus-within) .control {
        border-color: ${B.WN};
        box-shadow: 0 0 0 1px ${B.WN} inset;
    }

    :host(.resize-both) .control {
        resize: both;
    }

    :host(.resize-horizontal) .control {
        resize: horizontal;
    }

    :host(.resize-vertical) .control {
        resize: vertical;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        display: block;
        color: ${M.l};
        cursor: pointer;
        $font-size: ${A.K};
        line-height: ${A.Z};
        margin-bottom: 4px;
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${y.Z};
    }
    :host([disabled]) {
        opacity: ${N.q};
    }
`.withBehaviors((0,C.f)("filled",P),(0,g.mr)(b.A`
            :host([disabled]) {
                opacity: 1;
            }
            ::placeholder,
            ::-webkit-input-placeholder {
                color: ${v.A.FieldText};
            }
            :host([disabled]) ::placeholder,
            :host([disabled]) ::-webkit-input-placeholder,
            :host([disabled]) .label {
                color: ${v.A.GrayText};
            }
        `));var D=o(96950),L=o(82774),H=o(60402);const O=D.qy`
        <label
            part="label"
            for="control"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${(0,L.e)("defaultSlottedNodes")}></slot>
        </label>
        <textarea
            part="control"
            class="control"
            id="control"
            ?autofocus="${t=>t.autofocus}"
            cols="${t=>t.cols}"
            ?disabled="${t=>t.disabled}"
            form="${t=>t.form}"
            list="${t=>t.list}"
            maxlength="${t=>t.maxlength}"
            minlength="${t=>t.minlength}"
            name="${t=>t.name}"
            placeholder="${t=>t.placeholder}"
            ?readonly="${t=>t.readOnly}"
            ?required="${t=>t.required}"
            rows="${t=>t.rows}"
            ?spellcheck="${t=>t.spellcheck}"
            :value="${t=>t.value}"
            aria-atomic="${t=>t.ariaAtomic}"
            aria-busy="${t=>t.ariaBusy}"
            aria-controls="${t=>t.ariaControls}"
            aria-current="${t=>t.ariaCurrent}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-details="${t=>t.ariaDetails}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-errormessage="${t=>t.ariaErrormessage}"
            aria-flowto="${t=>t.ariaFlowto}"
            aria-haspopup="${t=>t.ariaHaspopup}"
            aria-hidden="${t=>t.ariaHidden}"
            aria-invalid="${t=>t.ariaInvalid}"
            aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
            aria-label="${t=>t.ariaLabel}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-live="${t=>t.ariaLive}"
            aria-owns="${t=>t.ariaOwns}"
            aria-relevant="${t=>t.ariaRelevant}"
            aria-roledescription="${t=>t.ariaRoledescription}"
            @input="${(t,e)=>t.handleTextInput()}"
            @change="${t=>t.handleChange()}"
            ${(0,H.K)("control")}
        ></textarea>
    `,U=f.compose({name:`${i.c.prefix}-text-area`,template:O,styles:V,shadowOptions:{delegatesFocus:!0}})},60239(t,e,o){o.d(e,{r(){return n}});var i=o(54996),r=o(42277);const n=o(68244).F.create({trustedType:{createHTML:t=>i.sanitize(t,{RETURN_TRUSTED_TYPE:!0})},guards:{aspects:{[r.D.property]:{innerHTML:(t,e,o,r)=>function(t,e,o){const n=i.sanitize(o,{RETURN_TRUSTED_TYPE:!0});for(var a=arguments.length,s=new Array(a>3?a-3:0),l=3;l<a;l++)s[l-3]=arguments[l];r(t,e,n,...s)}}}}})},70246(t,e,o){o.d(e,{k(){return h}});var i=o(45755),r=o(37820),n=o(97004),a=o(47691),s=o(356),l=o(31023);const{create:d}=i.G,c=d({name:"neutral-layer-card-container-recipe"},{evaluate(t){return function(t,e,o){const i=(0,r.qE)(t.closestIndexOf((0,n.Z)(e))-o,0,t.swatches.length-1);return t.get(i+o)}(t(l.r),t(s.l),t(a.E))}}),h=d("neutral-layer-card-container",t=>t(c).evaluate(t))},83397(t,e,o){o.d(e,{y(){return n}});var i=o(2171),r=o(55230);class n{static get style(){return i.vv.get(this.styleKey)}static set style(t){i.vv.set(this.styleKey,t)}}n.styleKey=Symbol("style"),n.attachAccessibilityListeners=(t,e)=>{e?(Array.from(e.getElementsByClassName("cwt-sort-list-item")).map(n.addTabIndex),Array.from(e.getElementsByClassName("cwt-link")).map(n.addTabIndex),Array.from(e.getElementsByClassName("cwt-count-icons")).map(n.addTabIndex),Array.from(e.getElementsByClassName("cwt-access-li")).map(n.addTabIndex),Array.from(e.getElementsByClassName("cwt-button")).map(n.addTabIndex),Array.from(e.getElementsByClassName("cwt-privacy-checkbox")).map(n.addTabIndex),Array.from(e.getElementsByClassName("transaction-history-trigger")).map(n.addTabIndex),Array.from(e.getElementsByTagName("a")).map(n.addTabIndex)):(Array.from(t.getElementsByClassName("cwt-sort-list-item")).map(n.addTabIndex),Array.from(t.getElementsByClassName("cwt-link")).map(n.addTabIndex),Array.from(t.getElementsByClassName("cwt-count-icons")).map(n.addTabIndex),Array.from(t.getElementsByClassName("cwt-access-li")).map(n.addTabIndex),Array.from(t.getElementsByClassName("cwt-button")).map(n.addTabIndex),Array.from(t.getElementsByClassName("transaction-history-trigger")).map(n.addTabIndex),Array.from(t.getElementsByTagName("a")).map(n.addTabIndex)),!n.style&&n.addAccessibilityOutlines()},n.simulateMouseClick=t=>{function e(t,e){const o=document.createEvent("MouseEvents");o.initEvent(e,!0,!0),t.dispatchEvent(o)}t&&(e(t,"mousedown"),e(t,"click"))},n.addTabIndex=t=>{if("true"==t.getAttribute("no-access"))return null;!t.hasAttribute("tabIndex")&&t.setAttribute("tabIndex","0"),t.hasAttribute("hasEnterKeydown")||(t.setAttribute("hasEnterKeydown","1"),t.addEventListener("keydown",e=>{13===e.keyCode&&(n.simulateMouseClick(t),e.preventDefault(),e.stopPropagation())}))},n.addAccessibilityOutlines=()=>{let t=!1;const e=[9,37,38,39,40];n.style=document.createElement("style");document.head.append(n.style),document.addEventListener("keydown",o=>{e.includes(o.keyCode)&&!t&&(t=!0)}),document.addEventListener("mousedown",e=>{e.isTrusted&&(t=!1)}),document.addEventListener("focusin",e=>{!t&&e.isTrusted?n.style.innerText="[hasEnterKeydown]:focus { outline: none; }":n.style&&(n.style.innerText='[hasEnterKeydown]:focus {  outline: "black auto 1px";}')})},n.handleOnKeyType=function(t,e){let o=arguments.length>2&&void 0!==arguments[2]?arguments[2]:r.Mm;const i=t;if(i.key===o||Array.isArray(o)&&o.includes(i.key))return t.stopPropagation(),null==e?void 0:e(t)}},88817(t,e,o){o.d(e,{m(){return P}});var i=o(56911),r=o(38493),n=o(60815),a=o(55230),s=o(92011),l=o(56863);class d extends s.L{}class c extends((0,l.dx)(d)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends c{constructor(){super(),this.initialValue="on",this.proxy.setAttribute("type","radio")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}defaultCheckedChanged(){this.$fastController.isConnected&&!this.dirtyChecked&&(this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}connectedCallback(){super.connectedCallback(),this.validate(),"radiogroup"!==this.parentElement?.getAttribute("role")&&null===this.getAttribute("tabindex")&&(this.disabled||this.setAttribute("tabindex","0")),this.checkedAttribute&&(this.dirtyChecked||this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}isInsideRadioGroup(){return null!==this.closest("[role=radiogroup]")}keypressHandler(t){if(t.key!==a.gG)return!0;this.checked||this.readOnly||(this.checked=!0)}clickHandler(t){this.disabled||this.readOnly||this.checked||(this.checked=!0)}}(0,i.Cg)([(0,r.CF)({attribute:"readonly",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,i.Cg)([n.sH,(0,i.Sn)("design:type",String)],h.prototype,"name",void 0),(0,i.Cg)([n.sH,(0,i.Sn)("design:type",Array)],h.prototype,"defaultSlottedNodes",void 0);var p=o(37180),u=o(74849),m=o(64187),f=o(73477),b=o(60993),g=o(22131),v=o(50882),$=o(48196),x=o(74838),y=o(26920),k=o(43774),w=o(46203),C=o(7896),T=o(48751),F=o(41123),M=o(95239),R=o(14996),S=o(79288);const z=u.A`
    ${(0,m.V)("inline-flex")} :host {
        --input-size: calc((${$.D} / 2) + ${x.vR});
        align-items: center;
        outline: none;
        margin: calc(${x.vR} * 1px) 0;
        ${""} user-select: none;
        position: relative;
        flex-direction: row;
        transition: all 0.2s ease-in-out;
    }

    .control {
        position: relative;
        width: calc(var(--input-size) * 1px);
        height: calc(var(--input-size) * 1px);
        box-sizing: border-box;
        border-radius: 50%;
        border: calc(${y.XA} * 1px) solid ${k.nF};
        background: ${w.le};
        outline: none;
        cursor: pointer;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        font-family: ${C.O};
        color: ${T.l};
        ${""} padding-inline-start: calc(${x.vR} * 2px + 2px);
        margin-inline-end: calc(${x.vR} * 2px + 2px);
        cursor: pointer;
        font-size: ${F.K};
        line-height: ${F.Z};
    }

    .control,
    .checked-indicator {
        flex-shrink: 0;
    }

    .checked-indicator {
        position: absolute;
        top: 5px;
        left: 5px;
        right: 5px;
        bottom: 5px;
        border-radius: 50%;
        display: inline-block;
        background: ${T.l};
        fill: ${T.l};
        opacity: 0;
        pointer-events: none;
    }

    :host(:enabled) .control:hover {
        background: ${w.jM};
        border-color: ${k.vA};
    }

    :host(:enabled) .control:active {
        background: ${w.RS};
        border-color: ${k.p4};
    }

    :host(:${f.N}) .control {
        box-shadow: 0 0 0 2px ${M.p}, 0 0 0 4px ${R.WN};
        border-color: ${R.WN};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${b.Z};
    }

    :host([aria-checked="true"]) .checked-indicator {
        opacity: 1;
    }

    :host([disabled]) {
        opacity: ${S.q};
    }
`.withBehaviors((0,g.mr)(u.A`
            .control {
                forced-color-adjust: none;
                border-color: ${v.A.FieldText};
                background: ${v.A.Field};
            }
            :host(:enabled) .control:hover,
            .control:active {
                border-color: ${v.A.Highlight};
                background: ${v.A.Field};
            }
            :host(:${f.N}) .control {
                border-color: ${v.A.Highlight};
                box-shadow: 0 0 0 2px ${v.A.Field},
                    0 0 0 4px ${v.A.FieldText};
            }
            :host([aria-checked="true"]:${f.N}:enabled) .control {
                border-color: ${v.A.Highlight};
                box-shadow: 0 0 0 2px ${v.A.Field},
                    0 0 0 4px ${v.A.FieldText};
            }
            :host([aria-checked="true"]:enabled) .control:hover,
            .control:active {
                border-color: ${v.A.Highlight};
                background: ${v.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${v.A.Highlight};
                fill: ${v.A.Highlight};
            }
            :host([aria-checked="true"]) .control:hover .checked-indicator {
                background: ${v.A.HighlightText};
                fill: ${v.A.HighlightText};
            }
            :host([disabled]) {
                forced-color-adjust: none;
                opacity: 1;
            }
            :host([disabled]) .label {
                color: ${v.A.GrayText};
            }
            :host([disabled]) .control,
            :host([aria-checked="true"][disabled]) .control:hover,
            .control:active {
                background: ${v.A.Field};
                border-color: ${v.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                fill: ${v.A.GrayText};
                background: ${v.A.GrayText};
            }
        `));var E=o(96950),A=o(82774),I=o(79109),B=o(18893);const N=function(t={}){return E.qy`
        <template
            role="radio"
            aria-checked="${t=>t.checked}"
            aria-required="${t=>t.required}"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            @keypress="${(t,e)=>t.keypressHandler(e.event)}"
            @click="${(t,e)=>t.clickHandler(e.event)}"
        >
            <div part="control" class="control">
                <slot name="checked-indicator">
                    ${(0,B.R)(t.checkedIndicator)}
                </slot>
            </div>
            <label
                part="label"
                class="${t=>["label",!t.defaultSlottedNodes?.length&&"label__hidden"].filter(Boolean).join(" ")}"
            >
                <slot
                    ${(0,A.e)({property:"defaultSlottedNodes",filter:I.g})}
                ></slot>
            </label>
        </template>
    `}({checkedIndicator:E.qy`
        <div part="checked-indicator" class="checked-indicator"></div>
    `}),P=h.compose({name:`${p.c.prefix}-radio`,template:N,styles:z})}}]);