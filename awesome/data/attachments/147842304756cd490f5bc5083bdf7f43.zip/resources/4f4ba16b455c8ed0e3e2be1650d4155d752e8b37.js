"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-info-watchlist-ideas"],{4968(t,e,i){i.d(e,{f(){return l}});var r=i(64187),s=i(74849),a=i(42792),o=i(99657),n=i(36452);const l=s.A.partial`position: relative; z-index: ${o.D};`;s.A`
    ${a.e}
    ${a.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${n.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${n.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${n.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(a.kc)},9720(t,e,i){i.r(e),i.d(e,{WatchlistIdeas(){return z}});var r=i(56911),s=i(92707),a=i(94043);class o extends s.z{constructor(){super(...arguments),this.showWatchlistChart=(0,a.S)()}}var n=i(92011),l=i(12640),h=i(74849),d=i(64003),c=i(4968);const g=h.A` .return .text{color:rgba(255,255,255,0.78)}`,p=h.A` .wli-wrapper{text-decoration:none;color:inherit;${c.f}}.wli{height:100%;border-radius:8px}ul{list-style:none;padding-inline-start:0}.hlstCtr{display:grid;width:100%;grid-template-columns:repeat(5,auto);justify-content:space-between;align-items:center;overflow:hidden;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600;margin:10px 0 0}.card{background:none;display:flex;flex-direction:column;justify-content:space-between;border-radius:6px;padding:12px;width:268px;height:100%;box-sizing:border-box}.hlstCtr.vert{grid-template-columns:1fr;grid-row-gap:12px}.hlstCtr.vert.no-logo{grid-row-gap:20px}.vert .card{justify-content:flex-start}.top{display:flex;justify-content:space-between;align-items:flex-end;width:100%}.small .top{align-items:center}.return{display:flex;flex-direction:column}.return .text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:${d.c}}.pcnt{display:flex;align-items:center}.pcnt-str{font-size:var(--type-ramp-plus-3-font-size,24px);line-height:var(--type-ramp-plus-3-line-height,32px);font-weight:600;margin:0px 6px}.top-stocks{text-align:center;font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px)}.top-stocks .title{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.disp-name{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.small.wli{display:flex;align-items:center}.small .return{flex-direction:column-reverse;justify-content:center;align-items:center}.small .disp-name{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;white-space:initial}.small .top-stocks{text-align:left;width:136px;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.icon{margin-top:2px}`.withBehaviors(new l.N(null,g));var u=i(96950),v=i(39957),f=i(69259);const m=u.qy`<ul class="hlstCtr ${t=>t.viewModel.isVerticalList?"vert":""} ${t=>t.viewModel.hasLogo?"":"no-logo"}">${(0,v.ux)(t=>t.viewModel.quotes,u.qy`<watchlist-ideas-quote-item :viewModel="${t=>t.viewModel}"></watchlist-ideas-quote-item>`)}</ul>`,x=u.qy`<div class="return"><div class="text" title="${t=>t.viewModel.watchlistideasReturnLabelText}">${t=>t.viewModel.watchlistideasReturnLabelText}</div><div class="pcnt"><img class="icon" src="${t=>t.viewModel.iconUrl}" alt="${t=>t.viewModel.watchlistideasReturnLabelText}" width="24" height="24"><div class="pcnt-str" style="color: ${t=>t.viewModel.listItemColor}" title="${t=>t.viewModel.annualReturnString}">${t=>t.viewModel.annualReturnString}</div></div></div>`,b=u.qy`<div class="top-stocks"><div class="title" title="${t=>t.viewModel.watchlistideasTopStocksIn}">${t=>t.viewModel.watchlistideasTopStocksIn}</div><div class="disp-name" title="${t=>t.viewModel.displayName}">${t=>t.viewModel.displayName}</div></div>`,w=u.qy`<div class="top">${x} ${b}</div>`,$=u.qy`<div class="chart">${(0,f.z)(t=>{var e;return(null===(e=t.viewModel.chartData)||void 0===e||null===(e=e.chartSeries)||void 0===e?void 0:e.length)>0&&t.showWatchlistChart},u.qy`<money-info-stock-chart :width=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartWidth}} :height=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartHeight}} :prices=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartSeries}} :baselinePrice=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartBaseline}} :lineColor=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.chartFillColor}} :baselineColor=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.baselineFillColor}} :pricesMaxCount=${()=>40} :isFullWidth=${t=>{var e;return null===(e=t.viewModel.chartData)||void 0===e?void 0:e.isFullWidth}}></money-info-stock-chart>`)}</div>`,y=u.qy`<div class="card"><div class="top">${x} ${$}</div>${b} ${m}</div>`,k=u.qy`<a role="link" href="${t=>t.viewModel.destinationUrl}" target="${t=>t.viewModel.openLinksInNewTab?"_blank":"_self"}" data-t="${t=>t.viewModel.telemetryTag}" tabindex="-1" class="wli-wrapper"><div class="wli ${t=>t.viewModel.widgetSize}">${t=>"small"===t.viewModel.widgetSize?w:y}</div></a>`;let z=class extends o{};z=(0,r.Cg)([(0,n.E)({name:"watchlist-ideas",template:k,styles:p,shadowOptions:{delegatesFocus:!0}})],z)},42792(t,e,i){i.d(e,{R7(){return v},e(){return p},kc(){return u},nH(){return g}});var r=i(57416),s=i(55153),a=i(95239),o=i(26920),n=i(48751),l=i(64187),h=i(22131),d=i(74849),c=i(50882);const g=d.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,p=d.A`
    ${(0,l.V)("flex")} :host {
        background: ${a.p};
        outline: calc(${o.XA} * 1px) solid ${s.cu};
        border-radius: calc((${r.JU} - ${o.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${n.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${o.XA} * 1px) ${s.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${o.XA} * 1px) ${s.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${o.XA} * 1px) ${s.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${s.QG} * 1px);
        height: calc(${s.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${s.QG} * 1px);
        height: calc((${s.l8} * 2px) + (${s.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${s.QG} * 2px) + (${s.Sn} * 1px));
        height: calc((${s.l8} * 2px) + (${s.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${s.QG} * 2px) + (${s.Sn} * 1px));
        height: calc(${s.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,h.mr)(d.A`
            :host {
                background: ${c.A.Canvas};
                color: ${c.A.CanvasText};
            }
        `),v=d.A`
    ${p}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},67538(t,e,i){i.r(e),i.d(e,{MoneyInfoStockChart(){return v}});var r=i(56911),s=i(92011),a=i(60815),o=i(22341),n=i(93552),l=i(31525),h=i(26220);let d=class extends s.L{connected(){try{this.initializeChart()}catch(t){(0,o.vV)(n.npu,t?t.message:"Unknown error")}}initializeChart(){if(this.canvasEl){const t=(0,h.mZ)();this.canvasEl.width=this.width*t,this.canvasEl.height=this.height*t,this.ctx=this.canvasEl.getContext("2d"),this.ctx.scale(t,t),this.canvasEl.style.width=`${this.width}px`,this.canvasEl.style.height=`${this.height}px`,this.drawChart()}}shouldShowBaseline(){if("number"!=typeof this.baselinePrice)return!1;const t=Math.min(...this.prices),e=Math.max(...this.prices);if(t===e)return!0;const i=t>this.baselinePrice?t-this.baselinePrice:this.baselinePrice-e;return i/(i+(e-t))<.5}drawChart(){if(!this.prices)return;const t=this.prices.slice();this.shouldShowBaseline()&&t.push(this.baselinePrice);let e=Math.min(...t),i=Math.max(...t);e===i&&(e-=1,i+=1);const r=Math.round(1e4*(i-e))/1e4,s=Math.max(this.pricesMaxCount||0,this.prices.length),a=this.prices.length/s,o=this.width*(this.isFullWidth?1:a);this.ctx.beginPath(),this.ctx.moveTo(0,this.height-(this.prices[0]-e)/r*this.height);for(let t=1;t<this.prices.length;t++){const i=t/(this.prices.length-1)*o,s=this.height-(this.prices[t]-e)/r*this.height;this.ctx.lineTo(i,s)}this.ctx.lineWidth=1.2,this.ctx.strokeStyle=this.lineColor,this.ctx.stroke(),this.ctx.lineTo(this.width,this.height),this.ctx.lineTo(0,this.height),this.ctx.closePath(),this.ctx.save(),this.ctx.clip();const n=this.ctx.createLinearGradient(0,0,0,this.height);n.addColorStop(0,`${this.lineColor}4D`),n.addColorStop(1,`${this.lineColor}00`),this.ctx.fillStyle=n,this.ctx.fillRect(0,0,o,this.height),this.ctx.restore(),this.ctx.beginPath(),this.ctx.moveTo(0,this.height-(this.baselinePrice-e)/r*this.height),this.ctx.lineTo(this.width,this.height-(this.baselinePrice-e)/r*this.height),this.ctx.strokeStyle=this.baselineColor,this.ctx.setLineDash(this.lineDash||[5,5]),this.ctx.stroke()}};(0,r.Cg)([a.sH],d.prototype,"prices",void 0),(0,r.Cg)([a.sH],d.prototype,"baselinePrice",void 0),(0,r.Cg)([a.sH],d.prototype,"width",void 0),(0,r.Cg)([a.sH],d.prototype,"height",void 0),(0,r.Cg)([a.sH],d.prototype,"lineColor",void 0),(0,r.Cg)([a.sH],d.prototype,"baselineColor",void 0),(0,r.Cg)([a.sH],d.prototype,"lineDash",void 0),d=(0,r.Cg)([l.x],d);const c=i(74849).A` 
`;var g=i(96950),p=i(60402);const u=g.qy`<template><canvas ${(0,p.K)("canvasEl")}></canvas></template>`;let v=class extends d{};v=(0,r.Cg)([(0,s.E)({name:"money-info-stock-chart",template:u,styles:c,shadowOptions:{delegatesFocus:!0}})],v)},72351(t,e,i){i.r(e),i.d(e,{WatchlistIdeasQuoteItem(){return f}});var r=i(56911),s=i(95296);class a extends s.m{}var o=i(92011),n=i(74849),l=i(48751);const h=n.A` .qimg{border-radius:50%;box-sizing:border-box;object-fit:contain;border:1px solid rgba(0,0,0,0.16)}.horz .qimg{margin-bottom:8px;justify-self:center}.curr .qimg{border-radius:0}.hlstItm{display:grid;align-items:center;justify-content:center;justify-self:stretch;row-gap:4px;color:${l.l}}.horz .hlstItm > span,.horz .hlstItm > img{justify-self:center}.qps{font-weight:600;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.symb{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);overflow:hidden;text-align:center;max-width:none;white-space:nowrap}.hlstItm{row-gap:0;width:40px}.vert .hlstItm .qps{margin:0;justify-self:flex-end}.vert .qps,.vert .symb,.vert .disp-name{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px)}.vert .hlstItm{width:100%;gap:2px;grid-template-columns:42px 48px 1fr 48px}.no-logo.vert .hlstItm{grid-template-columns:48px 1fr 48px}.no-logo.horz .hlstItm{margin-bottom:12px}.disp-name{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:400}.horz .disp-name{display:none}.no-logo .symb{color:white;min-width:40px;max-width:44px;border-radius:4px;overflow:hidden}.no-logo.horz .symb{margin-bottom:4px}.vert.w-logo .symb{text-align:start}`;var d=i(96950),c=i(69259),g=i(58792);const p=d.qy`<span class="qps" style="color: ${t=>t.viewModel.priceColor}">&lrm;${t=>t.viewModel.pcntValue}&lrm;</span>`,u=d.qy` ${(0,c.z)(t=>t.viewModel.hasLogo,d.qy` ${t=>t.viewModel.iconUrl?d.qy`<img class="qimg" src="${t=>t.viewModel.iconUrl}" alt="" loading=lazy width="32" height="32"/>`:d.qy`<img class="qimg qimg-empty" src="${(0,g.rA)().StaticsUrl}latest/money/icons/StockEmptyStateCircle.svg" alt=${t=>t.viewModel.symbol} width="32" height="32">`} `)}
`,v=d.qy`<li class="${t=>t.viewModel.widgetSize} ${t=>t.viewModel.isVertical?"vert":"horz"} ${t=>t.viewModel.hasLogo?"w-logo":"no-logo"}" title="${t=>t.viewModel.displayName}"><div class="hlstItm ${t=>t.viewModel.isCurrencySecurityType?"curr":""}">${u}<div class="symb" style="background-color: ${t=>t.viewModel.noLogoBgColor}">${t=>t.viewModel.symbol}</div><div class="disp-name">${t=>t.viewModel.displayName}</div>${p}</div></li>`;let f=class extends a{};f=(0,r.Cg)([(0,o.E)({name:"watchlist-ideas-quote-item",template:v,styles:h,shadowOptions:{delegatesFocus:!0}})],f)},84672(t,e,i){i.r(e),i.d(e,{MoneyInfoStockChartTransformer(){return r.M},WatchlistIdeasQuoteItemTransformer(){return o},WatchlistIdeasTransformer(){return c}});var r=i(89213),s=i(27208),a=i(86449);class o extends s.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getPriceColor(t,e){const i=this.getPcnt(t);return(0,a.BK)((0,a.jJ)(),i,e)}getPcntValue(t){const e=this.getPcnt(t);return`${this.getPriceDirection(e)}${e}%`}getPcnt(t){const e=t.return1Year;return e?Math.round(e):0}getPriceDirection(t){return t>0?"+":""}getIconURL(t){const e=t.quote;return(0,a.Mx)(e)&&e.symbol.length>=3?(0,a.A0)(e.symbol.slice(-3)):(0,a.nZ)(e,50,50,0)}async getViewModel(t){return{widgetSize:t.widgetSize,iconUrl:this.getIconURL(t),isCurrencySecurityType:(0,a.Mx)(t.quote),isVertical:t.isVertical,displayName:t.quote.displayName||"",pcntValue:this.getPcntValue(t.quote),priceColor:this.getPriceColor(t.quote,t.swapGainLossColor),symbol:t.quote.symbol,hasLogo:t.hasLogo,noLogoBgColor:t.noLogoBgColor,telemetryTag:""}}}var n=i(49150),l=i(30236),h=i(96950);const d=["#00809D","#5C005C","#FF7E36","#5C2D91","#029DD4"];class c extends s.IB{async transform(t){const e=await this.getCurrentViewModel(t);return{viewTemplate:h.qy`
                <watchlist-ideas
                    :viewModel="${e}"
                ></watchlist-ideas>`}}getListItemColor(t){return(0,a.BK)((0,a.jJ)(),this.annualReturn(t),this.transformerProvider.config.swapGainLossColor)}annualReturn(t){var e;return(null===(e=this.firstListItem(t))||void 0===e||null===(e=e.performance)||void 0===e||null===(e=e.year)||void 0===e?void 0:e.changePercent)||0}firstListItem(t){return t.tabData&&t.tabData.listItems?t.tabData.listItems[0]:null}getHasLogo(t){return t.filter(t=>!!t.iconUrl||!!((0,a.Mx)(t)&&t.symbol.length>=3)).length>2.5}getNoLogoBgColor(t){return d[t%5]}async getQuotes(t){var e;let i=null===(e=this.firstListItem(t))||void 0===e?void 0:e.quotes;if(!i)return[];i=i.slice(0,Math.min(5,i.length));const r=this.getHasLogo(i);this.hasLogo=r;const o=i.map((e,i)=>{const o={widgetSize:(0,a.CP)(t.cardSize),isVertical:this.isVerticalWatchlist(t),parentTelemetryObject:t.telemetryObject,quote:e,noLogoBgColor:r?"":this.getNoLogoBgColor(i),signature:t.signature,hasLogo:r,swapGainLossColor:this.transformerProvider.config.swapGainLossColor};return this.transformerProvider.generateView(o,s.Ai.WatchlistIdeasQuoteItem)});return(await Promise.all(o)).filter(a.z2)}annualReturnString(t){return+(this.annualReturn(t)>1e3?this.annualReturn(t).toFixed(1):this.annualReturn(t).toFixed(2))+"%"}isVerticalWatchlist(t){return t.cardSize===n.uE._1x_3y}iconUrl(t){const e=this.annualReturn(t);return(0,l.kX)(this.transformerProvider.config.urls,e,e>0?s.Ex.PriceSpike:s.Ex.PriceDrop,this.transformerProvider.config.swapGainLossColor)}getPriceChange(t){var e;const i=(null===(e=t.chartData)||void 0===e||null===(e=e.chartData)||void 0===e?void 0:e.series)||[];return 0===i.length?0:1===i.length?i[0]:i[i.length-1]-i[0]}getBaseline(t){var e;return((null===(e=t.chartData)||void 0===e||null===(e=e.chartData)||void 0===e?void 0:e.series)||[])[0]}async getChartData(t){if(t.chartData){t.chartData.pricePreviousClose=this.getBaseline(t);const e={quote:{changePcntNumber:this.getPriceChange(t)},chartData:{...t.chartData,pricePreviousClose:this.getBaseline(t)},width:100,height:32,isFullWidth:!0,cardSize:t.cardSize};return(await this.transformerProvider.generateView(e,s.Ai.MoneyInfoStockChart)).viewModel}}async getCurrentViewModel(t){var e;const i=await this.getQuotes(t);return{iconUrl:this.iconUrl(t),isVerticalList:this.isVerticalWatchlist(t),listItemColor:this.getListItemColor(t),chartData:await this.getChartData(t),quotes:i,destinationUrl:t.destinationUrl,openLinksInNewTab:this.transformerProvider.config.openLinksInNewTab,hasLogo:this.hasLogo,experienceName:t.experienceName,annualReturnString:this.annualReturnString(t),watchlistideasReturnLabelText:this.transformerProvider.strings.watchlistideasReturnLabelText,watchlistideasTopStocksIn:this.transformerProvider.strings.watchlistideasTopSecuritiesIn,displayName:(null===(e=this.firstListItem(t))||void 0===e?void 0:e.listDisplayName)||"",tabName:t.tabName,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{name:s.CD.watchlistIdeas,signature:t.signature,headline:t.tabName}),widgetSize:(0,a.CP)(t.cardSize)}}}Promise.resolve().then(i.bind(i,67538)),Promise.resolve().then(i.bind(i,9720)),Promise.resolve().then(i.bind(i,72351))},89213(t,e,i){i.d(e,{M(){return o}});var r=i(27208),s=i(49150),a=i(86449);class o extends r.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getChartFillColor(t){return t?(0,a.BK)((0,a.jJ)(),t.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor):""}chartPricePreviousClose(t){return t?t.pricePreviousClose:void 0}getChartWidth(t){return t.width?t.width:t.cardSize===s.uE._1x_1y?104:32}getChartHeight(t){return t.height?t.height:t.cardSize===s.uE._1x_1y?18:28}async getViewModel(t){var e,i;return{chartId:t.quote.id,chartWidth:this.getChartWidth(t),chartHeight:this.getChartHeight(t),chartFillColor:this.getChartFillColor(t.quote),baselineFillColor:this.getChartFillColor(t.quote),isFullWidth:t.isFullWidth,lineDash:t.lineDash,chartBaseline:this.chartPricePreviousClose(null==t?void 0:t.chartData),chartBaselineLoc:null==t||null===(e=t.chartData)||void 0===e?void 0:e.pricePreviousCloseLoc,chartSeries:null==t||null===(i=t.chartData)||void 0===i||null===(i=i.chartData)||void 0===i?void 0:i.series,cardSize:t.cardSize,telemetryTag:""}}}},92707(t,e,i){i.d(e,{z(){return l}});var r=i(56911),s=i(27208),a=i(60815),o=i(92011),n=i(31525);let l=class extends o.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return s.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const t=this.getState();t&&(t.subscribe(s.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(t){}onChartDictChange(t){}onShowNotificationTextChange(t){}onQuoteItemDictChange(t){}onCardWidthChanged(t){}};(0,r.Cg)([a.sH],l.prototype,"viewModel",void 0),l=(0,r.Cg)([n.x],l)},95296(t,e,i){i.d(e,{m(){return o}});var r=i(56911),s=i(60815),a=i(92011);class o extends a.L{}(0,r.Cg)([s.sH],o.prototype,"viewModel",void 0)},99657(t,e,i){i.d(e,{D(){return o},I(){return a}});var r=i(45755);const{create:s}=r.G,a=s("sloppy-click-z-index",1),o=s("click-z-index",1)}}]);