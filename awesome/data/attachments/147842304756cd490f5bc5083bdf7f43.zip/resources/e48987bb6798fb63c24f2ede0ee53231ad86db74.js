"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-tournament-status-row"],{7733(e,n,t){t.r(n),t.d(n,{SportsTournamentStatusRowTransformer(){return i._}});var i=t(91014);Promise.resolve().then(t.bind(t,61469))},61469(e,n,t){t.r(n),t.d(n,{TournamentStatusRow(){return $}});var i=t(56911),a=t(92011),r=t(48751);const o="\n    font-size: var(--type-ramp-minus-1-font-size, 12px);\n    font-weight: 600;\n    line-height: var(--type-ramp-minus-1-line-height, 16px);\n",s="\n    overflow: hidden;\n    text-overflow: ellipsis;\n    white-space: nowrap;\n",d=t(74849).A`
.tournament-container{display:flex;flex-direction:column;gap:2px;padding:5px 8px;border-radius:8px;background:var(--sports-item-background);position:relative;max-width:252px;text-decoration:none;color:${r.l};z-index:1}.tournament-container:hover{background:var(--sports-item-hover-background)}.winner-image-container{height:16px;width:16px;display:flex;justify-content:center;align-items:flex-end}.live-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);color:#D13438;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.pregame-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.postgame-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.inprogress-tournament-status-title{font-size:var(--type-ramp-minus-1-font-size,12px);color:#D13438;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px)}.tournament-location{${s} font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;line-height:var(--type-ramp-minus-1-line-height,16px);max-width:260px;height:100%}.tournament-title-container{display:flex;flex-direction:row;height:100%;align-items:flex-start;gap:6px;align-self:stretch}.tournament-details-container{display:flex;flex-direction:column;height:100%;gap:2px}.tournament-image{height:20px;width:20px}.tournament-title{font-size:var(--type-ramp-base-font-size,14px);font-weight:${"600"};
    line-height: var(--type-ramp-base-line-height, 20px);
    ${s} max-width:260px;height:100%}.winner-details-container{display:flex;justify-content:space-between;align-items:center}.winner-name-container{display:flex;flex-direction:row;align-items:center}.winner-score{${o}
    ${s} max-width:19px}.winner-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-weight:400;margin-right:2px}.winner-name{${o}
    ${s} max-width:128px}.winner-image{height:12px;width:12px}`;var l=t(96950),u=t(69259);Object.freeze({unknown:"unknown",preGame:"pre-game",inprogressGame:"inprogress-game",postGame:"post-game",tba:"tba"});const m=Object.freeze({unknown:"Unknown",preGame:"PreGame",inProgress:"InProgress",inProgressBreak:"InProgressBreak",postponed:"Postponed",suspended:"Suspended",cancelled:"Cancelled",forfeited:"Forfeited",delayed:"Delayed",final:"Final",bye:"Bye",abandoned:"Abandoned",live:"Live"});Object.freeze({Unknown:"Unknown",Invalid:"Invalid",PreGame:"PreGame",AboutToStart:"AboutToStart",ParticipantsAreNotKnownYet:"ParticipantsAreNotKnownYet",InProgress:"InProgress",InProgressBreak:"InProgressBreak",Postponed:"Postponed",Suspended:"Suspended",Cancelled:"Cancelled",Unscheduled:"Unscheduled",ForfeitedByBothTeams:"ForfeitedByBothTeams",ForfeitedByAwayTeam:"ForfeitedByAwayTeam",ForfeitedByHomeTeam:"ForfeitedByHomeTeam",ForfeitedByAwayTeamVacatedByHome:"ForfeitedByAwayTeamVacatedByHome",ForfeitedByHomeTeamVacatedByAway:"ForfeitedByHomeTeamVacatedByAway",VacatedByBothTeams:"VacatedByBothTeams",VacatedByAwayTeam:"VacatedByAwayTeam",VacatedByHomeTeam:"VacatedByHomeTeam",Delayed:"Delayed",StartDelayed:"StartDelayed",Final:"Final",Bye:"Bye",Retired:"Retired",Abandoned:"Abandoned",Unnecessary:"Unnecessary",Tea:"Tea",Lunch:"Lunch",InningsBreak:"InningsBreak",Stumps:"Stumps",RainDelay:"RainDelay",BadLight:"BadLight",CrowdTrouble:"CrowdTrouble",PitchCondition:"PitchCondition",FloodlightFailure:"FloodlightFailure",Drinks:"Drinks",SuperOver:"SuperOver",BadGroundCondition:"BadGroundCondition",BadWeatherCondition:"BadWeatherCondition",Dinner:"Dinner",Fog:"Fog",PlayHalted:"PlayHalted",StrategicTimeout:"StrategicTimeout",SuperOverInProgress:"SuperOverInProgress",WetGroundCondition:"WetGroundCondition",WetPitchCondition:"WetPitchCondition",DayWashedOut:"DayWashedOut",Toss:"Toss",MatchAbandonedWithoutToss:"MatchAbandonedWithoutToss",MatchAbandonedWithoutSingleBallBeingBowled:"MatchAbandonedWithoutSingleBallBeingBowled",MatchConceded:"MatchConceded",MatchAwarded:"MatchAwarded",Maintenance:"Maintenance"}),Object.freeze({full:"full",extendedBoxscore:"extended_boxscore",boxscore:"boxscore"}),Object.freeze({Unknown:"Unknown",PreGame:"PreGame",LiveGame:"LiveGame",PostGame:"PostGame"});const v=l.qy`
    <div class="live-tournament-status-title">
            ${e=>{var n,t;return`${null===(n=e.viewModel)||void 0===n||null===(n=n.strings)||void 0===n?void 0:n.sportsLive} • ${null===(t=e.viewModel)||void 0===t||null===(t=t.gameState)||void 0===t?void 0:t.name}`}}
    </div>
`,c=l.qy`
    <div class="pregame-tournament-status-title">
            ${e=>{var n;return null===(n=e.viewModel)||void 0===n?void 0:n.gameScheduleString}}
    </div>
`,p=l.qy`
    <div class="postgame-tournament-status-title">
            ${e=>{var n,t;return`${null===(n=e.viewModel)||void 0===n?void 0:n.gameScheduleString} • ${null===(t=e.viewModel)||void 0===t||null===(t=t.strings)||void 0===t?void 0:t.sportsStateFinal}`}}
    </div>
`,h=l.qy`
    <div class="inprogress-tournament-status-title">
            ${e=>{var n;return null===(n=e.viewModel)||void 0===n||null===(n=n.strings)||void 0===n?void 0:n.inProgress}}
    </div>
`,g=l.qy`
    <div class="winner-details-container">
        <div class="winner-name-container">
            <span class="winner-text">${e=>{var n;return null===(n=e.viewModel)||void 0===n||null===(n=n.strings)||void 0===n?void 0:n.winner}}</span>
            <div class="winner-image-container">
                <img class="winner-image" src=${e=>{var n;return null===(n=e.viewModel)||void 0===n||null===(n=n.winnerDetails)||void 0===n?void 0:n.imageUrl}} alt=${e=>{var n;return null===(n=e.viewModel)||void 0===n||null===(n=n.winnerDetails)||void 0===n?void 0:n.name}}></img>
            </div>
            <span class="winner-name">${e=>{var n;return null===(n=e.viewModel)||void 0===n||null===(n=n.winnerDetails)||void 0===n?void 0:n.name}}</span>
        </div>
        <div class="winner-score">
            ${e=>{var n;return null===(n=e.viewModel)||void 0===n||null===(n=n.winnerDetails)||void 0===n?void 0:n.score}}
        </div>
    </div>
`,y=l.qy`
    <div class="tournament-location">
        ${e=>{var n;return null===(n=e.viewModel)||void 0===n?void 0:n.locationName}}
    </div>
`,w=l.qy`
    <div class="tournament-details-container">
        <div class="tournament-title-container">
            <img class="tournament-image" src=${e=>{var n;return null===(n=e.viewModel)||void 0===n?void 0:n.imageUrl}} alt=${e=>{var n;return null===(n=e.viewModel)||void 0===n?void 0:n.name}}></img>
            <span class="tournament-title" title=${e=>{var n;return null===(n=e.viewModel)||void 0===n?void 0:n.name}}>
                ${e=>{var n;return null===(n=e.viewModel)||void 0===n?void 0:n.name}}
            </span>
        </div>
        ${(0,u.z)(e=>{var n;return(null===(n=e.viewModel)||void 0===n||null===(n=n.gameState)||void 0===n?void 0:n.state)!==m.final},y)}
        ${(0,u.z)(e=>{var n,t;return(null===(n=e.viewModel)||void 0===n||null===(n=n.gameState)||void 0===n?void 0:n.state)===m.final&&(null===(t=e.viewModel)||void 0===t?void 0:t.winnerDetails)},g)}
    </div>
`,x=l.qy`
<a
    class="tournament-container"
    href="${e=>e.viewModel.gameCenterUrl}"
    target="_blank"
    data-t="${e=>e.viewModel.telemetryTag}"
    tabindex="0"
    >
    ${e=>{var n;return(e=>{switch(e){case m.live:return v;case m.preGame:return c;case m.final:return p;case m.inProgress:return h;default:return c}})((null===(n=e.viewModel)||void 0===n||null===(n=n.gameState)||void 0===n?void 0:n.state)||"")}}
    ${w}
</a>
`,f=l.qy`
    ${(0,u.z)(e=>null!=e.viewModel,x)}
`;var B=t(92079);class b extends B.a{}let $=class extends b{};$=(0,i.Cg)([(0,a.E)({name:"tournament-status-row",template:f,styles:d})],$)},91014(e,n,t){t.d(n,{_(){return a}});var i=t(23587);class a extends i.Bc{async transform(e){return{viewModel:await this.getViewModel(e)}}async getViewModel(e){const n={...e.telemetryConstants,name:i.BP.SportsTournamentStatusRow};return{telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,n),...e}}}},92079(e,n,t){t.d(n,{a(){return o}});var i=t(56911),a=t(92011),r=t(31525);let o=class extends a.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};o=(0,i.Cg)([r.x],o)}}]);