(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["prism-carousel-card"],{903(t,e,o){"use strict";o.d(e,{D(){return l},G(){return s}});var i=o(93552),a=o(77367);let r,n;const s=()=>{n=new Map,r=new IntersectionObserver(t=>{for(const[t,e]of n.entries()){if(!(t&&e&&e.cardElement&&e.extTelemetry))return;const o=d(e.cardElement),i=o&&JSON.parse(o),a=i&&i.ext;if(!a||!a.row||!a.col)return;const r=`${a.row}-${a.col}`;t!==r&&(n.delete(t),n.set(r,{cardElement:e.cardElement,extTelemetry:a}))}t.forEach(t=>{const e=t.target,o=e&&d(e),i=o&&JSON.parse(o),a=i&&i.ext;if(!a||!a.row||!a.col)return;const r=`${a.row}-${a.col}`;t.isIntersecting?n.set(r,{cardElement:e,extTelemetry:a}):n.has(r)&&n.delete(r)})},{threshold:.99}),window.addEventListener("beforeunload",()=>{if("hidden"!==document.visibilityState)for(const[t,e]of n.entries()){if(!(t&&e&&e.cardElement&&e.extTelemetry))return;const o=t.split("-");if(isNaN(Number(o[0]))||isNaN(Number(o[1])))return;const i=parseFloat(o[0]),a=parseFloat(o[1]);c(e,n.get(`${i+1}-${a}`));c(e,n.get(`${i}-${a+1}`))}})},l=t=>{r&&t&&r.observe(t)};function d(t){if(t.classList&&t.classList.contains("infopane")){const e=t.querySelector("cs-article-card"),o=e&&e.shadowRoot&&e.shadowRoot.querySelector("cs-content-card");return o&&o.anchorTelemetryTag}return t.anchorTelemetryTag?t.anchorTelemetryTag:t.getAttribute("data-t")?t.getAttribute("data-t"):void 0}function c(t,e){if(!(t&&e&&e.cardElement&&e.extTelemetry&&t!==e))return;const o=t.cardElement.getBoundingClientRect(),r=e.cardElement.getBoundingClientRect();if(0===o.height||0===o.width||0===r.height||0===r.width)return;if(!(o.top>r.bottom||o.right<r.left||o.bottom<r.top||o.left>r.right)){const n=t.extTelemetry,s=e.extTelemetry;a.YT.sendAppErrorEvent({...i.ABd,message:"Feed cards are overlapping",pb:{...i.ABd.pb,customMessage:`{"${t.cardElement.id}": { "position": ${JSON.stringify(o)}, "slot": ${n.slot}, "template": "${n.template}", "row": ${n.row}, "col": ${n.col} },"${e.cardElement.id}": { "position": ${JSON.stringify(r)}, "slot": ${s.slot}, "template": "${s.template}", "row": ${s.row}, "col": ${s.col}}}`}})}}},4151(t,e,o){"use strict";o.d(e,{m(){return k}});var i=o(37180),a=o(56911),r=o(92011);class n extends r.L{}var s=o(23429),l=o(38493);class d extends n{constructor(){super(...arguments),this.appearance="lightweight"}appearanceChanged(t,e){t!==e&&s.L.enqueue(()=>{this.classList.add(e),this.classList.remove(t)})}}(0,a.Cg)([(0,l.CF)({mode:"fromView"}),(0,a.Sn)("design:type",String)],d.prototype,"appearance",void 0);var c=o(74849),u=o(64187),h=o(7896),p=o(61138),g=o(57416),f=o(74838),v=o(26920),m=o(48751),b=o(4283),x=o(74089),y=o(37302);const $=c.A`
    ${(0,u.V)("inline-block")} :host {
        box-sizing: border-box;
        font-family: ${h.O};
        font-size: ${p.k};
        line-height: ${p.F};
    }

    .control {
        border-radius: calc(${g.Pb} * 1px);
        padding: calc(((${f.vR} * 0.5) - ${v.XA}) * 1px)
            calc((${f.vR} - ${v.XA}) * 1px);
        border: calc(${v.XA} * 1px) solid transparent;
    }

    :host(.lightweight) .control {
        background: transparent;
        color: ${m.l};
        font-weight: 600;
    }

    :host(.accent) .control {
        background: ${b.IR};
        color: ${x.l_};
    }

    :host(.neutral) .control {
        background: ${y.F7};
        color: ${m.l};
    }
`,w=o(96950).qy`
        <div class="control" part="control">
            <slot></slot>
        </div>
    `,k=d.compose({name:`${i.c.prefix}-badge`,template:w,styles:$})},6637(t,e,o){"use strict";o.d(e,{$(){return n}});var i=o(14475),a=o(96950),r=o(58792);const n=t=>a.qy`<a class="ad-choice" data-t=${t.telemetryTag||""} href=${t.href||""} target="${i.z._blank}" title=${t.text||""}><img alt=${t.text||""} aria-hidden="true" src="${(0,r.rA)().StaticsUrl}/latest/responsive-card/adChoiceIcon.svg"></img></a>`},6791(t,e,o){"use strict";o.d(e,{f(){return a}});var i=o(50645);class a{constructor(){this.config={},this.strings={},this.initialized=!1}async initConfig(t){var e,o;this.initialized||(this.config=await this.getConfigFromRef(t)||{},this.strings=(null===(e=this.config)||void 0===e?void 0:e.localizedStrings)||{},this.initialized=!!this.config&&!(null===(o=this.config)||void 0===o||!o.localizedStrings))}getConfig(){return this.config}getLocStrings(){return this.strings}async getConfigFromRef(t){try{const e=(null==t?void 0:t.configRef)||this.configRef,o=await i.L.getConfig(e);return null==o?void 0:o.properties}catch(t){return{}}}}},8675(t,e,o){"use strict";o.d(e,{E(){return s}});var i=o(4126),a=o(74849),r=o(30664);const n=a.A`
.ad-label{font-size:12px;border:unset;padding:unset}`,s=a.A`
.ad-label{align-items:center;border-radius:4px;border:0.5px solid var(--color-neutral-stroke-1,var(--neutral-foreground-rest));color:inherit;display:flex;font-size:11px;padding:0 4px 1px 4px;text-decoration:none;z-index:${r.I}}a[no-border]{border:unset;padding:unset;display:inline-flex}.dsa:hover{text-decoration:underline}`.withBehaviors(new i.o("ruby",!0,n))},10809(t,e,o){"use strict";o.d(e,{D(){return s}});var i=o(18272),a=o(2171),r=o(6791);class n extends r.f{constructor(){super(...arguments),this.configRef={experienceType:"SuperComponentData",instanceSrc:"default"}}static getInstance(){return a.vv.get("__SuperComponentDataHelper__",()=>new n)}}const s=(0,i.G)(n)},12717(t,e,o){"use strict";o.d(e,{m(){return k}});var i=o(84506),a=o(37180),r=o(74849),n=o(64187),s=o(60993),l=o(73477),d=o(22131),c=o(50882),u=o(48196),h=o(48751),p=o(45476),g=o(26920),f=o(36452),v=o(79288),m=o(14996);const b=r.A`
    ${(0,n.V)("inline-flex")} :host {
        width: calc(${u.D} * 1px);
        height: calc(${u.D} * 1px);
        justify-content: center;
        align-items: center;
        margin: 0;
        position: relative;
        fill: currentcolor;
        color: ${h.l};
        background: transparent;
        border: none;
        outline: none;
        padding: 0;
    }

    :host::before {
        content: "";
        opacity: 0.8;
        background: ${p.Wl};
        border: calc(${g.XA} * 1px) solid ${f.I2};
        border-radius: 50%;
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        transition: all 0.1s ease-in-out;
    }

    .next,
    .previous {
        position: relative;
        ${""} width: 16px;
        height: 16px;
    }

    :host([disabled]) {
        opacity: ${v.q};
        cursor: ${s.Z};
    }

    :host(:hover) {
        cursor: pointer;
    }

    :host(:hover)::before {
        background: ${p.oO};
        border-color: ${f.mb};
    }

    :host(:${l.N}) {
        outline: none;
    }

    :host(:${l.N})::before {
        box-shadow: 0 0 0 1px ${m.WN} inset;
        border-color: ${m.WN};
    }

    :host(:active)::before {
        background: ${p.wO};
        border-color: ${f.MY};
    }

    :host::-moz-focus-inner {
        border: 0;
    }
`.withBehaviors((0,d.mr)(r.A`
            :host {
                background: ${c.A.Canvas};
            }
            :host .next,
            :host .previous {
                color: ${c.A.ButtonText};
                fill: currentcolor;
            }
            :host::before {
                background: ${c.A.Canvas};
                border-color: ${c.A.ButtonText};
            }
            :host(:hover)::before {
                forced-color-adjust: none;
                background: ${c.A.Highlight};
                border-color: ${c.A.ButtonText};
                opacity: 1;
            }
            :host(:hover) .next,
            :host(:hover) .previous {
                forced-color-adjust: none;
                color: ${c.A.HighlightText};
                fill: currentcolor;
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled])::before,
            :host([disabled]:hover)::before,
            :host([disabled]) .next,
            :host([disabled]) .previous,
            :host([disabled]:hover) .next,
            :host([disabled]:hover) .previous {
                forced-color-adjust: none;
                background: ${c.A.Canvas};
                border-color: ${c.A.GrayText};
                color: ${c.A.GrayText};
                fill: ${c.A.GrayText};
            }
            :host(:${l.N})::before {
                forced-color-adjust: none;
                border-color: ${c.A.Highlight};
                box-shadow: 0 0 0 2px ${c.A.Field},
                    0 0 0 4px ${c.A.FieldText};
            }
        `));var x=o(60143),y=o(96950);const $=(0,x.B)({next:y.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z"
            />
        </svg>
    `,previous:y.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z"
            />
        </svg>
    `});class w extends i.d{}const k=w.compose({name:`${a.c.prefix}-flipper`,template:$,styles:b})},14701(t,e,o){"use strict";o.d(e,{B(){return s}});var i=o(74849),a=o(30664),r=o(12640);const n=i.A`
.ad-choice{filter:var(--filter-color)}`,s=i.A`
:host{--filter-color:invert(99%) sepia(10%) saturate(0%) hue-rotate(244deg) brightness(120%) contrast(100%)}.ad-choice{align-items:center;display:flex;width:12px;z-index:${a.I}}@media (forced-colors:active){.ad-choice{filter:invert(1) !important}}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice{filter:var(--filter-color) !important}}`.withBehaviors(new r.N(null,n))},16038(t,e,o){"use strict";o.d(e,{m(){return p}});var i=o(65614),a=o(13312),r=o(55153),n=o(7896),s=o(74849),l=o(64187);const d=s.A`
    ${(0,l.V)("grid")}

    :host {
        font-family: ${n.O};
        width: auto;
        grid-auto-columns: calc(${r.QG} * 1px);
        grid-auto-row: calc(${r.l8} * 1px);
        grid-gap: calc(${r.Sn} * 1px);
    }
`;var c=o(39957),u=o(96950);const h=u.qy`
    <template @keydown="${(t,e)=>t.handleKeyDown(e.event)}">
        ${(0,c.ux)(t=>t.childrenLayout,u.qy`
                ${(t,e)=>e.parent.selectTemplate(t)}
            `)}
    </template>
`,p=a.tA.compose({name:`${i.G.prefix}-feed-layout`,styles:d,template:h})},19702(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M1.91 7.38A8.5 8.5 0 013.69 4.3a.5.5 0 01.54-.13l1.92.68a1 1 0 001.32-.76l.36-2a.5.5 0 01.4-.4 8.53 8.53 0 013.55 0c.2.04.35.2.38.4l.37 2a1 1 0 001.32.76l1.92-.68a.5.5 0 01.54.13 8.5 8.5 0 011.78 3.08c.06.2 0 .4-.15.54l-1.56 1.32a1 1 0 000 1.52l1.56 1.32a.5.5 0 01.15.54 8.5 8.5 0 01-1.78 3.08.5.5 0 01-.54.13l-1.92-.68a1 1 0 00-1.32.76l-.37 2a.5.5 0 01-.38.4 8.53 8.53 0 01-3.56 0 .5.5 0 01-.39-.4l-.36-2a1 1 0 00-1.32-.76l-1.92.68a.5.5 0 01-.54-.13 8.5 8.5 0 01-1.78-3.08.5.5 0 01.15-.54l1.56-1.32a1 1 0 000-1.52L2.06 7.92a.5.5 0 01-.15-.54zm1.06 0l1.3 1.1a2 2 0 010 3.04l-1.3 1.1c.3.79.71 1.51 1.25 2.16l1.6-.58a2 2 0 012.63 1.53l.3 1.67a7.56 7.56 0 002.5 0l.3-1.67a2 2 0 012.64-1.53l1.6.58a7.5 7.5 0 001.24-2.16l-1.3-1.1a2 2 0 010-3.04l1.3-1.1a7.5 7.5 0 00-1.25-2.16l-1.6.58a2 2 0 01-2.63-1.53l-.3-1.67a7.55 7.55 0 00-2.5 0l-.3 1.67A2 2 0 015.81 5.8l-1.6-.58a7.5 7.5 0 00-1.24 2.16zM7.5 10a2.5 2.5 0 115 0 2.5 2.5 0 01-5 0zm1 0a1.5 1.5 0 103 0 1.5 1.5 0 00-3 0z"></path></svg>'},22272(t,e,o){"use strict";o.d(e,{T(){return k}});var i=o(56911),a=o(92011),r=o(38493);const n="next",s="medium";class l extends a.L{constructor(){super(...arguments),this.direction=n,this.disabled=!1,this.size=s,this.ariaLabel=null}handleActivate(t){if(this.disabled)return!0;if(t instanceof KeyboardEvent){if("Enter"!==t.key&&" "!==t.key)return!0;t.preventDefault()}return t.stopPropagation(),this.click(),!1}}(0,i.Cg)([r.CF],l.prototype,"caretIcon",void 0),(0,i.Cg)([r.CF],l.prototype,"direction",void 0),(0,i.Cg)([(0,r.CF)({mode:"boolean"})],l.prototype,"disabled",void 0),(0,i.Cg)([r.CF],l.prototype,"size",void 0),(0,i.Cg)([(0,r.CF)({attribute:"aria-label"})],l.prototype,"ariaLabel",void 0);var d=o(28986),c=o(57416),u=o(48751),h=o(79288),p=o(48196),g=o(74838),f=o(74849),v=o(12640);const m=f.A` .flipper-caret{filter:invert(var(--flipperInvert,100%))}:host([invert-color="true"]) .flipper-caret{filter:invert(var(--flipperInvert,22%))}`,b=f.A` :host{align-items:center;background:${d.v8};
        border-radius: calc(${c.Pb} * 1px);
        color: ${u.l};display:grid;fill:currentcolor;justify-content:center;outline:none}:host([invert-color="true"]){background:var(--neutral-foreground-rest)}:host([direction="next"]) .flipper-caret{transform:rotate(180deg)}:host([disabled]){cursor:none;opacity:${h.q};pointer-events:none}:host([size="medium"]){height:calc(${p.D} * 1px);
        width: calc(${g.vR} * 4px)}:host([size="large"]){height:calc(${g.vR} * 12px);
        width: calc(${g.vR} * 6px)}:host([size="tall"]){height:calc(${g.vR} * 18px);
        width: calc(${g.vR} * 5.5px);
        border-radius: calc(${c.Pb} * 2px)}:host([size="square"]){height:calc(${g.vR} * 6px);
        width: calc(${g.vR} * 6px)}:host([size="extra-large"]){height:calc(${g.vR} * 12px);
        width: calc(${g.vR} * 6.5px)}:host([size="extra-large-2"]){height:calc(${g.vR} * 12px);
        width: calc(${g.vR} * 7px)}:host([size="extra-large-3"]){height:calc(${g.vR} * 14px);
        width: calc(${g.vR} * 7.5px);border-radius:0px}:host([size="large"]) .flipper-caret{height:24px;width:24px}:host([size="extra-large"]) .flipper-caret{height:30px;width:30px}:host([size="extra-large-2"]) .flipper-caret{height:34px;width:34px}:host([size="extra-large-3"]) .flipper-caret{height:24px;width:24px}.flipper-caret{filter:invert(var(--flipperInvert,15%));height:16px;width:16px}:host([invert-color="true"]) .flipper-caret{filter:invert(var(--flipperInvert,100%))}.flipper-container{display:flex}:host(:not([disabled]):hover){cursor:pointer;background:${d.Rg}}:host([invert-color="true"]:hover){background:var(--neutral-foreground-rest)}:host(:not([disabled]):active){background:${d.DK}}:host([invert-color="true"]:active){background:var(--neutral-foreground-rest)}:host([invert-color="true"]:hover){cursor:pointer}:host::-moz-focus-inner{border:0}`.withBehaviors(new v.N(null,m));var x,y=o(96950);const $=`${null===(x=(0,o(58792).rA)())||void 0===x?void 0:x.StaticsUrl}latest/fluent-icons/caret_left_16_filled.svg`,w=y.qy`<span role="button" class="flipper-container" tabindex="0" aria-label="${t=>t.ariaLabel}" @click="${(t,e)=>t.handleActivate(e.event)}" @keydown="${(t,e)=>{const o=e.event;return!!o.repeat||t.handleActivate(o)}}"><img alt="" class="flipper-caret" src="${t=>t.caretIcon?t.caretIcon:$}"/></span>`,k=l.compose({name:"card-flipper",styles:b,template:w})},25717(t,e,o){"use strict";o.d(e,{T(){return a}});var i=o(96950);function a(){return i.qy`
        <slot></slot>
    `}},26831(t,e,o){"use strict";o.d(e,{Hg(){return n}});var i=o(58792),a=o(26220);const r=/[:/?#[\]@!$&'()*+,;=]/g;function n(t,e,o,n){let s=`${i.T3.NavTargetUrlWithLocale}/channel`;if(t&&o){const i="source"===o?"sr":"tp";s+="/"+[o,e?encodeURIComponent(e.replace(r,"")):"",`${i}-${t}`].filter(t=>t).join("/")}const l=new URL(s);return n||(l.search=(0,a.iA)()),(0,a.ou)().includes("localhost.msn.com")&&(l.host=(0,a.ou)()),l.toString()}},28986(t,e,o){"use strict";o.d(e,{DK(){return v},Rg(){return f},v8(){return g}});var i=o(45755),a=o(64183),r=o(95239);function n(t,e){return i.G.create({name:t},e)}const s=n("neutral-fill-secondary-rest-delta",3),l=n("neutral-fill-secondary-hover-delta",2),d=n("neutral-fill-secondary-active-delta",1),c=n("neutral-fill-secondary-focus-delta",3);var u=o(31023);const{create:h}=i.G,p=n("neutral-fill-secondary-recipe",{evaluate(t,e){return(0,a.t)(t(u.r),e||t(r.p),t(s),t(l),t(d),t(c))}}),g=h("neutral-fill-secondary-rest",t=>t(p).evaluate(t).rest),f=h("neutral-fill-secondary-hover",t=>t(p).evaluate(t).hover),v=h("neutral-fill-secondary-active",t=>t(p).evaluate(t).active);h("neutral-fill-secondary-focus",t=>t(p).evaluate(t).focus)},29995(t,e,o){"use strict";o.d(e,{M(){return s}});var i=o(96950),a=o(60402),r=o(82774),n=o(35106);function s(t={}){return i.qy`
        <a
            class="control"
            part="control"
            download="${t=>t.download}"
            href="${t=>t.href}"
            hreflang="${t=>t.hreflang}"
            ping="${t=>t.ping}"
            referrerpolicy="${t=>t.referrerpolicy}"
            rel="${t=>t.rel}"
            target="${t=>t.target}"
            type="${t=>t.type}"
            aria-atomic="${t=>t.ariaAtomic}"
            aria-busy="${t=>t.ariaBusy}"
            aria-controls="${t=>t.ariaControls}"
            aria-current="${t=>t.ariaCurrent}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-details="${t=>t.ariaDetails}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-errormessage="${t=>t.ariaErrormessage}"
            aria-expanded="${t=>t.ariaExpanded}"
            aria-flowto="${t=>t.ariaFlowto}"
            aria-haspopup="${t=>t.ariaHaspopup}"
            aria-hidden="${t=>t.ariaHidden}"
            aria-invalid="${t=>t.ariaInvalid}"
            aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
            aria-label="${t=>t.ariaLabel}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-live="${t=>t.ariaLive}"
            aria-owns="${t=>t.ariaOwns}"
            aria-relevant="${t=>t.ariaRelevant}"
            aria-roledescription="${t=>t.ariaRoledescription}"
            ${(0,a.K)("control")}
        >
            ${(0,n.LT)(t)}
            <span class="content" part="content">
                <slot ${(0,r.e)("defaultSlottedContent")}></slot>
            </span>
            ${(0,n.aO)(t)}
        </a>
    `}},30581(t,e,o){"use strict";o.d(e,{yr(){return O}});var i=o(87993),a=o(96950),r=o(60402),n=o(69259),s=o(416),l=o(10108),d=o(82774),c=o(58792);const u=(0,o(75307).Eo)("MicrosoftLogoWithText","4806176","icons-wc/icons/shopping"),h=a.qy`<div class="footer ${t=>t.hasAbstract?"has-abstract-footer":""}" part="footer"><span part="start-actions" ${(0,r.K)("startActionsContainer")}><slot name="start-actions" ${(0,r.K)("startActions")} @slotchange=${t=>t.handleStartActionsContentChange()}></slot></span><span part="end-actions" ${(0,r.K)("endActionsContainer")}><slot name="end-actions" ${(0,r.K)("endActions")} @slotchange=${t=>t.handleEndActionsContentChange()}></slot></span></div>`,p=a.qy`<div style=" background: linear-gradient(265deg, rgb(18, 113, 3) 0%, rgb(69, 153, 3) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><img class="delivery-icon" loading="lazy" src="${(0,c.rA)().StaticsUrl}pr-3980746/shopping/deliveryTruckIcon.svg"><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">Free shipping</span></div>`,g=/\d+% cash ?back/i,f=a.qy`<div style=" background: linear-gradient(270deg, rgb(21, 61, 219) 0%, rgb(0, 113, 246) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">${t=>{var e;return(t.title&&(null===(e=t.title.match(g))||void 0===e?void 0:e[0]))??"Earn cash back"}}</span></div>`,v=(t,e)=>a.qy`<div style=" background: #424242; display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding: 0px 2px; padding-top: 0px; align-items:center; "><img src="${e}" aria-hidden="true" onerror="this.style.display='none'"/><span style=" ${t.includes("Holiday Deals")?"font-weight: 600;":"text-transform: uppercase; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size));"} color: white; padding:2px; align-items: center; ">${t}</span></div>`,m=a.qy`<div style="display: flex;">${t=>t.id.includes("__")?a.qy` ${(0,n.z)(t=>t.id.includes("_Christmas"),v("Holiday Deals","https://www.bing.com/th?id=OSS.BT4443E8F9A2BBD34313F790F7FC3FD09DD960AF1BCACA6A40544E8EBF98066A80"))} ${(0,n.z)(t=>t.id.includes("_BlackFriday"),v("Black Friday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))} ${(0,n.z)(t=>t.id.includes("_CyberMonday"),v("Cyber Monday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))}`:a.qy` ${(0,n.z)(t=>t&&!t.id.includes("_NoCashback"),f)} ${(0,n.z)(t=>t,p)} `}</div>`,b=a.qy`<div style="background: no-repeat center url('${t=>t.querySelector("img").src}');background-size: cover;filter: blur(40px); height: 100%; width:100%;position: absolute;"></div>`,x=a.qy`<div class="logo-container"><img src=${u} alt="Microsoft Logo" aria-hidden="true" /></div>`,y=a.qy`<template ${(0,s.Y)({property:"mediaNodes",filter:(0,l.Y)("[slot='media'], [slot='icon']")})}><span part="background-image" class='${t=>t.id.includes("contentcard_InfoBuyDirectCard")?"bd-background-image":"background-image"}'>${(0,n.z)(t=>t.id.includes("contentcard_tripleCashback"),x)} ${(0,n.z)(t=>t.id.includes("contentcard_edgeReclaim"),x)} ${(0,n.z)(t=>t.id.includes("contentcard_InfoBuyDirectCard"),b)}<slot name="background-image" ${(0,r.K)("backgroundImage")}></slot></span>${(0,n.z)(t=>t.id.includes("BuyDirectCard"),m)}<div class="mask" part="mask"></div><div class="body ${t=>t.hasAbstract?"has-abstract":""} ${t=>t.isGrid?"grid":""}" part="body">${(0,n.z)(t=>{var e;return(null==t||null===(e=t.mediaNodes)||void 0===e?void 0:e.length)>0},a.qy`<div class="media-wrapper" part="media-wrapper"><div part="media" ${(0,r.K)("mediaContainer")}><slot name="media" ${(0,r.K)("media")} @slotchange=${t=>t.handleMediaContentChange()}></slot><slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot><span part="icon" ${(0,r.K)("iconContainer")} class="${t=>t.iconSlottedNodes&&t.iconSlottedNodes.length?"icon":"icon__hidden"}"><slot name="icon" ${(0,r.K)("icon")} ${(0,d.e)("iconSlottedNodes")}></slot></span></div></div>`)}<div class="heading-container" part="heading-container">${(0,n.z)(t=>{var e;return 0===(null==t||null===(e=t.mediaNodes)||void 0===e?void 0:e.length)},a.qy`<slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot>`)}<slot name="attribution"></slot><span class="heading-wrapper" part="heading-wrapper" role="heading" aria-level=${t=>t.headinglevel} name="heading"><a class="heading" part="heading" href=${t=>t.href?t.href:void 0} target=${t=>t.target?t.target:void 0} @click=${(t,e)=>t.handleContentCardLinkClick(e.event)} data-t="${t=>t.anchorTelemetryTag}"><slot></slot></a></span></div><div class="abstract" part="abstract"><slot name="abstract" ${(0,d.e)("abstract")}></slot></div>${(0,n.z)(t=>t.layout!==i.S.default,h)}</div>${(0,n.z)(t=>t.layout===i.S.default,h)}<span part="hover-actions" class="${t=>t.hoverActionsSlottedNodes&&t.hoverActionsSlottedNodes.length?"hover-actions":"hover-actions__hidden"}"><slot name="hover-actions" ${(0,d.e)("hoverActionsSlottedNodes")}></slot></span><slot name="call-to-action"></slot></template>`;var $=o(64187),w=o(73477),k=o(22131),C=o(74849),z=o(50882),P=o(7896),S=o(61138),T=o(64003),_=o(41123),F=o(48751),D=o(89580),A=o(95239),I=o(86856);const L=C.A` :host([layout="default"]) .media-wrapper{float:right}`,M=C.A` :host([layout="default"]) .media-wrapper{float:left}`,N=C.A`
    ${(0,$.V)("flex")} :host{--icon-size:24px;position:relative;width:auto;box-sizing:border-box;font-family:${P.O};flex-direction:column;outline:none;height:100%;overflow:hidden}:host(:hover) .hover-actions{opacity:1;transition:opacity 0.2s ease-in-out}.body{display:grid;justify-content:center;row-gap:8px;column-gap:10px;grid-template-columns:1fr auto;grid-template-rows:auto}:host([layout="default"]) .body .abstract{display:none}:host([layout="default"]) .body{display:block}:host([layout="default"]) .body.grid{display:grid}:host([layout="default"]) .body.grid .media-wrapper{float:none}:host([layout="default"]) .has-abstract .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([layout="default"]) .has-abstract .media-wrapper{margin-inline-start:16px}:host([image-priority]) .has-abstract .media-wrapper{margin-inline-start:0}.footer{padding-inline-start:var(--footer-start-padding,16px);padding-inline-end:var(--footer-start-padding,16px);padding-top:var(--footer-padding-top,0);padding-bottom:var(--footer-padding-bottom,4px);margin-top:auto;font-size:var(--footer-font-size,${S.k});
        line-height: var(--footer-line-height, ${S.F})}.logo-container{display:flex;align-items:center;position:fixed;bottom:16px;z-index:1000;left:17px}.footer,.start-actions,.end-actions{display:flex;flex-direction:row;align-items:center;justify-content:space-between;color:${T.c};
        fill: ${T.c}}.footer__hidden{display:none}.hover-actions{display:flex;flex-direction:column;position:absolute;top:8px;z-index:2;opacity:0}.hover-actions__hidden{display:none}.hover-actions:focus-within{opacity:1}.heading-container{grid-row:1;display:flex;flex-direction:column;padding-inline-start:var(--heading-start-padding,16px);padding-inline-end:var(--heading-end-padding,16px);padding-bottom:0;padding-top:16px}.heading-wrapper a:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;top:0;width:100%;z-index:1}:host([layout="condensed"]) .body{gap:0}:host([layout="condensed"]) .footer{grid-row:2;grid-column-start:1;grid-column-end:var(--footer-grid-column-end,auto);padding-inline-start:16px}:host([layout="condensed"]) .media-wrapper{position:relative;grid-row:1 / span 2;margin-top:5px}:host([layout="condensed"]) .heading-container{padding-top:0px;--heading-end-padding:12px}:host([layout="condensed"]) ::slotted([slot="attribution"]){margin-bottom:0px}.icon{position:absolute;display:inline-flex;top:auto;bottom:0;justify-content:center;align-items:center;margin:0 0 4px 0;margin-inline-start:4px}.hover-actions{inset-inline-end:8px}.icon{inset-inline-start:0}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){inset-inline-start:8px}.icon__hidden{display:none}::slotted([slot="icon"]){width:var(--icon-size);height:var(--icon-size);fill:#FFF}::slotted([slot="attribution"]){margin-bottom:6px}::slotted([slot="abstract"]){margin:2px 0}.media-wrapper{grid-row:1;grid-column:2;margin-inline-end:var(--media-inline-padding,16px);margin-top:16px}.media{display:flex;position:relative}:host([image-priority]) .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([image-priority]) .body{grid-template-columns:1}:host([image-priority]) .media-wrapper{grid-row:1;grid-column:span 2;margin:0}:host([image-priority]) .heading-container{grid-row:2;grid-column:span 2;padding-top:10px;padding-inline-start:var(--heading-start-padding,16px)}:host([image-priority]) ::slotted([slot="media"]),:host([layout="infoPaneSplitHorizontal"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPane"]) .media-wrapper,:host([layout="infoPane1x3y"]) .media-wrapper{grid-row:1;grid-column:1;margin-top:0;width:fit-content;height:fit-content}:host([layout="infoPane"]) .icon,:host([layout="infoPaneSplitVertical"]) .icon,:host([layout="infoPane1x3y"]) .icon{display:inline;left:0;top:0;margin:4px 0 0;margin-inline-start:4px}:host([layout="infoPaneSplitVertical"]) .icon{display:block}:host([layout="infoPaneSplitHorizontal"]) .icon{bottom:0px}:host([layout="infoPaneSplitHorizontal"]) .heading-container,:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{align-self:end}:host([layout="infoPaneSplitHorizontal"]) .body,:host([layout="infoPane"]) .body,:host([layout="infoPane1x3y"]) .body{height:100%;grid-template-rows:1fr auto}::slotted([slot="call-to-action"]){width:calc(100% - 32px);grid-row:3;z-index:1;grid-column:1 / span 2;margin:0 16px}::slotted([slot="media"]){border-radius:calc(var(--content-card-corner-radius,2) * 2px)}:host([layout="default"]) .grid .heading-container{grid-area:initial !important}:host([layout="default"]) .has-abstract .abstract{display:block;padding:0 16px 16px 16px}.abstract{position:relative;margin:0;font-size:var(--abstract-font-size,${_.K});
        line-height: var(--abstract-line-height, ${_.Z});
        font-weight: 400;
        grid-column: span 2;
        box-sizing: content-box;
        color: ${T.c};padding:0 16px}::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){z-index:2;display:grid;gap:5px;align-items:center;grid-auto-flow:column}::slotted([slot="call-to-action"]){z-index:2}::slotted(fluent-button[slot="start-actions"]),::slotted(fluent-button[slot="end-actions"]){color:${T.c};
        fill: ${T.c}}::slotted(fluent-button[appearance="stealth"]:not(:hover)),:slotted([slot="hover-actions"]:not(:hover)){background:transparent}.heading{text-decoration:none;outline:none;color:${F.l};
        font-size: var(--heading-font-size, ${D.Y});
        line-height: var(--heading-line-height, ${D.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,3);white-space:initial}.mask{display:none}.heading:hover,.heading:${w.N}{text-decoration:underline}.heading::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}:host([layout="infoPane"]),:host([layout="infoPane1x3y"]){justify-content:flex-end;border:none}:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{position:absolute;bottom:0;right:0;left:0;background:${A.p};
        box-shadow: 0px -25px 15px ${A.p}}:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{grid-column:1 / 3;z-index:1}:host([layout="infoPane"]) .has-abstract .heading-container,:host([layout="infoPane1x3y"]) .has-abstract .heading-container{grid-area:2/ 1 / span 2 / auto;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:8px;align-self:flex-start}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{grid-row:2;grid-column:2;color:${F.l};padding:8px 16px 0 16px;align-self:end;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:4}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract{display:none}:host([layout="infoPane"]) .has-abstract,:host([layout="infoPane1x3y"]) .has-abstract{grid-template-columns:1fr 1fr;gap:0 10px}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer{min-height:calc(40px - 4px)}:host([layout="infoPane"]) .has-abstract .abstract,:host([layout="infoPane1x3y"]) .has-abstract .abstract{display:-webkit-box;align-self:flex-end}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{display:flex;position:absolute;top:0;left:0;right:0;bottom:0;background-image:var(--mask-gradient,linear-gradient(to top,rgba(0,0,0,1),rgba(0,0,0,0) 176px))}:host([layout="infoPane1x3y"]) .mask{background-image:var(--mask-gradient,linear-gradient(rgba(0,0,0,0),rgba(0,0,0,1) 69px,rgba(0,0,0,1)));top:257px}:host([layout="infoPane"]) .has-abstract .has-abstract-footer,:host([layout="infoPane1x3y"]) .has-abstract .has-abstract-footer{grid-row:3;grid-column:2;position:inherit;align-self:flex-end;max-height:40px}:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer{margin-top:unset;grid-row:2;grid-column:1 / span 2;padding-inline-start:16px;padding-inline-end:16px}:host([layout="infoPane"]) ::slotted(msft-attribution[slot="attribution"]),:host([layout="infoPane1x3y"]) ::slotted(msft-attribution[slot="attribution"]){color:${F.l};text-shadow:0px 0.4px 0.9px rgba(0,0,0,0.13),0px 0px 2.22px rgba(0,0,0,0.11)}:host([layout="infoPaneSplitVertical"]){grid-template-columns:304px 1fr;grid-template-rows:auto;background:${A.p}}:host([layout="infoPaneSplitVertical"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPaneSplitVertical"]) .media-wrapper{grid-row:1 / span 2;grid-column:1;margin:0}:host([layout="infoPaneSplitVertical"]) .heading-container{grid-row:1;grid-column:2;--heading-start-padding:4px;--heading-end-padding:16px;padding-bottom:0;padding-top:16px}:host([layout="infoPaneSplitVertical"]) .footer{grid-row:2;grid-column:2;padding-inline-start:0;padding-inline-end:16px;padding-top:0}:host([layout="infoPaneSplitHorizontal"]) .body{grid-template-columns:1fr 1fr;grid-template-rows:326px auto auto;row-gap:4px;background:${A.p}}:host([layout="infoPaneSplitHorizontal"]) .media-wrapper{grid-column:1 / span 2;margin:0}:host([layout="infoPaneSplitHorizontal"]) .heading-container{grid-column:1;grid-row:2 / span 2;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:12px}:host([layout="infoPaneSplitHorizontal"]) .footer{grid-column:2;grid-row:3;box-shadow:none}:host([layout="infoPaneSplitHorizontal"]) .abstract{color:inherit;align-self:inherit;padding:12px 16px 0 16px}.background-image{position:absolute;top:0;left:0;right:0;bottom:0}:host([layout="infoPane1x3y"]) .background-image{position:absolute;top:0;left:0;right:0;bottom:136px}.background-image ::slotted(img){width:100%;height:100%;object-fit:cover}.bd-background-image ::slotted(img){width:100%;height:100%;object-fit:contain;position:absolute;top:0px}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){position:absolute;top:8px;z-index:1}::slotted([slot="content-indicator"]){margin-bottom:26px;align-self:flex-start}`.withBehaviors(new I.t(L,M),(0,k.mr)(C.A` .heading{color:${z.A.LinkText};
                    background: ${z.A.ButtonFace}}.abstract{color:${z.A.ButtonText}}.icon{background-color:#000;height:fit-content}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{color:${z.A.ButtonText};
                    background: ${z.A.ButtonFace}}.footer,.start-actions,.end-actions,::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){background:${z.A.ButtonFace};
                    color: ${z.A.ButtonText};fill:currentcolor}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{background-image:none}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer,:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer,:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{background:${z.A.ButtonFace};box-shadow:none}::slotted(fluent-button[appearance="stealth"]:not(:hover)){background:${z.A.ButtonFace};
                }
            `));var B=o(99900);const O=i.m.compose({name:`${B.i.prefix}-content-card`,template:y,styles:N,shadowOptions:{delegatesFocus:!0}})},30664(t,e,o){"use strict";o.d(e,{I(){return i}});const i="1"},32519(t,e,o){"use strict";o.d(e,{Tk(){return l},qh(){return s},wP(){return n}});var i=o(50866),a=o(25109);function r(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:i.NZ.DarkPlum,o=arguments.length>2&&void 0!==arguments[2]?arguments[2]:i.L9.LightBlue;return{darkCardFillColor:e,lightCardFillColor:o,cardFillColor:t?e:o}}function n(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:i.NZ.DarkPlum,e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:i.L9.LightBlue;return(arguments.length>2?arguments[2]:void 0)&&(t="#333",e="#FFF"),r((0,a.ud)(),t,e)}function s(t){return r(t,arguments.length>1&&void 0!==arguments[1]?arguments[1]:i.NZ.DarkPlum,arguments.length>2&&void 0!==arguments[2]?arguments[2]:i.L9.LightBlue)}function l(t,e){var o,i,a,r,n,s;e&&e.data&&(a=t,(r=e.data)&&(a?(r.cardFillColor=r.darkCardFillColor,r.cardSecondaryColor=r.darkCardSecondaryColor,r.gradientAngle=r.darkGradientAngle):(r.cardFillColor=r.lightCardFillColor,r.cardSecondaryColor=r.lightCardSecondaryColor,r.gradientAngle=r.lightGradientAngle)),e.cardFillColor=null===(o=e.data)||void 0===o?void 0:o.cardFillColor,null!==(i=e.data)&&void 0!==i&&i.immersiveCard&&(e.immersiveImage=t?null===(n=e.data)||void 0===n?void 0:n.darkImmersiveImage:null===(s=e.data)||void 0===s?void 0:s.lightImmersiveImage))}},34668(t,e,o){"use strict";o.r(e),o.d(e,{PrismCarouselCard(){return Z},PrismCarouselCardStyles(){return dt},PrismCarouselCardTemplate(){return ot},ToolingInfo(){return ct}});var i=o(45899),a=o(37180),r=o(4731),n=o(44767),s=o(73079),l=o(4151),d=o(12717),c=o(75003),u=o(65614),h=o(5565),p=o(99900),g=o(30581),f=o(71608),v=o(16038),m=o(52718),b=o(56911),x=o(60815),y=o(12680),$=o(22341),w=o(93552),k=o(39671),C=o(29658),z=o(32519),P=o(50866),S=o(71398),T=o(85349);const _="header",F="seeall",D="seemore",A="nextSlideArrow",I="previousSlideArrow",L="Inspiration",M="destination",N="contentCardClick",B="saveName",O="hide",E="showMoreName",H="showFewerName",j="undoShowMore",R="undoShowFewer",V="cardactionellipsis",G="hidecard",q="moresettings",J="https://www.bing.com/images?form=nptsee";var U=o(19359),K=o(41065);function W(t,e){return{headline:e.pageTitle,id:e.id}}function Q(t,e,o,i){var a,r;const n=(0,U.g)(M,W(0,t),T.MS.Navigate,T.MJ.Headline,{ext:null==e||null===(a=e.selectCarouselItem)||void 0===a||null===(a=a.contract)||void 0===a?void 0:a.ext}),s=W(0,t),l=(0,U.g)(N,s,T.MS.Navigate,T.MJ.Headline,{ext:null==e||null===(r=e.selectCarouselItem)||void 0===r||null===(r=r.contract)||void 0===r?void 0:r.ext}),d=(0,U.l)(D,s,T.MS.More,T.MJ.ActionButton),c=(0,U.l)(B,s,T.MS.Save,T.MJ.ActionButton),u=(0,U.l)(O,s,T.MS.Hide,T.MJ.ActionButton);return{contentCard:l,destination:n,seeMore:d,save:c,showMore:(0,U.l)(E,s,T.MS.Like,T.MJ.ActionButton),showFewer:(0,U.l)(H,s,T.MS.Dislike,T.MJ.ActionButton),undoShowMore:(0,U.l)(j,s,T.MS.Unlike,T.MJ.ActionButton),undoShowFewer:(0,U.l)(R,s,T.MS.Undislike,T.MJ.ActionButton),hide:u,componentRoot:l}}var X=o(3083),Y=o(32288);class Z extends k.U{constructor(){super(...arguments),this.moreSettingsAction=()=>{this.goToPersonalizeSettingsCallback?this.goToPersonalizeSettingsCallback():this.$emit("goToPersonalizeSettingsCallback")},this.extractFeedData=()=>{if(this.mapperArgs){const{cardMetadata:t,goToPersonalizeSettingsCallback:e}=this.mapperArgs;this.cardMetadata=t,this.goToPersonalizeSettingsCallback=e}},this.dealWithCardMetadata=()=>{if(this.cardMetadata)try{this.prismData=JSON.parse(this.cardMetadata.data)}catch(t){(0,$.c_)(t,w.muh,"carousel prism data fetch error")}},this.hideCard=async()=>{try{let t=!1;return t=await S.d.updateSegmentCardsEnableStatus([{cardType:C.s.PrismCarouselCard,enabled:!1}]),t&&(this.refreshSDCardSection?this.refreshSDCardSection():this.$emit("refreshSDCardSection")),t}catch(t){return(0,$.c_)(t,w.muh,"carousel prism hide card error"),!1}},this.transformSuperCarousel=()=>{var t,e,o,i,a,r,n,s;const l=this.telemetryContent,d=(0,z.wP)(P.NZ.DarkPlum,P.L9.LightBlue),c={headerData:{title:{displayText:(null===(t=this.strings)||void 0===t?void 0:t.headTitle)||"",url:J},headerLogo:"",actionMenuData:{skipEventDelegate:!0,telemetryTag:null==l||null===(e=l.ellipsisClick)||void 0===e?void 0:e.getMetadataTag(),hideCallback:this.hideCard,hideTelemtryTag:null==l||null===(o=l.hideCardClick)||void 0===o?void 0:o.getMetadataTag(),moreSettingsCallback:this.moreSettingsAction,moreSettingsTelemetryTag:null==l||null===(i=l.moreSettingClick)||void 0===i?void 0:i.getMetadataTag()}},content:[{tabName:"",items:this.generateCarouselContentData((null===(a=this.prismData)||void 0===a?void 0:a.items)||[]),telemetryTag:""}],telemetry:{carousel:(null==l?void 0:l.prismCarousel.getMetadataTag())||"",nextArrow:(null==l?void 0:l.flipperNext.getMetadataTag())||"",previousArrow:(null==l?void 0:l.flipperPrevious.getMetadataTag())||"",seeMore:(null==l||null===(r=l.seeMore)||void 0===r?void 0:r.getMetadataTag())||"",seeMoreCard:(null==l||null===(n=l.seeMoreCard)||void 0===n?void 0:n.getMetadataTag())||"",tabNext:"",tabPrev:"",title:(null==l||null===(s=l.headTitle)||void 0===s?void 0:s.getMetadataTag())||""},id:"prism-carousel",gridArea:this.gridArea||"1",cardSize:this.cardSize||"",childTemplateType:"",...d};c.seeMore={content:{displayText:this.strings.seeAll,url:J},showHeader:!0,showCard:!0},this.superCarouselData=c},this.generateCarouselContentData=t=>{const e=[];return t.forEach((t,o)=>{e.push({imageData:t.turl?{altText:t.pageTitle,source:(0,X.oQ)(t.turl,{width:240,height:240,enableDpiScaling:!1,quality:90})}:void 0,mediaType:t.turl?"image":void 0,optedOutOfReactions:!1,destinationUrl:t.clickUrl?t.clickUrl+"&form=ntpcar":"",defaultAnchorTarget:"_blank",immersiveCard:!1,title:t.pageTitle,telemetryContext:Q(t,this.parentTelemetry),hideActionTray:!0,imageRatio:"1:1",cardTagName:Y.ti,providerData:{logoImage:"",name:t.domain||""}})}),e}}experienceConnected(){this.extractFeedData(),this.dealWithCardMetadata(),this.telemetryContent=(t=>{if(!t)return;const e=(0,U.l)(_,{headline:_},T.MS.Navigate,T.EG.Click),o=(0,U.l)(F,{headline:F},T.MS.Navigate,T.EG.Click),i=(0,U.l)(D,{headline:D},T.MS.Navigate,T.EG.Click),a=(0,U.l)(A,{headline:A},T.MS.Paginate,T.EG.Click),r=(0,U.l)(I,{headline:I},T.MS.Paginate,T.EG.Click);return{componentRoot:t,prismCarousel:(0,K.u)(L,{type:T.MJ.Carousel}),itemClick:(0,U.l)(M,{headline:M},T.MS.Navigate,T.EG.Click),headTitle:e,seeMore:o,seeMoreCard:i,flipperNext:a,flipperPrevious:r,ellipsisClick:(0,U.l)(V,{headline:V},T.MS.Open,T.EG.Click),hideCardClick:(0,U.l)(G,{headline:G},T.MS.Hide,T.EG.Click),moreSettingClick:(0,U.l)(q,{headline:q},T.MS.Customize,T.EG.Click)}})(this.parentTelemetry),this.transformSuperCarousel()}shadowDomPopulated(){this.superCarouselData&&this.markVisuallyReadyRaf()}getExperienceType(){return y.JxY}}(0,b.Cg)([x.sH],Z.prototype,"prismData",void 0),(0,b.Cg)([x.sH],Z.prototype,"superCarouselData",void 0),(0,b.Cg)([x.sH],Z.prototype,"telemetryContent",void 0);var tt=o(96950),et=o(69259);const ot=tt.qy`
${(0,et.z)(t=>t.superCarouselData,tt.qy`<div id="prism-carousel-card"><cs-carousel :data="${t=>t.superCarouselData}"></cs-carousel></div>`)}
`;var it=o(86856),at=o(22131),rt=o(74849);const nt=rt.A` .container{background:linear-gradient(323.98deg,#341F23 10.67%,#2F1C20 100%)}.body{background:rgba(255,255,255,0.07);border-radius:4px}`,st=rt.A`
`,lt=rt.A`
`,dt=rt.A`
`.withBehaviors((0,at.G2)(nt),new it.t(st,lt));i.m.define(a.c.registry),r.m.define(a.c.registry),n.m.define(a.c.registry),s.m.define(a.c.registry),l.m.define(a.c.registry),d.m.define(a.c.registry),c.m.define(a.c.registry),v.m.define(u.G.registry),h.KF.define(p.i.registry),g.yr.define(p.i.registry),f.Af.define(p.i.registry),(0,m.S)();const ct={experienceConfigSchema:undefined}},37256(t,e,o){"use strict";o.d(e,{R(){return u}});var i=o(64187),a=o(22131),r=o(74849),n=o(50882),s=o(37998),l=o(57416),d=o(95239),c=o(48751);const u=r.A`
    ${(0,i.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${d.p};
        color: ${c.l};
        border-radius: calc(${l.JU} * 1px);
        ${s.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,a.mr)(r.A`
            :host {
                forced-color-adjust: none;
                background: ${n.A.Canvas};
                box-shadow: 0 0 0 1px ${n.A.CanvasText};
            }
        `))},38380(t,e,o){"use strict";o.d(e,{v(){return i}});const i=(0,o(25717).T)()},42792(t,e,o){"use strict";o.d(e,{R7(){return f},e(){return p},kc(){return g},nH(){return h}});var i=o(57416),a=o(55153),r=o(95239),n=o(26920),s=o(48751),l=o(64187),d=o(22131),c=o(74849),u=o(50882);const h=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,p=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${r.p};
        outline: calc(${n.XA} * 1px) solid ${a.cu};
        border-radius: calc((${i.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,g=(0,d.mr)(c.A`
            :host {
                background: ${u.A.Canvas};
                color: ${u.A.CanvasText};
            }
        `),f=c.A`
    ${p}
    ${h}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(g)},45899(t,e,o){"use strict";o.d(e,{m(){return p}});var i=o(37180),a=o(56911),r=o(7511),n=o(38493);class s extends r._{appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="neutral")}defaultSlottedContentChanged(){const t=this.defaultSlottedContent.filter(t=>t.nodeType===Node.ELEMENT_NODE);1===t.length&&t[0]instanceof SVGElement?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,a.Cg)([n.CF,(0,a.Sn)("design:type",String)],s.prototype,"appearance",void 0);var l=o(74849),d=o(25984),c=o(17767);const u=l.A`
    ${d._9}
`.withBehaviors((0,c.f)("accent",d.Vw),(0,c.f)("hypertext",d.aY),(0,c.f)("lightweight",d.ZI),(0,c.f)("outline",d.LA),(0,c.f)("stealth",d.ss)),h=(0,o(29995).M)(),p=s.compose({name:`${i.c.prefix}-anchor`,template:h,styles:u,shadowOptions:{delegatesFocus:!0}})},50866(t,e,o){"use strict";o.d(e,{L9(){return r},NZ(){return a},qJ(){return i}});const i={_1x_1y:"_1x_1y",_1x_2y:"_1x_2y",_2x_2y:"_2x_2y",_2x_1y:"_2x_1y"},a={DarkPlum:"dark-plum",DarkDesert:"dark-desert",DarkDawn:"dark-dawn",DarkSea:"dark-sea",DarkOrange:"dark-orange",DarkTropic:"dark-tropic",DarkMerlot:"dark-merlot",DarkPurple:"dark-purple",DarkGreen:"dark-green"},r={LightBlue:"light-blue",LightPurple:"light-purple",LightSky:"light-sky",LightPink:"light-pink",LightYellow:"light-yellow",LightBluebird:"light-bluebird",LightOrange:"light-orange",LightAqua:"light-aqua",LightGreen:"light-green"}},60143(t,e,o){"use strict";o.d(e,{B(){return r}});var i=o(96950),a=o(18893);function r(t={}){const e={};return i.qy`
        <template
            role="button"
            aria-disabled="${t=>!!t.disabled||void 0}"
            tabindex="${t=>t.hiddenFromAT?-1:0}"
            @keyup="${(t,e)=>t.keyupHandler(e.event)}"
        >
            ${o=>function(t,o){let r=e[t];return r||(e[t]=r=i.qy`
                <span part="${t}" class="${t}">
                    <slot name="${t}">
                        ${(0,a.R)(o[t])}
                    </slot>
                </span>
            `),r}(o.direction,t)}
        </template>
    `}},64183(t,e,o){"use strict";o.d(e,{o(){return n},t(){return r}});var i=o(68009),a=o(49399);function r(t,e,o,a,r,n,s){const l=t.closestIndexOf(e);return null==s&&(s=(0,i.F)(e)),{rest:t.get(l+s*o),hover:t.get(l+s*a),active:t.get(l+s*r),focus:t.get(l+s*n)}}function n(t,e,o,i,n,s,l=void 0,d,c,u,h,p=void 0){return(0,a.H)(e)?r(t,e,d,c,u,h,p):r(t,e,o,i,n,s,l)}},64240(t,e,o){"use strict";o.d(e,{$p(){return c},Dd(){return l},aR(){return s},sr(){return d}});var i=o(96950),a=o(69259),r=o(65055),n=o(72030);const s=i.qy`
    ${(0,a.z)(t=>t.config.childExperienceReferencesWC&&t.config.childExperienceReferencesWC.contextualFeedbackWC&&n.V.shouldDisplayFeedLevelCF,i.qy`${t=>(0,r.yN)(t.config.childExperienceReferencesWC.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{cFId:"00000",surveyTemplate:"feed-level",cardType:"feed-level"}})}`)}
`,l=i.qy`
    ${(0,a.z)(t=>t.config.childExperienceReferencesWC&&t.config.childExperienceReferencesWC.contextualFeedbackWC&&n.V.thumbnailCardData&&n.V.thumbnailCardTemplate&&n.V.isThumbnailCardInWhiteList(),i.qy`${t=>{var e,o,i;return(0,r.yN)(t.config.childExperienceReferencesWC.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{cFId:null===(e=n.V.thumbnailCardData)||void 0===e||null===(e=e.wpoMetadata)||void 0===e?void 0:e.cfId,cFMetadataType:null===(o=n.V.thumbnailCardData)||void 0===o?void 0:o.cFMetadataType,thumbnailCardData:n.V.thumbnailCardData,thumbnailCardTemplate:n.V.thumbnailCardTemplate,surveyTemplate:"thumbnail-popup",cardType:"thumbnail-popup",telemetryContent:null===(i=n.V.thumbnailCardData)||void 0===i||null===(i=i.telemetryContext)||void 0===i||null===(i=i.contentCard)||void 0===i||null===(i=i.contract)||void 0===i?void 0:i.content}})}}`)}
`,d=i.qy`
    ${(0,a.z)(t=>{var e;return t.contextualFeedbackData&&(null===(e=t.config)||void 0===e||null===(e=e.childRefs)||void 0===e?void 0:e.contextualFeedbackWC)},i.qy`${t=>{var e,o,i,a,n;return(0,r.yN)(null===(e=t.config)||void 0===e||null===(e=e.childRefs)||void 0===e?void 0:e.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{surveyTemplate:"opt-out",cFId:null===(o=t.contextualFeedbackData)||void 0===o?void 0:o.cFId,cFMetadataType:null===(i=t.contextualFeedbackData)||void 0===i?void 0:i.cFMetadataType,scenarioName:null===(a=t.contextualFeedbackData)||void 0===a?void 0:a.scenarioName,optOutActionCallback:null===(n=t.contextualFeedbackData)||void 0===n?void 0:n.optOutActionCallback,wideCardStyle:t.size&&!t.size.startsWith("_1x")&&!t.size.startsWith("_2x")&&!t.size.startsWith("1u"),cardType:t.cFId},attributes:{size:t.size}})}}`)}
`,c=i.qy`
    ${(0,a.z)(t=>{var e,o,i;return(null===(e=t.data)||void 0===e?void 0:e.contextualFeedbackData)&&(null===(o=t.config)||void 0===o||null===(o=o.childRefs)||void 0===o?void 0:o.contextualFeedbackWC)&&n.V.shouldDisplayCSAT(null===(i=t.data)||void 0===i||null===(i=i.contextualFeedbackData)||void 0===i?void 0:i.cFId)},i.qy`${t=>{var e,o,i;return(0,r.yN)(null===(e=t.config)||void 0===e||null===(e=e.childRefs)||void 0===e?void 0:e.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{surveyTemplate:"default",cFId:null===(o=t.data)||void 0===o||null===(o=o.contextualFeedbackData)||void 0===o?void 0:o.cFId,cFMetadataType:null===(i=t.data)||void 0===i||null===(i=i.contextualFeedbackData)||void 0===i?void 0:i.cFMetadataType,wideCardStyle:t.size&&!t.size.startsWith("_1x")&&!t.size.startsWith("_2x")&&!t.size.startsWith("1u"),cardType:t.cFId},attributes:{size:t.size}})}}`)}
`},69781(t,e,o){"use strict";o.d(e,{kM(){return u},pS(){return h}});var i=o(58792),a=o(70775);const r=[],n=1e3,s=1e3,l=new Map;function d(){return"vp"===a._3.getQueryParameterByName("reqsrc",location.href)||"1"===a._3.getQueryParameterByName("vptest",location.href)}function c(t){var e;return null===i.T3||void 0===i.T3||null===(e=i.T3.CurrentRequestTargetScope)||void 0===e?void 0:e.pageExperiments.some(e=>e.includes(t))}function u(t,e,o){t&&"function"==typeof e&&!r.includes(t)&&(d()||(c("prg-mousehovrev")?(r.push(t),setTimeout(()=>{!function(t,e){if(!r.includes(t))return;e();const o=r.indexOf(t);o>-1&&r.splice(o,1)}(t,e)},o??n)):function(t,e,o){const i=Date.now(),a=l.get(t)||{enterTimer:null,lastHoverTime:0,pendingLeave:!1};if(i-a.lastHoverTime<s)return;a.enterTimer&&clearTimeout(a.enterTimer);a.enterTimer=window.setTimeout(()=>{e(),a.lastHoverTime=Date.now(),a.enterTimer=null},o||n),l.set(t,a)}(t,e,o)))}function h(t,e){if(c("prg-mousehovrev")){if(!d())if(t&&r.includes(t)){const e=r.indexOf(t);e>-1&&r.splice(e,1)}else"function"==typeof e&&e()}else!function(t,e){if(!t||"function"!=typeof e||d())return;const o=l.get(t);if(!o)return void e();if(o.enterTimer)return clearTimeout(o.enterTimer),o.enterTimer=null,void l.delete(t);o.lastHoverTime>0&&e();l.delete(t)}(t,e)}},71608(t,e,o){"use strict";o.d(e,{Af(){return m}});var i=o(92687),a=o(96950),r=o(60402);const n=a.qy`<span part="image" ${(0,r.K)("imageContainer")}><slot name="image" ${(0,r.K)("image")} @slotchange=${t=>t.handleImageContentChange()}></slot></span><span part="content" class="content"><slot></slot></span>`;var s=o(74849),l=o(64187),d=o(22131),c=o(7896),u=o(61138),h=o(64003),p=o(74838),g=o(50882);const f=s.A`
        ${(0,l.V)("inline-flex")} :host{box-sizing:border-box;font-family:${c.O};
            font-size: ${u.k};
            font-weight: 400;
            line-height: ${u.F};
            align-items: center;
            color: ${h.c};min-height:16px}.content{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.image{display:flex;margin-inline-end:calc(${p.vR} * 2px);
        }
    `.withBehaviors((0,d.mr)(s.A` :host,.content{color:${g.A.CanvasText};
                    fill: currentcolor;
                }
            `));var v=o(99900);const m=i.m.compose({name:`${v.i.prefix}-attribution`,template:n,styles:f})},72030(t,e,o){"use strict";o.d(e,{V(){return m}});var i=o(56911),a=o(45702),r=o(2171),n=o(18272),s=o(60815),l=o(26419),d=o(77367),c=o(15525),u=o(44162),h=o(22341),p=o(93552),g=o(5065),f=o(27160);class v{constructor(){this.config={},this.shouldDisplayFeedLevelCF=!1,this.forceDisableCoolDown=!1,this.forceFeedLevelCSATsignal=!1,this.setConfig=t=>{this.config=t},this.triggerFeedLevelCFDisplayIfConditionMet=async t=>{const e=await this.shouldDisplayFeedLevelCSAT(t);e&&this.config.enableNurturingTriggerCSAT&&this.callNurturingToTriggerCF("feedLevelCF"),this.shouldDisplayFeedLevelCF=e},this.triggerCFDisplayIfConditionMet=(t,e)=>{if(this.thumbnailCardData)return;const o=t.defaultLayout[0],i=o.wpoMetadata;let a=(null==i?void 0:i.cFMetadataType)||(null==o?void 0:o.type);const r=null==i?void 0:i.isGA,n=this.getInCoolDown();if(r&&n&&d.YT.addOrUpdateTmplProperty("cardCFBlocked",i.cfId||"1"),r&&!n){var s;i.cfId||(i.cfId="00002",a=f.pL.Article);let r=null===(s=t.C1)||void 0===s?void 0:s[0];r&&r.mapRawData&&(r=r.mapRawData()),this.thumbnailCardData={...o,...r,cardSize:"1u",colSpan:1,cFMetadataType:a},this.thumbnailCardTemplate=e,this.isThumbnailCardInWhiteList()&&this.config.enableNurturingTriggerCSAT&&this.callNurturingToTriggerCF(i.cfId)}},this.shouldDisplayCSAT=t=>this.getInCoolDown()?(d.YT.addOrUpdateTmplProperty("cardCFBlocked",t||"1"),!1):(this.config.enableNurturingTriggerCSAT&&this.callNurturingToTriggerCF(t),!0),this.callNurturingToTriggerCF=t=>{const e={id:"popupCF",group:"Functional",placementSource:"Internal",surfaceModel:{surfaceType:"ContextualFeedbackCardLevel"},contentModel:{title:"cf title",description:"cf description",contentType:a.r.CallToChoice,choiceOptions:[]}};(0,l.sn)().then(o=>{o.sendInternalPlacement(e),d.YT.addOrUpdateTmplProperty("cfNurturingCalled",t||"1")})};const t=new URLSearchParams(window.location.search);this.forceDisableCoolDown=!(null==t||!t.get("forceCSATCoolDown")),this.forceFeedLevelCSATsignal=!(null==t||!t.get("forceCSATSignal"))}static getInstance(){return r.vv.get("__contextualFeedbackController__",()=>new v)}async shouldDisplayFeedLevelCSAT(t){var e;const o=this.forceFeedLevelCSATsignal||t||(null===(e=await async function(t){try{var e;const o=await g.V_.getWpoOptimizationData(t);if(!o)return null;const i=o.filter(t=>(null==t?void 0:t.type)===u.Ar.feedContextualFeedback),a=(null==i?void 0:i.length)>0&&!(null===(e=i[0])||void 0===e||null===(e=e.properties)||void 0===e||!e.showFeedCF);if(a)return d.YT.addOrUpdateTmplProperty("wpopromflcf","1"),{showFeedCF:a}}catch(t){const e="Error in getting wpo feed-level contextual feedback promotion data";(0,h.vV)(p.nwt,e,`error:${t}`)}return null}())||void 0===e?void 0:e.showFeedCF),i=this.getInCoolDown();return o&&i&&d.YT.addOrUpdateTmplProperty("feedCFBlocked","1"),!!o&&!i}getInCoolDown(){return!this.forceDisableCoolDown&&(this.inCoolDown||(this.inCoolDown=this.hasRecentShown()),this.inCoolDown)}resetInCoolDown(){this.inCoolDown=void 0}hasRecentShown(){const t=(0,c.Lg)().getObject("isGAShow");if(!t)return!1;const e=new Date(t.universal);return((new Date).getTime()-e.getTime())/864e5<=14}isThumbnailCardInWhiteList(){var t;return this.config.thumbnailCardType===(null===(t=this.thumbnailCardData)||void 0===t?void 0:t.childTemplateType)}}(0,i.Cg)([s.sH],v.prototype,"shouldDisplayFeedLevelCF",void 0),(0,i.Cg)([s.sH],v.prototype,"thumbnailCardData",void 0),(0,i.Cg)([s.sH],v.prototype,"thumbnailCardTemplate",void 0);const m=(0,n.G)(v)},72526(t,e,o){"use strict";o.d(e,{L(){return g}});var i=o(56911),a=o(96193),r=o(47429),n=o(60815),s=o(22870),l=o(38493),d=o(95239),c=o(31023),u=o(24458),h=o(5291),p=o(57606);class g extends a.z{cardFillColorChanged(t,e){if(e){const t=(0,s.Hs)(e);null!==t&&(this.neutralPaletteSource=e,d.p.setValueFor(this,h.q.create(t.r,t.g,t.b)))}}neutralPaletteSourceChanged(t,e){if(e){const t=(0,s.Hs)(e),o=h.q.create(t.r,t.g,t.b);c.r.setValueFor(this,p.p.create(o))}}handleChange(t,e){this.cardFillColor||d.p.setValueFor(this,t=>t(u.M3).evaluate(t,t(d.p)))}connectedCallback(){super.connectedCallback();const t=(0,r.Zo)(this);if(t){const e=n.cP.getNotifier(t);e.subscribe(this,"fillColor"),e.subscribe(this,"neutralPalette"),this.handleChange(t,"fillColor")}}}(0,i.Cg)([(0,l.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,i.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,i.Cg)([(0,l.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,i.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0)},75003(t,e,o){"use strict";o.d(e,{m(){return s}});var i=o(37180),a=o(72526),r=o(37256),n=o(38380);const s=a.L.compose({name:`${i.c.prefix}-card`,template:n.v,styles:r.R})},75307(t,e,o){"use strict";o.d(e,{Bl(){return h},Eo(){return d},KN(){return l},LG(){return c},Mj(){return p},kg(){return s},x8(){return u}});var i=o(58792),a=o(99476),r=o(26363),n=o(77367);function s(){const t=(0,a.a)();return!!t&&("1"===t.get("vptest")||"true"===t.get("vptest")||"vp"===t.get("reqsrc"))}function l(t,e){return d(t,e,"shopping/product-tracking")}function d(t,e,o){if("local"===e&&window.location.origin.indexOf("localhost")>-1)return`http://127.0.0.1:3000/shopping/${t}.svg`;if(t){const a=e?`pr-${e}`:"latest",r=o?`${o}`:"shopping";return`${(0,i.rA)().StaticsUrl}${a}/${r}/${t}.svg`}return""}function c(t){return t&&t.href&&(t.href=u(t.href)),!0}function u(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;const o=(new Date).getTime()+e,i=(0,r.G)(),a=new URL(t);return a.searchParams.set("ts",o.toString()),a.searchParams.set("m_clk",`sid-${i}`),a.toString()}function h(t){return!!t&&/p4psearch\.1688\.com/.test(t)}function p(t,e){if(t&&t.href){const o=new URL(t.href);o.searchParams.set("m_ac","176674350"),o.searchParams.set("PageId",n.YT.getRequestId()),o.searchParams.set("ct",e),t.href=u(o.toString())}return!0}},84506(t,e,o){"use strict";o.d(e,{d(){return s}});var i=o(56911),a=o(92011),r=o(38493);const n="next";class s extends a.L{constructor(){super(...arguments),this.hiddenFromAT=!0,this.direction=n}keyupHandler(t){if(!this.hiddenFromAT){const e=t.key;"Enter"!==e&&"Space"!==e||this.$emit("click",t)}}}(0,i.Cg)([(0,r.CF)({mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],s.prototype,"disabled",void 0),(0,i.Cg)([(0,r.CF)({attribute:"aria-hidden",converter:r.Bs}),(0,i.Sn)("design:type",Boolean)],s.prototype,"hiddenFromAT",void 0),(0,i.Cg)([r.CF,(0,i.Sn)("design:type",String)],s.prototype,"direction",void 0)},87993(t,e,o){"use strict";o.d(e,{S(){return i},m(){return d}});var i,a=o(56911),r=o(60815),n=o(92011),s=o(38493),l=o(94407);!function(t){t.default="default",t.condensed="condensed",t.infoPane="infoPane",t.infoPane1x3y="infoPane1x3y",t.infoPaneSplitVertical="infoPaneSplitVertical",t.infoPaneSplitHorizontal="infoPaneSplitHorizontal"}(i||(i={}));class d extends n.L{constructor(){super(...arguments),this.layout=i.default,this.headinglevel=3}handleStartActionsContentChange(){this.startActionsContainer.classList.toggle("start-actions",this.startActions.assignedNodes().length>0)}handleEndActionsContentChange(){this.endActionsContainer.classList.toggle("end-actions",this.endActions.assignedNodes().length>0)}abstractChanged(){this.$fastController.isConnected&&(this.hasAbstract=this.abstract.length>0)}handleMediaContentChange(){this.mediaContainer.classList.toggle("media",this.media.assignedNodes().length>0)}handleContentCardLinkClick(t){return this.handleContentCardClickOverride?this.handleContentCardClickOverride(t):(this.$emit("link-invoked",t),!0)}connectedCallback(){super.connectedCallback(),this.addEventListener("mouseover",this.mouseOver),this.addEventListener("mouseout",this.mouseOut),this.addEventListener("focusin",this.focusIn),this.addEventListener("focusout",this.focusOut)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mouseover",this.mouseOver),this.removeEventListener("mouseout",this.mouseOut),this.removeEventListener("focusin",this.focusIn),this.removeEventListener("focusout",this.focusOut)}mouseOver(){this.setExpanded(!0),this.hasHover=!0}mouseOut(){this.hasFocus||this.setExpanded(!1),this.hasHover=!1}focusIn(){this.setExpanded(!0),this.hasFocus=!0}focusOut(){this.hasHover||this.setExpanded(!1),this.hasFocus=!1}filteredContentIndicator(){return this.contentIndicatorNodes.filter(t=>t instanceof l.L)}setExpanded(t){this.filteredContentIndicator().forEach(e=>e.expanded=t)}}(0,a.Cg)([s.CF],d.prototype,"layout",void 0),(0,a.Cg)([(0,s.CF)({attribute:"heading-level",mode:"fromView",converter:s.R$})],d.prototype,"headinglevel",void 0),(0,a.Cg)([(0,s.CF)({mode:"fromView"})],d.prototype,"href",void 0),(0,a.Cg)([r.sH],d.prototype,"isGrid",void 0),(0,a.Cg)([r.sH],d.prototype,"anchorTelemetryTag",void 0),(0,a.Cg)([r.sH],d.prototype,"mediaNodes",void 0),(0,a.Cg)([r.sH],d.prototype,"hasAbstract",void 0),(0,a.Cg)([r.sH],d.prototype,"abstract",void 0),(0,a.Cg)([r.sH],d.prototype,"iconSlottedNodes",void 0),(0,a.Cg)([(0,s.CF)({attribute:"image-priority",mode:"boolean"})],d.prototype,"imagePriority",void 0),(0,a.Cg)([s.CF],d.prototype,"target",void 0),(0,a.Cg)([r.sH],d.prototype,"hoverActionsSlottedNodes",void 0),(0,a.Cg)([r.sH],d.prototype,"handleContentCardClickOverride",void 0),(0,a.Cg)([r.sH],d.prototype,"contentIndicatorNodes",void 0)},92687(t,e,o){"use strict";o.d(e,{m(){return a}});var i=o(92011);class a extends i.L{handleImageContentChange(){this.imageContainer.classList.toggle("image",this.image.assignedNodes().length>0)}}},93518(t,e,o){"use strict";o.d(e,{X(){return p}});var i=o(56911),a=o(97004),r=o(64183),n=o(95239),s=o(356),l=o(31023),d=o(37302),c=o(96193),u=o(38493),h=o(50866);class p extends c.z{constructor(){super(...arguments),this.size=h.qJ._1x_2y}cardFillColorChanged(t,e){this.isDarkCardGradient()?s.l.setValueFor(this,a.y.DarkMode):this.isLightCardGradient()?s.l.setValueFor(this,a.y.LightMode):s.l.deleteValueFor(this)}isDarkCardGradient(){return Object.values(h.NZ).includes(this.cardFillColor)}isLightCardGradient(){return Object.values(h.L9).includes(this.cardFillColor)}isNamedGradientFillColor(){return this.isLightCardGradient()||this.isDarkCardGradient()}connectedCallback(){super.connectedCallback(),d.jO.setValueFor(this,{evaluate(t,e){return(0,r.o)(t(l.r),e||t(n.p),-1,1,0,0,void 0,2,3,1,2,void 0)}})}}(0,i.Cg)([(0,u.CF)({attribute:"card-fill-color"}),(0,i.Sn)("design:type",Object)],p.prototype,"cardFillColor",void 0),(0,i.Cg)([u.CF,(0,i.Sn)("design:type",String)],p.prototype,"size",void 0)},94407(t,e,o){"use strict";o.d(e,{L(){return s}});var i=o(56911),a=o(60815),r=o(92011),n=o(38493);class s extends r.L{constructor(){super(...arguments),this.expanded=!1}defaultItemsChanged(){this.$fastController.isConnected&&(this.shouldanimate=this.defaultItems.length>0)}}(0,i.Cg)([(0,n.CF)({mode:"boolean"})],s.prototype,"expanded",void 0),(0,i.Cg)([a.sH],s.prototype,"defaultItems",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean",attribute:"animate"})],s.prototype,"shouldanimate",void 0)},95718(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M2.85 2.15a.5.5 0 10-.7.7l3.5 3.5a8.1 8.1 0 00-3.37 5.05.5.5 0 10.98.2 7.09 7.09 0 013.1-4.53l1.6 1.59a3.5 3.5 0 104.88 4.89l4.3 4.3a.5.5 0 00.71-.7l-15-15zm9.27 10.68a2.5 2.5 0 11-3.45-3.45l3.45 3.45zm-2-4.83l3.38 3.38A3.5 3.5 0 0010.12 8zM10 6c-.57 0-1.13.07-1.67.21l-.8-.8A7.65 7.65 0 0110 5c3.7 0 6.94 2.67 7.72 6.4a.5.5 0 01-.98.2A6.97 6.97 0 0010 6z"></path></svg>'},96193(t,e,o){"use strict";o.d(e,{z(){return a}});var i=o(92011);class a extends i.L{}},98515(t,e,o){"use strict";o.d(e,{Q(){return c}});var i=o(14475),a=o(96950),r=o(69259),n=o(77793),s=o(46983);const l=(t,e)=>{e.event.preventDefault(),window.dispatchEvent(new CustomEvent("dsaClick",{detail:{adSelectionCriteria:t.adSelectionCriteria,anchorElement:e.event.target,strings:t.config.localizedStrings},bubbles:!0,composed:!0}))},d=(t,e)=>("Enter"===e.event.key&&l(t,e),!0),c=t=>a.qy` ${(0,r.z)(!!t.enableDSADialog,a.qy`<a class="ad-label dsa" data-t=${t.telemetryTag||""} title=${t.dsaDialogTooltip||""} ?no-border=${Boolean(t.noBorder)} @click=${l} @keydown=${d} tabindex="0">${t.text||"Ad"}</a>`)} ${(0,r.z)(!t.enableDSADialog,a.qy`<a class="ad-label" data-t=${t.telemetryTag||""} href=${t.href||""} target="${i.z._blank}" title=${(0,s.jj)()&&t.text||""} ?no-border=${Boolean(t.noBorder)} ${!(0,s.jj)()&&(0,n.Ib)(!0,!1)}>${t.text||"Ad"}</a>`)} `}}]);