(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["shared-hero-news-card"],{1413(t,e,i){"use strict";i.d(e,{P(){return o},y(){return a}});var r=i(96950),n=i(82774);function o(t,e){return e?.some(e=>e.slot===t)}function a(t){const e=t.slotName??"";return r.qy`
        <div id="${e}" class="${e}" part="${e}">
            <slot
                name="${e}"
                ${t.slottedRef?(0,n.e)(t.slottedRef):""}
            >
                ${t.slottedDefault??""}
            </slot>
        </div>
    `}},4401(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M6 2h8a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V4c0-1.1.9-2 2-2zm0 1a1 1 0 00-1 1v12a1 1 0 001 1h8a1 1 0 001-1V4a1 1 0 00-1-1H6zm7 3.5a.5.5 0 01-.41.5H7.5a.5.5 0 01-.09-1h5.09c.28 0 .5.22.5.5zm0 3.5a.5.5 0 01-.41.5H7.5a.5.5 0 01-.09-1h5.09c.28 0 .5.22.5.5zm0 3.5a.5.5 0 01-.41.5H7.5a.5.5 0 01-.09-1h5.09c.28 0 .5.22.5.5z"></path></svg>'},4968(t,e,i){"use strict";i.d(e,{f(){return d}});var r=i(64187),n=i(74849),o=i(42792),a=i(99657),s=i(36452);const d=n.A.partial`position: relative; z-index: ${a.D};`;n.A`
    ${o.e}
    ${o.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${d}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},13326(t,e,i){"use strict";i.r(e),i.d(e,{SharedHeroNewsCard(){return k},SharedHeroNewsCardStyles(){return P},SharedHeroNewsCardTemplate(){return M},ToolingInfo(){return E}});var r,n=i(55615),o=i(7574),a=i(66690),s=i(59836),d=i(65614),l=i(56911);!function(t){t.Finance="FinanceHeroNews",t.Sports="SportsHeroNews"}(r||(r={}));var c=i(22341),h=i(93552),u=i(85349),g=i(58792),m=i(42161),p=i(90366),v=i(12680),y=i(33477),b=i(4401),x=i.n(b);const f=t=>{if(t.newsCardType===r.Finance){var e;const i=null===(e=t.telemetryBuilder)||void 0===e||null===(e=e.createTelemetryObject(t.telemetryObject,{name:"menuDataProviderClick",action:u.EG.Click,behavior:u.MS.Navigate}))||void 0===e?void 0:e.getMetadataTag();return[{id:"dataProvider",title:t.strings.dataProviderOptStr,onClick(){var e;window.open(null===(e=t.config)||void 0===e?void 0:e.financeDataProviderUrl,"_blank")},glyph:x(),telemetryTag:i}]}};var w=i(54229),_=i(39671),$=i(49116),z=i(60815);class k extends _.U{constructor(){super(...arguments),this.newsCardType=r.Finance,this.isDataReady=!1,this.extractFeedData=()=>{if(this.mapperArgs){var t,e,i,r;const{cardMetadata:n,goToPersonalizeSettingsCallback:o}=this.mapperArgs;this.subCards=n.subCards,this.newsCardType=n.type,this.goToPersonalizeSettingsCallback=o;const a=this.getTabSignature();this.telemetryObject=null===(t=this.telemetryBuilder)||void 0===t?void 0:t.createViewTelemetryObject(this.mapperArgs.parentTelemetryObject,{name:"SharedHeroNewsCard",signature:a});const s=null===(e=this.telemetryBuilder)||void 0===e?void 0:e.createViewTelemetryObject(this.telemetryObject,{name:this.newsCardType,signature:a});this.cardTelemetryTag=null===(i=this.telemetryBuilder)||void 0===i?void 0:i.createTelemetryObjectTag(s),this.strings=(null===(r=this.config)||void 0===r?void 0:r.localizedStrings)||{},this.transformData()}},this.transformData=()=>{this.isDataReady=!1;try{const t=this.subCards.slice(),e=this.getLeftNewsItemIndex(t)||0,i=t[e];t.splice(e,1),this.newsItem=this.transformNewsItem(i),this.newsList=this.getNewsList(t),this.superCardData=(t=>{var e;const i=`title${t.newsCardType}${t.newsCardType===r.Sports?"2":""}`,n=null===(e=t.newsItem)||void 0===e?void 0:e.destinationUrl,o=t.strings[i];return{id:t.id,gridArea:"",childTemplateType:"sd-card",parentTelemetryObject:t.telemetryObject,cardSize:t.cardSize,headerData:{isHideCardAvailable:!1,telemetryHeadlines:{title:o,logo:o},telemetryDestinationUrl:{title:n,logo:n},headerLogo:"",title:o,titleNavigationLink:n,actionMenuData:{isFollowInterests:!1,isManageInterests:!1,items:f(t),moreSettingsPersonalizeCallback(){var e;null===(e=t.goToPersonalizeSettingsCallback)||void 0===e||e.call(t)}}}}})(this),this.isDataReady=!0}catch(t){(0,c.vV)(h.gSu,`Invalid feed data: ${JSON.stringify(this.subCards)}; error: ${t},`)}}}experienceConnected(){this.telemetryBuilder=new w.x1,this.extractFeedData()}mapperArgsChanged(t,e){e&&e!==t&&this.extractFeedData()}feedLayoutCardSizeChanged(t,e){e&&e!==t&&(this.cardSize=this.feedLayoutCardSize,this.extractFeedData())}isArticleVisible(){return this.cardSize===y.uE._2x_2y}shadowDomPopulated(){this.isDataReady&&this.markVisuallyReadyRaf()}getLeftNewsItemIndex(t){const e=t.findIndex(t=>this.isValidNewsItem(t,!0));return-1!==e?e:t.findIndex(t=>this.isValidNewsItem(t,!1))}isValidNewsItem(t,e){var i;return Boolean(t.url&&t.title&&(!e||(null===(i=t.images)||void 0===i||null===(i=i[0])||void 0===i?void 0:i.url)))}getNewsList(t){const e=t.filter(t=>this.isValidNewsItem(t,!1)),i=(e.length>=3?e:t).slice(0,3).map(t=>this.transformNewsItem(t));return this.logErrorForInvalidNewsData(i),i}logErrorForInvalidNewsData(t){const e=t.reduce((t,e)=>(e.destinationUrl&&e.title||(t+=`${t?"; ":""}id: ${e.id}, title: ${e.title}, url: ${e.destinationUrl}`),t),"");e&&(0,c.vV)(h.gSu,`Invalid news data: ${e}`)}getTabSignature(){switch(this.newsCardType){case r.Finance:return"NTP_heronews_FinanceHeroNews";case r.Sports:return"NTP_heronews_SportsHeroNews";default:return""}}transformNewsItem(t){var e,i;const{title:r,url:n,images:o,provider:a,publishedDateTime:s,id:d}=t,l=this.addOcidAndCvid(n||""),c=null===(e=this.telemetryBuilder)||void 0===e?void 0:e.createTelemetryObject(this.telemetryObject,{name:"HeroNewsArticleClick",action:u.EG.Click,behavior:u.MS.Navigate}),h=null==o||null===(i=o[0])||void 0===i?void 0:i.url;return{childTemplateType:"sd-card",cardSize:"_1x_2y",defaultAnchorTarget:"_blank",destinationUrl:l,gridArea:"",imageData:h?{source:h,altText:r,imageWidth:"56px",imageHeight:"56px"}:void 0,immersiveCard:!0,mediaType:"image",providerData:{name:null==a?void 0:a.name,logoImage:this.updateImageSizeByCardSize((null==a?void 0:a.logoUrl)||"")},publishedDateTime:this.getRelativeTimeString(s||"",this.strings),title:r,metadata:{abstract:r,category:"news"},id:d,telemetryContext:{componentRoot:c,destination:c,contentCard:c},hideActionTray:!0}}resizeImage(t,e){if(!t)return"";const i=new URL(t),r=new URLSearchParams(i.search);for(const t in e)void 0!==e[t]&&r.set(t,e[t]);return i.search=r.toString(),i.toString()}updateImageSizeByCardSize(t){return this.resizeImage(t,{w:16})}getRelativeTimeString(t,e){const i=g.T3.CurrentMarket,r=this.getRelativeTimePrefixFormat(e);try{return(0,$.sq)(new Date(t),i,r,void 0,void 0,!0)}catch(t){return""}}getRelativeTimePrefixFormat(t){const e=t.relativeTimeLocalization||{},i="{0}";return{JustNow:e.justNowLabel,NumberMinuteAgo:i+e.numberMinutesAgoLabel,NumberMinutesAgo:i+e.numberMinutesAgoLabel,NumberHourAgo:i+e.numberHoursAgoLabel,NumberHoursAgo:i+e.numberHoursAgoLabel,NumberDayAgo:i+e.numberDaysAgoLabel,NumberDaysAgo:i+e.numberDaysAgoLabel,NumberWeekAgo:i+e.numberWeeksAgoLabel,NumberWeeksAgo:i+e.numberWeeksAgoLabel,NumberMonthAgo:i+e.numberMonthsAgoLabel,NumberMonthsAgo:i+e.numberMonthsAgoLabel,NumberYearAgo:i+e.numberYearsAgoLabel,NumberYearsAgo:i+e.numberYearsAgoLabel}}addOcidAndCvid(t){return null!=t&&t.startsWith("http")?t:t?(0,m.g2)((0,p.t7)(t)):""}getExperienceType(){return v._Jh}}(0,l.Cg)([z.sH],k.prototype,"mapperArgs",void 0),(0,l.Cg)([z.sH],k.prototype,"subCards",void 0),(0,l.Cg)([z.sH],k.prototype,"superCardData",void 0),(0,l.Cg)([z.sH],k.prototype,"newsList",void 0),(0,l.Cg)([z.sH],k.prototype,"newsItem",void 0),(0,l.Cg)([z.sH],k.prototype,"newsCardType",void 0),(0,l.Cg)([z.sH],k.prototype,"isDataReady",void 0),(0,l.Cg)([z.sH],k.prototype,"cardSize",void 0),(0,l.Cg)([z.sH],k.prototype,"feedLayoutCardSize",void 0);var T=i(96950),N=i(69259),C=i(94043),A=i(50193);const I=T.qy`<cs-article-card-carousel class="card carousel-no-dark-bg" :data=${t=>t.newsItem}></cs-article-card-carousel>`,D=T.qy`<div slot="card-content" class="content ${t=>t.isArticleVisible()?"":"no-art"}">${I}<responsive-list class="list" :contentList=${t=>t.newsList}></responsive-list></div>`,S=T.qy`${t=>(0,A.C)(`TTSR.${t.newsCardType}`)}`,M=T.qy`<div class="wrap"><responsive-sd-card :data="${t=>t.superCardData}" responsive-sizing-enabled="true" size="${t=>t.cardSize}" data-t="${t=>t.cardTelemetryTag}">${(0,N.z)(t=>t.isDataReady,D)}</responsive-sd-card></div>${(0,N.z)(()=>!(0,C.S)(),S)}
`;var H=i(74849),L=i(4968);const P=H.A` responsive-sd-card:not([size="_2x_2y"]){--sd-card-content-padding-inline:4px}.wrap{position:relative}.content{overflow:hidden;display:flex}.card{width:278px;${L.f}}.list{margin-left:8px}.no-art .list{margin:0px}.no-art .card{display:none}`;(0,o.o)(),(0,n.c)(),a.csResponsiveList.define(d.G.registry),s.m.define(d.G.registry);const E={experienceConfigSchema:undefined}},26831(t,e,i){"use strict";i.d(e,{Hg(){return a}});var r=i(58792),n=i(26220);const o=/[:/?#[\]@!$&'()*+,;=]/g;function a(t,e,i,a){let s=`${r.T3.NavTargetUrlWithLocale}/channel`;if(t&&i){const r="source"===i?"sr":"tp";s+="/"+[i,e?encodeURIComponent(e.replace(o,"")):"",`${r}-${t}`].filter(t=>t).join("/")}const d=new URL(s);return a||(d.search=(0,n.iA)()),(0,n.ou)().includes("localhost.msn.com")&&(d.host=(0,n.ou)()),d.toString()}},28160(t,e,i){"use strict";i.d(e,{Z(){return o}});var r=i(96950),n=i(58792);const o=r.qy`<button slot="hide-story" class="card-see-more" title=${t=>t.cardActionsTooltips&&t.cardActionsTooltips.seeMore} @click=${(t,e)=>t.toggleCardActionMenu&&t.toggleCardActionMenu(t,e.event)} data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.seeMore)||void 0===e?void 0:e.getMetadataTag()}}"><img src="${n.T3.StaticsUrl}latest/icons-wc/icons/MoreV2.svg" loading="lazy" alt="more" aria-hidden="true" /></button>`},29652(t,e,i){"use strict";i.d(e,{Y(){return c}});var r=i(85349),n=i(96950),o=i(69259),a=i(17857),s=i(41938),d=i.n(s),l=i(83222);const c=n.qy` ${(0,o.z)(t=>t.enableCardHideStoryIcon,n.qy`<button aria-label="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.hide}" class="card-hide" slot="hide-story" title="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.hide}" @click=${(t,e)=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^a.J.hide^a.J.hidden,"Hide",!0,null,null,null,e.event,null,"hidestory-button")} @keypress=${t=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^a.J.hide^a.J.hidden,"Hide","Hide",!0,null,null,null,null,null,"hidestory-button")} data-t="${t=>{var e,i,n;return(null===(e=t.telemetryContext)||void 0===e?void 0:e.hide)&&(i=t.telemetryContext.hide,new l.$({...null==i?void 0:i.contract,name:"showFewer",action:r.EG.Click,behavior:r.MS.Dislike,type:r.MJ.ActionButton,content:{...null==i||null===(n=i.contract)||void 0===n?void 0:n.content}}).getMetadataTag())}}">${n.qy.partial(d())}</button>`)}
`},41938(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M2.4 2.55l.07-.08a.75.75 0 01.98-.07l.08.07L8 6.94l4.47-4.47a.75.75 0 111.06 1.06L9.06 8l4.47 4.47c.27.27.3.68.07.98l-.07.08a.75.75 0 01-.98.07l-.08-.07L8 9.06l-4.47 4.47a.75.75 0 01-1.06-1.06L6.94 8 2.47 3.53a.75.75 0 01-.07-.98l.07-.08-.07.08z"></path></svg>'},49116(t,e,i){"use strict";i.d(e,{sq(){return h},KY(){return u},YS(){return g},Tp(){return m}});var r=i(97266),n=i(77809),o=i(62745);class a{constructor(t,e,i){this.timeLocStrings=t,this.locale=e,this.locUtility=i}transform(t,e,i){const r=3600,a=86400;if(!t)return"";if(!this.locUtility.supportsLocaleSpecifiers)return e;const s=(0,o.KU)(t);switch((0,o.vB)(t)){case n.H.None:return"";case n.H.JustNow:return this.timeLocStrings.JustNow;case n.H.LessThanOneHour:return this.timespanString(s,s<120?this.timeLocStrings.NumberMinuteAgo:this.timeLocStrings.NumberMinutesAgo,60);case n.H.Today:return this.timespanString(s,s<7200?this.timeLocStrings.NumberHourAgo:this.timeLocStrings.NumberHoursAgo,r);case n.H.Yesterday:if(0===i){const e=this.timeLocStrings.TimeYesterday;return this.locUtility.format(e,this.locUtility.formatTimeFromDate(t,this.locale))}return s<a?this.timespanString(s,s<7200?this.timeLocStrings.NumberHourAgo:this.timeLocStrings.NumberHoursAgo,r):this.timespanString(s,s<172800?this.timeLocStrings.NumberDayAgo:this.timeLocStrings.NumberDaysAgo,a);case n.H.ThisWeek:return 0===i?this.locUtility.format(this.timeLocStrings.TimeDayOfWeek,this.locUtility.localizedWeekday(t,this.locale),this.locUtility.formatTimeFromDate(t,this.locale)):this.timespanString(s,s<172800?this.timeLocStrings.NumberDayAgo:this.timeLocStrings.NumberDaysAgo,a);case n.H.ThisYear:return this.locUtility.localizedMonthDate(t,this.locale);default:return this.locUtility.localizedDateStringMedium(t,this.locale)}}timespanString(t,e,i){const r=Math.floor(t/i);return this.locUtility.format(e,this.locUtility.localizedNumberString(r,this.locale))}}const s={JustNow:"Just Now",JustNowSimple:"now",NumberMinuteAgo:"{0} minute ago",NumberMinutesAgo:"{0} minutes ago",NumberMinutesAgoSimple:"{0}m",NumberMinutesAgoAria:"{0} minutes",NumberHourAgo:"{0} hour ago",NumberHoursAgo:"{0} hours ago",NumberHoursAgoSimple:"{0}h",NumberHoursAgoAria:"{0} hours",NumberDayAgo:"{0} day ago",NumberDaysAgo:"{0} days ago",NumberDaysAgoSimple:"{0}d",NumberDaysAgoAria:"{0} days",NumberWeekAgo:"{0} week",NumberWeeksAgo:"{0} weeks",NumberWeeksAgoSimple:"{0}w",NumberWeeksAgoAria:"{0} weeks",NumberMonthAgo:"{0} month",NumberMonthsAgo:"{0} months",NumberMonthsAgoSimple:"{0}mo",NumberMonthsAgoAria:"{0} months",NumberYearAgo:"{0} year",NumberYearsAgo:"{0} years",NumberYearsAgoSimple:"{0}y",NumberYearsAgoAria:"{0} years",TimeYesterday:"Yesterday at {0}",TimeDayOfWeek:"{0} at {1}"},d={Minute:{one:"{0} دقيقة",two:"دقيقتان",threeToTen:"{0} دقائق",elevenPlus:"{0} دقيقة"},Hour:{one:"{0} ساعة",two:"ساعتان",threeToTen:"{0} ساعات",elevenPlus:"{0} ساعة"},Day:{one:"{0} يوم",two:"يومان",threeToTen:"{0} أيام",elevenPlus:"{0} يوما"},Week:{one:"{0} أسبوع",two:"{0} أسبوع",threeToTen:"{0} أسابيع",elevenPlus:"{0} أسبوعا"},Month:{one:"{0} شهر",two:"{0} شهر",threeToTen:"{0} أشهر",elevenPlus:"{0} شهرا"},Year:{one:"{0} عام",two:"{0} عام",threeToTen:"{0} أعوام",elevenPlus:"{0} عاما"}},l={Week:{one:"{0} שבוע",two:"{0} שבועיים",three:"{0} שבועות"},Month:{one:"{0} חודש",two:"{0} חודשיים",three:"{0} חודשים"},Year:{one:"{0} שנה",two:"{0} שנתיים",three:"{0} שנים"}},c={MsPerMinute:6e4,MsPerHour:36e5,MsPerDay:864e5,MsPerWeek:6048e5,MsPerMonth:2592e6,MsPerYear:31104e6};function h(t,e,i,n,o,h,u,g){const m=e&&e.toLowerCase();if(!(t instanceof Date)||isNaN(t.valueOf()))return"";if(h&&i)return function(t,e,i,r,n,o){if(!(t instanceof Date)||isNaN(t.valueOf()))return"";const a=c.MsPerMinute,s=c.MsPerHour,h=c.MsPerDay,u=c.MsPerWeek,g=c.MsPerMonth,m=c.MsPerYear,p=e.getTime()-t.getTime();if(p<a)return o?i.JustNowAria||"":n?i.JustNowSimple||"":i.JustNow||"";let v=m,y="Year";p<s?(v=a,y="Minute"):p<h?(v=s,y="Hour"):p<u?(v=h,y="Day"):p<g?(v=u,y="Week"):p<m&&(v=g,y="Month");const b=/^[Aa][Rr]-/.test(r),x=/^[Hh][Ee]-/.test(r),f=Math.floor(p/v);let w=null;w=b?function(t,e){if(t<2)return d[e].one;if(t<3)return d[e].two;if(t<11)return d[e].threeToTen;return d[e].elevenPlus}(f,y):x?function(t,e,i,r){if(r||"Minute"==i||"Hour"==i||"Day"==i)return t[`Number${i}${e>1||r?"s":""}Ago${r?"Simple":""}`];if(e<2)return l[i].one;if(e<3)return l[i].two;return l[i].three}(i,f,y,n):o?i[`Number${y}sAgoAria`]:i[`Number${y}${f>1||n?"s":""}Ago${n?"Simple":""}`];return w?w.replace("{0}",f):""}(t,new Date,i,m,u,g);if(!i&&"zh-cn"===m)return"";i||(i=s);const p=(o=o||new r.e).localizedDateString(t,m);n||(n=0);return new a(i,m,o).transform(t,p,n)}function u(t){return t.toLocaleString("ja-JP",{hour12:!1,hour:"2-digit",minute:"2-digit",day:"2-digit",month:"2-digit",timeZone:"Asia/Tokyo"}).replace("午後","").replace("午前","")}function g(t){return m(t,30)}function m(t,e){if(!t)return!0;if(!e||e<0)return!1;try{const i=new Date(t);if(isNaN(i.getTime()))return!0;const r=(new Date).getTime()-i.getTime();return Math.floor(r/c.MsPerDay)>=e}catch{return!0}}},54229(t,e,i){"use strict";i.d(e,{aC(){return y},YJ(){return o},x1(){return a},iJ(){return p},h9(){return v},LE(){return u},Eh(){return c},Ai(){return l},dI(){return h},j8(){return g},ao(){return m}});var r=i(85349),n=i(19359);const o={Customize:r.MS.Customize,Paginate:r.MS.Paginate,Hide:r.MS.Hide,Cancel:r.MS.Cancel,Close:r.MS.Close,Dislike:r.MS.Dislike,Show:r.MS.Show,Click:r.MS.Click};class a{createTelemetryObjectTag(t){return t?t.getMetadataTag():""}createTelemetryObject(t,e,i,o){if(!t||!e)return;const{name:a,content:s,...d}=e,l={...s,type:(null==s?void 0:s.type)||r.b5.StructuredData,vertical:this.verticalName,category:this.categoryName,subcategory:this.subCategoryName},c={...this.ext,signature:i};o&&(c.previewType=o);const h={...d,ext:c,zone:this.zone};return(0,n.g)(a,l,h)}createViewTelemetryObject(t,e){return this.createTelemetryObject(t,{name:e.name,action:r.EG.View,behavior:r.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType)}createViewTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:r.MS.View,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createNavClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createAddClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Add,type:r.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createHoverShowTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.Hover,behavior:r.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createMouseLeaveCloseTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.MouseLeave,behavior:r.MS.Close,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createDislikeActionTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:r.MS.Dislike,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createFollowTelemetryTag(t,e,i){const n=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:i?r.MS.Follow:r.MS.Unfollow,type:r.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createMenuDataProviderTelemetryTag(t,e,i){const n=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Undefined,type:r.MJ.ActionButton,content:{headline:e.headline},zone:i},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createNavClickWithTypeTelemetryTag(t,e,i){const n=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Navigate,type:i,content:{headline:e.headline,id:e.id,brandId:e.brandId,type:e.type||r.b5.StructuredData}},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createBehaviorTelemetryTag(t,e,i){const n=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:i,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createBaseContentCardTelemetryContext(t,e){const i=this.createTelemetryObject(t,{name:e.name,type:r.MJ.ContentCard,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType),n=this.createTelemetryObject(i,{name:e.name,type:r.MJ.Headline,behavior:r.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);if(i&&n)return{contentCard:i,destination:n}}initTelemetryBuilder(t,e,i,r,n){this.verticalName=t,this.categoryName=e,this.ext=i,this.zone=r,this.subCategoryName=n}updateExt(t){this.ext=t}}var s=i(77367),d=i(84742);function l(t){try{s.YT.sendActionEvent(t,r.EG.MouseLeave,r.MS.Close)}catch(t){return}}function c(t){try{s.YT.sendActionEvent(t,r.EG.Hover,r.MS.Show)}catch(t){return}}function h(t,e){try{s.YT.sendActionEvent(t,r.EG.Click,r.MS.Navigate,e)}catch(t){return}}function u(t,e,i){try{s.YT.sendActionEvent(t,e?r.EG.KeyPress:r.EG.Click,i?r.MS.Follow:r.MS.Unfollow)}catch(t){return}}function g(t){try{if(!t)throw new Error("Current target is undefined, cannot send content view telemetry.");s.YT.sendContentViewEvent(t,d.ym.View)}catch(t){return}}function m(t,e){const i=e?`${e}`:"";s.YT.addOrUpdateTmplProperty(t,i)}function p(t){s.YT.removeTmplProperty(t)}function v(t){for(const e of t)p(e)}var y,b=i(22341);!function(t){t.safeExecute=function(t,e,i,r,n){let o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return t()}catch(t){return i&&(0,b.vV)(i,`${r}: ${null==t?void 0:t.message}`,n,o),e}},t.safeExecuteAsync=async function(t,e,i,r,n){let o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return await t()}catch(t){return i&&(0,b.vV)(i,`${r}: ${null==t?void 0:t.message}`,n,o),Promise.resolve(e)}},t.logExceptionWithFormat=function(t,e,i,r,n){let o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};(0,b.c_)(t,e,`${r}${r?": ":""}${i}`,n,o)},t.logErrorWithFormat=function(t,e,i,r){let n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:{};(0,b.vV)(t,`${i}${i?": ":""}${e}`,r,n)}}(y||(y={}))},55615(t,e,i){"use strict";i.d(e,{c(){return a}});var r=i(84056),n=i(65614),o=i(97823);const a=()=>{(0,r.J)(),o.r.define(n.G.registry)}},59836(t,e,i){"use strict";i.d(e,{m(){return v}});var r=i(65614),n=i(92011);class o extends n.L{}var a=i(7896),s=i(61138),d=i(48751),l=i(74838),c=i(74849),h=i(64187),u=i(22131),g=i(50882);const m=c.A`
    ${(0,h.V)("inline-flex")} :host {
        box-sizing: border-box;
        font-family: ${a.O};
        font-size: ${s.k};
        font-weight: 400;
        line-height: ${s.F};
        align-items: center;
        color: ${d.l};
        min-height: 16px;
    }

    .content {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        align-self: baseline;
    }

    ::slotted([slot="image"]) {
        display: flex;
        margin-inline-end: calc(${l.vR} * 2px);
    }
`.withBehaviors((0,u.mr)(c.A`
            :host,
            .content {
                color: ${g.A.ButtonText};
                fill: currentcolor;
            }
        `)),p=i(96950).qy`
    <slot name="image"></slot>
    <span part="content" class="content">
        <slot></slot>
    </span>
`,v=o.compose({name:`${r.G.prefix}-attribution`,styles:m,template:p})},62745(t,e,i){"use strict";i.d(e,{KU(){return d},LY(){return c},_u(){return h},vB(){return u}});var r=i(77809);const n=3600,o=120,a=new RegExp("\\:([\\d]{2})");function s(){return new Date}function d(t){return(s().getTime()-t.getTime())/1e3}function l(t,e){return new Date(t.getFullYear(),t.getMonth(),t.getDate()+e,t.getHours(),t.getMinutes(),t.getSeconds(),t.getMilliseconds())}function c(t,e){return new Date(t.valueOf()+60*e*60*1e3)}function h(t,e){const i=parseInt(e),r=parseInt(a.exec(e)[1]),n=i<0?-1:1,o=new Date(t.getTime()+60*(60*i+n*r)*1e3),s=`0${Math.abs(i)}`.substr(-2)+":"+`0${Math.abs(r)}`.substr(-2);return o.toISOString().replace("Z",(n<0?"-":"+")+s)}function u(t){const e=d(t),i=function(){const t=s();return t.setHours(0,0,0,0),t}(),a=l(i,-1),c=l(i,-6),h=function(){const t=s();return new Date(t.getFullYear(),0,0,0,0,0,0)}();return e>=-3300&&e<-60?r.H.InMinutes:e<0?r.H.None:e<o?r.H.JustNow:e<n?r.H.LessThanOneHour:t>=i?r.H.Today:t>=a?r.H.Yesterday:t>=c?r.H.ThisWeek:t>=h?r.H.ThisYear:r.H.FullDate}},66690(t,e,i){"use strict";i.d(e,{csResponsiveList(){return W}});var r=i(89580),n=i(48751),o=i(4283),a=i(74089),s=i(4968),d=i(74849),l=i(22131),c=i(4126),h=i(69904);const u=d.A` .container{display:grid;grid-template-columns:1fr 1fr}.articleContent{height:max-content}`,g=d.A`
.articleHeadingInfo:hover .articleTitle{text-decoration:underline}`,m=d.A` .articleTitle{font-size:${r.Y};
        line-height: ${r.v};-webkit-line-clamp:3}cs-attribution{margin-bottom:6px}`,p=d.A` .articleContent.selected{background:#EBEBEB}.articleContent:hover{background:#F5F5F5}.articleContent:active{background:#E0E0E0}@media (prefers-color-scheme:dark){.articleContent.selected{background:#383838}.articleContent:hover{background:#3D3D3D}.articleContent:active{background:#1F1F1F}}`,v=d.A`
.articleContent:hover{background:rgba(255,255,255,0.06)}.articleContent.selected{background:#26292E}`,y=d.A`
.container{height:100%}.articleContent{border-radius:8px;color:${n.l};display:grid;gap:12px;grid-template-columns:auto var(--responsive-list-image-size,20.9%);height:33.33%;overflow:hidden;text-decoration:none;padding:0px 16px}a.articleContent:focus-visible{outline-offset:-1px}.articleContent.noImage{grid-template-columns:auto}.articleContent.selected{background:#F6F9FC}a{${s.f}}.articleContent:hover{background:rgba(0,0,0,0.04)}.articleHeadingInfo{height:fit-content;margin:auto 0px;min-height:60px;overflow:hidden}cs-attribution{display:flex;margin-bottom:4px;max-width:100%}cs-attribution::part(content){color:var(--content-color,${n.l})}cs-attribution .attribution-image{height:16px;width:16px}cs-attribution .divider{padding-inline-end:1px}cs-attribution .time{margin-inline-start:2px;unicode-bidi:embed}cs-attribution .webContentIcon{filter:invert(var(--iconInvert,0));margin:0px 2px;opacity:0.5;vertical-align:bottom}.articleTag{padding:1px 4px 3px;white-space:nowrap;border-radius:6px;background:${o.IR};
    color: ${a.l_}}.articleTag.breaking{background:#E10303}.articleTitle{display:-webkit-box;font-size:${h.Kg};
    font-weight: 600;
    line-height: ${h.Z6};
    overflow: hidden;
    -webkit-line-clamp: var(--responsive-list-title-lineheight, 2);
    -webkit-box-orient: vertical;
}

.articleImageContainer {
    display: flex;
    position: relative;
    align-items: center;
    justify-content: center;
}

.articleImage {
    aspect-ratio: 1/1;
    border-radius: 8px;
    margin: auto;
    max-width: 72px;
    width: 100%;
    object-fit: var(--responsive-list-image-object-fit, unset);
}

.articleContent.oneItemList {
    height: 100%;
}

.articleContent.twoItemList {
    --responsive-list-image-size: 35.8%;
    height: 50%;
}

.twoItemList .articleHeadingInfo {
    min-height: 92px;
}

.twoItemList .articleTitle {
    --responsive-list-title-lineheight: 3;
}

.twoItemList .articleImage {
    max-width: 116px;
}

.playIndicator {
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, .2);
    border-radius: 50%;
    display: flex;
    padding: 5px;
    position: absolute;
}

.playIndicator img {
    filter: invert(1);
    width: 14px;
}

@container (width < 300px) {
    .articleHeadingInfo {
        min-height: min-content;
    }

    .articleTitle {
        --responsive-list-title-lineheight: 1;
    }
}
`.withBehaviors((0,l.G2)(v),new c.o("horizontalMode",!0,u),new c.o("useSubtleControlColors",!0,p),new c.o("useSubtleItemSize",!0,m),new c.o("underlineTitle",!0,g));var b=i(96950),x=i(69259),f=i(39957),w=i(14475),_=i(60402),$=i(22162),z=i(58792);const k=`${(0,z.rA)().StaticsUrl}/latest/fluent-icons/globe_16_regular.svg`,T=b.qy`<cs-attribution>${(0,x.z)(t=>t.attrBadge,b.qy`<span class="articleTag ${t=>{var e;return null===(e=t.attrBadge)||void 0===e?void 0:e.type}}" slot="image">${t=>{var e,i;return(null===(e=t.attrBadge)||void 0===e?void 0:e.localizedLabel)||(null===(i=t.attrBadge)||void 0===i?void 0:i.value)}}</span>`)} ${(0,x.z)(t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.logoImage},b.qy`<img alt="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}" aria-hidden="true" class="attribution-image" decoding="${t=>t.enableLazyImage?"async":""}" loading="${t=>t.enableLazyImage?"lazy":""}" part="image" slot="image" src="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.logoImage}}" title="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}" @load=${t=>t.visualReadinessCallback&&t.visualReadinessCallback(1,$.j.provider)} />`)} ${(0,x.z)(t=>t.providerData&&t.providerData.name,b.qy`<span style="unicode-bidi: embed;" class="attribution-text" title="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}">${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}</span>`)} ${(0,x.z)(t=>t.isWebContent&&!t.metadata.videoMetadata,b.qy`<img class="webContentIcon" src="${k}">`)} ${(0,x.z)(t=>t.publishedDateTime,b.qy`<span aria-hidden="true" class="divider" focusable="false">·</span><span class="time">${t=>t.publishedDateTime}</span>`)}</cs-attribution>`,N=b.qy`<span class="playIndicator"><img aria-hidden="true" role="presentation" src="${(0,z.rA)().StaticsUrl}/latest/fluent-icons/play_16_filled.svg"></img></span>`,C=b.qy`<div class="articleImageContainer"><img class="articleImage" part="articleImage" src=${(t,e)=>{var i;return t.imageData?e.parent.getScaledListItemImage(t.imageData.source,null===(i=t.imageData)||void 0===i?void 0:i.options):""}} alt=${t=>{var e;return(null===(e=t.imageData)||void 0===e?void 0:e.altText)??""}}>${(0,x.z)((t,e)=>{var i;return(null===(i=e.parent.contentList)||void 0===i?void 0:i.length)>1&&"video"==t.contentType},N)}</div>`,A=b.qy` ${()=>T}<span class="articleTitle" ${(0,_.K)("articleContentRef")}>${t=>t.title}</span>`,I=b.qy`<span class="articleTitle" ${(0,_.K)("articleContentRef")}>${t=>t.title}</span>${()=>T}
`,D=b.qy`<a role="listitem" part="listContent" class=${(t,e)=>{var i;return((t,e,i)=>{let r="articleContent";return 1===t&&(r+=" oneItemList"),2===t&&(r+=" twoItemList"),e||(r+=" noImage"),i&&(r+=" selected"),r})(null===(i=e.parent.contentList)||void 0===i?void 0:i.length,!!t.imageData,t.selected||!1)}} href=${t=>t.destinationUrl} target="${(t,e)=>((t,e)=>e?w.z._self:t.openLinksInNewTab?w.z._blank:t.defaultAnchorTarget||w.z._self)(t,e.parent.config.enableOpenContentInSelf)}" title=${t=>t.title} data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.destination)||void 0===e?void 0:e.getMetadataTag()}}" @click="${(t,e)=>e.parent.clickHandler(t,e)}"><div class="articleHeadingInfo" part="listContentInfo">${(0,x.z)((t,e)=>e.parent.enableFlipTitleProvider,I,A)}</div>${(0,x.z)(t=>t.imageData,C)}</a>`,S=b.qy`<div class="container" role="list" data-t="${t=>{var e;return null===(e=t.listContainerTelemetry)||void 0===e?void 0:e.getMetadataTag()}}">${(0,x.z)(t=>null==t?void 0:t.contentList,b.qy` ${(0,f.ux)(t=>t.contentList,D,{positioning:!0})} `)}</div>`;var M=i(56911),H=i(92011),L=i(60815),P=i(38493),E=i(3083),F=i(10809),Y=i(27160);class j extends H.L{connectedCallback(){this.config=F.D.getConfig(),this.enableFlipTitleProvider=this.config.enableFlipTitleProvider,this.underlineTitle=this.contentList&&this.contentList[0]&&this.contentList[0].underlineTitle,super.connectedCallback()}getScaledListItemImage(t,e){const i={width:100,height:100,enableDpiScaling:!1,...e};return(0,E.oQ)(t,i)}clickHandler(t,e){return t.useMobile&&!t.isMsnMobile?(t.mobileCardClickCallback(e.event,Y.pL.Article,t,"article card"),!1):(t.contentClickCallback&&t.contentClickCallback(t,e),!0)}}(0,M.Cg)([L.sH],j.prototype,"contentList",void 0),(0,M.Cg)([L.sH],j.prototype,"listContainerTelemetry",void 0),(0,M.Cg)([(0,P.CF)({attribute:"horizontal-mode",mode:"boolean"})],j.prototype,"horizontalMode",void 0),(0,M.Cg)([(0,P.CF)({attribute:"use-subtle-control-colors",mode:"boolean"})],j.prototype,"useSubtleControlColors",void 0),(0,M.Cg)([(0,P.CF)({attribute:"use-subtle-item-size",mode:"boolean"})],j.prototype,"useSubtleItemSize",void 0),(0,M.Cg)([(0,P.CF)({attribute:"underline-title",mode:"boolean"})],j.prototype,"underlineTitle",void 0),(0,M.Cg)([(0,P.CF)({attribute:"enable-flip-title-provider",mode:"boolean"})],j.prototype,"enableFlipTitleProvider",void 0);const W=j.compose({name:"responsive-list",styles:y,template:S})},73893(t,e,i){"use strict";i.d(e,{m(){return s}});var r=i(65614),n=i(71008),o=i(42792);const a=i(96950).qy`
    <slot></slot>
`,s=n.h.compose({name:`${r.G.prefix}-card`,styles:o.R7,template:a})},77809(t,e,i){"use strict";var r;i.d(e,{H(){return r}}),function(t){t[t.None=0]="None",t[t.JustNow=1]="JustNow",t[t.LessThanOneHour=2]="LessThanOneHour",t[t.Today=3]="Today",t[t.Yesterday=4]="Yesterday",t[t.ThisWeek=5]="ThisWeek",t[t.ThisYear=6]="ThisYear",t[t.FullDate=7]="FullDate",t[t.InMinutes=8]="InMinutes"}(r||(r={}))},80090(t,e,i){"use strict";i.d(e,{m(){return I}});var r=i(65614),n=i(11310),o=i(7896),a=i(48751),s=i(41123),d=i(57416),l=i(62047),c=i(14996),h=i(89580),u=i(99657),g=i(86856),m=i(74849),p=i(73477),v=i(4126),y=i(22131),b=i(50882);const x=m.A`
    .text,
    .media-info,
    .gradient {
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
    }

    .action-tray {
        transition-duration: var(--video-transition-end-duration);
        transition-property: background-color;
    }

    ::slotted([slot="media-overlay"]) {
        color: #ffffff;
        fill: #ffffff;
        height: 40px;
        min-width: 40px;
        display: grid;
        padding: 0px;
        grid-auto-flow: column;
        grid-gap: 8px;
        box-sizing: border-box;
        align-items: center;
        justify-content: center;
        border-radius: 20px;
        border: 1px solid transparent;
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
        background: linear-gradient(
                    135deg,
                    rgba(0, 0, 0, 0.5) 0%,
                    rgba(0, 0, 0, 0.7) 100%
                )
                padding-box,
            linear-gradient(
                    180deg,
                    rgba(255, 255, 255, 0.4) 0%,
                    rgba(255, 255, 255, 0.2) 100%
                )
                border-box;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 22px;
        min-width: 22px;
        padding: 0 6px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 38px;
        min-width: 38px;
        padding: 0 6px;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([animate-video]) .media-info,
    :host([immersive-card][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_1x_2y"][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_2x_2y"][animate-video]) ::slotted([slot="media-overlay"]) {
        transition-delay: var(--video-transition-delay);
        transition-duration: var(--video-transition-start-duration);
        opacity: 0;
    }
`,f=m.A`
    .preload {
        transition: none !important;
    }

    :host {
        --content-padding: 16px;
        --no-image-action-tray-padding: 20px;
        --action-tray-padding: 10px;
        width: 100%;
        height: 100%;
        font-family: ${o.O};
        --video-transition-delay: 1s;
        --video-transition-start-duration: 1s;
        --video-transition-end-duration: 1s;
    }

    :host([subscibed])::after {
        position: absolute;
        content: "";
        bottom: 0;
        left: 0;
        right: 0;
        height: 4px;
        width: 100%;
        background: linear-gradient(90deg, #ffa03d 0%, #ffdb00 100%);
    }

    :host([size="_1x_2y"]),
    :host([size="_2x_2y"]) {
        --content-card-heading-font-size: 18px;
        --content-card-heading-line-height: 24px;
    }

    :host .content {
        display: grid;
        grid-template-columns: 1fr minmax(auto, 84px);
        grid-template-rows: 1fr auto;
        row-gap: 14px var(--content-padding) var(--content-padding) var(--content-padding);
        column-gap: 12px;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        color: ${a.l};
        position: relative;
    }

    :host([size="_1x_1y"]) .content {
        row-gap: 0px;
        padding: 14px var(--content-padding) 10px var(--content-padding);
    }

    :host([size="_2x_1y"]) .content {
        row-gap: 0px;
        padding: var(--content-padding) var(--content-padding) 14px var(--content-padding);
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        grid-template-columns: 1fr;
        column-gap: 0;
    }

    :host([size="_1x_2y"]) .content {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]) .content.no-image {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .content:not(.no-image) .text {
        padding-top: 12px;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .content:not(.no-image) .text {
        padding-top: 0;
    }

    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        align-items: end;
        grid-template-rows: 1fr auto auto;
    }

    :host([size="_2x_2y"]) .no-image {
        align-items: unset;
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content {
        padding: 0;
        row-gap: 0;
    }

    :host([size="_1x_1y"]) .content.no-image,
    :host([size="_2x_1y"]) .content.no-image,
    :host([size="_1x_2y"]) .content.no-image,
    :host([size="_2x_2y"]) .content.no-image {
        grid-template-rows: 1fr auto;
    }

    ::slotted([slot="abstract"]) {
        display: none;
        overflow: hidden;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: var(--abstract-max-lines, 7);
        margin-top: var(--abstract-margin-top, 5px);
    }

    .no-image ::slotted([slot="abstract"]) {
        display: -webkit-box;
        -webkit-line-clamp: var(--abstract-max-lines, 3);
    }

    :host([size="_1x_1y"]) .no-image ::slotted([slot="abstract"]),
    :host([size="_2x_1y"]) .no-image ::slotted([slot="abstract"]) {
        --abstract-max-lines: 1;
    }

    .text {
        grid-area: 1 / 1;
        padding: var(--content-padding) var(--content-padding) 0 var(--content-padding);
        overflow: hidden;
        font-size: ${s.K};
        line-height: ${s.Z};
    }

    :host([size="_1x_1y"]) .text,
    :host([size="_2x_1y"]) .text {
        padding: 0;
    }

    :host([size="_1x_1y"]) .no-image .text,
    :host([size="_2x_1y"]) .no-image .text {
        grid-column: 1 / span 2;
    }

    :host([size="_1x_2y"]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        padding: 14px var(--content-padding) 0 var(--content-padding);
        grid-row: 1;
    }

    :host([size="_2x_2y"]) .text,
    :host([size="_1x_2y"]) .text {
        grid-row: 2;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .text {
        background-color: var(--image-gradient-overlay-end-color);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray,
    :host([size="_1x_2y"]:not([immersive-card])) .action-tray,
    :host .no-image .action-tray {
        background-color: transparent;
    }

    :host([immersive-card]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        background: unset;
    }

    :host([size="_1x_2y"]) .action-tray,
    :host([size="_2x_2y"]) .action-tray {
        grid-row: 3;
        padding: 4px var(--content-padding) var(--action-tray-padding)
            var(--content-padding);
    }

    :host([immersive-card]) .action-tray,
    :host([size="_2x_2y"]) .content:not(.no-image) .action-tray {
        padding: var(--action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
    }

    .action-tray {
        grid-row: 2;
        grid-column: span 2;
        display: flex;
        position: relative;
        background-color: var(--image-gradient-overlay-end-color);
        padding: var(--action-tray-padding) var(--content-padding) var(--content-padding)
            var(--content-padding);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray {
        padding: 0;
    }

    :host([size="_2x_1y"]) .content:not(.no-image) .action-tray {
        grid-area: 2 / 1 / auto / auto;
    }

    :host([size="_1x_1y"]) .no-image .action-tray {
        padding: 4px 0 0 0;
    }

    :host([size="_1x_2y"]) .no-image .action-tray,
    :host([size="_2x_2y"]) .no-image .action-tray {
        padding: var(--no-image-action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
        background: none;
        grid-row: 2;
        grid-column: 1;
    }

    .media-info {
        display: grid;
        grid-auto-flow: column;
        width: fit-content;
        grid-gap: 4px;
        fill: white;
        color: white;
        margin-bottom: 8px;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .media-info {
        grid-row: 1;
        grid-column: 1;
        align-self: flex-end;
        margin-bottom: 6px;
        margin-inline-start: 6px;
    }

    :host([size="_2x_1y"]:not([immersive-card])) .media-info {
        grid-area: 1 / 2 / span2 / auto;
        align-self: flex-end;
        margin-bottom: 8px;
        margin-inline-start: 6px;
    }

    ::slotted([slot="media-info"]) {
        display: grid;
        align-items: center;
        grid-auto-flow: column;
        grid-gap: 3px;
        background-color: var(--image-gradient-overlay-end-color);
        border-radius: calc(${d.Pb} * 1px);
        padding: 2px 6px;
        font-size: ${l.t};
        line-height: ${l.e};
    }

    ::slotted([slot="hide-story"]) {
        box-sizing: border-box;
        align-items: center;
        background-color: #ffffff;
        border-radius: 100%;
        border: 1px solid #e5e5e5;
        color: rgba(0, 0, 0 1);
        cursor: pointer;
        display: flex;
        fill: currentcolor;
        font-family: ${o.O};
        font-size: ${s.K};
        height: 28px;
        justify-content: center;
        line-height: ${s.Z};
        margin-inline-start: 4px;
        min-width: 28px;
        outline: none;
        padding: 0;
        position: relative;
    }

    ::slotted([slot="hide-story"]:hover) {
        background-color: #f2f2f2;
    }

    ::slotted([slot="hide-story"]:active) {
        background-color: #f7f7f7;
    }

    :host .hide-story-wrapper {
        position: absolute;
        display: flex;
        flex-direction: row;
        top: var(--content-padding);
    }

    :host .hide-story {
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.1s linear;
    }

    :host(:hover) .hide-story,
    :host(:focus-within) .hide-story {
        opacity: 1;
    }

    :host ::slotted([slot="hide-story"]:${p.N}) {
        border-color: ${c.WN};
    }

    ::slotted([slot="media"]) {
        grid-column: 1;
        object-fit: cover;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media"]) {
        height: 84px;
        width: 84px;
        grid-row: 1;
        grid-column: 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media"]) {
        height: 114px;
        width: 216px;
        grid-area: 1 / 2 / span2 / 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_1x_2y"]) ::slotted([slot="media"]) {
        grid-row: 1;
        grid-column: 1;
        height: 157px;
        width: 100%;
        display: flex;
    }

    :host([size="_2x_2y"]) ::slotted([slot="media"]),
    :host([immersive-card]) ::slotted([slot="media"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
    }

    ::slotted([slot="attribution"]) {
        display: flex;
        grid-column: 1;
        grid-row: 1;
        margin-bottom: 8px;
    }

    :host([size="_1x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]),
    :host([size="_2x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]) {
        grid-column-end: 1;
    }

    .heading {
        color: ${a.l};
        fill: currentcolor;
        display: -webkit-box;
        outline: 0;
        overflow: hidden;
        text-decoration: none;
        -webkit-line-clamp: var(--heading-max-lines, 3);
        -webkit-box-orient: vertical;
        font-weight: 600;
        font-size: var(--content-card-heading-font-size, ${h.Y});
        line-height: var(--content-card-heading-line-height, ${h.v});
    }

    .heading:focus-visible {
        text-decoration: underline;
    }

    .heading:after {
        bottom: 0;
        content: "";
        height: 100%;
        left: 0;
        position: absolute;
        right: 0;
        width: 100%;
        z-index: ${u.I};
    }

    :host([size="_2x_2y"][immersive-card]) .heading {
        --heading-max-lines: 2;
    }

    .media-overlay {
        position: absolute;
        display: flex;
        align-items: center;
        justify-content: center;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        pointer-events: none;
    }

    :host([size="_1x_1y"]) .media-overlay {
        grid-column: 2;
        grid-row: 1;
        height: 84px;
        width: 84px;
    }

    :host([size="_1x_2y"]) .media-overlay {
        grid-row-start: 1;
        grid-row-end: 1;
    }

    :host([size="_2x_2y"]) .media-overlay,
    :host([immersive-card]) .media-overlay {
        top: 100px;
        align-items: unset;
    }

    :host([size="_1x_2y"]) .no-image .heading,
    :host([size="_2x_2y"]) .no-image .heading {
        --heading-max-lines: 9;
    }

    :host([size="_2x_1y"]) .media-overlay {
        grid-area: 1 / 2 / span2 / 2;
        height: 114px;
        width: 216px;
    }

    ::slotted(p) {
        font-weight: 400;
        font-size: var(--abstract-font-size, 14px);
        line-height: var(--abstract-line-height, 20px);
        font-kerning: auto;
        margin: 8px 0px 0px;
    }

    ::slotted([slot="footer-start"]),
    ::slotted([slot="footer-end"]),
    ::slotted([slot="hide-story"]) {
        z-index: ${u.D};
    }

    .footer-end,
    .footer-start {
        display: flex;
        align-items: center;
    }

    .footer-end {
        margin-inline-start: auto;
    }

    .gradient {
        background: linear-gradient(
            180deg,
            var(--image-gradient-overlay-start-color) 0%,
            var(--image-gradient-overlay-end-color) 100%
        );
        grid-row: 1;
        height: 100%;
        display: none;
    }

    :host([size="_2x_2y"]) .gradient,
    :host([immersive-card]) .gradient {
        display: block;
        height: 80px;
    }

    :host([size="_2x_2y"]) .no-image .gradient,
    .no-image .gradient {
        display: none;
    }

    :host([size="_2x_1y"]) .content {
        column-gap: 24px;
    }
`.withBehaviors(new v.o("mediaType","video",x),new g.t(m.A`
            :host .hide-story-wrapper {
                right: var(--content-padding);
            }
        `,m.A`
            :host .hide-story-wrapper {
                left: var(--content-padding);
            }
        `),(0,y.mr)(m.A`
            :host {
                forced-color-adjust: auto;
            }
            .gradient {
                display: none;
            }
            :host([size="_1x_2y"]) .content,
            :host([size="_1x_1y"]) .content,
            :host([size="_2x_1y"]) .content {
                background: ${b.A.ButtonFace};
            }
            :host([size="_1x_2y"]) .text,
            :host([size="_1x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .text,
            :host([size="_2x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .content,
            :host([immersive-card]) .content {
                background: transparent;
            }
            ::slotted([slot="hide-story"]) {
                color: ${b.A.ButtonText};
                fill: currentcolor;
            }
        `));var w=i(96950),_=i(82774),$=i(416),z=i(10108),k=i(69259),T=i(1413);const N=w.qy`
    <slot name="media" ${(0,_.e)("mediaSlot")}></slot>
`,C=(A={mediaTemplate:N},w.qy`
        <template
            role="article"
            ${(0,$.Y)({property:"childElements",filter:(0,z.Y)()})}
        >
            <div class="content${t=>t.mediaType?"":" no-image"}" part="content">
                ${A.mediaTemplate}
                ${(0,k.z)(t=>t&&(0,T.P)("media-info",t.childElements)&&!(t.immersiveCard||"_2x_2y"===t.size),(0,T.y)({slotName:"media-info"}))}
                <div class="gradient" part="gradient"></div>
                ${(0,T.y)({slotName:"media-overlay",slottedDefault:A.mediaOverlay})}
                <div class="text" part="text">
                    ${(0,k.z)(t=>t&&(0,T.P)("media-info",t.childElements)&&(t.immersiveCard||"_2x_2y"===t.size),(0,T.y)({slotName:"media-info"}))}
                    <slot name="attribution"></slot>
                    <a
                        id="heading"
                        class="heading"
                        part="heading"
                        href="${t=>t.href?t.href:void 0}"
                        target="${t=>t.target?t.target:void 0}"
                        @click=${(t,e)=>t.handleContentCardLinkClick(e.event)}
                        data-t="${t=>t.anchorTelemetryTag}"
                    >
                        <span role="heading" aria-level="${t=>t.headingLevel}">
                            <slot></slot>
                        </span>
                    </a>
                    ${(0,T.y)({slotName:"abstract"})}
                </div>
                <div
                    class="action-tray ${t=>t.loaded?"":"preload"}"
                    part="action-tray"
                >
                    ${(0,T.y)({slotName:"footer-start",slottedDefault:A.footerStart})}
                    ${(0,T.y)({slotName:"footer-end",slottedDefault:A.footerEnd})}
                </div>
                <div class="hide-story-wrapper" part="hide-story-wrapper">
                    ${(0,T.y)({slotName:"hide-story",slottedDefault:A.hideStory})}
                </div>
            </div>
        </template>
    `);var A;const I=n.W.compose({name:`${r.G.prefix}-content-card`,styles:f,template:C})},84056(t,e,i){"use strict";i.d(e,{J(){return s}});var r=i(59836),n=i(73893),o=i(80090),a=i(65614);function s(){r.m.define(a.G.registry),n.m.define(a.G.registry),o.m.define(a.G.registry)}},97266(t,e,i){"use strict";i.d(e,{e(){return o}});var r,n=i(48566);!function(t){t[t.Default=0]="Default",t[t.Medium=1]="Medium",t[t.MonthDate=2]="MonthDate",t[t.Weekday=3]="Weekday",t[t.Time=4]="Time"}(r||(r={}));class o{constructor(){this.dateFormatOptionsMap=new Map,this.setSupportsLocaleSpecifiers(),this.dateFormatOptionsMap.set(r.Medium,{year:"numeric",month:"short",day:"numeric"}),this.dateFormatOptionsMap.set(r.MonthDate,{month:"short",day:"numeric"}),this.dateFormatOptionsMap.set(r.Weekday,{weekday:"short"}),this.dateFormatOptionsMap.set(r.Time,{hour:"numeric",minute:"numeric"})}overrideDateFormat(t,e){t&&e&&this.dateFormatOptionsMap.set(t,e)}localizedDateString(t,e){return this.formatDate(t,r.Default,e)}localizedDateStringMedium(t,e){return this.formatDate(t,r.Medium,e)}localizedMonthDate(t,e){return this.formatDate(t,r.MonthDate,e)}localizedWeekday(t,e){return this.formatDate(t,r.Weekday,e)}formatTimeFromDate(t,e){return this.supportsLocaleSpecifiers&&this.dateFormatOptionsMap?t.toLocaleTimeString(e,this.dateFormatOptionsMap.get(r.Time)):t.toTimeString()}format(t){if(!t)return"";for(var e=arguments.length,i=new Array(e>1?e-1:0),r=1;r<e;r++)i[r-1]=arguments[r];return n.Qf.Format(t,...i)}localizedNumberString(t,e){return this.supportsLocaleSpecifiers?t.toLocaleString(e):t.toString()}formatDate(t,e,i){let n=null;if(this.supportsLocaleSpecifiers)if(e===r.Default)n=t.toLocaleDateString(i);else if(this.dateFormatOptionsMap){const r=this.dateFormatOptionsMap.get(e);n=t.toLocaleDateString(i,r)}return null===n&&(n=t.toDateString()),null!==n?n.replace(/\u200E/g,"").replace(/\u200F/g,""):n}setSupportsLocaleSpecifiers(){this.supportsLocaleSpecifiers=(()=>{try{(0).toLocaleString("i")}catch(t){return"RangeError"===t.name}return!1})()}}},97823(t,e,i){"use strict";i.d(e,{r(){return x}});var r=i(79454),n=i(31782),o=i(69329),a=i(29652),s=i(28160),d=i(8481),l=i(5569),c=i(96950),h=i(58914),u=i(74849),g=i(89580),m=i(12640);const p=u.A`:host,.card-outer{background:rgba(255,255,255,0.7);border-radius:8px;height:inherit;width:inherit}.card-content{background:rgba(255,255,255,0.7)}[slot="media"],.card-image{height:126px}[t-image-ratio="1:1"] .card-image{height:238px}::part(heading),[size="_1x_1y"] .card-title,[size="_1x_2y"] .card-title,[size="_2x_2y"] .card-title{font-size:${g.Y};
        line-height: ${g.v}}[size="_2x_2y"][immersive-card] .card-image{height:100%;width:100%}[size="_2x_2y"][immersive-card]::part(action-tray){height:0px}:host(:hover) .card-image.darkShadow{filter:brightness(0.9)}[immersive-card] .card-image{height:240px;width:320px}[immersive-card]{background:none;--neutral-foreground-rest:rgb(255,255,255)}`,v=u.A` :host(.carousel-no-dark-bg) .card-content,:host(.carousel-no-dark-bg) .card-outer{background-color:rgba(0,0,0,0)}.card-content,.card-outer{background:rgba(41,41,41,0.7)}`,y=u.A`
    ${h.l}
    ${p}
`.withBehaviors(new m.N(null,v));var b=i(2665);const x=l.d.compose({name:"cs-article-card-carousel",styles:y,template:(0,b._)({attribution:c.qy`${r.Au}`,footerStart:c.qy`${n.xZ}`,footerEnd:c.qy`${o.IL}`,hideStory:c.qy`${a.Y}${s.Z}`,title:c.qy`${d.B2}`})})}}]);