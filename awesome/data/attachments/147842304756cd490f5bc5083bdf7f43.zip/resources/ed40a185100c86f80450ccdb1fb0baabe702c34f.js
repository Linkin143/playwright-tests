(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["cs-core-desktop_libs_dist_design-system_z-index_js-libs_card-overlap-monitor_dist_CardOverlap-9791d7"],{903(t,e,i){"use strict";i.d(e,{D(){return d},G(){return s}});var o=i(93552),r=i(77367);let a,n;const s=()=>{n=new Map,a=new IntersectionObserver(t=>{for(const[t,e]of n.entries()){if(!(t&&e&&e.cardElement&&e.extTelemetry))return;const i=l(e.cardElement),o=i&&JSON.parse(i),r=o&&o.ext;if(!r||!r.row||!r.col)return;const a=`${r.row}-${r.col}`;t!==a&&(n.delete(t),n.set(a,{cardElement:e.cardElement,extTelemetry:r}))}t.forEach(t=>{const e=t.target,i=e&&l(e),o=i&&JSON.parse(i),r=o&&o.ext;if(!r||!r.row||!r.col)return;const a=`${r.row}-${r.col}`;t.isIntersecting?n.set(a,{cardElement:e,extTelemetry:r}):n.has(a)&&n.delete(a)})},{threshold:.99}),window.addEventListener("beforeunload",()=>{if("hidden"!==document.visibilityState)for(const[t,e]of n.entries()){if(!(t&&e&&e.cardElement&&e.extTelemetry))return;const i=t.split("-");if(isNaN(Number(i[0]))||isNaN(Number(i[1])))return;const o=parseFloat(i[0]),r=parseFloat(i[1]);c(e,n.get(`${o+1}-${r}`));c(e,n.get(`${o}-${r+1}`))}})},d=t=>{a&&t&&a.observe(t)};function l(t){if(t.classList&&t.classList.contains("infopane")){const e=t.querySelector("cs-article-card"),i=e&&e.shadowRoot&&e.shadowRoot.querySelector("cs-content-card");return i&&i.anchorTelemetryTag}return t.anchorTelemetryTag?t.anchorTelemetryTag:t.getAttribute("data-t")?t.getAttribute("data-t"):void 0}function c(t,e){if(!(t&&e&&e.cardElement&&e.extTelemetry&&t!==e))return;const i=t.cardElement.getBoundingClientRect(),a=e.cardElement.getBoundingClientRect();if(0===i.height||0===i.width||0===a.height||0===a.width)return;if(!(i.top>a.bottom||i.right<a.left||i.bottom<a.top||i.left>a.right)){const n=t.extTelemetry,s=e.extTelemetry;r.YT.sendAppErrorEvent({...o.ABd,message:"Feed cards are overlapping",pb:{...o.ABd.pb,customMessage:`{"${t.cardElement.id}": { "position": ${JSON.stringify(i)}, "slot": ${n.slot}, "template": "${n.template}", "row": ${n.row}, "col": ${n.col} },"${e.cardElement.id}": { "position": ${JSON.stringify(a)}, "slot": ${s.slot}, "template": "${s.template}", "row": ${s.row}, "col": ${s.col}}}`}})}}},1302(t,e,i){"use strict";i.d(e,{Be(){return o},WI(){return n},h(){return r},y3(){return a}});const o="TTSR.FirstSection",r=12,a=304,n=.08},1413(t,e,i){"use strict";i.d(e,{P(){return a},y(){return n}});var o=i(96950),r=i(82774);function a(t,e){return e?.some(e=>e.slot===t)}function n(t){const e=t.slotName??"";return o.qy`
        <div id="${e}" class="${e}" part="${e}">
            <slot
                name="${e}"
                ${t.slottedRef?(0,r.e)(t.slottedRef):""}
            >
                ${t.slottedDefault??""}
            </slot>
        </div>
    `}},6791(t,e,i){"use strict";i.d(e,{f(){return r}});var o=i(50645);class r{constructor(){this.config={},this.strings={},this.initialized=!1}async initConfig(t){var e,i;this.initialized||(this.config=await this.getConfigFromRef(t)||{},this.strings=(null===(e=this.config)||void 0===e?void 0:e.localizedStrings)||{},this.initialized=!!this.config&&!(null===(i=this.config)||void 0===i||!i.localizedStrings))}getConfig(){return this.config}getLocStrings(){return this.strings}async getConfigFromRef(t){try{const e=(null==t?void 0:t.configRef)||this.configRef,i=await o.L.getConfig(e);return null==i?void 0:i.properties}catch(t){return{}}}}},10809(t,e,i){"use strict";i.d(e,{D(){return s}});var o=i(18272),r=i(2171),a=i(6791);class n extends a.f{constructor(){super(...arguments),this.configRef={experienceType:"SuperComponentData",instanceSrc:"default"}}static getInstance(){return r.vv.get("__SuperComponentDataHelper__",()=>new n)}}const s=(0,o.G)(n)},12628(t,e,i){"use strict";i.d(e,{A(){return y}});var o=i(79454),r=i(31782),a=i(69329),n=i(28160),s=i(8481),d=i(5569),l=i(96950),c=i(58914),g=i(74849),p=i(75988);const h=g.A`
    ${p.p}
`,u=g.A`
    ${c.l}
    ${h}
`;var x=i(2665);const v=d.d.compose({name:"cs-article-card-no-hide-story",styles:u,template:(0,x._)({attribution:l.qy`${o.Au}`,footerStart:l.qy`${r.xZ}`,footerEnd:l.qy`${a.IL}`,hideStory:l.qy`${n.Z}`,title:l.qy`${s.B2}`})});var f=i(84056),m=i(65614);const y=()=>{(0,f.J)(),v.define(m.G.registry)}},16038(t,e,i){"use strict";i.d(e,{m(){return h}});var o=i(65614),r=i(13312),a=i(55153),n=i(7896),s=i(74849),d=i(64187);const l=s.A`
    ${(0,d.V)("grid")}

    :host {
        font-family: ${n.O};
        width: auto;
        grid-auto-columns: calc(${a.QG} * 1px);
        grid-auto-row: calc(${a.l8} * 1px);
        grid-gap: calc(${a.Sn} * 1px);
    }
`;var c=i(39957),g=i(96950);const p=g.qy`
    <template @keydown="${(t,e)=>t.handleKeyDown(e.event)}">
        ${(0,c.ux)(t=>t.childrenLayout,g.qy`
                ${(t,e)=>e.parent.selectTemplate(t)}
            `)}
    </template>
`,h=r.tA.compose({name:`${o.G.prefix}-feed-layout`,styles:l,template:p})},26831(t,e,i){"use strict";i.d(e,{Hg(){return n}});var o=i(58792),r=i(26220);const a=/[:/?#[\]@!$&'()*+,;=]/g;function n(t,e,i,n){let s=`${o.T3.NavTargetUrlWithLocale}/channel`;if(t&&i){const o="source"===i?"sr":"tp";s+="/"+[i,e?encodeURIComponent(e.replace(a,"")):"",`${o}-${t}`].filter(t=>t).join("/")}const d=new URL(s);return n||(d.search=(0,r.iA)()),(0,r.ou)().includes("localhost.msn.com")&&(d.host=(0,r.ou)()),d.toString()}},28160(t,e,i){"use strict";i.d(e,{Z(){return a}});var o=i(96950),r=i(58792);const a=o.qy`<button slot="hide-story" class="card-see-more" title=${t=>t.cardActionsTooltips&&t.cardActionsTooltips.seeMore} @click=${(t,e)=>t.toggleCardActionMenu&&t.toggleCardActionMenu(t,e.event)} data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.seeMore)||void 0===e?void 0:e.getMetadataTag()}}"><img src="${r.T3.StaticsUrl}latest/icons-wc/icons/MoreV2.svg" loading="lazy" alt="more" aria-hidden="true" /></button>`},29652(t,e,i){"use strict";i.d(e,{Y(){return c}});var o=i(85349),r=i(96950),a=i(69259),n=i(17857),s=i(41938),d=i.n(s),l=i(83222);const c=r.qy` ${(0,a.z)(t=>t.enableCardHideStoryIcon,r.qy`<button aria-label="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.hide}" class="card-hide" slot="hide-story" title="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.hide}" @click=${(t,e)=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^n.J.hide^n.J.hidden,"Hide",!0,null,null,null,e.event,null,"hidestory-button")} @keypress=${t=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^n.J.hide^n.J.hidden,"Hide","Hide",!0,null,null,null,null,null,"hidestory-button")} data-t="${t=>{var e,i,r;return(null===(e=t.telemetryContext)||void 0===e?void 0:e.hide)&&(i=t.telemetryContext.hide,new l.$({...null==i?void 0:i.contract,name:"showFewer",action:o.EG.Click,behavior:o.MS.Dislike,type:o.MJ.ActionButton,content:{...null==i||null===(r=i.contract)||void 0===r?void 0:r.content}}).getMetadataTag())}}">${r.qy.partial(d())}</button>`)}
`},30664(t,e,i){"use strict";i.d(e,{I(){return o}});const o="1"},36355(t,e,i){"use strict";i.d(e,{v(){return u}});var o=i(50866),r=i(43922),a=i(25109),n=i(29937),s=i(52356);function d(t,e){const i=t;return function(t){t.imageData&&t.imageData.source&&(t.mediaType=["video","webcontent"].includes(t.contentType)?r.z.video:r.z.image)}(i),function(t,e){t.immersiveCard||(t.immersiveCard=t.cardSize===o.qJ._2x_2y&&t.cardLayout!==n.Sv.infoPane||t.cardSize===o.qJ._2x_2y&&t.cardLayout===n.Sv.infoPane&&e.config&&!e.config.enableImmersiveInfopane||t.cardLayout===n.Sv.infoPane&&e.config&&e.config.enableSuperInfopane&&!e.config.disable1UImmersiveInfopane)}(i,e),i}function l(t,e){if(t.immersiveCard&&t.mediaType)return t.cardFillColor="#333",t.darkCardFillColor=t.cardFillColor,void(t.lightCardFillColor=t.cardFillColor);let i=!1;if(i=t.useMobile&&!t.isMsnMobile?(0,a.r0)(t):t.useWinSystemMode||t.isMsnMobile?s.y.appInDarkMode():(0,a.ud)(),e&&e.config&&e.config.enableFeedSuperCardsSingleColor)e.config.cardColorsOverride?(t.lightCardFillColor=e.config.cardColorsOverride.lightCardFillColor,t.darkCardFillColor=e.config.cardColorsOverride.darkCardFillColor):(t.lightCardFillColor="#FFFFFF",t.lightCardSecondaryColor=void 0,t.lightGradientAngle=void 0,t.darkCardFillColor="#292929",t.darkCardSecondaryColor=void 0,t.darkGradientAngle=void 0);else{var o,r;const e=null===(o=t.colorSamples)||void 0===o?void 0:o.find(t=>!1===t.isDarkMode),i=!e||!e.hexColor&&!e.secHexColor&&!e.gradientAngle;t.lightCardFillColor=i?"#FFFFFF":e.hexColor,t.lightCardSecondaryColor=i?"#E1E1E1":e.secHexColor,t.lightGradientAngle=i?"112.05deg":e.gradientAngle;const a=null===(r=t.colorSamples)||void 0===r?void 0:r.find(t=>!0===t.isDarkMode),n=!a||!a.hexColor&&!a.secHexColor&&!a.gradientAngle;t.darkCardFillColor=n?"#565656":a.hexColor,t.darkCardSecondaryColor=n?"#272727":a.secHexColor,t.darkGradientAngle=n?"112.05deg":a.gradientAngle}t.cardFillColor=i?t.darkCardFillColor:t.lightCardFillColor,t.cardSecondaryColor=i?t.darkCardSecondaryColor:t.lightCardSecondaryColor,t.gradientAngle=i?t.darkGradientAngle:t.lightGradientAngle}function c(t,e){if(!e||!e.config)return;if(!e.config.enableFeedSuperCardsSolidColor&&!t.enableNativeAdCardsSolidColor)return;if(!t.immersiveCard&&"#000000"!==t.cardFillColor||t.cardSize===o.qJ._2x_2y&&!t.imageData){t.lightCardFillColor="#FFF",t.lightCardSecondaryColor=void 0,t.lightGradientAngle=void 0,t.darkCardFillColor="#333",t.darkCardSecondaryColor=void 0,t.darkGradientAngle=void 0;const e=s.y.appInDarkMode();t.cardFillColor=e?t.darkCardFillColor:t.lightCardFillColor,t.cardSecondaryColor=void 0,t.gradientAngle=void 0}}function g(t,e){const i=e._config,o=d(t,e);return l(o,e),o.openLinksInNewTab=o.openLinksInNewTab||o.openArticleInNewTab,o.seeMoreOverride=i.seeMoreOverride,c(o,e),o}function p(t,e,i){var o,a,n;const s=d(t,e);return s.isInfopaneComplexAd=i,l(s,e),c(s,e),function(t,e){if(e&&e.config&&e.config.nativeAdImageQuality&&t.imageData&&t.mediaType===r.z.image&&t.imageData.source){const i=new URL(t.imageData.source),o=null==i?void 0:i.searchParams;o&&(o.set("qlt",e.config.nativeAdImageQuality),i.search=o.toString(),t.imageData.source=i.toString())}}(s,e),s.enableAdShimmerEffect=null==e||null===(o=e.config)||void 0===o?void 0:o.enableAdShimmerEffect,s.useFeeds3Designs=null==e||null===(a=e.config)||void 0===a?void 0:a.enableDynamicWaterfall,s.enableResponsiveWidth=null==e||null===(n=e.config)||void 0===n?void 0:n.enableResponsiveWidth,s}var h=i(99476);class u{static createViewModel(t,e){switch(t&&t.childTemplateType){case"article-card":case"content-card":case"web-content-card":return g(t,e);case"video-card":return function(t,e){const i=d(t,e);l(i,e),i.openLinksInNewTab=i.openLinksInNewTab||i.openArticleInNewTab,c(i,e);const r=e.config;return i.immersiveCard=i.cardSize===o.qJ._2x_2y&&i.immersiveCard,i.enableSuperVideoIconLarge=r.enableSuperVideoIconLarge,i}(t,e);case"native-ad-card":case"native-top-ad-card":return p(t,e);case"super-sd-card":return d(t,e);case"content-group":return function(t,e){let i=d(t,e);const r=e._config;i.cardData=t,i.lightCardFillColor="#FFFFFF",i.darkCardFillColor="#333";const a=s.y.appInDarkMode();i.cardFillColor=a?i.darkCardFillColor:i.lightCardFillColor,t.contentGroupMetadata.subCards.forEach((t,i)=>{t.isNativeAd&&t.nativeAds.length>0?t.nativeAds.forEach(i=>{p(i,e,t.nativeAds.length>1)}):(g(t,e),r.enableFeed3Cards&&"1u"===t.cardSize&&(t.cardSize="_1x_2y"))});const n=(0,h.a)().get("vpFreeze");i={...i,...r};const l=r.autoRotateIntervalMs;i.enableFlippersOnRest=r.enableInfopaneFlippersOnRest,i.enableTransparentFlippersOnRest=r.enableTransIfpFlippersOnRest,i.enableSlideShow=!r.disableSlideShow&&!n,i.enablePlayPauseButton=!r.disableInfopanePlayPauseButton,i.disableNavAnimation=r.disableNavAnimation,i.rotationDuration=l?l/1e3:3,i.enableSuperCardMemoize=e.getEnableSuperCardMemoize(),i.disableInfopaneComplexAds=r.disableInfopaneComplexAds,i.enableIpTransform=r.enableIpTransform,i.restartRotationTimer=r.restartRotationTimer;const c=r.enableOneCInfopaneNav&&i.cardSize===o.qJ._1x_2y;return i.tabCount=r.enableMaxInfopaneSlider&&!c?99:5,i}(t,e);case"infopane-card":return function(t,e){const i=d(t,e),r=e._config;i.cardData=t,i.lightCardFillColor="#FFFFFF",i.darkCardFillColor="#333";const a=s.y.appInDarkMode();i.cardFillColor=a?i.darkCardFillColor:i.lightCardFillColor,t.slideContentData.forEach((t,i)=>{t&&(t.isNativeAd?r.enableResponsiveInfopaneMap?p(t,e):t.nativeAds.length>0&&t.nativeAds.forEach(i=>{p(i,e,t.nativeAds.length>1)}):(g(t,e),r.enableFeed3Cards&&"1u"===t.cardSize&&(t.cardSize="_1x_2y")))});const n=(0,h.a)().get("vpFreeze"),l=r.autoRotateIntervalMs??i.cardData.autoRotateIntervalMs;r.autoRotateIntervalMs||i.wpoRotationDuration||(i.wpoRotationDuration=i.cardData.autoRotateIntervalMs/1e3),i.enableSlideShow=!r.disableSlideShow&&!n,i.enablePlayPauseButton=!r.disableInfopanePlayPauseButton,i.enableResponsiveInfopaneMap=r.enableResponsiveInfopaneMap,i.enableAutoPlayInfopaneVideos=r.enableAutoPlayInfopaneVideos,i.enableResponsiveCards=r.enableResponsiveComponent,i.disableNavAnimation=r.disableNavAnimation,i.shiftIpNavToRight=r.shiftIpNavToRight,i.rotationDuration=l?l/1e3:3,i.enableSingleRotation=i.cardData.enableRotateOnlyOnce,i.enableSuperCardMemoize=e.getEnableSuperCardMemoize(),i.disableInfopaneComplexAds=r.disableInfopaneComplexAds,i.enableFlippersOnRest=r.enableInfopaneFlippersOnRest,i.enableTransparentFlippersOnRest=r.enableTransIfpFlippersOnRest,i.enableIpTransform=r.enableIpTransform,i.enableInfopaneDenseCardInteraction=r.enableInfopaneDenseCardInteraction,i.restartRotationTimer=r.infopaneRestartRotationBuffer>0?i.wpoRotationDuration+r.infopaneRestartRotationBuffer:r.restartRotationTimer,i.cardData.flipperSize=r.ipFlipperCustomSize??"large",i.cardData.flipperColorInverted=r.invertIpFlipperColor,i.seeMoreOverride=r.seeMoreOverride,i.enableLazyInfopane=!!r.enableLazyInfopane,i.lazyInfopanePreloadCount=r.lazyInfopanePreloadCount;const c=r.enableOneCInfopaneNav&&i.cardSize===o.qJ._1x_2y;return r.enableBottomNav&&!c&&(i.navPosition="bottom"),i.tabCount=r.enableMaxInfopaneSlider&&!c?99:5,i}(t,e);case"carousel":return function(t,e){return d(t,e)}(t,e);default:return null}}}},38955(t,e,i){"use strict";var o=i(65614),r=i(79454),a=i(31782),n=i(69329),s=i(29652),d=i(28160),l=i(8481),c=i(5569),g=i(2665),p=i(96950),h=i(58914),u=i(74849),x=i(4283),v=i(86856),f=i(12640);const m=u.A``,y=u.A` .card-head-title{direction:rtl;padding:16px 14px 0px 0px}.card-head-title .card-icon{padding-left:6px}.card-head-title .card-icon{padding-left:6px}`,b=u.A` .feeds3::part(content){grid-template-rows:auto}.feeds3.card-outer{height:100%}.feeds3 .image-overlay{height:240px}.card-image{height:180px}.image-overlay{position:absolute;left:0px;bottom:-134px;width:304px;height:190px;border:none;background:linear-gradient(180deg,rgba(0,0,0,0) 0%,#000000 28%)}.immersive-text-wrapper{position:absolute;bottom:20px;left:50%;width:270px;height:124px;margin-left:-135px;padding:8px 12px 8px;box-sizing:border-box;background:#fff;border-radius:8px;color:var(--neutral-foreground-rest)}.immersive-text-wrapper.new-design{bottom:32px}.card-head-title{display:flex;position:absolute;z-index:99;padding:16px 0px 0px 14px}.card-head-background{background:linear-gradient(180deg,rgba(0,0,0,0.54) 0%,rgba(0,0,0,0) 62.96%,rgba(0,0,0,0) 100%);position:absolute;z-index:1;width:100%;height:80px;border-radius:6px 6px 0 0}.card-head-title .card-icon{padding-right:6px}.card-head-title .card-title-text{font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height);color:white;margin:0px}.card-head-title.new-design{cursor:pointer}.card-head-title.new-design .card-title-text:hover{text-decoration:underline}.card-title-wrapper{display:inline-block;overflow:hidden;text-decoration:none;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;line-height:20px}.breaking-news-tag{margin-right:4px;padding:0 5px;background-color:${x.IR};border-radius:3px;color:white}.breaking-news-red-tag{margin-right:4px;padding:0 5px;border-radius:3px;color:white;background-color:#C50F1F !important}.breaking-news-red-tag::part(control){background-color:#C50F1F !important}.card-action{position:absolute;z-index:2;bottom:7px}[size="_1x_1y"] .card-title{font-size:18px;line-height:20px}[size="_1x_2y"] .card-title{font-size:16px;line-height:20px}[size="_2x_2y"] .card-image{top:0px;height:auto}[size="_2x_2y"] .image-overlay{bottom:0px;width:612px}[size="_2x_2y"] .immersive-text-wrapper{width:578px;margin-left:-289px;--neutral-foreground-rest:#091c1c}[size="_2x_2y"] .card-title{font-size:22px;line-height:27px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;color:var(--neutral-foreground-rest)}[size="_2x_2y"] [media-type="image"] cs-attribution{color:var(--neutral-foreground-rest)}[size="_2x_2y"][immersive-card]::part(action-tray){height:0px}[size="_2x_2y"]:not([immersive-card])::part(action-tray){background:transparent}`,_=u.A` .immersive-text-wrapper{background:#333333;--neutral-foreground-rest:#ffffff}[size="_2x_2y"] .immersive-text-wrapper{--neutral-foreground-rest:#ffffff}`,$=u.A`
    ${h.l}
    ${b}
`.withBehaviors(new v.t(m,y),new f.N(null,_)),w=c.d.compose({name:"cs-article-card-immersive",styles:$,template:(0,g._)({attribution:p.qy`${r.$9}`,footerStart:p.qy`${a.Y$}`,footerEnd:p.qy`${n.IL}`,hideStory:p.qy`${s.Y}${d.Z}`,title:p.qy`${l.B2}`,overlay:p.qy`<div class="image-overlay" slot="media-overlay"></div>`,titleIcon:'<svg width="16" height="17" viewBox="0 0 16 17" fill="none"><path d="M8.02 1a.66.66 0 0 0-.37.12h-.01c-.7.36-1.23.96-1.5 1.69a3.44 3.44 0 0 0-.05 2.4c.14.4.33.8.57 1.15.1.14.2.28.25.44a1.4 1.4 0 0 1-.04 1.09 1.59 1.59 0 0 1-1.47.94h-.04c-.22 0-.45-.04-.64-.14-.23-.1-.43-.23-.61-.4l-.17-.2a.7.7 0 0 0-1.2.23l-.06.2a4.78 4.78 0 0 0 .21 3.36A5.3 5.3 0 0 0 7.8 15h.07c1.4 0 2.73-.53 3.75-1.49a4.92 4.92 0 0 0 1.56-3.62 5.54 5.54 0 0 0-1.82-4.12 13.21 13.21 0 0 1-2.04-2.3c-.52-.85-.6-1.32-.6-1.79 0-.4-.33-.68-.69-.68Z" fill="url(#paint0_linear_976_100007)"/><defs><linearGradient id="paint0_linear_976_100007" x1="7.83" y1="1" x2="7.63" y2="15" gradientUnits="userSpaceOnUse"><stop stop-color="#FF686C"/><stop offset="1" stop-color="#EC7A01"/></linearGradient></defs></svg>',isImmersiveCard:!0})});var z=i(84056),k=i(12628),F=i(45214);(0,z.J)(),w.define(o.G.registry),(0,F.O)(),(0,k.A)()},41938(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M2.4 2.55l.07-.08a.75.75 0 01.98-.07l.08.07L8 6.94l4.47-4.47a.75.75 0 111.06 1.06L9.06 8l4.47 4.47c.27.27.3.68.07.98l-.07.08a.75.75 0 01-.98.07l-.08-.07L8 9.06l-4.47 4.47a.75.75 0 01-1.06-1.06L6.94 8 2.47 3.53a.75.75 0 01-.07-.98l.07-.08-.07.08z"></path></svg>'},42792(t,e,i){"use strict";i.d(e,{R7(){return x},e(){return h},kc(){return u},nH(){return p}});var o=i(57416),r=i(55153),a=i(95239),n=i(26920),s=i(48751),d=i(64187),l=i(22131),c=i(74849),g=i(50882);const p=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,d.V)("flex")} :host {
        background: ${a.p};
        outline: calc(${n.XA} * 1px) solid ${r.cu};
        border-radius: calc((${o.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${r.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${r.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${r.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${r.QG} * 1px);
        height: calc(${r.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${r.QG} * 1px);
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc(${r.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,l.mr)(c.A`
            :host {
                background: ${g.A.Canvas};
                color: ${g.A.CanvasText};
            }
        `),x=c.A`
    ${h}
    ${p}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},43922(t,e,i){"use strict";i.d(e,{z(){return o}});const o={image:"image",video:"video"}},45214(t,e,i){"use strict";i.d(e,{O(){return P}});var o=i(65614),r=i(16038),a=i(56911),n=i(92011),s=i(60815),d=i(87119);class l extends n.L{}(0,a.Cg)([d.V],l.prototype,"configProvider",void 0),(0,a.Cg)([s.sH],l.prototype,"feedLayouts",void 0),(0,a.Cg)([s.sH],l.prototype,"layout",void 0),(0,a.Cg)([s.sH],l.prototype,"placeholderFeedLayout",void 0);var c=i(96950),g=i(36355),p=i(2171);class h{static getViewTemplate(t,e){const i=e&&e.getSuperCardsTemplatesMap(),o=i&&i[t.childTemplateType];if(!o)return null;const r=()=>{const t=c.qy.partial(o);return c.qy`
            <${t}
                class="card-container"
                config-instance-src="${t=>t.configInstanceSrc||"default"}"
                :displaySettings=${t=>t.displaySettings}
                :data=${t=>g.v.createViewModel(t,e)}
                style="grid-area:${t=>t.gridArea}"
                size="${t=>t.cardSize}"
                tabIndex="${t=>t.customTabIndex??0}"
            >
            </${t}>
        `};if(!e.getEnableSuperCardMemoize())return r();const a="_SuperContainer__TagCreatorFactory_",n=p.vv.get(a)||{};return n[o]||(n[o]=r(),p.vv.set(a,n)),n[o]}}var u=i(38493);class x extends l{constructor(){super(...arguments),this.lastFeedLayoutPosition=-1}feedLayoutsChanged(){var t;if(null===(t=this.feedLayouts)||void 0===t||!t.length)return;const e=this.configProvider.getCardTemplatesMap(),i=this.configProvider.getSuperCardsTemplatesMap();for(let t=this.lastFeedLayoutPosition+1;t<this.feedLayouts.length;t++){this.feedLayouts[t].feedData.defaultLayout.forEach(t=>{if(i[t.childTemplateType]){const i=h.getViewTemplate(t,this.configProvider);i&&(e[t.childTemplateType]=i)}})}this.lastFeedLayoutPosition=this.feedLayouts.length-1}}(0,a.Cg)([(0,u.CF)({attribute:"responsive-width"})],x.prototype,"responsiveWidth",void 0);var v=i(37635),f=i(74849);const m=f.A``,y=f.A`
    ${m} :host{display:grid;flex-flow:row wrap;gap:12px;justify-content:center;--layer-corner-radius:8}cs-feed-layout{grid-auto-rows:146px;--card-base-gap:12}:host([responsive-width="true"]) cs-feed-layout{grid-auto-columns:minmax(271px,348px);grid-auto-rows:auto}`.withBehaviors(new v.X(["configProvider"],t=>{var e;let i=f.A``;if(null!==(e=t.configProvider)&&void 0!==e&&null!==(e=e.config)&&void 0!==e&&e.feedLayoutGap){var o;const e=null===(o=t.configProvider)||void 0===o||null===(o=o.config)||void 0===o?void 0:o.feedLayoutGap;i=f.A` :host{gap:${e}px}cs-feed-layout{--card-base-gap:${e}; }
                `}return i}),new v.X(["configProvider"],t=>{var e,i,o;return t.configProvider&&t.configProvider.config&&(null!==(e=t.configProvider.config)&&void 0!==e&&e.useMobileNoHoverCards||null!==(i=t.configProvider.config)&&void 0!==i&&i.useMobileNoHoverLightCards||null!==(o=t.configProvider.config)&&void 0!==o&&o.enableChannelCard)?f.A` cs-feed-layout{grid-auto-rows:auto;grid-auto-columns:auto;`:f.A``}));var b=i(69259),_=i(39957);const $=c.qy` ${(0,b.z)(t=>!!(t.feedData&&t.feedData.defaultLayout&&t.feedData.defaultLayout.length),c.qy`<cs-feed-layout :disabledKeyListeners="${(t,e)=>e.parent.configProvider.getDisabledKeyListeners()}" layout="${(t,e)=>e.parent.layout}" :isPlaceholder="${t=>t.isPlaceholder}" :data="${t=>t.feedData}" :childTemplateMap="${(t,e)=>e.parent.configProvider.getCardTemplatesMap()}" :layoutStyles="${(t,e)=>e.parent.configProvider.getLayoutTemplatesMap()[t.templateId].styles}" style="${(t,e)=>e.parent.configProvider.getOverrideStyles()}" t-card-size="${t=>t.baseCardSize}"></cs-feed-layout>`)}`,w=c.qy` ${(0,b.z)(t=>t.feedLayouts&&t.feedLayouts.length,c.qy` ${(0,_.ux)(t=>t.feedLayouts,$)}<slot name="abovePlaceholder"></slot>${(0,b.z)(t=>t.placeholderFeedLayout,c.qy` ${(0,_.ux)(t=>[t.placeholderFeedLayout],$)} `)} `)}`,z=x.compose({name:"cs-personalized-feed",styles:y,template:w});var k=i(13312),F=i(29307),C=i(96787);class L extends n.L{constructor(){super(...arguments),this.enableWFMonitor=!1,this.sentinelHeight=1}feedLayoutsChanged(){this.mutateCurrentFeedLayouts()}placeholderFeedLayoutChanged(){this.placeholderFeedLayout&&this.mutateFeedLayout(this.placeholderFeedLayout)}layoutChanged(){this.mutateCurrentFeedLayouts(),this.placeholderFeedLayout&&this.mutateFeedLayout(this.placeholderFeedLayout)}responsiveFeedLayoutsChanged(){var t;this.cardTemplateMap=null===(t=this.responsiveFeedLayouts)||void 0===t||null===(t=t[0])||void 0===t?void 0:t.childTemplateMap}disconnectedCallback(){super.disconnectedCallback()}mutateCurrentFeedLayouts(){var t;null!==(t=this.feedLayouts)&&void 0!==t&&t.length&&this.layout&&this.feedLayouts.forEach(t=>this.mutateFeedLayout(t))}mutateFeedLayout(t){var e;const i=this.configProvider.getCardTemplatesMap();i["native-ad-card-video"]||(i["native-ad-card-video"]=(0,F.A)(i["native-ad-card"])),i["native-ad-card-boost"]||(i["native-ad-card-boost"]=(0,F.A)(i["native-ad-card"]));const o=null==t?void 0:t.feedData;null==o||null===(e=o.defaultLayout)||void 0===e||e.forEach((t,e)=>{const r=o[this.layout]&&o[this.layout].find(e=>(0,C.Yd)(e)&&e.id===t.id);r&&"video-card"===r.childTemplateType?t.childTemplateType="video-card":r&&"infopane-slide-card"===r.childTemplateType&&"infopane-slide-card"!==t.childTemplateType&&(o[this.layout].find(e=>(0,C.Yd)(e)&&e.id===t.id).childTemplateType=t.childTemplateType),this.updateTemplateForNotSupportedScenario(t,i)});for(const t in k._4)o[t]&&o[t].forEach(t=>t.childDOMOrder=t.card_dom_order)}personalizedFeedElementChanged(){this.onFeedLayoutElementsChanged&&!this.personalizedFeedElementMutationObserver&&this.personalizedFeedElement&&this.personalizedFeedElement.shadowRoot&&(this.personalizedFeedElementMutationObserver=new MutationObserver(()=>{if(this.personalizedFeedElement&&this.personalizedFeedElement.shadowRoot){const t=Array.from(this.personalizedFeedElement.shadowRoot.children).filter(t=>"CS-FEED-LAYOUT"===t.tagName&&!t.isPlaceholder);this.onFeedLayoutElementsChanged(t)}}),this.personalizedFeedElementMutationObserver.observe(this.personalizedFeedElement.shadowRoot,{childList:!0}))}updateTemplateForNotSupportedScenario(t,e){if(!(t&&"native-ad-card"===t.childTemplateType))return;if(t.videoProps||t.useProng2AmplifyCardTemplate)if(t.videoProps){const i=t.childTemplateType+"-v1";e[i]||(e[i]=e["native-ad-card-video"]),t.childTemplateType=i}else if(t.useProng2AmplifyCardTemplate){const i=t.childTemplateType+"-v2";e[i]||(e[i]=e["native-ad-card-boost"]),t.childTemplateType=i}}getResponsiveCardTemplates(t){if("widgetsWaterfall"===t)return this.cardTemplateMap;const e=this.configProvider.getCardTemplatesMap();e["infopane-card"]=h.getViewTemplate({id:"infopane",childTemplateType:"infopane-card"},this.configProvider),e["native-ad-card-video"]||(e["native-ad-card-video"]=(0,F.A)(e["native-ad-card"]));return e["native-ad-card"]=h.getViewTemplate({id:"nativead",childTemplateType:"native-ad-card"},this.configProvider),e}}(0,a.Cg)([d.V],L.prototype,"configProvider",void 0),(0,a.Cg)([s.sH],L.prototype,"feedLayouts",void 0),(0,a.Cg)([s.sH],L.prototype,"responsiveFeedLayouts",void 0),(0,a.Cg)([s.sH],L.prototype,"enableWFMonitor",void 0),(0,a.Cg)([s.sH],L.prototype,"enableFirstSectionFlush",void 0),(0,a.Cg)([s.sH],L.prototype,"cardTemplateMap",void 0),(0,a.Cg)([s.sH],L.prototype,"childTemplateSizeMap",void 0),(0,a.Cg)([s.sH],L.prototype,"layout",void 0),(0,a.Cg)([s.sH],L.prototype,"personalizedFeedElement",void 0),(0,a.Cg)([s.sH],L.prototype,"sentinelHeight",void 0),(0,a.Cg)([s.sH],L.prototype,"placeholderFeedLayout",void 0),(0,a.Cg)([s.sH],L.prototype,"responsiveWidth",void 0),(0,a.Cg)([s.sH],L.prototype,"seenContentHandler",void 0),(0,a.Cg)([(0,u.CF)({attribute:"content-seen-removal-mode",converter:u.R$})],L.prototype,"contentSeenRemovalMode",void 0);const S=f.A``;var T=i(60402),D=i(1302);(0,i(50193).C)(D.Be);const N=c.qy`<cs-personalized-feed ${(0,T.K)("personalizedFeedElement")} :layout="${t=>t.layout}" :feedLayouts=${t=>t.feedLayouts} :placeholderFeedLayout=${t=>t.placeholderFeedLayout} :responsiveWidth="${t=>t.responsiveWidth}"><slot name="sentinel" slot="abovePlaceholder"></slot></cs-personalized-feed>`,M=c.qy` ${(0,_.ux)(t=>t.responsiveFeedLayouts,c.qy`<cs-responsive-feed-layout :childTemplateMap="${(t,e)=>e.parent.getResponsiveCardTemplates(t.id)}" :childTemplateSizeMap="${(t,e)=>{var i;return null===(i=e.parent)||void 0===i?void 0:i.childTemplateSizeMap}}" :wideCard="${t=>t.wideCard}" :wideCardSize="${t=>t.wideCardSize}" :onFeedElementsChanged="${(t,e)=>e.parent.onFeedLayoutElementsChanged}" :enableMonitor="${(t,e)=>e.parent.enableWFMonitor}" :onBlankMonitorResult="${t=>t.onBlankMonitorResult}" :sentinelHeight="${(t,e)=>e.parent.sentinelHeight}" :sentinelRenderedElements="${(t,e)=>e.parent.sentinelRenderedElements}" :sectionTrackerTag="${t=>t.sectionTrackerTag}" :renderingMode="${t=>t.rowRendering?"row":"column"}" :responsiveWidth="${(t,e)=>e.parent.responsiveWidth}" :columns="${t=>t.columns}" :customRowSection="${t=>t.customRowSection}" :id="${t=>t.id}" :seenContentHandler="${(t,e)=>e.parent.seenContentHandler}" content-seen-removal-mode=${(t,e)=>e.parent.contentSeenRemovalMode}>${void 0}</cs-responsive-feed-layout>`,{positioning:!0})}
`,E=c.qy` ${(0,b.z)(t=>{var e;return!t.responsiveFeedLayouts&&(null===(e=t.feedLayouts)||void 0===e?void 0:e.length)},N)} ${(0,b.z)(t=>{var e;return null===(e=t.responsiveFeedLayouts)||void 0===e?void 0:e.length},M)}
`,O=L.compose({name:"cs-super-container",styles:S,template:E}),P=()=>{z.define(o.G.registry),O.define(o.G.registry),r.m.define(o.G.registry)}},50866(t,e,i){"use strict";i.d(e,{L9(){return a},NZ(){return r},qJ(){return o}});const o={_1x_1y:"_1x_1y",_1x_2y:"_1x_2y",_2x_2y:"_2x_2y",_2x_1y:"_2x_1y"},r={DarkPlum:"dark-plum",DarkDesert:"dark-desert",DarkDawn:"dark-dawn",DarkSea:"dark-sea",DarkOrange:"dark-orange",DarkTropic:"dark-tropic",DarkMerlot:"dark-merlot",DarkPurple:"dark-purple",DarkGreen:"dark-green"},a={LightBlue:"light-blue",LightPurple:"light-purple",LightSky:"light-sky",LightPink:"light-pink",LightYellow:"light-yellow",LightBluebird:"light-bluebird",LightOrange:"light-orange",LightAqua:"light-aqua",LightGreen:"light-green"}},59836(t,e,i){"use strict";i.d(e,{m(){return v}});var o=i(65614),r=i(92011);class a extends r.L{}var n=i(7896),s=i(61138),d=i(48751),l=i(74838),c=i(74849),g=i(64187),p=i(22131),h=i(50882);const u=c.A`
    ${(0,g.V)("inline-flex")} :host {
        box-sizing: border-box;
        font-family: ${n.O};
        font-size: ${s.k};
        font-weight: 400;
        line-height: ${s.F};
        align-items: center;
        color: ${d.l};
        min-height: 16px;
    }

    .content {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        align-self: baseline;
    }

    ::slotted([slot="image"]) {
        display: flex;
        margin-inline-end: calc(${l.vR} * 2px);
    }
`.withBehaviors((0,p.mr)(c.A`
            :host,
            .content {
                color: ${h.A.ButtonText};
                fill: currentcolor;
            }
        `)),x=i(96950).qy`
    <slot name="image"></slot>
    <span part="content" class="content">
        <slot></slot>
    </span>
`,v=a.compose({name:`${o.G.prefix}-attribution`,styles:u,template:x})},64183(t,e,i){"use strict";i.d(e,{o(){return n},t(){return a}});var o=i(68009),r=i(49399);function a(t,e,i,r,a,n,s){const d=t.closestIndexOf(e);return null==s&&(s=(0,o.F)(e)),{rest:t.get(d+s*i),hover:t.get(d+s*r),active:t.get(d+s*a),focus:t.get(d+s*n)}}function n(t,e,i,o,n,s,d=void 0,l,c,g,p,h=void 0){return(0,r.H)(e)?a(t,e,l,c,g,p,h):a(t,e,i,o,n,s,d)}},73893(t,e,i){"use strict";i.d(e,{m(){return s}});var o=i(65614),r=i(71008),a=i(42792);const n=i(96950).qy`
    <slot></slot>
`,s=r.h.compose({name:`${o.G.prefix}-card`,styles:a.R7,template:n})},80090(t,e,i){"use strict";i.d(e,{m(){return T}});var o=i(65614),r=i(11310),a=i(7896),n=i(48751),s=i(41123),d=i(57416),l=i(62047),c=i(14996),g=i(89580),p=i(99657),h=i(86856),u=i(74849),x=i(73477),v=i(4126),f=i(22131),m=i(50882);const y=u.A`
    .text,
    .media-info,
    .gradient {
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
    }

    .action-tray {
        transition-duration: var(--video-transition-end-duration);
        transition-property: background-color;
    }

    ::slotted([slot="media-overlay"]) {
        color: #ffffff;
        fill: #ffffff;
        height: 40px;
        min-width: 40px;
        display: grid;
        padding: 0px;
        grid-auto-flow: column;
        grid-gap: 8px;
        box-sizing: border-box;
        align-items: center;
        justify-content: center;
        border-radius: 20px;
        border: 1px solid transparent;
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
        background: linear-gradient(
                    135deg,
                    rgba(0, 0, 0, 0.5) 0%,
                    rgba(0, 0, 0, 0.7) 100%
                )
                padding-box,
            linear-gradient(
                    180deg,
                    rgba(255, 255, 255, 0.4) 0%,
                    rgba(255, 255, 255, 0.2) 100%
                )
                border-box;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 22px;
        min-width: 22px;
        padding: 0 6px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 38px;
        min-width: 38px;
        padding: 0 6px;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([animate-video]) .media-info,
    :host([immersive-card][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_1x_2y"][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_2x_2y"][animate-video]) ::slotted([slot="media-overlay"]) {
        transition-delay: var(--video-transition-delay);
        transition-duration: var(--video-transition-start-duration);
        opacity: 0;
    }
`,b=u.A`
    .preload {
        transition: none !important;
    }

    :host {
        --content-padding: 16px;
        --no-image-action-tray-padding: 20px;
        --action-tray-padding: 10px;
        width: 100%;
        height: 100%;
        font-family: ${a.O};
        --video-transition-delay: 1s;
        --video-transition-start-duration: 1s;
        --video-transition-end-duration: 1s;
    }

    :host([subscibed])::after {
        position: absolute;
        content: "";
        bottom: 0;
        left: 0;
        right: 0;
        height: 4px;
        width: 100%;
        background: linear-gradient(90deg, #ffa03d 0%, #ffdb00 100%);
    }

    :host([size="_1x_2y"]),
    :host([size="_2x_2y"]) {
        --content-card-heading-font-size: 18px;
        --content-card-heading-line-height: 24px;
    }

    :host .content {
        display: grid;
        grid-template-columns: 1fr minmax(auto, 84px);
        grid-template-rows: 1fr auto;
        row-gap: 14px var(--content-padding) var(--content-padding) var(--content-padding);
        column-gap: 12px;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        color: ${n.l};
        position: relative;
    }

    :host([size="_1x_1y"]) .content {
        row-gap: 0px;
        padding: 14px var(--content-padding) 10px var(--content-padding);
    }

    :host([size="_2x_1y"]) .content {
        row-gap: 0px;
        padding: var(--content-padding) var(--content-padding) 14px var(--content-padding);
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        grid-template-columns: 1fr;
        column-gap: 0;
    }

    :host([size="_1x_2y"]) .content {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]) .content.no-image {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .content:not(.no-image) .text {
        padding-top: 12px;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .content:not(.no-image) .text {
        padding-top: 0;
    }

    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        align-items: end;
        grid-template-rows: 1fr auto auto;
    }

    :host([size="_2x_2y"]) .no-image {
        align-items: unset;
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content {
        padding: 0;
        row-gap: 0;
    }

    :host([size="_1x_1y"]) .content.no-image,
    :host([size="_2x_1y"]) .content.no-image,
    :host([size="_1x_2y"]) .content.no-image,
    :host([size="_2x_2y"]) .content.no-image {
        grid-template-rows: 1fr auto;
    }

    ::slotted([slot="abstract"]) {
        display: none;
        overflow: hidden;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: var(--abstract-max-lines, 7);
        margin-top: var(--abstract-margin-top, 5px);
    }

    .no-image ::slotted([slot="abstract"]) {
        display: -webkit-box;
        -webkit-line-clamp: var(--abstract-max-lines, 3);
    }

    :host([size="_1x_1y"]) .no-image ::slotted([slot="abstract"]),
    :host([size="_2x_1y"]) .no-image ::slotted([slot="abstract"]) {
        --abstract-max-lines: 1;
    }

    .text {
        grid-area: 1 / 1;
        padding: var(--content-padding) var(--content-padding) 0 var(--content-padding);
        overflow: hidden;
        font-size: ${s.K};
        line-height: ${s.Z};
    }

    :host([size="_1x_1y"]) .text,
    :host([size="_2x_1y"]) .text {
        padding: 0;
    }

    :host([size="_1x_1y"]) .no-image .text,
    :host([size="_2x_1y"]) .no-image .text {
        grid-column: 1 / span 2;
    }

    :host([size="_1x_2y"]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        padding: 14px var(--content-padding) 0 var(--content-padding);
        grid-row: 1;
    }

    :host([size="_2x_2y"]) .text,
    :host([size="_1x_2y"]) .text {
        grid-row: 2;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .text {
        background-color: var(--image-gradient-overlay-end-color);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray,
    :host([size="_1x_2y"]:not([immersive-card])) .action-tray,
    :host .no-image .action-tray {
        background-color: transparent;
    }

    :host([immersive-card]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        background: unset;
    }

    :host([size="_1x_2y"]) .action-tray,
    :host([size="_2x_2y"]) .action-tray {
        grid-row: 3;
        padding: 4px var(--content-padding) var(--action-tray-padding)
            var(--content-padding);
    }

    :host([immersive-card]) .action-tray,
    :host([size="_2x_2y"]) .content:not(.no-image) .action-tray {
        padding: var(--action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
    }

    .action-tray {
        grid-row: 2;
        grid-column: span 2;
        display: flex;
        position: relative;
        background-color: var(--image-gradient-overlay-end-color);
        padding: var(--action-tray-padding) var(--content-padding) var(--content-padding)
            var(--content-padding);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray {
        padding: 0;
    }

    :host([size="_2x_1y"]) .content:not(.no-image) .action-tray {
        grid-area: 2 / 1 / auto / auto;
    }

    :host([size="_1x_1y"]) .no-image .action-tray {
        padding: 4px 0 0 0;
    }

    :host([size="_1x_2y"]) .no-image .action-tray,
    :host([size="_2x_2y"]) .no-image .action-tray {
        padding: var(--no-image-action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
        background: none;
        grid-row: 2;
        grid-column: 1;
    }

    .media-info {
        display: grid;
        grid-auto-flow: column;
        width: fit-content;
        grid-gap: 4px;
        fill: white;
        color: white;
        margin-bottom: 8px;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .media-info {
        grid-row: 1;
        grid-column: 1;
        align-self: flex-end;
        margin-bottom: 6px;
        margin-inline-start: 6px;
    }

    :host([size="_2x_1y"]:not([immersive-card])) .media-info {
        grid-area: 1 / 2 / span2 / auto;
        align-self: flex-end;
        margin-bottom: 8px;
        margin-inline-start: 6px;
    }

    ::slotted([slot="media-info"]) {
        display: grid;
        align-items: center;
        grid-auto-flow: column;
        grid-gap: 3px;
        background-color: var(--image-gradient-overlay-end-color);
        border-radius: calc(${d.Pb} * 1px);
        padding: 2px 6px;
        font-size: ${l.t};
        line-height: ${l.e};
    }

    ::slotted([slot="hide-story"]) {
        box-sizing: border-box;
        align-items: center;
        background-color: #ffffff;
        border-radius: 100%;
        border: 1px solid #e5e5e5;
        color: rgba(0, 0, 0 1);
        cursor: pointer;
        display: flex;
        fill: currentcolor;
        font-family: ${a.O};
        font-size: ${s.K};
        height: 28px;
        justify-content: center;
        line-height: ${s.Z};
        margin-inline-start: 4px;
        min-width: 28px;
        outline: none;
        padding: 0;
        position: relative;
    }

    ::slotted([slot="hide-story"]:hover) {
        background-color: #f2f2f2;
    }

    ::slotted([slot="hide-story"]:active) {
        background-color: #f7f7f7;
    }

    :host .hide-story-wrapper {
        position: absolute;
        display: flex;
        flex-direction: row;
        top: var(--content-padding);
    }

    :host .hide-story {
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.1s linear;
    }

    :host(:hover) .hide-story,
    :host(:focus-within) .hide-story {
        opacity: 1;
    }

    :host ::slotted([slot="hide-story"]:${x.N}) {
        border-color: ${c.WN};
    }

    ::slotted([slot="media"]) {
        grid-column: 1;
        object-fit: cover;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media"]) {
        height: 84px;
        width: 84px;
        grid-row: 1;
        grid-column: 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media"]) {
        height: 114px;
        width: 216px;
        grid-area: 1 / 2 / span2 / 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_1x_2y"]) ::slotted([slot="media"]) {
        grid-row: 1;
        grid-column: 1;
        height: 157px;
        width: 100%;
        display: flex;
    }

    :host([size="_2x_2y"]) ::slotted([slot="media"]),
    :host([immersive-card]) ::slotted([slot="media"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
    }

    ::slotted([slot="attribution"]) {
        display: flex;
        grid-column: 1;
        grid-row: 1;
        margin-bottom: 8px;
    }

    :host([size="_1x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]),
    :host([size="_2x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]) {
        grid-column-end: 1;
    }

    .heading {
        color: ${n.l};
        fill: currentcolor;
        display: -webkit-box;
        outline: 0;
        overflow: hidden;
        text-decoration: none;
        -webkit-line-clamp: var(--heading-max-lines, 3);
        -webkit-box-orient: vertical;
        font-weight: 600;
        font-size: var(--content-card-heading-font-size, ${g.Y});
        line-height: var(--content-card-heading-line-height, ${g.v});
    }

    .heading:focus-visible {
        text-decoration: underline;
    }

    .heading:after {
        bottom: 0;
        content: "";
        height: 100%;
        left: 0;
        position: absolute;
        right: 0;
        width: 100%;
        z-index: ${p.I};
    }

    :host([size="_2x_2y"][immersive-card]) .heading {
        --heading-max-lines: 2;
    }

    .media-overlay {
        position: absolute;
        display: flex;
        align-items: center;
        justify-content: center;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        pointer-events: none;
    }

    :host([size="_1x_1y"]) .media-overlay {
        grid-column: 2;
        grid-row: 1;
        height: 84px;
        width: 84px;
    }

    :host([size="_1x_2y"]) .media-overlay {
        grid-row-start: 1;
        grid-row-end: 1;
    }

    :host([size="_2x_2y"]) .media-overlay,
    :host([immersive-card]) .media-overlay {
        top: 100px;
        align-items: unset;
    }

    :host([size="_1x_2y"]) .no-image .heading,
    :host([size="_2x_2y"]) .no-image .heading {
        --heading-max-lines: 9;
    }

    :host([size="_2x_1y"]) .media-overlay {
        grid-area: 1 / 2 / span2 / 2;
        height: 114px;
        width: 216px;
    }

    ::slotted(p) {
        font-weight: 400;
        font-size: var(--abstract-font-size, 14px);
        line-height: var(--abstract-line-height, 20px);
        font-kerning: auto;
        margin: 8px 0px 0px;
    }

    ::slotted([slot="footer-start"]),
    ::slotted([slot="footer-end"]),
    ::slotted([slot="hide-story"]) {
        z-index: ${p.D};
    }

    .footer-end,
    .footer-start {
        display: flex;
        align-items: center;
    }

    .footer-end {
        margin-inline-start: auto;
    }

    .gradient {
        background: linear-gradient(
            180deg,
            var(--image-gradient-overlay-start-color) 0%,
            var(--image-gradient-overlay-end-color) 100%
        );
        grid-row: 1;
        height: 100%;
        display: none;
    }

    :host([size="_2x_2y"]) .gradient,
    :host([immersive-card]) .gradient {
        display: block;
        height: 80px;
    }

    :host([size="_2x_2y"]) .no-image .gradient,
    .no-image .gradient {
        display: none;
    }

    :host([size="_2x_1y"]) .content {
        column-gap: 24px;
    }
`.withBehaviors(new v.o("mediaType","video",y),new h.t(u.A`
            :host .hide-story-wrapper {
                right: var(--content-padding);
            }
        `,u.A`
            :host .hide-story-wrapper {
                left: var(--content-padding);
            }
        `),(0,f.mr)(u.A`
            :host {
                forced-color-adjust: auto;
            }
            .gradient {
                display: none;
            }
            :host([size="_1x_2y"]) .content,
            :host([size="_1x_1y"]) .content,
            :host([size="_2x_1y"]) .content {
                background: ${m.A.ButtonFace};
            }
            :host([size="_1x_2y"]) .text,
            :host([size="_1x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .text,
            :host([size="_2x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .content,
            :host([immersive-card]) .content {
                background: transparent;
            }
            ::slotted([slot="hide-story"]) {
                color: ${m.A.ButtonText};
                fill: currentcolor;
            }
        `));var _=i(96950),$=i(82774),w=i(416),z=i(10108),k=i(69259),F=i(1413);const C=_.qy`
    <slot name="media" ${(0,$.e)("mediaSlot")}></slot>
`,L=(S={mediaTemplate:C},_.qy`
        <template
            role="article"
            ${(0,w.Y)({property:"childElements",filter:(0,z.Y)()})}
        >
            <div class="content${t=>t.mediaType?"":" no-image"}" part="content">
                ${S.mediaTemplate}
                ${(0,k.z)(t=>t&&(0,F.P)("media-info",t.childElements)&&!(t.immersiveCard||"_2x_2y"===t.size),(0,F.y)({slotName:"media-info"}))}
                <div class="gradient" part="gradient"></div>
                ${(0,F.y)({slotName:"media-overlay",slottedDefault:S.mediaOverlay})}
                <div class="text" part="text">
                    ${(0,k.z)(t=>t&&(0,F.P)("media-info",t.childElements)&&(t.immersiveCard||"_2x_2y"===t.size),(0,F.y)({slotName:"media-info"}))}
                    <slot name="attribution"></slot>
                    <a
                        id="heading"
                        class="heading"
                        part="heading"
                        href="${t=>t.href?t.href:void 0}"
                        target="${t=>t.target?t.target:void 0}"
                        @click=${(t,e)=>t.handleContentCardLinkClick(e.event)}
                        data-t="${t=>t.anchorTelemetryTag}"
                    >
                        <span role="heading" aria-level="${t=>t.headingLevel}">
                            <slot></slot>
                        </span>
                    </a>
                    ${(0,F.y)({slotName:"abstract"})}
                </div>
                <div
                    class="action-tray ${t=>t.loaded?"":"preload"}"
                    part="action-tray"
                >
                    ${(0,F.y)({slotName:"footer-start",slottedDefault:S.footerStart})}
                    ${(0,F.y)({slotName:"footer-end",slottedDefault:S.footerEnd})}
                </div>
                <div class="hide-story-wrapper" part="hide-story-wrapper">
                    ${(0,F.y)({slotName:"hide-story",slottedDefault:S.hideStory})}
                </div>
            </div>
        </template>
    `);var S;const T=r.W.compose({name:`${o.G.prefix}-content-card`,styles:b,template:L})},84056(t,e,i){"use strict";i.d(e,{J(){return s}});var o=i(59836),r=i(73893),a=i(80090),n=i(65614);function s(){o.m.define(n.G.registry),r.m.define(n.G.registry),a.m.define(n.G.registry)}},87119(t,e,i){"use strict";i.d(e,{V(){return o}});const o=i(64332).DI.createContext()},93518(t,e,i){"use strict";i.d(e,{X(){return h}});var o=i(56911),r=i(97004),a=i(64183),n=i(95239),s=i(356),d=i(31023),l=i(37302),c=i(96193),g=i(38493),p=i(50866);class h extends c.z{constructor(){super(...arguments),this.size=p.qJ._1x_2y}cardFillColorChanged(t,e){this.isDarkCardGradient()?s.l.setValueFor(this,r.y.DarkMode):this.isLightCardGradient()?s.l.setValueFor(this,r.y.LightMode):s.l.deleteValueFor(this)}isDarkCardGradient(){return Object.values(p.NZ).includes(this.cardFillColor)}isLightCardGradient(){return Object.values(p.L9).includes(this.cardFillColor)}isNamedGradientFillColor(){return this.isLightCardGradient()||this.isDarkCardGradient()}connectedCallback(){super.connectedCallback(),l.jO.setValueFor(this,{evaluate(t,e){return(0,a.o)(t(d.r),e||t(n.p),-1,1,0,0,void 0,2,3,1,2,void 0)}})}}(0,o.Cg)([(0,g.CF)({attribute:"card-fill-color"}),(0,o.Sn)("design:type",Object)],h.prototype,"cardFillColor",void 0),(0,o.Cg)([g.CF,(0,o.Sn)("design:type",String)],h.prototype,"size",void 0)},96193(t,e,i){"use strict";i.d(e,{z(){return r}});var o=i(92011);class r extends o.L{}},96787(t,e,i){"use strict";function o(t){return!t.mapRawData}i.d(e,{Yd(){return o},wc(){return r}});const r=t=>({defaultLayout:t?[t]:[],C6:[],C5:[],C4:[],C3:[],C2:[],C1:[]})},99657(t,e,i){"use strict";i.d(e,{D(){return n},I(){return a}});var o=i(45755);const{create:r}=o.G,a=r("sloppy-click-z-index",1),n=r("click-z-index",1)}}]);