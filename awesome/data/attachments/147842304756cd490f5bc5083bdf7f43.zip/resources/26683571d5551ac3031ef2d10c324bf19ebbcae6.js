// © Microsoft Corporation. All rights reserved.
import { HomePageEntryPointHomePageErrorPage, logException, logger, markRefreshEnd } from "@msnews/diagnostics";
import { Telemetry, TrackingSystemType, initTelemetry } from "@msnews/telemetry-contracts";
import { RequestContext, appEnvironment, canUseDigitalId, getAppEnvironment, getContextData, headData, init, localStorageExists, resolver, sessionStorageExists, trackWebWorkerErrors } from "@msnews/core";
import { TelemetryLibrary, getTelemetryTrackingSystemConfig } from "@msnews/telemetry-core";
import { MidlevelTelemetry } from "./MidlevelTelemetry";
import { getFeed } from "./midlevel";
import { initDigitalIdSubscription } from "@msnews/auth";
import { template } from "./template";
(async () => {
    try {
        const requestContext = new RequestContext();
        const locationHref = getContextData(requestContext.data.locationHref, "locationHref");
        // Initialize Telemetry
        const telemetryConfig = getTelemetryTrackingSystemConfig(headData.ClientSettings.domain, appEnvironment.Environment, appEnvironment.IsChinaCompliance, false);
        const anonCookieOption = canUseDigitalId() ? undefined : { anonCookieName: appEnvironment.AuthCookieName };
        logger.log(`digital-id: hasAnonCookieOption=${!!anonCookieOption}, anonCookieName=${appEnvironment.AuthCookieName}`);
        initDigitalIdSubscription();
        initTelemetry(new TelemetryLibrary({
            ...anonCookieOption,
            trackingSystems: telemetryConfig,
            autoCaptureContentView: false,
            enableTraceGenerator: true,
            telemetryInitOptions: appEnvironment.TelemetryInitOptions
        }));
        const isStatic = !!headData.ClientSettings && headData.ClientSettings.static_page === "true";
        Telemetry.initPage({ page: { url: locationHref, isStatic } }, appEnvironment.ActivityIdLowerCaseNoHypens, appEnvironment.BuildVersion, appEnvironment.FrontDoorMuid);
        // Remove any previous window onerror listeners defined from other inline script
        window.onerror = null;
        // set webworkerspresent flag as false as DL page code is executed only by a single thread and does not make use of web workers
        init(false);
        // Add listener for web worker errors
        trackWebWorkerErrors(Telemetry.sendAppErrorEvent.bind(Telemetry));
        // Send sendAppErrorEvent as callback to resolver since Core cannot depend on Telemetry repo.
        resolver.initialize(Telemetry.sendAppErrorEvent.bind(Telemetry));
        const telemetryProperties = MidlevelTelemetry.getTelemetryProperties(window, locationHref);
        if (!telemetryProperties.enable) {
            Telemetry.disableTrackingSystem(TrackingSystemType.All);
        }
        let isMobile = false;
        if (headData && headData.ClientSettings) {
            const clientSettings = headData.ClientSettings;
            isMobile = ((clientSettings.browser && clientSettings.browser.ismobile === "true") || clientSettings.deviceFormFactor === "phone" /* DeviceFormFactorType.Phone */);
        }
        const pageTelemetryContract = MidlevelTelemetry.getPageTelemetryContract(telemetryProperties, telemetryProperties.isStaticPage, isMobile, locationHref);
        // Set custom property to investigate MUID mismatch\Auth\Market issues.
        Telemetry.addOrUpdateCustomProperty("prg-refs", `{ refA: ${appEnvironment.ActivityIdLowerCaseNoHypens}, refC: ${headData.ClientSettings.pageGenTime}}`);
        Telemetry.updatePageMetadata(pageTelemetryContract);
        // Initialize appEnvironment.TrackInfo
        appEnvironment.TrackInfo = {
            sitePage: {
                page_product: "prime",
                page_type: headData.ClientSettings.pagetype
            }
        };
        // Fire impr telemetry (too early for impr_update to be sent)
        const isAutoRefresh = location.search.includes("AR=");
        Telemetry.sendPageView({ page: { url: locationHref, isAutoRefresh: isAutoRefresh } }, true);
        const ttvr = markRefreshEnd("TTVR");
        const markers = {
            launchType: 1,
            TTVR: ttvr
        };
        Telemetry.sendLoadTimeEvent({ markers });
    }
    catch (e) {
        // Render an error page
        // TODO: need an error page from design
        logException(e, HomePageEntryPointHomePageErrorPage, "Error during app initialize.");
    }
    finally {
        // Check if localStorage and sessionStorage is not available
        localStorageExists(Telemetry.sendAppErrorEvent);
        sessionStorageExists(Telemetry.sendAppErrorEvent);
    }
})();
if ((headData.Locale.toLowerCase() === "he-il") || (headData.Locale.toLowerCase() === "ar-ae") || (headData.Locale.toLowerCase() === "ar-sa") || (headData.Locale.toLowerCase() === "ar-eg")) {
    const fun = function convertToPlain(html) {
        const tempDivElement = document.getElementById("root");
        if (tempDivElement) {
            tempDivElement.innerHTML = html;
        }
        let styleClass = "*{padding: 0;margin: 0;box-sizing: border-box;}";
        styleClass = styleClass + "body{background: #f1f1f1; margin:auto; overflow-x:hidden;} a:hover {text-decoration:underline; }";
        styleClass = styleClass + "  a{text-decoration: none; cursor:pointer;} .Desktop{position: relative;} ";
        styleClass = styleClass + ".browserImg{width: 1369px;height: 55.32px;left: -1.5px;top: 0px;}";
        styleClass = styleClass + ".logo-search-container{margin:2rem; display: flex;}";
        styleClass = styleClass + ".logo{width: 60px;height: 26.01px;left: 213px;top: 90px;}";
        styleClass = styleClass + ".search-box{width: 616px; height: 32px; left: 375px; top: 32px; background: #FFFFFF; margin-right:6rem; padding: 12px; padding-top:8px; border:none; border-radius:0rem .3rem .3rem 0rem; box-shadow:  0px 0px 4px #767676}";
        styleClass = styleClass + ".search-box:hover, .search-box:focus-visible, .search-box:disabled, .search-box:active{outline: none;}";
        styleClass = styleClass + "input{writing-mode: horizontal-tb !important; text-rendering: auto; color: fieldtext; letter-spacing: normal; word-spacing: normal; line-height: normal; text-transform: none; text-indent: 0px; text-shadow: none; display: inline-block; text-align: start;}";
        styleClass = styleClass + `.ie-container{ width: 1260px;height: 293px;position: absolute;left:36px;background-image: url(${getAppEnvironment().StaticsUrl}/pr-3693935/IE11NTP/ie-image.png);}`;
        styleClass = styleClass + ".banner-container{ width: 100%;position: absolute;left:36px; text-align:center; top: 377px;}";
        styleClass = styleClass + ".text{ margin: 3rem; margin-bottom: 0rem; margin-left:0px; margin-right:50rem; }";
        styleClass = styleClass + ".p1{ width: 420px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 400; font-size: 36px; line-height: 42px; letter-spacing: -0.02em; color: #FFFFFF; margin-bottom: 1rem; }";
        styleClass = styleClass + ".p2{ width:auto; height:auto; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 400; font-size: 14px; line-height: 21px; letter-spacing: -0.02em; color: #FFFFFF; margin-bottom: 1rem; }";
        styleClass = styleClass + ".buttons{ padding: 0px; margin-right: 50rem; padding-top:20px}";
        styleClass = styleClass + ".button{ display: flex; flex-direction: row; align-items: center; padding: 9px 20px 10px; gap: 4px; width: 296px; height: 40px; background: #FFFFFF; border-radius: 4px; text-decoration: none; color:black; }";
        styleClass = styleClass + ".button-text{ width: 234px; height: auto; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 16px; line-height: 21px; color: #000000; flex: none; order: 0; flex-grow: 0; margin-right:2px;}";
        styleClass = styleClass + "@media screen and (min-width:540px){ .ie-mobile{ display: none; } }";
        styleClass = styleClass + "@media screen and (max-width:540px) { body{ width:375px; } .browserImg{ display: none; } .logo{ display: none; } .Desktop{ position: relative; width: 375px; height: 1400px;} .ie-container{ display: none; } .search-box { width: 200px; height: 32px; left: 375px; top: 32px; background: #FFFFFF;} .mobile-text{ display: flex; flex-direction: column; align-items: center; padding: 20px 0px; gap: 16px; position: absolute; width: 375px; height: 245px; left: 0px; top: 244px; background: #767676; } .mobile-p1{ width: 327px; height: 60px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 400; font-size: 24px; line-height: 30px; text-align: center; letter-spacing: -0.02em; color: #FFFFFF; } .mobile-p2{ width: 327px; height: 48px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 400; font-size: 16px; line-height: 24px; text-align: center; letter-spacing: -0.02em; color: #FFFFFF;} .mobile-buttons{ width: 296px; height: 40px; padding-top:25px;} .mobile-button{ display: flex; flex-direction: row; align-items: center; padding: 9px 20px 10px; gap: 4px; width: 296px; height: 40px; background: #FFFFFF; border-radius: 4px; text-decoration: none; } .mobile-button-text{ width: 234px; height: auto; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 16px; line-height: 21px; color: #000000; margin-right:2px;} }";
        styleClass = styleClass + "@media screen and (max-width:540px){ .frame{ display: none; } .mobile-ads{ display: flex; flex-direction: column; align-items: flex-start; padding: 0px; gap: 20px; position: absolute; width: 300px; height: auto; left: 38px; top: 590px; } .ads-card, .feed-card{  position: relative; width: 300px; height: 304px; background: #FFFFFF; box-shadow: 0px 1.6px 3.6px rgba(0, 0, 0, 0.13), 0px 0px 2.9px rgba(0, 0, 0, 0.11); flex: none; order: 1; flex-grow: 0; } .ads-card-img{ width: 300px; height: 157px; left: 0px; top: 0px; background: #FFFFFF; } .content{ display: flex; flex-direction: column; justify-content: flex-end; align-items: center; padding: 0px; gap: 20px; width: 300px; left: 0px; top: 157px;margin-top:3%; overflow:hidden;} .title{ display: flex; flex-direction: column; justify-content: flex-end; align-items: flex-start; padding: 0px; gap: 5px; width: 268px; height: 75px; } .attribution-img{ height: 96px; } .title-link{ width: 268px; height: 75px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 18px; line-height: 24px; font-feature-settings: 'fina' on, 'init' on; color: #1A1A1A; } .banner-container{ left: 0px; top: 515px; } } ";
        styleClass = styleClass + "@media screen and (max-width:540px){.logo-search-container{margin-right:-10% !important;}}";
        styleClass = styleClass + "@media screen and (min-width:541px) { .overflow{width: 1340px;} .mobile-ads{ display: none; } .frame{ display: flex; flex-direction: column; align-items: flex-start; padding: 0px; position: absolute; width: 1260px; height: auto; left: 53px; top: 490px; } .ads{ display: flex; flex-direction: row; align-items: flex-start; padding: 0px; width: 1260px; height: 304px; } .Infopane{ width: 620px; height: 304px; } .content-card{ position: relative; display: flex; flex-direction: column; justify-content: flex-end; align-items: center; padding: 0px; isolation: isolate; left: 0%; right: 0%; top: 0%; bottom: 0%; border: 1px solid rgba(0, 0, 0, 0.0578); filter: drop-shadow(0px 2px 4px rgba(0, 0, 0, 0.04)); } .infopane-image{ left: 0px; right: 0px; top: 0px; bottom: 0px; flex: none; order: 0; flex-grow: 0; z-index: 0; } .attribute{ position: absolute; top:225px; left:0; right:0; width: 620px; height: 78px; background: rgba(0, 0, 0, 0.27); padding:10px; } .Infopane-icon{ flex-direction: row; align-items: center; padding: 0px; gap: 4px; width: 15px; height:auto; flex: none; order: 0; flex-grow: 0; } .Infopane-title{ width: 588px; height: 29px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 18px; line-height: 24px; font-feature-settings: 'fina' on, 'init' on; color: #FFFFFF; flex: none; order: 1; align-self: stretch; flex-grow: 0; } .ads-card, .feed-card { position: relative; width: 300px; height: 304px; background: #FFFFFF; box-shadow: 0px 1.6px 3.6px rgba(0, 0, 0, 0.13), 0px 0px 2.9px rgba(0, 0, 0, 0.11); } .ads-card-img{ width: 300px; height: 157px; left: 0px; top: 0px; background: #FFFFFF; } .content{ display: flex; flex-direction: column; justify-content: flex-end; align-items: center; padding: 0px; gap: 20px; width: 300px; left: 0px; top: 157px;margin-top:3%; overflow:hidden;} .title{ display: flex; flex-direction: column; justify-content: flex-end; align-items: flex-start; padding: 0px; gap: 5px; width: 268px; height: 75px; } .attribution-img{ height: 96px; } .title-link{ width: 268px; height: 75px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 18px; font-feature-settings: 'fina' on, 'init' on; color: #1A1A1A; } .logo-search-container{margin-right:15%;}  }";
        styleClass = styleClass + "@media screen and (min-width:1440px) { body{ width:1335px; margin-left: auto; margin-right: auto; } }";
        styleClass = styleClass + "@media screen and (max-width:1024px) and (min-width:1024px) { body{ margin-left:-53px; } }";
        const styleClassadSlag = styleClass + ".ad-slug{ position: absolute; display:flex; flex-direction: row; padding: 10px; padding-left:12px; width:300px; height: 30px; bottom:2%; } .ad-tag{ width: 22px; height: 18px; border: 0.2px solid #292929; border-radius: 2px; text-align: center; background:#1e6525; } .ad-link{ height: 16px; margin-right:0.5rem; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif;  color: rgba(43,43,43,.7); font-size: 13px; } .ad-link-text{ text-decoration: none; color:black; }";
        const styleClassSearchBoxicon = styleClassadSlag + ".search-icon{ height: 33px;box-shadow: 0px 0px 4px #767676; border-radius: 5px 0px 0px 5px; clip-path: inset(-5px -5px -5px 0px); background:#4d93d9;}";
        const styleClassIcontext = styleClassSearchBoxicon + ".Iconstyle{display:inline; font-family:Segoe UI,Segoe WP,Arial,Sans-Serif; color:rgba(43,43,43,.7); margin-left:.4rem;} #Infopane-image-Icon-1{padding-top:2px;}";
        const styleClassAdlink = styleClassIcontext + ".ad-tag-link{color:#fff; font-family:Segoe UI,Segoe WP,Arial,Sans-Serif; font-size:12px;}";
        const styleClassFooter = styleClassAdlink + ".river{font-family: 'Segoe UI Semibold','Segoe WP Semibold','Segoe WP','Segoe UI',Arial,Sans-Serif; margin-bottom: 20px; font-size:12px; color:#666; margin-right: 20px;} .river a{color: #666;}";
        const styleClassInfopaneKicker = styleClassFooter + "#Infopane-image-Icon-1{display:flex; flex-direction:column;} .Infopane-kicker{display: inline; margin-right: 8px; text-decoration: none;  position: absolute;  color: #a0a0a0; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; cursor:pointer; font-size:12px;}";
        const styleClassBannerOverlay = styleClassInfopaneKicker + ".overlay{width: 100%; height:100%; position: absolute;} .overlay-mob{width: 100%; height:90%; position: absolute;}";
        const head = document.head || document.getElementsByTagName("head")[0];
        const head1 = document.head || document.getElementsByTagName("head")[1];
        const style = document.createElement("style");
        style.appendChild(document.createTextNode(styleClassBannerOverlay));
        head.appendChild(style);
        const meta = document.createElement("meta");
        meta.name = "viewport";
        meta.content = "width=device-width, initial-scale=1";
        document.head.appendChild(meta);
        const my_awesome_script = document.createElement("script");
        my_awesome_script.setAttribute("src", "https://code.jquery.com/jquery-3.6.3.min.js");
        document.head.appendChild(my_awesome_script);
        setTimeout(() => {
            getFeed();
        }, 800);
        return tempDivElement;
    };
    const htmlStringnew = `<div class='overflow'> <div class='Desktop'> <div class='logo-search-container'> <div id='divLogo'><img class='logo' src='${getAppEnvironment().StaticsUrl}/pr-3693935/IE11NTP/logo.png' title='msn_logo' alt='msn_logo' /></div> <input type='search' name='q' id = 'txtSearch' autocomplete='off' class='search-box icon' /><button id='search-button-telemetry' type='submit' value='Go' style='cursor:pointer; border:none;'><img src='${getAppEnvironment().StaticsUrl}/pr-3693935/IE11NTP/Icon.png' class='search-icon' /></button> </div> <div class='ie-mobile'> <a href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' id='ie-mobile-telemetry1'> <img src='${getAppEnvironment().StaticsUrl}/pr-3693935/IE11NTP/mobile-image.png' class='mobileImage'> </a> <div class='mobile-text'> <a href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' id='ie-mobile-telemetry2' class='overlay-mob'></a> <p class='mobile-p1'> <span id='mobbannerTextHeadline'></span></p> <p class='mobile-p2'> <span id='mobbannerText'></span></p> <div class='mobile-buttons'> <a href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' class='mobile-button'> <p class='mobile-button-text'><span id='mobbuttontext'></span></p> <img src='${getAppEnvironment().StaticsUrl}/pr-3693935/IE11NTP/desktop-shape-2-rtl.png'> </a> </div> </div> </div> <div class='ie-container'> <a id='banner-telemetry' href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' class='overlay'></a> <div class='message'> <div class='text'> <p class='p1' style='margin-bottom: 1rem;'><span id='bannerTextHeadline'></span></p> <p class='p2' style='margin-bottom: 1rem;'><span id='bannerText'></span></p> </div> <div class='buttons'> <a href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' class='button'> <p class='button-text'><span id='bannerButtonText'></span></p> <img src='${getAppEnvironment().StaticsUrl}/pr-3693935/IE11NTP/desktop-shape-2-rtl.png'> </a> </div> </div> </div> <div class='banner-container'> <div id='banner1' class='banner-ad'> </div> </div> <div class='frame' id ='frame1'> <div class='ads ads-1 mobile-ads' style='margin-bottom:20px;'> <div class='Infopane' style='margin-right:20px;'> <div class='content-card' style='border:none;'> <div id='Infopane-image-1'></div> <div class='attribute'> <div id='Infopane-title-1'> </div> <div id='Infopane-image-Icon-1'></div> </div> </div> </div> <div class='feed-card' style='margin-right:20px;'> <div id='artical1'> </div> <div class='content'> <div class='title attribution-img'> <div id='artical1Icon'> </div> <a id='articalTitle' class='title-link'> </a> </div> </div> </div> <div class='ads-card' style='margin-right:20px;' id='divAD_0'></div> </div> <div class='ads ads-2' style='margin-bottom: 20px;'> <div class='ads-card' style='margin-right:20px; order:0;' id='divAD_1'> </div> <div class='feed-card' style='margin-right:20px; order:1;'> <div id='artical2'> </div> <div class='content'> <div class='title attribution-img'> <div id='artical2Icon'> </div> <a id='artica2Title' class='title-link'> </a> </div> </div> </div> <div class='ads-card ads-card-margin' style='margin-right:20px; order:2;' id='divAD_2'> </div> <div class='feed-card' style='order: 3; margin-right: 20px;'> <div id='artical3'></div> <div class='content'> <div class='title attribution-img'> <div id='artical3Icon'></div> <a id='artica3Title' class='title-link'> </a> </div> </div> </div> </div> <div class='ads ads-3' style='margin-bottom: 20px;'> <div class='feed-card' style='margin-right:20px; order:0;'> <div id='artical4'> </div> <div class='content'> <div class='title attribution-img'> <div id='artical4Icon'> </div> <a id='artica4Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-right: 20px; order: 1;'> <div id='artical5'></div> <div class='content'> <div class='title attribution-img'> <div id='artical5Icon'></div> <a id='artica5Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-right:20px; order:2;'> <div id='artical6'> </div> <div class='content'> <div class='title attribution-img'> <div id='artical6Icon'> </div> <a id='artica6Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-right: 20px; order: 3;'> <div id='artical7'></div> <div class='content'> <div class='title attribution-img'> <div id='artical7Icon'></div> <a id='artica7Title' class='title-link'> </a> </div> </div> </div> </div> <div class='ads ads-4' style='margin-bottom: 20px;'> <div class='feed-card' style='margin-right:20px; order:0;'> <div id='artical8'> </div> <div class='content'> <div class='title attribution-img'> <div id='artical8Icon'> </div> <a id='artica8Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-right:20px; order:1;'> <div id='artical9'> </div> <div class='content'> <div class='title attribution-img'> <div id='artical9Icon'> </div> <a id='artica9Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-right: 20px; order:2;'> <div id='artical10'></div> <div class='content'> <div class='title attribution-img'> <div id='artical10Icon'></div> <a id='artica10Title' class='title-link'> </a> </div> </div> </div> <div class='ads-card ads-card-margin' style='order: 3; margin-right: 20px;' id='divAD_3'></div> </div> <div id='spfooter' class='river' style='visibility: visible;'></div> </div> <div class='mobile-ads' id = 'mobileads'> <div class='feed-card' style='margin-bottom:20px;'> <div id='mobartical1'> </div> <div class='content'> <div class='title attribution-img'> <div id='mobartical1Icon'> </div> <a id='mobarticalTitle' class='title-link'> </a> </div> </div> </div> <div class='ads-card' style='margin-bottom:20px;' id='mobdivAD_0'></div> <div class='ads-card' style='margin-bottom:20px;' id='mobdivAD_1'> </div> <div class='feed-card' style='margin-bottom:20px;'> <div id='mobartical2'> </div> <div class='content'> <div class='title attribution-img'> <div id='mobartical2Icon'> </div> <a id='mobartica2Title' class='title-link'> </a> </div> </div> </div> <div class='ads-card' style='margin-bottom:20px;' id='mobdivAD_2'></div> <div class='feed-card' style='margin-bottom:20px;'> <div id='mobartical3'></div> <div class='content'> <div class='title attribution-img'> <div id='mobartical3Icon'></div> <a id='mobartica3Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-bottom: 20px;'> <div id='mobartical4'> </div> <div class='content'> <div class='title attribution-img'> <div id='mobartical4Icon'> </div> <a id='mobartica4Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-bottom: 20px;'> <div id='mobartical5'></div> <div class='content'> <div class='title attribution-img'> <div id='mobartical5Icon'></div> <a id='mobartica5Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-bottom: 20px;'> <div id='mobartical6'> </div> <div class='content'> <div class='title attribution-img'> <div id='mobartical6Icon'> </div> <a id='mobartica6Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-bottom: 20px;'> <div id='mobartical7'></div> <div class='content'> <div class='title attribution-img'> <div id='mobartical7Icon'></div> <a id='mobartica7Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-bottom: 20px;'> <div id='mobartical8'></div> <div class='content'> <div class='title attribution-img'> <div id='mobartical8Icon'></div> <a id='mobartica8Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-bottom:20px;'> <div id='mobartical9'></div> <div class='content'> <div class='title attribution-img'> <div id='mobartical9Icon'></div> <a id='mobartica9Title' class='title-link'> </a> </div> </div> </div> <div class='feed-card' style='margin-bottom:20px;'> <div id='mobartical10'></div> <div class='content'> <div class='title attribution-img'> <div id='mobartical10Icon'></div> <a id='mobartica10Title' class='title-link'> </a> </div> </div> </div> <div class='ads-card' style='margin-bottom:20px;' id='mobdivAD_3'></div> <div id='mobspfooter' class='river' style='visibility: visible; position:relative; order:1;'> </div> </div> </div> </div>`;
    fun(htmlStringnew);
}
else {
    const fun = function convertToPlain(html) {
        const tempDivElement = document.getElementById("root");
        if (tempDivElement) {
            tempDivElement.innerHTML = html;
        }
        let styleClass = "*{padding: 0;margin: 0;box-sizing: border-box;}";
        styleClass = styleClass + "body{background: #f1f1f1; margin:auto; overflow-x:hidden;}";
        styleClass = styleClass + "a{text-decoration: none; cursor:pointer;} .Desktop{position: relative;} a:hover {text-decoration:underline; }";
        styleClass = styleClass + ".browserImg{width: 1369px;height: 55.32px;left: -1.5px;top: 0px;}";
        styleClass = styleClass + ".logo-search-container{margin:2rem; display: flex; position: relative; left:10%;}";
        styleClass = styleClass + ".logo{width: 60px;height: 26.01px;left: 213px;top: 90px;}";
        styleClass = styleClass + ".search-box{width: 616px; height: 32px; left: 375px; top: 32px; background: #FFFFFF; border-radius: 4px 0px 0px 4px; margin-left:6rem; padding: 12px; padding-top:8px; border:none; border-radius:.3rem 0rem 0rem .3rem; box-shadow:  0px 0px 4px #767676}";
        styleClass = styleClass + ".search-box:hover, .search-box:focus-visible, .search-box:disabled, .search-box:active{outline: none;}";
        styleClass = styleClass + "input{writing-mode: horizontal-tb !important; text-rendering: auto; color: fieldtext; letter-spacing: normal; word-spacing: normal; line-height: normal; text-transform: none; text-indent: 0px; text-shadow: none; display: inline-block; text-align: start;}";
        styleClass = styleClass + `.ie-container{ width: 1260px;height: 293px;position: absolute;left:53px;background-image: url(${getAppEnvironment().StaticsUrl}/pr-3693935/IE11NTP/ie-image.png);}`;
        styleClass = styleClass + ".banner-container{ width: 100%;position: absolute;left:53px; text-align:center; top: 377px;}";
        styleClass = styleClass + ".text{ margin: 3rem; margin-bottom: 0rem; }";
        styleClass = styleClass + ".p1{ width: 633px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 400; font-size: 36px; line-height: 42px; letter-spacing: -0.02em; color: #FFFFFF; margin-bottom: 1rem; }";
        styleClass = styleClass + ".p2{ width: 620px; height: 21px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 400; font-size: 14px; line-height: 21px; letter-spacing: -0.02em; color: #FFFFFF; margin-bottom: 1rem; }";
        styleClass = styleClass + ".buttons{ padding: 0px; margin-left: 3rem; padding-top:20px}";
        styleClass = styleClass + ".button{ display: flex; flex-direction: row; align-items: center; padding: 9px 20px 10px; gap: 4px; width: 296px; height: 42px; background: #FFFFFF; border-radius: 4px; text-decoration: none; color:black; }";
        styleClass = styleClass + ".button-text{ width: 234px; height: auto; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 15px; line-height: 21px; color: #000000; flex: none; order: 0; flex-grow: 0; margin-right:2px; text-align: center;}";
        styleClass = styleClass + "@media screen and (min-width:540px){ .ie-mobile{ display: none; } }";
        styleClass = styleClass + "@media screen and (max-width:540px) { body{ width:375px; } .browserImg{ display: none; } .logo{ display: none; } .Desktop{ position: relative; width: 375px; height: 1400px;} .ie-container{ display: none; } .search-box { width: 200px; height: 32px; left: 375px; top: 32px; background: #FFFFFF; margin-left: -1rem; } .mobile-text{ display: flex; flex-direction: column; align-items: center; padding: 20px 0px; gap: 16px; position: absolute; width: 375px; height: 245px; left: 0px; top: 244px; background: #767676; } .mobile-p1{ width: 327px; height: 60px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 400; font-size: 24px; line-height: 30px; text-align: center; letter-spacing: -0.02em; color: #FFFFFF; } .mobile-p2{ width: 327px; height: 48px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 400; font-size: 14px; line-height: 24px; text-align: center; letter-spacing: -0.02em; color: #FFFFFF; } .mobile-buttons{ width: 296px; height: 42px; padding-top:25px;} .mobile-button{ display: flex; flex-direction: row; align-items: center; padding: 9px 20px 10px; gap: 4px; width: 296px; height: 40px; background: #FFFFFF; border-radius: 4px; text-decoration: none; } .mobile-button-text{ width: 234px; height: auto; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 15px; line-height: 21px; color: #000000; margin-right:2px; text-align:center;} }";
        styleClass = styleClass + "@media screen and (max-width:540px){ .frame{ display: none; } .mobile-ads{ display: flex; flex-direction: column; align-items: flex-start; padding: 0px; gap: 20px; position: absolute; width: 300px; height: auto; left: 38px; top: 590px; } .ads-card, .feed-card{  position: relative; width: 300px; height: 304px; background: #FFFFFF; box-shadow: 0px 1.6px 3.6px rgba(0, 0, 0, 0.13), 0px 0px 2.9px rgba(0, 0, 0, 0.11); flex: none; order: 1; flex-grow: 0; } .ads-card-img{ width: 300px; height: 157px; left: 0px; top: 0px; background: #FFFFFF; } .content{ display: flex; flex-direction: column; justify-content: flex-end; align-items: center; padding: 0px; gap: 20px; width: 300px; left: 0px; top: 157px;margin-top:3%; overflow:hidden;} .title{ display: flex; flex-direction: column; justify-content: flex-end; align-items: flex-start; padding: 0px; gap: 5px; width: 268px; height: 75px; } .attribution-img{ height: 96px; } .title-link{ width: 268px; height: 75px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 18px; line-height: 24px; font-feature-settings: 'fina' on, 'init' on; color: #1A1A1A; } .banner-container { left: 0px; top: 515px; } } ";
        styleClass = styleClass + "@media screen and (min-width:541px) { .overflow{text-align: left;width: 1260px; } .mobile-ads{ display: none; } .frame{ display: flex; flex-direction: column; align-items: flex-start; padding: 0px; position: absolute; width: 1260px; height: auto; left: 53px; top: 490px; } .ads{ display: flex; flex-direction: row; align-items: flex-start; padding: 0px; width: 1260px; height: 304px; } .Infopane{ width: 620px; height: 304px; } .content-card{ position: relative; display: flex; flex-direction: column; justify-content: flex-end; align-items: center; padding: 0px; isolation: isolate; left: 0%; right: 0%; top: 0%; bottom: 0%; border: 1px solid rgba(0, 0, 0, 0.0578); filter: drop-shadow(0px 2px 4px rgba(0, 0, 0, 0.04)); } .infopane-image{ left: 0px; right: 0px; top: 0px; bottom: 0px; flex: none; order: 0; flex-grow: 0; z-index: 0; } .attribute{ position: absolute; top:225px; left:0; right:0; width: 620px; height: 78px; background: rgba(0, 0, 0, 0.27); padding:10px; } .Infopane-icon{  flex-direction: row; align-items: center; padding: 0px; gap: 4px; width: 15px; height:auto; flex: none; order: 0; flex-grow: 0; } .Infopane-title{ width: 588px; height: 29px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 18px; line-height: 24px; font-feature-settings: 'fina' on, 'init' on; color: #FFFFFF; flex: none; order: 1; align-self: stretch; flex-grow: 0; } .ads-card, .feed-card { position: relative; width: 300px; height: 304px; background: #FFFFFF; box-shadow: 0px 1.6px 3.6px rgba(0, 0, 0, 0.13), 0px 0px 2.9px rgba(0, 0, 0, 0.11); } .ads-card-img{ width: 300px; height: 157px; left: 0px; top: 0px; background: #FFFFFF; } .content{ display: flex; flex-direction: column; justify-content: flex-end; align-items: center; padding: 0px; gap: 20px; width: 300px; left: 0px; top: 157px;margin-top:3%; overflow:hidden;} .title{ display: flex; flex-direction: column; justify-content: flex-end; align-items: flex-start; padding: 0px; gap: 5px; width: 268px; height: 75px; } .attribution-img{ height: 96px; } .title-link{ width: 268px; height: 75px; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; font-style: normal; font-weight: 600; font-size: 18px; font-feature-settings: 'fina' on, 'init' on; color: #1A1A1A; }  }";
        styleClass = styleClass + "@media screen and (min-width:1440px) { body{ width:1335px; margin-left: auto; margin-right: auto; } }";
        styleClass = styleClass + "@media screen and (max-width:1024px) and (min-width:1024px) { body{ margin-left:-53px; } }";
        const styleClassadSlag = styleClass + ".ad-slug{ position: absolute; display:flex; flex-direction: row; padding: 10px; padding-left:12px; width:300px; height: 30px; bottom:2%; } .ad-tag{ width: 22px; height: 18px; border: 0.2px solid #292929; border-radius: 2px; text-align: center; background:#1e6525; } .ad-link{ height: 16px; margin-left:0.5rem; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif;  color: rgba(43,43,43,.7); font-size: 13px; } .ad-link-text{ text-decoration: none; color:black; }";
        const styleClassSearchBoxicon = styleClassadSlag + ".search-icon{ height: 33px;box-shadow: 0px 0px 4px #767676; border-radius: 0 5px 5px 0px; clip-path: inset(-5px -5px -5px 0px);}";
        const styleClassIcontext = styleClassSearchBoxicon + ".Iconstyle{display:inline; font-family:Segoe UI,Segoe WP,Arial,Sans-Serif; color:rgba(43,43,43,.7); margin-left:.4rem;} #Infopane-image-Icon-1{padding-top:2px;}";
        const styleClassAdlink = styleClassIcontext + ".ad-tag-link{color:#fff; font-family:Segoe UI,Segoe WP,Arial,Sans-Serif; font-size:12px;}";
        const styleClassFooter = styleClassAdlink + ".river{font-family: 'Segoe UI Semibold','Segoe WP Semibold','Segoe WP','Segoe UI',Arial,Sans-Serif; margin-bottom: 20px; font-size:12px; color:#666;} .river a{color: #666;}";
        const styleClassInfopaneKicker = styleClassFooter + "#Infopane-image-Icon-1{display:flex; flex-direction:column;} .Infopane-kicker{display: inline; margin-left: 8px; text-decoration: none;  position: absolute;  color: #a0a0a0; font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; cursor:pointer; font-size:12px;}";
        const styleClassBannerOverlay = styleClassInfopaneKicker + ".overlay{width: 100%; height:100%; position: absolute;} .overlay-mob{width: 100%; height:90%; position: absolute;}";
        const head = document.head || document.getElementsByTagName("head")[0];
        const head1 = document.head || document.getElementsByTagName("head")[1];
        const style = document.createElement("style");
        style.appendChild(document.createTextNode(styleClassBannerOverlay));
        head.appendChild(style);
        if (headData.Locale.toLowerCase() === "pl-pl" || headData.Locale.toLowerCase().substring(0, 2) === "es" || headData.Locale.toLocaleLowerCase() === "te-in") {
            const stylePlPl = ".mobile-p2{padding-top:15px;}";
            const style = document.createElement("style");
            style.appendChild(document.createTextNode(stylePlPl));
            head.appendChild(style);
        }
        if (headData.Locale.toLowerCase().substring(0, 2) === "en" || headData.Locale.toLowerCase() === "hi-in" || headData.Locale.toLowerCase() === "mr-in" || headData.Locale.toLowerCase().substring(0, 2) === "zh") {
            const stylePlPl = "@media screen and (max-width: 540px){.mobile-buttons{padding-top:10px !important;}}";
            const style = document.createElement("style");
            style.appendChild(document.createTextNode(stylePlPl));
            head.appendChild(style);
        }
        const meta = document.createElement("meta");
        meta.name = "viewport";
        meta.content = "width=device-width, initial-scale=1";
        document.head.appendChild(meta);
        const my_awesome_script = document.createElement("script");
        my_awesome_script.setAttribute("src", "https://code.jquery.com/jquery-3.6.3.min.js");
        document.head.appendChild(my_awesome_script);
        setTimeout(() => {
            getFeed();
        }, 800);
        return tempDivElement;
    };
    fun(template);
}
//# sourceMappingURL=page.js.map