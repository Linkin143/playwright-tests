// © Microsoft Corporation. All rights reserved.
// Days of week for determining present day
var DayOfWeek;
(function (DayOfWeek) {
    DayOfWeek[DayOfWeek["sunday"] = 0] = "sunday";
    DayOfWeek[DayOfWeek["monday"] = 1] = "monday";
    DayOfWeek[DayOfWeek["tuesday"] = 2] = "tuesday";
    DayOfWeek[DayOfWeek["wednesday"] = 3] = "wednesday";
    DayOfWeek[DayOfWeek["thursday"] = 4] = "thursday";
    DayOfWeek[DayOfWeek["friday"] = 5] = "friday";
    DayOfWeek[DayOfWeek["saturday"] = 6] = "saturday";
})(DayOfWeek || (DayOfWeek = {}));
/**
 * Homepage config validator class
 *
 * @export
 * @class HomePageConfigValidator
 */
export class HomePageConfigValidator {
    /**
     * Constructor for Homepage Config Validator
     * @constructor
     */
    constructor() {
        this.expValidatorMap = new Map();
        /**
         * Validator to check if module should be removed from config for the current day.
         * @method
         * @returns {boolean}
         */
        this.hideModuleForCurrentDay = (validationObj) => {
            if (!validationObj || !validationObj.allowedDays || !validationObj.allowedDays.length) {
                return false;
            }
            const currentDay = new Date().getDay();
            const allowedDays = validationObj.allowedDays;
            return !allowedDays.find(day => DayOfWeek[currentDay] === day.toLocaleLowerCase());
        };
        this.setValidators();
    }
    /**
     * Returns the validator map
     * @method
     * @returns {Map<string, () => boolean>}
     */
    getAllValidators() {
        return this.expValidatorMap;
    }
    /**
     * Add validators to internal map
     * @method
     * @returns {boolean}
     */
    setValidators() {
        this.expValidatorMap.set("dayOfWeekValidator", this.hideModuleForCurrentDay);
    }
}
//# sourceMappingURL=HomePageConfigValidator.js.map