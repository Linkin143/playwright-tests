"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-info-event-brief"],{4968(e,t,i){i.d(t,{f(){return s}});var r=i(64187),a=i(74849),o=i(42792),n=i(99657),l=i(36452);const s=a.A.partial`position: relative; z-index: ${n.D};`;a.A`
    ${o.e}
    ${o.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${s}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},42792(e,t,i){i.d(t,{R7(){return u},e(){return g},kc(){return f},nH(){return p}});var r=i(57416),a=i(55153),o=i(95239),n=i(26920),l=i(48751),s=i(64187),d=i(22131),c=i(74849),h=i(50882);const p=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,g=c.A`
    ${(0,s.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${n.XA} * 1px) solid ${a.cu};
        border-radius: calc((${r.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${l.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,f=(0,d.mr)(c.A`
            :host {
                background: ${h.A.Canvas};
                color: ${h.A.CanvasText};
            }
        `),u=c.A`
    ${g}
    ${p}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(f)},47361(e,t,i){i.r(t),i.d(t,{EventBrief(){return z}});var r=i(56911),a=i(27208),o=i(92707);class n extends o.z{get showCompanyInformation(){return this.viewModel.eventLevel===a.LC.Company&&"_1x_1y"!==this.viewModel.cardSize&&Boolean(this.viewModel.quoteItem)}}var l=i(92011),s=i(4968),d=i(12640),c=i(74849),h=i(48751);const p=c.A` .event-company-price{background:rgba(41,41,41,0.7)}`,g=c.A` .event-brief-content{color:${h.l};
        display: grid;
        grid-template-rows: 1fr auto auto;
        row-gap: 6px;
        height: 100%;
        box-sizing: border-box;
        text-decoration: none;
        ${s.f}}._1x_1y.event-brief-content{grid-template-columns:auto 56px;gap:12px;grid-template-rows:none;align-items:center}._1x_3y.event-brief-content{padding-bottom:16px}.event-brief-content.company-layout{grid-template-rows:1fr auto auto auto}.event-brief-small-content{display:flex;flex-direction:column;gap:6px;max-width:200px}.event-name{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;text-overflow:ellipsis;height:fit-content}._1x_1y .event-name{font-weight:600;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);-webkit-line-clamp:1}._1x_2y .event-name{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600}._1x_3y .event-name{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px);font-weight:600;-webkit-line-clamp:3}._1x_3y.event-brief-content:not(.company-layout) .event-publisher{margin-top:26px}._1x_2y.event-brief-content:not(.company-layout) .event-publisher{margin-top:10px}.event-related-stories{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.event-company-price{display:flex;justify-content:space-around;align-items:center;column-gap:2px;margin-top:6px;border-radius:6px;padding:0 6px;width:78px;height:20px;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);font-weight:600;background:rgba(255,255,255,0.46);backdrop-filter:blur(30px)}.event-brief-image{max-height:100%;overflow:hidden}.event-brief-image img{width:100%;height:100%;max-width:100%;border-radius:8px;object-fit:cover}._1x_1y .event-brief-image{max-height:56px}._1x_1y .event-brief-image img{height:56px}.event-publisher.no-pimg{grid-template-columns:auto}.event-publisher{display:grid;grid-template-columns:16px auto;gap:8px;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.event-publisher img{width:16px;height:16px;max-width:16px;border-radius:2px}.event-publisher .publisher-info{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`.withBehaviors(new d.N(null,p));var f=i(96950),u=i(69259);const b=f.qy`<div class="event-brief-image"><img src="${e=>e.viewModel.eventImageUrl}" alt=""/></div>`,v=f.qy`<div class="event-publisher ${e=>e.viewModel.publisherIconUrl?"":"no-pimg"} ">${(0,u.z)(e=>e.viewModel.publisherIconUrl,f.qy`<img src="${e=>e.viewModel.publisherIconUrl}" alt=""/>`)}<span class="publisher-info">${e=>e.viewModel.publisherInfoText}</span></div><div class="event-name">${e=>e.viewModel.eventName}</div>`,x=f.qy`<div class="event-company-price"><div class="company-name">${e=>{var t;return null===(t=e.viewModel.quoteItem)||void 0===t?void 0:t.symbol}}</div><div class="percentage-change" style="color: ${e=>e.viewModel.percentageColor}">&lrm;${e=>{var t;return null===(t=e.viewModel.quoteItem)||void 0===t?void 0:t.changePcnt}}&lrm;</div></div>`,m=f.qy`<div class="event-related-stories">${e=>e.viewModel.relatedStoriesText}</div>`,y=f.qy`<div class="event-brief-small-content">${v} ${m}</div>${b}
`,$=f.qy` ${b} ${(0,u.z)(e=>e.showCompanyInformation,x)} ${v} ${(0,u.z)(e=>"_1x_1y"!==e.viewModel.cardSize,m)}
`,w=f.qy`<a class=" event-brief-content ${e=>e.viewModel.cardSize} ${e=>e.showCompanyInformation?"company-layout":""} " title="${e=>e.viewModel.eventName}" href="${e=>e.viewModel.destinationUrl}" data-t="${e=>e.viewModel.telemetryTag}" target="${e=>e.viewModel.openLinksInNewTab?"_blank":"_self"}">${e=>"_1x_1y"===e.viewModel.cardSize?y:$}</a>`,k=f.qy` ${(0,u.z)(e=>e&&void 0!==e.viewModel,w)}
`;let z=class extends n{};z=(0,r.Cg)([(0,l.E)({name:"event-brief",template:k,styles:g,shadowOptions:{delegatesFocus:!0}})],z)},92707(e,t,i){i.d(t,{z(){return s}});var r=i(56911),a=i(27208),o=i(60815),n=i(92011),l=i(31525);let s=class extends n.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return a.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const e=this.getState();e&&(e.subscribe(a.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(e){}onChartDictChange(e){}onShowNotificationTextChange(e){}onQuoteItemDictChange(e){}onCardWidthChanged(e){}};(0,r.Cg)([o.sH],s.prototype,"viewModel",void 0),s=(0,r.Cg)([l.x],s)},93656(e,t,i){i.r(t),i.d(t,{EventBriefTransformer(){return l}});var r=i(27208),a=i(30236),o=i(96950),n=i(86449);class l extends r.IB{async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,n.jJ)();const i=await this.getCurrentViewModel(e);return{viewTemplate:o.qy`
                <event-brief
                    :viewModel="${i}"
                ></event-brief>`}}getAccentColor(e){var t;return(0,n.BK)((0,n.jJ)(),(null===(t=e.quoteItem)||void 0===t?void 0:t.changePcntNumber)||0,this.transformerProvider.config.swapGainLossColor)}getDestinationUrl(e){return(0,a.Oq)(this.transformerProvider.config.urls,e.eventBriefData)}async getCurrentViewModel(e){var t;const{telemetryBuilder:i,config:a}=this.transformerProvider,{eventBriefData:o,quoteItem:n}=e,l=null===(t=o.newsDetails)||void 0===t?void 0:t.newsList,s=l&&l.length>0?l[0]:void 0;return{cardSize:this.cardSize,experienceName:e.experienceName,isDarkModeTheme:this.isInDarkMode,destinationUrl:this.getDestinationUrl(e),percentageColor:this.getAccentColor(e),openLinksInNewTab:a.openLinksInNewTab,relatedStoriesText:`${this.transformerProvider.strings.relatedStories}`.replace("{0}",`${o.numberOfNews}`),telemetryTag:i.createNavClickTelemetryTag(e.telemetryObject,{name:r.CD.moneyEventBrief,signature:e.signature}),quoteItem:n,...o,publisherIconUrl:null==s?void 0:s.providerLogoUrl,publisherInfoText:(null==s?void 0:s.providerName)||""}}}Promise.resolve().then(i.bind(i,47361))},99657(e,t,i){i.d(t,{D(){return n},I(){return o}});var r=i(45755);const{create:a}=r.G,o=a("sloppy-click-z-index",1),n=a("click-z-index",1)}}]);