"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["rich-calendar-component"],{2694(t,i,e){e.r(i),e.d(i,{RichCalendarTabOthers(){return R}});var a,o=e(56911),n=e(92011),r=e(60815),l=e(38493),d=e(76346),s=e(99947),v=e(70828),g=e(11363),c=e(85657),p=e(58792),h=e(27233);class u extends n.L{constructor(){super(...arguments),this.size=d.vN.Medium}get config(){var t;return null===(t=this.richCalendarCard)||void 0===t?void 0:t.config}get currentTagType(){var t;return null===(t=this.richCalendarCard)||void 0===t||null===(t=t.currentTab)||void 0===t?void 0:t.tagType}get cachedEventUrl(){var t;return null===(t=this.richCalendarCard)||void 0===t?void 0:t.cachedEventUrl}get cardSize(){var t;return(null===(t=this.richCalendarCard)||void 0===t||null===(t=t.commonViewModel)||void 0===t?void 0:t.cardSize)??d.qJ.OneU}richCalendarCardChanged(t,i){if(i&&i.todayDateInfo&&this.currentTagType){switch(this.generateTabSize(),this.currentTagType){case d.al.Event:this.nowTagData=this.generateXiechengData(i.todayDateInfo);break;case d.al.NceeEvent:this.nowTagData=this.generateGaokaoData(i.todayDateInfo);break;case d.al.Activity:this.nowTagData=this.generateDamaiData(i.todayDateInfo);break;case d.al.LuckyDay:this.nowTagData=this.generateLuckyDayData(i.todayDateInfo);break;case d.al.Sports:this.nowTagData=this.generateSportsData(i.todayDateInfo)}this.nowTagData&&(this.nowTagData.telemetry=(0,g.aw)(c.kj.Tabs[this.currentTagType]))}}get illustrationPosition(){var t;return this.cardSize===d.qJ.HalfU||null!==(t=this.config)&&void 0!==t&&t.UseEnLayout||this.currentTagType!==d.al.Festival?a.Inner:a.TopRight}generateTagContainerClassName(){const t=this.currentTagType;let i="calendar-tag-container";return t===d.al.Event?i+=" calendar-tag-container-event":t===d.al.NceeEvent?i+=" calendar-tag-container-gaokao":this.illustrationPosition===a.Inner&&(i+=" calendar-tag-container-inner"),i}generateTabSize(){if(this.cardSize===d.qJ.HalfU)this.size=d.vN.Small;else this.size=d.vN.Medium}generateXiechengData(t){var i;const{Date:e,Event:a}=t;if(null!=a&&a.Data&&(null==a||null===(i=a.Data)||void 0===i?void 0:i.length)>0){var o,n;const t=`${null==e?void 0:e.Year}-${a.Data[0].replace(null===(o=this.config)||void 0===o?void 0:o.MonthLabel,"-").replace(null===(n=this.config)||void 0===n?void 0:n.DayLabel,"")}`;return{name:a.Name,data:a.Data,href:`https://trains.ctrip.com/webapp/train/list?dDate=${t}&allianceid=4249274&sid=47038258`}}}generateGaokaoData(t){const{Date:i,NceeEvent:e}=t;var a,o;if(e)return{name:null==e?void 0:e.Name,data:null!=e&&e.Data&&(null==e||null===(a=e.Data)||void 0===a?void 0:a.length)>0?e.Data:[],countdown:null==e?void 0:e.CountDown,showCountdown:(null==e?void 0:e.CountDown)>=0,href:s.fZ(i,this.config,{formCode:null===(o=this.config)||void 0===o?void 0:o.eventFormCode,bingQuery:null==e?void 0:e.Name})}}generateDamaiData(t){var i;const{ShowEvents:e}=t;var a;if(e&&null!==(i=e[0])&&void 0!==i&&i.Image)return{Image:v.n(e[0].Image,{width:52}),Data:e&&null!==(a=e[0])&&void 0!==a&&a.Data&&3==e[0].Data.length?{title:e[0].Data[0],date:e[0].Data[1],position:e[0].Data[2]}:{title:"",date:"",position:""},href:e[0].Url}}generateLuckyDayData(t){const{Date:i,RichInfo:e}=t;if(6===(null==e?void 0:e.RichInfoType)&&Array.isArray(null==e?void 0:e.Text)){let t=e.Text[0];return p.T3.CurrentMarket===h.DX.JAJP&&(t=`${c.FH.LuckyDayTabLabel} ${t}`),{title:e.Text[0]??"",description:e.Text[1]??"",href:s.jS(i,this.config,{eventUrl:this.cachedEventUrl,bingQuery:t})}}}generateSportsData(t){var i;const{Date:e,SportsEvents:a}=t;if(null==a||!a.length)return;const o=s.jS(e,this.config,{eventUrl:this.cachedEventUrl,bingQuery:a[0].Query??a[0].Name,formCode:null===(i=this.config)||void 0===i?void 0:i.eventFormCode}),n=a[0].Name??"",r={title:n,description:a[0].Text??"",href:o};return a[0].Image&&(r.illustration={enableAnimation:!1,src:v.n(a[0].Image,{width:85}),href:o,name:n}),r}}(0,o.Cg)([r.sH],u.prototype,"richCalendarCard",void 0),(0,o.Cg)([r.sH],u.prototype,"nowTagData",void 0),(0,o.Cg)([l.CF],u.prototype,"size",void 0),function(t){t[t.Inner=0]="Inner",t[t.TopRight=1]="TopRight"}(a||(a={}));var x=e(74849),b=e(4126),f=e(12640),k=e(22131);const w=x.A``,m=x.A`
.gaokao-tag-box .date-tag-right .arrow-icon {
    background: #ffffff;
}
`,$=x.A`
.gaokao-tag-box .date-tag-right .arrow-icon {
    background: #242424;
}
`;var y=x.A`
a {
    text-decoration: none;
    color: inherit;
}

.calendar-tag-container {
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    width: 276px;
    height: 68px;
    padding-left: 8px;
    padding-right: 4px;
    border-radius: 6px;
    background: var(--date-tag-background);
    box-shadow: var(--date-tag-box-boxshadow);
    backdrop-filter: blur(2px);
    position: relative;
    z-index: 1;

    &:hover {
        background: var(--hover-background);
    }

    &.calendar-tag-container-countdown {
        height: 32px;
    }

    &.calendar-tag-container-event {
        padding: 0px;
        border-radius: 4px;
    }

    &.calendar-tag-container-gaokao {
        padding: 0px;
        background-color: var(--gaokao-tag-box-background);
        border: var(--gaokao-tag-box-border);
        box-shadow: 0px 0px 10px 0px rgba(30, 118, 113, 0.1);

        &:hover {
            background-color: var(--hover-background);
        }
    }
    &.calendar-tag-container-inner {
        column-gap: 8px;
    }
}

.default-illustration{
    display: block;
    position: relative;
    width: 48px;
    height: 48px;
    top: 0;
    left: 0;
}

.default-illustration img{
    width: 100%;
    height: 100%;
}

.date-tag-box {
    flex: 1;
    display: block;
    width: 100%;
    height: 48px;
}

.event-big-tag {
    background-image: url("${c.r$}latest/richcalendar/img/ticket_big_v2.svg"), url("${c.r$}latest/richcalendar/img/ticket_hover_big_v2.svg");
}

.event-big-tag:hover {
    background-image: url("${c.r$}latest/richcalendar/img/ticket_hover_big_v2.svg");
}

.event-small-tag {
    background-image: url("${c.r$}latest/richcalendar/img/ticket_small_v2.svg"), url("${c.r$}latest/richcalendar/img/ticket_hover_small_v2.svg");
}

.event-small-tag:hover {
    background-image: url("${c.r$}latest/richcalendar/img/ticket_hover_small_v2.svg");
}

.event-big-tag {
    height: 68px;
    border-radius: 4px;
    margin-top: 6px;
}

.event-small-tag {
    height: 66px;
    border-radius: 4px;
}

.event-sign {
    display: flex;
    width: 48px;
    height: 48px;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    border-radius: 6px;
    position: absolute;
    left: 12px;
    color: #fff;
    font-weight: 600;
    background: linear-gradient(180deg, #FF8033 0%, #FF5A00 103.52%),linear-gradient(211.76deg, rgba(255, 222, 219, 0.4) 7.06%, rgba(255, 178, 169, 0) 34.81%);
}

.event-big-tag .event-sign {
    top: 9.5px;
}

.event-small-tag .event-sign {
    top: 8.5px;
}

.event-sign div:first-child {
    height: 16px;
    line-height: 16px;
    font-size: 16px;
}

.event-sign div:last-child {
    height: 10px;
    line-height: 10px;
    font-size: 10px;
    margin-top: 4px;
}

.event-tag-content {
    position: absolute;
    left: 68px;
    color: rgba(255, 95, 17, 1);
    padding-top: 9.5px;
}

.event-small-tag .event-tag-content {
    padding-top: 8.5px;
}

.event-title {
    line-height: 12px;
    font-size: 12px;
    font-weight: 400;
}

.event-content {
    line-height: 16px;
    padding: 4px 0;
    width: 200px;
}

.event-content .date-weight {
    font-weight: 600;
    margin-right: 2px;
}

.event-tip {
    padding: 3px;
    height: 9px;
    line-height: 9px;
    width: fit-content;
    font-size: 10px;
    font-weight: 400;
    background: rgba(255, 247, 231, 1);
    border-radius: 4px;
    color: rgba(68, 29, 0, 1);
}

.event-countdown {
    margin-left: 6px;
}

.event-tag-box .date-tag-right {
    position: absolute;
    right: 7px;

    & .arrow-icon {
        background: #FF5F11;
    }
}

.date-tag-left {
    width: calc(100% - 12px);
    height: 48px;
    float: left;
    position: relative;
}

.date-tag-left .tag-content{
    max-width: 100%;
    height: 48px;
    position: absolute;
    left: 0;
}

.date-tag-box-activity,
.date-tag-box-activity:hover {
    background-clip: border-box;
    background-origin: border-box;
    background-image: var(--theme-calendar-date-color), var(--theme-calendar-date-color);
}

.date-tag-box-activity .date-tag-right .arrow-icon {
    background: #FFFFFF;
}

.sports-content {
    color: var(--theme-color);
}

.sports-title,
.tag-luckyDay-title {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    line-height: 14px;
    font-size: 14px;
    font-weight: 600;
    vertical-align: top;
    padding-bottom: 2px;
}

.sports-description,
.tag-luckyDay-description {
    height: 32px;
    font-size: 12px;
    font-weight: 400;
    line-height: 16px;
    margin-top: 2px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    text-overflow: ellipsis;
}

.date-tag-horoscope {
    height: 25px;
    margin-top: 4px;
    font-size: 12px;
    font-weight: 400;
    line-height: 12px;
    color: var(--date-dayofweek-color);
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
}

.tag-activity {
    display: flex;
    height: 52px;
}

.activity-img {
    display: inline-block;
    width: 52px;
    height: 52px;
    border-radius: 4px;
}

.activity-img img {
    width: 100%;
    height: 100%;
}

.activity-content {
    display: flex;
    flex-direction: column;
    margin: 1px 0px 1px 8px;
    width: 184px;
    height: 50px;
    color: #FFFFFF;
    .activity-title {
        width: 184px;
        height: 14px;
        font-size: 12px;
        line-height: 14px;
        font-weight: 600;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .activity-date {
        height: 12px;
        line-height: 12px;
        font-size: 11px;
        margin-top: 6px;
    }
    .activity-position {
        height: 12px; 
        line-height: 12px;
        font-size: 11px;
        margin-top: 4px;
    }
    img {
        width: 12px;
        height: 12px;
        line-height: 12px;
        margin-right: 5px;
    }
    .activity-flex {
        display: flex;
        align-items: center;
    }
    span {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
}

.gaokao-small-tag {
    height: 66px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    background: var(--gaokao-small-tag-background);
}

.gaokao-big-tag {
    height: 68px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    background: var(--gaokao-big-tag-background);
}

.hide-gaokao-sign {
    display: none;
}

.gaokao-sign {
    display: flex;
    width: 52px;
    height: 52px;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    border-radius: 6px;
    position: absolute;
    left: 8px;
    font-weight: 600;
    background: var(--gaokao-sign-background);
    overflow: hidden;
    border: var(--gaokao-sign-border);
    box-sizing: border-box;
    .gaokao-sign-title {
        background: #FF7E21;
        width: 52px;
        text-align: center;
        height: 18px;
        line-height: 18px;
        position: absolute;
        top: 0px;
        font-size: 10px;
        color: #fff;
    }
    .gaokao-sign-countdown {
        font-size: 32px;
        color: #FF7E21;
        line-height: 34px;
        height: 34px;
        position: absolute;
        bottom: 0px;
    }
}

.gaokao-tag-content {
    position: absolute;
    left: 68px;
}
.gaokao-title {
    font-size: 10px;
    line-height: 14px;
    font-weight: 400;
    color: var(--gaokao-title-color);
}

.gaokao-title-hidden {
    display: none;
}
.gaokao-content {
    font-size: 14px;
    font-weight: 600;
    line-height: 20px;
    margin-bottom: 2px;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 245px;
    white-space: nowrap;
}
.gaokao-content-short {
    max-width: 190px;
}
.gaokao-tip {
    height: 15px;
    line-height: 15px;
    padding-left: 3px;
    padding-right: 3px;
    margin-left: -3px;
    width: fit-content;
    font-size: 9px;
    font-weight: 400;
    background: var(--gaokao-tip-background);
    border-radius: 4px;
    color: rgba(255, 126, 33, 1);
    text-overflow: ellipsis;
    overflow: hidden;
    max-width: 250px;
    white-space: nowrap;
}
.gaokao-tip-short {
    max-width: 180px;
}
.gaokao-tag-content-left {
    position: absolute;
    left: 12px;
}
.gaokao-tag-box .date-tag-right {
    position: absolute;
    right: 7px;
}
`.withBehaviors(new b.o("size",d.vN.Small,x.A`
        .calendar-tag-container {
            height: 66px;
        }
        .date-tag-box {
            height: 50px;
        }
    `),new f.N($,m),(0,k.G2)(m),(0,k.mr)(w)),F=e(96950),z=e(69259);const D=F.qy`<rich-calendar-see-more :richCalendarCard="${t=>t.richCalendarCard}"></rich-calendar-see-more>`,C=F.qy` ${(0,z.z)(t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.illustration},F.qy`<div class="default-illustration ${t=>{var i;return null===(i=t.nowTagData)||void 0===i||null===(i=i.illustration)||void 0===i?void 0:i.classname}}"><img src="${t=>{var i;return null===(i=t.nowTagData)||void 0===i||null===(i=i.illustration)||void 0===i?void 0:i.src}}" alt="${t=>{var i;return null===(i=t.nowTagData)||void 0===i||null===(i=i.illustration)||void 0===i?void 0:i.name}}"></div>`)}
`,_=F.qy`<div class="date-tag-box event-tag-box"><div class="${t=>t.size===d.vN.Small?"event-small-tag":"event-big-tag"}"><div class="event-sign"><div>${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.name}}</div><div>${c.FH.EventTitlSecondLine}</div></div><div class="event-tag-content"><div class="event-title">${c.FH.EventContentTitle}</div><div class="event-content"><span class="date-weight">${t=>{var i;return null===(i=t.nowTagData)||void 0===i||null===(i=i.data)||void 0===i?void 0:i[0]}}</span>${c.FH.EventCountdownDate}</div><div class="event-tip">${t=>{var i,e;return null!==(i=t.nowTagData)&&void 0!==i&&null!==(i=i.data)&&void 0!==i&&i[1]?null===(e=t.nowTagData)||void 0===e?void 0:e.data[1]:""}}<span class="event-countdown">${t=>{var i,e;return null!==(i=t.nowTagData)&&void 0!==i&&null!==(i=i.data)&&void 0!==i&&i[2]?null===(e=t.nowTagData)||void 0===e?void 0:e.data[2]:""}}</span></div></div>${D}</div></div>`,T=F.qy`<div class="date-tag-box gaokao-tag-box"><div class="${t=>t.size===d.vN.Small?"gaokao-small-tag":"gaokao-big-tag"}"><div class="${t=>{var i;return null!==(i=t.nowTagData)&&void 0!==i&&i.showCountdown?"gaokao-sign":"hide-gaokao-sign"}}"><div class="gaokao-sign-title">${c.FH.GaoKaoCountdownLabel}</div><div class="gaokao-sign-countdown">${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.countdown}}</div></div><div class="${t=>{var i;return null!==(i=t.nowTagData)&&void 0!==i&&i.showCountdown?"gaokao-tag-content":"gaokao-tag-content-left"}}"><div class="${t=>{var i;return null!==(i=t.nowTagData)&&void 0!==i&&null!==(i=i.data)&&void 0!==i&&i[2]?"gaokao-title":"gaokao-title-hidden"}}">${t=>{var i;return null===(i=t.nowTagData)||void 0===i||null===(i=i.data)||void 0===i?void 0:i[0]}}</div><div class="gaokao-content ${t=>{var i;return null!==(i=t.nowTagData)&&void 0!==i&&i.showCountdown?"gaokao-content-short":" "}}">${t=>{var i,e,a;return null!==(i=t.nowTagData)&&void 0!==i&&null!==(i=i.data)&&void 0!==i&&i[2]?null===(e=t.nowTagData)||void 0===e?void 0:e.data[1]:null===(a=t.nowTagData)||void 0===a||null===(a=a.data)||void 0===a?void 0:a[0]}}</div><div class="gaokao-tip ${t=>{var i;return null!==(i=t.nowTagData)&&void 0!==i&&i.showCountdown?"gaokao-tip-short":" "}}">${t=>{var i,e,a;return null!==(i=t.nowTagData)&&void 0!==i&&null!==(i=i.data)&&void 0!==i&&i[2]?null===(e=t.nowTagData)||void 0===e?void 0:e.data[2]:null===(a=t.nowTagData)||void 0===a||null===(a=a.data)||void 0===a?void 0:a[1]}}</div></div>${D}</div></div>`,E=F.qy`<div class="date-tag-box"><div class="date-tag-left"><div class="tag-activity"><img class="activity-img" src="${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.Image}}"/><div class="activity-content"><div class="activity-title">${t=>{var i;return null===(i=t.nowTagData)||void 0===i||null===(i=i.Data)||void 0===i?void 0:i.title}}</div><div class="activity-date activity-flex"><img src="${c.r$}latest/richcalendar/img/activity/Date.svg"/><span>${t=>{var i;return null===(i=t.nowTagData)||void 0===i||null===(i=i.Data)||void 0===i?void 0:i.date}}</span></div><div class="activity-position activity-flex"><img src="${c.r$}latest/richcalendar/img/activity/Position.svg"/><span>${t=>{var i;return null===(i=t.nowTagData)||void 0===i||null===(i=i.Data)||void 0===i?void 0:i.position}}</span></div></div></div></div>${D}</div>`,S=F.qy`<div class="date-tag-box"><div class="date-tag-left"><div class="tag-content tag-luckyDay"><div class="tag-luckyDay-title">${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.title}}</div><div class="tag-luckyDay-description">${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.description}}</div></div></div>${D}</div>`,j=F.qy`<div class="date-tag-box"><div class="date-tag-left"><div class="tag-content sports-content"><div class="sports-title" title="${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.title}}">${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.title}}</div><div class="sports-description" title="${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.description}}">${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.description}}</div></div></div>${D}</div>`;var P=F.qy`<a class="${t=>t.generateTagContainerClassName()}" data-t="${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.telemetry}}" target="_blank" href="${t=>{var i;return null===(i=t.nowTagData)||void 0===i?void 0:i.href}}" rel="noopener">${(0,z.z)(t=>t.illustrationPosition===a.Inner,C)} ${(0,z.z)(t=>t.currentTagType===d.al.Event,_)} ${(0,z.z)(t=>t.currentTagType===d.al.NceeEvent,T)} ${(0,z.z)(t=>t.currentTagType===d.al.Activity,E)} ${(0,z.z)(t=>t.currentTagType===d.al.LuckyDay,S)} ${(0,z.z)(t=>t.currentTagType===d.al.Sports,j)}</a>`;let R=class extends u{};R=(0,o.Cg)([(0,n.E)({name:"rich-calendar-tab-others",template:P,styles:y,shadowOptions:null})],R)},2899(t,i,e){e.r(i),e.d(i,{RichCalendarTabPicture(){return y}});var a=e(56911),o=e(92011),n=e(60815),r=e(38493),l=e(76346),d=e(11363),s=e(85657),v=e(70828),g=e(99947);class c extends o.L{constructor(){super(...arguments),this.size=l.vN.Medium}get cardSize(){var t;return(null===(t=this.richCalendarCard)||void 0===t||null===(t=t.commonViewModel)||void 0===t?void 0:t.cardSize)??l.qJ.OneU}richCalendarCardChanged(t,i){var e;i&&null!==(e=i.contentData)&&void 0!==e&&e.TodayInfo&&(this.generateTabSize(),this.generatePictureData(i.todayDateInfo))}generatePictureData(t){null!=t&&t.WallPaper&&t.WallPaper.ImageUrl?this.pictureData={imageUrl:(0,v.n)(t.WallPaper.ImageUrl,{width:250,height:0,crop:0}),hoverText:t.WallPaper.HoverText,title:t.WallPaper.Title,text:t.WallPaper.Text,href:(0,g.O2)(t.WallPaper.RedirectUrl),telemetry:(0,d.aw)(s.kj.Tabs[l.al.Picture])}:this.pictureData=void 0}generateTabSize(){if(this.cardSize===l.qJ.HalfU)this.size=l.vN.Small;else this.size=l.vN.Medium}}(0,a.Cg)([n.sH],c.prototype,"richCalendarCard",void 0),(0,a.Cg)([n.sH],c.prototype,"pictureData",void 0),(0,a.Cg)([r.CF],c.prototype,"size",void 0);var p=e(74849),h=e(22131),u=e(12640);const x=p.A`
    .picture-container {
        background-color: rgba(255, 255, 255, 0.08);
    }
    .picture-title {
        color: #FFFFFF;
    }
    .picture-subtitle {
        color: #FFFFFF;
    }
`,b=p.A`
    .picture-container {
        background-color: var(--date-tag-background, #FFFFFF);
    }
    .picture-title {
        color: #242424;
    }
    .picture-subtitle {
        color: #242424;
    }
`,f=p.A`
    .picture-container {
        outline: 1px solid;
    }
`;var k=p.A`
    .picture-tag {
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: flex-start;
        width: 276px;
        height: 68px;
        padding-left: 8px;
        padding-right: 4px;
        border-radius: 6px;
        background: var(--date-tag-background);
        box-shadow: var(--date-tag-box-boxshadow);
        position: relative;
        z-index: 1;

        &:hover {
            background: var(--hover-background);
        }
    }

    .picture-tag-small {
        height: 66px;
    }

    .picture-content {
        display: flex;
        align-items: center;
        gap: 8px;
        height: 100%;
        flex: 1;
        min-width: 0;
    }

    .picture-image {
        height: 52px;
        width: 96px;
        border-radius: 2px;
        object-fit: cover;
        flex: 0 0 auto;
    }

    .picture-description {
        display: flex;
        flex-direction: column;
        justify-content: center;
        min-width: 0;
        gap: 4px;
    }

    .picture-title {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        line-height: 20px;
        font-size: 14px;
        font-weight: 600;
        margin: 0;
    }

    .picture-subtitle {
        display: -webkit-box;
        overflow: hidden;
        text-overflow: ellipsis;
        line-height: 12px;
        font-size: 10px;
        margin: 0;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
    }
`.withBehaviors(new u.N(b,x),(0,h.G2)(x),(0,h.mr)(f)),w=e(96950);const m=w.qy`<rich-calendar-see-more :richCalendarCard="${t=>t.richCalendarCard}" :customTitle="${s.FH.PictureHoverLabel}"></rich-calendar-see-more>`;var $=w.qy`<a class="picture-tag ${t=>t.size===l.vN.Small?"picture-tag-small":""}" data-t="${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.telemetry}}" target="_blank" href="${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.href}}" rel="noopener" aria-label="${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.hoverText}}"><div class="picture-content"><img class="picture-image" src="${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.imageUrl}}" alt="${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.hoverText}}" title="${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.hoverText}}" /><div class="picture-description"><div class="picture-title" title="${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.title}}">${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.title}}</div><div class="picture-subtitle" title="${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.text}}">${t=>{var i;return null===(i=t.pictureData)||void 0===i?void 0:i.text}}</div></div></div>${m}</a>`;let y=class extends c{};y=(0,a.Cg)([(0,o.E)({name:"rich-calendar-tab-picture",template:$,styles:k,shadowOptions:null})],y)}}]);