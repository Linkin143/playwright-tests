"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-watchlist-summary"],{4968(t,e,r){r.d(e,{f(){return l}});var i=r(64187),a=r(74849),s=r(42792),n=r(99657),o=r(36452);const l=a.A.partial`position: relative; z-index: ${n.D};`;a.A`
    ${s.e}
    ${s.nH}

    ${(0,i.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${o.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${o.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${o.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(s.kc)},42792(t,e,r){r.d(e,{R7(){return m},e(){return p},kc(){return u},nH(){return c}});var i=r(57416),a=r(55153),s=r(95239),n=r(26920),o=r(48751),l=r(64187),d=r(22131),h=r(74849),g=r(50882);const c=h.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,p=h.A`
    ${(0,l.V)("flex")} :host {
        background: ${s.p};
        outline: calc(${n.XA} * 1px) solid ${a.cu};
        border-radius: calc((${i.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${o.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,d.mr)(h.A`
            :host {
                background: ${g.A.Canvas};
                color: ${g.A.CanvasText};
            }
        `),m=h.A`
    ${p}
    ${c}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},60035(t,e,r){r.r(e),r.d(e,{WatchlistSummaryQuoteItemTransformer(){return g},WatchlistSummaryTransformer(){return h}});var i=r(49150),a=r(27208),s=r(86449),n=r(50180),o=r(58792),l=r(30236),d=r(96950);class h extends a.IB{async transform(t){const e=await this.getCurrentViewModel(t);return{viewTemplate:d.qy`
                <watchlist-summary
                    :viewModel="${e}"
                ></watchlist-summary>`}}getListItemColor(t){return(0,s.BK)((0,s.jJ)(),this.annualReturn(t),this.transformerProvider.config.swapGainLossColor)}annualReturn(t){const{oneDayReturn:e}=this.firstListItem(t)||{};return e||0}firstListItem(t){return t.tabData&&t.tabData.listItems?t.tabData.listItems[0]:null}async getSummaryQuotes(t){var e,r;if(!t.tabData||!t.tabData.listItems||null===(e=t.tabData.listItems)||void 0===e||!e[0].quotes)return[];let i=null===(r=t.tabData.listItems)||void 0===r?void 0:r[0].quotes;i=i.slice(0,Math.min(this.quotesMaxLength(t),i.length));const n=this.isWithLogo(t),o=i.map(e=>{const r={cardSize:(0,s.CP)(t.cardSize),isVertical:this.isVerticalWatchlist(t),isWithLogo:n,parentTelemetryObject:t.telemetryObject,quote:e,signature:t.signature,swapGainLossColor:this.transformerProvider.config.swapGainLossColor};return this.transformerProvider.generateView(r,a.Ai.WatchlistSummaryQuoteItem)});return(await Promise.all(o)).filter(s.z2)}getQuotesHelper(t){var e;if(t.cardSize===i.uE._1x_1y)return[];const r=(null===(e=this.firstListItem(t))||void 0===e?void 0:e.quotes)??null;if(!r)return null;return r.length?r.slice(0,this.quotesMaxLength(t)):null}quotesMaxLength(t){return t.cardSize===i.uE._1x_1y?0:t.cardSize===i.uE._1x_3y?8:4}isWithLogo(t){return this.isLogoUrlPresentInQuotes(t)||(null===o.T3||void 0===o.T3?void 0:o.T3.CurrentMarket)&&"en-us"==(null===o.T3||void 0===o.T3?void 0:o.T3.CurrentMarket.toLowerCase())}isLogoUrlPresentInQuotes(t){const e=this.getQuotesHelper(t);if(!e)return null;return e.map(t=>(0,s.zH)(t.iconUrl||"")).filter(Boolean).length>=1}annualReturnStringForSummary(t){return this.annualReturn(t)>0?`+${this.annualReturnString(t)}`:this.annualReturnString(t)}annualReturnString(t){return+(this.annualReturn(t)>1e3?this.annualReturn(t).toFixed(1):this.annualReturn(t).toFixed(2))+"%"}wlsQuotePerformance(t){var e,r;if(!this.listQuoteItem(t))return"";const i=(null===(e=this.listQuoteItem(t))||void 0===e?void 0:e.displayName)||"",a=this.getQuotePerformingText(t,null===(r=this.listQuoteItem(t))||void 0===r?void 0:r.changePcntNumber)||"";return(0,n.GP)(a,i)}getQuotePerformingText(t,e){return this.annualReturn(t)>e?this.transformerProvider.strings.wlsOutPerformingQuote:this.annualReturn(t)<e?this.transformerProvider.strings.wlsUnderPerformingQuote:this.transformerProvider.strings.wlsMatchedPerforming}listQuoteItem(t){var e;return(null===(e=t.tabData)||void 0===e?void 0:e.indexQuoteItem)??null}getTitleText(){return this.transformerProvider.strings.watchlistsummaryTitleText||""}isVerticalWatchlist(t){const e=this.getQuotesHelper(t),r=t.cardSize===i.uE._1x_2y?3:5;return(null==e?void 0:e.length)<r}getWidgetAppTypeClass(){return this.transformerProvider.config.isDynamicFeed?"winDsh":""}getSignal(t){return t>0?a.KH.Gainer:a.KH.Loser}iconUrl(t){const e=this.annualReturn(t);return(0,l.kX)(this.transformerProvider.config.urls,e,a.Ex.WatchlistSummary,this.transformerProvider.config.swapGainLossColor,this.getSignal(e))}async getCurrentViewModel(t){const e=await this.getSummaryQuotes(t);return{annualReturn:this.annualReturn(t),annualReturnStringForSummary:this.annualReturnStringForSummary(t),data:t.tabData,destinationUrl:t.destinationUrl,openLinksInNewTab:this.transformerProvider.config.openLinksInNewTab,iconUrl:this.iconUrl(t),isVerticalList:this.isVerticalWatchlist(t),isWithLogo:this.isWithLogo(t),listItemColor:this.getListItemColor(t),quotes:e,experienceName:t.experienceName,strings:{...this.transformerProvider.strings},tabName:t.tabName,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{name:a.CD.watchlistSummary,signature:t.signature,headline:t.tabName}),titleText:this.getTitleText(),widgetAppTypeClass:this.getWidgetAppTypeClass(),widgetSize:(0,s.CP)(t.cardSize),wlsQuotePerformance:this.wlsQuotePerformance(t)}}}class g extends a.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getPriceColor(t,e){const r=this.getPcnt(t);return(0,s.BK)((0,s.jJ)(),r,e)}getPcntValue(t){const e=this.getPcnt(t);return`${this.getPriceDirection(e)}${e}%`}getPcnt(t){const e=t.changePcntNumber;return e?Math.round(e):0}getPriceDirection(t){return t>0?"+":""}getIconURL(t){const e=t.quote;return(0,s.Mx)(e)&&e.symbol.length>=3?(0,s.A0)(e.symbol.slice(-3)):(0,s.nZ)(e,50,50,0)}async getViewModel(t){return{cardSize:t.cardSize,iconUrl:this.getIconURL(t),isCurrencySecurityType:(0,s.Mx)(t.quote),isVertical:t.isVertical,isWithLogo:t.isWithLogo,logoLink:(0,s.nZ)(t.quote),pcntValue:this.getPcntValue(t.quote),priceColor:this.getPriceColor(t.quote,t.swapGainLossColor),symbol:t.quote.symbol,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.parentTelemetryObject,{name:a.CD.quoteItemClick,signature:t.signature,headline:t.quote.symbol,id:t.quote.id})}}}Promise.resolve().then(r.bind(r,87941)),Promise.resolve().then(r.bind(r,64827))},64827(t,e,r){r.r(e),r.d(e,{WatchlistSummaryQuoteItem(){return x}});var i=r(56911),a=r(95296);class s extends a.m{}var n=r(92011),o=r(86856),l=r(74849);const d=l.A`
`,h=l.A` .wls .vert .qimg{margin-left:8px;margin-right:0}.wls.large .vert .qimg{margin-left:12px;margin-right:0}`,g=l.A` :host{--starndard-green:#0B7B24;--standard-red:#BF3401;--standard-blue:#0078D4;--standard-grey:rgba(0,0,0,0.54)}.semibold{font-weight:600}.qimg{width:32px;height:32px;border-radius:50%;box-sizing:border-box;object-fit:contain}.hlstItm{display:grid;align-items:center;justify-content:center;justify-self:stretch;row-gap:4px}.hlstItm > span,.hlstItm > img{justify-self:center}.qts{font-weight:600;text-align:center;white-space:nowrap;min-width:40px}.horz .qts{overflow:hidden;text-overflow:clip;width:46px}.qps{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.symb{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);max-width:none}.hlstItm{row-gap:0;width:40px}.curr .qimg{border-radius:0}.qimg,.qimg-empty{width:32px;height:32px;margin-bottom:8px;justify-self:center}.qimg-empty svg{width:100%;height:100%}.vert .qimg{margin-left:8px;margin-right:0}.large .vert .qimg{margin-left:12px;margin-right:0}.vert .hlstItm .qps{justify-self:flex-start;margin:0 6px;font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px)}.vert .qts{text-align:initial;min-width:initial}.vert .hlstItm{width:100%;gap:5px;grid-template-columns:40px min-content 1fr}.large .vert .hlstItm{grid-template-columns:52px min-content 1fr}.vert .qimg{margin-right:8px;margin-bottom:0}.large .vert .qimg{margin-right:12px;margin-bottom:0}.large .vert .qimg,.large .vert .qimg-empty{width:40px;height:40px}`.withBehaviors(new o.t(d,h));var c=r(96950),p=r(69259);const u=`${(0,r(58792).rA)().StaticsUrl}latest/money/icons/StockEmptyStateCircle.svg`,m=c.qy`<span class="qps semibold" style="color: ${t=>t.viewModel.priceColor}">${t=>t.viewModel.pcntValue}</span>`,f=c.qy`<div class="${t=>t.viewModel.cardSize}" title="${t=>t.viewModel.symbol}"><div class="${t=>t.viewModel.isVertical?"vert":"horz"}"><div class="hlstItm ${t=>t.viewModel.isCurrencySecurityType?"curr":""}">${(0,p.z)(t=>t.viewModel.isWithLogo,c.qy` ${t=>t.viewModel.iconUrl?c.qy`<img class="qimg" src="${t=>t.viewModel.iconUrl}" alt="" loading=lazy/>`:c.qy`<div class="qimg qimg-empty"><img class="logo" src=${u} alt=${t=>t.viewModel.symbol}></div>`} `)}<span class="symb qts">${t=>t.viewModel.symbol}</span>${m}</div></div></div>`;let x=class extends s{};x=(0,i.Cg)([(0,n.E)({name:"watchlist-summary-quote-item",template:f,styles:g,shadowOptions:{delegatesFocus:!0}})],x)},87941(t,e,r){r.r(e),r.d(e,{WatchlistSummary(){return w}});var i=r(56911),a=r(92707);class s extends a.z{onSizeChange(t){}onChartDictChange(t){}}var n=r(92011),o=r(86856),l=r(12640),d=r(74849),h=r(4968);const g=d.A` .wls .pcnt-str{margin-left:6px}.wls.small .pcnt-str{margin-left:2px}.wls.small .lbl{margin-left:8px}`,c=d.A` .wls .pcnt-str{margin-right:6px}.wls.small .pcnt-str{margin-right:2px}.wls.small .lbl{margin-right:8px}`,p=d.A` :host{--starndard-green:#02E176 !important;--standard-red:#FFAB8C !important;--standard-blue:#63ADE5 !important;--standard-grey:rgba(255,255,255,0.54) !important}`,u=d.A` .wls-wrapper{text-decoration:none;color:inherit;${h.f}}.wls{height:100%;border-radius:8px}.wls-quote-wrapper{background:var(--quote-background)}:host{--starndard-green:#0B7B24;--standard-red:#BF3401;--standard-blue:#0078D4;--standard-grey:rgba(0,0,0,0.54)}ul{list-style:none;padding-inline-start:0}.semibold{font-weight:600}.wls-quote-wrapper{margin:0;border-radius:8px;padding:8px 12px;flex:1}.wls .hlstCtr{display:grid;max-width:100%;grid-template-columns:repeat(4,auto);justify-content:space-between;align-items:center;overflow:hidden;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600;margin:0}.wls .card{display:flex;flex-direction:column;justify-content:space-between;border-radius:6px;background:var(--quote-view-background);width:268px;box-sizing:border-box;height:100%;gap:12px}.wls.small .card{padding:8px 12px}.wls .header{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);font-weight:600;margin-bottom:8px}.wls.small .header{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600}.wls.small .info{display:flex;justify-content:space-between}.wls .pcnt{font-size:var(--type-ramp-plus-4-font-size,28px);line-height:var(--type-ramp-plus-4-line-height,36px);font-weight:600;display:flex;align-items:center;margin-bottom:4px}.wls.small .pcnt{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.wls .lbl{font-weight:600;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:var(--standard-grey);margin-top:2px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.wls .quote-lbl{font-weight:600;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:var(--standard-grey);margin-bottom:8px}.wls.large .hlstCtr{margin-top:48px}.large.wls .hlstCtr{row-gap:20px}.wls.large .pcnt svg{width:28px;height:28px}.wls .icon{width:24px;height:24px;margin-top:4px}.wls.small .icon{width:16px;height:16px;margin-top:2px}.wls.small .lbl{margin-top:0;margin-bottom:4px}.wls .hlstCtr.vert{grid-template-columns:1fr;grid-row-gap:12px;margin-top:5px;margin-bottom:auto}.large .vert.hlstCtr{row-gap:14px}.vert .card{justify-content:flex-start}.wls.large .vert.hlstCtr{margin-bottom:auto}`.withBehaviors(new l.N(null,p),new o.t(g,c));var m=r(96950),f=r(39957),x=r(69259);const v=m.qy`<div class="wls-quote-wrapper"><div class="quote-lbl">${t=>t.viewModel.strings.wlsSomeTopMovers||""}</div><div class="hlstCtr ${t=>t.viewModel.isVerticalList?"vert":""}">${(0,f.ux)(t=>t.viewModel.quotes,m.qy`<watchlist-summary-quote-item :viewModel="${t=>t.viewModel}"></watchlist-summary-quote-item>`)}</div></div>`,b=m.qy`<a role="link" href="${t=>t.viewModel.destinationUrl}" target="${t=>t.viewModel.openLinksInNewTab?"_blank":"_self"}" data-t="${t=>t.viewModel.telemetryTag}" tabindex="-1" class="wls-wrapper"><div class="wls ${t=>t.viewModel.widgetAppTypeClass} ${t=>t.viewModel.widgetSize} "><div class="card"><div><div class="header" title="${t=>t.viewModel.strings.wlsTodaysReturn||""}">${t=>t.viewModel.strings.wlsTodaysReturn||""}</div><div class="info"><span class="pcnt semibold" style="color: ${t=>t.viewModel.listItemColor}">${(0,x.z)(t=>t.viewModel.annualReturn,m.qy`<img class="icon" src="${t=>t.viewModel.iconUrl}" alt="" loading=lazy>`)}<span class="pcnt-str" title="${t=>t.viewModel.annualReturnStringForSummary}">${t=>t.viewModel.annualReturnStringForSummary}</span></span><div class="lbl" title="${t=>t.viewModel.wlsQuotePerformance}">${t=>t.viewModel.wlsQuotePerformance}</div></div></div>${(0,x.z)(t=>"small"!==t.viewModel.widgetSize,v)}</div></div></a>`;let w=class extends s{};w=(0,i.Cg)([(0,n.E)({name:"watchlist-summary",template:b,styles:u,shadowOptions:{delegatesFocus:!0}})],w)},92707(t,e,r){r.d(e,{z(){return l}});var i=r(56911),a=r(27208),s=r(60815),n=r(92011),o=r(31525);let l=class extends n.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return a.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const t=this.getState();t&&(t.subscribe(a.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(t){}onChartDictChange(t){}onShowNotificationTextChange(t){}onQuoteItemDictChange(t){}onCardWidthChanged(t){}};(0,i.Cg)([s.sH],l.prototype,"viewModel",void 0),l=(0,i.Cg)([o.x],l)},95296(t,e,r){r.d(e,{m(){return n}});var i=r(56911),a=r(60815),s=r(92011);class n extends s.L{}(0,i.Cg)([a.sH],n.prototype,"viewModel",void 0)},99657(t,e,r){r.d(e,{D(){return n},I(){return s}});var i=r(45755);const{create:a}=i.G,s=a("sloppy-click-z-index",1),n=a("click-z-index",1)}}]);