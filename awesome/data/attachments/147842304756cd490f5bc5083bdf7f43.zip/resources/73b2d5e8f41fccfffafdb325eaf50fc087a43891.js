// © Microsoft Corporation. All rights reserved.
import { artical10TelemetryObject, artical1TelemetryObject, artical2TelemetryObject, artical3TelemetryObject, artical4TelemetryObject, artical5TelemetryObject, artical6TelemetryObject, artical7TelemetryObject, artical8TelemetryObject, artical9TelemetryObject, bannerTelemetryObject, footerTelemetryObject, infopaneTelemetryObject, mobartical10TelemetryObject, mobartical1TelemetryObject, mobartical2TelemetryObject, mobartical3TelemetryObject, mobartical4TelemetryObject, mobartical5TelemetryObject, mobartical6TelemetryObject, mobartical7TelemetryObject, mobartical8TelemetryObject, mobartical9TelemetryObject, mobnativeAds0TelemetryObject, mobnativeAds1TelemetryObject, mobnativeAds2TelemetryObject, mobnativeAds3TelemetryObject, msnLogoTelemetryObject, nativeAds0TelemetryObject, nativeAds1TelemetryObject, nativeAds2TelemetryObject, nativeAds3TelemetryObject, searchButtonTelemetryObject } from "./IE11NTPHomepage.telemetry";
import { BackfillIds } from "@msnews/experiences-constants";
import { IE11NTPLocalisation } from "./Localisation";
import { MsnHpLeadgenAdsPromoIdsMap } from "./Leadgen";
import { appNexusAdsWrapper } from "./AppNexusAdsWrapper";
import { headData } from "@msnews/core";
// Get FeedAPI,Native ADS Response
// load Native ADS and article
export function getFeed() {
    let infopaneCount = 0;
    const locale = headData.Locale;
    const jsonAPI = "https://assets.msn.com/service/MSN/Feed/me?$top=32&DisableTypeSerialization=true&activityId=7FF05383-E874-420B-A4A9-263700520B95&apikey=Io4orNtwRr08vQQBER8stWzJbGltMJzMwkmiMOv9z3&cm=" + locale + "&contentType=article,video,slideshow,link,content360&delta=true&infopaneCount=24&location=47.7159|-122.204&ocid=msndl&queryType=myfeed&responseSchema=cardview&timeOut=1000&user=m-34506447AA77621236DF6B41ABAB635A&wrapodata=false";
    $.getJSON(jsonAPI, {
        format: "json"
    })
        .done(function (res) {
        setTimeout(() => {
            getNativeADS(locale);
        }, 800);
        if (res && res.subCards[0] && res.subCards[0].subCards[infopaneCount].url && res.subCards[0].subCards[infopaneCount].images && res.subCards[0].subCards[infopaneCount].images[0].url && res.subCards[0].subCards[infopaneCount].provider && res.subCards[0].subCards[infopaneCount].provider.logoUrl && res.subCards[0].subCards[infopaneCount].provider.name && res.subCards[0].subCards[infopaneCount].title) {
            infopaneCount = infopaneCount + 1;
            $("#Infopane-image-1").append("<a href = '" + res.subCards[0].subCards[infopaneCount].url + "' target='_blank'> <img width = 620px class='infopane-image' src = '" + res.subCards[0].subCards[infopaneCount].images[0].url + "&w=620&h=304&qlt=90&c=1&rs=1" + "' height = 304px /></a>");
            $("#Infopane-title-1").append("<a target='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "'' class='Infopane-title'>" + res.subCards[0].subCards[infopaneCount].title + "</a>");
            $("#Infopane-image-Icon-1").append("<a target='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "'' ><img  src = '" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "' class='Infopane-icon'/><p class='Infopane-kicker'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p></a>");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#Infopane-image-1").append("<a href = '" + res.subCards[0].subCards[infopaneCount].url + "' target='_blank'> <img width = 620px class='infopane-image' src = '" + res.subCards[0].subCards[infopaneCount].images[0].url + "&w=620&h=304&qlt=90&c=1&rs=1" + "' height = 304px /></a>");
            $("#Infopane-title-1").append("<a target='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "'' class='Infopane-title'>" + res.subCards[0].subCards[infopaneCount].title + "</a>");
            $("#Infopane-image-Icon-1").append("<a target='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "'' ><img  src = '" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "' class='Infopane-icon'/><p class='Infopane-kicker'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p></a>");
        }
        if (res && res.subCards[0] && res.subCards[0].subCards[infopaneCount] && res.subCards[0].subCards[infopaneCount].url && res.subCards[0].subCards[infopaneCount].images && res.subCards[0].subCards[infopaneCount].images[0].url && res.subCards[0].subCards[infopaneCount].provider && res.subCards[0].subCards[infopaneCount].provider.logoUrl && res.subCards[0].subCards[infopaneCount].provider.name && res.subCards[0].subCards[infopaneCount].title) {
            infopaneCount = infopaneCount + 1;
            $("#artical1").append("<a target ='_blank'  href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical1Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#articalTitle").html(res.subCards[0].subCards[infopaneCount].title);
            $("#articalTitle").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#articalTitle").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical1").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical1Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#articalTitle").html(res.subCards[0].subCards[infopaneCount].title);
            $("#articalTitle").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#articalTitle").attr("target", "_blank");
        }
        if (res && res.subCards[0] && res.subCards[0].subCards[infopaneCount] && res.subCards[0].subCards[infopaneCount].url && res.subCards[0].subCards[infopaneCount].images && res.subCards[0].subCards[infopaneCount].images[0].url && res.subCards[0].subCards[infopaneCount].provider && res.subCards[0].subCards[infopaneCount].provider.logoUrl && res.subCards[0].subCards[infopaneCount].provider.name && res.subCards[0].subCards[infopaneCount].title) {
            infopaneCount = infopaneCount + 1;
            $("#artical2").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical2Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica2Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica2Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica2Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical2").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical2Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica2Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica2Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica2Title").attr("target", "_blank");
        }
        if (res && res.subCards[infopaneCount] && res.subCards[infopaneCount].url && res.subCards[infopaneCount].images && res.subCards[infopaneCount].images[0].url && res.subCards[infopaneCount].provider && res.subCards[infopaneCount].provider.logoUrl && res.subCards[infopaneCount].provider.name && res.subCards[infopaneCount].title) {
            $("#artical3").append("<a target ='_blank' href='" + res.subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical3Icon").append("<img height=16px width=16px src='" + res.subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'> " + res.subCards[infopaneCount].provider.name + "</p>");
            $("#artica3Title").html(res.subCards[infopaneCount].title);
            $("#artica3Title").attr("href", res.subCards[infopaneCount].url);
            $("#artica3Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical3").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical3Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica3Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica3Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica3Title").attr("target", "_blank");
        }
        if (res && res.subCards[2] && res.subCards[2].url && res.subCards[2].images && res.subCards[2].images[0].url && res.subCards[2].provider && res.subCards[2].provider.logoUrl && res.subCards[2].provider.name && res.subCards[2].title) {
            $("#artical4").append("<a target ='_blank' href='" + res.subCards[2].url + "' class='title-link'><img src='" + imageResizer(res.subCards[2].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical4Icon").append("<img height=16px width=16px src='" + res.subCards[2].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[2].provider.name + "</p>");
            $("#artica4Title").html(res.subCards[2].title);
            $("#artica4Title").attr("href", res.subCards[2].url);
            $("#artica4Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical4").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical4Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica4Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica4Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica4Title").attr("target", "_blank");
        }
        if (res && res.subCards[3] && res.subCards[3].url && res.subCards[3].images && res.subCards[3].images[0].url && res.subCards[3].provider && res.subCards[3].provider.logoUrl && res.subCards[3].provider.name && res.subCards[3].title) {
            $("#artical5").append("<a target ='_blank' href='" + res.subCards[3].url + "' class='title-link'><img src='" + imageResizer(res.subCards[3].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical5Icon").append("<img height=16px width=16px src='" + res.subCards[3].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[3].provider.name + "</p>");
            $("#artica5Title").html(res.subCards[3].title);
            $("#artica5Title").attr("href", res.subCards[3].url);
            $("#artica5Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical5").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical5Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica5Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica5Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica5Title").attr("target", "_blank");
        }
        if (res && res.subCards[4] && res.subCards[4].url && res.subCards[4].images && res.subCards[4].images[0].url && res.subCards[4].provider && res.subCards[4].provider.logoUrl && res.subCards[4].provider.name && res.subCards[4].title) {
            $("#artical6").append("<a target ='_blank' href='" + res.subCards[4].url + "' class='title-link'><img src='" + imageResizer(res.subCards[4].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical6Icon").append("<img height=16px width=16px src='" + res.subCards[4].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[4].provider.name + "</p>");
            $("#artica6Title").html(res.subCards[4].title);
            $("#artica6Title").attr("href", res.subCards[4].url);
            $("#artica6Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical6").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical6Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica6Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica6Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica6Title").attr("target", "_blank");
        }
        if (res && res.subCards[5] && res.subCards[5].url && res.subCards[5].images && res.subCards[5].images[0].url && res.subCards[5].provider && res.subCards[5].provider.logoUrl && res.subCards[5].provider.name && res.subCards[5].title) {
            $("#artical7").append("<a target ='_blank' href='" + res.subCards[5].url + "' class='title-link'><img src='" + imageResizer(res.subCards[5].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical7Icon").append("<img height=16px width=16px src='" + res.subCards[5].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[5].provider.name + "</p>");
            $("#artica7Title").html(res.subCards[5].title);
            $("#artica7Title").attr("href", res.subCards[5].url);
            $("#artica7Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical7").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical7Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica7Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica7Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica7Title").attr("target", "_blank");
        }
        if (res && res.subCards[6] && res.subCards[6].url && res.subCards[6].images && res.subCards[6].images[0].url && res.subCards[6].provider && res.subCards[6].provider.logoUrl && res.subCards[6].provider.name && res.subCards[6].title) {
            $("#artical8").append("<a target ='_blank' href='" + res.subCards[6].url + "' class='title-link'><img src='" + imageResizer(res.subCards[6].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical8Icon").append("<img height=16px width=16px src='" + res.subCards[6].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[6].provider.name + "</p>");
            $("#artica8Title").html(res.subCards[6].title);
            $("#artica8Title").attr("href", res.subCards[6].url);
            $("#artica8Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical8").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical8Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica8Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica8Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica8Title").attr("target", "_blank");
        }
        if (res && res.subCards[7] && res.subCards[7].url && res.subCards[7].images && res.subCards[7].images[0].url && res.subCards[7].provider && res.subCards[7].provider.logoUrl && res.subCards[7].provider.name && res.subCards[7].title) {
            $("#artical9").append("<a target ='_blank' href='" + res.subCards[7].url + "' class='title-link'><img src='" + imageResizer(res.subCards[7].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical9Icon").append("<img height=16px width=16px src='" + res.subCards[7].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[7].provider.name + "</p>");
            $("#artica9Title").html(res.subCards[7].title);
            $("#artica9Title").attr("href", res.subCards[7].url);
            $("#artica9Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical9").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical9Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica9Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica9Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica9Title").attr("target", "_blank");
        }
        if (res && res.subCards[8] && res.subCards[8].url && res.subCards[8].images && res.subCards[8].images[0].url && res.subCards[8].provider && res.subCards[8].provider.logoUrl && res.subCards[8].provider.name && res.subCards[8].title) {
            $("#artical10").append("<a target ='_blank' href='" + res.subCards[8].url + "' class='title-link'><img src='" + imageResizer(res.subCards[8].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical10Icon").append("<img height=16px width=16px src='" + res.subCards[8].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[8].provider.name + "</p>");
            $("#artica10Title").html(res.subCards[8].title);
            $("#artica10Title").attr("href", res.subCards[8].url);
            $("#artica10Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#artical10").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#artical10Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#artica10Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#artica10Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#artica10Title").attr("target", "_blank");
        }
        // Mobile
        if (res && res.subCards[0] && res.subCards[0].subCards[infopaneCount] && res.subCards[0].subCards[infopaneCount].url && res.subCards[0].subCards[infopaneCount].images && res.subCards[0].subCards[infopaneCount].images[0].url && res.subCards[0].subCards[infopaneCount].provider && res.subCards[0].subCards[infopaneCount].provider.logoUrl && res.subCards[0].subCards[infopaneCount].provider.name && res.subCards[0].subCards[infopaneCount].title) {
            infopaneCount = infopaneCount + 1;
            $("#mobartical1").append("<a target ='_blank'  href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical1Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobarticalTitle").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobarticalTitle").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobarticalTitle").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical1").append("<a target ='_blank'  href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical1Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobarticalTitle").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobarticalTitle").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobarticalTitle").attr("target", "_blank");
        }
        if (res && res.subCards[0] && res.subCards[0].subCards[2] && res.subCards[0].subCards[2].url && res.subCards[0].subCards[2].images && res.subCards[0].subCards[2].images[0].url && res.subCards[0].subCards[2].provider && res.subCards[0].subCards[2].provider.logoUrl && res.subCards[0].subCards[2].provider.name && res.subCards[0].subCards[2].title) {
            infopaneCount = infopaneCount + 1;
            $("#mobartical2").append("<a target ='_blank' href='" + res.subCards[0].subCards[2].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[2].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical2Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[2].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[2].provider.name + "</p>");
            $("#mobartica2Title").html(res.subCards[0].subCards[2].title);
            $("#mobartica2Title").attr("href", res.subCards[0].subCards[2].url);
            $("#mobartica2Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical2").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical2Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobartical2Icon").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobartical2Icon").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobartical2Icon").attr("target", "_blank");
        }
        if (res && res.subCards[infopaneCount] && res.subCards[infopaneCount].url && res.subCards[infopaneCount].images && res.subCards[infopaneCount].images[0].url && res.subCards[infopaneCount].provider && res.subCards[infopaneCount].provider.logoUrl && res.subCards[infopaneCount].provider.name && res.subCards[infopaneCount].title) {
            $("#mobartical3").append("<a target ='_blank' href='" + res.subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical3Icon").append("<img height=16px width=16px src='" + res.subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[infopaneCount].provider.name + "</p>");
            $("#mobartica3Title").html(res.subCards[infopaneCount].title);
            $("#mobartica3Title").attr("href", res.subCards[infopaneCount].url);
            $("#mobartica3Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical3").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical3Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobartica3Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobartica3Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobartica3Title").attr("target", "_blank");
        }
        if (res && res.subCards[2] && res.subCards[2].url && res.subCards[2].images && res.subCards[2].images[0].url && res.subCards[2].provider && res.subCards[2].provider.logoUrl && res.subCards[2].provider.name && res.subCards[2].title) {
            $("#mobartical4").append("<a target ='_blank' href='" + res.subCards[2].url + "' class='title-link'><img src='" + imageResizer(res.subCards[2].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical4Icon").append("<img height=16px width=16px src='" + res.subCards[2].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[2].provider.name + "</p>");
            $("#mobartica4Title").html(res.subCards[2].title);
            $("#mobartica4Title").attr("href", res.subCards[2].url);
            $("#mobartica4Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical4").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical4Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobartica4Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobartica4Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobartica4Title").attr("target", "_blank");
        }
        if (res && res.subCards[3] && res.subCards[3].url && res.subCards[3].images && res.subCards[3].images[0].url && res.subCards[3].provider && res.subCards[3].provider.logoUrl && res.subCards[3].provider.name && res.subCards[3].title) {
            $("#mobartical5").append("<a target ='_blank' href='" + res.subCards[3].url + "' class='title-link'><img src='" + imageResizer(res.subCards[3].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical5Icon").append("<img height=16px width=16px src='" + res.subCards[3].provider.logoUrl + "'> <p class='Iconstyle'>" + res.subCards[3].provider.name + "</p>");
            $("#mobartica5Title").html(res.subCards[3].title);
            $("#mobartica5Title").attr("href", res.subCards[3].url);
            $("#mobartica5Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical5").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical5Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobartica5Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobartica5Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobartica5Title").attr("target", "_blank");
        }
        if (res && res.subCards[4] && res.subCards[4].url && res.subCards[4].images && res.subCards[4].images[0].url && res.subCards[4].provider && res.subCards[4].provider.logoUrl && res.subCards[4].provider.name && res.subCards[4].title) {
            $("#mobartical6").append("<a target ='_blank' href='" + res.subCards[4].url + "' class='title-link'><img src='" + imageResizer(res.subCards[4].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical6Icon").append("<img height=16px width=16px src='" + res.subCards[4].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[4].provider.name + "</p>");
            $("#mobartica6Title").html(res.subCards[4].title);
            $("#mobartica6Title").attr("href", res.subCards[4].url);
            $("#mobartica6Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical6").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical6Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobartica6Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobartica6Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobartica6Title").attr("target", "_blank");
        }
        if (res && res.subCards[5] && res.subCards[5].url && res.subCards[5].images && res.subCards[5].images[0].url && res.subCards[5].provider && res.subCards[5].provider.logoUrl && res.subCards[5].provider.name && res.subCards[5].title) {
            $("#mobartical7").append("<a target ='_blank' href='" + res.subCards[5].url + "' class='title-link'><img src='" + imageResizer(res.subCards[5].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical7Icon").append("<img height=16px width=16px src='" + res.subCards[5].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[5].provider.name + "</p>");
            $("#mobartica7Title").html(res.subCards[5].title);
            $("#mobartica7Title").attr("href", res.subCards[5].url);
            $("#mobartica7Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical7").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical7Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobartica7Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobartica7Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobartica7Title").attr("target", "_blank");
        }
        if (res && res.subCards[6] && res.subCards[6].url && res.subCards[6].images && res.subCards[6].images[0].url && res.subCards[6].provider && res.subCards[6].provider.logoUrl && res.subCards[6].provider.name && res.subCards[6].title) {
            $("#mobartical8").append("<a target ='_blank' href='" + res.subCards[6].url + "' class='title-link'><img src='" + imageResizer(res.subCards[6].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical8Icon").append("<img height=16px width=16px src='" + res.subCards[6].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[6].provider.name + "</p>");
            $("#mobartica8Title").html(res.subCards[6].title);
            $("#mobartica8Title").attr("href", res.subCards[6].url);
            $("#mobartica8Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical8").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical8Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobartica8Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobartica8Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobartica8Title").attr("target", "_blank");
        }
        if (res && res.subCards[7] && res.subCards[7].url && res.subCards[7].images && res.subCards[7].images[0].url && res.subCards[7].provider && res.subCards[7].provider.logoUrl && res.subCards[7].provider.name && res.subCards[7].title) {
            $("#mobartical9").append("<a target ='_blank' href='" + res.subCards[7].url + "' class='title-link'><img src='" + imageResizer(res.subCards[7].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical9Icon").append("<img height=16px width=16px src='" + res.subCards[7].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[7].provider.name + "</p>");
            $("#mobartica9Title").html(res.subCards[7].title);
            $("#mobartica9Title").attr("href", res.subCards[7].url);
            $("#mobartica9Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical9").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical9Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobartica9Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobartica9Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobartica9Title").attr("target", "_blank");
        }
        if (res && res.subCards[8] && res.subCards[8].url && res.subCards[8].images && res.subCards[8].images[0].url && res.subCards[8].provider && res.subCards[8].provider.logoUrl && res.subCards[8].provider.name && res.subCards[8].title) {
            $("#mobartical10").append("<a target ='_blank' href='" + res.subCards[8].url + "' class='title-link'><img src='" + imageResizer(res.subCards[8].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical10Icon").append("<img height=16px width=16px src='" + res.subCards[8].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[8].provider.name + "</p>");
            $("#mobartica10Title").html(res.subCards[8].title);
            $("#mobartica10Title").attr("href", res.subCards[8].url);
            $("#mobartica10Title").attr("target", "_blank");
        }
        else {
            infopaneCount = infopaneCount + 1;
            $("#mobartical10").append("<a target ='_blank' href='" + res.subCards[0].subCards[infopaneCount].url + "' class='title-link'><img src='" + imageResizer(res.subCards[0].subCards[infopaneCount].images[0].url) + "' class='ads-card-img'></a>");
            $("#mobartical10Icon").append("<img height=16px width=16px src='" + res.subCards[0].subCards[infopaneCount].provider.logoUrl + "'><p class='Iconstyle'> " + res.subCards[0].subCards[infopaneCount].provider.name + "</p>");
            $("#mobartica10Title").html(res.subCards[0].subCards[infopaneCount].title);
            $("#mobartica10Title").attr("href", res.subCards[0].subCards[infopaneCount].url);
            $("#mobartica10Title").attr("target", "_blank");
        }
        const searchIconbth = document.querySelector("#search-button-telemetry");
        searchIconbth.addEventListener("click", searchIcon, false);
        $("#txtSearch").attr("data-t", searchButtonTelemetryObject?.getMetadataTag());
        $("#search-button-telemetry").attr("data-t", searchButtonTelemetryObject?.getMetadataTag());
        $("#txtSearch").on("keydown", function search(e) {
            if (e.key === "Enter") {
                $("#search-button-telemetry").trigger("click");
            }
        });
        const divLogo = document.querySelector("#divLogo");
        divLogo.addEventListener("click", refreshPage, false);
        $("#divLogo").attr("data-t", msnLogoTelemetryObject?.getMetadataTag());
        $("#banner-telemetry").attr("data-t", bannerTelemetryObject?.getMetadataTag());
        $("#ie-mobile-telemetry1").attr("data-t", bannerTelemetryObject?.getMetadataTag());
        $("#ie-mobile-telemetry2").attr("data-t", bannerTelemetryObject?.getMetadataTag());
        $("#Infopane-image-1").attr("data-t", infopaneTelemetryObject?.getMetadataTag());
        $("#Infopane-title-1").attr("data-t", infopaneTelemetryObject?.getMetadataTag());
        $("#Infopane-image-Icon-1").attr("data-t", infopaneTelemetryObject?.getMetadataTag());
        $("#mobartical1").attr("data-t", mobartical1TelemetryObject?.getMetadataTag());
        $("#mobarticalTitle").attr("data-t", mobartical1TelemetryObject?.getMetadataTag());
        $("#artical1").attr("data-t", artical1TelemetryObject?.getMetadataTag());
        $("#articalTitle").attr("data-t", artical1TelemetryObject?.getMetadataTag());
        $("#artical2").attr("data-t", artical2TelemetryObject?.getMetadataTag());
        $("#artica2Title").attr("data-t", artical2TelemetryObject?.getMetadataTag());
        $("#mobartical2").attr("data-t", mobartical2TelemetryObject?.getMetadataTag());
        $("#mobartica2Title").attr("data-t", mobartical2TelemetryObject?.getMetadataTag());
        $("#artical3").attr("data-t", artical3TelemetryObject?.getMetadataTag());
        $("#artica3Title").attr("data-t", artical3TelemetryObject?.getMetadataTag());
        $("#mobartical3").attr("data-t", mobartical3TelemetryObject?.getMetadataTag());
        $("#mobartica3Title").attr("data-t", mobartical3TelemetryObject?.getMetadataTag());
        $("#artical4").attr("data-t", artical4TelemetryObject?.getMetadataTag());
        $("#artica4Title").attr("data-t", artical4TelemetryObject?.getMetadataTag());
        $("#mobartical4").attr("data-t", mobartical4TelemetryObject?.getMetadataTag());
        $("#mobartica4Title").attr("data-t", mobartical4TelemetryObject?.getMetadataTag());
        $("#artical5").attr("data-t", artical5TelemetryObject?.getMetadataTag());
        $("#artica5Title").attr("data-t", artical5TelemetryObject?.getMetadataTag());
        $("#mobartical5").attr("data-t", mobartical5TelemetryObject?.getMetadataTag());
        $("#mobartica5Title").attr("data-t", mobartical5TelemetryObject?.getMetadataTag());
        $("#artical6").attr("data-t", artical6TelemetryObject?.getMetadataTag());
        $("#artica6Title").attr("data-t", artical6TelemetryObject?.getMetadataTag());
        $("#mobartical6").attr("data-t", mobartical6TelemetryObject?.getMetadataTag());
        $("#mobartica6Title").attr("data-t", mobartical6TelemetryObject?.getMetadataTag());
        $("#artical7").attr("data-t", artical7TelemetryObject?.getMetadataTag());
        $("#artica7Title").attr("data-t", artical7TelemetryObject?.getMetadataTag());
        $("#mobartical7").attr("data-t", mobartical7TelemetryObject?.getMetadataTag());
        $("#mobartica7Title").attr("data-t", mobartical7TelemetryObject?.getMetadataTag());
        $("#artical8").attr("data-t", artical8TelemetryObject?.getMetadataTag());
        $("#artica8Title").attr("data-t", artical8TelemetryObject?.getMetadataTag());
        $("#mobartical8").attr("data-t", mobartical8TelemetryObject?.getMetadataTag());
        $("#mobartica8Title").attr("data-t", mobartical8TelemetryObject?.getMetadataTag());
        $("#artical9").attr("data-t", artical9TelemetryObject?.getMetadataTag());
        $("#artica9Title").attr("data-t", artical9TelemetryObject?.getMetadataTag());
        $("#mobartical9").attr("data-t", mobartical9TelemetryObject?.getMetadataTag());
        $("#mobartica9Title").attr("data-t", mobartical9TelemetryObject?.getMetadataTag());
        $("#artical10").attr("data-t", artical10TelemetryObject?.getMetadataTag());
        $("#artica10Title").attr("data-t", artical10TelemetryObject?.getMetadataTag());
        $("#mobartical10").attr("data-t", mobartical10TelemetryObject?.getMetadataTag());
        $("#mobartica10Title").attr("data-t", mobartical10TelemetryObject?.getMetadataTag());
        $("#spfooter").attr("data-t", footerTelemetryObject?.getMetadataTag());
        $("#mobspfooter").attr("data-t", footerTelemetryObject?.getMetadataTag());
    });
    marketLocalisation(locale);
    loadDisplayADS();
}
export function refreshPage(e) {
    e.preventDefault();
    window.location.reload();
}
function searchIcon(e) {
    e.preventDefault();
    window.open("https://www.bing.com/search?q=" + $("#txtSearch").val() + "&form=PRUSEN" + "&mkt=" + headData.Locale);
    return false;
}
function getNativeADS(locale) {
    const docId = MsnHpLeadgenAdsPromoIdsMap[locale] || BackfillIds[locale];
    const jsonAPI = "https://assets.msn.com/content/v1/cms/api/amp/Document/" + docId + "";
    $.getJSON(jsonAPI, {
        format: "json"
    })
        .done(function (res) {
        LoadNativeADS(res);
    });
}
function getEntityID(url) {
    const entityid = "https://img-s-msn-com.akamaized.net/tenant/amp/entityid/" + url?.substring(url?.lastIndexOf("/") + 1);
    return entityid;
}
function loadDisplayADS() {
    let isMobile = false;
    if (headData && headData.ClientSettings) {
        const clientSettings = headData.ClientSettings;
        isMobile = ((clientSettings.browser && clientSettings.browser.ismobile === "true") || clientSettings.deviceFormFactor === "phone" /* DeviceFormFactorType.Phone */);
    }
    if (!isMobile) {
        const head = document.head || document.getElementsByTagName("head")[0];
        // In desktop mode, the banner ad is hidden when the page has a small width
        const styleBanner = "@media screen and (max-width: 540px){.banner-container{ display: none; }}";
        const style = document.createElement("style");
        style.appendChild(document.createTextNode(styleBanner));
        head.appendChild(style);
    }
    appNexusAdsWrapper.renderAdWithRefresh("banner1");
}
function LoadNativeADS(nativeADSRespo) {
    nativeADSRespo.list.forEach((item, index) => {
        let adsHTML;
        let mobadsHTML = "";
        if (index <= 4) {
            adsHTML = "<div id = 'nativeImageAds" + index + "' ><a  target ='_blank' href='" + item?.link?.href + "' class='title-link'><img src='" + adImageResizer(getEntityID(item.link?.image?.href)) + "' class='ads-card-img'></a></div>";
            adsHTML += "<div class='content'> <div class='title'> <a id = 'nativeTitleAds" + index + "' class='title-link' href = '" + item?.link?.href + "' target = '_blank'> " + item?.link?.title + "</a> </div> </div> ";
            adsHTML += "<div class='ad-slug'> <div class='ad-tag'><a id = 'nativeTagAds" + index + "' target ='_blank' href='" + item?.link?.href + "' class='ad-link-text'> <p class='ad-tag-link'> Ad </p> </a> </div>";
            adsHTML += "<div class='ad-link'>" + item?.link?.kicker + "</div> </div> </div> ";
            $("#divAD_" + index + "").append(adsHTML);
            // Mobile Native ads
            mobadsHTML = "<div><a id = 'mobnativeImageAds" + index + "' target ='_blank' href='" + item?.link?.href + "' class='title-link'><img src='" + adImageResizer(getEntityID(item?.link?.image?.href)) + "' class='ads-card-img'></a></div>";
            mobadsHTML += "<div class='content'> <div class='title'> <a id = 'mobnativeTitleAds" + index + "' class='title-link' href = '" + item?.link?.href + "' target = '_blank'> " + item?.link?.title + "</a> </div> </div> ";
            mobadsHTML += "<div class='ad-slug'> <div class='ad-tag'><a id = 'mobnativeTagAds" + index + " target ='_blank' href='" + item?.link?.href + "' class='ad-link-text'> <p class='ad-tag-link'> Ad </p> </a> </div>";
            mobadsHTML += "<div class='ad-link'>" + item?.link?.kicker + "</div> </div> </div> ";
            $("#mobdivAD_" + index + "").append(mobadsHTML);
        }
        $("#nativeImageAds0").attr("data-t", nativeAds0TelemetryObject?.getMetadataTag());
        $("#nativeTitleAds0").attr("data-t", nativeAds0TelemetryObject?.getMetadataTag());
        $("#nativeTagAds0").attr("data-t", nativeAds0TelemetryObject?.getMetadataTag());
        $("#mobnativeImageAds0").attr("data-t", mobnativeAds0TelemetryObject?.getMetadataTag());
        $("#mobnativeTitleAds0").attr("data-t", mobnativeAds0TelemetryObject?.getMetadataTag());
        $("#mobnativeTagAds0").attr("data-t", mobnativeAds0TelemetryObject?.getMetadataTag());
        $("#nativeImageAds1").attr("data-t", nativeAds1TelemetryObject?.getMetadataTag());
        $("#nativeTitleAds1").attr("data-t", nativeAds1TelemetryObject?.getMetadataTag());
        $("#nativeTagAds1").attr("data-t", nativeAds1TelemetryObject?.getMetadataTag());
        $("#mobnativeImageAds1").attr("data-t", mobnativeAds1TelemetryObject?.getMetadataTag());
        $("#mobnativeTitleAds1").attr("data-t", mobnativeAds1TelemetryObject?.getMetadataTag());
        $("#mobnativeTagAds1").attr("data-t", mobnativeAds1TelemetryObject?.getMetadataTag());
        $("#nativeImageAds2").attr("data-t", nativeAds2TelemetryObject?.getMetadataTag());
        $("#nativeTitleAds2").attr("data-t", nativeAds2TelemetryObject?.getMetadataTag());
        $("#nativeTagAds2").attr("data-t", nativeAds2TelemetryObject?.getMetadataTag());
        $("#mobnativeImageAds2").attr("data-t", mobnativeAds2TelemetryObject?.getMetadataTag());
        $("#mobnativeTitleAds2").attr("data-t", mobnativeAds2TelemetryObject?.getMetadataTag());
        $("#mobnativeTagAds2").attr("data-t", mobnativeAds2TelemetryObject?.getMetadataTag());
        $("#nativeImageAds3").attr("data-t", nativeAds3TelemetryObject?.getMetadataTag());
        $("#nativeTitleAds3").attr("data-t", nativeAds3TelemetryObject?.getMetadataTag());
        $("#nativeTagAds3").attr("data-t", nativeAds3TelemetryObject?.getMetadataTag());
        $("#mobnativeImageAds3").attr("data-t", mobnativeAds3TelemetryObject?.getMetadataTag());
        $("#mobnativeTitleAds3").attr("data-t", mobnativeAds3TelemetryObject?.getMetadataTag());
        $("#mobnativeTagAds3").attr("data-t", mobnativeAds3TelemetryObject?.getMetadataTag());
    });
}
function marketLocalisation(locale) {
    const getLocalisation = IE11NTPLocalisation[locale];
    let footerHtml = "<span>© 2023 Microsoft |</span>";
    getLocalisation.footerItems.forEach((item, index) => {
        footerHtml += "<a target='_blank' href = '" + item?.href + "'>" + item?.Displaytext + "</a>";
    });
    $("#spfooter").append(footerHtml);
    $("#bannerTextHeadline").append(getLocalisation?.bannerTextHeadline);
    $("#bannerText").append(getLocalisation?.bannerText);
    $("#bannerButtonText").append(getLocalisation?.bannerButtonText);
    // Mobile
    $("#mobspfooter").append(footerHtml);
    $("#mobbannerTextHeadline").append(getLocalisation?.bannerTextHeadline);
    $("#mobbannerText").append(getLocalisation?.bannerText);
    $("#mobbuttontext").append(getLocalisation?.bannerButtonText);
}
function imageResizer(url) {
    const resizeUrl = url + "&w=300&h=157&qlt=90&c=1&rs=1";
    return resizeUrl;
}
function adImageResizer(url) {
    const resizeUrl = url + "?w=300&h=157&q=90";
    return resizeUrl;
}
//# sourceMappingURL=midlevel.js.map