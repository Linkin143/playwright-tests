"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["health-tip-wc"],{4332(e,t,i){i.d(t,{e3(){return o},fR(){return r}});var a=i(26220);function r(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,a.$t)();return/^python-requests|^CriteoBot|^ias-|GrapeshotCrawler/.test(e)}function o(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:(0,a.$t)();if(!e)return!1;const t=(0,a.iA)(),i=t&&t.includes("reqsrc=vp");return-1!==e.indexOf("Yahoo")||-1!==e.indexOf("Yandex")||-1!==e.indexOf("Baiduspider")||-1!==e.indexOf("Bingbot")||-1!==e.indexOf("Googlebot")||-1!==e.indexOf("Google-InspectionTool")||-1!==e.indexOf("msnbot")||!i&&-1!==e.indexOf("HeadlessChrome")}},6677(e,t,i){i.r(t),i.d(t,{HealthTipWC(){return U},HealthTipWCStyles(){return Ue},HealthTipWCTemplate(){return xe},ToolingInfo(){return _e}});var a=i(56911),r=i(33477),o=i(79201),n=i(22341),s=i(96951);const l="HealthTipCard",h="destination",c="healthtip_cardaction",d="moresettings",p="hide";var u,g;!function(e){e.ARTICLE_TIPS="landing_article_page",e.EXPERT_TIPS="landing_a_to_z_page",e.HARVARD_TIPS="landing_ask_professionals_page",e.FITNESS_TIPS="landing_fitness_page",e.HUB_TIPS="landing_healthub_page",e.CUSTOM_TIPS="new_year_new_you",e.BING_TIPS="landing_bing_l1_page"}(u||(u={})),function(e){e.HHP="HHP",e.FITNESS="Fitness",e.FOOD="Food",e.ARTICLE="Article",e.CONDITION="Condition",e.NUTRITION="Nutrition",e.WELLNESS="Wellness"}(g||(g={}));var b=i(85349),v=i(58792),$=i(12680),m=i(31422),x=i(29658),f=i(39671),k=i(17918),w=i(40865),y=i(26220),T=i(96950),C=i(55230),S=i(60815),O=i(71398),z=i(19359);class U extends f.U{constructor(){var e;super(...arguments),this.prongTelemetryObject={},this.healthTipData={},this.isEnableActionMenu=!0,this.isActionMenuOpen=!1,this.cardSize=r.uE._1x_2y,this.disableHeader=null===(e=(0,y.iA)())||void 0===e?void 0:e.includes("disableheader=1"),this.renderMoreSettingsIcon=()=>T.qy`<span class="more-settings-icon" style="width: 11px; height: auto; background-repeat: no-repeat; background-image: url(${(0,v.rA)().StaticsUrl}latest/health/health-growth/moreSettingsIcon.svg); display: inline-block;"></span>`,this.hideHealthCard=async()=>{try{let e=!1;return e=await O.d.updateSegmentCardsEnableStatus([{cardType:x.s.HealthCard,enabled:!1}]),e&&(this.refreshFeed?this.refreshFeed():this.$emit("refreshSDCardSection")),this.toggleActionMenu(!1,null),e}catch(e){return(0,n.c_)(e,s.Om,"Error in Health Tip Card WCE hide option"),!1}},this.moreSettingAction=()=>{this.toggleActionMenu(!1,null),this.$emit("goToPersonalizeSettingsCallback")},this.onOutsideClick=e=>{e.target instanceof U||(0,w.W)(this.actionsMenuButtonElement,e.composedPath()[0])||this.toggleActionMenu(!1,null)},this.onKeydown=e=>{e.key===C.F9&&this.toggleActionMenu(!1,null)},this.markVisualReadiness=()=>{this.markVisuallyReadyRaf()}}experienceConnected(){try{this.generateTelemetryTags(),this.hoverTelemetryHelper=new o.w(this.config.enableHover),this.actionsMenuProps=this.generateActionsMenuProps()}catch(e){(0,n.vV)(s.Om,"Error in Health Tip Card WCE experience Connected")}}getExperienceType(){return $.Lwu}generateTelemetryTags(){var e,t,i,a,r;this.telemetryObject&&(this.healthTipCardTelemetryObject=(0,z.g)(l,{vertical:"lifestyle",category:"health",type:b.b5.StructuredData},{type:b.MJ.HealthTipCard,ext:null===(e=this.parentTelemetry)||void 0===e||null===(e=e.contract)||void 0===e?void 0:e.ext}),this.healthTipCardTelemetryTag=this.healthTipCardTelemetryObject.getMetadataTag(),this.healthTipDestinationTelemetryTag=(0,z.g)(h,{id:this.healthTipData.debugInfo,vertical:"lifestyle",category:"health",type:b.b5.StructuredData},b.MS.Navigate,b.EG.Click,null===(t=this.parentTelemetry)||void 0===t||null===(t=t.contract)||void 0===t?void 0:t.ext,{type:b.MJ.HealthTipCard}).getMetadataTag(),this.ellipsisTelemetryTag=(0,z.g)(c,{vertical:"lifestyle",category:"health",type:b.b5.StructuredData},b.MS.More,b.EG.Click,null===(i=this.parentTelemetry)||void 0===i||null===(i=i.contract)||void 0===i?void 0:i.ext,{type:b.MJ.HealthTipCard}).getMetadataTag(),this.moreSettingsTelemetryTag=(0,z.g)(d,{vertical:"lifestyle",category:"health",type:b.b5.StructuredData},b.MS.Navigate,b.MJ.HealthTipCard,{ext:null===(a=this.parentTelemetry)||void 0===a||null===(a=a.contract)||void 0===a?void 0:a.ext}).getMetadataTag(),this.hideCardTelemetryTag=(0,z.g)(p,{vertical:"lifestyle",category:"health",type:b.b5.StructuredData},b.MS.Hide,b.MJ.HealthTipCard,{ext:null===(r=this.parentTelemetry)||void 0===r||null===(r=r.contract)||void 0===r?void 0:r.ext}).getMetadataTag(),this.config.isDynamicFeed&&(this.prongTelemetryObject={ellipsisTelemetryTag:this.ellipsisTelemetryTag,hideCardTelemetryTag:this.hideCardTelemetryTag,moreSettingsTelemetryTag:this.moreSettingsTelemetryTag,healthTipDestinationTelemetryTag:this.healthTipDestinationTelemetryTag,healthTipCardTelemetryTag:this.healthTipCardTelemetryTag}),this.config.isNTPFeed&&(this.feedTelemetryObject=this.healthTipDestinationTelemetryTag))}generateActionsMenuProps(){return{menuItems:this.getActionMenuItem()}}getActionMenuItem(){return[{id:"hide",glyph:m.A,title:this.strings.hideCardText,ariaLabel:this.strings.hideCardText,telemetryTag:this.hideCardTelemetryTag,onClick:async()=>{this.hideHealthCard()}},{id:"more",glyph:this.renderMoreSettingsIcon(),title:this.strings.moreSettingsText,ariaLabel:this.strings.moreSettingsText,telemetryTag:this.moreSettingsTelemetryTag,onClick:async()=>{this.moreSettingAction()}}]}toggleActionMenu(e,t){this.isActionMenuOpen=e,this.isActionMenuOpen?(this.actionsMenuButtonElement=t&&t.currentTarget,document.addEventListener("click",this.onOutsideClick),document.addEventListener("keydown",this.onKeydown)):(this.actionsMenuButtonElement=null,document.removeEventListener("click",this.onOutsideClick),document.removeEventListener("keydown",this.onKeydown))}shadowDomPopulated(){(0,k.tt)(this.getExperienceType())}}(0,a.Cg)([S.sH],U.prototype,"ellipsisTelemetryTag",void 0),(0,a.Cg)([S.sH],U.prototype,"moreSettingsTelemetryTag",void 0),(0,a.Cg)([S.sH],U.prototype,"hideCardTelemetryTag",void 0),(0,a.Cg)([S.sH],U.prototype,"healthTipCardTelemetryTag",void 0),(0,a.Cg)([S.sH],U.prototype,"healthTipDestinationTelemetryTag",void 0),(0,a.Cg)([S.sH],U.prototype,"prongTelemetryObject",void 0),(0,a.Cg)([S.sH],U.prototype,"feedTelemetryObject",void 0),(0,a.Cg)([S.sH],U.prototype,"healthTipData",void 0),(0,a.Cg)([S.sH],U.prototype,"isEnableActionMenu",void 0),(0,a.Cg)([S.sH],U.prototype,"isActionMenuOpen",void 0),(0,a.Cg)([S.sH],U.prototype,"actionsMenuProps",void 0),(0,a.Cg)([S.sH],U.prototype,"cardSize",void 0);var _=i(69259),D=i(47264),H=i(92011),M=i(38493),I=i(356),A=i(97004),P=i(70775),F=i(31756),L=i(34230),E=i(2171),N=i(4332);class R{static get baseUrlForBot(){return E.vv.get(this.baseUrlForBotKey,()=>(0,v.rA)().AssetsUrl+"/service/news/feed/segments/health")}static set baseUrlForBot(e){E.vv.set(this.baseUrlForBotKey,e)}static get healthOCID(){return E.vv.get(this.healthOCIDKey,()=>"health-verthp-feeds")}static set healthOCID(e){E.vv.set(this.healthOCIDKey,e)}static get baseUrlForPost(){return E.vv.get(this.baseUrlForPostKey,()=>"https://api.msn.com/segments/v0/items/Health/healthhub/healthhub")}static set baseUrlForPost(e){E.vv.set(this.baseUrlForPostKey,e)}static getHealth1SParams(e){let t=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];const i=[];return i.push({key:"$select",value:e}),i.push({key:"$top",value:"20"}),i.push({key:"noCache",value:"true"}),!1===t&&i.push({key:"ranid",value:`${Math.random().toString().replace("0.","")}`}),i}static async PostDataToOneServiceWithAuth(e,t){let i=!(arguments.length>2&&void 0!==arguments[2])||arguments[2],a=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"healthub/healthhub";return await this.PostDataToOneServiceInternal(!0,e,t,i,a)}static getPostServiceUrlWithCustomTimeout(e,t){let i=!(arguments.length>2&&void 0!==arguments[2])||arguments[2],a=arguments.length>3?arguments[3]:void 0;const r=(0,N.e3)()?new URL(this.baseUrlForBot):new URL(this.baseUrlForPost),o=this.getHealth1SParams(t,i);e?o.push(...F.WR.getOneServiceParamsWithAuth(null===v.T3||void 0===v.T3?void 0:v.T3.UserId,this.healthOCID)):o.push(...F.WR.getOneServiceParamsWithoutAuth(null===v.T3||void 0===v.T3?void 0:v.T3.UserId,this.healthOCID));const n=o.findIndex(e=>"$select"===e.key);return-1!==n&&o.splice(n,1),r.search=P._3.keyValueArrayToQueryString(o),F.WR.addTelemetryTracingQueryParam(r),r.searchParams.append("timeout",a.toString()),r.href}static getPostServiceUrl(e,t){let i=!(arguments.length>2&&void 0!==arguments[2])||arguments[2];const a=(0,N.e3)()?new URL(this.baseUrlForBot):new URL(this.baseUrlForPost),r=this.getHealth1SParams(t,i);e?r.push(...F.WR.getOneServiceParamsWithAuth(null===v.T3||void 0===v.T3?void 0:v.T3.UserId,this.healthOCID)):r.push(...F.WR.getOneServiceParamsWithoutAuth(null===v.T3||void 0===v.T3?void 0:v.T3.UserId,this.healthOCID));const o=r.findIndex(e=>"$select"===e.key);if(-1!==o&&r.splice(o,1),t.toLowerCase().indexOf("healthtipsdcard|click")>0||t.toLowerCase().indexOf("healthtipsdcard|view")>0){const e=r.findIndex(e=>"apikey"===e.key);-1!==e&&r.splice(e,1);const t=[{key:"apikey",value:"FywQv6H345wNCU4yKWraF2esI9qiMQFx90v53mMHrm"}];r.push(...t)}return a.search=P._3.keyValueArrayToQueryString(r),F.WR.addTelemetryTracingQueryParam(a),a.href}static createRequestBody(e){const t="query".charAt(0).toUpperCase()+"query".slice(1),i="queryType".charAt(0).toUpperCase()+"queryType".slice(1),a="Value",r="UserId",o=(null===v.T3||void 0===v.T3?void 0:v.T3.UserId.split("-")[1])||(null===v.T3||void 0===v.T3?void 0:v.T3.UserId),n="type".charAt(0).toUpperCase()+"type".slice(1);return JSON.stringify({[r]:{[a]:o,[n]:"1"},[t]:{[i]:"$select",[a]:e}})}static async PostDataToOneServiceInternal(e,t,i){let a=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],r=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"healthub/healthhub";try{if(!i)throw new Error("Null or empty market");let o;o=e?{method:"POST",credentials:"include",headers:await F.WR.getOneServiceHeaders()}:{method:"POST",headers:{accept:"application/json"}};const n=t.match(/timeRequiredToRun=(\d+)/),s=n?parseInt(n[1]):0;let l=n&&!isNaN(s)?this.getPostServiceUrlWithCustomTimeout(e,t,a,s):this.getPostServiceUrl(e,t,a);r&&"healthhub/healthhub"!==r&&(l=l.replace("healthhub/healthhub",r)),o.body=this.createRequestBody(t),o.headers={accept:"application/json"};const h=await(0,L.w)(async()=>{const e=await fetch(l,o);if(!e)throw Error(`Null response. Url = ${l}`);if(!e.ok){var t;const i={};throw null==e||null===(t=e.headers)||void 0===t||t.forEach((e,t)=>{i[t]=e}),Error(`Status:${e.status} Url = ${l} Headers = ${JSON.stringify(i)}`)}return e.json()},"PostDataToOneServiceInternal");if(!(h&&h.length&&h[0]&&h[0].data))throw new Error(`Null, empty or invalid response Json. Url = ${l}`);return JSON.parse(h[0].data)}catch(e){let t="";throw e&&"object"==typeof e?t=String(e):e&&"string"==typeof e&&(t=e),new Error(`Error in one service call. ${t}`)}}static async PostDataToOneService(e,t){let i=!(arguments.length>2&&void 0!==arguments[2])||arguments[2],a=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"healthub/healthhub";return await this.PostDataToOneServiceInternal(!1,e,t,i,a)}static GetStatusCodeFromOneServiceError(e){let t="";if(e&&e.message){const i=/status:\d\d\d/gi,a=e.message.match(i);if(a&&a.length>0){const e=a[0].split(":");t=e.length>1?e[1]:""}}return t}}R.baseUrlForBotKey=Symbol("baseUrlForBot"),R.healthOCIDKey=Symbol("healthOCID"),R.baseUrlForPostKey=Symbol("baseUrlForPost");var j=i(90366);const B={generateUrl(e){return e+"&c=1&w=300&h=300"},convertTextToSentenceCase(e){return e.charAt(0).toUpperCase()+e.substring(1,e.length).toLowerCase()},getHeaderText(e,t,i){if(e){if(i&&e.cardType&&e.cardType===u.BING_TIPS)return B.convertTextToSentenceCase(t.healthTrends)||"Health trends";if(e.cardType&&e.cardType===u.CUSTOM_TIPS)return B.convertTextToSentenceCase(t.customHeaderText);if(e.subCategory&&e.subCategory===g.HHP)return B.convertTextToSentenceCase(t.harvardHeaderText);if(e.subCategory&&e.subCategory===g.FOOD&&e.cardType&&(e.cardType===u.HARVARD_TIPS||e.cardType===u.EXPERT_TIPS))return B.convertTextToSentenceCase(t.expertHeaderText)}return B.convertTextToSentenceCase(t.headerText)},isExpertTip(e){return!!e.cardType&&((e.cardType!==u.EXPERT_TIPS||!e.subCategory||e.subCategory!==g.CONDITION)&&(e.cardType===u.EXPERT_TIPS||e.cardType===u.HARVARD_TIPS||e.cardType===u.FITNESS_TIPS))},getPersonalizedUrl(e,t){if(e&&e.includes("bing.com"))return e;try{!0===t&&!1===e.includes("disableheader=1")&&(e=`${e}${e.includes("?")?"&":"?"}disableheader=1`);const i=new URL(e).host,a=new URL((0,j.HZ)());return e.replace(i,a.host)}catch(t){return(0,n.c_)(t,s.Om,"Error while updating URL from global config"),e}},getrgbvalue(e){const t=e.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i,(e,t,i,a)=>`#${t}${t}${i}${i}${a}${a}`),i=(null==t?void 0:t.substring(1)).match(/.{2}/g);return((null==i?void 0:i.length)&&i.map(e=>parseInt(e,16))||[]).join(",")}};var W,q=i(94043),J=i(31525);let Z=W=class extends H.L{constructor(){super(...arguments),this.onThemeChange=e=>{this.darkMode=e},this.healthTipData={},this.isActionMenuOpen=!1,this.darkMode=!1,this.moreSettingAction=()=>{this.toggleActionMenu(!1,null),this.$emit("goToPersonalizeSettingsCallback")},this.hideHealthCard=async()=>{try{let e=!1;return e=await O.d.updateSegmentCardsEnableStatus([{cardType:x.s.HealthCard,enabled:!1}]),e&&(this.refreshFeed?this.refreshFeed():this.$emit("refreshSDCardSection")),this.toggleActionMenu(!1,null),e}catch(e){return(0,n.c_)(e,s.Om,"Error in Health Tip Card WCE hide option"),!1}},this.onOutsideClick=e=>{var t;e.target instanceof W||null!==(t=this.actionsMenuButtonElement)&&void 0!==t&&t.contains(e.path[0])||this.toggleActionMenu(!1,null)},this.onKeydown=e=>{e.key===C.F9&&this.toggleActionMenu(!1,null)}}connected(){this.superCardData=this.buildSuperCardData(),I.l.subscribe(this),super.connectedCallback(),(0,q.S)()&&(this.healthTipData&&this.strings&&this.markVisualReadiness&&this.markVisualReadiness(),this.setIntersectionObserver())}disconnectedCallback(){super.disconnectedCallback(),this.unsetIntersectionObserver()}handleChange(e){const t=e.getValueFor(this)<=A.y.DarkMode;this.onThemeChange(t)}setIntersectionObserver(){if(this.intersectionObserver)return;this.intersectionObserver=new IntersectionObserver(e=>{if(e){var t;if((null===(t=e[0])||void 0===t?void 0:t.intersectionRatio)>0){const e={Scenario:"HealthTipSDCard|View",CanvasOcid:this.getCallerOcid(),HealthTipData:JSON.stringify({healthTip:this.healthTipData.healthTip,msnArticleURL:B.getPersonalizedUrl(this.healthTipData.msnArticleURL)})};R.PostDataToOneService(JSON.stringify(e),((0,v.rA)().CurrentMarket||"en-us").toString(),!1,"healthhub/healthtip"),this.unsetIntersectionObserver()}}},{threshold:[0]}),this.intersectionObserver.observe(this)}unsetIntersectionObserver(){this.intersectionObserver&&(this.intersectionObserver.disconnect(),this.intersectionObserver=void 0)}toggleActionMenu(e,t){this.isActionMenuOpen=e,this.isActionMenuOpen?(this.actionsMenuButtonElement=t&&t.currentTarget,document.addEventListener("click",this.onOutsideClick),document.addEventListener("keydown",this.onKeydown)):(this.actionsMenuButtonElement=null,document.removeEventListener("click",this.onOutsideClick),document.removeEventListener("keydown",this.onKeydown))}handleCardClick(e){const t=e.composedPath().find(e=>e instanceof HTMLElement&&(e.classList.contains("more-actions")||e.classList.contains("menu-item")));if(document.activeElement instanceof HTMLElement&&document.activeElement.blur(),!t){const e={Scenario:"HealthTipSDCard|Click",CanvasOcid:this.getCallerOcid(),HealthTipData:JSON.stringify({healthTip:this.healthTipData.healthTip,msnArticleURL:B.getPersonalizedUrl(this.healthTipData.msnArticleURL)})};R.PostDataToOneService(JSON.stringify(e),((0,v.rA)().CurrentMarket||"en-us").toString(),!1,"healthhub/healthtip")}return!0}getCallerOcid(){return void 0===this.callerOcid&&(this.callerOcid=F.WR.getOneServiceOCID((0,v.rA)().TrackInfo,"defaultOcid")),this.callerOcid}healthTipDataChanged(){this.healthTipData&&this.strings&&(this.superCardData=this.buildSuperCardData())}buildSuperCardData(){return{id:"HealthTipFeed",gridArea:"",childTemplateType:"",metadata:x.s.HealthCard,headerData:{headerLogo:`<img style="width: 16px; height: 16px; display: inline-block; background-size: cover; background-repeat: no-repeat; margin-left: -10px; margin-top: 4px;" src="${(0,v.rA)().StaticsUrl}/latest/health/health-growth/HealthIconFeed.svg" />`,title:B.getHeaderText(this.healthTipData,this.strings,this.bingHeader),logoNavigationLink:B.getPersonalizedUrl(this.healthTipData.msnArticleURL),titleNavigationLink:B.getPersonalizedUrl(this.healthTipData.msnArticleURL),actionMenuData:{hideCardCallback:this.hideHealthCard,moreSettingsPersonalizeCallback:this.moreSettingAction}},footerData:{footerLink:{text:this.strings.footerSeeMore,navigationUrl:B.getPersonalizedUrl(this.healthTipData.msnArticleURL)}},contextualFeedbackData:this.wpoMetadata&&this.wpoMetadata.isGA?{cFId:this.wpoMetadata.cfId,cFMetadataType:this.wpoMetadata.cFMetadataType}:null,parentTelemetryObject:this.parentTelemetryObject}}};(0,a.Cg)([S.sH],Z.prototype,"parentTelemetryObject",void 0),(0,a.Cg)([S.sH],Z.prototype,"destinationUrlTelemetryObject",void 0),(0,a.Cg)([S.sH],Z.prototype,"superCardData",void 0),(0,a.Cg)([S.sH],Z.prototype,"healthTipData",void 0),(0,a.Cg)([S.sH],Z.prototype,"strings",void 0),(0,a.Cg)([S.sH],Z.prototype,"useGlobalSettingsUrl",void 0),(0,a.Cg)([S.sH],Z.prototype,"cardSize",void 0),(0,a.Cg)([S.sH],Z.prototype,"isActionMenuOpen",void 0),(0,a.Cg)([S.sH],Z.prototype,"actionsMenuProps",void 0),(0,a.Cg)([S.sH],Z.prototype,"darkMode",void 0),(0,a.Cg)([(0,M.CF)({attribute:"isSmallCard",mode:"boolean"})],Z.prototype,"isSmallCard",void 0),Z=W=(0,a.Cg)([J.x],Z);const G=T.qy` &nbsp;<span>&#8226;</span>&nbsp; ${e=>e.healthTipData.expertQualification}
`,V=T.qy`<div class="health-tip-image-container"><img src="${e=>B.generateUrl(e.healthTipData.articleThumbnail.imageURL)}" alt="${e=>e.healthTipData.healthTip}"/></div>`,Q=T.qy`<div class="health-tip-publisher-container ${e=>B.isExpertTip(e.healthTipData)?"expert-tip-container":""}"><img src="${e=>e.healthTipData.articleThumbnail.publisherIcon}" alt="${e=>e.healthTipData.publisherName}" class="health-tip-image"/><div class="health-tip-publisher-name">${e=>e.healthTipData.publisherName}${(0,_.z)(e=>B.isExpertTip(e.healthTipData)&&!!e.healthTipData.expertQualification,G)}</div></div>`,Y=T.qy`<div class="health-tip-title-container${e=>e.swapTipAndImage?"-fb":""}" title="${e=>e.healthTipData.healthTip}">"${e=>e.healthTipData.healthTip}"</div>`,K=T.qy`<div class="health-tip-title">${Y} ${(0,_.z)(e=>!e.bingHeader,Q)}</div>`,X=T.qy`<div class="health-tip-title">${(0,_.z)(e=>!e.bingHeader,Q)} ${Y}</div>`,ee=T.qy`<responsive-sd-card :data="${e=>e.superCardData}" data-t=${e=>{var t;return null===(t=e.parentTelemetryObject)||void 0===t?void 0:t.getMetadataTag()}} class="health-tip-root"  id="health-tip-card" size="${e=>e.cardSize}" ?feeds3-design="${e=>e.useFeeds3Design}" @click="${(e,t)=>e.handleCardClick(t.event)}"><div slot="card-content"><a class="health-tip-container-link ${e=>e.isSmallCard?"small-card":""} ${e=>e.bingHeader?"new-ux":""}" aria-label=${e=>B.getHeaderText(e.healthTipData,e.strings,e.bingHeader)+";"+e.healthTipData.healthTip+"; -"+e.healthTipData.publisherName} href="${e=>B.getPersonalizedUrl(e.healthTipData.msnArticleURL)}" target="_blank">${V} ${X}</a></div></responsive-sd-card>`,te=T.qy`<responsive-sd-card :data="${e=>e.superCardData}" data-t=${e=>{var t;return null===(t=e.parentTelemetryObject)||void 0===t?void 0:t.getMetadataTag()}} class="health-tip-root"  id="health-tip-card" size="${e=>e.cardSize}" ?feeds3-design="${e=>e.useFeeds3Design}" @click="${(e,t)=>e.handleCardClick(t.event)}"><div slot="card-content"><a class="health-tip-container-link ${e=>e.isSmallCard?"small-card":""} ${e=>e.bingHeader?"new-ux":""}" aria-label=${e=>B.getHeaderText(e.healthTipData,e.strings,e.bingHeader)+";"+e.healthTipData.healthTip+"; -"+e.healthTipData.publisherName} href="${e=>B.getPersonalizedUrl(e.healthTipData.msnArticleURL)}" target="_blank">${K} ${V}</a></div></responsive-sd-card>`,ie=T.qy` ${(0,_.z)(e=>e.swapTipAndImage,te)} ${(0,_.z)(e=>!e.swapTipAndImage,ee)}
`;var ae=i(89580),re=i(41123),oe=i(61138),ne=i(12640),se=i(74849);const le=se.A`
.health-tip-root .health-tip-container-link{color:#fff}`,he=se.A`
:host{border-radius:8px}.health-tip-root .health-tip-container-link{color:#1a1a1a;display:flex;flex-direction:column;-webkit-font-smoothing:antialiased;gap:14px;text-decoration:none}.health-tip-root .new-ux{gap:16px}.health-tip-root .health-tip-container-link.small-card{flex-direction:row;gap:12px}.health-tip-image-container{height:140px}.small-card .health-tip-image-container{height:56px;width:56px;order:1}.health-tip-image-container img{border-radius:8px;width:100%;height:140px;object-fit:cover}.small-card .health-tip-image-container img{height:56px;width:56px}.health-tip-title{display:flex;flex-direction:column;gap:4px}.small-card .health-tip-title{max-width:calc(100% - 68px)}.health-tip-title-container{display:-webkit-box;-webkit-line-clamp:2;overflow:hidden;-webkit-box-orient:vertical;font-weight:600;font-size:${ae.Y};
    line-height: ${ae.v};height:44px}.health-tip-title-container-fb{display:-webkit-box;-webkit-line-clamp:2;overflow:hidden;-webkit-box-orient:vertical;font-weight:600;font-size:${ae.Y};
    line-height: ${ae.v};height:49px}.small-card .health-tip-title-container{font-size:${re.K};
    line-height: ${re.Z};height:40px}.health-tip-publisher-container{display:flex;flex-direction:row;align-items:center;width:100%;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.health-tip-publisher-container img{width:16px;height:16px;margin-inline-end:8px;border-radius:2px}.health-tip-publisher-container.expert-tip-container img{width:14px;height:14px;border-radius:50%;border:1px solid #fff;margin-inline-end:8px}.health-tip-publisher-container .health-tip-publisher-name{font-size:${oe.k};
    line-height: ${oe.F};
    font-weight: normal;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}

`.withBehaviors(new ne.N(null,le));var ce=i(7014),de=i(37180),pe=i(7574);let ue=class extends Z{};ue=(0,a.Cg)([(0,H.E)({name:"health-tip-feed-card",template:ie,styles:he,shadowOptions:{delegatesFocus:!0}})],ue),ce.m.define(de.c.registry),(0,pe.d)();const ge=(0,v.rA)().StaticsUrl+"latest/common/icons/ArrowRightAlt.svg",be=T.qy`<msn-actions-menu :referrerButton=${e=>e.actionsMenuButtonElement} :menuItems=${e=>e.actionsMenuProps.menuItems}></msn-actions-menu>`,ve=T.qy`<span>&#8226;</span>&nbsp; ${e=>e.healthTipData.expertQualification}
`,$e=T.qy`<fluent-design-system-provider use-defaults><div class="health-tip-root" id="health-tip-card" data-t="${e=>e.healthTipCardTelemetryTag}" @mouseenter=${(e,t)=>{t.event&&e.hoverTelemetryHelper&&e.hoverTelemetryHelper.onMouseEnter(t.event.currentTarget)}} @mouseleave=${(e,t)=>{t.event&&e.hoverTelemetryHelper&&e.hoverTelemetryHelper.onMouseLeave(t.event.currentTarget)}}><a href="${e=>B.getPersonalizedUrl(e.healthTipData.msnArticleURL,e.disableHeader)}" target="_blank" data-t="${e=>e.healthTipDestinationTelemetryTag}" class="health-tip-container-link" aria-label={${e=>B.getHeaderText(e.healthTipData,e.strings)+";"+e.healthTipData.healthTip}}><div class="health-tip-image-container"><img id="healthTipImage" src="${e=>B.generateUrl(e.healthTipData.articleThumbnail.imageURL)}" /></div><div class="health-tip-gradient-container" style="background: linear-gradient(180deg, rgba(${e=>B.getrgbvalue(e.healthTipData.articleThumbnail.darkModeBackgroundColor)}, 0.8) -37.66%, rgba(${e=>B.getrgbvalue(e.healthTipData.articleThumbnail.darkModeBackgroundColor)}, 0) 129.93%, rgba(${e=>B.getrgbvalue(e.healthTipData.articleThumbnail.darkModeBackgroundColor)}, 0.448) 129.93%);"></div><div class="health-tip-gradient-container" style="background: linear-gradient(180deg, rgba(${e=>B.getrgbvalue(e.healthTipData.articleThumbnail.darkModeBackgroundColor)}, 0.8) -37.66%, rgba(${e=>B.getrgbvalue(e.healthTipData.articleThumbnail.darkModeBackgroundColor)}, 0) 129.93%, rgba(${e=>B.getrgbvalue(e.healthTipData.articleThumbnail.darkModeBackgroundColor)}, 0.448) 129.93%); transform: matrix(1, 0, 0, -1, 0, 0);"></div><div class="health-tip-blur-container" style="background: rgba(${e=>B.getrgbvalue(e.healthTipData.articleThumbnail.darkModeBackgroundColor)}, 0.1);"></div><div class="health-tip-header-container" data-t="${e=>e.healthTipCardTelemetryTag}"><div class="health-tip-header-content">${e=>B.getHeaderText(e.healthTipData,e.strings)}</div></div><div class="health-tip-footer-container ${e=>B.isExpertTip(e.healthTipData)?"expert-footer-container":""}"><div class="health-tip-title-container" title="${e=>e.healthTipData.healthTip}">"${e=>e.healthTipData.healthTip}"</div><div class="health-tip-publisher-container ${e=>B.isExpertTip(e.healthTipData)?"expert-tip-container":""}"><img src="${e=>e.healthTipData.articleThumbnail.publisherIcon}" class="health-tip-image"/><div class="health-tip-publisher-name">${e=>e.healthTipData.publisherName} ${(0,_.z)(e=>e.healthTipData.expertQualification&&B.isExpertTip(e.healthTipData),ve)}</div></div></div></a>${(0,_.z)(e=>e.isEnableActionMenu,T.qy`<div class="health-tip-more-info"><fluent-button class= "toggle-button" @click=${(e,t)=>e.toggleActionMenu&&e.toggleActionMenu(!e.isActionMenuOpen,t.event)} title="${e=>e.strings.moreSettingsText}" aria-label="${e=>e.strings.moreSettingsText}" data-t="${e=>e.ellipsisTelemetryTag}">${T.qy.partial(D.A)}</fluent-button></div>`)}<a href="${e=>B.getPersonalizedUrl(e.healthTipData.msnArticleURL,e.disableHeader)}" target="_blank" data-t="${e=>e.healthTipDestinationTelemetryTag}" class="health-tip-action-link" aria-label={${e=>e.healthTipData.footerCTA}}><div class="health-tip-action-container"><div class="text">${e=>e.healthTipData.footerCTA}</div><img src=${ge} class="action" alt="Right arrow" aria-hidden="true" /></div></a></div></fluent-design-system-provider>${(0,_.z)(e=>e.isActionMenuOpen,be)}
`,me=T.qy`<health-tip-feed-card :wpoMetadata=${e=>e.wpoMetadata} :healthTipData=${e=>e.healthTipData} :cardSize=${e=>e.cardSize} :isSmallCard=${e=>e.cardSize===r.uE._1x_1y||e.cardSize===r.uE._05u} :strings=${e=>e.strings} :swapTipAndImage=${e=>void 0!==e.config.swapTipAndImage&&e.config.swapTipAndImage} :bingHeader=${e=>void 0!==e.config.bingHeader&&e.config.bingHeader} :goToPersonalizeSettingsCallback=${e=>e.goToPersonalizeSettingsCallback} :refreshFeed=${e=>e.refreshFeed} :parentTelemetryObject=${e=>e.healthTipCardTelemetryObject} :destinationUrlTelemetryObject=${e=>e.feedTelemetryObject} :markVisualReadiness=${e=>e.markVisualReadiness} :useFeeds3Design="${e=>e.config.useFeeds3Design}"></health-tip-feed-card>`,xe=T.qy` ${(0,_.z)(e=>e.config.isNTPFeed,me)} ${(0,_.z)(e=>!e.config.isDynamicFeed&&!e.config.isNTPFeed,$e)}
`;var fe=i(57416),ke=i(22683),we=i(62198),ye=i(86856),Te=i(50882),Ce=i(22131);const Se=se.A`
.health-tip-title-container{background:${Te.A.ButtonFace};
    color: ${Te.A.LinkText}}.health-tip-action-container,.health-tip-action-container svg path{background:${Te.A.ButtonFace};
    color: ${Te.A.LinkText};
    fill: ${Te.A.LinkText}}.health-tip-header-content,.health-tip-publisher-container .health-tip-publisher-name{background:${Te.A.ButtonFace};
    color: ${Te.A.CanvasText}
}
`,Oe=se.A`
.health-tip-more-info{border-radius:50%;position:absolute;top:10px;right:16px;z-index:3}`,ze=se.A`
.health-tip-more-info{border-radius:50%;position:absolute;top:10px;left:16px;z-index:3}.health-tip-action-container .action{transform:rotate(180deg)}`,Ue=se.A`
:host{border-radius:calc(${fe.JU} * 1px);}.health-tip-root{height:304px;max-width:300px;border-bottom:1px solid ${ke.hb};
    position: relative;
    z-index: 1;
    background: #000;
    border-radius: calc(${fe.JU} * 1px);}.health-tip-root a{color:#fff;text-decoration:none;display:flex;flex-direction:column;-webkit-font-smoothing:antialiased}.health-tip-root a:hover .health-tip-title-container{text-decoration:underline}.health-tip-root a .health-tip-action-container:hover{text-decoration:underline}.health-tip-container-link{height:calc(100% - 45px)}.health-tip-action-link{height:45px}.health-tip-container-link:focus-visible,.health-tip-action-link:focus-visible{outline:none}.health-tip-container-link:focus-visible .health-tip-title-container,.health-tip-container-link:focus-visible .health-tip-header-content{outline:1px solid}.health-tip-action-link:focus-visible .health-tip-action-container{outline:1px solid}.health-tip-image-container{height:304px;position:absolute;top:0px;z-index:-1}.health-tip-image-container img{object-fit:cover;height:100%;width:100%;border-radius:6px}.health-tip-gradient-container{text-transform:uppercase;display:flex;flex-direction:row;align-items:flex-end;padding:304px 300px 0px 0px;z-index:0;position:absolute;top:0;border-radius:calc(${fe.JU} * 1px);}.health-tip-blur-container{text-transform:uppercase;display:flex;flex-direction:row;align-items:flex-end;padding:300px 300px 0px 0px;backdrop-filter:blur(2px);transform:matrix(1,0,0,-1,0,0);z-index:1;position:absolute;top:0;border-radius:calc(${fe.JU} * 1px);}.health-tip-footer-container{position:absolute;top:auto;bottom:45px;height:calc(100% - 94px);width:100%;z-index:2;border-radius:0 0 6px 6px}.health-tip-header-container{text-transform:uppercase;display:flex;flex-direction:row;align-items:flex-end;font-weight:600;font-size:${oe.k};
    line-height: ${oe.F};color:#fff;padding:16px 16px 0px;z-index:2;border-radius:6px 6px 0px 0px}.health-tip-publisher-container{padding:16px 16px;display:flex;flex-direction:row;align-items:center;position:absolute;bottom:20px;width:calc(100% - 32px);gap:8px}.health-tip-publisher-container.expert-tip-container{gap:4px}.health-tip-publisher-container img{width:16px;height:16px;border-radius:4px}.health-tip-publisher-container.expert-tip-container img{width:16px;height:16px;border-radius:50%;border:2px solid #fff}.health-tip-title-container{display:-webkit-box;-webkit-line-clamp:4;overflow:hidden;-webkit-box-orient:vertical;padding:0px 16px 0;font-weight:600;font-size:${we.a};
    line-height: ${we.b};position:absolute;bottom:72px}.health-tip-publisher-container .health-tip-publisher-name{font-size:${oe.k};
    line-height: ${oe.F};font-weight:normal;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.health-tip-action-container{position:absolute;bottom:0;z-index:3}.health-tip-action-container .text{display:-webkit-box;-webkit-line-clamp:2;overflow:hidden;max-height:40px;-webkit-box-orient:vertical}.health-tip-action-container .action{display:flex;margin-bottom:4px}.health-tip-action-container{display:flex;flex-direction:row;align-items:flex-end;gap:6px;padding:5px 16px 20px;font-size:${re.K};
    line-height: ${re.Z};font-weight:normal}.health-tip-more-info .toggle-button{border-radius:50%;background:rgba(255,255,255,0.09);color:#fff;height:24px;width:24px;min-width:24px}.health-tip-more-info .toggle-button:hover{background:rgba(255,255,255,0.2)}`.withBehaviors(new ye.t(Oe,ze),(0,Ce.mr)(Se)),_e={experienceConfigSchema:undefined}},7014(e,t,i){i.d(t,{m(){return L}});var a=i(56911),r=i(38493),o=i(60815),n=i(55230),s=i(92011),l=i(56863);class h extends s.L{}class c extends((0,l.dx)(h)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class d extends c{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(!this.readOnly)switch(e.key){case n.Mm:case n.gG:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,t){super.checkedChanged(e,t),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,a.Cg)([(0,r.CF)({attribute:"readonly",mode:"boolean"}),(0,a.Sn)("design:type",Boolean)],d.prototype,"readOnly",void 0),(0,a.Cg)([o.sH,(0,a.Sn)("design:type",Array)],d.prototype,"defaultSlottedNodes",void 0);var p=i(37180),u=i(74849),g=i(64187),b=i(60993),v=i(73477),$=i(22131),m=i(50882),x=i(48196),f=i(86856),k=i(7896),w=i(74838),y=i(79288),T=i(46203),C=i(26920),S=i(43774),O=i(95239),z=i(14996),U=i(48751),_=i(41123),D=i(74089),H=i(4283);const M=u.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,g.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${k.O};
        margin: calc(${w.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${y.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${b.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${x.D} / 2) + ${w.vR}) * 2px);
        height: calc(((${x.D} / 2) + ${w.vR}) * 1px);
        background: ${T.le};
        border-radius: calc(${x.D} * 1px);
        border: calc(${C.XA} * 1px) solid ${S.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${T.jM};
        border-color: ${S.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${T.RS};
        border-color: ${S.p4};
    }

    :host(:${v.N}) .switch {
        box-shadow: 0 0 0 2px ${O.p}, 0 0 0 4px ${z.WN};
        border-color: ${z.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${x.D} - (${w.vR} * 5.5)) * 1px);
        width: calc((${x.D} - (${w.vR} * 5.5)) * 1px);
        top: calc(${w.vR} * 1px);
        background: ${U.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${U.l};
        cursor: pointer;
        font-size: ${_.K};
        line-height: ${_.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${U.l};
        font-size: ${_.K};
        line-height: ${_.Z};
        margin-inline-end: calc(${w.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${w.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${D.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${H.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${H.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${D.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${H.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${D.J_};
    }

    :host([aria-checked="true"]:${v.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${O.p}, 0 0 0 4px ${z.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new f.t(u.A`
            .checked-indicator {
                left: calc(${w.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${x.D} / 2) + ${w.vR}) + ${w.vR}) * 1px
                );
            }
        `,u.A`
            .checked-indicator {
                right: calc(${w.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${x.D} / 2) + ${w.vR}) + ${w.vR}) * 1px
                );
            }
        `),(0,$.mr)(u.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${m.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${m.A.Field};
                border-color: ${m.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${m.A.HighlightText};
                border-color: ${m.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${m.A.Highlight};
                border-color: ${m.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${m.A.HighlightText};
                border-color: ${m.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${m.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${m.A.Highlight};
            }
            :host(:${v.N}) .switch {
                border-color: ${m.A.Highlight};
                box-shadow: 0 0 0 2px ${m.A.Field},
                    0 0 0 4px ${m.A.FieldText};
            }
            :host([aria-checked="true"]:${v.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${m.A.Field},
                    0 0 0 4px ${m.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${m.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${m.A.Field};
                border-color: ${m.A.GrayText};
            }
            .status-message,
            .label {
                color: ${m.A.FieldText};
            }
        `));var I=i(96950),A=i(82774),P=i(18893);const F=function(e={}){return I.qy`
        <template
            role="switch"
            aria-checked="${e=>e.checked}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            tabindex="${e=>e.disabled?null:0}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <label
                part="label"
                class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,A.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,P.R)(e.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:I.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),L=class extends d{}.compose({name:`${p.c.prefix}-switch`,template:F,styles:M})},31422(e,t){t.A='<svg width="14" height="14" viewBox="0 0 14 14"><path d="M.4.15A.5.5 0 0 0 .37.8l.05.05 2.69 2.7A6.66 6.66 0 0 0 .46 7.36a.5.5 0 0 0 .97.25 5.66 5.66 0 0 1 2.39-3.36l1.2 1.2A2.67 2.67 0 0 0 8.8 9.25l3.95 3.94a.5.5 0 0 0 .75-.65l-.04-.05L9.37 8.4l-.8-.8L6.66 5.7 4.74 3.77l-.76-.75L1.13.15a.5.5 0 0 0-.71 0Zm5.33 6.03 2.36 2.35a1.67 1.67 0 0 1-2.36-2.35Zm1.2-3.85A6.66 6.66 0 0 0 5 2.62l.83.82a5.67 5.67 0 0 1 6.6 4.18.5.5 0 0 0 .96-.24 6.67 6.67 0 0 0-6.46-5.05Zm.13 2.34 2.53 2.54a2.67 2.67 0 0 0-2.53-2.54Z" fill-opacity=".83"/></svg>'},43774(e,t,i){i.d(t,{p4(){return b},ls(){return v},vA(){return g},nF(){return u}});var a=i(45755),r=i(68009),o=i(95239);const{create:n}=a.G,s=n("neutral-stroke-strong-hover-delta",40),l=n("neutral-stroke-strong-active-delta",16),h=n("neutral-stroke-strong-focus-delta",25);var c=i(31023);const{create:d}=a.G,p=d({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,t,i,a,o,n){const s=(0,r.F)(t),l=e.colorContrast(t,i),h=e.closestIndexOf(l);return{rest:l,hover:e.get(h+s*a),active:e.get(h+s*o),focus:e.get(h+s*n)}}(e(c.r),e(o.p),3,e(s),e(l),e(h))}}),u=d("neutral-stroke-strong-rest",e=>e(p).evaluate(e).rest),g=d("neutral-stroke-strong-hover",e=>e(p).evaluate(e).hover),b=d("neutral-stroke-strong-active",e=>e(p).evaluate(e).active),v=d("neutral-stroke-strong-focus",e=>e(p).evaluate(e).focus)},47264(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20"><path d="M6 10a1.25 1.25 0 1 1-2.5 0A1.25 1.25 0 0 1 6 10zM11.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0zM15.25 11.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5z"/></svg>'},79201(e,t,i){i.d(t,{w(){return o}});var a=i(77367),r=i(85349);class o{constructor(e){this.enableHover=e,this.inElement=!1,this.onMouseEnter=(e,t)=>{!1!==t&&(void 0!==t||this.enableHover)&&a.YT&&e&&!this.inElement&&(this.inElement=!0,a.YT.sendActionEvent(e,r.EG.Hover))},this.onMouseLeave=(e,t)=>{!1!==t&&(void 0!==t||this.enableHover)&&a.YT&&e&&this.inElement&&(this.inElement=!1,a.YT.sendActionEvent(e,r.EG.MouseLeave))}}}},96951(e,t,i){i.d(t,{Jl(){return r},NZ(){return n},Om(){return o},ZO(){return l},eM(){return s}});var a=i(93552);(0,a.KR6)(53e3,a.XkX),(0,a.KR6)(53001,a.XkX),(0,a.KR6)(53002),(0,a.KR6)(53003),(0,a.KR6)(53004),(0,a.KR6)(53005,a.XkX),(0,a.KR6)(53006,a.XkX),(0,a.KR6)(53007,a.XkX),(0,a.KR6)(53008),(0,a.KR6)(53009),(0,a.KR6)(53010,a.XkX),(0,a.KR6)(53011,a.XkX),(0,a.KR6)(53012),(0,a.KR6)(53013,a.XkX),(0,a.KR6)(53014,a.imi,(0,a.N5g)(!0)),(0,a.KR6)(53015,a.XkX),(0,a.KR6)(53016,a.XkX),(0,a.KR6)(53031,a.XkX),(0,a.KR6)(53032,a.XkX),(0,a.KR6)(53050),(0,a.KR6)(53051),(0,a.KR6)(53055),(0,a.KR6)(53062),(0,a.KR6)(53063),(0,a.KR6)(53064),(0,a.KR6)(53065),(0,a.KR6)(53099),(0,a.KR6)(53151,a.XkX),(0,a.KR6)(53156,a.XkX),(0,a.KR6)(53161,a.XkX),(0,a.KR6)(54001,a.XkX),(0,a.KR6)(54002),(0,a.KR6)(54003),(0,a.KR6)(54004),(0,a.KR6)(54005),(0,a.KR6)(54006,a.XkX),(0,a.KR6)(54007),(0,a.KR6)(54008),(0,a.KR6)(54009),(0,a.KR6)(54010),(0,a.KR6)(54011),(0,a.KR6)(54012),(0,a.KR6)(54013),(0,a.KR6)(54014),(0,a.KR6)(54015),(0,a.KR6)(54016),(0,a.KR6)(54017),(0,a.KR6)(54101,a.XkX),(0,a.KR6)(54102,a.XkX),(0,a.KR6)(54103),(0,a.KR6)(54104),(0,a.KR6)(54105),(0,a.KR6)(54106),(0,a.KR6)(56014),(0,a.KR6)(56015),(0,a.KR6)(56016),(0,a.KR6)(56017),(0,a.KR6)(56018),(0,a.KR6)(56019),(0,a.KR6)(56020),(0,a.KR6)(56021),(0,a.KR6)(56022),(0,a.KR6)(56023),(0,a.KR6)(56024),(0,a.KR6)(56025),(0,a.KR6)(56026),(0,a.KR6)(56027),(0,a.KR6)(56028),(0,a.KR6)(56029),(0,a.KR6)(56030),(0,a.KR6)(56031),(0,a.KR6)(56032),(0,a.KR6)(56033),(0,a.KR6)(56034),(0,a.KR6)(56035),(0,a.KR6)(56036),(0,a.KR6)(56037),(0,a.KR6)(60301,a.XkX),(0,a.KR6)(60302),(0,a.KR6)(60303),(0,a.KR6)(60304),(0,a.KR6)(60305),(0,a.KR6)(60306);const r=(0,a.KR6)(70100),o=(0,a.KR6)(70101),n=((0,a.KR6)(70102,a.imi,(0,a.N5g)(!0)),(0,a.KR6)(70103)),s=((0,a.KR6)(70104),(0,a.KR6)(70105),(0,a.KR6)(224500,a.XkX,(0,a.N5g)(!0))),l=((0,a.KR6)(224501),(0,a.KR6)(224502))}}]);