"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-tennis"],{2623(e,t,i){i.r(t),i.d(t,{SportsTennisStats(){return S}});var a=i(56911),r=i(92011),o=i(74849),s=i(22131),n=i(61138),l=i(62047),d=i(36452),c=i(86856),p=i(12640);const h=o.A` .stats-card{color:rgba(255,255,255,1)}`,g=o.A` .left-bar{transform:rotate(180deg)}.right-bar{transform:rotate(180deg)}`,x=o.A` .stats-card{width:268px;height:fit-content;padding:8px 12px;margin-top:8px;border-radius:8px;background:none;box-sizing:border-box;color:rgba(0,0,0,0.9)}.stats-title{font-size:${n.k};
        font-weight: 600;
        line-height: ${n.F};height:24px;border-bottom:1px solid rgba(0,0,0,0.06)}.stats-content >div{margin-top:8px}.content-large >div{margin-top:16px}.stats-item{height:28px;display:flex;justify-content:space-between;flex-direction:column}.bar-title{height:14px;line-height:${l.e};
        font-size: ${l.t};font-weight:600;display:flex;justify-content:space-between}.bar-title >div{display:inline-block}.stats-bar{display:flex;height:8px;width:100%;border-radius:8px;justify-content:space-between;background:${d.I2}}.left-bar{display:flex;height:8px;width:calc(50% - 0.5px);background:${d.I2};border-radius:8px 0 0 8px;justify-content:right}.right-bar{display:flex;height:8px;width:calc(50% - 0.5px);background:${d.I2};border-radius:0 8px 8px 0;justify-content:left}.left-bar >div{height:8px;width:30%;border-radius:8px 0 0 8px;background:#005FB8}.right-bar >div{height:8px;width:30%;border-radius:0 8px 8px 0;background:#EAA300}`.withBehaviors(new c.t(null,g),new p.N(null,h),(0,s.mr)(o.A` :host{forced-color-adjust:auto}`));var f=i(96950),b=i(39957),u=i(69259);const m=f.qy`
    <div class="stats-title">
        ${e=>e.viewModel.strings.playerStats}
    </div>
`,v=f.qy`
    <div class="stats-item">
        <div class="bar-title">
            <div>${e=>e.leftDes}</div>
            <div>${e=>e.text}</div>
            <div>${e=>e.rightDes}</div>
        </div>
        <div class="stats-bar">
            <div class="left-bar"><div style="width: ${e=>e.leftPercent}"></div></div>
            <div class="right-bar"><div style="width: ${e=>e.rightPercent}"></div></div>
        </div>
    </div>
`,$=f.qy`
    <div class="stats-content ${e=>e.viewModel.isLarge?"content-large":""}">
        ${(0,b.ux)(e=>e.viewModel.tennisStatsInfo.statsList,v)}
    </div>
`,y=f.qy`
    <div class="stats-card" data-t="${e=>e.viewModel.telemetryTag}">
        ${m}
        ${$}
    </div>
`,w=f.qy`
    ${(0,u.z)(e=>null!=e.viewModel,y)}
`;var k=i(92079);class z extends k.a{}let S=class extends z{};S=(0,a.Cg)([(0,r.E)({name:"sports-tennis-stats",template:w,styles:x,shadowOptions:{delegatesFocus:!0}})],S)},4968(e,t,i){i.d(t,{f(){return l}});var a=i(64187),r=i(74849),o=i(42792),s=i(99657),n=i(36452);const l=r.A.partial`position: relative; z-index: ${s.D};`;r.A`
    ${o.e}
    ${o.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${n.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${n.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${n.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},11526(e,t,i){i.r(t),i.d(t,{SportsSpotlightTennis(){return m}});var a=i(56911),r=i(92079);class o extends r.a{}var s=i(92011),n=i(74849),l=i(48751);const d=n.A` .spotlight-Tennis-content{color:${l.l};
        display: grid;
        grid-template-rows: 1fr auto auto;
        row-gap: 6px;
        height: 100%;
        box-sizing: border-box;
    }
`;var c=i(96950),p=i(69259);const h=c.qy`
    <sports-tennis-match
        :viewModel="${e=>e.viewModel.matchView.viewModel}"
    ></sports-tennis-match>
`,g=c.qy`
    <sports-tennis-stats
        :viewModel="${e=>e.viewModel.statsData}"
    ></sports-tennis-stats>
`,x=c.qy`
    <sports-table
        :viewModel="${e=>e.viewModel.playerInfoTableData}"
    ></sports-table>
`,f=c.qy`
    <sports-table
        :viewModel="${e=>e.viewModel.scoreCardTableData}"
    ></sports-table>
`,b=c.qy`
    <div class="sports-spotlight-content ${e=>e.viewModel.cardSize}" data-t="${e=>e.viewModel.telemetryTag}">
        ${h}
        ${(0,p.z)(e=>null!=e.viewModel.scoreCardTableData,f)}
        ${(0,p.z)(e=>null!=e.viewModel.statsData,g)}
        ${(0,p.z)(e=>null!=e.viewModel.playerInfoTableData,x)}
    </div>
`,u=c.qy`
    ${(0,p.z)(e=>null!=e.viewModel,b)}
`;let m=class extends o{};m=(0,a.Cg)([(0,s.E)({name:"sports-spotlight-tennis",template:u,styles:d,shadowOptions:{delegatesFocus:!0}})],m)},17471(e,t,i){i.r(t),i.d(t,{SportsTable(){return j}});var a=i(56911),r=i(92011),o=i(48751),s=i(62047),n=i(41123),l=i(61138),d=i(86856),c=i(74849),p=i(22131),h=i(4968),g=i(12640);const x=c.A` .table-card{color:rgba(255,255,255,1)}.card-header{color:rgba(255,255,255,1)}.card-header-tag{box-shadow:inset 0px 0px 0px 2px rgba(255,153,164,1)}.card-header-tag >span:nth-of-type(1){background:rgba(255,153,164,1);color:rgba(68,39,38,1)}.card-header-tag >span:nth-of-type(2){background:rgba(68,39,38,1);color:rgba(255,153,164,1)}.table-cell{border-top:1px solid rgba(255,255,255,0.07)}.no-border{border-top:none}.underlay{opacity:0.16}`,f=c.A` .line >img{margin-left:2px}.line >img.extra-margin{margin-left:4px}.line{padding-right:0px;padding-left:4px}.head-cell{padding-right:0px;padding-left:4px}.card-header-tag >span:nth-of-type(2){border-top-right-radius:0;border-bottom-right-radius:0;border-top-left-radius:3px;border-bottom-left-radius:3px}`,b=c.A` .table-container{text-decoration:none}.clickable{${h.f}}.table-card{margin-top:8px;width:268px;height:fit-content;background:none;color:${o.l};border-radius:8px;padding:8px 12px;box-sizing:border-box}.table-card.fill-card{margin-top:0px;padding:0px 12px;background:inherit}.card-header{display:flex;justify-content:space-between;align-items:baseline;padding:0 0 8px;color:${o.l}}.card-header >div{display:flex;font-size:12px;font-weight:600}.card-header-tag{height:18px;line-height:${s.e};box-shadow:inset 0px 0px 0px 4px rgba(196,43,28,1);border-radius:4px;padding:2px 2px;box-sizing:border-box}.card-header-tag >span{display:inline-block;font-size:${s.t};font-weight:600;box-sizing:border-box;padding:0px 2px}.card-header-tag >span:nth-of-type(1){background:rgba(196,43,28,1);color:rgba(255,255,255,1)}.card-header-tag >span:nth-of-type(2){background:rgba(255,255,255,1);color:rgba(196,43,28,1);border-top-right-radius:3px;border-bottom-right-radius:3px}.grid-table{display:grid;width:244px;grid-template-columns:minmax(20px,auto) 1fr minmax(auto,42px) minmax(auto,70px);grid-template-rows:repeat(9,28px)}.table-cell{position:relative;border-top:1px solid rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.line{font-size:${s.t};font-style:normal;font-weight:400;display:flex;align-items:center;padding:0 4px 0 0;width:100%;z-index:1}.line.large-font{font-size:${n.K}}.line > div{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.pre-text{font-size:${s.t};font-weight:600;width:14px;min-width:14px;padding-right:6px}.pre-text.large-font{font-size:${n.K};font-weight:400;width:16px}.head-cell{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;border-top:1px solid rgba(0,0,0,0.06);font-size:${l.k};font-style:normal;font-weight:600;display:flex;align-items:center;padding:0 4px 0 0}.hidden{display:none}.no-border{border-top:none}.overflow{overflow:visible}.line > sup{margin:0 0 4px 1px}.right{justify-content:end}.center{justify-content:center}.left{justify-content:start}.top{align-items:flex-start}.middle{align-items:center}.bottom{align-items:flex-end}.bold{font-weight:600}.line > img{margin-right:2px;height:16px;width:16px}.line > img.extra-margin{margin-right:4px}.iconround > img{border-radius:50%}img.icon-20{height:20px;width:20px;min-width:20px}.line > img.icon-24{height:24px;width:24px;min-width:24px}.font-xs{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.font-s{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.font-m{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.font-l{font-size:var(--smtc-text-ramp-lg-item-body-font-size,16px);line-height:var(--smtc-text-ramp-lg-item-body-line-height,26px)}.align-right{justify-content:flex-end;padding-right:0}.secondary{color:var(--smtc-foreground-ctrl-neutral-secondary-rest,#4c4642)}.underlay{position:absolute;top:-2px;height:calc(100% + 4px);width:100%;background:#0178A7;opacity:0.08}.first-column .underlay{border-radius:12px 0px 0px 12px;width:calc(100% + 4px);left:-4px}.last-column .underlay{border-radius:0px 12px 12px 0px}.no-padding .line,.no-padding .head-cell{padding:0px}.full-width .table-card{width:100%}.cplt .table-card{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320)}`.withBehaviors(new d.t(null,f),new g.N(null,x),(0,p.mr)(c.A` :host{forced-color-adjust:auto}`));var u=i(96950),m=i(39957),v=i(69259);const $=u.qy`
    ${e=>void 0!==e.viewModel.data.title?u.qy`
        <div class="card-header" style="${e=>e.viewModel.headerStyles}">
            <div style="${e=>e.viewModel.data.titleStyles}">${e=>e.viewModel.data.title}</div>
            ${e=>void 0!==e.viewModel.data.subTitle?u.qy`
                <div class="card-header-tag">
                    <span>${e=>e.viewModel.data.tagName}</span>
                    <span>${e=>e.viewModel.data.subTitle}</span>
                </div>`:""}
            ${e=>void 0!==e.viewModel.data.subTitleText?u.qy`
                <div style="${e=>e.viewModel.data.subTitleStyles}">
                    <span>${e=>e.viewModel.data.subTitleText}</span>
                </div>`:""}
        </div>
    `:""}
`,y=u.qy`
    ${(0,m.ux)(e=>e.getHeaderValues(),u.qy`
        <div class="head-cell ${e=>void 0!==e.class?e.class:""}" style="${e=>e.textStyles}">
            ${e=>void 0!==e.icon?u.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null}"
            />`:""}
            ${e=>e.value}
        </div>
    `)}
`,w=u.qy`
    ${(0,m.ux)(e=>e.getAllBodyCells(),()=>u.qy`
    <div class="table-cell ${e=>void 0!==e.cellClass?e.cellClass:""}">
        ${e=>e.isHightlighted?u.qy`<div class="underlay"></div>`:""}
        <div class="line ${e=>void 0!==e.class?e.class:""}">
            ${e=>void 0!==e.preText?u.qy`<div class="pre-text ${e=>void 0!==e.preTextClass?e.preTextClass:""}" style="${e=>e.preTextStyles}">${e.preText}</div>`:""}
            ${e=>void 0!==e.icon?u.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null} ${e=>e.icon?"":"hidden"}"
                onerror="this.style.display='none'"
            />`:""}
            ${e=>u.qy`<div style="${e=>e.textStyles}" title=${e=>e.value}>${e.value}</div>`}
            ${e=>void 0!==e.index?u.qy`<sup>${e.index}</sup>`:""}
        </div>
        <div class="line ${e=>void 0!==e.classL2?e.classL2:""}">
            ${e=>u.qy`<div>${e.valueL2}</div>`}
        </div>
    </div>
`)}
`,k=u.qy`
    <a
        class="${e=>e.viewModel.clickThroughUrl?"clickable":""} table-container ${e=>e.viewModel.tableClass}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="${e=>e.viewModel.clickThroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}" 
    >
        ${e=>e.viewModel.isHeaderAboveTheTable?$:""}
        <div
            class="table-card ${e=>e.viewModel.fillFullCard?"fill-card":""}"
            style="${e=>e.viewModel.tableStyles}"
        >
            ${e=>e.viewModel.isHeaderAboveTheTable?"":$}
            <div class="grid-table"
                style="${e=>`\n                    grid-template-columns: ${e.viewModel.columnStyle};\n                    grid-template-rows: ${e.viewModel.rowStyle};\n                    ${e.viewModel.gridStyles};\n                `}">
                ${e=>e.getHeaderValues().length>0?y:""}
                ${w}
            </div>
        </div>
    </a>
`,z=u.qy`
    ${(0,v.z)(e=>null!=e.viewModel,k)}
`;var S=i(92079);class T extends S.a{constructor(){super(...arguments),this.getKeys=()=>this.viewModel.data.keys,this.getHeaderValues=()=>{const{header:e}=this.viewModel.data;return e?this.getKeys().map(t=>e[t]):[]},this.isLarge=()=>"_1x_3y"===this.viewModel.cardSize,this.getAllBodyCells=()=>{const e=[],t=this.getKeys();return this.viewModel.data.body.forEach(i=>{t.forEach(t=>e.push(i[t]))}),e}}}let j=class extends T{};j=(0,a.Cg)([(0,r.E)({name:"sports-table",template:z,styles:b,shadowOptions:{delegatesFocus:!0}})],j)},42792(e,t,i){i.d(t,{R7(){return f},e(){return g},kc(){return x},nH(){return h}});var a=i(57416),r=i(55153),o=i(95239),s=i(26920),n=i(48751),l=i(64187),d=i(22131),c=i(74849),p=i(50882);const h=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,g=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${s.XA} * 1px) solid ${r.cu};
        border-radius: calc((${a.JU} - ${s.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${n.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${r.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${r.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${s.XA} * 1px) ${r.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${r.QG} * 1px);
        height: calc(${r.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${r.QG} * 1px);
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc(${r.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,x=(0,d.mr)(c.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),f=c.A`
    ${g}
    ${h}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(x)},63030(e,t,i){i.r(t),i.d(t,{SportsTennisMatch(){return C}});var a=i(56911),r=i(92011),o=i(74849),s=i(22131),n=i(48751),l=i(62047),d=i(41123),c=i(61138),p=i(86856),h=i(12640),g=i(4968);const x=o.A` .live-info{background:rgba(255,153,164,1);color:rgba(68,39,38,1);border:1px solid rgba(255,153,164,1)}.triangle{background-color:rgba(255,255,255,1)}`,f=o.A` .triangle{transform:rotate(180deg)}.left{transform:rotate(0deg)}`,b=o.A` .match-card{width:268px;height:66px;text-decoration:none;padding:7px 12px;border-radius:8px;display:flex;flex-direction:row;justify-content:space-between;align-items:center;background:none;box-sizing:border-box;color:${n.l};
        ${g.f}}.match-card >div:nth-of-type(3){align-items:end}.match-name{height:50px;width:64px;display:flex;flex-direction:column;justify-content:space-between}.match-name > div{display:inline-block}.match-name > div:nth-of-type(2){height:10px;max-width:100%;line-height:10px;font-size:${l.t};
        font-weight: 400;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    .match-name > div:nth-of-type(3){
        height: 14px;
        max-width: 100%;
        line-height: 10px;
        font-size: ${d.K};font-weight:700;text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.middle-info{width:110px;font-size:${l.t};display:flex;flex-direction:column;justify-content:center}.middle-info >div{display:flex;justify-content:center;align-items:center;min-height:${l.e};max-width:100%}.middle-info >div >span{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.des-mid{font-size:${d.K};font-style:normal;font-weight:600}.triangle{margin:0 2px;width:4px;height:8px;background-color:rgba(36,36,36,1);clip-path:polygon(0 0,0% 100%,100% 50%)}.left{transform:rotate(180deg)}.live-info{height:18px;line-height:18px;padding:0 4px;margin:2px 0;background:#C42B1C;font-size:${c.k};font-weight:600;color:rgba(255,255,255,1);border-radius:4px;border:1px solid #C42B1C}.match-icon{width:16px;height:16px}`.withBehaviors(new p.t(null,f),new h.N(null,x),(0,s.mr)(o.A` :host{forced-color-adjust:auto}`));var u=i(96950),m=i(69259);const v=u.qy`
    <div class="match-name">
        <div>
            <img class="match-icon" role="presentation" src="${e=>e.viewModel.participant1.icon}"/>
        </div>
        <div>${e=>e.viewModel.participant1.firstName}</div>
        <div>${e=>e.viewModel.participant1.lastName}</div>
    </div>
`,$=u.qy`
    <div class="match-name">
        <div>
            <img class="match-icon" role="presentation" src="${e=>e.viewModel.participant2.icon}"/>
        </div>
        <div>${e=>e.viewModel.participant2.firstName}</div>
        <div>${e=>e.viewModel.participant2.lastName}</div>
    </div>
`,y=u.qy`
    <div class="live-info">${e=>e.viewModel.strings.sportsLive}</div>
`,w=u.qy`
    ${e=>"left"===e.viewModel.winner?u.qy`<div class="triangle left"></div>`:""}
    <div>${e=>e.viewModel.matchDesMiddle}</div>
    ${e=>"right"===e.viewModel.winner?u.qy`<div class="triangle"></div>`:""}
`,k=u.qy`
    <div class="middle-info">
        <div><span>${e=>e.viewModel.matchDesTop}</span></div>
        <div class="des-mid">
            ${e=>e.viewModel.isLive?y:w}
        </div>
        <div><span>${e=>e.viewModel.matchDesBottom}</span></div>
    </div>
`,z=u.qy`
    <a class="match-card" data-t="${e=>e.viewModel.telemetryTag}"
        href="${e=>e.viewModel.clickthroughUrl?e.viewModel.clickthroughUrl:void 0}"
        target="${e=>e.viewModel.linkTarget}"
    >
        ${v}
        ${k}
        ${$}
    </a>
`,S=u.qy`
    ${(0,m.z)(e=>null!=e.viewModel,z)}
`;var T=i(92079);class j extends T.a{}let C=class extends j{};C=(0,a.Cg)([(0,r.E)({name:"sports-tennis-match",template:S,styles:b,shadowOptions:{delegatesFocus:!0}})],C)},63868(e,t,i){i.r(t),i.d(t,{SportsSpotlightTennisTransformer(){return c},SportsTennisMatchTransformer(){return p}});var a=i(49150),r=i(23587),o=i(79811),s=i(96950),n=i(22341),l=i(85312),d=i(58792);class c extends r.Bc{async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,o.jJ)();const i=await this.getCurrentViewModel(e);return{viewTemplate:s.qy`
                <sports-spotlight-tennis
                    :viewModel="${i}"
                ></sports-spotlight-tennis>
            `}}async getCurrentViewModel(e){const{telemetryBuilder:t}=this.transformerProvider;if(!e.sportsSpotlightTennisData||!e.sportsSpotlightTennisData.match)return void(0,n.vV)(l.Ax,"Spotlight Tennis Match data missing",`market=${d.T3.CurrentMarket}`,JSON.stringify(e));const i=e.sportsSpotlightTennisData.match,{state:o}=i.gameState;let s,c,p;if(o!==r.T0.Live&&o!==r.T0.InProgress||this.cardSize!==a.uE._1x_2y){if(o!==r.T0.PreGame){var h;s=null!==(h=e.sportsSpotlightTennisData)&&void 0!==h&&h.statistics?await this.getStatsData(e):void 0}}else s=void 0;return o===r.T0.PreGame&&(c=await this.getPlayInfoTableData(e)),o!==r.T0.Live&&o!==r.T0.InProgress||(p=await this.getScoreTableData(e)),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsSpotlightTennisCard}),sportsSpotlightTennisData:e.sportsSpotlightTennisData,matchView:await this.getMatchView(e),statsData:s,scoreCardTableData:p,playerInfoTableData:c}}async getMatchView(e){const t={parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,matchData:e.sportsSpotlightTennisData.match};return await this.transformerProvider.generateView(t,r.hi.SportsTennisMatch)}getScoreValue(e){if(e&&e.length>0){const t=e.split("_");return 2===t.length?{value:t[0],index:t[1]}:{value:e}}return{value:"-"}}async getScoreTableData(e){const{telemetryBuilder:t}=this.transformerProvider,{scoreCardInfo:i}=e.sportsSpotlightTennisData;if(!i||!i.scoreCards||0===i.scoreCards.length)return void(0,n.vV)(l.Ax,"Spotlight Tennis ScoreCard data missing",`market=${d.T3.CurrentMarket}`,JSON.stringify(e));const a={keys:["name","round1","round2","round3"],header:{name:{value:this.transformerProvider.strings.scoreCard,class:"bold no-border"},round1:{value:"1",cellClass:"bottom",class:"right bold no-border"},round2:{value:"2",cellClass:"bottom",class:"right bold no-border"},round3:{value:"3",cellClass:"bottom",class:"right bold no-border"}},body:i.scoreCards.map(e=>({name:{value:e.name||"-",cellClass:"top",class:"left"},round1:{...this.getScoreValue(e.round1),cellClass:"bottom",class:"right"},round2:{...this.getScoreValue(e.round2),cellClass:"bottom",class:"right"},round3:{...this.getScoreValue(e.round3),cellClass:"bottom",class:"right"}}))};return{telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:`${r.BP.SportsSpotlightTennisCard}ScoreTable`}),cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,data:a,columnStyle:"140px minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr)",rowStyle:"repeat(3, 28px)"}}async getPlayInfoTableData(e){const{telemetryBuilder:t,strings:i}=this.transformerProvider,{playerInfo:o}=e.sportsSpotlightTennisData;if(!o||!o.players||2!==o.players.length)return void(0,n.vV)(l.Ax,"Spotlight Tennis player data missing",`market=${d.T3.CurrentMarket}`,JSON.stringify(e));const s=i.playerBios;let c=["currentRank","age","birthPlace","weight","height","turnedPro","plays","ytdWinLoss","ytdTitles","careerWin","careerLoss","careerTitles"];this.cardSize===a.uE._1x_2y&&(c=["currentRank","age","birthPlace","ytdWinLoss","ytdTitles"]);const p=o.players[0],h=o.players[1],g=this.cardSize===a.uE._1x_3y?9:4,x={title:s,keys:["left","middle","right"],body:c.slice(0,g).map(e=>{let t=p[e],a=h[e];return"currentRank"===e&&(t=`#${t}`,a=`#${a}`),{left:{value:p[e]?t:"N/A",cellClass:"top",class:"left bold"},middle:{value:i[e]||e,cellClass:"middle",class:"center"},right:{value:h[e]?a:"N/A",cellClass:"bottom",class:"right bold"}}})},f=this.cardSize===a.uE._1x_3y?"repeat(9, 28px)":"repeat(4, 28px)";return{telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:`${r.BP.SportsSpotlightTennisCard}PlayInfoTable`}),cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,data:x,columnStyle:"minmax(0, 1fr) minmax(0, 1fr) minmax(0, 1fr)",rowStyle:f}}async getStatsData(e){var t;const{telemetryBuilder:i,strings:o}=this.transformerProvider,s=e.sportsSpotlightTennisData.match,{state:c}=s.gameState,{statistics:p}=e.sportsSpotlightTennisData||{};if(!p||!p.season&&!p.game)return void(0,n.vV)(l.Ax,"Spotlight Tennis statistic data missing",`market=${d.T3.CurrentMarket}`,JSON.stringify(e));let h=4,g=!1;c===r.T0.Final&&(h=this.cardSize===a.uE._1x_3y?6:3,g=this.cardSize===a.uE._1x_3y);const x=p.season||p.game;let f;if(x&&2===x.length){const e=x[0],t=x[1];f=(p.statsKeyOrder||Object.keys(e)).slice(0,h).map(i=>{const a=e[i],r=parseFloat(a),s=t[i],n=parseFloat(s),l=Math.max(r,n)||1,d=100*r/l+"%",c=100*n/l+"%";return{text:o[i]||i,leftDes:a,rightDes:s,leftPercent:d,rightPercent:c}})}const b={...null===(t=e.sportsSpotlightTennisData)||void 0===t?void 0:t.statsInfo,statsList:f};return{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,telemetryTag:i.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:`${r.BP.SportsSpotlightTennisCard}Stats`}),tennisStatsInfo:b,isLarge:g,strings:{playerStats:o.playerStats}}}}class p extends r.Bc{async transform(e){this.isInDarkMode=(0,o.jJ)();return{viewModel:await this.getCurrentViewModel(e)}}async getCurrentViewModel(e){const{telemetryBuilder:t}=this.transformerProvider,{matchData:i}=e,{state:a}=i.gameState,s=(0,o.yn)(i.gameStartDateTime),n=(0,o.AL)(s,d.T3.CurrentMarket||"en-us"),l=a===r.T0.Live||a===r.T0.InProgress?i.roundInfo:n,c=a===r.T0.Final?this.transformerProvider.strings.sportsStateFinal:(0,o.ry)(s,d.T3.CurrentMarket||"en-us"),p={icon:(0,o.iK)(i.participantOne.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),firstName:i.participantOne.firstName,lastName:i.participantOne.lastName},h={icon:(0,o.iK)(i.participantTwo.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),firstName:i.participantTwo.firstName,lastName:i.participantTwo.lastName};let g;a===r.T0.Final&&(g=i.participantOne.isWinner?"left":"right");const x=a===r.T0.Live||a===r.T0.InProgress;return{telemetryTag:t.createNavClickTelemetryTag(e.parentTelemetryObject,{...e.telemetryConstants,name:r.BP.Game}),isDarkModeTheme:this.isInDarkMode,matchDesTop:i.gameDes,matchDesBottom:l,matchDesMiddle:c,participant1:p,participant2:h,gameState:i.gameState,winner:g,isLive:x,linkTarget:"_blank",clickthroughUrl:(0,o.Ot)(i.gameCenterUrl),strings:{sportsLive:this.transformerProvider.strings.sportsLive}}}}Promise.resolve().then(i.bind(i,11526)),Promise.resolve().then(i.bind(i,63030)),Promise.resolve().then(i.bind(i,2623)),Promise.resolve().then(i.bind(i,17471))},92079(e,t,i){i.d(t,{a(){return s}});var a=i(56911),r=i(92011),o=i(31525);let s=class extends r.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};s=(0,a.Cg)([o.x],s)},99657(e,t,i){i.d(t,{D(){return s},I(){return o}});var a=i(45755);const{create:r}=a.G,o=r("sloppy-click-z-index",1),s=r("click-z-index",1)}}]);