"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-span"],{43678(t,e,i){i.r(e),i.d(e,{SportsSpanMatch(){return B}});var a=i(56911),s=i(84564),n=i(60815),o=i(55230),r=i(51705),l=i(54229),h=i(74998),c=i(17918),d=i(69914);const v="ocid",p="s_artexp_tpspn",u="s_artexp_stkspn",m="sports-overlay-ready",g="sports-overlay-open";var f=i(85312),x=i(40865);class y extends s.z{constructor(){super(...arguments),this.isStickyVertical=!1,this.showOverlay=!1,this.overlayHasBeenOpened=!1,this.overlayStartedLoad=!1,this.isItemHovered=!1,this.isOverlayContentReady=!1,this.index=-1,this.overlayStyle="",this.isInView=!0,this.readyMessageCallback=t=>{l.aC.safeExecute(()=>{var e;const i=t;"sports overlay ready"===i.data&&(i.stopPropagation(),this.isOverlayContentReady=!0,this.dispatchEvent(new CustomEvent(m)),null===(e=this.overlayIFrame)||void 0===e||null===(e=e.contentWindow)||void 0===e||e.removeEventListener("message",this.readyMessageCallback),function(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:performance.now();const i=!0===h.Rb.IsPrerender?e-(0,c.W4)(d.xF):e;(0,c.tD)(t,i)}(`Overlay.${this.index}.Ready`))},void 0,f.x1,"SportsInfoSpan - exception while reading ready overlay message for match item")},this.onSomeOverlayOpen=t=>{l.aC.safeExecute(()=>{var e;(null==t||null===(e=t.detail)||void 0===e?void 0:e.index)!==this.index&&this.handleItemFocus(t,!1)},void 0,f.x1,"SportsInfoSpan - exception while reading overlay open message")},this.onOutsideClick=t=>{const e=t.composedPath()&&t.composedPath()[0];this.itemElement&&(0,x.W)(this.itemElement,e)||this.handleItemFocus(t,!1)},this.onMatchItemKeydown=t=>{switch(null==t?void 0:t.key){case o.J9:return!0;case o.F9:return this.handleItemFocus(t,!1),!1;default:return!1}}}get overlayUrl(){const t=new URL(this.viewModel.clickThroughUrl),e=this.isStickyVertical?u:p,i=t.searchParams;return i.has(v)&&i.delete(v),i.set("noHeader","true"),i.set("skipAuth","true"),i.set("src",e),this.sportsSpalink&&i.set("item",this.sportsSpalink),t.href}get clickThroughUrl(){const t=new URL(this.viewModel.clickThroughUrl),e=this.isStickyVertical?u:p;return t.searchParams.set("src",e),t.href}overlayIFrameOnload(){var t;!this.overlayStartedLoad&&null!==(t=this.overlayIFrame)&&void 0!==t&&t.contentWindow&&(this.overlayIFrame.contentWindow.document.addEventListener("keydown",this.onMatchItemKeydown),this.overlayIFrame.contentWindow.addEventListener("message",this.readyMessageCallback),this.overlayStartedLoad=!0,this.overlayIFrame.contentWindow.document.body.style.overscrollBehavior="contain")}disconnected(){var t;null===(t=this.overlayIFrame)||void 0===t||null===(t=t.contentWindow)||void 0===t||t.document.removeEventListener("keydown",this.onMatchItemKeydown)}executeAfterOverlayReady(t){const e=t?this.sendSportsPageViewEvent.bind(this):this.sendSportsOverlayClosedMessage.bind(this);this.isOverlayContentReady?e():this.addEventListener(m,e,{once:!0})}sendSportsPageViewEvent(){var t;null!==(t=this.overlayIFrame)&&void 0!==t&&t.contentWindow&&this.overlayIFrame.contentWindow.postMessage("sports overlay visible",this.overlayUrl??"")}sendSportsOverlayClosedMessage(){var t;null!==(t=this.overlayIFrame)&&void 0!==t&&t.contentWindow&&this.overlayIFrame.contentWindow.postMessage("sports overlay closed",this.overlayUrl??"")}toggleOverlay(t){var e;(this.overlayHasBeenOpened=t||this.overlayHasBeenOpened,this.showOverlay=t,t)?(this.parentElement&&(this.parentElement.dispatchEvent(new CustomEvent(g,{detail:{index:this.index}})),this.parentElement.addEventListener(g,this.onSomeOverlayOpen)),document.addEventListener("click",this.onOutsideClick)):(document.removeEventListener("click",this.onOutsideClick),null===(e=this.parentElement)||void 0===e||e.removeEventListener(g,this.onSomeOverlayOpen))}sendHoverTelemetry(t,e){l.aC.safeExecute(()=>{e?(0,l.Eh)(t):(0,l.Ai)(t)},void 0,f.J2,`SportsInfoSpan - issue sending ${e?"mouseenter":"mouseleave"} telemetry event for ${t} target`)}handleItemFocus(t,e){if(!t)return;t.stopPropagation();const i=t.currentTarget;this.isItemHovered=e,window.setTimeout(()=>{if(this.showOverlay!==e)return this.viewModel.disableHoverOverlay?(this.showOverlay=e,void this.sendHoverTelemetry(i,e)):void((this.isItemHovered&&e||this.showOverlay&&!e)&&(this.toggleOverlay(e),this.sendHoverTelemetry(i,e),this.executeAfterOverlayReady(e)))},this.isStickyVertical?this.viewModel.stickySpanHoverDelay:this.viewModel.topSpanHoverDelay)}onMatchItemFocus(t,e){!r.s||!e&&(t=>{const e=null==t?void 0:t.composedPath();if(!e||e.length<1)return!1;const i=e[0];return null==i?void 0:i.classList.contains("i-tag")})(t)||this.handleItemFocus(t,e)}openLink(t){if(!t)return;t.stopPropagation();const e=this.clickThroughUrl;e&&(l.aC.safeExecute(()=>{const i=t.currentTarget;(0,l.dI)(i,e)},void 0,f.J2,`SportsInfoSpan - issue sending  navclick telemetry event for ${t.currentTarget} target: ${e}`),window.open(e,"_blank"))}onKeyDown(t){switch(null==t?void 0:t.key){case o.J9:return!0;case" ":case o.Mm:return this.openLink(t),!1;default:return!1}}}(0,a.Cg)([n.sH],y.prototype,"isStickyVertical",void 0),(0,a.Cg)([n.sH],y.prototype,"showOverlay",void 0),(0,a.Cg)([n.sH],y.prototype,"overlayHasBeenOpened",void 0),(0,a.Cg)([n.sH],y.prototype,"overlayStartedLoad",void 0),(0,a.Cg)([n.sH],y.prototype,"isItemHovered",void 0),(0,a.Cg)([n.sH],y.prototype,"isOverlayContentReady",void 0),(0,a.Cg)([n.sH],y.prototype,"index",void 0),(0,a.Cg)([n.sH],y.prototype,"overlayStyle",void 0),(0,a.Cg)([n.sH],y.prototype,"isInView",void 0),(0,a.Cg)([n.sH],y.prototype,"sportsSpalink",void 0);var w=i(92011),$=i(4283),b=i(86856),S=i(74849),k=i(22131);const T=S.A` .i-tag{color:#FFFFFF}.h-match-item .i-tag{background:rgba(255,255,255,0.09)}.h-match-item .i-tag.o-active{background:rgba(255,255,255,0.13)}.v-match-item .i-tag{background:#424242}.v-match-item .i-tag.o-active{background:#4F4F4F}.live-str{color:#FF6341}.vs-str{color:rgba(255,255,255,0.54)}`,F=S.A`
.if-container{margin-left:var(--overlay-horizontal-offset)}.v-match-item .if-container{padding-left:${16..toString()}px;
}
`,I=S.A`
.if-container{margin-right:var(--overlay-horizontal-offset)}.v-match-item .if-container{padding-right:${16..toString()}px;
}
`,M=S.A` .i-tag{color:rgba(0,0,0,0.83);cursor:pointer}.ncmatch{text-decoration:none}.h-match-item.not-inview{position:absolute;z-index:-99}.h-match-item .i-tag{background:rgba(0,0,0,0.04);display:grid;grid-template-columns:auto auto auto auto;column-gap:6px;align-items:center;width:max-content;font-size:12px;padding:4px 12px;border-radius:6px;line-height:24px}.h-match-item .i-tag.ind-match{grid-template-columns:auto auto}.h-match-item .i-tag.o-active{background:#EBEBEB}.v-match-item .i-tag{background:#FFFFFF;box-shadow:0px 2px 4px rgba(0,0,0,0.1);display:flex;flex-direction:column;gap:4px;align-items:flex-start;font-size:10px;padding:8px;border-radius:4px}.v-match-item .i-tag.o-active{background:#EFEFEF;box-shadow:0px 3px 6px rgba(0,0,0,0.12)}.match-p{display:grid;grid-template-columns:24px fit-content(75px);column-gap:2px;align-items:center}.h-match-item .ind-match .match-p{grid-template-columns:24px fit-content(175px)}.h-match-item .match-p img{width:24px;height:24px}.h-match-item .match-p .mp-icon{width:24px;height:24px}.mp-name{font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.vs-str{color:#717171}.v-match-item{width:78px;height:70px}.v-match-item .g-state-str{line-height:14px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100%}.v-match-item .match-p{grid-template-columns:16px 44px;line-height:16px}.v-match-item .match-p img{width:16px;height:16px}.v-match-item .match-p .mp-icon{width:16px;height:16px}.live-str{text-transform:uppercase;color:#C42B1C}.if-container{position:absolute;z-index:${200..toString()};background:transparent;width:var(--iframe-width);height:var(--iframe-height)}.h-match-item .if-container{padding-top:var(--overlay-vertical-offset)}.v-match-item .if-container{margin-top:var(--overlay-vertical-offset)}iframe{border:0;overflow-y:scroll;overflow-x:hidden;width:var(--iframe-width);height:var(--iframe-height);border-radius:6px;box-shadow:0px 16px 32px rgba(0,0,0,0.14)}.hide{display:none}.details-overlay-btn{width:max-content;padding:8px 20px;background:${$.IR};
        color: white;
        border: none;
        cursor: pointer;
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
        border-radius: 20px;
        position: absolute;
        bottom: 16px;
        left: 50%;
        transform: translateX(-50%);
    }

`.withBehaviors(new b.t(F,I),(0,k.G2)(T));var O=i(96950),E=i(60402),_=i(69259);const D=O.qy`
<button class="details-overlay-btn"
    tabindex="${t=>t.showOverlay?"0":"-1"}"
    title="${t=>t.viewModel.seeDetailsString}"
    aria-label="${t=>t.viewModel.seeDetailsString}"
    @click="${(t,e)=>t.openLink(e.event)}"
    @keydown="${(t,e)=>t.onKeyDown(e.event)}"
    data-t="${t=>t.viewModel.overlaySeeDetailsTelemetryTag}"
>
        ${t=>t.viewModel.seeDetailsString}
</button>
`,L=O.qy`
    <iframe class="match-if"
        src="${t=>t.overlayUrl}"
        @load="${t=>t.overlayIFrameOnload()}"
        ${(0,E.K)("overlayIFrame")}
    ></iframe>
`,R=O.qy`
    <div
        class="if-container ${t=>t.showOverlay?"":"hide"}"
        style="${t=>t.overlayStyle}"
        data-t="${t=>t.isStickyVertical?t.viewModel.stickySpanOverlayTelemetryTag:t.viewModel.topSpanOverlayTelemetryTag}"
    >
        ${(0,_.z)(t=>t.overlayHasBeenOpened,L)}
        ${D}
    </div>
`,V=(t,e)=>O.qy`
    <span class="mp-icon">
        <img
            role="presentation"
            src="${t}"
        />
    </span>
    <span class="mp-name">
        ${e}
    </span>
`,H=t=>{return O.qy`
    <span class="g-state-str ${t=>t.viewModel.isLive?"live-str":""}">
        ${t=>t.viewModel.gameStateString}
    </span>
    <span class="match-p">
        ${t=>V(t.viewModel.participantOneImgIcon||"",t.viewModel.participantOneName)}
    </span>
    ${(0,_.z)(t=>!t.viewModel.isIndividualMatch,(e=!t,O.qy`
    ${(0,_.z)(()=>e,O.qy`<span class="vs-str">
            ${t=>t.viewModel.versusString}
        </span>`)}
    <span class=" match-p">
        ${t=>V(t.viewModel.participantTwoImgIcon||"",t.viewModel.participantTwoName)}
    </span>
`))}
`;var e},N=O.qy`
    <div class="i-tag ${t=>t.showOverlay?"o-active":""} ${t=>t.viewModel.isIndividualMatch?"ind-match":""}"
        tabindex="${t=>t.isInView&&!t.viewModel.disableHoverOverlay?"0":"-1"}"
        aria-label=""
    >
        ${t=>H(t.isStickyVertical)}
    </div>
`,z=O.qy`
    <a class="ncmatch ${t=>t.isStickyVertical?"v-match-item":"h-match-item"}"
        @mouseenter=${(t,e)=>t.handleItemFocus(e.event,!0)}
        @mouseleave=${(t,e)=>t.handleItemFocus(e.event,!1)}
        @focusin=${(t,e)=>t.onMatchItemFocus(e.event,!0)}
        @focusout=${(t,e)=>t.onMatchItemFocus(e.event,!1)}
        href="${t=>t.clickThroughUrl}"
        target="_blank"
        title=""
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        ${N}
    </a>
`,C=O.qy`
<div class="${t=>t.isStickyVertical?"v-match-item":"h-match-item"}${t=>t.isInView?"":" not-inview"}"
        @mouseenter=${(t,e)=>t.handleItemFocus(e.event,!0)}
        @mouseleave=${(t,e)=>t.handleItemFocus(e.event,!1)}
        @focusin=${(t,e)=>t.onMatchItemFocus(e.event,!0)}
        @focusout=${(t,e)=>t.onMatchItemFocus(e.event,!1)}
        @keydown=${(t,e)=>t.onMatchItemKeydown(e.event)}
        data-t="${t=>t.viewModel.telemetryTag}"
        ${(0,E.K)("itemElement")}
    >
        ${N}
        ${R}
    </div>
`,A=O.qy`
    ${t=>t.viewModel.disableHoverOverlay?z:C}
`;let B=class extends y{};B=(0,a.Cg)([(0,w.E)({name:"sports-span-match",template:A,styles:M,shadowOptions:{delegatesFocus:!0}})],B)},46323(t,e,i){i.r(e),i.d(e,{SportsInfoSpanTransformer(){return c},SportsSpanMatchTransformer(){return v}});var a=i(23587),s=i(54229),n=i(85312),o=i(50180),r=i(79811),l=i(2171);const h=["Soccer_SpainLaLiga","Racing_Formula1","Racing_IRL","Racing_MotoGP"];class c extends a.pC{constructor(){super(...arguments),this.telemetryConstants={}}static getInstance(t,e){const i=`SportsInfoSpanTransformer_${t}`,a=l.vv.get(i,()=>({}));return a[i]||(a[i]=new c(e)),a[i]}async transform(t){this.parentTelemetryObject=t.get(a.mx.rootTelemetryObject);const e=t.get(a.mx.sportsFeedDataParsed),i=this.getV2TabData(e),s=null==e?void 0:e.sportsMatchupCardData;this.setTelemetry(i,s);return{viewModel:await this.getViewModel(e,i,s)}}getV2TabData(t){var e;const i=null==t||null===(e=t.Model)||void 0===e?void 0:e.Tabs;if(i&&!(i.length<1))return i[0]}setTelemetry(t,e){var i;const s=(null==t||null===(i=t.tabContent)||void 0===i||null===(i=i.league)||void 0===i?void 0:i.id)||(null==e?void 0:e.sportType),n=(null==t?void 0:t.primaryEntityId)||(null==e?void 0:e.leagueId);this.transformerProvider.telemetryBuilder.initTelemetryBuilder(a.BP.Vertical,s,void 0,void 0,n),this.telemetryObject=this.transformerProvider.telemetryBuilder.createViewTelemetryObject(this.parentTelemetryObject,{name:a.BP.SportsTopSpan})}async getViewModel(t,e,i){return{matches:await this.getMatchViews(t,e),title:this.getSpanTitle(t,e,i),telemetryTag:this.transformerProvider.telemetryBuilder.createTelemetryObjectTag(this.telemetryObject),stickySpanTelemetryTag:this.transformerProvider.telemetryBuilder.createViewTelemetryTag(this.parentTelemetryObject,{name:a.BP.SportsStickySpan})}}static isMotorSportsMatch(t){return[a.v1.MotorSportsRaceList,a.v1.MotorSportsSingleRace].includes(t)}static isGolfMatch(t){return[a.v1.GolfLeaderBoard,a.v1.GolfSchedule].includes(t)}static isTennisMatch(t){return a.v1.Tennis===t}getTitlesForTabType(t){const e={generic:this.transformerProvider.strings.sportSpanGenericTitle,league:this.transformerProvider.strings.leagueSpanTitle,leagueNoArt:this.transformerProvider.strings.leagueSpanTitleNoArticle,team:this.transformerProvider.strings.teamSpanTitle};return t?c.isMotorSportsMatch(t)||c.isGolfMatch(t)?{generic:this.transformerProvider.strings.featuredTournaments,league:this.transformerProvider.strings.featuredLeagueTournaments,leagueNoArt:this.transformerProvider.strings.featuredLTournamentsNoArt,team:this.transformerProvider.strings.teamSpanTitle}:c.isTennisMatch(t)?{generic:this.transformerProvider.strings.featuredMatches,league:this.transformerProvider.strings.featuredLeagueMatches,leagueNoArt:this.transformerProvider.strings.featuredLMatchesNoArt,team:this.transformerProvider.strings.teamSpanTitle}:e:e}getSpanTitle(t,e,i){const s=null==t?void 0:t.ArticleResponseType,n=null==e?void 0:e.tabType,r=this.getTitlesForTabType(n);switch(s){case a.bo.Mentioned:{let t,a;if("Team"===((null==e?void 0:e.primaryEntityType)||(null==i?void 0:i.primaryEntityType)))t=r.team,a=(null==e?void 0:e.primaryEntityName)||(null==i?void 0:i.primaryEntityName);else{var l,c;const s=(null==e||null===(l=e.tabContent)||void 0===l||null===(l=l.league)||void 0===l?void 0:l.id)||(null==i?void 0:i.leagueId);t=h.includes(s??"")?r.leagueNoArt:r.league,a=(null==e||null===(c=e.tabContent)||void 0===c||null===(c=c.league)||void 0===c?void 0:c.name)||(null==i?void 0:i.leagueName)}return t&&a?(0,o.GP)(t,a):r.generic}case a.bo.Related:default:return r.generic}}async getMatchViews(t,e){const i=this.getSportsMatchOverallData(t,e);if(!i)return[];const s=i.map(async t=>{const i={matchData:t,parentTelemetryObject:this.telemetryObject,telemetryConstants:this.telemetryConstants,tabType:null==e?void 0:e.tabType};return this.transformerProvider.generateView(i,a.hi.SportsSpanMatch)});return(await Promise.all(s)).filter(r.z2)}getSportsMatchOverallData(t,e){var i;return e?s.aC.safeExecute(()=>{var t;return(null===(t=e.tabContent)||void 0===t||null===(t=t.league)||void 0===t||null===(t=t.sportsMatches)||void 0===t?void 0:t.map(t=>({sportsMatchData:t})))||[]},void 0,n.ON,`Sports V2 sportsMatches is not valid. sportsMatches=${JSON.stringify(null===(i=e.tabContent)||void 0===i||null===(i=i.league)||void 0===i?void 0:i.sportsMatches)}; tabType=${e.tabType};`):null==t?void 0:t.sportsMatchOverallData}}var d=i(58792);class v extends a.pC{async transform(t){return{viewModel:await this.getViewModel(t)}}static isIndividualMatch(t){return!!t&&(v.isMotorSportsMatch(t)||v.isGolfMatch(t))}static isMotorSportsMatch(t){return[a.v1.MotorSportsRaceList,a.v1.MotorSportsSingleRace].includes(t)}static isGolfMatch(t){return[a.v1.GolfLeaderBoard,a.v1.GolfSchedule].includes(t)}static isMotorSportsLive(t){var e;return(null===(e=t.sessions)||void 0===e?void 0:e.some(t=>"InProgress"===t.sessionStatus))||!1}static getIndividualGameEndDate(t,e){let i=t.gameEndDateTime;var a;null==i&&v.isMotorSportsMatch(e)&&(i=null===(a=t.sessions)||void 0===a||null===(a=a.at(-1))||void 0===a?void 0:a.endDateTime);return i&&(0,r.AL)((0,r.yn)(i),d.T3.CurrentMarket)||t.gameDate}getGameStateString(t,e){switch(t.gameStateCatetory){case a.Xp.preGame:return t.gameDate;case a.Xp.inprogressGame:return v.isMotorSportsMatch(e)&&!v.isMotorSportsLive(t)?this.transformerProvider.strings.sportsInProgress:this.transformerProvider.strings.sportsLive;case a.Xp.postGame:return v.isIndividualMatch(e)?`${this.transformerProvider.strings.sportsStateFinal} · ${v.getIndividualGameEndDate(t,e)}`:this.transformerProvider.strings.sportsStateFinal;default:return""}}getIndividualMatchViewModelOverride(t,e,i){let s="";v.isMotorSportsMatch(i)?s=null==t?void 0:t.raceName:v.isGolfMatch(i)&&(s=null==t?void 0:t.name);const n=(0,r.iK)(t.imageId,!1,e);return{participantOneImgIcon:(0,r._K)(n,e.height,e.width,!0),participantTwoImgIcon:null,participantOneName:s||"",participantTwoName:"",gameStateString:this.getGameStateString(t,i),isLive:v.isMotorSportsMatch(i)?v.isMotorSportsLive(t):t.gameStateCatetory===a.Xp.inprogressGame,isIndividualMatch:!0}}getViewModel(t){var e,i,s,n;const o=t.matchData.sportsMatchData,l=this.transformerProvider.config.teamImageInfo;let h={};"string"!=typeof o.gameState&&(o.gameStateCatetory=(0,r.m5)(o.gameState.state));const c=(0,r.yn)(o.gameStartDateTime);return o.gameDate=(0,r.AL)(c,d.T3.CurrentMarket),o.gameCenterUrl&&(o.matchClickthroughUrl=(0,r.Ot)(o.gameCenterUrl)),o.participantOne&&(o.participantOne.imageUrl=(0,r.iK)(o.participantOne.imageId,!1,l)),o.participantTwo&&(o.participantTwo.imageUrl=(0,r.iK)(o.participantTwo.imageId,!1,l)),v.isIndividualMatch(t.tabType)&&(h=this.getIndividualMatchViewModelOverride(o,l,t.tabType)),{participantOneImgIcon:(0,r._K)(null===(e=o.participantOne)||void 0===e?void 0:e.imageUrl,l.height,l.width,!0),participantTwoImgIcon:(0,r._K)(null===(i=o.participantTwo)||void 0===i?void 0:i.imageUrl,l.height,l.width,!0),participantOneName:(null===(s=o.participantOne)||void 0===s?void 0:s.name)||"",participantTwoName:(null===(n=o.participantTwo)||void 0===n?void 0:n.name)||"",gameStateString:this.getGameStateString(o),isLive:o.gameStateCatetory===a.Xp.inprogressGame,versusString:this.transformerProvider.strings.sportsVS,seeDetailsString:this.transformerProvider.strings.seeDetailsButton,clickThroughUrl:o.matchClickthroughUrl,overlayWidth:this.transformerProvider.config.overlayWidth,overlayHeight:this.transformerProvider.config.overlayHeight,disableHoverOverlay:this.transformerProvider.config.disableHoverOverlay,topSpanHoverDelay:this.transformerProvider.config.topSpanHoverDelay,stickySpanHoverDelay:this.transformerProvider.config.stickySpanHoverDelay,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.parentTelemetryObject,{...t.telemetryConstants,name:a.BP.Game}),topSpanOverlayTelemetryTag:this.transformerProvider.telemetryBuilder.createViewTelemetryTag(t.parentTelemetryObject,{...t.telemetryConstants,name:a.BP.SportsTopSpanOverlay}),stickySpanOverlayTelemetryTag:this.transformerProvider.telemetryBuilder.createViewTelemetryTag(t.parentTelemetryObject,{...t.telemetryConstants,name:a.BP.SportsStickySpanOverlay}),overlaySeeDetailsTelemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.parentTelemetryObject,{...t.telemetryConstants,name:a.BP.SeeDetails,headline:this.transformerProvider.strings.seeDetailsButton}),...h}}}Promise.resolve().then(i.bind(i,43678))},51705(t,e,i){i.d(e,{s(){return s}});var a=i(94043);let s=!1;(0,a.S)()&&(window.addEventListener("keydown",()=>{s=!0}),window.addEventListener("mousedown",()=>{s=!1}))},84564(t,e,i){i.d(e,{z(){return o}});var a=i(56911),s=i(60815),n=i(92011);class o extends n.L{}(0,a.Cg)([s.sH],o.prototype,"viewModel",void 0)}}]);