"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_feedback-dialog-wc_dist_index_js"],{4912(t,e,i){i.d(e,{v(){return r}});var o=i(96950),n=i(69259),a=i(60402),s=i(87656);const r=function(t){const e=o.qy.partial((0,s.g)(t.anchoredRegion));return o.qy`
        ${(0,n.z)(t=>t.tooltipVisible,o.qy`
            <${e}
                fixed-placement="true"
                auto-update-mode="${t=>t.autoUpdateMode}"
                vertical-positioning-mode="${t=>t.verticalPositioningMode}"
                vertical-default-position="${t=>t.verticalDefaultPosition}"
                vertical-inset="${t=>t.verticalInset}"
                vertical-scaling="${t=>t.verticalScaling}"
                horizontal-positioning-mode="${t=>t.horizontalPositioningMode}"
                horizontal-default-position="${t=>t.horizontalDefaultPosition}"
                horizontal-scaling="${t=>t.horizontalScaling}"
                horizontal-inset="${t=>t.horizontalInset}"
                vertical-viewport-lock="${t=>t.horizontalViewportLock}"
                horizontal-viewport-lock="${t=>t.verticalViewportLock}"
                dir="${t=>t.currentDirection}"
                ${(0,a.K)("region")}
            >
                <div class="tooltip" part="tooltip" role="tooltip">
                    <slot></slot>
                </div>
            </${e}>
        `)}
    `}({anchoredRegion:i(7927).m})},9299(t,e,i){i.d(e,{m(){return F}});var o=i(56911),n=i(38493),a=i(60815),s=i(55230),r=i(92011),l=i(56863);class c extends r.L{}class d extends((0,l.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends d{constructor(){super(),this.initialValue="on",this.indeterminate=!1,this.keypressHandler=t=>{if(!this.readOnly&&t.key===s.gG)this.indeterminate&&(this.indeterminate=!1),this.checked=!this.checked},this.clickHandler=t=>{this.disabled||this.readOnly||(this.indeterminate&&(this.indeterminate=!1),this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}}(0,o.Cg)([(0,n.CF)({attribute:"readonly",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",Array)],h.prototype,"defaultSlottedNodes",void 0),(0,o.Cg)([a.sH,(0,o.Sn)("design:type",Boolean)],h.prototype,"indeterminate",void 0);var p=i(37180),u=i(74849),g=i(64187),v=i(73477),b=i(60993),f=i(22131),m=i(50882),$=i(74838),x=i(57416),w=i(26920),y=i(43774),k=i(46203),C=i(7896),S=i(48751),D=i(41123),T=i(95239),A=i(14996),I=i(79288),z=i(48196);const E=u.A`
    ${(0,g.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        margin: calc(${$.vR} * 1px) 0;
        ${""} user-select: none;
    }

    .control {
        position: relative;
        width: calc((${z.D} / 2 + ${$.vR}) * 1px);
        height: calc((${z.D} / 2 + ${$.vR}) * 1px);
        box-sizing: border-box;
        border-radius: calc(${x.Pb} * 1px);
        border: calc(${w.XA} * 1px) solid ${y.nF};
        background: ${k.le};
        outline: none;
        cursor: pointer;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        font-family: ${C.O};
        color: ${S.l};
        ${""} padding-inline-start: calc(${$.vR} * 2px + 2px);
        margin-inline-end: calc(${$.vR} * 2px + 2px);
        cursor: pointer;
        font-size: ${D.K};
        line-height: ${D.Z};
    }

    .checked-indicator {
        width: 100%;
        height: 100%;
        display: block;
        fill: ${S.l};
        opacity: 0;
        pointer-events: none;
    }

    .indeterminate-indicator {
        border-radius: calc((${x.Pb} / 2) * 1px);
        background: ${S.l};
        position: absolute;
        top: 50%;
        left: 50%;
        width: 50%;
        height: 50%;
        transform: translate(-50%, -50%);
        opacity: 0;
    }

    :host(:enabled) .control:hover {
        background: ${k.jM};
        border-color: ${y.vA};
    }

    :host(:enabled) .control:active {
        background: ${k.RS};
        border-color: ${y.p4};
    }

    :host(:${v.N}) .control {
        box-shadow: 0 0 0 2px ${T.p}, 0 0 0 4px ${A.WN};
        border-color: ${A.WN};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${b.Z};
    }

    :host([aria-checked="true"]:not([aria-checked="mixed"])) .checked-indicator,
    :host([aria-checked="mixed"]) .indeterminate-indicator {
        opacity: 1;
    }

    :host([disabled]) {
        opacity: ${I.q};
    }
`.withBehaviors((0,f.mr)(u.A`
            .control {
                forced-color-adjust: none;
                border-color: ${m.A.FieldText};
                background: ${m.A.Field};
            }
            :host(:enabled) .control:hover,
            .control:active {
                border-color: ${m.A.Highlight};
                background: ${m.A.Field};
            }
            .checked-indicator {
                fill: ${m.A.FieldText};
            }
            .indeterminate-indicator {
                background: ${m.A.FieldText};
            }
            :host(:${v.N}) .control {
                border-color: ${m.A.Highlight};
                box-shadow: 0 0 0 2px ${m.A.Field},
                    0 0 0 4px ${m.A.FieldText};
            }
            :host([aria-checked="true"]:${v.N}:enabled) .control {
                box-shadow: 0 0 0 2px ${m.A.Field},
                    0 0 0 4px ${m.A.FieldText};
            }
            :host([aria-checked="true"]) .control {
                background: ${m.A.Highlight};
                border-color: ${m.A.Highlight};
            }
            :host([aria-checked="true"]) .control:hover,
            .control:active {
                background: ${m.A.HighlightText};
            }
            :host([aria-checked="true"]) .checked-indicator {
                fill: ${m.A.HighlightText};
            }
            :host([aria-checked="true"]) .control:hover .checked-indicator {
                fill: ${m.A.Highlight};
            }
            :host([aria-checked="true"]) .indeterminate-indicator {
                background: ${m.A.HighlightText};
            }
            :host([aria-checked="true"]) .control:hover .indeterminate-indicator {
                background: ${m.A.Highlight};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .control {
                forced-color-adjust: none;
                border-color: ${m.A.GrayText};
                background: ${m.A.Field};
            }
            :host([disabled]) .indeterminate-indicator,
            :host([aria-checked="true"][disabled])
                .control:hover
                .indeterminate-indicator {
                forced-color-adjust: none;
                background: ${m.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                forced-color-adjust: none;
                fill: ${m.A.GrayText};
            }
        `));var M=i(96950),B=i(82774),O=i(18893);const P=function(t={}){return M.qy`
        <template
            role="checkbox"
            aria-checked="${t=>t.indeterminate?"mixed":t.checked}"
            aria-required="${t=>t.required}"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            tabindex="${t=>t.disabled?null:0}"
            @keypress="${(t,e)=>t.keypressHandler(e.event)}"
            @click="${(t,e)=>t.clickHandler(e.event)}"
        >
            <div part="control" class="control">
                <slot name="checked-indicator">
                    ${(0,O.R)(t.checkedIndicator)}
                </slot>
                <slot name="indeterminate-indicator">
                    ${(0,O.R)(t.indeterminateIndicator)}
                </slot>
            </div>
            <label
                part="label"
                class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,B.e)("defaultSlottedNodes")}></slot>
            </label>
        </template>
    `}({checkedIndicator:M.qy`
        <svg
            aria-hidden="true"
            part="checked-indicator"
            class="checked-indicator"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M8.143 12.6697L15.235 4.5L16.8 5.90363L8.23812 15.7667L3.80005 11.2556L5.27591 9.7555L8.143 12.6697Z"
            />
        </svg>
    `,indeterminateIndicator:M.qy`
        <div part="indeterminate-indicator" class="indeterminate-indicator"></div>
    `}),F=h.compose({name:`${p.c.prefix}-checkbox`,template:P,styles:E})},13988(t,e,i){i.d(e,{m(){return D}});var o=i(56911),n=i(92011),a=i(38493),s=i(60815),r=i(55230),l=i(5096),c=i(96789);const d="single",h="multi";class p extends n.L{constructor(){super(...arguments),this.expandmode=h,this.activeItemIndex=0,this.change=()=>{this.$emit("change",this.activeid)},this.setItems=()=>{if(0!==this.accordionItems.length&&(this.accordionIds=this.getItemIds(),this.accordionItems.forEach((t,e)=>{t instanceof c.k&&(t.addEventListener("change",this.activeItemChange),this.isSingleExpandMode()&&(this.activeItemIndex!==e?t.expanded=!1:t.expanded=!0));const i=this.accordionIds[e];t.setAttribute("id","string"!=typeof i?`accordion-${e+1}`:i),this.activeid=this.accordionIds[this.activeItemIndex],t.addEventListener("keydown",this.handleItemKeyDown),t.addEventListener("focus",this.handleItemFocus)}),this.isSingleExpandMode())){(this.findExpandedItem()??this.accordionItems[0]).setAttribute("aria-disabled","true")}},this.removeItemListeners=t=>{t.forEach((t,e)=>{t.removeEventListener("change",this.activeItemChange),t.removeEventListener("keydown",this.handleItemKeyDown),t.removeEventListener("focus",this.handleItemFocus)})},this.activeItemChange=t=>{if(t.defaultPrevented||t.target!==t.currentTarget)return;t.preventDefault();const e=t.target;this.activeid=e.getAttribute("id"),this.isSingleExpandMode()&&(this.resetItems(),e.expanded=!0,e.setAttribute("aria-disabled","true"),this.accordionItems.forEach(t=>{t.hasAttribute("disabled")||t.id===this.activeid||t.removeAttribute("aria-disabled")})),this.activeItemIndex=Array.from(this.accordionItems).indexOf(e),this.change()},this.handleItemKeyDown=t=>{if(t.target===t.currentTarget)switch(this.accordionIds=this.getItemIds(),t.key){case r.I5:t.preventDefault(),this.adjust(-1);break;case r.HX:t.preventDefault(),this.adjust(1);break;case r.kE:this.activeItemIndex=0,this.focusItem();break;case r.FM:this.activeItemIndex=this.accordionItems.length-1,this.focusItem()}},this.handleItemFocus=t=>{if(t.target===t.currentTarget){const e=t.target,i=this.activeItemIndex=Array.from(this.accordionItems).indexOf(e);this.activeItemIndex!==i&&-1!==i&&(this.activeItemIndex=i,this.activeid=this.accordionIds[this.activeItemIndex])}}}accordionItemsChanged(t,e){this.$fastController.isConnected&&(this.removeItemListeners(t),this.setItems())}findExpandedItem(){for(let t=0;t<this.accordionItems.length;t++)if("true"===this.accordionItems[t].getAttribute("expanded"))return this.accordionItems[t];return null}resetItems(){this.accordionItems.forEach((t,e)=>{t.expanded=!1})}getItemIds(){return this.accordionItems.map(t=>t.getAttribute("id"))}isSingleExpandMode(){return this.expandmode===d}adjust(t){this.activeItemIndex=(0,l.Vf)(0,this.accordionItems.length-1,this.activeItemIndex+t),this.focusItem()}focusItem(){const t=this.accordionItems[this.activeItemIndex];t instanceof c.k&&t.expandbutton.focus()}}(0,o.Cg)([(0,a.CF)({attribute:"expand-mode"}),(0,o.Sn)("design:type",String)],p.prototype,"expandmode",void 0),(0,o.Cg)([s.sH,(0,o.Sn)("design:type",Array)],p.prototype,"accordionItems",void 0);var u=i(37180),g=i(74849),v=i(64187),b=i(7896),f=i(61138),m=i(48751),$=i(26920),x=i(22683);const w=g.A`
    ${(0,v.V)("flex")} :host {
        box-sizing: border-box;
        flex-direction: column;
        font-family: ${b.O};
        font-size: ${f.k};
        line-height: ${f.F};
        color: ${m.l};
        border-top: calc(${$.XA} * 1px) solid ${x.hb};
    }
`;var y=i(96950),k=i(82774),C=i(10108);const S=y.qy`
        <template>
            <slot ${(0,k.e)({property:"accordionItems",filter:(0,C.Y)()})}></slot>
        </template>
    `,D=p.compose({name:`${u.c.prefix}-accordion`,template:S,styles:w})},14804(t,e,i){i.d(e,{c(){return A}});var o=i(56911),n=i(92011),a=i(23429),s=i(38493),r=i(60815),l=i(31157),c=i(55230),d=i(42938);const h="top",p="right",u="bottom",g="left",v="center",b="start",f="end",m="top-left",$="top-center",x="top-right",w="bottom-left",y="bottom-center",k="bottom-right",C="top-start",S="top-end",D="bottom-start",T="bottom-end";class A extends n.L{constructor(){super(...arguments),this.anchor="",this.delay=300,this.autoUpdateMode="anchor",this.anchorElement=null,this.viewportElement=null,this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.horizontalInset="false",this.verticalInset="false",this.horizontalScaling="content",this.verticalScaling="content",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition=void 0,this.tooltipVisible=!1,this.currentDirection=l.O.ltr,this.showDelayTimer=null,this.hideDelayTimer=null,this.isAnchorHoveredFocused=!1,this.isRegionHovered=!1,this.handlePositionChange=t=>{this.classList.toggle("top","start"===this.region.verticalPosition),this.classList.toggle("bottom","end"===this.region.verticalPosition),this.classList.toggle("inset-top","insetStart"===this.region.verticalPosition),this.classList.toggle("inset-bottom","insetEnd"===this.region.verticalPosition),this.classList.toggle("center-vertical","center"===this.region.verticalPosition),this.classList.toggle("left","start"===this.region.horizontalPosition),this.classList.toggle("right","end"===this.region.horizontalPosition),this.classList.toggle("inset-left","insetStart"===this.region.horizontalPosition),this.classList.toggle("inset-right","insetEnd"===this.region.horizontalPosition),this.classList.toggle("center-horizontal","center"===this.region.horizontalPosition)},this.handleRegionMouseOver=t=>{this.isRegionHovered=!0},this.handleRegionMouseOut=t=>{this.isRegionHovered=!1,this.startHideDelayTimer()},this.handleAnchorMouseOver=t=>{this.tooltipVisible?this.isAnchorHoveredFocused=!0:this.startShowDelayTimer()},this.handleAnchorMouseOut=t=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.handleAnchorFocusIn=t=>{this.startShowDelayTimer()},this.handleAnchorFocusOut=t=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.startHideDelayTimer=()=>{this.clearHideDelayTimer(),this.tooltipVisible&&(this.hideDelayTimer=window.setTimeout(()=>{this.updateTooltipVisibility()},60))},this.clearHideDelayTimer=()=>{null!==this.hideDelayTimer&&(clearTimeout(this.hideDelayTimer),this.hideDelayTimer=null)},this.startShowDelayTimer=()=>{this.isAnchorHoveredFocused||(this.delay>1?null===this.showDelayTimer&&(this.showDelayTimer=window.setTimeout(()=>{this.startHover()},this.delay)):this.startHover())},this.startHover=()=>{this.isAnchorHoveredFocused=!0,this.updateTooltipVisibility()},this.clearShowDelayTimer=()=>{null!==this.showDelayTimer&&(clearTimeout(this.showDelayTimer),this.showDelayTimer=null)},this.getAnchor=()=>{const t=this.getRootNode();return t instanceof ShadowRoot?t.getElementById(this.anchor):document.getElementById(this.anchor)},this.handleDocumentKeydown=t=>{if(!t.defaultPrevented&&this.tooltipVisible&&t.key===c.F9)this.isAnchorHoveredFocused=!1,this.updateTooltipVisibility(),this.$emit("dismiss")},this.updateTooltipVisibility=()=>{if(!1===this.visible)this.hideTooltip();else{if(!0===this.visible)return void this.showTooltip();if(this.isAnchorHoveredFocused||this.isRegionHovered)return void this.showTooltip();this.hideTooltip()}},this.showTooltip=()=>{this.tooltipVisible||(this.currentDirection=(0,d.u)(this),this.tooltipVisible=!0,document.addEventListener("keydown",this.handleDocumentKeydown),a.L.enqueue(this.setRegionProps))},this.hideTooltip=()=>{this.tooltipVisible&&(this.clearHideDelayTimer(),null!==this.region&&void 0!==this.region&&(this.region.removeEventListener("positionchange",this.handlePositionChange),this.region.viewportElement=null,this.region.anchorElement=null,this.region.removeEventListener("mouseover",this.handleRegionMouseOver),this.region.removeEventListener("mouseout",this.handleRegionMouseOut)),document.removeEventListener("keydown",this.handleDocumentKeydown),this.tooltipVisible=!1)},this.setRegionProps=()=>{this.tooltipVisible&&(this.region.viewportElement=this.viewportElement,this.region.anchorElement=this.anchorElement,this.region.addEventListener("positionchange",this.handlePositionChange),this.region.addEventListener("mouseover",this.handleRegionMouseOver,{passive:!0}),this.region.addEventListener("mouseout",this.handleRegionMouseOut,{passive:!0}))}}visibleChanged(){this.$fastController.isConnected&&(this.updateTooltipVisibility(),this.updateLayout())}anchorChanged(){this.$fastController.isConnected&&(this.anchorElement=this.getAnchor())}positionChanged(){this.$fastController.isConnected&&this.updateLayout()}anchorElementChanged(t){if(this.$fastController.isConnected){if(null!=t&&(t.removeEventListener("mouseover",this.handleAnchorMouseOver),t.removeEventListener("mouseout",this.handleAnchorMouseOut),t.removeEventListener("focusin",this.handleAnchorFocusIn),t.removeEventListener("focusout",this.handleAnchorFocusOut)),null!==this.anchorElement&&void 0!==this.anchorElement){this.anchorElement.addEventListener("mouseover",this.handleAnchorMouseOver,{passive:!0}),this.anchorElement.addEventListener("mouseout",this.handleAnchorMouseOut,{passive:!0}),this.anchorElement.addEventListener("focusin",this.handleAnchorFocusIn,{passive:!0}),this.anchorElement.addEventListener("focusout",this.handleAnchorFocusOut,{passive:!0});const t=this.anchorElement.id;null!==this.anchorElement.parentElement&&this.anchorElement.parentElement.querySelectorAll(":hover").forEach(e=>{e.id===t&&this.startShowDelayTimer()})}null!==this.region&&void 0!==this.region&&this.tooltipVisible&&(this.region.anchorElement=this.anchorElement),this.updateLayout()}}viewportElementChanged(){null!==this.region&&void 0!==this.region&&(this.region.viewportElement=this.viewportElement),this.updateLayout()}connectedCallback(){super.connectedCallback(),this.anchorElement=this.getAnchor(),this.updateTooltipVisibility()}disconnectedCallback(){this.hideTooltip(),this.clearShowDelayTimer(),this.clearHideDelayTimer(),super.disconnectedCallback()}updateLayout(){switch(this.verticalPositioningMode="locktodefault",this.horizontalPositioningMode="locktodefault",this.position){case h:case u:this.verticalDefaultPosition=this.position,this.horizontalDefaultPosition="center";break;case p:case g:case b:case f:this.verticalDefaultPosition="center",this.horizontalDefaultPosition=this.position;break;case v:this.verticalDefaultPosition="center",this.horizontalDefaultPosition="center";break;case m:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="left";break;case $:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="center";break;case y:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="center";break;case x:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="right";break;case w:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="left";break;case k:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="right";break;case C:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="start";break;case S:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="end";break;case D:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="start";break;case T:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="end";break;default:this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition="center"}}}(0,o.Cg)([(0,s.CF)({mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],A.prototype,"visible",void 0),(0,o.Cg)([s.CF,(0,o.Sn)("design:type",String)],A.prototype,"anchor",void 0),(0,o.Cg)([(0,s.CF)({attribute:"delay",converter:s.R$}),(0,o.Sn)("design:type",Number)],A.prototype,"delay",void 0),(0,o.Cg)([s.CF,(0,o.Sn)("design:type",String)],A.prototype,"position",void 0),(0,o.Cg)([(0,s.CF)({attribute:"auto-update-mode"}),(0,o.Sn)("design:type",String)],A.prototype,"autoUpdateMode",void 0),(0,o.Cg)([(0,s.CF)({attribute:"horizontal-viewport-lock"}),(0,o.Sn)("design:type",Boolean)],A.prototype,"horizontalViewportLock",void 0),(0,o.Cg)([(0,s.CF)({attribute:"vertical-viewport-lock"}),(0,o.Sn)("design:type",Boolean)],A.prototype,"verticalViewportLock",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Object)],A.prototype,"anchorElement",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Object)],A.prototype,"viewportElement",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",String)],A.prototype,"verticalPositioningMode",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",String)],A.prototype,"horizontalPositioningMode",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",String)],A.prototype,"horizontalInset",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",String)],A.prototype,"verticalInset",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",String)],A.prototype,"horizontalScaling",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",String)],A.prototype,"verticalScaling",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Object)],A.prototype,"verticalDefaultPosition",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Object)],A.prototype,"horizontalDefaultPosition",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Boolean)],A.prototype,"tooltipVisible",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",String)],A.prototype,"currentDirection",void 0)},15013(t,e,i){i.d(e,{_(){return p}});var o=i(2171),n=i(58792),a=i(78797),s=i(89950),r=i(47185),l=i(10526),c=i(34230),d=i(31756),h=i(93140);async function p(t){t.telemetry||(t.telemetry={});const e=(0,l.NP)();let i=(0,r.F6)(),p=(0,r.I6)();const u=(0,r.DP)();if(!i){const t=await async function(){var t;const e="OcvFeedbackAuth";if(o.vv.has(e))return o.vv.get(e);const i=null===(t=(0,a._W)())||void 0===t?void 0:t.access_token;return i?await(0,c.w)(async()=>{const t=new URL(`https://api.msn.${n.T3.IsChinaCompliance?"cn":"com"}/auth/token/v1/validation/usertoken`);d.WR.getCommonParams2("Peregrine").forEach(e=>t.searchParams.set(e.key,e.value));const a=await d.WR.getBaseRequestData("POST");a.headers["Content-Type"]="application/json",a.body=JSON.stringify({accessToken:i});const s=await fetch(t.href,a),r=await s.json(),l=null==r?void 0:r.claims;return l&&o.vv.set(e,l),l},"authTokenValidation"):void 0}();i=null==t?void 0:t.puid,p=null==t?void 0:t.tenantId}switch(e){case"MSA":t.complianceChecks={authenticationType:"MSA",ageGroup:h.P2[u]},t.telemetry.loggableUserId="p:"+i,t.telemetry.tenantId=s.nt;break;case"AAD":t.complianceChecks={authenticationType:"AAD",ageGroup:h.P2[u]},t.telemetry.loggableUserId="ap:"+i,t.telemetry.tenantId=p;break;default:t.complianceChecks={authenticationType:"Unauthenticated",ageGroup:h.P2[h.P2.Undefined]},t.telemetry.loggableUserId="",t.telemetry.tenantId="00000000-0000-0000-0000-000000000000"}}},23322(t,e,i){i.r(e),i.d(e,{ActiveDialog(){return ct},CommonCSSStyles(){return ft},FeedbackDialogWC(){return dt},FeedbackDialogWCStyles(){return mt},FeedbackDialogWCTemplate(){return qt},ToolingInfo(){return Jt},feedbackDialogWC(){return Kt}});var o,n=i(4731),a=i(37180),s=i(45899),r=i(9299),l=i(58661),c=i(19249),d=i(65636),h=i(65007),p=i(13988),u=i(49473),g=i(29783),v=i(69400),b=i(56911),f=i(12680),m=i(85349),$=i(83222);!function(t){t.closeButtonName="CloseButton",t.closeButtonHeadline="Close",t.closeConfirmationButtonName="CloseConfirmationButton",t.closeConfirmationButtonHeadline="Close confirmation",t.cancelButton="Cancel",t.submitButton="Submit",t.privacyLink="Privacy",t.helpLink="Help",t.helpAndSupportLinkName="HelpAndSupport",t.helpAndSupportLinkHeadline="Help and support"}(o||(o={}));const x={module:{name:"FeedbackDialog",type:m.MJ.Module,behavior:m.MS.Feedback},closeButton:{name:o.closeButtonName,type:m.MJ.ActionButton,behavior:m.MS.Close,content:{headline:o.closeButtonHeadline}},closeConfirmationButton:{name:o.closeConfirmationButtonName,type:m.MJ.ActionButton,behavior:m.MS.Close,content:{headline:o.closeConfirmationButtonHeadline}},cancelButton:{name:o.cancelButton,type:m.MJ.ActionButton,behavior:m.MS.Cancel,content:{headline:o.cancelButton}},submitButton:{name:o.submitButton,type:m.MJ.ActionButton,behavior:m.MS.Complete,content:{headline:o.submitButton}},privacyLink:{name:o.privacyLink,type:m.MJ.ActionButton,behavior:m.MS.Navigate,content:{headline:o.privacyLink}},helpLink:{name:o.helpLink,type:m.MJ.ActionButton,behavior:m.MS.Navigate,content:{headline:o.helpLink}},helpAndSupport:{name:o.helpAndSupportLinkName,type:m.MJ.ActionButton,behavior:m.MS.Navigate,content:{headline:o.helpAndSupportLinkHeadline}}};function w(t){const e={};return Object.keys(t).forEach(i=>{e[i]=new $.$(t[i]).getMetadataTag()}),e}var y=i(2171),k=i(58792),C=i(8800),S=i(74998),D=i(93552),T=i(77367);class A{static get ocvServiceUrl(){return y.vv.get(this.ocvServiceUrlKey,()=>k.T3.Environment===C.O.int?"https://petrol-int.office.microsoft.com/v1/feedback":"https://petrol.office.microsoft.com/v1/feedback")}static set ocvServiceUrl(t){y.vv.set(this.ocvServiceUrlKey,t)}static get powerliftUrl(){return y.vv.get(this.powerliftUrlKey,()=>"https://powerlift-frontdesk.acompli.net/api/incidents")}static set powerliftUrl(t){y.vv.set(this.powerliftUrlKey,t)}constructor(t){this.fetchImpl=t}async reportFeedbackToOcv(t){const e={method:"POST",mode:"cors",cache:"no-cache",headers:{"Content-Type":"application/json"},body:JSON.stringify(t)};try{const t=await this.fetchImpl(A.ocvServiceUrl,e);return!!t.ok||(T.YT.sendAppErrorEvent({...D.H_c,message:"Request is not valid, it has no content, or the manifest is not formatted correctly",pb:{...D.H_c.pb,customMessage:`Error code: ${t.status} Error message: ${t.statusText}\n                            Request params: ${e} Service url: ${A.ocvServiceUrl}`}}),!1)}catch(t){return T.YT.sendAppErrorEvent({...D.wN$,message:"Exception reporting feedback to OCV",pb:{...D.wN$.pb,customMessage:`Error code: ${t?t.code:"undefined"} Error message: ${t?t.message:"undefined"}\n                        Request params: ${e} Service url: ${A.ocvServiceUrl}`}}),!1}}async reportFeedbackToOcvByFiles(t,e,i){try{const o=new FormData;if(i)try{const n=await this.sendLogtoPowerLiftServer(t,i);t.application.extendedManifestData=JSON.stringify({diagnosticsUploadInfo:{diagnosticsEndPoint:"PowerLift",diagnosticsUploadId:n}})}catch(a){T.YT.sendAppErrorEvent({...D.wN$,message:"Exception of generate diagnostic data"})}if(e)try{function s(t){const e=t.split(","),i=e[0].match(/:(.*?);/)[1],o=atob(e[1]);let n=o.length;const a=new Uint8Array(n);for(;n--;)a[n]=o.charCodeAt(n);return new Blob([a],{type:i})}const r=await s(e);o.append("Screenshot",r,"screenshot.png")}catch(l){T.YT.sendAppErrorEvent({...D.wN$,message:"Exception of generate screenshot file."})}try{const c=new File([JSON.stringify(t)],"Manifest.json",{type:"application/json"});o.append("Manifest",c)}catch(d){T.YT.sendAppErrorEvent({...D.wN$,message:"Exception of generate Manifest.json."})}return await this.fetchImpl(A.ocvServiceUrl,{method:"POST",body:o}),!0}catch(h){return T.YT.sendAppErrorEvent({...D.wN$,message:"Exception reporting feedback to OCV",pb:{...D.wN$.pb,customMessage:`Error code: ${h?h.code:"undefined"} Error message: ${h?h.message:"undefined"} from reportFeedbackToOcvByFiles\n                        Service url: ${A.ocvServiceUrl}`}}),!1}}async sendLogtoPowerLiftServer(t,e){var i;const o={data:{dataStringKey:"dataStringValue",ntp_diagnostics:e,system_flags:""},meta:{accounts:[{userId:t.email}],clientCapabilities:[],clientVersion:"",createdAt:(new Date).toISOString(),id:t.clientFeedbackId,sessionId:-1,installId:"0",lang:(null===(i=S.Rb.ClientSettings)||void 0===i||null===(i=i.locale)||void 0===i?void 0:i.language)||"en",platform:t.platform||""}},n={method:"POST",headers:{"Content-Type":"application/json","PowerLift-Api-Key":"x+gaQoO6u4HwIn3IyGCftGVGPstT43PS","PowerLift-Api-Version":"v5"},body:JSON.stringify(o)};try{const t=await this.fetchImpl(A.powerliftUrl,n);t.ok||T.YT.sendAppErrorEvent({...D.dxI,message:"Powerlift service response status is not successful",pb:{...D.dxI.pb,customMessage:`Error code: ${t.status} Error message: ${t.statusText}\n                            Request params: ${n} Service url: ${A.powerliftUrl}`}});return(await t.json()).id}catch(t){return T.YT.sendAppErrorEvent({...D.dxI,message:"Exception when parse Powerlift service response",pb:{...D.dxI.pb,customMessage:`Error code: ${t?t.code:"undefined"} Error message: ${t?t.message:"undefined"}\n                        Request params: ${n} Service url: ${A.powerliftUrl}`}}),""}}}A.ocvServiceUrlKey=Symbol("ocvServiceUrl"),A.powerliftUrlKey=Symbol("powerliftUrl");var I,z,E,M,B,O,P,F,N=i(93140),L=i(15013),U=i(25109),H=i(30860),j=i(50645),R=i(46528),V=i(17958),_=i(15525),W=i(22755),Z=i(38493),G=i(60815),q=i(39671),J=i(27259),K=i(22341);function X(){var t;return null===(t=window)||void 0===t?void 0:t.ShellFeedsApp}async function Q(){const t=X();if(null==t||!t.tryGetIDXContentAsync)return;let e,i;try{e=await t.tryGetIDXContentAsync(),i=JSON.parse(e)}catch(t){e=e||"",(0,K.vV)(D.INq,"API Payload not "+(e?"parsed":"returned"),`api=${!!e} . parse=${!!i} . ex: ${e&&(null==t?void 0:t.toString())} . len: ${e.length} . sample: ${e.substring(e.length-100)}`,{len:`${e.length}`,sample:`${e.substring(e.length-100)}`})}return i}!function(t){t[t.UserInitiatedColdStart=0]="UserInitiatedColdStart",t[t.UserInitiatedWarmStart=1]="UserInitiatedWarmStart",t[t.BackgroundPrelaunch=2]="BackgroundPrelaunch",t[t.BackgroundColdStartOnIDXUpdate=3]="BackgroundColdStartOnIDXUpdate",t[t.BackgroundWarmStartOnIDXUpdate=4]="BackgroundWarmStartOnIDXUpdate",t[t.ProtocolColdStart=5]="ProtocolColdStart",t[t.ProtocolWarmStart=6]="ProtocolWarmStart",t[t.Unknown=7]="Unknown"}(I||(I={})),Object.freeze({accountType:"X-Search-Account",accountTypeDisplayText:"X-Search-AccountType",altRpsToken:"X-Search-RPSToken",backgroundThemeInfo:"X-BM-Theme",debugId1S:"ddd-debugid",entAuthToken:"Ent-Authorization",msaV2Token:"Authorization",muid:"MUID",rpsToken:"UserAuthToken",sessionId:"X-Device-ClientSession",userEmail:"X-Search-UserEmail",windowsFlights:"X-BM-WindowsFlights"}),function(t){t[t.Enabled=1]="Enabled",t[t.Disabled=0]="Disabled",t[t.Unknown=-1]="Unknown",t[t.UnSupported=-2]="UnSupported"}(z||(z={})),function(t){t[t.Unknown=0]="Unknown",t[t.Hover=1]="Hover",t[t.Click=2]="Click",t[t.MouseLeave=3]="MouseLeave",t[t.MouseMove=4]="MouseMove",t[t.Tapped=5]="Tapped",t[t.KeyboardLeave=6]="KeyboardLeave",t[t.ProtocolLaunch=7]="ProtocolLaunch"}(E||(E={})),function(t){t[t.KirDisabled=-1]="KirDisabled",t[t.KirEnabledAnd1SDisabled=0]="KirEnabledAnd1SDisabled",t[t.KirEnabledAnd1SEnabled=1]="KirEnabledAnd1SEnabled"}(M||(M={})),function(t){t[t.Unknown=-3]="Unknown",t[t.FeatureNotPresent=-2]="FeatureNotPresent",t[t.Current=-1]="Current",t[t.IconAndText=0]="IconAndText",t[t.Icon=1]="Icon",t[t.Unpinned=2]="Unpinned"}(B||(B={})),function(t){t.Active="0",t.Inactive="1"}(O||(O={})),function(t){t[t.KirDisabled=-1]="KirDisabled",t[t.KirEnabledAnd1SDisabled=0]="KirEnabledAnd1SDisabled",t[t.KirEnabledAnd1SEnabled=1]="KirEnabledAnd1SEnabled"}(P||(P={})),function(t){t[t.NotAvailable=-1]="NotAvailable",t[t.Auto=0]="Auto",t[t.Small=1]="Small",t[t.Tall=2]="Tall",t[t.Wide=3]="Wide"}(F||(F={}));var Y=i(63456);function tt(t,e){if(!t||!e)return;const{defaultPreview:i,rotationalPreviews:o}=t;if((null==i?void 0:i.previewType)===e)return{preview:i,isRotational:!1};return{preview:null==o?void 0:o.find(t=>(null==t?void 0:t.previewType)===e),isRotational:!0}}function et(t,e){if(!t)return`missing-${e}-preview`;const i=(0,Y.A)(t,"adaptiveCards.small.body[0]");return(0,Y.A)(i,"items[0].columns").filter(t=>{var e;return"TextBlock"===(null===(e=(0,Y.A)(t,"items[0]"))||void 0===e?void 0:e.type)}).map(t=>{var e;return(null===(e=(0,Y.A)(t,"items[0]"))||void 0===e?void 0:e.text)??""}).toString()}i(94623);var it=i(10526),ot=i(13257),nt=i(90905);const at=()=>({width:devicePixelRatio*window.screen.width,height:devicePixelRatio*window.screen.height,fixedHeight:devicePixelRatio*window.screen.height-30*devicePixelRatio});function st(t){let e;const i=[];let o="";const n=function(t){let e,i=1;if(t.nodeType==Node.ATTRIBUTE_NODE)return null;for(e=t.previousSibling;e;e=e.previousSibling)e.nodeName==t.nodeName&&++i;return i};if(t instanceof Document)return"/";for(;t;t=t.nodeType==Node.ATTRIBUTE_NODE?t.ownerElement:t.parentNode){switch(e=i[i.length]={},t.nodeType){case Node.TEXT_NODE:e.name="text()";break;case Node.ATTRIBUTE_NODE:e.name="@"+t.nodeName;break;case Node.PROCESSING_INSTRUCTION_NODE:e.name="processing-instruction()";break;case Node.COMMENT_NODE:e.name="comment()";break;case Node.ELEMENT_NODE:default:e.name=t.nodeName}e.position=n(t)}for(let t=i.length-1;t>=0;t--)e=i[t],o+="/"+e.name,null!=e.position&&(o+="["+e.position+"]");return o}const rt=(t,e,i)=>{t();const o=(t,e,i,o)=>Math.abs(t-e)+Math.abs(i-o),n=t=>{const e=document.createElement("div");return Object.keys(t).map(i=>e.style[i]=t[i]),e},a=new Map;g(document.body);const s=window.setInterval(()=>g(document.body),500);let r=null;window.addEventListener("scroll",u),window.addEventListener("resize",u);const l=n({position:"fixed",borderRadius:"4px",margin:"0 auto",left:0,width:"240px",bottom:"20px",right:0,zIndex:1001,pointerEvents:"auto",cursor:"pointer",backgroundColor:"#3b3b3b",color:"white",display:"flex",justifyContent:"space-between",padding:"12px 24px"});l.className="temporary-mask-cover";const c=n({borderBottom:"1px solid white",display:"inline-block",marginLeft:"12px",fontSize:"12px"});c.innerHTML=i.cancel,c.addEventListener("click",()=>{e(null),h(a)});const d=n({display:"inline-block"});d.innerHTML=i.pickAreaHelpInfo,l.appendChild(d),l.appendChild(c),document.body.appendChild(l);const h=t=>{t.forEach((t,e)=>e.removeEventListener("mouseover",t)),t.clear(),clearInterval(s),u(),document.body.removeChild(l),window.removeEventListener("scroll",u),window.removeEventListener("resize",u)},p=(0,nt.A)(t=>t(),200);function u(){r&&(document.body.removeChild(r),r=null)}function g(t,i){var s;if(!t)return;if(i&&!a.get(t)){const s=i.getBoundingClientRect(),l=t.getBoundingClientRect();if(function(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:20;return o(t.left,e.left,t.top,e.top)<i&&o(t.right,e.right,t.bottom,e.bottom)<i}(l,s)||l.height>window.screen.height);else{if("temporary-mask-cover"===t.className)return;{const i=i=>{i.stopPropagation(),p(()=>{u(),r=function(t){const i=t.getBoundingClientRect(),o=Math.min(i.width,i.height),s=n({position:"fixed",left:i.left+"px",top:i.top+"px",width:i.width+"px",height:i.height+"px",border:"2px solid red",justifyContent:"center",alignItems:"center",display:"flex",zIndex:1e3,pointerEvents:"auto",cursor:"pointer",backgroundColor:"rgba(0,0,0,.2)"}),r=n({maxWidth:o+"px",maxHeight:o+"px",minWidth:o/5+"px",minHeight:o/5+"px",width:"30px",height:"30px",zIndex:1e3,borderRadius:"50%",cursor:"pointer",opacity:.7});let l;return s.className="temporary-mask-cover",s.addEventListener("mousemove",t=>{(new Date).getTime()-l>50&&l?(s.style.pointerEvents="none",l=0):l=(new Date).getTime()}),s.addEventListener("mouseover",t=>{p(()=>{r.style.backgroundColor="#ff0000"}),t.stopPropagation(),t.preventDefault()}),s.addEventListener("click",i=>{e(t),h(a)}),r.innerHTML='<svg viewBox="0 0 16 16" fill="#ffffff" xmlns="http://www.w3.org/2000/svg"><path d="M8 0C8.73438 0 9.44271 0.0963542 10.125 0.289062C10.8073 0.476562 11.4427 0.744792 12.0312 1.09375C12.625 1.44271 13.1641 1.86198 13.6484 2.35156C14.138 2.83594 14.5573 3.375 14.9062 3.96875C15.2552 4.55729 15.5234 5.19271 15.7109 5.875C15.9036 6.55729 16 7.26562 16 8C16 8.73438 15.9036 9.44271 15.7109 10.125C15.5234 10.8073 15.2552 11.4453 14.9062 12.0391C14.5573 12.6276 14.138 13.1667 13.6484 13.6562C13.1641 14.1406 12.625 14.5573 12.0312 14.9062C11.4427 15.2552 10.8073 15.526 10.125 15.7188C9.44271 15.9062 8.73438 16 8 16C7.26562 16 6.55729 15.9062 5.875 15.7188C5.19271 15.526 4.55469 15.2552 3.96094 14.9062C3.3724 14.5573 2.83333 14.1406 2.34375 13.6562C1.85938 13.1667 1.44271 12.6276 1.09375 12.0391C0.744792 11.4453 0.473958 10.8073 0.28125 10.125C0.09375 9.44271 0 8.73438 0 8C0 7.26562 0.09375 6.55729 0.28125 5.875C0.473958 5.19271 0.744792 4.55729 1.09375 3.96875C1.44271 3.375 1.85938 2.83594 2.34375 2.35156C2.83333 1.86198 3.3724 1.44271 3.96094 1.09375C4.55469 0.744792 5.19271 0.476562 5.875 0.289062C6.55729 0.0963542 7.26562 0 8 0ZM7.08594 10.5234C7.20052 10.5234 7.3099 10.5026 7.41406 10.4609C7.51823 10.4141 7.60938 10.3516 7.6875 10.2734L11.0391 6.92188C11.1172 6.84375 11.1771 6.7526 11.2188 6.64844C11.2604 6.54427 11.2812 6.4375 11.2812 6.32812C11.2812 6.21354 11.2578 6.10417 11.2109 6C11.1693 5.89583 11.1094 5.80729 11.0312 5.73438C10.9583 5.65625 10.8698 5.59635 10.7656 5.55469C10.6615 5.50781 10.5521 5.48438 10.4375 5.48438C10.3281 5.48438 10.2188 5.50521 10.1094 5.54688C10.0052 5.58854 9.91406 5.64844 9.83594 5.72656L7.08594 8.47656L6.16406 7.55469C5.9974 7.38802 5.79688 7.30469 5.5625 7.30469C5.44792 7.30469 5.33854 7.32812 5.23438 7.375C5.13021 7.41667 5.03906 7.47656 4.96094 7.55469C4.88281 7.63281 4.82031 7.72396 4.77344 7.82812C4.73177 7.92708 4.71094 8.03385 4.71094 8.14844C4.71094 8.25781 4.73177 8.36719 4.77344 8.47656C4.82031 8.58073 4.88281 8.67188 4.96094 8.75L6.48438 10.2734C6.5625 10.3516 6.65365 10.4141 6.75781 10.4609C6.86719 10.5026 6.97656 10.5234 7.08594 10.5234Z"></path></svg>',s.appendChild(r),document.body.append(s),s}(t)})};t.addEventListener("mouseover",i),a.set(t,i)}}}const l=null!==(s=t.children)&&void 0!==s&&s.length?t.children:t.shadowRoot&&t.shadowRoot.children;l&&l.length&&Array.prototype.slice.call(l).map(e=>g(e,t))}};function lt(){let t=(new Date).getTime();return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(e){const i=(t+16*Math.random())%16|0;return t=Math.floor(t/16),("x"==e?i:3&i|8).toString(16)})}var ct;!function(t){t.ReportDialog="ReportDialog",t.CloseDialog="CloseDialog"}(ct||(ct={}));class dt extends q.U{constructor(){super(...arguments),this.visible=!1,this.activeDialog=ct.ReportDialog,this.showDiagnosticData=!1,this.showScreenshotEditor=!1,this.userSignInStatus=-1,this.onKeydown=t=>{switch(this.visible&&"Escape"===t.key&&(this.closeDialogOnEscKeyDown&&(t.stopPropagation(),this.close(!1)),this.checkActiveElement("report-dialog","reportDialogSelect")||this.close()),this.activeDialog){case ct.ReportDialog:this.onKeyDownReportDialog(t);break;case ct.CloseDialog:this.onKeyDownCloseDialog(t)}},this.onKeyDownReportDialog=t=>{if("Tab"===t.key)if(!t.shiftKey&&this.checkActiveElement("report-dialog","reportDialogCancelButton")){var e,i,o,n;t.preventDefault();(null===(e=(i=this.shadowRoot).querySelector)||void 0===e||null===(o=(n=e.call(i,"report-dialog").shadowRoot).getElementById)||void 0===o?void 0:o.call(n,"reportDialogSubmitButton")).disabled?this.setFocus("reportDialogCloseButtonIcon"):this.setFocus("reportDialogSubmitButton")}else if(!t.shiftKey&&this.checkActiveElement("report-dialog","reportDialogSubmitButton"))t.preventDefault(),this.setFocus("reportDialogCloseButtonIcon");else if(t.shiftKey&&this.checkActiveElement("report-dialog","reportDialogCloseButtonIcon")){var a,s,r,l;t.preventDefault();(null===(a=(s=this.shadowRoot).querySelector)||void 0===a||null===(r=(l=a.call(s,"report-dialog").shadowRoot).getElementById)||void 0===r?void 0:r.call(l,"reportDialogSubmitButton")).disabled?this.setFocus("reportDialogCancelButton"):this.setFocus("reportDialogSubmitButton")}},this.onKeyDownCloseDialog=t=>{"Tab"===t.key&&(this.checkActiveElement("close-dialog","closeDialogCloseButton")?(t.preventDefault(),this.setFocus("closeDialogCloseButtonIcon")):this.checkActiveElement("close-dialog","closeDialogSupportText")?(t.preventDefault(),this.setFocus("closeDialogCloseButton")):this.checkActiveElement("close-dialog","closeDialogCloseButtonIcon")&&(t.preventDefault(),this.setFocus("closeDialogSupportText")))},this.checkActiveElement=(t,e)=>{var i,o,n,a,s,r;return!(null===(i=(o=this.shadowRoot).querySelector)||void 0===i||!i.call(o,t)||null===(n=(a=this.shadowRoot).querySelector)||void 0===n||!n.call(a,t).shadowRoot.activeElement||(null===(s=(r=this.shadowRoot).querySelector)||void 0===s?void 0:s.call(r,t).shadowRoot.activeElement.id)!==e)},this.setFocus=t=>{let e;switch(this.activeDialog){case ct.ReportDialog:var i,o,n,a;e=null===(i=(o=this.shadowRoot).querySelector)||void 0===i||null===(n=(a=i.call(o,"report-dialog").shadowRoot).getElementById)||void 0===n?void 0:n.call(a,t);break;case ct.CloseDialog:var s,r,l,c;e=null===(s=(r=this.shadowRoot).querySelector)||void 0===s||null===(l=(c=s.call(r,"close-dialog").shadowRoot).getElementById)||void 0===l?void 0:l.call(c,t)}e&&e.focus()},this.backgroundColorChangeHandler=()=>{this.backgroundColor=!this.config.overrideDarkMode&&((0,U.ud)()?H.KS:H.z4)},this.generateDiagnosticData=async()=>{var t;const e=(null===(t=j.L.getInstance())||void 0===t||null===(t=t.getConfigResolver())||void 0===t?void 0:t.getConfigServiceObject())||{};this.diagnosticData={rootConfig:{resolverEnvironment:e.resolverEnvironment,configServiceQueryParams:e.configServiceQueryParams,hadNetworkError:e.hadNetworkError},error:ot.Sy.list.length?[...ot.Sy.list]:void 0,headData:S.Rb,appEnvironment:k.T3}},this.generateAdsMetadata=()=>{const t="AllAds",e=[];if(window[t]){const i=window[t],o=new R.bb,n=(0,R.KP)(o.data.innerWidth,"innerWidth"),a=(0,R.KP)(o.data.innerHeight,"innerHeight");i&&i.forEach((t,i)=>{const o=t._data;if(t&&function(t,e,i){const o=t.getBoundingClientRect();return!(o.right<0||o.bottom<0||o.left>e||o.top>i)&&o.top>=0&&o.left>=0&&o.bottom<=i&&o.right<=e}(t,n,a)&&o&&o.items&&o.items.length>0){const t={placement:o.id,crid:o.crids&&o.crids.length>0?o.crids[0]:"",uniqueId:o.items[0].uniqueId,description:o.items[0].description,destinationUrl:o.items[0].destinationUrl,imageUrl:o.items[0].imageUrl,provider:o.items[0].providerName,title:o.items[0].title};e.push(t)}})}return e},this.handleShowScreenshot=async t=>{this.screenshotOptions=t,this.showScreenshotEditor=!0},this.generateBriefInfo=()=>{var t;const{oid:e,tenant_id:i,account_id:o,account_type:n,age_group:a}=k.T3.ResolvedAccountInfo||{};return{activityID:null===(t=S.Rb.ClientSettings)||void 0===t?void 0:t.aid,account:{oid:e,tenant_id:i,account_id:o,account_type:n,age_group:a}}}}experienceConnected(){this.feedbackDialogTelemetryTags={...w(x)},this.backgroundColor=!this.config.overrideDarkMode&&((0,U.ud)()?H.KS:H.z4),this.getSignInStatus()}getExperienceType(){return f.TAx}connectedCallback(){super.connectedCallback(),this.feedbackServiceClient=new A(window.fetch.bind(window)),document.addEventListener("keydown",this.onKeydown,{capture:!0}),window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",this.backgroundColorChangeHandler),this.generateDiagnosticData()}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this.onKeydown,{capture:!0}),window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change",this.backgroundColorChangeHandler)}visibleChanged(t,e){!0===e&&(this.activeDialog=ct.ReportDialog)}async reportFeedback(t){const{feedbackInput:e,feedbackEmail:i,feedbackCategories:o,feedbackScreenshot:n,isDiagnosticData:a}=t;let s,r;switch(this.config.serviceEndPoint){case N.G4.Ods:s=!0;break;case N.G4.Ocv:r=!0;break;default:s=!0,r=!0}if(s){const t=this.createFeedbackData(e);T.YT.sendFeedbackEvent(t)}if(r){const t=await this.createOcvFeedbackData({feedbackInput:e,email:i,feedbackCategory:o,isDiagnosticData:a});this.config.advancedFeatures||n||a?await this.feedbackServiceClient.reportFeedbackToOcvByFiles(t,n,null):await this.feedbackServiceClient.reportFeedbackToOcv(t)}}createFeedbackData(t){return{id:lt(),type:"General",submitValue:t&&t.length>0?t:""}}async createOcvFeedbackData(t){let{feedbackInput:e,email:i,feedbackCategory:o,isDiagnosticData:n}=t;const a=new N.vO,s=S.Rb&&S.Rb.ClientSettings||{},r=k.T3&&k.T3.HostPage||{},{aid:l="",detection:c={},deviceFormFactor:d="",geo_city:h,geo_country:p,geo_citycf:u,geo_countrycf:g,pageGenTime:v="",static_page:b=""}=s,f=S.Rb&&S.Rb.Diagnostics||{},m=f&&(0,V.RC)(JSON.stringify(f)),{isMsft:$=!1,isCorpNet:x=!1}=c,{categoryKey:w="",subcategoryKey:y,verticalKey:C="Prod"}=r,D=(0,_.Lg)().getItem("authRecordTrail");let A=T.YT.getPageMetadata().JoinIdProps.IDXId;const I=(0,J.Xq)();if(null!=A&&""!=A){const t=A.split(",");A=t.slice(0,10).toString()}const z=k.T3.CurrentRequestTargetScope&&k.T3.CurrentRequestTargetScope.pageExperiments?k.T3.CurrentRequestTargetScope.pageExperiments.join(","):"",E=k.T3.CurrentRequestTargetScope&&k.T3.CurrentRequestTargetScope.browser,M=this.getOcvPartDataByPageType({clientSettings:s}),B=this.generateBriefInfo();a.appId=M.appId;const O={serviceType:"oneservice",oneServiceTraceId:A,oneServiceActivityId:l};"windowsShell"===k.T3.AppType&&(O.oneServiceActivityId="");let P="Unauthenticated";if(2===this.userSignInStatus){const t=(0,it.NP)();"MSA"===t?P="MSA":"AAD"===t&&(P="AAD")}T.YT.sendTraceInfoEvent(O),a.submitTime=(new Date).toISOString();const F=lt();a.clientFeedbackId=F,a.comment=e,a.rating=4;const U=[(0,J.tb)()?"1S":"","true"===b?"PCS":""].join(" ").trim()||"None";let H="";if("windowsShellV2"===k.T3.AppType&&window&&window.ShellFeedsApp&&window.ShellFeedsApp.shellFeedsExperienceInfo){const t=await Q();if(t){const{selectedHeadlineId:e,selectedHeadlineType:i}=window.ShellFeedsApp.shellFeedsExperienceInfo;H=function(t,e,i){if(!t)return"desync-missing-previews";if(!e)return"desync-missing-selectedHeadlineType";if(!i)return"desync-missing-selectedHeadlineId";const{isRotational:o,preview:n}=tt(t,e)||{};return n?et(n,o?"rotational":"default"):"desync"}(null==t?void 0:t.previews,i,e)}}a.application={appData:JSON.stringify({ScreenResolution:window&&window.screen?[screen.width,screen.height].join("x"):"",WatsonReportId:F,isMsft:$,isCorpNet:x,vertical:C,accountType:P,authData:D,pageGenTime:v,prgDiagnostics:m,city:h,iso:p,citycf:u,countrycf:g,debugId:I,debugIdClickTaskbar:window&&window.ShellFeedsApp&&window.ShellFeedsApp.shellFeedsExperienceInfo&&window.ShellFeedsApp.shellFeedsExperienceInfo.debugId,taskbarHeadlineContent:H,staticFallback:U,...B,...this.config.advancedFeatures&&n?{diagnosticData:JSON.stringify(this.diagnosticData)}:{},adsMetadata:JSON.stringify(this.generateAdsMetadata())})},a.email=i;const j=this.config.supplementFeatureName?"-"+this.config.supplementFeatureName:"";return a.telemetry={audience:k.T3?k.T3.CurrentMarket:"",audienceGroup:"Production",channel:w,deviceType:d,errorClassification:o,featureArea:M.featureArea+j,flights:z,isUserSubscriber:(0,it.Fo)(),platform:k.T3.CurrentRequestTargetScope&&k.T3.CurrentRequestTargetScope.os,processSessionId:l,sourceContext:M.sourceContext,isLogIncluded:n,sqmMachineId:k.T3.MachineId},a.web={browser:E?E.browserType:"",browserVersion:E?E.version:"",sourcePageName:y,sourcePageURI:location.href},await(0,L._)(a),a}getOcvPartDataByPageType(t){let e,i,o,{clientSettings:n}=t;switch(k.T3.AppType){case"windows":case"windowsShell":case"windowsShellV2":e=N.Ij.windowsFeed,i=k.T3.AppType,o=n?n.pagetype:"";break;case"edgeChromium":e=N.Ij.edgeChromium,i="New Tab Page",o="Features\\New Tab Page";break;case"personalize":e=N.Ij.feedbackDefault,i=k.T3.AppType,o="Newsletter";break;case"views":case"homePage":case"gaming":case"health":case"cgHomePage":case"weather":case"msn":case"shopping":case"community":e=N.Ij.feedbackDefault,i=k.T3.AppType,o=n?n.pagetype:""}return{appId:e,sourceContext:i,featureArea:o}}close(){let t=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];if(this.visible=!1,this.$emit("feedback-dialog-closed"),t){var e,i,o,n;const t="homepage-footer",a=document.querySelector(t)&&(null===(e=(i=document.querySelector(t).shadowRoot).querySelector)||void 0===e||null===(o=(n=e.call(i,"msn-feedback-link").shadowRoot).getElementById)||void 0===o?void 0:o.call(n,"feedback-link-button"));null==a||a.focus()}}handleReportDialogSubmit(t){this.reportFeedback(t.detail),this.activeDialog=ct.CloseDialog}hideDialog(t){this.isHidden=t}async getSignInStatus(){const t=(0,W.FS)();this.userSignInStatus=t?await(0,it.XK)():await(0,it.e9)()}}(0,b.Cg)([Z.CF],dt.prototype,"backgroundColor",void 0),(0,b.Cg)([G.sH],dt.prototype,"visible",void 0),(0,b.Cg)([G.sH],dt.prototype,"activeDialog",void 0),(0,b.Cg)([G.sH],dt.prototype,"isHidden",void 0),(0,b.Cg)([G.sH],dt.prototype,"showDiagnosticData",void 0),(0,b.Cg)([G.sH],dt.prototype,"showScreenshotEditor",void 0),(0,b.Cg)([G.sH],dt.prototype,"userSignInStatus",void 0),(0,b.Cg)([G.sH],dt.prototype,"getDefaultFeedback",void 0);var ht=i(92011),pt=i(23429),ut=i(77558),gt=i(74849),vt=i(22683),bt=i(48751);const ft=gt.A` .action-dialog{--action-dialog-z-index:${ut.P.Dialog.toString()};
        --layer-corner-radius: 6;
        --neutral-divider-rest: ${vt.hb};--action-dialog-width:var(--feedback-dialog-width,min(368px,88%));--action-dialog-height:var(--feedback-dialog-height);--button-min-width:min(156px,50%);position:relative}.action-dialog svg{fill:${bt.l}}.action-dialog-control-buttons{border-radius:var(--button-border-radius);font-size:var(--type-ramp-minus-1-font-size,12px)}.no-border-radius{border-radius:0px;--layer-corner-radius:0}.action-dialog-controls-container-single{display:grid;justify-content:center;grid-template-columns:1fr}.action-dialog-controls-container{display:grid;grid-template-columns:var(--button-min-width) var(--button-min-width);justify-content:center;grid-gap:var(--space-between-buttons)}.title{height:48px;border-bottom:1px solid ${vt.hb};
    }
`,mt=gt.A` :host{border-radius:6px}.temporary-hide{display:none}`;var $t=i(64003);const xt=gt.A`    
    ${ft} fluent-checkbox::part(label){width:100%;margin-inline-end:0}.report-dialog-content{display:flex;flex-direction:column;margin:18px 0 4px}.diagnostic-data-link{height:20px;display:flex}.report-dialog-content .input-option{display:flex;flex:1}.text-wrapper{display:flex;align-items:center;justify-content:space-between}.margin-gap-from-top{margin-top:14px}.report-dialog-content .feedback-inputbox{resize:none;width:100%;margin-bottom:"inherit"}.report-dialog-content .feedback-inputbox::part(control){height:100px;overflow:hidden;letter-spacing:inherit !important}.report-dialog-content fluent-text-field::part(control)::placeholder,.report-dialog-content .feedback-inputbox::part(control)::placeholder{color:${$t.c}}.report-dialog-content fluent-text-field::part(control){letter-spacing:inherit !important}.report-dialog-content .feedback-footer{display:block;height:45px;margin-bottom:40px}.report-dialog-content .feedback-footer fluent-anchor{font-size:var(--type-ramp-minus-2-font-size,10px)}.report-dialog-content .feedback-disclaimer{display:block;margin-top:5px;font-size:var(--type-ramp-minus-2-font-size,10px)}.report-dialog-content .image-wrapper{width:100%;position:relative}.report-dialog-content .image-wrapper img{max-height:400px;width:100%;object-fit:contain}.report-dialog-content .editor-button{position:absolute;right:0;top:0;opacity:0.8;padding:2px;backgroundColor:${bt.l}}.question-circle svg{fill:var(--neutral-focus);display:inline-block;width:16px;cursor:pointer}#reportDialogCloseButtonIcon::part(control):focus-visible{outline:var(--focus-stroke-outer) auto;border:unset;box-shadow:unset;outline-offset:-3px}`;var wt=i(96950),yt=i(39957),kt=i(69259),Ct=i(60402),St=i(63250),Dt=i(43554);i(68017).n;const Tt=wt.qy`<fluent-select id="reportDialogSelect" aria-label="reportdialog-select" title=${t=>t.strings.reportDialogFeedbackCategoryText} current-value=${t=>t.strings.reportDialogCommunitiesText} @change=${(t,e)=>{var i,o;const n=Object.keys(null===(i=t.reportDialogOptions)||void 0===i?void 0:i.options),a=((null===(o=e.event)||void 0===o?void 0:o.target)||{}).selectedIndex||0;t.handleReportTypeChange(n[a])}}><span slot="selected-value">${(t,e)=>t.strings[t.reportDialogOptions.selectedReportType+"Text"]}</span>${(0,yt.ux)(t=>{var e;return Object.keys(null===(e=t.reportDialogOptions)||void 0===e?void 0:e.options)},wt.qy`<fluent-option @click="${(t,e)=>{e.parent.handleReportTypeChange(t)}}" value="${(t,e)=>e.parent.strings[t+"Text"]}" id="${t=>t}" class=${(t,e)=>e.parent.reportDialogOptions.selectedReportType===t?"selected":"unselected"} aria-label="${t=>t}" ?selected=${(t,e)=>e.parent.reportDialogOptions.selectedReportType===t}><span>${(t,e)=>e.parent.strings[t+"Text"]}</span></fluent-option>`)}</fluent-select>`,At=wt.qy`<div class="report-dialog-content">${(0,kt.z)(t=>{var e;return null===(e=t.reportDialogOptions)||void 0===e?void 0:e.options},Tt)}<fluent-text-area class="feedback-inputbox" :value=${t=>{var e;return null===(e=t.reportDialogOptions)||void 0===e?void 0:e.reportDialogFeedbackInput}} @input=${(t,e)=>t.setReportDialogFeedbackInput(e.event.target.value)} placeholder=${t=>t.strings.reportDialogFeedbackText} title=${t=>t.strings.inputTitleText} aria-required="false"></fluent-text-area>${(0,kt.z)(t=>t.advancedFeatures,wt.qy`<template>${(0,kt.z)(t=>!t.disableIsDiagnosticData,wt.qy`<div class="text-wrapper"><fluent-checkbox @change="${(t,e,i)=>{var o;return t.isDiagnosticData=null===(o=e.event.target)||void 0===o?void 0:o.checked}}" class="input-option diagnostic-data-link" arial-label=${t=>t.strings.includeDiagnosticData} :defaultChecked="${t=>t.isDiagnosticData}"><fluent-anchor appearance="lightweight" target="_blank" @click=${(t,e)=>{e.event.preventDefault(),e.event.stopPropagation(),t.$emit("showDiagnosticData")}}> ${t=>t.strings.includeDiagnosticData}</fluent-anchor></fluent-checkbox>${(0,kt.z)(t=>!t.disableQuestionCircle,wt.qy`<span arial-label=${t=>t.strings.pickSpecificArea} class="question-circle" id="pick-area-info-helper" @click="${(t,e)=>t.pickArea()}"> ${wt.qy.partial('<svg viewBox="0 0 24 24" fill="none"><path d="M12 2c1.2 0 2.36.21 3.42.6l-1.19 1.2a8.51 8.51 0 1 0 5.97 5.97l1.2-1.2A10 10 0 1 1 12 2Zm0 4c.52 0 1.02.07 1.5.19v1.57a4.5 4.5 0 1 0 2.74 2.74h1.57A6.01 6.01 0 1 1 12 6Zm2 6a2 2 0 1 1-1.22-1.84l1.72-1.72V5.25c0-.2.08-.39.22-.53l2.5-2.5a.75.75 0 0 1 1.28.53V5.5h2.75a.75.75 0 0 1 .53 1.28l-2.5 2.5a.75.75 0 0 1-.53.22h-3.19l-1.72 1.72c.1.24.16.5.16.78Zm4.44-4 1-1h-1.69a.75.75 0 0 1-.75-.75V4.56l-1 1v2.38a.7.7 0 0 1 .06.06h2.38Z"/></svg>')}</span><fluent-tooltip :delay=${t=>0} anchor="pick-area-info-helper"><span class="tooltip-info">${t=>t.strings.pickSpecificArea}</span></fluent-tooltip>`)}</div>`)} ${(0,kt.z)(t=>t.supportScreenshot,wt.qy`<div class="text-wrapper"><fluent-checkbox class="input-option" ${(0,Ct.K)("screenshotCheckbox")} @change="${(t,e,i)=>{var o;return null!==(o=e.event.target)&&void 0!==o&&o.checked?t.screenshot(e.event.target):t.screenshotUrl=""}}" arial-label=${t=>t.strings.includeThisScreenshot}><span class="input-text">${t=>t.strings.includeThisScreenshot}</span></fluent-checkbox><span class="question-circle" id="screenshot-info-helper">${wt.qy.partial('<svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 1 0 20 10 10 0 0 1 0-20Zm0 1.67a8.34 8.34 0 0 0 0 16.66 8.34 8.34 0 0 0 0-16.66Zm0 11.83a1 1 0 1 1 0 2 1 1 0 0 1 0-2Zm0-8.75a2.75 2.75 0 0 1 2.75 2.75c0 1.01-.3 1.57-1.05 2.36l-.17.17c-.62.62-.78.89-.78 1.47a.75.75 0 0 1-1.5 0c0-1.01.3-1.57 1.05-2.36l.17-.17c.62-.62.78-.89.78-1.47a1.25 1.25 0 0 0-2.5-.13v.13a.75.75 0 0 1-1.5 0A2.75 2.75 0 0 1 12 6.75Z"/></svg>')}</span><fluent-tooltip :delay=${t=>0} anchor="screenshot-info-helper"><span class="tooltip-info">${t=>t.strings.screenshotHelpInfo}</span></fluent-tooltip></div>`)} ${(0,kt.z)(t=>t.supportScreenshot&&t.screenshotUrl,wt.qy`<div class="image-wrapper"><img src="${t=>t.screenshotUrl}"/><fluent-button class="editor-button" arial-label=${t=>t.strings.corpImage} role="button" title=${t=>t.strings.corpImage} appearance="stealth"tabindex="0" @click=${t=>t.$emit("handleShowScreenshot",{screenshotUrl:t.screenshotUrlBackup,screenshotCorpCallback(e){return t.screenshotUrl=e}})}>${wt.qy.partial(Dt.A)}</fluent-button></div>`)}</template>`)}<div class="text-wrapper"><fluent-checkbox class="input-option" :checked=${t=>t.useEmailAddress} :placeholder=${t=>t.userEmailPlaceholder} @change=${(t,e)=>{var i;return t.useEmailAddress=null===(i=e.event.target)||void 0===i?void 0:i.checked}} arial-label=${t=>t.strings.emailLabel} :defaultChecked="${t=>t.useEmailAddress}">${t=>t.strings.emailLabel}</fluent-checkbox></div><fluent-text-field :value=${t=>t.userEmailValue} :placeholder=${t=>t.strings.emailValidationLabel} :title=${t=>t.strings.emailAttributeTitle} @input=${(t,e)=>{t.inputEmailHandler(e.event.target.value)}} aria-required="false"></fluent-text-field><div class="feedback-footer margin-gap-from-top"><div class="feedback-disclaimer"><div>${t=>t.statementText}</div><fluent-anchor appearance="lightweight" href=${"https://go.microsoft.com/fwlink/?LinkId=521839"} target="_blank" data-t="${t=>t.feedbackDialogTelemetryTags.privacyLink}">${t=>t.strings.reportDialogPrivacyStatementLinkText}</fluent-anchor></div></div></div>`,It=wt.qy`<msn-action-dialog class="action-dialog ${t=>t.enableWinShellLayout?"no-border-radius":""}" headline=${t=>t.strings.reportDialogHeader} ariaLabel=${t=>t.strings.reportDialogHeaderAriaLabel} :trapFocus=${t=>!0} modal><fluent-button slot="close-button" appearance="stealth" tabindex="0" id="reportDialogCloseButtonIcon" @click=${t=>t.close()} aria-label=${t=>t.strings.closeDialogButtonText} role="button" title=${t=>t.strings.closeDialogButtonText} data-t="${t=>t.feedbackDialogTelemetryTags.closeButton}">${wt.qy.partial(St.A)}</fluent-button>${(0,kt.z)(t=>t.reportDialogOptions,At)}<div class="action-dialog-controls-container"><fluent-button class="action-dialog-control-buttons ${t=>t.enableWinShellLayout?"no-border-radius":""}" slot="cancel-button" id="reportDialogCancelButton" @click=${t=>t.close()} aria-label=${t=>t.strings.closeDialogButtonText} role="button" title=${t=>t.strings.closeDialogButtonText} data-t="${t=>t.feedbackDialogTelemetryTags.cancelButton}">${t=>t.strings.closeDialogButtonText}</fluent-button><fluent-button class="action-dialog-control-buttons ${t=>t.enableWinShellLayout?"no-border-radius":""}" slot="action-button" appearance="accent" id="reportDialogSubmitButton" @click=${t=>t.raiseSubmitEvent()} ?disabled=${t=>t.shouldSubmitBeDisabled} aria-label=${t=>t.strings.sendDialogButtonText} role="button" title=${t=>t.strings.sendDialogButtonText} data-t="${t=>t.feedbackDialogTelemetryTags.submitButton}">${t=>t.strings.sendDialogButtonText}</fluent-button></div></msn-action-dialog>`,zt="user-email-to-ocv-key";let Et=class extends ht.L{constructor(){var t;super(...arguments),this.userEmailPlaceholder="",this.isDiagnosticData=!1,this.advancedFeatures=!1,this.diableisDiagnosticData=!1,this.supportScreenshot="function"==typeof(null===(t=navigator.mediaDevices)||void 0===t?void 0:t.getUserMedia),this.inputBlurHandler=(0,nt.A)(()=>{this.isValidEmail(this.userEmailValue)&&(this.useEmailAddress=!0)},1e3),this.setReportDialogFeedbackInput=t=>{this.reportDialogOptions={...this.reportDialogOptions,reportDialogFeedbackInput:t}},this.screenshot=t=>{var e;e=(e,i)=>{e&&i?(this.screenshotUrl=i,this.screenshotUrlBackup=i):t.checked=!1,this.$emit("hideDialog",!1)},(()=>{this.$emit("hideDialog",!0)})(),navigator.mediaDevices.getDisplayMedia({video:!0,preferCurrentTab:!0,selfBrowserSurface:"include"}).then(function(t){const{width:i,height:o,fixedHeight:n}=at(),a=document.createElement("video");a.width=i,a.height=o,a.autoplay=!0,a.playsInline=!0,document.body.appendChild(a),a.srcObject=t,a.style.display="none",window.setTimeout(()=>{const s=document.createElement("canvas");s.width=i,s.height=o,s.getContext("2d").drawImage(a,0,0,i,o);const r=document.createElement("canvas"),l=r.getContext("2d");r.width=i,r.height=n,l.drawImage(s,0,0),e(!0,r.toDataURL("image/png")),t.getTracks().forEach(t=>{t.stop(),document.body.removeChild(a)})},300)},()=>e(!1)).catch(()=>e(!1))},this.pickArea=()=>{rt(()=>{this.$emit("hideDialog",!0)},t=>{if(this.$emit("hideDialog",!1),!t)return;this.highlightSelectedArea(t);const e={xPath:st(t),...t.getBoundingClientRect().toJSON(),dom:t.outerHTML.slice(0,1e4)};this.$emit("pickAnAreaDone",e)},{pickAreaHelpInfo:this.strings.pickAreaHelpInfo,cancel:this.strings.cancelDialogButtonText})}}connectedCallback(){var t;super.connectedCallback();const e=(null===(t=this.getDefaultFeedback)||void 0===t?void 0:t.call(this))??"";if(this.strings.reportDialogBlurryImageText&&this.strings.reportDialogFeedRelevancyText&&this.strings.reportDialogFeedbackCategoryText){let t={};this.availableReportDialogOptions?this.availableReportDialogOptions.forEach(e=>{t={...t,[e]:!1}}):t={reportDialogCommunities:!1,reportDialogBrokenFeature:!1,reportDialogContentQuality:!1,reportDialogMoney:!1,reportDialogSports:!1,reportDialogWeather:!1,reportDialogEntertainment:!1,reportDialogNews:!1,reportDialogTraffic:!1,reportDialogShopping:!1,reportDialogGaming:!1,reportDialogHealth:!1,reportDialogTravel:!1,reportDialogGeneralFeedback:!1},this.reportDialogOptions={options:t,selectedReportType:this.defaultSelectedReportType||"reportDialogFeedbackCategory",reportDialogFeedbackInput:e}}else this.reportDialogOptions={options:{reportDialogBlurryImage:!1,reportDialogFeedRelevancy:!1,reportDialogDuplicateContent:!1,reportDialogAdQuality:!1,reportDialogContentQuality:!1,reportDialogGeneralFeedback:!1},selectedReportType:this.defaultSelectedReportType||"reportDialogGeneralFeedback",reportDialogFeedbackInput:e};this.statementText=this.strings.reportDialogFeedbackDisclaimerText;const i=S.Rb&&S.Rb.ClientSettings,o=i&&i.detection&&i.detection.isMsft||!1;this.useEmailAddress=null!=this.useEmailAddress?this.useEmailAddress:o,pt.L.enqueue(()=>{this.shouldAutoTakeScreenshot&&this.screenshotCheckbox&&!this.screenshotUrl&&(this.screenshotCheckbox.checked=!0)})}inputEmailHandler(t){this.userEmailValue=t,this.inputBlurHandler()}useEmailAddressChanged(t,e){!0===e?this.getUserEmail():this.userEmailValue=""}shouldAutoFillEmailChanged(t,e){!0===e?this.getUserEmail():this.userEmailValue=""}handleReportTypeChange(t){this.reportDialogOptions={...this.reportDialogOptions,selectedReportType:t}}close(){this.$emit("close"),this.clearScreenshot()}raiseSubmitEvent(){const t={feedbackInput:this.reportDialogOptions.reportDialogFeedbackInput,feedbackEmail:this.useEmailAddress?this.userEmailValue:void 0,feedbackCategories:this.reportDialogOptions.selectedReportType,feedbackScreenshot:this.screenshotUrl,isDiagnosticData:this.isDiagnosticData};this.$emit("submit",t),this.clearScreenshot()}clearScreenshot(){this.screenshotCheckbox&&(this.screenshotCheckbox.checked=!1),this.screenshotUrl="",this.screenshotUrlBackup=""}get shouldSubmitBeDisabled(){var t,e;const i=this.userEmailValue,o=!!i&&this.isValidEmail(i);return""===(null===(t=this.reportDialogOptions)||void 0===t?void 0:t.reportDialogFeedbackInput.trim())||this.useEmailAddress&&!o||"reportDialogFeedbackCategory"==(null===(e=this.reportDialogOptions)||void 0===e?void 0:e.selectedReportType)}isValidEmail(t){const e=/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(t);return e&&(0,_.Lg)().setItem(zt,t),e}getUserEmail(){const t=(0,_.Lg)().getItem(zt);if(t)return void(this.userEmailValue=t);if(!this.userEmailValue){const t=(0,Y.A)(window,"MeControl.WebInline.getOptions",void 0);if(!t)return;const e=(0,Y.A)(t(),"currentAccount.memberName","");this.userEmailValue=e}}highlightSelectedArea(t){var e;this.recoverPickAreaStyle(),this.pickAreaBorderStyle=null===(e=t.style)||void 0===e?void 0:e.border,t.style.border="solid 2px red",this.pickAreaDom=t}recoverPickAreaStyle(){this.pickAreaDom&&(this.pickAreaDom.style.border=this.pickAreaBorderStyle,this.pickAreaDom=null,this.pickAreaBorderStyle="")}disconnectedCallback(){super.disconnectedCallback(),this.recoverPickAreaStyle()}};(0,b.Cg)([G.sH],Et.prototype,"enableWinShellLayout",void 0),(0,b.Cg)([G.sH],Et.prototype,"feedbackDialogTelemetryTags",void 0),(0,b.Cg)([G.sH],Et.prototype,"reportDialogOptions",void 0),(0,b.Cg)([G.sH],Et.prototype,"strings",void 0),(0,b.Cg)([G.sH],Et.prototype,"useEmailAddress",void 0),(0,b.Cg)([G.sH],Et.prototype,"userEmailValue",void 0),(0,b.Cg)([G.sH],Et.prototype,"shouldAutoFillEmail",void 0),(0,b.Cg)([G.sH],Et.prototype,"userEmailPlaceholder",void 0),(0,b.Cg)([G.sH],Et.prototype,"isDiagnosticData",void 0),(0,b.Cg)([G.sH],Et.prototype,"advancedFeatures",void 0),(0,b.Cg)([G.sH],Et.prototype,"diableisDiagnosticData",void 0),(0,b.Cg)([G.sH],Et.prototype,"screenshotUrl",void 0),(0,b.Cg)([G.sH],Et.prototype,"statementText",void 0),(0,b.Cg)([G.sH],Et.prototype,"getDefaultFeedback",void 0),(0,b.Cg)([G.sH],Et.prototype,"defaultSelectedReportType",void 0),(0,b.Cg)([G.sH],Et.prototype,"shouldAutoTakeScreenshot",void 0),(0,b.Cg)([G.Jg],Et.prototype,"shouldSubmitBeDisabled",null),Et=(0,b.Cg)([(0,ht.E)({name:"report-dialog",template:It,styles:xt})],Et);const Mt=function(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:2;const e=at(),i=Math.max(innerWidth/t,800);return{width:i,height:e.fixedHeight/e.width*i}}(),Bt=gt.A`
    ${ft} msn-action-dialog::part(control){width:${String(Mt.width+60)}px;
        height: ${String(Mt.height+120)}px}msn-action-dialog .img-editor{width:${String(Mt.width)}px;
        height: ${String(Mt.height)}px;position:relative;margin-top:12px}.action-dialog-control-buttons::part(control){padding:12px 48px}.canvas-mask{width:100%;height:100%;top:0;left:0;position:absolute;background-color:transparent}.action-buttons{margin-top:20px;width:100%;text-align:center}`,Ot=wt.qy`<msn-action-dialog class="action-dialog" headline=${t=>t.strings.screenshotEditorHeader} ariaLabel=${t=>t.strings.screenshotEditorHeader} :trapFocus=${t=>!1} modal><fluent-button slot="close-button" appearance="stealth" tabindex="0" @click=${t=>t.$emit("close")} aria-label=${t=>t.strings.closeDialogButtonText} role="button" title=${t=>t.strings.closeDialogButtonText}>${wt.qy.partial(St.A)}</fluent-button><div class="img-editor" ${(0,Ct.K)("container")} @mousemove=${(t,e)=>t.drag(e.event)} @touchmove= ${(t,e)=>t.drag(e.event)} @mousedown=${(t,e)=>t.dragStart(e.event)} @mouseup=${(t,e)=>t.dragEnd(e.event)} @touchend=${(t,e)=>t.dragEnd(e.event)} @touchstart=${(t,e)=>t.dragStart(e.event)}><img ${(0,Ct.K)("imageRef")}  width="100%" height="100%" src="${t=>{var e;return null===(e=t.screenshotOptions)||void 0===e?void 0:e.screenshotUrl}}"/><canvas ${(0,Ct.K)("canvasRef")} class="canvas-mask" width="${t=>t.rect.width}" height="${t=>t.rect.height}"></canvas></div><div class="action-buttons"><fluent-button class="action-dialog-control-buttons" slot="action-button" appearance="accent" tabindex="0" @click=${t=>t.confirm()} aria-label=${t=>t.strings.confirm} role="button" title=${t=>t.strings.confirm}>${t=>t.strings.confirm}</fluent-button><fluent-button class="action-dialog-control-buttons" slot="cancel-button" tabindex="0" aria-label=${t=>t.strings.cancelDialogButtonText} role="button" title=${t=>t.strings.cancelDialogButtonText} @click=${t=>t.$emit("close")}>${t=>t.strings.cancelDialogButtonText}</fluent-button></div></msn-action-dialog>`;let Pt=class extends ht.L{constructor(){super(...arguments),this.strings={},this.rect=Mt,this.selectedRect=[],this.startX=0,this.startY=0,this.active=!1,this.drag=t=>{if(t.preventDefault(),!this.active)return;const e=this.canvasRef.getBoundingClientRect(),i="touchmove"===t.type?t.touches[0].clientX-e.left:t.clientX-e.left,o="touchmove"===t.type?t.touches[0].clientY-e.top:t.clientY-e.top,n=i<this.startX?i:this.startX,a=o<this.startY?o:this.startY,s=Math.abs(i-this.startX),r=Math.abs(o-this.startY);this.drawSelectedArea(n,a,s,r)}}dragStart(t){this.active=!0;const e=this.canvasRef.getBoundingClientRect();this.startX="touchstart"===t.type?t.touches[0].clientX-e.left:t.clientX-e.left,this.startY="touchstart"===t.type?t.touches[0].clientY-e.top:t.clientY-e.top}dragEnd(t){t.preventDefault(),this.active=!1;const e=this.canvasRef.getBoundingClientRect(),i="touchend"===t.type?t.touches[0].clientX-e.left:t.clientX-e.left,o="touchend"===t.type?t.touches[0].clientY-e.top:t.clientY-e.top,n=i<this.startX?i:this.startX,a=o<this.startY?o:this.startY,s=Math.abs(i-this.startX),r=Math.abs(o-this.startY);this.drawSelectedArea(n,a,s,r,!0),this.selectedRect=[n,a,s,r]}confirm(){const t=at(),e=document.createElement("canvas");e.width=t.width,e.height=t.fixedHeight;const i=e.getContext("2d");this.imageRef.setAttribute("crossOrigin","Anonymous"),i.drawImage(this.imageRef,0,0,t.width,t.fixedHeight);const o=t.width/this.rect.width,n=document.createElement("canvas"),a=n.getContext("2d"),s=this.selectedRect.map(t=>t*o);n.width=s[2],n.height=s[3],a.drawImage(e,s[0],s[1],s[2],s[3],0,0,s[2],s[3]),this.screenshotOptions.screenshotCorpCallback(n.toDataURL("image/png")),this.$emit("close")}drawSelectedArea(t,e,i,o){let n=arguments.length>4&&void 0!==arguments[4]&&arguments[4];const a=this.rect.width,s=this.rect.height,r=this.canvasRef.getContext("2d");r.fillStyle="rgba(0,0,0, 0.7)",r.strokeStyle=n?"#ffffff":"rgba(255,255,255,.5)",r.clearRect(0,0,a,s),r.fillRect(0,0,a,s),r.clearRect(t,e,i,o),r.setLineDash([15,3,3,3]),r.strokeRect(t,e,i,o)}};(0,b.Cg)([G.sH],Pt.prototype,"screenshotOptions",void 0),(0,b.Cg)([G.sH],Pt.prototype,"strings",void 0),Pt=(0,b.Cg)([(0,ht.E)({name:"screenshot-editor-dialog",template:Ot,styles:Bt})],Pt);var Ft=i(92393);const Nt=gt.A`
    ${ft} .feedback-text{padding:0 10px 0 0;font-size:var(--type-ramp-minus-1-font-size,10px)}.feedback-supportText{display:flex;font-size:var(--type-ramp-minus-1-font-size,10px)}.feedback-supportUrl{padding:0 5px 0 5px;position:relative;top:-9px;font-size:var(--type-ramp-minus-2-font-size,10px)}.feedback-supportUrl a{text-decoration:none;color:${Ft.W_}}.feedback-supportUrl a:hover{color:${Ft.YL};
    }
`,Lt=wt.qy`<msn-action-dialog class="action-dialog" headline=" ${t=>t.strings.closeDialogHeader}" ariaLabel=${t=>t.strings.closeDialogHeader} :trapFocus=${t=>!0} modal><fluent-button slot="close-button" appearance="stealth" tabindex="0" id="closeDialogCloseButtonIcon" @click=${t=>t.close()} aria-label=${t=>t.strings.closeButtonAriaLabel} role="button" title=${t=>t.strings.closeDialogButtonText} data-t="${t=>t.feedbackDialogTelemetryTags.closeButton}">${wt.qy.partial(St.A)}</fluent-button><div class="close-dialog-content"><p class="feedback-text">${t=>t.strings.closeDialogBody}</p><div class="feedback-supportText">${t=>t.supportText[0]}<div class="feedback-supportUrl"><fluent-anchor appearance="lightweight" id="closeDialogSupportText" href= ${t=>t.supportUrlLink} target="_blank">${t=>t.strings.closeDialogSupportLinkText}</fluent-anchor></div>${t=>t.supportText[1]}</div></div><div class="action-dialog-controls-container-single"><fluent-button class="action-dialog-control-buttons" appearance="accent" id="closeDialogCloseButton" @click=${t=>t.close()} title=${t=>t.strings.closeDialogButtonText} aria-label=${t=>t.strings.closeButtonAriaLabel} role="button" data-t="${t=>t.feedbackDialogTelemetryTags.submitButton}">${t=>t.strings.closeDialogButtonText}</fluent-button></div></msn-action-dialog>`;let Ut=class extends ht.L{close(){this.$emit("close")}get supportUrlLink(){return this.supportUrl}get supportText(){return this.strings.closeDialogSupportText.split("{0}")}};(0,b.Cg)([Z.CF],Ut.prototype,"supportUrl",void 0),(0,b.Cg)([G.sH],Ut.prototype,"feedbackDialogTelemetryTags",void 0),(0,b.Cg)([G.sH],Ut.prototype,"strings",void 0),Ut=(0,b.Cg)([(0,ht.E)({name:"close-dialog",template:Lt,styles:Nt})],Ut);var Ht=i(14996),jt=i(37302),Rt=i(71157);const Vt=gt.A`
    ${ft} msn-action-dialog::part(control){width:600px;max-width:100%;max-height:800px;padding-bottom:60px;overflow-y:auto;overflow-x:hidden}.pre-wrapper{border:#e5e5e5 1px solid}pre{white-space:pre-wrap;word-wrap:break-word}svg.action-operator{fill:transparent;stroke:${Ht.WN}}fluent-accordion-item{margin-top:var(--dialog-padding);border-bottom:1px solid ${jt.F7};padding:12px}.heading{font-size:${Rt.T};
    }
`,_t=wt.qy`<svg class="action-operator" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" slot="collapsed-icon"><path d="M15.2222 1H2.77778C1.79594 1 1 1.79594 1 2.77778V15.2222C1 16.2041 1.79594 17 2.77778 17H15.2222C16.2041 17 17 16.2041 17 15.2222V2.77778C17 1.79594 16.2041 1 15.2222 1Z" stroke-linecap="round" stroke-linejoin="round"></path><path d="M9 5.44446V12.5556" stroke-linecap="round" stroke-linejoin="round"></path><path d="M5.44446 9H12.5556" stroke-linecap="round" stroke-linejoin="round"></path></svg>`,Wt=wt.qy`<svg class="action-operator" width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" slot="expanded-icon"><path d="M15.2222 1H2.77778C1.79594 1 1 1.79594 1 2.77778V15.2222C1 16.2041 1.79594 17 2.77778 17H15.2222C16.2041 17 17 16.2041 17 15.2222V2.77778C17 1.79594 16.2041 1 15.2222 1Z" stroke-linecap="round" stroke-linejoin="round"></path><path d="M5.44446 9H12.5556" stroke-linecap="round" stroke-linejoin="round"></path></svg>`,Zt=wt.qy`<msn-action-dialog :trapFocus=${t=>!1} class="action-dialog" headline=${t=>t.strings.diagnosticDialogHeader} ariaLabel=${t=>t.strings.diagnosticDialogHeader} modal><fluent-button slot="close-button" appearance="stealth" tabindex="0" @click=${t=>t.close()} aria-label=${t=>t.strings.closeDialogButtonText} role="button" title=${t=>t.strings.closeDialogButtonText} data-t="${t=>t.feedbackDialogTelemetryTags.closeButton}">${wt.qy.partial(St.A)}</fluent-button><fluent-accordion><fluent-accordion-item><div slot="heading" class="heading">${t=>t.strings.diagnosticAppInfo}</div>${_t} ${Wt}<div class="pre-wrapper"><pre>${t=>JSON.stringify({headData:t.diagnosticData.headData,appEnvironment:t.diagnosticData.appEnvironment},null,2)}</pre></div></fluent-accordion-item><fluent-accordion-item><div slot="heading" class="heading">${t=>t.strings.diagnosticSettingInfo}</div>${_t} ${Wt}<div class="pre-wrapper"><pre>${t=>JSON.stringify({rootConfig:t.diagnosticData.rootConfig},null,2)}</pre></div></fluent-accordion-item><fluent-accordion-item><div slot="heading" class="heading">${t=>t.strings.diagnosticErrorInfo}</div>${_t} ${Wt}<div class="pre-wrapper"><pre>${t=>JSON.stringify({error:t.diagnosticData.error},null,2)}</pre></div></fluent-accordion-item>${(0,kt.z)(t=>t.diagnosticData.pickedArea,wt.qy`<fluent-accordion-item><div slot="heading" class="heading">${t=>t.strings.selectedAreaInfo}</div>${_t} ${Wt}<div class="pre-wrapper"><pre>${t=>JSON.stringify({pickedArea:t.diagnosticData.pickedArea},null,2)}</pre></div></fluent-accordion-item>`)}</fluent-accordion></msn-action-dialog>`;let Gt=class extends ht.L{constructor(){super(...arguments),this.strings={}}close(){this.$emit("close")}};(0,b.Cg)([G.sH],Gt.prototype,"diagnosticData",void 0),(0,b.Cg)([G.sH],Gt.prototype,"strings",void 0),(0,b.Cg)([G.sH],Gt.prototype,"feedbackDialogTelemetryTags",void 0),Gt=(0,b.Cg)([(0,ht.E)({name:"diagnostic-data-dialog",template:Zt,styles:Vt})],Gt);const qt=wt.qy`<div data-t="${t=>t.feedbackDialogTelemetryTags.module}" class="${t=>t.isHidden?"temporary-hide":""}"><fluent-design-system-provider fill-color=${t=>t.backgroundColor}>${(0,kt.z)(t=>t.visible&&t.activeDialog===ct.ReportDialog,wt.qy`<report-dialog :enableWinShellLayout=${t=>t.config.enableWinShellLayout} :shouldAutoFillEmail=${t=>t.config.includeUserEmail} :shouldAutoTakeScreenshot=${t=>t.config.includeScreenshot} :feedbackDialogTelemetryTags=${t=>t.feedbackDialogTelemetryTags} :strings=${t=>t.strings} :advancedFeatures=${t=>t.config.advancedFeatures} :isDiagnosticData=${t=>t.config.includeDiagnosticData} :disableIsDiagnosticData=${t=>t.config.disableIsDiagnosticData} :getDefaultFeedback=${t=>t.getDefaultFeedback} :defaultSelectedReportType=${t=>t.config.defaultSelectedReportType} :availableReportDialogOptions=${t=>t.config.availableReportDialogOptions} :supportScreenshot=${t=>t.config.supportScreenshot} :disableQuestionCircle=${t=>t.config.disableQuestionCircle} @hideDialog=${(t,e)=>{var i;t.hideDialog(null===(i=e.event)||void 0===i?void 0:i.detail)}} @submit=${(t,e)=>t.handleReportDialogSubmit(e.event)} @showDiagnosticData= ${t=>{t.showDiagnosticData=!0}} @handleShowScreenshot =${(t,e)=>{var i;return t.handleShowScreenshot(null===(i=e.event)||void 0===i?void 0:i.detail)}} @pickAnAreaDone =${(t,e)=>{var i;return t.diagnosticData={...t.diagnosticData,pickedArea:null===(i=e.event)||void 0===i?void 0:i.detail}}} @close=${t=>t.close()}></report-dialog>`)} ${(0,kt.z)(t=>t.visible&&t.activeDialog===ct.CloseDialog,wt.qy`<close-dialog supportUrl=${t=>{var e;return null===(e=t.config.confirmationHelpAndSupport)||void 0===e?void 0:e.href}} :feedbackDialogTelemetryTags=${t=>t.feedbackDialogTelemetryTags} :strings=${t=>t.strings} @close=${t=>t.close()}></close-dialog>`)} ${(0,kt.z)(t=>t.visible&&t.showDiagnosticData,wt.qy`<diagnostic-data-dialog @close=${t=>t.showDiagnosticData=!1} :feedbackDialogTelemetryTags=${t=>t.feedbackDialogTelemetryTags} :diagnosticData=${t=>t.diagnosticData} :strings=${t=>t.strings}></diagnostic-data-dialog>`)} ${(0,kt.z)(t=>t.visible&&t.showScreenshotEditor,wt.qy`<screenshot-editor-dialog @close=${t=>t.showScreenshotEditor=!1} :feedbackDialogTelemetryTags=${t=>t.feedbackDialogTelemetryTags} :screenshotOptions=${t=>t.screenshotOptions} :strings=${t=>t.strings}></screenshot-editor-dialog>`)}</fluent-design-system-provider></div>`,Jt={experienceConfigSchema:undefined},Kt=dt.compose({name:"feedback-dialog-wc",template:qt,styles:[mt]});n.m.define(a.c.registry),s.m.define(a.c.registry),r.m.define(a.c.registry),l.m.define(a.c.registry),c.m.define(a.c.registry),d.m.define(a.c.registry),h.m.define(a.c.registry),p.m.define(a.c.registry),u.m.define(a.c.registry),g.m.define(a.c.registry),v.m.define(a.c.registry)},29783(t,e,i){i.d(e,{m(){return $}});var o=i(37180),n=i(14804),a=i(45755),s=i(68009),r=i(95239);const{create:l}=a.G,c=l("neutral-fill-inverse-rest-delta",0),d=l("neutral-fill-inverse-hover-delta",-3),h=l("neutral-fill-inverse-active-delta",7),p=l("neutral-fill-inverse-focus-delta",0);var u=i(31023);const{create:g}=a.G,v=g({name:"neutral-fill-inverse-recipe"},{evaluate(t,e){return function(t,e,i,o,n,a){const r=(0,s.F)(e),l=t.closestIndexOf(t.colorContrast(e,14)),c=l+r*Math.abs(i-o);let d,h;return(1===r?i<o:r*i>r*o)?(d=l,h=c):(d=c,h=l),{rest:t.get(d),hover:t.get(h),active:t.get(d+r*n),focus:t.get(d+r*a)}}(t(u.r),e||t(r.p),t(c),t(d),t(h),t(p))}});g("neutral-fill-inverse-rest",t=>t(v).evaluate(t).rest),g("neutral-fill-inverse-hover",t=>t(v).evaluate(t).hover),g("neutral-fill-inverse-active",t=>t(v).evaluate(t).active),g("neutral-fill-inverse-focus",t=>t(v).evaluate(t).focus);class b extends n.c{connectedCallback(){super.connectedCallback();const t=v;r.p.setValueFor(this,e=>e(t).evaluate(e,e(r.p)).rest)}}var f=i(54750),m=i(4912);const $=b.compose({name:`${o.c.prefix}-tooltip`,template:m.v,styles:f.R})},29995(t,e,i){i.d(e,{M(){return r}});var o=i(96950),n=i(60402),a=i(82774),s=i(35106);function r(t={}){return o.qy`
        <a
            class="control"
            part="control"
            download="${t=>t.download}"
            href="${t=>t.href}"
            hreflang="${t=>t.hreflang}"
            ping="${t=>t.ping}"
            referrerpolicy="${t=>t.referrerpolicy}"
            rel="${t=>t.rel}"
            target="${t=>t.target}"
            type="${t=>t.type}"
            aria-atomic="${t=>t.ariaAtomic}"
            aria-busy="${t=>t.ariaBusy}"
            aria-controls="${t=>t.ariaControls}"
            aria-current="${t=>t.ariaCurrent}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-details="${t=>t.ariaDetails}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-errormessage="${t=>t.ariaErrormessage}"
            aria-expanded="${t=>t.ariaExpanded}"
            aria-flowto="${t=>t.ariaFlowto}"
            aria-haspopup="${t=>t.ariaHaspopup}"
            aria-hidden="${t=>t.ariaHidden}"
            aria-invalid="${t=>t.ariaInvalid}"
            aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
            aria-label="${t=>t.ariaLabel}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-live="${t=>t.ariaLive}"
            aria-owns="${t=>t.ariaOwns}"
            aria-relevant="${t=>t.ariaRelevant}"
            aria-roledescription="${t=>t.ariaRoledescription}"
            ${(0,n.K)("control")}
        >
            ${(0,s.LT)(t)}
            <span class="content" part="content">
                <slot ${(0,a.e)("defaultSlottedContent")}></slot>
            </span>
            ${(0,s.aO)(t)}
        </a>
    `}},43554(t,e){e.A='<svg width="14" height="15" viewBox="0 0 14 15"><path d="M11.77.75c.31 0 .6.06.87.18A2.2 2.2 0 0 1 14 2.98a2.2 2.2 0 0 1-.66 1.57L4.2 13.7 0 14.76l1.05-4.21 9.14-9.13a2.19 2.19 0 0 1 .73-.49c.27-.11.55-.17.85-.17Zm-9.75 9.88a2.78 2.78 0 0 1 1.32.78 2.76 2.76 0 0 1 .78 1.32l7.6-7.6-2.1-2.1-7.6 7.6Zm-.99 3.09 2.4-.6a2.09 2.09 0 0 0-.22-.64 2.04 2.04 0 0 0-.4-.54 2.04 2.04 0 0 0-.54-.4 2.09 2.09 0 0 0-.64-.23l-.6 2.4Zm11.22-9.13.37-.35a2.93 2.93 0 0 0 .32-.36c.1-.12.17-.26.22-.4a1.36 1.36 0 0 0 .09-.5 1.5 1.5 0 0 0-.9-1.36 1.4 1.4 0 0 0-.58-.12 1.36 1.36 0 0 0-.5.09 1.73 1.73 0 0 0-.4.22 3.06 3.06 0 0 0-.36.32l-.35.37 2.09 2.1Z"/></svg>'},43774(t,e,i){i.d(e,{p4(){return v},ls(){return b},vA(){return g},nF(){return u}});var o=i(45755),n=i(68009),a=i(95239);const{create:s}=o.G,r=s("neutral-stroke-strong-hover-delta",40),l=s("neutral-stroke-strong-active-delta",16),c=s("neutral-stroke-strong-focus-delta",25);var d=i(31023);const{create:h}=o.G,p=h({name:"neutral-stroke-strong-recipe"},{evaluate(t){return function(t,e,i,o,a,s){const r=(0,n.F)(e),l=t.colorContrast(e,i),c=t.closestIndexOf(l);return{rest:l,hover:t.get(c+r*o),active:t.get(c+r*a),focus:t.get(c+r*s)}}(t(d.r),t(a.p),3,t(r),t(l),t(c))}}),u=h("neutral-stroke-strong-rest",t=>t(p).evaluate(t).rest),g=h("neutral-stroke-strong-hover",t=>t(p).evaluate(t).hover),v=h("neutral-stroke-strong-active",t=>t(p).evaluate(t).active),b=h("neutral-stroke-strong-focus",t=>t(p).evaluate(t).focus)},45899(t,e,i){i.d(e,{m(){return u}});var o=i(37180),n=i(56911),a=i(7511),s=i(38493);class r extends a._{appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="neutral")}defaultSlottedContentChanged(){const t=this.defaultSlottedContent.filter(t=>t.nodeType===Node.ELEMENT_NODE);1===t.length&&t[0]instanceof SVGElement?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,n.Cg)([s.CF,(0,n.Sn)("design:type",String)],r.prototype,"appearance",void 0);var l=i(74849),c=i(25984),d=i(17767);const h=l.A`
    ${c._9}
`.withBehaviors((0,d.f)("accent",c.Vw),(0,d.f)("hypertext",c.aY),(0,d.f)("lightweight",c.ZI),(0,d.f)("outline",c.LA),(0,d.f)("stealth",c.ss)),p=(0,i(29995).M)(),u=r.compose({name:`${o.c.prefix}-anchor`,template:p,styles:h,shadowOptions:{delegatesFocus:!0}})},49473(t,e,i){i.d(e,{m(){return S}});var o=i(96789),n=i(37180),a=i(74849),s=i(64187),r=i(73477),l=i(22131),c=i(50882),d=i(7896),h=i(61138),p=i(26920),u=i(22683),g=i(74838),v=i(48751),b=i(14996),f=i(4283),m=i(48196);const $=a.A`
    ${(0,s.V)("flex")} :host {
        box-sizing: border-box;
        font-family: ${d.O};
        flex-direction: column;
        font-size: ${h.k};
        line-height: ${h.F};
        border-bottom: calc(${p.XA} * 1px) solid ${u.hb};
    }

    .region {
        display: none;
        padding: calc((6 + (${g.vR} * 2 * ${g.Br})) * 1px);
    }

    .heading {
        display: grid;
        position: relative;
        grid-template-columns: auto 1fr auto calc(${m.D} * 1px);
        z-index: 2;
    }

    .button {
        appearance: none;
        border: none;
        background: none;
        grid-column: 2;
        grid-row: 1;
        outline: none;
        padding: 0 calc((6 + (${g.vR} * 2 * ${g.Br})) * 1px);
        text-align: left;
        height: calc(${m.D} * 1px);
        color: ${v.l};
        cursor: pointer;
        font-family: inherit;
    }

    .button:hover,
    .button:active {
        color: ${v.l};
    }

    .button::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 1;
        cursor: pointer;
    }

    ${""}
    .button:${r.N}::before {
        outline: none;
        border: calc(${p.XA} * 1px) solid ${b.WN};
        box-shadow: 0 0 0 calc((${p.vd} - ${p.XA}) * 1px)
            ${b.WN};
    }

    :host([expanded]) .region {
        display: block;
    }

    .icon {
        display: flex;
        align-items: center;
        justify-content: center;
        grid-column: 4;
        z-index: 2;
        pointer-events: none;
        fill: ${f.IR};
    }

    ::slotted([name="collapsed-icon"]) {
        display: flex;
    }

    :host([expanded]) ::slotted([name="collapsed-icon"]),
    :host([expanded]) .collapsed-icon {
        display: none;
    }

    .expanded-icon,
    ::slotted([name="expanded-icon"]) {
        display: none;
    }

    :host([expanded]) ::slotted([name="expanded-icon"]),
    :host([expanded]) .expanded-icon {
        display: flex;
    }

    ::slotted([name="start"]) {
        display: flex;
        align-items: center;
        padding-inline-start: calc(${g.vR} * 1px);
        justify-content: center;
        grid-column: 1;
        z-index: 2;
    }

    ::slotted([name="end"]) {
        display: flex;
        align-items: center;
        justify-content: center;
        grid-column: 3;
        z-index: 2;
    }
`.withBehaviors((0,l.mr)(a.A`
            ${""}
            .button:${r.N}::before {
                border-color: ${c.A.Highlight};
                box-shadow: 0 0 0 calc((${p.vd} - ${p.XA}) * 1px)
                    ${c.A.Highlight};
            }
            .icon {
                fill: ${c.A.ButtonText};
            }
        `));var x=i(96950),w=i(60402),y=i(35106),k=i(18893);const C=function(t={}){return x.qy`
        <div
            class="heading"
            part="heading"
            role="heading"
            aria-level="${t=>t.headinglevel}"
        >
            <button
                class="button"
                part="button"
                ${(0,w.K)("expandbutton")}
                aria-expanded="${t=>t.expanded}"
                aria-controls="${t=>t.id}-panel"
                id="${t=>t.id}"
                @click="${(t,e)=>t.clickHandler(e.event)}"
            >
                <span class="heading-content" part="heading-content">
                    <slot name="heading"></slot>
                </span>
            </button>
            ${(0,y.LT)(t)}
            ${(0,y.aO)(t)}
            <span class="icon" part="icon" aria-hidden="true">
                <slot name="expanded-icon">
                    ${(0,k.R)(t.expandedIcon)}
                </slot>
                <slot name="collapsed-icon">
                    ${(0,k.R)(t.collapsedIcon)}
                </slot>
            <span>
        </div>
        <div
            class="region"
            part="region"
            id="${t=>t.id}-panel"
            role="region"
            aria-labelledby="${t=>t.id}"
        >
            <slot></slot>
        </div>
`}({collapsedIcon:x.qy`
        <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
            class="collapsed-icon"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M16.22 3H3.78a.78.78 0 00-.78.78v12.44c0 .43.35.78.78.78h12.44c.43 0 .78-.35.78-.78V3.78a.78.78 0 00-.78-.78zM3.78 2h12.44C17.2 2 18 2.8 18 3.78v12.44c0 .98-.8 1.78-1.78 1.78H3.78C2.8 18 2 17.2 2 16.22V3.78C2 2.8 2.8 2 3.78 2zM11 9h3v2h-3v3H9v-3H6V9h3V6h2v3z"
            />
        </svg>
    `,expandedIcon:x.qy`
        <svg
            width="20"
            height="20"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
            class="expanded-icon"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M3.78 3h12.44c.43 0 .78.35.78.78v12.44c0 .43-.35.78-.78.78H3.78a.78.78 0 01-.78-.78V3.78c0-.43.35-.78.78-.78zm12.44-1H3.78C2.8 2 2 2.8 2 3.78v12.44C2 17.2 2.8 18 3.78 18h12.44c.98 0 1.78-.8 1.78-1.78V3.78C18 2.8 17.2 2 16.22 2zM14 9H6v2h8V9z"
            />
        </svg>
    `}),S=o.k.compose({name:`${n.c.prefix}-accordion-item`,template:C,styles:$})},54750(t,e,i){i.d(e,{R(){return p}});var o=i(22131),n=i(74849),a=i(37998),s=i(57416),r=i(41123),l=i(95239),c=i(7896),d=i(26920),h=i(48751);const p=n.A`
    :host {
        --elevation: 11;
        position: relative;
        contain: layout;
        overflow: visible;
        height: 0;
        width: 0;
        z-index: 10000;
    }

    .tooltip {
        box-sizing: border-box;
        border-radius: calc(${s.Pb} * 1px);
        border: calc(${d.XA} * 1px) solid transparent;
        background: ${l.p};
        color: ${h.l};
        padding: 4px 12px;
        height: fit-content;
        width: fit-content;
        font-family: ${c.O};
        font-size: ${r.K};
        line-height: ${r.Z};
        white-space: nowrap;
        ${a.ET}
    }

    fluent-anchored-region {
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: visible;
        flex-direction: row;
    }

    fluent-anchored-region.right,
    fluent-anchored-region.left {
        flex-direction: column;
    }

    fluent-anchored-region.top .tooltip::after,
    fluent-anchored-region.bottom .tooltip::after,
    fluent-anchored-region.left .tooltip::after,
    fluent-anchored-region.right .tooltip::after {
        content: "";
        width: 12px;
        height: 12px;
        background: ${l.p};
        border-radius: calc(${s.Pb} * 1px);
        position: absolute;
    }

    fluent-anchored-region.top .tooltip::after {
        transform: rotate(45deg) translateX(-50%);
        bottom: 4px;
        left: 50%;
    }

    fluent-anchored-region.top .tooltip {
        margin-bottom: 12px;
    }

    fluent-anchored-region.bottom .tooltip::after {
        transform: rotate(45deg) translateX(-50%);
        top: 12px;
        left: 50%;
    }

    fluent-anchored-region.bottom .tooltip {
        margin-top: 12px;
    }

    fluent-anchored-region.left .tooltip::after {
        transform: rotate(45deg) translateY(-50%);
        top: 50%;
        right: 12px;
    }

    fluent-anchored-region.left .tooltip {
        margin-right: 12px;
    }

    fluent-anchored-region.right .tooltip::after {
        transform: rotate(45deg) translateY(-50%);
        top: 50%;
        left: 4px;
    }

    fluent-anchored-region.right .tooltip {
        margin-left: 12px;
    }
`.withBehaviors((0,o.mr)(n.A`
            :host([disabled]) {
                opacity: 1;
            }
            fluent-anchored-region.top .tooltip::after,
            fluent-anchored-region.bottom .tooltip::after,
            fluent-anchored-region.left .tooltip::after,
            fluent-anchored-region.right .tooltip::after {
                content: "";
                width: unset;
                height: unset;
            }
        `))},58661(t,e,i){i.d(e,{m(){return R}});var o=i(37180),n=i(56911),a=i(38493),s=i(60815),r=i(76881),l=i(88458),c=i(92011),d=i(56863);class h extends c.L{}class p extends((0,d.rf)(h)){constructor(){super(...arguments),this.proxy=document.createElement("textarea")}}const u="none";class g extends p{constructor(){super(...arguments),this.resize=u,this.cols=20,this.handleTextInput=()=>{this.value=this.control.value}}readOnlyChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.readOnly=this.readOnly)}autofocusChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.autofocus=this.autofocus)}listChanged(){this.proxy instanceof HTMLTextAreaElement&&this.proxy.setAttribute("list",this.list)}maxlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.maxLength=this.maxlength)}minlengthChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.minLength=this.minlength)}spellcheckChanged(){this.proxy instanceof HTMLTextAreaElement&&(this.proxy.spellcheck=this.spellcheck)}select(){this.control.select(),this.$emit("select")}handleChange(){this.$emit("change")}validate(){super.validate(this.control)}}(0,n.Cg)([(0,a.CF)({mode:"boolean"}),(0,n.Sn)("design:type",Boolean)],g.prototype,"readOnly",void 0),(0,n.Cg)([a.CF,(0,n.Sn)("design:type",String)],g.prototype,"resize",void 0),(0,n.Cg)([(0,a.CF)({mode:"boolean"}),(0,n.Sn)("design:type",Boolean)],g.prototype,"autofocus",void 0),(0,n.Cg)([(0,a.CF)({attribute:"form"}),(0,n.Sn)("design:type",String)],g.prototype,"formId",void 0),(0,n.Cg)([a.CF,(0,n.Sn)("design:type",String)],g.prototype,"list",void 0),(0,n.Cg)([(0,a.CF)({converter:a.R$}),(0,n.Sn)("design:type",Number)],g.prototype,"maxlength",void 0),(0,n.Cg)([(0,a.CF)({converter:a.R$}),(0,n.Sn)("design:type",Number)],g.prototype,"minlength",void 0),(0,n.Cg)([a.CF,(0,n.Sn)("design:type",String)],g.prototype,"name",void 0),(0,n.Cg)([a.CF,(0,n.Sn)("design:type",String)],g.prototype,"placeholder",void 0),(0,n.Cg)([(0,a.CF)({converter:a.R$,mode:"fromView"}),(0,n.Sn)("design:type",Number)],g.prototype,"cols",void 0),(0,n.Cg)([(0,a.CF)({converter:a.R$,mode:"fromView"}),(0,n.Sn)("design:type",Number)],g.prototype,"rows",void 0),(0,n.Cg)([(0,a.CF)({mode:"boolean"}),(0,n.Sn)("design:type",Boolean)],g.prototype,"spellcheck",void 0),(0,n.Cg)([s.sH,(0,n.Sn)("design:type",Array)],g.prototype,"defaultSlottedNodes",void 0),(0,l.X)(g,r.gs);class v extends g{appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="outline")}}(0,n.Cg)([a.CF,(0,n.Sn)("design:type",String)],v.prototype,"appearance",void 0);var b=i(74849),f=i(22131),m=i(50882),$=i(64187),x=i(73477),w=i(60993),y=i(61484),k=i(48196),C=i(17767),S=i(37302),D=i(7896),T=i(48751),A=i(46203),I=i(57416),z=i(26920),E=i(36452),M=i(41123),B=i(74838),O=i(14996),P=i(79288);const F=b.A`
    :host([appearance="filled"]) .control {
        background: ${S.F7};
        border-color: transparent;
    }

    :host([appearance="filled"]:hover:not([disabled])) .control {
        background: ${S.Xt};
        border-color: transparent;
    }

    :host([appearance="filled"]:focus-within:not([disabled])) .control {
        border-color: transparent;
        box-shadow: none;
    }
    ${y.p}
`.withBehaviors((0,f.mr)(b.A`
            :host([appearance="filled"]:hover:not([disabled])) .control,
            :host([appearance="filled"]:focus-within:not([disabled])) .control {
                background: ${m.A.Field};
                border-color: ${m.A.FieldText};
            }
            :host([appearance="filled"]:not([disabled]):active)::after,
            :host(
                    [appearance="filled"]:not([disabled]):focus-within:not(:active)
                )::after {
                border-bottom-color: ${m.A.Highlight};
            }
        `)),N=b.A`
    ${(0,$.V)("inline-flex")} :host {
        font-family: ${D.O};
        outline: none;
        user-select: none;
        position: relative;
        flex-direction: column;
        vertical-align: bottom;
    }

    .control {
        box-sizing: border-box;
        position: relative;
        color: ${T.l};
        background: ${A.le};
        border-radius: calc(${I.Pb} * 1px);
        border: calc(${z.XA} * 1px) solid ${E.I2};
        height: calc(${k.D} * 2px);
        font: inherit;
        font-size: ${M.K};
        line-height: ${M.Z};
        padding: calc(${B.vR} * 1.5px) calc(${B.vR} * 2px + 1px);
        width: 100%;
        resize: none;
    }

    .control:hover:enabled {
        background: ${A.jM};
        border-color: ${E.mb};
    }

    .control:hover,
    .control:${x.N},
    .control:disabled,
    .control:active {
        outline: none;
    }

    :host(:focus-within) .control {
        border-color: ${O.WN};
        box-shadow: 0 0 0 1px ${O.WN} inset;
    }

    :host(.resize-both) .control {
        resize: both;
    }

    :host(.resize-horizontal) .control {
        resize: horizontal;
    }

    :host(.resize-vertical) .control {
        resize: vertical;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        display: block;
        color: ${T.l};
        cursor: pointer;
        $font-size: ${M.K};
        line-height: ${M.Z};
        margin-bottom: 4px;
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${w.Z};
    }
    :host([disabled]) {
        opacity: ${P.q};
    }
`.withBehaviors((0,C.f)("filled",F),(0,f.mr)(b.A`
            :host([disabled]) {
                opacity: 1;
            }
            ::placeholder,
            ::-webkit-input-placeholder {
                color: ${m.A.FieldText};
            }
            :host([disabled]) ::placeholder,
            :host([disabled]) ::-webkit-input-placeholder,
            :host([disabled]) .label {
                color: ${m.A.GrayText};
            }
        `));var L=i(96950),U=i(82774),H=i(60402);const j=L.qy`
        <label
            part="label"
            for="control"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot ${(0,U.e)("defaultSlottedNodes")}></slot>
        </label>
        <textarea
            part="control"
            class="control"
            id="control"
            ?autofocus="${t=>t.autofocus}"
            cols="${t=>t.cols}"
            ?disabled="${t=>t.disabled}"
            form="${t=>t.form}"
            list="${t=>t.list}"
            maxlength="${t=>t.maxlength}"
            minlength="${t=>t.minlength}"
            name="${t=>t.name}"
            placeholder="${t=>t.placeholder}"
            ?readonly="${t=>t.readOnly}"
            ?required="${t=>t.required}"
            rows="${t=>t.rows}"
            ?spellcheck="${t=>t.spellcheck}"
            :value="${t=>t.value}"
            aria-atomic="${t=>t.ariaAtomic}"
            aria-busy="${t=>t.ariaBusy}"
            aria-controls="${t=>t.ariaControls}"
            aria-current="${t=>t.ariaCurrent}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-details="${t=>t.ariaDetails}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-errormessage="${t=>t.ariaErrormessage}"
            aria-flowto="${t=>t.ariaFlowto}"
            aria-haspopup="${t=>t.ariaHaspopup}"
            aria-hidden="${t=>t.ariaHidden}"
            aria-invalid="${t=>t.ariaInvalid}"
            aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
            aria-label="${t=>t.ariaLabel}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-live="${t=>t.ariaLive}"
            aria-owns="${t=>t.ariaOwns}"
            aria-relevant="${t=>t.ariaRelevant}"
            aria-roledescription="${t=>t.ariaRoledescription}"
            @input="${(t,e)=>t.handleTextInput()}"
            @change="${t=>t.handleChange()}"
            ${(0,H.K)("control")}
        ></textarea>
    `,R=v.compose({name:`${o.c.prefix}-text-area`,template:j,styles:N,shadowOptions:{delegatesFocus:!0}})},68017(t,e,i){i.d(e,{n(){return y}});var o=i(56911),n=i(92011),a=i(26633),s=i(38493);class r extends a.b{constructor(){super(...arguments),this.headinglevel=2,this.dismiss=()=>{this.$emit("action-dialog-dismiss")}}}(0,o.Cg)([(0,s.CF)({attribute:"headline"})],r.prototype,"headline",void 0);var l=i(57416),c=i(71157),d=i(62198),h=i(74849),p=i(64187);const u=h.A`
    ${(0,p.V)("flex")} :host{--dialog-height:var(--action-dialog-height,auto);--dialog-width:var(--action-dialog-width,auto);--button-border-radius:20px;--button-min-width:160px;--control-corner-radius:2px;--dialog-padding:24px;--space-above-title:20px;--space-between-buttons:8px;z-index:var(--action-dialog-z-index,0)}.body{margin:0 var(--dialog-padding) var(--dialog-padding) var(--dialog-padding)}.content{display:flex;flex-direction:column}.controls{display:grid;grid-template-columns:auto auto;grid-gap:var(--space-between-buttons);justify-content:center}.heading{display:grid;grid-template-columns:1fr auto;grid-template-rows:1;position:relative;width:100%;border-top-left-radius:calc(${l.JU} * 1px);
        border-top-right-radius: calc(${l.JU} * 1px);overflow:hidden}.heading span{font-size:${c.T};
        font-weight: 600;
        line-height: ${d.a};
        margin-inline-start: var(--dialog-padding);
        margin-top: var(--space-above-title);
    }
`;var g=i(96950),v=i(69259),b=i(60402);const f=g.qy`<div class="positioning-region" part="positioning-region">${(0,v.z)(t=>t.modal,g.qy`<div class="overlay" part="overlay" role="presentation" tabindex="-1" @click="${t=>t.dismiss()}"></div>`)}<div role="dialog" class="control" part="control" aria-modal="${t=>t.modal}" aria-describedby="${t=>t.ariaDescribedby}" aria-labelledby="${t=>t.ariaLabelledby}" aria-label="${t=>t.ariaLabel}" ${(0,b.K)("dialog")}><div class="heading" part="heading"><span role="heading" aria-level=${t=>t.headinglevel}>${t=>t.headline}</span><slot name="close-button"></slot></div><div class="body" part="body"><div class="content" part="content"><slot></slot></div><div class="controls" part="controls"><slot name="action-button"></slot><slot name="cancel-button"></slot></div></div></div></div>`;var m=i(37998),$=i(95239),x=i(26920);const w=h.A` :host([hidden]){display:none}:host{--elevation:14;--dialog-height:480px;--dialog-width:640px;display:block}.overlay{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.3);touch-action:none}.positioning-region{display:flex;justify-content:center;position:fixed;top:0;bottom:0;left:0;right:0;overflow:auto}.control{${m.ET}
    margin-top: auto;
    margin-bottom: auto;
    border-radius: calc(${l.JU} * 1px);
    width: var(--dialog-width);
    height: var(--dialog-height);
    background: ${$.p};
    z-index: 1;
    border: calc(${x.XA} * 2px) solid transparent;
    position: relative;
  }
`;let y=class extends r{};y=(0,o.Cg)([(0,n.E)({name:"msn-action-dialog",template:f,styles:[w,u],shadowOptions:{delegatesFocus:!0}})],y)},87656(t,e,i){i.d(e,{g(){return n}});var o=i(7813);function n(t){if("string"==typeof t)return t;if("function"==typeof t&&!(t=o.I.getByType(t)))throw new Error("Missing FASTElement definition.");return t.name}},93140(t,e,i){var o,n,a,s;i.d(e,{G4(){return o},Ij(){return s},P2(){return a},vO(){return r}}),function(t){t.Ocv="Ocv",t.Ods="Ods"}(o||(o={})),function(t){t.NotConfigured="Not Configured",t.Enabled="Enabled",t.Disabled="Disabled"}(n||(n={})),function(t){t[t.Undefined=0]="Undefined",t[t.MinorWithoutParentalConsent=1]="MinorWithoutParentalConsent",t[t.MinorWithParentalConsent=2]="MinorWithParentalConsent",t[t.Adult=3]="Adult",t[t.NotAdult=4]="NotAdult",t[t.MinorNoParentalConsentRequired=5]="MinorNoParentalConsentRequired"}(a||(a={})),function(t){t[t.feedbackDefault=2224]="feedbackDefault",t[t.windowsFeed=2475]="windowsFeed",t[t.edgeChromium=2231]="edgeChromium"}(s||(s={}));class r{constructor(){this.manifestType="Sas",this.appId=s.feedbackDefault,this.source="Client",this.type="Idea"}}},96789(t,e,i){i.d(e,{k(){return l}});var o=i(56911),n=i(92011),a=i(38493),s=i(35106),r=i(88458);class l extends n.L{constructor(){super(...arguments),this.headinglevel=2,this.expanded=!1,this.clickHandler=t=>{this.expanded=!this.expanded,this.change()},this.change=()=>{this.$emit("change")}}}(0,o.Cg)([(0,a.CF)({attribute:"heading-level",mode:"fromView",converter:a.R$}),(0,o.Sn)("design:type",Number)],l.prototype,"headinglevel",void 0),(0,o.Cg)([(0,a.CF)({mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],l.prototype,"expanded",void 0),(0,o.Cg)([a.CF,(0,o.Sn)("design:type",String)],l.prototype,"id",void 0),(0,r.X)(l,s.qw)}}]);