"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["quiz-card"],{4968(e,i,t){t.d(i,{f(){return l}});var o=t(64187),r=t(74849),s=t(42792),a=t(99657),n=t(36452);const l=r.A.partial`position: relative; z-index: ${a.D};`;r.A`
    ${s.e}
    ${s.nH}

    ${(0,o.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${n.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${n.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${n.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(s.kc)},7014(e,i,t){t.d(i,{m(){return B}});var o=t(56911),r=t(38493),s=t(60815),a=t(55230),n=t(92011),l=t(56863);class h extends n.L{}class d extends((0,l.dx)(h)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class c extends d{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(!this.readOnly)switch(e.key){case a.Mm:case a.gG:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,i){super.checkedChanged(e,i),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,o.Cg)([(0,r.CF)({attribute:"readonly",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],c.prototype,"readOnly",void 0),(0,o.Cg)([s.sH,(0,o.Sn)("design:type",Array)],c.prototype,"defaultSlottedNodes",void 0);var u=t(37180),p=t(74849),g=t(64187),b=t(60993),m=t(73477),v=t(22131),A=t(50882),k=t(48196),w=t(86856),y=t(7896),f=t(74838),C=t(79288),x=t(46203),T=t(26920),Q=t(43774),I=t(95239),W=t(14996),z=t(48751),S=t(41123),q=t(74089),$=t(4283);const R=p.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,g.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${y.O};
        margin: calc(${f.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${C.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${b.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${k.D} / 2) + ${f.vR}) * 2px);
        height: calc(((${k.D} / 2) + ${f.vR}) * 1px);
        background: ${x.le};
        border-radius: calc(${k.D} * 1px);
        border: calc(${T.XA} * 1px) solid ${Q.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${x.jM};
        border-color: ${Q.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${x.RS};
        border-color: ${Q.p4};
    }

    :host(:${m.N}) .switch {
        box-shadow: 0 0 0 2px ${I.p}, 0 0 0 4px ${W.WN};
        border-color: ${W.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${k.D} - (${f.vR} * 5.5)) * 1px);
        width: calc((${k.D} - (${f.vR} * 5.5)) * 1px);
        top: calc(${f.vR} * 1px);
        background: ${z.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${z.l};
        cursor: pointer;
        font-size: ${S.K};
        line-height: ${S.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${z.l};
        font-size: ${S.K};
        line-height: ${S.Z};
        margin-inline-end: calc(${f.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${f.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${q.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${$.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${$.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${q.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${$.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${q.J_};
    }

    :host([aria-checked="true"]:${m.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${I.p}, 0 0 0 4px ${W.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new w.t(p.A`
            .checked-indicator {
                left: calc(${f.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${k.D} / 2) + ${f.vR}) + ${f.vR}) * 1px
                );
            }
        `,p.A`
            .checked-indicator {
                right: calc(${f.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${k.D} / 2) + ${f.vR}) + ${f.vR}) * 1px
                );
            }
        `),(0,v.mr)(p.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${A.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${A.A.Field};
                border-color: ${A.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${A.A.HighlightText};
                border-color: ${A.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${A.A.Highlight};
                border-color: ${A.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${A.A.HighlightText};
                border-color: ${A.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${A.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${A.A.Highlight};
            }
            :host(:${m.N}) .switch {
                border-color: ${A.A.Highlight};
                box-shadow: 0 0 0 2px ${A.A.Field},
                    0 0 0 4px ${A.A.FieldText};
            }
            :host([aria-checked="true"]:${m.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${A.A.Field},
                    0 0 0 4px ${A.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${A.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${A.A.Field};
                border-color: ${A.A.GrayText};
            }
            .status-message,
            .label {
                color: ${A.A.FieldText};
            }
        `));var O=t(96950),D=t(82774),E=t(18893);const M=function(e={}){return O.qy`
        <template
            role="switch"
            aria-checked="${e=>e.checked}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            tabindex="${e=>e.disabled?null:0}"
            @keypress="${(e,i)=>e.keypressHandler(i.event)}"
            @click="${(e,i)=>e.clickHandler(i.event)}"
        >
            <label
                part="label"
                class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,D.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,E.R)(e.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:O.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),B=class extends c{}.compose({name:`${u.c.prefix}-switch`,template:M,styles:R})},23268(e,i,t){t.r(i),t.d(i,{QuizCard(){return S},QuizCardStyles(){return j},QuizCardTemplate(){return V},QuizCardTemplate1(){return Y},QuizCardTemplateMedium(){return L},QuizCardTemplateSmall(){return U},ToolingInfo(){return Z}});var o=t(7014),r=t(37180),s=t(7574),a=t(56911),n=t(85349),l=t(60815),h=t(38493),d=t(55230),c=t(12680),u=t(33477),p=t(58792),g=t(29658);const b=`${(0,p.rA)().StaticsUrl}latest/icons-wc/icons/QuizCardHeaderIcon.svg`,m=e=>({id:e.id,gridArea:"",childTemplateType:"",cardSize:e.cardSize,headerData:{headerLogo:b,title:e.quizData?e.quizData.Quizzes[0].BannerInfo.Title:"Quiz",titleNavigationLink:"https://www.bing.com/search?q=bing+quizzes&form=BTNTPQ",actionMenuData:{hideCardCallback:e.hideCardCallback,moreSettingsPersonalizeCallback:e.goToPersonalizeSettingsCallback}},metadata:{cardType:g.s.QuizCard}});var v=t(96950);const A=v.qy`
    <svg width="60" height="117" viewBox="0 0 60 117" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0 4C0 1.79086 1.79086 0 4 0H56C58.2091 0 60 1.79086 60 4V112.722C60 115.877 56.519 117.79 53.856 116.099L32.144 102.314C30.8354 101.483 29.1646 101.483 27.856 102.314L6.14404 116.099C3.48096 117.79 0 115.877 0 112.722V4Z" fill="#4464FF"/>
</svg>
    `,k="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAA2CAYAAACMRWrdAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAA4LSURBVHgB7Vp7jJ1FFT8z3+veu3e3u9uWtralW0pLWxBaQCmvKo8KqY0BBIkEjAWUQoICIopoWSwLESOCYBRQRImRRDRQDAYKtCkkQBFQ+kJa2hWkD/vadu/z+76Z8ZyZ+e69W7vde2/3D0N6NrPfe+b85jzmnDMX4DAdpv8LYkO9sKB7+SihOo/mseQALt4pmg+5qwR3FHNAefZdCY50ZBSVd21d/9cH5pehDrro9tcmMCc1uizBczhjUYQ3sUNHAJN6TLqmcV1wuGAMWPz04mNX4Q0FzQKb8733b3c8ZzHj+Me4eRu7U9h99cv9usBnvhLS4+K3Qd+/v7n0njP6D9T33Fv/fpHyR/wEHLfL9Gf6ZIqB4si+AnuPGQjcjEWXKc57g+KeBc8snrp2MN7dwR6cceu6K2LH6/Y0IFbToIqFJReKhoSEF6nnFha6Y6bk8NY39u97znc3d4Wu82TguDhfpl/DP/7jpnO6rwEnk2fP6RAz1tXSOupRvDxlMP75YA/y0j83zR1wEJiDvbl4dO3Rw8881MHae+Yd0zwNkxHA6y/tWXfc/n3HnC3JeB7Tfei+uB7HrYyD13jfrW3JOGDe5a776ct71o1rGJhC9eYKtEpwVA8655JpVTGNrqHyTtIQjVYdhsdSqED6nffX9nv6TW99wXfdy2kiOL7IaQpsP1w5Ziw9Dtfj0LX+S8YE867AtjsXtjYMjItok8CvaVBqVYbJyFTlGuzz/RvgezJWUI7h7AVLNnwu6TcKRt7Xgpqg31FsQD+6X+sSGJ4ze01j6n71e6iieC6ieMezd896bzD+B7WxNlm4vxymbvB83m5GAttzjZ0d0C+p6gNkrBziILzloZO+vvTYqHXGZWnuTmbJd8Q4s52rxCEl9+ycV8ZSFVukVgpLD8BBaFCJrbhvdp8s53rCWILCmVfSyj+RFp3L/Zu0x+Q5vo5HEUOXapt+r+f5t/mJl5MWnZWukZaVmJakqs6RrL5HfIhY9Ka3rX0YDkJDrmOn3rBpZSYIzuSOdfc13gkqXktVZzs5aD7NtcTjzjCEDtejxcp8z//X45HFJVIZ4H5rxpKohyzcfd6yO6c+DwchF4YgVdr7lRLr+Fva80eyxHLJtddOyQBQNfqJ5wQuJySktDe1kkAmSZJ24bLYzIKhknVSP1ZV7HoEBaEM71g5BCgiPtQLr/1ydm8scheEYSlSAm/EYNRMN2nUj47JdaKi9jzGYzGOIUtDJeqWqG6i1qRiwqp7ovKVI40H+llczv+ar3zoTqiDhlTFhOZcv+7cgLf82XPd1topYTXSqvxXqiK4PQgqzTmkHV5VY2AHWORrggCVXEMl8lCq8Fz86qMLVqzojmE4gRHNvW7VacwZ9aTr+OO0OVRsC7TaKFVtZFcRtgLaxEjXNarEuHWCNcMyZqMWptXRPOMV1rS5xuFj4s1ffa1eUA0D0+CueXsqd9qfZ67TxRIZESjUGaGoocrgkUB57j6Y09kLE7K7VDbIa8bzUQv7IDcONu+dBPuiNh1F6DhUw6t1UFZSMvzhiz+ddDs0SA0DI5p35SufiPxRiyXzriFQMVATEKMdjE1vhXnjX4Ezxr4FUzu2YNSoDOOcmK5tDP6552h4b+9ktXTjmWxLbjyCxMgDmwapxDam8lct+9nMZ6EJagpYQvOvffuynMr09EvRNTm7Ca6c9iScMuYfmm8HgRg8JBFiVt+sgKoCxGcYiSzrPRkeX3M+7MofoTwVP9xZ3PGDP/5m7g5okg4JGNFNN9017ZPj9jw9b9JLx3g81tG647iohinE4WvGGVRVywQZxjYVOUpacAgcvYcAV285epn3worPn/zwmxEcAh0SsPW/mN7lBu5TLRl2AgHyHA+CoAWBBVAbd7HEbZNjIXNyHduDXRNdzAQCVwMjKUrJV8el8oLOeX/5AJqkpoGte3DGpEyrs9x12WTSrHS6BQK/1Xg2CmAjjBBoSRa8GmVIsx4pEZmoycUFKnAgyckIHHaCLzqkwpvLJX52x1lP9EITNOQCfSD60y3HTwhS/EXO1GQCkc2MgFTQZqKHSACPiNm0sS2XVA7BYHiuMN/H6gEwD1MiB3MxgSD60JPmIr0g81IErFBOYt7Jriue37P8gnZogpoCNu1IcS9q0xTSpBHZTvC9DKYVyHBMHjCNzFMVhNQP/WUc0TqEpxFgOQQDWGoxqltEuRG4KDEn4hDtKIAKcVLCGFiuoD9HqU11XO9xaIIaBrb2gZkLs2l1CS3C2VQb2lWA6iaMDaGz0DZkM06FYAlIhLkLtZAaBsNRhEDxmbLRsuNhduwFEO4qgSoTOJJcSY+H3nXBrmUXL4QGqSFgv1t02hEpH7pJT1J+CjLprInzKH7ixmGY5FAav4D5ilOOIEBA6XIZMggqhUB9ui+FiVash3QcXNB9Hwo782iDEnixiFF8pDPnVIr3NKqSDQGbNWPvJejDjiTLb820mciAIlQnZdN3m6+gNHh/PziFIgKQ2vZWrk/BU6sygPyDi5PhIFieL2kV1p6Tljk0SZ/A7bKqmMvricOIZByTwaJGeG0IWMqR15Ew0n4aowTyCkKrH9UnVAIqRlXa22/U01au9uQ5LF2VhZVrA6xT2CiEPCFNQLGkj+QtGUqPwKkI0xMETX0xSsGxb4xgrm6E17qBrew5/kSHwUzitCXVYuuLxLYpl3Lt4hFUf86m8ZZ5lNaaD3wdB1K96fUNvo0wbdBL3yLzJG1tnnjL8x0o7s2b/BVVkqSGY0/Z/syFp9bLb93ARgTx+SQVClo9zIS1HXGvmmMSE4WCYbmmHkjnaz70cWUyf+9vteuWbkl4BVrC5EyYvs20MmAlGKs/GNBr5yQhHThz6+V3yAw6IcR0Inm+VCow+RIn4/dMlYpAoisnxSviglwOTRpCH5HqbdrmgUvlNLy1cYsLG7B1tqpKgSYdKMgE5lpXp/BrF3WyuC8HLe2tRh19j5zKccMOLHBUF0nF5a4eXOdWilVLZLg2vbs1A394uRWdobEZqYsvWDYVTqUfH73ng0+RNIR9R6IpCbj2QgWzppkZJGBYx9fZt9Z2kiYGlbiuf6pefusGJgWfwjB6IFU0dQtuM91qhSnwBC4DWOMoYHgUJtmyM6AfcjoZ2mSwOxmlsIjuPw8j202orGS1tigiYUsEQpcapJCjoU6q28Y4V74+JhXfJMxMSmQUA40RsOi8PugYid4sUAeNRMle86UcjGwrwPevYjBxjK3VV8pwKHU0NL3MiQq4NAw7MKEKXBqfYUtJtlprK7/MuPb2rIRvXbAXzjkJvVkgBu0vX87BmbMiuG0h09KCxKFY0KpSY7S2R+uhlCWok+oGhuXqnfqoK1MWTJJj6Z4G7sqcPasM40aKagmtti+MOjraJFx8Dgws5uhIzIRi2jYxMTUlc6W9Jm6YbYQ6qX6JAXuDYd2c9F7Pa2wW4GoCWQVGKrU778LWXYkdDiQqFezZx6AQsgGTQaGUshXlGJ2Rw6v2Sc9kKDdBnVQ3MFxg15AXpCAWixsYqFo1S+psygLTJQEOvdsdvYGgHzEBEStBqEpY6In12kZZ9utrWDUKoaNer4T2lOWwrCOcpKyuVVHJd+rlt25gW/r5y6RVVMePyVsRLhy8suMIpo6RnL690TU7I5iDtbVHsOgiATd+OYJsCwIUJV24eec9Zd9nRv0o6kcQAhNRjtLCGqZRCGWKsv0l55l6+a0b2GfvXv1qFDsbKCMu5co23CnrbVVNxGFsog5aibbupiRTwemzI7jh0hiOGi9h/BEAN1+hYPb0CMK4DB9uV5X3IWeierK/YqkE7a3tJhWifTSy61iuG7vwhdX18lv3OkZUKPNH0mm4p1wUkGmROvpTyAS4fmWnhGEACxjrffEzkfZsMycJm3cxfZ1OMbhsPsCUiQo6R5jhGWYCElMZqktSrsYxxwswP0tSaaI4kvc1wGpj0X3M2x+JY2cLRfPFfaaIxEsUfceVgFdHSbjbNx0BzeiS9r6N6Cl0t3Z4ygkuTEUpAoJSOqPGuiRm2jnsr7OtwwxogaFD6e0LC79vgNXGgM3uXtFXlt4tFKnHZZzdvDBej7JdFVcCWmKGFzBiD6k0IKtLQuIg0QExzAIoZ6NkVIPCYx5jwtEdY7R9abJrNYryjvHXvFmABqipKtVHS+Y8kebsUo6SSHfg1neKmWKNjx4RvR3oGE8lsw1kLHqLt7JhoT2cjiwEgioj0BJWtUZkR4Hr6kIjJLOBWv9Y29UrFkKD1FQxpyXvXhtJZwNJK+zDQDYPOtnk9JOVEkYcKqQ4CLTrNJvNurZPQJTZh0LvZxxIvlhA5xlg9DHWgFLVtQ+D6E3r/1O4GZqgpiRGtL57TtdYx1/uctalU0gsf/BWVRNClrQUUe+gssFAwHCtEuT99O95PCzbZW0tkn49YDIG+g6nYTOGAmelr37pX9AENQ2M6KPvnHtkyhNL02l2gv4FBk44x1hRpaVO84lZ7RHR/hQ1nXg6pt6YrH8aEN7TqY3SNUjc3Hilv+h8afSNz22FJumQgCWU6573I9dh3+b0w6SkJIDgMB8B5Qm7vVtDBCamyAQlFNsVx6E1DDeNpLjzx7tPv6O7u1vCIdCwACPq6z7nqIB7Pa7D0alon67v6wVcb7ZYNVXVzQmzp42AmIpEpJbv6IObJy55tu5F+GA0bMASKnaf3yWEe73ns7lYLT5Z8f1+r5E0VM5IqjfQqF7c2Vf4+cSelz6CYaRhB1ZLm786f+yEY/zp/WWRRacx1vPIOUA/bjZt80rs3exdS7fDYTpMH2/6L4cr+Tw4HYB1AAAAAElFTkSuQmCC",w="QuizCard_Customization_AddRemoveClicked",y="QuizCard_Customization_HideCardClicked",f={answerclick:{name:"quiz.answer",action:n.EG.Click,behavior:n.MS.Show,type:n.MJ.Section},learmoreclick:{name:"quiz.learnmore",action:n.EG.Click,behavior:n.MS.Navigate,type:n.MJ.Section},morequizzesclick:{name:"quiz.morequizzes",action:n.EG.Click,behavior:n.MS.Navigate,type:n.MJ.Section},linkablequizzesclick:{name:"quiz.linkablequizzes",action:n.EG.Click,behavior:n.MS.Navigate,type:n.MJ.Section},playonbingclick:{name:"quiz.playquiz",action:n.EG.Click,behavior:n.MS.Navigate,type:n.MJ.Section},nextquestionclick:{name:"quiz.nextquestion",action:n.EG.Click,behavior:n.MS.More,type:n.MJ.Section},getscoreclick:{name:"quiz.getscore",action:n.EG.Click,behavior:n.MS.Show,type:n.MJ.Section},summaryShown:{name:"quiz.summaryShown",action:n.EG.View,behavior:n.MS.Show,type:n.MJ.Section}};class C{constructor(e){this.telemetryObject=e}getSectionTelemetryTag(e,i){return e in f?this.getTelemetryTag(f[e]):this.getTelemetryTag({name:i||`quiz.${e}`,action:n.EG.View,behavior:n.MS.Show,type:n.MJ.Section})}getTelemetryTag(e){return this.telemetryObject.addOrUpdateChild(e).getMetadataTag()}}var x,T=t(48566),Q=t(39671),I=t(31525),W=t(71398),z=t(19359);let S=x=class extends Q.U{constructor(){super(...arguments),this.questions=[],this.totalQuestions=0,this.totalCorrectAnswers=0,this.currentQuestionNumber=0,this.enableNextButton=!1,this.enablePlayOnBing=!1,this.enableGetYourScore=!1,this.enableLearnMore=!1,this.showQuizPage=!1,this.showSummaryPage=!1,this.participatedInQuiz=!1,this.currentQuestionAlreadyAnswered=!1,this.isActionMenuOpen=!1,this.actionsMenuProps=[],this.enableMockResponse="false",this.moreSettingAction=()=>{this.toggleActionMenu(!1,null),this.goToPersonalizeSettingsCallback&&this.goToPersonalizeSettingsCallback(),this.$emit("goToPersonalizeSettingsCallback")},this.hideCardCallback=async()=>{let e=!1;const i=[{cardType:g.s.QuizCard,enabled:!1}];try{e=await W.d.updateSegmentCardsEnableStatus(i)}catch(i){e=!1}return e&&(this.refreshSDCardSection?this.refreshSDCardSection():this.$emit("refreshSDCardSection"),this.toggleActionMenu(!1,null)),e},this.onOutsideClick=e=>{var i;e&&e.target&&e.target instanceof x||e&&e.path&&e.path.length>0&&null!==(i=this.actionsMenuButtonElement)&&void 0!==i&&i.contains(e.path[0])||this.toggleActionMenu(!1,null)},this.onKeydown=e=>{e.keyCode.toString()===d.F9&&this.toggleActionMenu(!1,null)}}experienceConnected(){"true"===this.enableMockResponse&&(this.oneServiceQuizData='{"BowheadMetadata":{"PipelineTag":""},"Quizzes":[{"QuizCategory":null,"QuizId":"Books","Questions":[{"QuestionText":"Bring on the Empty Horses\' is the second part of whose autobiography?","AnswerExplanation":"","AnswerChoices":[{"DisplayText":"Richard Harris\'s","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Bring+on+the+Empty+Horses%27+is+the+second+part+of+whose+autobiography%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%220%22+WQCI%3A%220%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%220%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Roger Moore\'s","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Bring+on+the+Empty+Horses%27+is+the+second+part+of+whose+autobiography%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%220%22+WQCI%3A%221%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%220%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"David Niven\'s","IsCorrectAnswer":true,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Bring+on+the+Empty+Horses%27+is+the+second+part+of+whose+autobiography%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%220%22+WQCI%3A%222%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%221%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Dirk Bogarde\'s","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Bring+on+the+Empty+Horses%27+is+the+second+part+of+whose+autobiography%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%220%22+WQCI%3A%223%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%220%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"}],"QuestionId":"Books_1"},{"QuestionText":"According to his autobiography, which jockey was born lucky?","AnswerExplanation":"","AnswerChoices":[{"DisplayText":"John Francome","IsCorrectAnswer":true,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=According+to+his+autobiography%2C+which+jockey+was+born+lucky%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%221%22+WQCI%3A%220%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Fred Winter","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=According+to+his+autobiography%2C+which+jockey+was+born+lucky%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%221%22+WQCI%3A%221%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Dick Francis","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=According+to+his+autobiography%2C+which+jockey+was+born+lucky%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%221%22+WQCI%3A%222%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Peter Scudamore","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=According+to+his+autobiography%2C+which+jockey+was+born+lucky%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%221%22+WQCI%3A%223%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"}],"QuestionId":"Books_2"},{"QuestionText":"Who wrote a \'Testament of Youth\'?","AnswerExplanation":"","AnswerChoices":[{"DisplayText":"Roland Leighton","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Who+wrote+a+%27Testament+of+Youth%27%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%222%22+WQCI%3A%220%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Shirley Williams","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Who+wrote+a+%27Testament+of+Youth%27%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%222%22+WQCI%3A%221%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Vera Brittain","IsCorrectAnswer":true,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Who+wrote+a+%27Testament+of+Youth%27%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%222%22+WQCI%3A%222%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Winifred Holtby","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Who+wrote+a+%27Testament+of+Youth%27%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%222%22+WQCI%3A%223%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"}],"QuestionId":"Books_3"},{"QuestionText":"Songs My Mother Taught Me,\' published in 1995, is the autobiography of which actor?","AnswerExplanation":"","AnswerChoices":[{"DisplayText":"James Dean","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Songs+My+Mother+Taught+Me%2C%27+published+in+1995%2C+is+the+autobiography+of+which+actor%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%223%22+WQCI%3A%220%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Paul Newman","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Songs+My+Mother+Taught+Me%2C%27+published+in+1995%2C+is+the+autobiography+of+which+actor%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%223%22+WQCI%3A%221%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Marlon Brando","IsCorrectAnswer":true,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Songs+My+Mother+Taught+Me%2C%27+published+in+1995%2C+is+the+autobiography+of+which+actor%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%223%22+WQCI%3A%222%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Al Pacino","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Songs+My+Mother+Taught+Me%2C%27+published+in+1995%2C+is+the+autobiography+of+which+actor%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%223%22+WQCI%3A%223%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"}],"QuestionId":"Books_4"},{"QuestionText":"Which Dickens novel is considered an autobiography?","AnswerExplanation":"","AnswerChoices":[{"DisplayText":"Bleak House","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Which+Dickens+novel+is+considered+an+autobiography%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%224%22+WQCI%3A%220%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"Domby And Son","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Which+Dickens+novel+is+considered+an+autobiography%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%224%22+WQCI%3A%221%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"David Copperfield","IsCorrectAnswer":true,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Which+Dickens+novel+is+considered+an+autobiography%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%224%22+WQCI%3A%222%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"},{"DisplayText":"The Pickwick Papers","IsCorrectAnswer":false,"ChoiceImage":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"RequeryUrl":"/search?q=Which+Dickens+novel+is+considered+an+autobiography%3F&filters=dw_answerstobesuppressed%3A%22ConversationalSearch%22+IsConversation%3A%22True%22+WQOskey%3A%22Books%22+WQId%3A%2225%22+WQQI%3A%224%22+WQCI%3A%223%22+ShowTimesTaskPaneTrigger%3A%22false%22+WQSCORE%3A%22WQSCOREVALUE%22&FORM=CWQHYL&rnoreward=1&skipopalnative=true"}],"QuestionId":"Books_5"}],"QuizType":0,"BannerInfo":{"ImageInfo":{"DesktopThumbnailId":"","MobileThumbnailId":"","Attribution":""},"Title":"Book quiz","Description":null},"Attributes":{"tags":"","PromotionalQuizzes":"Bing homepage quiz,Cat quiz,Meditation quiz,News quiz"},"PromotionInfo":{"PromotionText":"","BingLandingUrl":"https://www.bing.com/search?q=Books quiz&filters=IsConversation:%22True%22+WQOskey:%22Books%22+WQId:%221%22"}}],"Status":{"Message":"Success","Code":204}}'),this.PopulateCardData()}PopulateCardData(){this.quizData||(this.quizContent=this.TransformToViewData(),this.questions=this.quizContent.quizQuestions,this.initializeQuizStatics(),this.setupTelemetryObjects(),this.superCardData=m(this)),this.setupTelemetryObjects(),this.superCardData=m(this),this.quizData&&this.questions.length>0&&(this.currentQuestionNumber=0,this.currentQuestion=this.questions[this.currentQuestionNumber],this.currentQuestionNumber++,this.enablePlayOnBing=!0)}TransformToViewData(){try{this.oneServiceQuizData&&this.oneServiceQuizData.length>0&&(this.quizData=JSON.parse(this.oneServiceQuizData),this.cardSize=this.cardSize??u.uE._1x_2y,this.isDynamicFeed=this.config.isDynamicFeed??!1,this.superCardData=m(this),this.showQuizPage=!0)}catch(e){this.showQuizPage=!0}const e=this.quizData,i=null==e?void 0:e.Quizzes[0];return{quizID:null==i?void 0:i.QuizId,quizType:null==i?void 0:i.QuizCategory,moreQuizzesOnBingLink:"https://www.bing.com/search?q=bing+quizzes&form=BTNTPQ",otherQuizzes:this.getOtherQuizzes(),playOnBingLink:null==i?void 0:i.PromotionInfo.BingLandingUrl,quizQuestions:this.getQuestions(i)}}oneServiceQuizDataChanged(e,i){i!==e&&(this.quizContent=this.TransformToViewData(),this.questions=this.quizContent.quizQuestions,this.initializeQuizStatics(),this.setupTelemetryObjects(),this.questions&&this.questions.length>0&&(this.currentQuestionNumber=0,this.currentQuestion=this.questions[this.currentQuestionNumber],this.currentQuestionNumber++,this.enablePlayOnBing=!0))}getOtherQuizzes(){const e=[];if(!this.quizData)return e;const i=this.quizData;if(!i.Quizzes[0].Attributes.PromotionalQuizzes)return e;for(const o of null===(t=i.Quizzes[0].Attributes)||void 0===t?void 0:t.PromotionalQuizzes.split(",")){var t;if(o&&o.length>0){const i={quizName:o,quizLink:T.Qf.Format("https://www.bing.com/search?q={quizname}&form=BTNTPQ",{quizname:o})};e.push(i)}}return e}getQuestions(e){const i=[];if(!e)return i;for(const t of e.Questions)i.push({questionID:t.QuestionId,correctAnswerReason:t.AnswerExplanation,questionText:t.QuestionText,LearnMoreLink:"",correctAnswerOption:0,options:this.loadOptions(t.AnswerChoices)});return i}loadOptions(e){const i=[];if(e.length>3)for(let i=0;i<e.length;i++)if(!e[i].IsCorrectAnswer){e.splice(i,1);break}const t=["A","B","C","D"];for(let o=0;o<e.length;o++){const r=e[o];r.optionNo=o,r.OptionLabel=t[o],r.Display=!0,i.push(r)}return i}getExperienceType(){return c.zHB}initializeQuizStatics(){this.totalQuestions=this.questions.length,this.totalCorrectAnswers=0}setupTelemetryObjects(){null!=this.telemetryObject&&(this.quizWCTelemetry||(this.quizWCTelemetry=new C(this.telemetryObject)),this.addRemoveCardTelemetryTags=this.getClickTelemetryTag(w,"Add or Remove cards"),this.hideCardTelemetryTag=this.getClickTelemetryTag(y,"Hide card"),this.playOnBingClickedTelemetryTags=this.quizWCTelemetry.getSectionTelemetryTag("playonbingclick",""),this.moreQuizzesClickedTelemetryTags=this.quizWCTelemetry.getSectionTelemetryTag("morequizzesclick",""),this.learnMoreTelemetryTags=this.quizWCTelemetry.getSectionTelemetryTag("learmoreclick",""),this.otherQuizzesClickedTelemetryTags=this.quizWCTelemetry.getSectionTelemetryTag("linkablequizzesclick",""),this.nextQuestionClickedTelemetryTags=this.quizWCTelemetry.getSectionTelemetryTag("nextquestionclick",""),this.scoreTelemetryTags=this.quizWCTelemetry.getSectionTelemetryTag("getscoreclick",""),this.answerClickedTelemetryTag=this.quizWCTelemetry.getSectionTelemetryTag("answerclick",""))}shadowDomPopulated(){this.markVisuallyReadyRaf()}openWindowWithUrl(e){e&&e.length>0&&window.open(new URL(e).href,"_blank")}toggleActionMenu(e,i){this.isActionMenuOpen=e,this.isActionMenuOpen?(this.actionsMenuButtonElement=i&&i.currentTarget,document.addEventListener("click",this.onOutsideClick),document.addEventListener("keydown",this.onKeydown)):(this.actionsMenuButtonElement=void 0,document.removeEventListener("click",this.onOutsideClick),document.removeEventListener("keydown",this.onKeydown))}getClickTelemetryTag(e,i){return this.telemetryObject?(0,z.g)(e,{id:e,type:n.b5.StructuredData,headline:i},n.MS.Navigate,n.EG.Click,this.telemetryExt,{type:n.MJ.ActionButton}).getMetadataTag():""}getViewTelemetryTag(e){return this.telemetryObject?(0,z.g)(e,{type:n.b5.StructuredData,id:e},n.MS.View,n.EG.View,this.telemetryExt,{type:n.MJ.Module}).getMetadataTag():""}getOptionsFromDom(){var e,i;const t=null===(e=this.shadowRoot)||void 0===e||null===(i=e.getElementById)||void 0===i||null===(i=i.call(e,"options"))||void 0===i?void 0:i.children;return t?Array.from(t):null}resetQuestionView(){const e=this.getOptionsFromDom();e&&Array.from(e).forEach(e=>{e.classList.remove("option-correct"),e.classList.remove("option-wrong"),e.classList.add("questionunanswered")})}playOnBingClick(e){var i,t;e&&"click"!=e.type&&e.code!=d.Mm||(this.totalQuestions===this.currentQuestionNumber&&this.participatedInQuiz?(this.showQuizPage=!1,this.showSummaryPage=!0,this.totalQuestions===this.totalCorrectAnswers?this.summaryMessageBasedonScore=this.strings.SummaryBannerExcellentScore:this.totalCorrectAnswers/this.totalQuestions>=.5?this.summaryMessageBasedonScore=this.strings.SummaryBannerMediumScore:this.totalCorrectAnswers/this.totalQuestions<.5&&(this.summaryMessageBasedonScore=this.strings.SummaryBannerLowScore)):this.quizContent&&this.quizContent.playOnBingLink&&this.openWindowWithUrl(T.Qf.Format("{playonBingUrl}{formcodevalue}",{playonBingUrl:this.quizContent.playOnBingLink,formcodevalue:"&form=BTNTPQ"})),null===(i=this.shadowRoot)||void 0===i||null===(t=i.getElementById)||void 0===t||null===(t=t.call(i,"question"))||void 0===t||t.focus())}moreQuizzesClick(){this.quizContent&&this.quizContent.moreQuizzesOnBingLink&&this.openWindowWithUrl(this.quizContent.moreQuizzesOnBingLink)}otherQuizClick(e){e&&e.quizLink&&this.openWindowWithUrl(e.quizLink)}showNextQuestion(e){const i=this.getOptionsFromDom();if(i&&Array.from(i).forEach(e=>{e.classList.remove("option-hide")}),!e||"click"==e.type||e.code==d.Mm){if(this.enableLearnMore=!1,this.enableNextButton=!1,this.enablePlayOnBing=!0,this.currentQuestionAlreadyAnswered=!1,this.currentQuestion=this.questions[this.currentQuestionNumber],this.currentQuestionNumber++,1!=this.currentQuestionNumber&&this.currentQuestionNumber!==this.questions.length||(this.enablePlayOnBing=!0,this.enableNextButton=!1),this.currentQuestionNumber>1&&this.resetQuestionView(),this.currentQuestion)for(const e of null===(t=this.currentQuestion)||void 0===t?void 0:t.options){var t;this.quizWCTelemetry&&(e.telemetryTag=this.quizWCTelemetry.getSectionTelemetryTag("answerclick",""))}var o,r;if(e&&(e.code==d.J9||e.code==d.Mm))null===(o=this.shadowRoot)||void 0===o||null===(r=o.getElementById)||void 0===r||null===(r=r.call(o,"question"))||void 0===r||r.focus()}}answerOptionClick(e,i){var t,o;const r=this.getOptionsFromDom();if(r&&!this.currentQuestionAlreadyAnswered){this.participatedInQuiz=!0,this.enableLearnMore=!0,this.currentQuestionAlreadyAnswered=!0,e.IsCorrectAnswer&&this.totalCorrectAnswers++,this.currentQuestion.LearnMoreLink=T.Qf.Format("https://www.bing.com{url}&form=BTNTPQ",{url:e.RequeryUrl});for(let e=0;e<this.currentQuestion.options.length;e++)this.currentQuestion.options[e].IsCorrectAnswer&&this.showCorrectAnswer(r,this.currentQuestion.options[e]);this.showInCorrectAnswer(r,e),this.setAnswersAriaLabel(r,e),this.totalQuestions>this.currentQuestionNumber?(this.enableNextButton=!0,this.enablePlayOnBing=!1):(this.enableNextButton=!1,this.enablePlayOnBing=!1,this.enableGetYourScore=!0),null===(t=this.shadowRoot)||void 0===t||null===(o=t.getElementById)||void 0===o||null===(o=o.call(t,"learn-more-link"))||void 0===o||o.focus()}}getScore(){this.enableGetYourScore=!0,this.totalValueText=this.strings.TotalScoreFormat.toString()+this.questions.length.toString(),this.playOnBingClick(null)}showCorrectAnswer(e,i){Array.from(e).forEach(e=>{const t=e.id,o=Number(t);e.classList.remove("questionunanswered"),i.Display=!1,o==i.optionNo&&i.IsCorrectAnswer&&(e.classList.add("option-correct"),i.Display=!0)})}showInCorrectAnswer(e,i){Array.from(e).forEach(e=>{const t=e.id,o=Number(t);i.Display=!1,o!=i.optionNo||i.IsCorrectAnswer?e.classList.contains("option-correct")||e.classList.add("option-hide"):(e.classList.add("option-wrong"),i.Display=!0)})}setAnswersAriaLabel(e,i){Array.from(e).forEach(e=>{Number(e.id)===i.optionNo?e.classList.contains("option-correct")?e.setAttribute("aria-label",`${e.getAttribute("aria-label")} ${this.strings.CorrectAnsSelected}`):e.classList.contains("option-wrong")&&e.setAttribute("aria-label",`${e.getAttribute("aria-label")} ${this.strings.WrongAnsSelected}`):e.classList.contains("option-correct")&&e.setAttribute("aria-label",`${e.getAttribute("aria-label")} ${this.strings.CorrectAns}`)})}};(0,a.Cg)([l.sH],S.prototype,"quizData",void 0),(0,a.Cg)([l.sH],S.prototype,"quizContent",void 0),(0,a.Cg)([l.sH],S.prototype,"questions",void 0),(0,a.Cg)([l.sH],S.prototype,"currentQuestion",void 0),(0,a.Cg)([l.sH],S.prototype,"totalQuestions",void 0),(0,a.Cg)([l.sH],S.prototype,"totalCorrectAnswers",void 0),(0,a.Cg)([l.sH],S.prototype,"currentQuestionNumber",void 0),(0,a.Cg)([l.sH],S.prototype,"enableNextButton",void 0),(0,a.Cg)([l.sH],S.prototype,"enablePlayOnBing",void 0),(0,a.Cg)([l.sH],S.prototype,"enableGetYourScore",void 0),(0,a.Cg)([l.sH],S.prototype,"enableLearnMore",void 0),(0,a.Cg)([l.sH],S.prototype,"showQuizPage",void 0),(0,a.Cg)([l.sH],S.prototype,"showSummaryPage",void 0),(0,a.Cg)([l.sH],S.prototype,"totalValueText",void 0),(0,a.Cg)([l.sH],S.prototype,"cardSize",void 0),(0,a.Cg)([l.sH],S.prototype,"isDynamicFeed",void 0),(0,a.Cg)([l.sH],S.prototype,"isActionMenuOpen",void 0),(0,a.Cg)([l.sH],S.prototype,"actionsMenuProps",void 0),(0,a.Cg)([l.sH],S.prototype,"questionShownTelemetryTags",void 0),(0,a.Cg)([l.sH],S.prototype,"answerClickedTelemetryTag",void 0),(0,a.Cg)([l.sH],S.prototype,"SummaryShownTelemetryTags",void 0),(0,a.Cg)([l.sH],S.prototype,"PromotionClickedTelemetryTags",void 0),(0,a.Cg)([l.sH],S.prototype,"moreQuizzesClickedTelemetryTags",void 0),(0,a.Cg)([l.sH],S.prototype,"otherQuizzesClickedTelemetryTags",void 0),(0,a.Cg)([l.sH],S.prototype,"playOnBingClickedTelemetryTags",void 0),(0,a.Cg)([l.sH],S.prototype,"nextQuestionClickedTelemetryTags",void 0),(0,a.Cg)([l.sH],S.prototype,"learnMoreTelemetryTags",void 0),(0,a.Cg)([(0,h.CF)({attribute:"enable-mock-response"})],S.prototype,"enableMockResponse",void 0),(0,a.Cg)([l.sH],S.prototype,"scoreTelemetryTags",void 0),(0,a.Cg)([l.sH],S.prototype,"superCardData",void 0),(0,a.Cg)([l.sH],S.prototype,"oneServiceQuizData",void 0),S=x=(0,a.Cg)([I.x],S);var q=t(69259),$=t(39957);t(73182).MsnActionsMenu;const R=v.qy`
${(0,q.z)(e=>e.currentQuestion&&null!=e.currentQuestion&&null!=e.currentQuestion.options,v.qy`<div id="options">${(0,$.ux)(e=>{var i;return null===(i=e.currentQuestion)||void 0===i?void 0:i.options},v.qy` ${(0,q.z)(e=>e.Display,v.qy`<fluent-button class="option questionunanswered" id=${(e,i)=>e.optionNo} @click=${(e,i)=>i.parent.answerOptionClick(e,i.index)} data-t="${(e,i)=>i.parent.answerClickedTelemetryTag}" title=${e=>e.DisplayText} aria-label=${e=>"option "+e.OptionLabel+" "+e.DisplayText}><div slot="start"><div class="option-label">${e=>e.OptionLabel}</div><div class="option-text" id=${(e,i)=>"option-text-"+e.optionNo.toString()} role="option">${e=>e.DisplayText}</div></div></fluent-button>`)} `)}</div>`)} ${(0,q.z)(e=>e.enableLearnMore,v.qy`<a id="learn-more-link" href=${e=>{var i;return null===(i=e.currentQuestion)||void 0===i?void 0:i.LearnMoreLink}} target="_blank" role="link" data-t="${e=>e.learnMoreTelemetryTags}">${e=>e.strings.LearnMore}</a>`)}
`,O=v.qy` ${(0,$.ux)(e=>e.getOtherQuizzes(),v.qy`<div id="summary-other-quiz" tabindex="0" @click=${(e,i)=>{i.parent.otherQuizClick(e)}} role="button" data-t="${(e,i)=>i.parent.otherQuizzesClickedTelemetryTags}">${(e,i)=>e.quizName}</div>`)}
`,D=v.qy`<div class="super-card-quiz-footer"><div class="pagination">${e=>e.currentQuestionNumber.toString()+"/"+e.totalQuestions.toString()}</div>${(0,q.z)(e=>e.enableNextButton,v.qy`<fluent-button part="footer-button" id="next-question" tabIndex="0" aria-label=${e=>e.strings.NextQuestion} role="button" @click=${(e,i)=>e.showNextQuestion(i.event)} data-t="${(e,i)=>e.nextQuestionClickedTelemetryTags}">${e=>e.strings.NextQuestion}</fluent-button>`)} ${(0,q.z)(e=>e.enablePlayOnBing,v.qy`<button tabindex="0" id="play-on-bing" @click=${(e,i)=>e.playOnBingClick(i.event)} data-t="${e=>e.playOnBingClickedTelemetryTags}" aria-label=${e=>e.strings.PlayOnBing} role="link">${e=>e.strings.PlayOnBing}</button>`)} ${(0,q.z)(e=>e.enableGetYourScore,v.qy`<fluent-button tabIndex="0" id="get-score" @click=${(e,i)=>e.getScore()} aria-label=${e=>e.strings.GetYourScore} role="button" data-t="${e=>e.scoreTelemetryTags}">${e=>e.strings.GetYourScore}</fluent-button>`)}</div>`,E=v.qy`<div class="quiz-container"><div id="quiz-main-container"><div id="question-wrapper"><div id="question" tabIndex="0" aria-label=${e=>{var i;return null===(i=e.currentQuestion)||void 0===i?void 0:i.questionText}} title=${e=>{var i;return null===(i=e.currentQuestion)||void 0===i?void 0:i.questionText}}>${e=>{var i;return null===(i=e.currentQuestion)||void 0===i?void 0:i.questionText}}</div></div>${R}</div>${D}</div>`,M=v.qy`<div id="point-five-quiz-main-container" class="quiz-container"><div id="point-five-question-wrapper"><div id="question" tabIndex="0" aria-label=${e=>{var i;return null===(i=e.currentQuestion)||void 0===i?void 0:i.questionText}}>${e=>{var i;return null===(i=e.currentQuestion)||void 0===i?void 0:i.questionText}}</div></div><div class="play-bing-link"><div tabindex="0" id="play-on-bing" @click=${(e,i)=>e.playOnBingClick(i.event)} @keydown=${(e,i)=>e.playOnBingClick(i.event)} data-t="${e=>e.playOnBingClickedTelemetryTags}" aria-label=${e=>e.strings.PlayOnBing} role="button">${e=>e.strings.PlayOnBing}</div></div></div></div>`,B=v.qy`<div class="super-card-quiz-footer" slot=""><div id="summary-play-on-bing"
tabindex="0"
aria-label=${e=>e.strings.SummaryMoreQuizzesOnBing}
role="button"
@click=${e=>e.moreQuizzesClick()}
data-t="${e=>e.moreQuizzesClickedTelemetryTags}">${e=>e.strings.SummaryMoreQuizzesOnBing}</div></div>`,F=v.qy`<div class="quiz-container"><div id="summary-container"><div id="summary-banner-container" tabindex="0" aria-label="quiz summary"><div id="summary-banner-background"><div id="summary-banner-medal"><img src=${k} /></div><div id="summary-banner-congrats" tabindex="0" aria-label=${e=>e.summaryMessageBasedonScore}>${e=>e.summaryMessageBasedonScore}</div><div id="summary-banner-ribbon">${A}<div id="summary-text"><div id="summary-banner-score-word" tabindex="0" aria-label=${e=>e.strings.Score}>${e=>e.strings.Score}</div><div id="summary-banner-score-value" tabindex="0" aria-label=${e=>"total correct answers"+e.totalCorrectAnswers}>${e=>e.totalCorrectAnswers}</div><div id="summary-banner-score-total">${e=>e.totalValueText}</div></div></div></div></div><div id="summary-other-quizzes-title" tabindex="0" aria-label=${e=>e.strings.OtherQuizzesTitle}>${e=>e.strings.OtherQuizzesTitle}</div><div id="summary-other-quizzes-container">${O}</div></div>${B}</div>`,L=v.qy`<responsive-sd-card :data="${e=>e.superCardData}" class="quiz-main-container" size="${e=>e.cardSize}"><div slot="card-content">${(0,q.z)(e=>e.showQuizPage,E)} ${(0,q.z)(e=>e.showSummaryPage,F)}</div></responsive-sd-card>`,U=v.qy`<responsive-sd-card :data="${e=>e.superCardData}" class="quiz-main-container" size="${e=>e.cardSize}"><div slot="card-content">${(0,q.z)(e=>e.showQuizPage,M)}</div></responsive-sd-card>`,Y=v.qy`<div class="hidden" aria-live="polite"></div>${e=>e.cardSize==u.uE._1x_1y?U:L}
`,V=v.qy`<div class="hidden" aria-live="polite"></div>${e=>e.config.isDynamicFeed&&e.cardSize==u.uE._1x_1y?U:L}
`;var H=t(74849),P=t(4968),N=t(25109);const j=H.A` a,fluent-button,div{${P.f}}:host{--sd-card-title-font-weight:400}.super-card-quiz-footer{display:flex;flex-direction:row;justify-content:space-between;align-items:flex-end}.super-card-quiz-footer .pagination{font-size:12px}.quiz-container{display:flex;flex-direction:column;height:100%;justify-content:space-between}.super-card-quiz-footer .actionbutton{position:absolute;right:16px}#question-wrapper{position:relative;display:flex}#question{overflow:hidden;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;font-family:"Segoe UI";font-style:normal;font-weight:600;font-size:16px;line-height:22px;text-overflow:ellipsis;margin-bottom:16px;height:66px}.option{background:rgba(255,255,255,0.5);border-radius:20px;width:266px;margin-bottom:4px;height:30px;display:block;position:relative;border:1px solid #6c6c6c;font-family:"Segoe UI";font-style:normal;font-weight:400;font-size:14px;line-height:20px;display:flex;align-items:center}.questionunanswered:hover{cursor:pointer;background:${(0,N.ud)()?"#666":"#FFF"}}.option-correct{background:rgba(68,100,255,0.3)}.option-wrong{background:rgba(94,94,94,0.2)}.option-hide{}.option-label{font-family:Segoe UI;font-size:12px;line-height:16px;display:inline-block;background:${(0,N.ud)()?"rgba(0, 0, 0, 0.7)":"rgba(255, 255, 255, 0.5)"};border-radius:30px;text-align:center;padding:2px 7px 4px;width:8px}.option-text{margin-left:4px;font-family:Segoe UI;font-size:14px;line-height:20px;display:inline-block;width:200px;overflow:hidden;text-overflow:ellipsis;text-align:left}#quiz-progress{position:absolute;left:16px;bottom:16.5px;font-family:"Segoe UI";font-style:normal;font-weight:400;font-size:12px;line-height:16px}#next-question,#get-score{position:absolute;right:1px;background:#4464ff;border-radius:20px;cursor:pointer;color:#f7f7f7;height:24px;font-family:"Segoe UI";font-style:normal;font-weight:400;font-size:12px;line-height:16px;text-align:center}#play-on-bing{right:1px;font-family:"Segoe UI";font-style:normal;font-weight:400;font-size:12px;line-height:16px;color:${(0,N.ud)()?"#FFF":"#262626"};cursor:pointer;background:none;border:none;padding:0}:host(.footer.neutral){background-color:red}#learn-more-link{font-family:Segoe UI;font-size:14px;line-height:20px;color:#115EA3;text-decoration:none}#learn-more-link:focus{text-decoration:underline}#summary-banner-container{}#summary-banner-background{background:${(0,N.ud)()?"rgba(0, 0, 0, 0.54)":"rgba(255, 255, 255, 0.8)"};box-shadow:0px 16px 20px -10px rgba(0,0,0,0.2);border-radius:4px;width:268px;height:88px;padding-top:8px;display:flex}#summary-banner-medal{padding-top:20px;padding-left:8px;width:54px}#summary-banner-ribbon{margin-left:20px;margin-top:-15px}#summary-banner-congrats{padding-top:22px;width:122px;height:22px;font-family:"Segoe UI";font-size:16px;line-height:22px}#summary-banner-status-message{font-family:Segoe UI;font-size:10px;line-height:14px;width:122px;height:28px}#summary-banner-score-word{text-align:center;width:46px;height:14px;ont-family:"Segoe UI";font-size:10px;line-height:14px;text-align:center}#summary-banner-score-value{font-family:Segoe UI;font-size:32px;line-height:40px;text-align:center;width:46px;height:40px}#summary-banner-score-total{text-align:center;width:46px;height:14px;font-family:"Segoe UI";font-size:10px;line-height:14px;text-align:center}#summary-other-quizzes-title{line-height:14px;margin-top:15px;font-family:"Segoe UI";font-style:normal;font-weight:600;font-size:10px;line-height:14px}#summary-other-quizzes-container{display:block;overflow:hidden;margin-top:16px}#summary-other-quiz{display:inline-block;height:20px;border-radius:30px;margin-bottom:4px;margin-right:4px;cursor:pointer;padding:4px 12px;gap:8px;text-overflow:ellipsis;background:${(0,N.ud)()?"rgba(255, 255, 255, 0.09)":"rgba(255, 255, 255, 0.54)"};border-radius:30px;line-height:20px;border:1px solid #616161;font-family:"Segoe UI";font-style:normal;font-weight:400;font-size:14px;line-height:20px}#other-quiz-container{display:flex}#summary-text{position:absolute;top:5px;padding:5px;color:#f7f7f7}#summary-play-on-bing{cursor:pointer;font-size:12px;margin:auto}.play-bing-link{display:flex;justify-content:center}#point-five-question-wrapper{${P.f}
        position: relative;
        display: flex;
        height: 66px;
    }

`.withBehaviors(),Z={experienceConfigSchema:undefined};o.m.define(r.c.registry),(0,s.d)()},43774(e,i,t){t.d(i,{p4(){return b},ls(){return m},vA(){return g},nF(){return p}});var o=t(45755),r=t(68009),s=t(95239);const{create:a}=o.G,n=a("neutral-stroke-strong-hover-delta",40),l=a("neutral-stroke-strong-active-delta",16),h=a("neutral-stroke-strong-focus-delta",25);var d=t(31023);const{create:c}=o.G,u=c({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,i,t,o,s,a){const n=(0,r.F)(i),l=e.colorContrast(i,t),h=e.closestIndexOf(l);return{rest:l,hover:e.get(h+n*o),active:e.get(h+n*s),focus:e.get(h+n*a)}}(e(d.r),e(s.p),3,e(n),e(l),e(h))}}),p=c("neutral-stroke-strong-rest",e=>e(u).evaluate(e).rest),g=c("neutral-stroke-strong-hover",e=>e(u).evaluate(e).hover),b=c("neutral-stroke-strong-active",e=>e(u).evaluate(e).active),m=c("neutral-stroke-strong-focus",e=>e(u).evaluate(e).focus)}}]);