// © Microsoft Corporation. All rights reserved.
export const template = `
<div class='overflow'>
	<div class='Desktop'>
		<div class='logo-search-container'>
			<div id='divLogo'>
				<img class='logo' src='https://assets.msn.com/staticsb/statics/pr-3693935/IE11NTP/logo.png' title='msn_logo' alt='msn_logo' />
			</div>
			<input type='search' name='q' id='txtSearch' autocomplete='off' class='search-box icon' />
			<button id='search-button-telemetry' type='submit' value='Go' style='cursor:pointer; border:none;'>
                <img src='https://assets.msn.com/staticsb/statics/pr-3693935/IE11NTP/Icon.png' class='search-icon' />
            </button>
		</div>
		<div class='ie-mobile'>
			<a href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' id='ie-mobile-telemetry1'>
				<img src='https://assets.msn.com/staticsb/statics/pr-3693935/IE11NTP/mobile-image.png' class='mobileImage'>
			</a>
			<div class='mobile-text'>
				<a href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' id='ie-mobile-telemetry2' class='overlay-mob'></a>
				<p class='mobile-p1'>
					<span id='mobbannerTextHeadline'></span>
				</p>
				<p class='mobile-p2'>
					<span id='mobbannerText'></span>
				</p>
				<div class='mobile-buttons'>
					<a href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' class='mobile-button'>
						<p class='mobile-button-text'>
							<span id='mobbuttontext'></span>
						</p>
						<img src='https://assets.msn.com/staticsb/statics/pr-3693935/IE11NTP/desktop-shape.png'>
					</a>
				</div>
			</div>
		</div>
		<div class='ie-container'>
			<a id='banner-telemetry' href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' class='overlay'></a>
			<div class='message'>
				<div class='text'>
					<p class='p1' style='margin-bottom: 1rem;'>
						<span id='bannerTextHeadline'></span>
					</p>
					<p class='p2' style='margin-bottom: 1rem;'>
						<span id='bannerText'></span>
					</p>
				</div>
				<div class='buttons'>
					<a href='https://www.microsoft.com/en-us/edge/download?form=MA13FW' class='button'>
						<p class='button-text'>
							<span id='bannerButtonText'></span>
						</p>
						<img src='https://assets.msn.com/staticsb/statics/pr-3693935/IE11NTP/desktop-shape.png'>
					</a>
				</div>
			</div>
		</div>
		<div class='banner-container'>
			<div id='banner1' class='banner-ad'></div>
		</div>
		<div class='frame' id='frame1'>
			<div class='ads ads-1 mobile-ads' id='ads1' style='margin-bottom:20px;'>
				<div class='Infopane' style='margin-right:20px;'>
					<div class='content-card' style='border:none;'>
						<div id='Infopane-image-1'></div>
						<div class='attribute'>
							<div id='Infopane-title-1'></div>
							<div id='Infopane-image-Icon-1'></div>
						</div>
					</div>
				</div>
				<div class='feed-card' style='margin-right:20px;'>
					<div id='artical1'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical1Icon'></div>
							<a id='articalTitle' class='title-link'></a>
						</div>
					</div>
				</div>
				<div class='ads-card' id='divAD_0'></div>
			</div>
			<div class='ads ads-2' style='margin-bottom: 20px;'>
				<div class='ads-card' style='margin-right:20px; order:0;' id='divAD_1'></div>
				<div class='feed-card' style='margin-right:20px; order:1;'>
					<div id='artical2'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical2Icon'></div>
							<a id='artica2Title' class='title-link'></a>
						</div>
					</div>
				</div>
				<div class='ads-card ads-card-margin' style='margin-right:20px; order:2;' id='divAD_2'></div>
				<div class='feed-card' style='order:3;'>
					<div id='artical3'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical3Icon'></div>
							<a id='artica3Title' class='title-link'></a>
						</div>
					</div>
				</div>
			</div>
			<div class='ads ads-3' style='margin-bottom: 20px;'>
				<div class='feed-card' style='margin-right:20px; order:0;'>
					<div id='artical4'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical4Icon'></div>
							<a id='artica4Title' class='title-link'></a>
						</div>
					</div>
				</div>
				<div class='feed-card' style='margin-right: 20px; order: 1;'>
					<div id='artical5'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical5Icon'></div>
							<a id='artica5Title' class='title-link'></a>
						</div>
					</div>
				</div>
				<div class='feed-card' style='margin-right:20px; order:2;'>
					<div id='artical6'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical6Icon'></div>
							<a id='artica6Title' class='title-link'></a>
						</div>
					</div>
				</div>
				<div class='feed-card' style='order:3;'>
					<div id='artical7'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical7Icon'></div>
							<a id='artica7Title' class='title-link'></a>
						</div>
					</div>
				</div>
			</div>
			<div class='ads ads-4' style='margin-bottom: 20px;'>
				<div class='feed-card' style='margin-right:20px; order:0;'>
					<div id='artical8'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical8Icon'></div>
							<a id='artica8Title' class='title-link'></a>
						</div>
					</div>
				</div>
				<div class='feed-card' style='margin-right:20px; order:1;'>
					<div id='artical9'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical9Icon'></div>
							<a id='artica9Title' class='title-link'></a>
						</div>
					</div>
				</div>
				<div class='feed-card' style='margin-right: 20px; order:2;'>
					<div id='artical10'></div>
					<div class='content'>
						<div class='title attribution-img'>
							<div id='artical10Icon'></div>
							<a id='artica10Title' class='title-link'></a>
						</div>
					</div>
				</div>
				<div class='ads-card ads-card-margin' style='order:3;' id='divAD_3'></div>
			</div>
			<div id='spfooter' class='river' style='visibility: visible;'></div>
		</div>
		<div class='mobile-ads' id='mobileads01'>
			<div class='feed-card' style='margin-bottom:20px;'>
				<div id='mobartical1'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical1Icon'></div>
						<a id='mobarticalTitle' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='ads-card' style='margin-bottom:20px;' id='mobdivAD_0'></div>
			<div class='ads-card' style='margin-bottom:20px;' id='mobdivAD_1'></div>
			<div class='feed-card' style='margin-bottom:20px;'>
				<div id='mobartical2'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical2Icon'></div>
						<a id='mobartica2Title' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='ads-card' style='margin-bottom:20px;' id='mobdivAD_2'></div>
			<div class='feed-card' style='margin-bottom:20px;'>
				<div id='mobartical3'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical3Icon'></div>
						<a id='mobartica3Title' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='feed-card' style='margin-bottom: 20px;'>
				<div id='mobartical4'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical4Icon'></div>
						<a id='mobartica4Title' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='feed-card' style='margin-bottom: 20px;'>
				<div id='mobartical5'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical5Icon'></div>
						<a id='mobartica5Title' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='feed-card' style='margin-bottom: 20px;'>
				<div id='mobartical6'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical6Icon'></div>
						<a id='mobartica6Title' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='feed-card' style='margin-bottom: 20px;'>
				<div id='mobartical7'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical7Icon'></div>
					    <a id='mobartica7Title' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='feed-card' style='margin-bottom: 20px;'>
				<div id='mobartical8'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical8Icon'></div>
						<a id='mobartica8Title' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='feed-card' style='margin-bottom:20px;'>
				<div id='mobartical9'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical9Icon'></div>
						<a id='mobartica9Title' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='feed-card' style='margin-bottom:20px;'>
				<div id='mobartical10'></div>
				<div class='content'>
					<div class='title attribution-img'>
						<div id='mobartical10Icon'></div>
						<a id='mobartica10Title' class='title-link'></a>
					</div>
				</div>
			</div>
			<div class='ads-card' style='margin-bottom:20px;' id='mobdivAD_3'></div>
			<div id='mobspfooter' class='river' style='visibility: visible; position:relative; order:1;'></div>
		</div>
	</div>
</div>`;
//# sourceMappingURL=template.js.map