// © Microsoft Corporation. All rights reserved.
// require("localstorage-polyfill");
// Runs side effect code to replace lodash memoize cache implementation
// before other import side effects like FAST that uses memoize
//
// WARNING: Please leave node-memoize-cache & node.bundler at top of the import and do not auto sort
import "@msnews/node-memoize-cache";
import "./node.bundler";
import { DefaultLogger, resetPageTimings, setLogger, updateAppErrorsPropertyBag, getElapsedSinceTimeOrigin, setPageTiming } from "@msnews/diagnostics";
import { SSRTelemetry, getSSRTelemetryDataFromProps, initializeSSRNodeEnvironment, setLoggerDebugLevel, ssrEnvironment, getRequestReferrer, getRequestUserAgent, getOneServiceHeaders, getSSRForceExceptionScript, getStackTrace, shouldForceShowException, getRequestVPCetoToken } from "@msnews/ssr-util";
import { ServerCache, abortableFetchInitialize, appEnvironment, initializePublicPath, invokeResetCallbacks, resetAppEnvironment, resetCoreHelpers, resetResolverInstance, tryParseJson, headData } from "@msnews/core";
import { TrackingSystemType } from "@msnews/telemetry-contracts";
import { getRequestData, IsomorphicStorage, resetRequestData } from "@msnews/isomorphic-util";
import { EarlyFallbackError, setIsomorphicStorage } from "@msnews/ssr-server-utils";
import { OneDSEventMapper, trackingSystemConfig } from "@msnews/telemetry-core";
import { processFASTWCResponse } from "./web-component-renderer";
import { patchDomShim } from "./patch-dom-shim";
import { SignInStateResolver } from "@msnews/auth";
initializeSSRNodeEnvironment();
/**
 * Default function that render service will call to do the rendering of the page
 * @param req The request object
 * @param res The response object
 * @param cache The server cache object
 * @param httpAgent Http agent to manage connections in the same process
 * @param httpsAgent Https agent to manage connections in the same process
 * @param requestStorage AsyncLocalStorage object that came from fast-ssr RequestStorage to be used as request scope store. Currently only Web Component app type entry point will use it. React SSR can ignore.
 * @param templateData Object containing html and other data parsed by Render Service to be available to server module
 * @param requestMetricsLogger Logger to log request metrics for outbound requests made during SSR
 */
export default async (req, res, cache, httpAgent, httpsAgent, _requestStorage, templateData, requestMetricsLogger) => {
    try {
        setIsomorphicStorage(_requestStorage);
        const clientData = getClientDataFromHtmlTemplate(templateData);
        const isWCSEO = req.query?.wcseo === "1";
        const isVPSSR = req.query?.vpssr === "1";
        patchDomShim(req, clientData, templateData, isWCSEO || isVPSSR);
        headData.initializeHeadData(clientData);
        templateData.requestStartTime !== undefined && resetPageTimings(templateData.requestStartTime);
        setPageTiming("ssrTimeServerEntry", getElapsedSinceTimeOrigin());
        // Initialize abortable fetch custom http agents and request metrics logger from render service
        abortableFetchInitialize(httpAgent, httpsAgent, undefined, requestMetricsLogger);
        // Save original request into isomorphic storage
        IsomorphicStorage.set("__originalRequest__" /* IsomorphicStorageKeys.OriginalRequest */, req);
        // Set Logger with req.id.
        // logger is still a Singleton accessor which is not in request scope yet.
        // TODO: Refactor logger Singleton into request context.
        // https://dev.azure.com/microsoft/OS/_workitems/edit/28448840
        setLogger(new DefaultLogger(req.id));
        setLoggerDebugLevel(String(req.query.debug));
        // Get additional request data
        const requestProps = getRequestProps(req);
        // Reset to un-decoded, original cookie, which comes from browser's request directly.
        // If containg non-ANSIC chars, decoded cookie will cause "invalid HTTP header" error when calling community data with it.
        requestProps.cookie = req.headers?.cookie;
        // Update server side app errors with build number for each request
        if (clientData && clientData.clientSettings) {
            const { bundleInfo } = clientData.clientSettings;
            const buildNumber = bundleInfo && bundleInfo.v;
            if (buildNumber) {
                const pb = {
                    build: buildNumber,
                    ssrEnvironment: "Server"
                };
                updateAppErrorsPropertyBag(pb);
            }
        }
        else {
            throw new Error("Failed to get clientSettings");
        }
        // Initialize SSR telemetry using request data
        const telemetryData = getSSRTelemetryDataFromProps(req.id, requestProps, clientData);
        let telemetryTrackingSystemConfig = ssrEnvironment.isProduction() ? trackingSystemConfig.prod : trackingSystemConfig.int;
        if (appEnvironment.IsChinaCompliance) {
            telemetryTrackingSystemConfig = ssrEnvironment.isProduction() ? trackingSystemConfig.prodCN : trackingSystemConfig.intCN;
        }
        if (shouldForceShowException(req.query) || isVPSSR) {
            telemetryTrackingSystemConfig = [...telemetryTrackingSystemConfig, {
                    type: TrackingSystemType.Debug,
                    mapper: new OneDSEventMapper(),
                    transporterConfig: {
                        callback: (payload) => {
                            if (payload?.name !== "MS.News.Web.AppError") {
                                return;
                            }
                            res.write(getSSRForceExceptionScript(`<b>Server side App Error: </b><pre>${JSON.stringify(payload, null, 4)}</pre>`, templateData.nonce));
                            res.end();
                        }
                    }
                }];
        }
        SSRTelemetry.initializeTelemetryAPI(telemetryData, telemetryTrackingSystemConfig, true);
        // Reset all singletons the request consumes and supply client data that was passed in with the request through query param.
        reinitializeSingletons(clientData, requestProps);
        // Logic to check if we should reject SSR based on auth state.
        const requestData = getRequestData();
        if (!requestData.msalAuthReady) {
            // token expired
            // If MSAL is not ready, we should not proceed with SSR
            throw new EarlyFallbackError("Rejecting SSR because of expired auth token in cookie. Please visit a CSR page first to refresh token or clear all cookies and retry. Reject reason: " + requestData.pssrRejectedReason);
        }
        appEnvironment.EnableFiveColLayout = true;
        appEnvironment.CrsDisableServerCache = true;
        appEnvironment.DisableInMemoryCache = true;
        initializePublicPath();
        SignInStateResolver();
        // Initialize the ServerCache with the cache from Render Service
        ServerCache.initialize(cache);
        // Depending on render type requested, serve either plain unstyled HTML (for Bots and SEO scenario)
        // or Web Component templates with FAST SSR
        await processFASTWCResponse(req, requestProps, res, templateData, isWCSEO);
        setPageTiming("ssrTimeEnd", getElapsedSinceTimeOrigin());
    }
    catch (err) {
        if (shouldForceShowException(req.query)) {
            const stackTrace = `${err?.stack || getStackTrace()}`;
            // SSR-TODO: Remove this debugging code before production release.
            // The flag will stop re-throw exception and show it in HTML
            console.error(`[SSR] Top level exception: ${err} Stack trace: ${stackTrace} Request Id: ${req.id}`);
            res.write(getSSRForceExceptionScript(`<b>Error: </b>${err}<br /><b>Stack trace: </b><pre>${stackTrace}</pre><br />Request Id: ${req.id}<br />`, templateData.nonce));
            res.end();
            return;
        }
        throw err;
    }
    finally {
        setPageTiming("ssrTimeRequestEnd", getElapsedSinceTimeOrigin());
    }
};
/**
 * Get browser data from query string params
 * @param req The request containing query params
 */
export function getRequestProps(req) {
    let protocol = req.protocol;
    const host = req.hostname;
    const url = req.originalUrl;
    // TODO: Request homepage with https, but the req.protocol is http; let's force a conversion here for now, and investigate the specific reason later.
    if (protocol === "http") {
        protocol = "https";
    }
    const fullUrl = `${protocol}://${host}${url}`;
    const requestProps = {
        href: fullUrl,
        innerHeight: 0,
        devicePixelRatio: 1,
        canUseCssGrid: false,
        requestId: String(req.id),
        cookie: req.headers?.cookie,
        referer: getRequestReferrer(req),
        userAgent: getRequestUserAgent(req),
        oneServiceHeaders: getOneServiceHeaders(req),
        vpCetoToken: getRequestVPCetoToken(req)
    };
    return requestProps;
}
/**
 * Get client data from query string params
 * @param req The request containing query params
 */
function getClientDataFromHtmlTemplate(templateData) {
    const clientSettings = tryParseJson(templateData.dataClientSettings);
    // const isLocalhost = (req.headers["host"] || "").startsWith("localhost");
    const clientData = {
        clientInfo: templateData.dataInfo || "", // this is allowed to be empty
        clientSettings: clientSettings,
        language: "", // Doesn't seem to be used
        marketDir: templateData.textDirection
    };
    return clientData;
}
/**
 * Clean the singelton classes throughout the repo
 * TODO: maybe move this to its own lib or some utility function
 * @param clientData Client data from query params.
 * @param requestData Browser data from the request (contained in the query params).
 * @param requestContext The request context
 */
function reinitializeSingletons(clientData, requestData) {
    // Reset singletons that do not have dependencies
    invokeResetCallbacks();
    // RequestData - Dependencies: None
    resetRequestData(requestData, true);
    // HeadData & Core helpers - Dependencies: requestData, hasExperiment
    resetCoreHelpers(clientData);
    // App Environment - Dependencies: requestData, Logger, HeadData
    resetAppEnvironment(null, ssrEnvironment.configServiceOverride, ssrEnvironment.serviceDomainOverride, ssrEnvironment.hostHeaderOverride);
    // Module Object
    resetPageTimings();
    // Resolver - Dependencies: requestData, AppEnvironment, Logger, PerfTracker, PerfTimeline, ExperienceDiagnostics, WebWorkerUtility, WebStorage
    resetResolverInstance();
}
//# sourceMappingURL=node.index.js.map