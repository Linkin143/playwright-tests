// © Microsoft Corporation. All rights reserved.
import { getAppEnvironment } from "@msnews/core";
export const adChoicesTemplate = `
    <a href='//go.microsoft.com/fwlink/?LinkID=286759' tabindex='{-1}' target='_blank' class='adChoices'>
        <div style='float: right;'>
            <img src="${() => `${getAppEnvironment().StaticsUrl}/latest/icons-wc/icons/AdChoice.svg`}" style="width: 12px; height: 12px" alt="adChoicesTemplate" aria-hidden="true"/>
            <span class='adChoicesSpan'>AdChoices</span>
        </div>
    </a>
`;
export const adChoicesStyle = (width) => `
    .adChoices {
        display: inline-block;
        width: ${width}px;
        margin: auto;
    }
    .adChoicesSpan { 
        font-family: Segoe UI,Segoe WP,Arial,Sans-Serif; 
        color: #242424; 
        font-size: 10px; 
    }
`;
//# sourceMappingURL=adChoicesTemplate.js.map