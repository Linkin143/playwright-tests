"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-event-country"],{4968(e,t,i){i.d(t,{f(){return a}});var o=i(64187),r=i(74849),n=i(42792),l=i(99657),s=i(36452);const a=r.A.partial`position: relative; z-index: ${l.D};`;r.A`
    ${n.e}
    ${n.nH}

    ${(0,o.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${a}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(n.kc)},13525(e,t,i){i.r(t),i.d(t,{SportsEventCountryTransformer(){return c}});var o=i(49150),r=i(23587),n=i(79811),l=i(96950),s=i(58792),a=i(22341),d=i(85312);class c extends r.Bc{async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,n.jJ)();const i=await this.getCurrentViewModel(e);return{viewTemplate:l.qy`
                <sports-event-country
                    :viewModel="${i}"
                ></sports-event-country>`}}isFollowed(e){var t;return e.followedSports&&e.followedSports.get((null===(t=e.data)||void 0===t||null===(t=t.teamMedalCount)||void 0===t||null===(t=t.team)||void 0===t?void 0:t.satoriId)||"")}getLeagueLogoUrl(e){return e?(0,n._K)((0,n.iK)(e,!1,this.transformerProvider.config.teamImageInfoEnhanced),58,58,!0):this.getTeamImageFallback()}getTeamImageFallback(){return`${(0,s.rA)().StaticsUrl}latest/sports/icons/TeamFlagFallback.svg`}async getCurrentViewModel(e){var t,i,o,l;const{telemetryBuilder:c,strings:p}=this.transformerProvider;if(null===(t=e.data)||void 0===t||!t.teamMedalCount)return void(0,a.vV)(d.Ax,"Sports Event Country data missing",`market=${s.T3.CurrentMarket}`,JSON.stringify(e));const h=(null===(i=e.data)||void 0===i||null===(i=i.teamMedalCount)||void 0===i?void 0:i.team)||{},g=this.getLeagueLogoUrl(h.imageId),u=(0,n.Ot)(null===(o=e.data)||void 0===o?void 0:o.clickThroughUrl);var v;(0,n.Hn)(h.hasExplicitInterest)&&!this.isFollowed(e)&&(null===(v=e.followedSports)||void 0===v||v.set(h.satoriId,!0));return{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,strings:p,teamMedalCount:null===(l=e.data)||void 0===l?void 0:l.teamMedalCount,leagueLogoUrl:g,listView:await this.getListView(e),followLeagueClickHandler:e=>{h.hasExplicitInterest=e,this.transformerProvider.followClickEntityHandler({id:h.satoriId,yId:h.yId,name:h.name,type:r.XR.League,imageUrl:g},e,u)},destinationUrl:u,isFollowed:this.isFollowed(e),followTelemetryTag:c.createFollowTelemetryTag(e.telemetryObject,{name:r.BP.SportsEventCountryCard,brandId:"SportsEventCountryCard",headline:r.BP.SportsEventCountryCard,id:1,signature:e.telemetryConstants.signature},!0),unFollowTelemetryTag:c.createFollowTelemetryTag(e.telemetryObject,{name:r.BP.SportsEventCountryCard,brandId:"SportsEventCountryCard",headline:r.BP.SportsEventCountryCard,id:1,signature:e.telemetryConstants.signature},!1),telemetryTag:c.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsEventCountryCard})}}async getListView(e){if(this.cardSize===o.uE._1x_1y)return;const{recentMedals:t}=e.data||{};return t&&t.length>0?await this.transformerProvider.generateView(e,r.hi.SportsRecentMedal):await this.transformerProvider.generateView(e,r.hi.SportsEventSchedule)}}Promise.resolve().then(i.bind(i,50688)),Promise.resolve().then(i.bind(i,96041))},42792(e,t,i){i.d(t,{R7(){return v},e(){return g},kc(){return u},nH(){return h}});var o=i(57416),r=i(55153),n=i(95239),l=i(26920),s=i(48751),a=i(64187),d=i(22131),c=i(74849),p=i(50882);const h=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,g=c.A`
    ${(0,a.V)("flex")} :host {
        background: ${n.p};
        outline: calc(${l.XA} * 1px) solid ${r.cu};
        border-radius: calc((${o.JU} - ${l.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${l.XA} * 1px) ${r.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${l.XA} * 1px) ${r.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${l.XA} * 1px) ${r.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${r.QG} * 1px);
        height: calc(${r.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${r.QG} * 1px);
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc(${r.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,d.mr)(c.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),v=c.A`
    ${g}
    ${h}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},50688(e,t,i){i.r(t),i.d(t,{SportsEventCountry(){return T}});var o=i(56911),r=i(92079),n=i(60815),l=i(50180);class s extends r.a{constructor(){super(...arguments),this.isFollowed=!1}connected(){super.connected(),this.isFollowed=this.viewModel.isFollowed}onFollowClick(){this.viewModel.followLeagueClickHandler(!this.isFollowed),this.isFollowed=!this.isFollowed}getFollowButtonIconName(){return this.isFollowed?"OlympicFollow":this.viewModel.isDarkModeTheme?"CircleAddLargeDark":"CircleAddLarge"}getFollowItemButtonTitle(){var e,t,i;return(0,l.GP)(this.viewModel.isFollowed?null===(e=this.viewModel.strings)||void 0===e?void 0:e.haveFollowed:null===(t=this.viewModel.strings)||void 0===t?void 0:t.followSports,(null===(i=this.viewModel.teamMedalCount)||void 0===i||null===(i=i.team)||void 0===i?void 0:i.name)||"")}followButtonTelemetry(){return""}getMedalCountList(){var e,t,i,o;const r=null===(e=this.viewModel.teamMedalCount)||void 0===e?void 0:e.medalsWon;return[{name:null===(t=this.viewModel.strings)||void 0===t?void 0:t.gold,medal:"Gold",count:null==r?void 0:r.Gold},{name:null===(i=this.viewModel.strings)||void 0===i?void 0:i.silver,medal:"Silver",count:null==r?void 0:r.Silver},{name:null===(o=this.viewModel.strings)||void 0===o?void 0:o.bronze,medal:"Bronze",count:null==r?void 0:r.Bronze}]}}(0,o.Cg)([n.sH],s.prototype,"isFollowed",void 0);var a=i(92011),d=i(48751),c=i(86856),p=i(4968),h=i(12640),g=i(74849);const u=g.A` .sports-follow-icon::before{background-color:rgba(0,0,0,0.5)}.sports-event-country-follow{color:rgba(255,255,255,0.9)}.icon-add-light{display:none}.icon-add-dark{display:block}`,v=g.A`
`,x=g.A` .sports-follow-icon{margin:1px auto 0 4px}`,m=g.A` .sports-event-country-card{${p.f};
        width: 268px;
        color: ${d.l};text-decoration:none}._1x_1y .sports-event-country-card{height:65px}._1x_2y .sports-event-country-card{height:230px}._1x_3y .sports-event-country-card{height:380px}.sports-event-country-follow{display:flex;flex-direction:column;align-items:center;margin-bottom:4px}.sports-country-follow{display:flex;width:100%;align-items:center;margin-bottom:6px}.sports-country-content{display:flex;align-items:center;justify-content:center;color:${d.l};font-size:15px;font-weight:600;overflow:hidden}.sports-country-icon{width:24px;height:24px;margin:0 8px 0 0}.sports-follow-icon{position:relative;cursor:pointer;margin:0 -2px 0 auto;width:24px;height:24px;border:none;background:none;padding:0;border-radius:50%;overflow:hidden;display:flex;justify-content:center;align-items:center}.sports-follow-icon::before{content:'';position:absolute;top:50%;left:50%;width:18px;height:18px;background-color:rgba(255,255,255,0.9);border-radius:50%;transform:translate(-50%,-50%)}.icon-selected{position:relative;object-fit:cover;border-radius:50%;width:18px;height:18px}.icon-add{position:relative;object-fit:cover;border-radius:50%;width:24px;height:24px}.icon-add-light{display:block}.icon-add-dark{display:none}.icon-hide{display:none}.sports-medal-count{width:268px;height:64px;display:flex;background:var(--sports-item-background);border-radius:6px;color:${d.l}}.sports-medal-count:hover,.sports-medal-count:focus-visible{background:var(--sports-item-hover-background)}._1x_1y .sports-country-follow{margin-bottom:2px}._1x_3y .sports-country-follow{margin-bottom:12px}._1x_1y .sports-medal-count{height:38px}._1x_3y .sports-medal-count{height:74px}.sports-medal-item-panel{display:flex;justify-content:center;align-items:center}.sports-medal-item{display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;width:65px}._1x_1y .sports-medal-item{flex-direction:row}.sports-medal-item p,.sports-medal-total-medals{margin:0;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);font-weight:600}.sports-medal-icon{width:16px;height:16px}.sports-medal-divider{width:1px;height:45px;background:var(--color-neutral-stroke-1);border-radius:4px}._1x_1y .sports-medal-divider{height:25px}.sports-medal-total{flex-grow:1;display:flex;justify-content:center;flex-direction:column;align-items:center}._1x_1y .sports-medal-total{flex-direction:row}.sports-medal-total-text{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);font-weight:600;margin:2px 0px 1px 0px}.sports-medal-total-medals{margin:0}._1x_1y .sports-medal-total p{margin-right:4px;padding-top:2px}._1x_1y .sports-medal-icon{margin-inline-end:6px}.sports-medal-count-number{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);font-weight:700}._1x_3y .sports-event-country-follow{margin-bottom:12px}`.withBehaviors(new c.t(v,x),new h.N(null,u));var f=i(96950),b=i(69259),y=i(39957),$=i(58792);const w=f.qy`
    <div class="sports-country-follow">
        <div class="sports-country-content">
            ${(0,b.z)(e=>e.viewModel.leagueLogoUrl,f.qy`
                <img src="${e=>e.viewModel.leagueLogoUrl}" class="sports-country-icon" onerror="this.style.visibility='hidden'" alt="" />
            `)}
            ${e=>{var t;return null===(t=e.viewModel.teamMedalCount)||void 0===t||null===(t=t.team)||void 0===t?void 0:t.name}}
        </div>
        <button
            class="sports-follow-icon"
            type="button"
            tabindex="0"
            aria-label="${e=>e.getFollowItemButtonTitle()}"
            title="${e=>e.getFollowItemButtonTitle()}"
            data-t="${e=>e.isFollowed?e.viewModel.unFollowTelemetryTag:e.viewModel.followTelemetryTag}"
            @click="${e=>e.onFollowClick()}"
        >
            <img
                src="${(0,$.rA)().StaticsUrl}latest/sports/icons/OlympicFollow.svg"
                class="${e=>e.isFollowed?"icon-selected":"icon-hide"}"
                alt=""
                onerror="this.style.visibility='hidden'"
            />
            <img
                src="${(0,$.rA)().StaticsUrl}latest/sports/icons/CircleAddLarge.svg"
                class="${e=>e.isFollowed?"icon-hide":"icon-add icon-add-light"}"
                alt=""
                onerror="this.style.visibility='hidden'"
            />
            <img
                src="${(0,$.rA)().StaticsUrl}latest/sports/icons/CircleAddLargeDark.svg"
                class="${e=>e.isFollowed?"icon-hide":"icon-add icon-add-dark"}"
                alt=""
                onerror="this.style.visibility='hidden'"
            />
        </button>
    </div>
`,k=f.qy`
    <div class="sports-medal-item-panel">    
        <div class="sports-medal-item">
            <img src="${(0,$.rA)().StaticsUrl}latest/sports/icons/Olympic${e=>e.medal}.svg" class="sports-medal-icon" onerror="this.style.visibility='hidden'" alt="" />
            <div class="sports-medal-count-number">
                ${e=>e.count||0}
            </div>
            <p>
                ${(0,b.z)((e,t)=>"_1x_1y"!==t.parent.viewModel.cardSize,e=>e.name)}
            </p>
        </div>
        <div class="sports-medal-divider"></div>
    </div>
`,_=f.qy`
      <div class="sports-medal-count">
        ${(0,y.ux)(e=>e.getMedalCountList(),k)}
        <div class="sports-medal-total">
            <p class="sports-medal-total-text">
                ${e=>{var t;return null===(t=e.viewModel.strings)||void 0===t?void 0:t.total}}
            </p>
            <div class="sports-medal-count-number">
                ${e=>{var t;return(null===(t=e.viewModel.teamMedalCount)||void 0===t||null===(t=t.medalsWon)||void 0===t?void 0:t.Total)||0}}
            </div>
            ${(0,b.z)(e=>"_1x_1y"!==e.viewModel.cardSize,f.qy`
                <p class="sports-medal-total-medals">
                    ${e=>{var t;return null===(t=e.viewModel.strings)||void 0===t?void 0:t.medals}}
                </p>    
            `)}
        </div>
    </div>
`,z=f.qy`
    <div class="sports-event-country-follow">
        ${w}
        ${_}
    </div>
`,C=f.qy`
    ${e=>{var t;return null===(t=e.viewModel.listView)||void 0===t?void 0:t.viewTemplate}}
`,F=f.qy`
    <a class="sports-event-country-card ${e=>e.viewModel.cardSize}" href="${e=>e.viewModel.destinationUrl}" target="_blank" data-t="${e=>e.viewModel.telemetryTag}">
        ${z}
        ${(0,b.z)(e=>"_1x_1y"!==e.viewModel.cardSize,C)}
    </a>
`,S=f.qy`
    ${(0,b.z)(e=>e&&null!=e.viewModel,F)}
`;let T=class extends s{};T=(0,o.Cg)([(0,a.E)({name:"sports-event-country",template:S,styles:m})],T)},84564(e,t,i){i.d(t,{z(){return l}});var o=i(56911),r=i(60815),n=i(92011);class l extends n.L{}(0,o.Cg)([r.sH],l.prototype,"viewModel",void 0)},92079(e,t,i){i.d(t,{a(){return l}});var o=i(56911),r=i(92011),n=i(31525);let l=class extends r.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};l=(0,o.Cg)([n.x],l)},96041(e,t,i){i.r(t),i.d(t,{SportsInfoList(){return _}});var o=i(56911),r=i(92011),n=i(74849),l=i(22131),s=i(61138),a=i(41123),d=i(62047),c=i(4968),p=i(12640);const h=n.A` .info-list{color:rgba(255,255,255,1)}.divider>div:not(:first-child){border-top:1px solid rgba(255,255,255,0.1)}.list-content{background:rgba(26,26,26,0.5)}`,g=n.A` .list-container{text-decoration:none;${c.f}}.info-list{width:268px;height:fit-content;display:flex;flex-direction:column;color:rgba(36,36,36,1)}.list-header{display:flex;flex-direction:row;justify-content:space-between;margin-bottom:6px;align-items:baseline}.list-title{font-weight:600;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px)}.list-sub-title{font-weight:600;font-size:${s.k}}.list-content{display:flex;flex-direction:column;width:100%;border-radius:8px;background:rgba(255,255,255,0.5);padding:0 12px;box-sizing:border-box;overflow:hidden}.hero-bg{background:var(--sports-item-background)}.hero-bg:hover,.hero-bg:focus-visible{background:var(--sports-item-hover-background)}.list-content._1x_1y{max-height:42px}.list-content._1x_2y{max-height:200px}.list-content._1x_3y{max-height:358px}._1x_1y.list-header{margin-bottom:4px}._1x_1y .list-title{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}._1x_1y .list-sub-title{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.divider>div:not(:first-child){border-top:1px solid rgba(0,0,0,0.05)}.content-item{display:flex;flex-direction:row;align-items:center;gap:8px;height:50px;box-sizing:border-box}.content-item .hero-bg{border-radius:8px}.content-item.small{height:50px;padding:9px 0px;&>img{width:32px;height:32px};&>.content-middle{height:32px}}._1x_1y>.content-item.small{height:42px;&>.content-middle{height:32px}}.content-item.medium{height:66px;padding:6px 0px;&>img{width:40px;height:40px}}.content-item.large{height:96px;padding:12px 0px;&>img{width:54px;height:54px}}.content-middle{display:flex;flex-direction:column;justify-content:space-between;height:38px;width:100%;flex-grow:2;min-width:0}.content-title{font-weight:600;font-size:${a.K};
        line-height: ${a.Z};text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.small>.content-middle>.content-title{font-size:${s.k};
        line-height: ${s.F}}.content-sub-title{font-weight:400;font-size:${s.k};
        line-height: ${s.F};white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.small>.content-middle>.content-sub-title{font-size:${d.t};
        line-height: ${d.e}}.content-des{font-weight:600;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);white-space:nowrap}.small>.content-des{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}`.withBehaviors(new p.N(null,h),(0,l.mr)(n.A` :host{forced-color-adjust:auto}`));var u=i(96950),v=i(69259),x=i(50180),m=i(39957);const f=u.qy`
    <div class="content-item ${(e,t)=>t.parent.viewModel.itemSize} ${(e,t)=>t.parent.viewModel.hasItemBg?"hero-bg":""}" style="${e=>e.itemStyle?e.itemStyle:""}">
        ${(0,v.z)(e=>e.icon&&!(0,x.oT)(e.icon),u.qy`
            <img
                class="content-icon"
                style="${e=>e.iconStyle?e.iconStyle:""}"
                role="presentation"
                onerror="this.style.visibility='hidden'"
                src="${e=>e.icon}"/>`)}
        <div class="content-middle" style="${e=>e.contentMiddleStyle||""}">
            <div class="content-title" title="${e=>e.title}">${e=>e.title}</div>
            <div class="content-sub-title" title="${e=>e.subTitle}">${e=>e.subTitle}</div>
        </div>
        ${(0,v.z)(e=>e.des&&!(0,x.oT)(e.des),u.qy`
            <div class="content-des" style="${e=>e.desStyle?e.desStyle:""}">${e=>e.des}</div>
        `)}
    </div>
`,b=u.qy`
    <div class="list-header ${e=>e.viewModel.cardSize}">
        <div class="list-title" title="${e=>e.viewModel.title}">${e=>e.viewModel.title}</div>
        ${(0,v.z)(e=>e.viewModel.subTitle,u.qy`<div class="list-sub-title" title="${e=>e.viewModel.subTitle}">${e=>e.viewModel.subTitle}</div>`)}
    </div>
`,y=u.qy`
    <a 
        class="${e=>e.viewModel.clickThroughUrl?"list-container":""}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="_blank"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        <div class="info-list">
            ${(0,v.z)(e=>e.viewModel.title||e.viewModel.subTitle,b)}
            <div class="
                list-content
                ${e=>e.viewModel.cardSize}
                ${e=>e.viewModel.showDivider?"divider":""}
                ${e=>e.viewModel.hasItemBg?"":"hero-bg"}
            "
                style="${e=>e.viewModel.listStyle?e.viewModel.listStyle:""}"
            >
                ${(0,m.ux)(e=>e.viewModel.items,f)}
            </div>
        </div>
    </a>
`,$=u.qy`
    ${(0,v.z)(e=>null!=e.viewModel,y)}
`;var w=i(84564);class k extends w.z{}let _=class extends k{};_=(0,o.Cg)([(0,r.E)({name:"sports-info-list",template:$,styles:g,shadowOptions:{delegatesFocus:!0}})],_)},99657(e,t,i){i.d(t,{D(){return l},I(){return n}});var o=i(45755);const{create:r}=o.G,n=r("sloppy-click-z-index",1),l=r("click-z-index",1)}}]);