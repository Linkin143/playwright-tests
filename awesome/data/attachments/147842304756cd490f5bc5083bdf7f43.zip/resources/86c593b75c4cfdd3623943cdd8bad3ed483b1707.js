"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["qna-card"],{5675(t,i,e){e.d(i,{S(){return a}});var r=e(96950);function a(){return r.qy`
        <template slot="tabpanel" role="tabpanel">
            <slot></slot>
        </template>
    `}},5993(t,i,e){e.d(i,{V(){return o},m(){return n}});var r=e(47264),a=e(73182),s=e(96950);a.MsnActionsMenu;const o=function(t,i,e,a){let o=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"more-actions",n=arguments.length>5&&void 0!==arguments[5]&&arguments[5];return s.qy`
        <fluent-button
            slot="${o}"
            appearance="neutral"
            class=${a??""}
            @click=${t}
            data-t=${t=>i}
            title="${e}"
            aria-label="${e}"
            aria-expanded="${n}"
            role="button"
        >
            ${s.qy.partial(r.A)}
        </fluent-button>
    `},n=function(t,i,e){let r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"end";return s.qy`
        <msn-actions-menu 
            :referrerButton=${i=>t}
            :menuItems=${t=>i}
            :useFastAnchoredRegion=${t=>!0!==e}
            defaultHorizontalPosition=${r}
        />
    `}},6769(t,i,e){e.r(i),e.d(i,{HeroImage(){return tt},HeroImageLarge(){return it},Qna(){return N},QnaImagePairSingleQnaTemplateCard(){return rt},QnaImagePairTemplate(){return et},QnaImagePairTemplateCard(){return at},QnaImagePairTemplateCards(){return st},QnaStyles(){return pt},QnaTemplate(){return nt},ToolingInfo(){return ut}});var r=e(4731),a=e(37180),s=e(45899),o=e(44767),n=e(73079),l=e(15961),h=e(93533),d=e(37510),c=e(12717),p=e(8092),u=e(99900),g=e(98602),v=e(77097),f=e(34019),b=e(56911),x=e(77367),$=e(85349),m=e(12680);const w="QnaCard",C="QnaCard_Customization_Addremove",y="QnaCard_Customization_Datafrom",k="QnaCard_WholeCard_Navigate",T="QnaCard_Seemore",M="QnaCard_ImagePair",q="QnaCard_PreviousFlipper",z="QnaCard_BowheadPipeline",I="QnaCard_NextFlipper",L="QnaCard_Carousel",S="QnaCard_Topic",_="QnaCard_HideCard";var A=e(58792),H=e(97266);class Z{static getInstance(){return this._instance||(this._instance=new Z)}QnaTransformation(){this.locUtility=new H.e,this.market=(0,A.rA)().CurrentMarket}TransformQnaImagePairs(t,i){return{imagePairs:t.Cards.map(t=>this.TransformQnaCardDataIntoQnaImagePair(t,i))}}TransformNTPCardData(t,i){return{seeMoreText:t.SeemoreText,seeMoreUrl:t.SeemoreUrl,title:i.title}}TransformQnaCardDataIntoQnaImagePair(t,i){let e=t.TopicImageThumbnailId;e=null==e?t.ImageThumbnailId:e;let r=null;e&&(r=i?`https://th.bing.com/th/id/${e}?w=268&h=150&c=3&qlt=85&pid=3.1`:`https://th.bing.com/th/id/${e}?w=200&h=200&c=1&qlt=85&pid=3.1`);const a=null==t.ImageUrlVNext||0==t.ImageUrlVNext.length?r:t.ImageUrlVNext;return{sourceIconUrl:`https://th.bing.com/th/id/${t.SiteIcon}?qlt=85&pid=3.1`,sourceTitle:t.SiteName,snippet:t.Title,targetUrl:t.Url,heroImageUrl:a,itemId:t.ItemId,topics:t.Topics}}}function F(t,i){i.preventDefault(),i.stopPropagation(),x.YT.sendActionEvent(i.currentTarget,$.EG.Click,$.MS.Navigate);const e=`https://www.msn.com/${A.T3.CurrentMarket}/qna/topics/${t}?ocid=msedgntp`;window.open(e)}var j=e(29658),Q=e(39671),P=e(17918),B=e(60815),D=e(38319);class N extends Q.U{constructor(){super(...arguments),this.qnaViewIndex=0,this.onClick=t=>{x.YT.sendActionEvent(t.currentTarget,$.EG.Click,$.MS.Undefined)}}experienceConnected(){if(this.extractData(),this.visuallyReadyComplete=0,null!=this.backendData||null!=this.backendData.bingStructureSegments){const t=JSON.parse(this.backendData.bingStructureSegments[0].data);null!=t.BowheadMetadata&&(this.pipelineTag=t.BowheadMetadata.PipelineTag);const i=Z.getInstance().TransformNTPCardData(t,this.strings),e=Z.getInstance().TransformQnaImagePairs(t,1===this.config.numQnaPerSlide);e.imagePairs.forEach(t=>{t.callTtvr=()=>{--this.visuallyReadyComplete,0===this.visuallyReadyComplete&&(0,P.oO)(this.getExperienceType())},this.visuallyReadyComplete<2&&this.visuallyReadyComplete++}),this.viewData={...i,...e,trendingTopics:t.TrendingTopics},this.useCarouselCard=!this.config.singleCardExperience,this.showQnaView(this.qnaViewIndex)}this.useCarouselCard&&(0,P.oO)(this.getExperienceType()),this.setupTelemetryObjects(),this.ingestTelemetryMetadata(),this.initSuperSDSetting()}getExperienceType(){return m.Qb0}extractData(){this.mapperArgs&&(this.backendData={bingStructureSegments:[this.mapperArgs.cardMetadata]},this.goToPersonalizeSettingsCallback=this.mapperArgs.goToPersonalizeSettingsCallback,this.refreshSDCardSection=this.mapperArgs.refreshSDCardSection)}initSuperSDSetting(){const t={moreSetting:{title:this.strings.moreSettings,telemetryTag:this.addRemoveQnaTelemetryTags},hideSetting:{title:this.strings.hideThisCard,telemetryTag:this.hideCardQnaTelemetryTag}};this.superSDSetting=new D.t(N,j.s.QnaCard,t,this.goToPersonalizeSettingsCallback,this.refreshSDCardSection)}clickedOnCarouselCard(t){if(!(t&&t.target&&t.target.nodeName&&"FLUENT-BUTTON"===t.target.nodeName||"MSN-ACTIONS-MENU"===t.target.nodeName)&&(t&&t.target&&t.target.nodeName&&"FLUENT-ANCHOR"===t.target.nodeName&&t.target.hasAttribute("href")&&window.open(t.currentTarget.getAttribute("href"),"_blank"),t&&t.currentTarget&&t.currentTarget.hasAttribute("href")&&t.path)){let i=!1,e="";t.path.forEach(t=>{!i&&t&&t.classList&&t.classList.length>0&&(t.classList.contains("crd_lnk")||t.classList.contains("wcl"))&&t.hasAttribute("href")&&(i=!0,e=t.getAttribute("href"))}),i&&window.open(e,"_blank")}}showQnaView(t){const i=t%(this.viewData.imagePairs.length/this.config.numQnaPerSlide),e=i*this.config.numQnaPerSlide;this.imagePairs=this.viewData.imagePairs.slice(e,e+this.config.numQnaPerSlide),this.imagePairs.length==this.config.numQnaPerSlide&&(this.qnaViewIndex=i)}ingestTelemetryMetadata(){}setupTelemetryObjects(){if(null!=this.telemetryObject){this.qnaTelemetryObject=this.telemetryObject.addOrUpdateChild({name:w,action:$.EG.View,type:$.MJ.Module,behavior:$.MS.View,content:{id:w,type:$.b5.StructuredData},ext:this.telemetryExt}),this.viewData.wholeCardTelemetryTag=this.qnaTelemetryObject.getMetadataTag(),this.viewData.wholeCardClickTelemetryTag=this.qnaTelemetryObject.addOrUpdateChild({name:k,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Navigate,content:{id:k,type:$.b5.StructuredData,headline:"Navigate"},ext:this.telemetryExt}).getMetadataTag(),this.viewData.seeMoreClickTelemetryTag=this.qnaTelemetryObject.addOrUpdateChild({name:T,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Navigate,content:{id:T,type:$.b5.StructuredData,headline:"Navigate"},ext:this.telemetryExt}).getMetadataTag();for(let t=0;t<this.viewData.imagePairs.length;t++){const i=this.viewData.imagePairs[t];i.imagePairTelemetryTag=this.qnaTelemetryObject.addOrUpdateChild({name:`${M}_${i.itemId}_${t}`,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Navigate,content:{id:`${M}_${i.itemId}_${t}`,type:$.b5.StructuredData,headline:"ImagePair"},ext:this.telemetryExt}).getMetadataTag();for(let t=0;i.topics&&t<i.topics.length;t++)i.topics[t].TopicTelemetryTag=this.qnaTelemetryObject.addOrUpdateChild({name:`${S}_${i.topics[t].Id}`,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Navigate,content:{id:`${S}_${i.topics[t].Id}`,type:$.b5.StructuredData,headline:"Topic"},ext:this.telemetryExt}).getMetadataTag()}for(let t=0;this.viewData.trendingTopics&&t<this.viewData.trendingTopics.length;t++)this.viewData.trendingTopics[t].TopicTelemetryTag=this.qnaTelemetryObject.addOrUpdateChild({name:`${S}_${this.viewData.trendingTopics[t].Id}`,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Navigate,content:{id:`${S}_${this.viewData.trendingTopics[t].Id}`,type:$.b5.StructuredData,headline:"Topic"},ext:this.telemetryExt}).getMetadataTag();this.addRemoveQnaTelemetryTags=this.qnaTelemetryObject.addOrUpdateChild({name:C,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Open,content:{id:C,type:$.b5.StructuredData,headline:"Add or Remove cards"},ext:this.telemetryExt}).getMetadataTag(),this.dataFromQnaTelemetryTags=this.qnaTelemetryObject.addOrUpdateChild({name:y,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Open,content:{id:y,type:$.b5.StructuredData,headline:"Data from"},ext:this.telemetryExt}).getMetadataTag(),this.qnaTelemetryObject&&this.qnaTelemetryObject.addOrUpdateChild({name:_,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Hide,content:{id:_,type:$.b5.StructuredData,headline:"Hide card"}}).getMetadataTag(),this.viewData.previousFlipperTelemetryTags=this.qnaTelemetryObject.addOrUpdateChild({name:q,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Undefined,content:{id:q,type:$.b5.StructuredData,headline:"Previous flipper"},ext:this.telemetryExt}).getMetadataTag(),this.viewData.nextFlipperTelemetryTags=this.qnaTelemetryObject.addOrUpdateChild({name:I,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Undefined,content:{id:I,type:$.b5.StructuredData,headline:"Next flipper"},ext:this.telemetryExt}).getMetadataTag(),this.viewData.carouselClickTelemetryTags=this.qnaTelemetryObject.addOrUpdateChild({name:L,action:$.EG.Click,type:$.MJ.ActionButton,behavior:$.MS.Undefined,content:{id:L,type:$.b5.StructuredData,headline:"Carousel Click"},ext:this.telemetryExt}).getMetadataTag(),this.viewData.pipelineTelemetryTag=this.qnaTelemetryObject.addOrUpdateChild({name:`${z}_${this.pipelineTag}`,action:$.EG.View,type:$.MJ.Module,behavior:$.MS.View,content:{id:z,type:$.b5.StructuredData,headline:this.pipelineTag}}).getMetadataTag()}}}(0,b.Cg)([B.sH],N.prototype,"qnaViewIndex",void 0),(0,b.Cg)([B.sH],N.prototype,"imagePairs",void 0),(0,b.Cg)([B.sH],N.prototype,"superSDSetting",void 0);var U=e(96950);U.qy`
<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
    <path d="M6 10a1.25 1.25 0 11-2.5 0A1.25 1.25 0 016 10z" />
    <path d="M11.25 10a1.25 1.25 0 11-2.5 0 1.25 1.25 0 012.5 0z" />
    <path d="M15.25 11.25a1.25 1.25 0 100-2.5 1.25 1.25 0 000 2.5z" />
</svg>
`,U.qy`
<svg width="16" height="16" viewBox="0 0 17 17"><path d="M0.0242728 5.88266C0.393563 4.74053 1.00191 3.69213 1.80461 2.80364C1.94035 2.65339 2.15331 2.59984 2.34397 2.66802L4.26225 3.35392C4.78233 3.53977 5.35459 3.26883 5.54045 2.74875C5.55872 2.69762 5.5728 2.64507 5.58253 2.59173L5.94799 0.585725C5.98432 0.386273 6.1375 0.228505 6.3358 0.186297C6.91599 0.0628015 7.51086 0 8.11354 0C8.71584 0 9.31037 0.0627251 9.89022 0.186072C10.0885 0.228241 10.2416 0.38591 10.2781 0.585286L10.6445 2.59165C10.7436 3.13497 11.2644 3.4951 11.8077 3.39601C11.8611 3.38627 11.9137 3.37219 11.9647 3.35395L13.8831 2.66802C14.0738 2.59984 14.2867 2.65339 14.4225 2.80364C15.2252 3.69213 15.8335 4.74053 16.2028 5.88266C16.2651 6.07534 16.205 6.28658 16.0507 6.41764L14.4958 7.73773C14.0748 8.0952 14.0233 8.72627 14.3808 9.14726C14.416 9.18865 14.4544 9.22712 14.4958 9.26225L16.0507 10.5824C16.205 10.7134 16.2651 10.9247 16.2028 11.1173C15.8335 12.2595 15.2252 13.3079 14.4225 14.1964C14.2867 14.3466 14.0738 14.4002 13.8831 14.332L11.9648 13.6461C11.4447 13.4602 10.8725 13.7312 10.6866 14.2512C10.6684 14.3024 10.6543 14.3549 10.6445 14.4085L10.2781 16.4147C10.2416 16.6141 10.0885 16.7718 9.89022 16.8139C9.31037 16.9373 8.71584 17 8.11354 17C7.51086 17 6.91599 16.9372 6.3358 16.8137C6.1375 16.7715 5.98432 16.6137 5.94799 16.4143L5.58254 14.4084C5.48346 13.865 4.96268 13.5049 4.41936 13.604C4.36593 13.6137 4.31339 13.6278 4.26234 13.6461L2.34397 14.332C2.15331 14.4002 1.94035 14.3466 1.80461 14.1964C1.00191 13.3079 0.393563 12.2595 0.0242728 11.1173C-0.038028 10.9247 0.0220447 10.7134 0.176415 10.5824L1.73126 9.26227C2.15225 8.9048 2.20374 8.27373 1.84627 7.85274C1.81112 7.81135 1.77265 7.77288 1.73128 7.73775L0.176415 6.41764C0.0220447 6.28658 -0.038028 6.07534 0.0242728 5.88266ZM1.08482 5.87709L2.37852 6.97546C2.46131 7.04576 2.53824 7.12269 2.60854 7.20548C3.32348 8.04746 3.2205 9.3096 2.37849 10.0246L1.08482 11.1229C1.37687 11.9051 1.79832 12.6322 2.32976 13.2751L3.92574 12.7044C4.02802 12.6679 4.1331 12.6397 4.23995 12.6202C5.3266 12.422 6.36815 13.1423 6.56633 14.229L6.8703 15.8975C7.27817 15.9655 7.69353 16 8.11354 16C8.53327 16 8.94834 15.9656 9.35595 15.8976L9.66076 14.2289C9.68025 14.1221 9.7084 14.017 9.74495 13.9147C10.1167 12.8746 11.2612 12.3327 12.3014 12.7044L13.8973 13.2751C14.4288 12.6322 14.8502 11.9051 15.1423 11.1229L13.8486 10.0245C13.7658 9.95424 13.6888 9.87731 13.6185 9.79452C12.9036 8.95254 13.0066 7.6904 13.8486 6.97544L15.1423 5.87709C14.8502 5.09486 14.4288 4.36783 13.8973 3.72494L12.3013 4.29559C12.1991 4.33214 12.094 4.3603 11.9871 4.37979C10.9005 4.57796 9.85893 3.8577 9.66078 2.77119L9.35595 1.10235C8.94834 1.03443 8.53327 1 8.11354 1C7.69353 1 7.27817 1.03448 6.8703 1.10249L6.56632 2.77105C6.54683 2.87791 6.51867 2.98299 6.48212 3.08527C6.11042 4.12542 4.96589 4.6673 3.92565 4.29556L2.32976 3.72494C1.79832 4.36783 1.37687 5.09486 1.08482 5.87709ZM5.61354 8.5C5.61354 7.11929 6.73283 6 8.11354 6C9.49425 6 10.6135 7.11929 10.6135 8.5C10.6135 9.88071 9.49425 11 8.11354 11C6.73283 11 5.61354 9.88071 5.61354 8.5ZM6.61354 8.5C6.61354 9.32843 7.28511 10 8.11354 10C8.94197 10 9.61354 9.32843 9.61354 8.5C9.61354 7.67157 8.94197 7 8.11354 7C7.28511 7 6.61354 7.67157 6.61354 8.5Z" fill-opacity="0.83"></path></svg>
`;const R=U.qy`
<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" part="glbsvg">
<path d="M6 12C9.31371 12 12 9.31371 12 6C12 2.68629 9.31371 0 6 0C2.68629 0 0 2.68629 0 6C0 9.31371 2.68629 12 6 12ZM6 1C6.37372 1 6.87543 1.35608 7.31258 2.31781C7.4073 2.52619 7.49448 2.75446 7.57265 3H4.42735C4.50552 2.75446 4.5927 2.52619 4.68742 2.31781C5.12457 1.35608 5.62628 1 6 1ZM3.77705 1.90401C3.62614 2.23601 3.49428 2.6038 3.38411 3H1.99963C2.52341 2.30269 3.22525 1.74677 4.03766 1.39978C3.94287 1.56117 3.85596 1.7304 3.77705 1.90401ZM3.16299 4C3.05694 4.6275 3 5.30146 3 6C3 6.69854 3.05694 7.3725 3.16299 8H1.41604C1.14845 7.38754 1 6.7111 1 6C1 5.2889 1.14845 4.61246 1.41604 4H3.16299ZM3.38411 9C3.49428 9.3962 3.62614 9.76399 3.77705 10.096C3.85596 10.2696 3.94287 10.4388 4.03766 10.6002C3.22525 10.2532 2.52341 9.69731 1.99963 9H3.38411ZM4.42735 9H7.57265C7.49448 9.24554 7.4073 9.47381 7.31258 9.68219C6.87543 10.6439 6.37372 11 6 11C5.62628 11 5.12457 10.6439 4.68742 9.68219C4.5927 9.47381 4.50552 9.24554 4.42735 9ZM7.82134 8H4.17866C4.06438 7.3892 4 6.71396 4 6C4 5.28604 4.06438 4.6108 4.17866 4H7.82134C7.93562 4.6108 8 5.28604 8 6C8 6.71396 7.93562 7.3892 7.82134 8ZM8.61589 9H10.0004C9.47659 9.69731 8.77475 10.2532 7.96234 10.6002C8.05713 10.4388 8.14404 10.2696 8.22295 10.096C8.37386 9.76399 8.50572 9.3962 8.61589 9ZM10.584 8H8.83701C8.94306 7.3725 9 6.69854 9 6C9 5.30146 8.94306 4.6275 8.83701 4H10.584C10.8516 4.61246 11 5.2889 11 6C11 6.7111 10.8516 7.38754 10.584 8ZM7.96234 1.39978C8.77475 1.74677 9.47659 2.30269 10.0004 3H8.61589C8.50572 2.6038 8.37386 2.23601 8.22295 1.90401C8.14404 1.7304 8.05713 1.56117 7.96234 1.39978Z" fill-opacity="0.83" part="glbpath"/>
</svg>`,O=U.qy`
<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" part="glbsvg">
<path fill="white" d="M6 12C9.31371 12 12 9.31371 12 6C12 2.68629 9.31371 0 6 0C2.68629 0 0 2.68629 0 6C0 9.31371 2.68629 12 6 12ZM6 1C6.37372 1 6.87543 1.35608 7.31258 2.31781C7.4073 2.52619 7.49448 2.75446 7.57265 3H4.42735C4.50552 2.75446 4.5927 2.52619 4.68742 2.31781C5.12457 1.35608 5.62628 1 6 1ZM3.77705 1.90401C3.62614 2.23601 3.49428 2.6038 3.38411 3H1.99963C2.52341 2.30269 3.22525 1.74677 4.03766 1.39978C3.94287 1.56117 3.85596 1.7304 3.77705 1.90401ZM3.16299 4C3.05694 4.6275 3 5.30146 3 6C3 6.69854 3.05694 7.3725 3.16299 8H1.41604C1.14845 7.38754 1 6.7111 1 6C1 5.2889 1.14845 4.61246 1.41604 4H3.16299ZM3.38411 9C3.49428 9.3962 3.62614 9.76399 3.77705 10.096C3.85596 10.2696 3.94287 10.4388 4.03766 10.6002C3.22525 10.2532 2.52341 9.69731 1.99963 9H3.38411ZM4.42735 9H7.57265C7.49448 9.24554 7.4073 9.47381 7.31258 9.68219C6.87543 10.6439 6.37372 11 6 11C5.62628 11 5.12457 10.6439 4.68742 9.68219C4.5927 9.47381 4.50552 9.24554 4.42735 9ZM7.82134 8H4.17866C4.06438 7.3892 4 6.71396 4 6C4 5.28604 4.06438 4.6108 4.17866 4H7.82134C7.93562 4.6108 8 5.28604 8 6C8 6.71396 7.93562 7.3892 7.82134 8ZM8.61589 9H10.0004C9.47659 9.69731 8.77475 10.2532 7.96234 10.6002C8.05713 10.4388 8.14404 10.2696 8.22295 10.096C8.37386 9.76399 8.50572 9.3962 8.61589 9ZM10.584 8H8.83701C8.94306 7.3725 9 6.69854 9 6C9 5.30146 8.94306 4.6275 8.83701 4H10.584C10.8516 4.61246 11 5.2889 11 6C11 6.7111 10.8516 7.38754 10.584 8ZM7.96234 1.39978C8.77475 1.74677 9.47659 2.30269 10.0004 3H8.61589C8.50572 2.6038 8.37386 2.23601 8.22295 1.90401C8.14404 1.7304 8.05713 1.56117 7.96234 1.39978Z" fill-opacity="0.83"/>
</svg>`;var E=e(39957),V=e(69259),W=e(73182),X=e(72017),Y=e(5993);W.MsnActionsMenu;const G=U.qy` ${t=>{var i,e;return(0,Y.m)(null===(i=t.superSDSetting)||void 0===i?void 0:i.actionsMenuButtonElement,null===(e=t.superSDSetting)||void 0===e?void 0:e.menuItems)}}
`,J=U.qy` ${(t,i)=>(0,Y.V)(()=>{var e;return null===(e=t.superSDSetting)||void 0===e?void 0:e.toggleActionMenu(!t.superSDSetting.isActionMenuOpen,i.event)},t.addRemoveQnaTelemetryTags,t.strings.moreOptionsTooltip,"toggle-button")}
`,K=U.qy`<div class="lt_actnmn">${J} ${(0,V.z)(t=>{var i;return null===(i=t.superSDSetting)||void 0===i?void 0:i.isActionMenuOpen},G)}</div>`,tt=(t,i)=>U.qy`<div class="ipr" part="ipr"><div class="imgctr" part="imgctr"><img src="${t}" width="76px" height="76px" style="border-radius: 6px;" part="iprimg" @load=${i} @error=${i} /><div class="glb" part="iprglb">${R}</div></div></div>`,it=t=>U.qy`<div part="imgLarge"><img src="${t.heroImageUrl}" style="border-radius: 6px; height: 150px; width: 100%" part="iprimg" /><div part="imgTopRow"><div part="docsrc"><img src="${t.sourceIconUrl}" width="16px" height="16px" /><div part="srcttll">${t.sourceTitle}</div></div><div part="iprglbl">${O}</div></div><div part="topics">${(0,E.ux)(()=>t.topics,U.qy`<div @click=${(t,i)=>F(t.Id,i.event)} data-t="${t=>t.TopicTelemetryTag}" part="topic">${t=>t.Name}</div>`)}</div></div>`,et=U.qy`<div class="fl sa"><a href="${t=>t.targetUrl}" title="${t=>t.snippet}" class="crd_lnk" target="_blank" data-t="${t=>t.imagePairTelemetryTag}"><div class="fl sb qip"><div class="ipl"><div class="fl actr srcpb"><img src="${t=>t.sourceIconUrl}" width="16px" height="16px" /><div class="rm1 b55 srcttl">${t=>t.sourceTitle}</div></div><div class="albs thrlmt">${t=>t.snippet}</div></div>${(0,V.z)(t=>null!=t.heroImageUrl,t=>tt(t.heroImageUrl,t.callTtvr))}</div></a></div>`,rt=t=>U.qy`<div><div class="fl sa" part="flsal"><a href="${t.targetUrl}" title="${t.snippet}" class="crd_lnk" part="crd_lnk" target="_blank" data-t="${i=>t.imagePairTelemetryTag}">${(0,V.z)(()=>null!=t.heroImageUrl,()=>it(t))}<div part="doctitle">${t.snippet}</div></a></div></div>`,at=t=>U.qy`<div><div class="fl sa" part="flsa"><a href="${t.targetUrl}" title="${t.snippet}" class="crd_lnk" part="crd_lnk" target="_blank" data-t="${i=>t.imagePairTelemetryTag}"><div class="fl sb qip" part="flsbqip"><div class="ipl" part="ipl"><div class="fl actr srcpb" part="flactrsrcpb"><img src="${t.sourceIconUrl}" width="16px" height="16px" /><div class="rm1 b55 srcttl" part="srcttl">${t.sourceTitle}</div></div><div class="albs thrlmt" part="albsthrlmt">${t.snippet}</div></div>${(0,V.z)(()=>null!=t.heroImageUrl,()=>tt(t.heroImageUrl,t.callTtvr))}</div></a></div></div>`,st=t=>U.qy`
${(0,E.ux)(()=>t,U.qy`${at}`)}
`;function ot(t,i,e){const r=(0,X.A)(i.imagePairs,e).map(r=>({tabContent:U.qy`<div @click=${(i,e)=>t.clickedOnCarouselCard(e.event)} href="${i.seeMoreUrl}">${(0,V.z)(()=>e>1,st(r))} ${(0,V.z)(()=>1===e,rt(r[0]))}<div class="fl sa" part="flsa"><fluent-anchor class="footer-anchor sd-action" href="${i.seeMoreUrl}" title="${i.seeMoreText}" target="_blank" data-t="${t=>i.seeMoreClickTelemetryTag}" part="fancr">${i.seeMoreText}</fluent-anchor></div></div>`}));return r.push({tabContent:U.qy`<div @click=${(i,e)=>t.clickedOnCarouselCard(e.event)} href="${i.seeMoreUrl}">${()=>(t=>U.qy`<div><div part="flsafdc"><div part="topic-card-img">More trending Q&A topics recommended for you</div><div part="trendTopics">${(0,E.ux)(()=>t.trendingTopics,U.qy`<div @click=${(t,i)=>F(t.Id,i.event)} data-t="${t=>t.TopicTelemetryTag}" part="trendTopic">${t=>t.Name}</div>`)}</div></div></div>`)(i)}<div class="fl sa" part="flsa"><fluent-anchor class="footer-anchor sd-action" href="${i.seeMoreUrl}" title="${i.seeMoreText}" target="_blank" data-t="${t=>i.seeMoreClickTelemetryTag}" part="fancr">${i.seeMoreText}</fluent-anchor></div></div>`}),r}const nt=U.qy`
${(0,V.z)(t=>!0===t.useCarouselCard,t=>{return i=t.viewData,e=t,U.qy`<div class="wcl" title="${i.seeMoreText}" href="${i.seeMoreUrl}" target="_blank" data-t="${t=>i.wholeCardClickTelemetryTag}"><div data-t="${t=>i.wholeCardTelemetryTag}" class="qna_ctr"><div data-t="${t=>i.pipelineTelemetryTag}"><div class="fl sb actr crdttl" href="${i.seeMoreUrl}" @click=${(t,i)=>e.clickedOnCarouselCard(i.event)}><div class"b55 rm1">${t=>t.config.useTitle2?t.strings.title2:i.title}</div>${K}</div><div class="fl sb fdc fdchtcc" data-t="${t=>i.carouselClickTelemetryTags}"><msft-carousel-card :contentData="${t=>ot(e,i,t.config.numQnaPerSlide)}" :previousFlipperTelemetryTag=${t=>i.previousFlipperTelemetryTags} :nextFlipperTelemetryTag=${t=>i.nextFlipperTelemetryTags} class="qna-carousel-card" auto-scroll="${t=>t.config.autoRotate}" auto-scroll-interval-ms="10000"></msft-carousel-card></div></div></div></div>`;var i,e})}
${(0,V.z)(t=>!1===t.useCarouselCard,t=>{return i=t.viewData,U.qy`<a class="wcl" title="${i.seeMoreText}" href="${i.seeMoreUrl}" target="_blank" data-t="${t=>i.wholeCardClickTelemetryTag}"><div data-t="${t=>i.wholeCardTelemetryTag}" class="qna_ctr"><div data-t="${t=>i.pipelineTelemetryTag}"><div class="fl sb actr crdttl"><div class"b55 rm1">${i.title}</div>${K}</div><div class="fl sb fdc fdcht"><div>${(0,E.ux)(t=>t.imagePairs,U.qy`${et}`)}</div><div class="fl sa"><fluent-anchor class="footer-anchor sd-action" href="${i.seeMoreUrl}" title="${i.seeMoreText}" target="_blank" data-t="${t=>i.seeMoreClickTelemetryTag}">${i.seeMoreText}</fluent-anchor></div></div></div></div></a>`;var i})}
`;var lt=e(74849),ht=e(48751),dt=e(37302),ct=e(95239);const pt=lt.A`
:host{border-radius:6px;max-width:268px;font-family:"Segoe UI SemiBold","Segoe UI",Arial,Sans-Serif}.qna_ctr{width:300px;height:304px;border-radius:6px;background:linear-gradient(160deg,rgba(200,220,243,0.1),rgba(200,220,243,0.4)),#FFFFFF}a.wcl:-webkit-any-link{text-decoration:none;color:inherit}.wcl{cursor:pointer}.fl{display:flex}.qna-carousel-card{height:100%}.qna-carousel-card::part(flsa),.qna-carousel-card::part(flsal){display:flex;justify-content:space-around}.qna-carousel-card::part(flsal):hover{background:rgba(0,0,0,0.05);cursor:pointer}.qna-carousel-card::part(flsafdc){display:flex;justify-content:space-around;flex-direction:column}.qna-carousel-card::part(flsbqip){display:flex;justify-content:space-between;width:292px;height:104px}.qna-carousel-card::part(flsbqip):hover{background:rgba(0,0,0,0.05);cursor:pointer}.qna-carousel-card::part(flsbqipl){display:flex;justify-content:space-between;width:292px;height:85px}.qna-carousel-card::part(flactrsrcpb){display:flex;align-items:center;padding-bottom:4px}.qna-carousel-card::part(albsthrlmt){font-size:14px;line-height:20px;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;text-overflow:ellipsis}.qna-carousel-card::part(crd_lnk){text-decoration:none;color:inherit}.qna-carousel-card::part(ipl){padding:8px 8px 16px 12px}.qna-carousel-card::part(srcttl){font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:rgba(0,0,0,0.55);padding-left:8px;padding-right:6px}.qna-carousel-card::part(ipr){padding:12px 12px 16px 0px}.qna-carousel-card::part(imgctr){position:relative}.qna-carousel-card::part(iprimg){z-index:1}.qna-carousel-card::part(iprglb){position:absolute;top:4px;left:4px;z-index:3;width:20px;height:20px;border-radius:4px;background:rgba(255,255,255,0.55)}.qna-carousel-card::part(glbsvg){padding-top:4px;padding-left:4px;padding-right:4px}.qna-carousel-card::part(glbpath){fill:black}.qna-carousel-card::part(fancr){border-radius:20px;height:24px;font-family:"Segoe UI","Segoe UI Midlevel","Segoe WP",Arial,sans-serif;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);margin-top:8px}.dnn{display:none}.sb{justify-content:space-between}.sa{justify-content:space-around}.actr{align-items:center}.srcpb{padding-bottom:4px}fluent-button path{fill:black}fluent-button::part(content)::before{height:0px}.qip{width:292px;height:104px}.qip:hover{background:rgba(0,0,0,0.05);cursor:pointer}.ipl{padding:8px 8px 16px 12px}.ipr{padding:12px 12px 16px 0px}.imgctr{position:relative}.ipr img{z-index:1}.imgLarge{position:relative}.imgLarge img{height:102px;width:258px}.ipr .glb{position:absolute;top:4px;left:4px;z-index:3;width:20px;height:20px;border-radius:4px;background:rgba(255,255,255,0.55)}.glb svg{position:absolute;padding:4px}.ipr path{fill:black}.rm1{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.b55{color:rgba(0,0,0,0.55)}.crdttl{padding-top:12px;padding-left:16px;padding-right:16px;font-size:var(--type-ramp-minus-1-font-size,12px);color:rgba(0,0,0,0.55);height:24px}.fdc{flex-direction:column}.fdcht{height:254px}.fdchtcc{height:272px}fluent-anchor{border-radius:20px}.srcttl{padding-left:8px;padding-right:6px}.albs{font-size:14px;line-height:20px}.ovrflw{height:100%;overflow:hidden}.thrlmt{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;text-overflow:ellipsis}.sd-action{border-radius:20px;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.footer-anchor{height:24px;font-family:Segoe UI,Segoe UI Midlevel,Segoe WP,Arial,Sans-Serif}.footer-anchor::part(control){padding:0px 24px;width:100%}a.crd_lnk:-webkit-any-link{text-decoration:none;color:inherit}.srcttl{font-family:"Segoe UI",Arial,Sans-Serif}.ellipse{display:inline-block;height:4px;width:4px;background:rgba(0,0,0,0.4458);border-radius:50%}.ellipse-selected{height:6px;width:6px}.parts{display:flex;align-items:center;padding:0px 3.5px;cursor:pointer}.pips{display:flex;flex-direction:row;justify-content:space-around;margin:auto;height:20px;position:relative}.qna-carousel-card::part(topics){position:absolute;bottom:5px;left:5px;overflow:hidden;flex-flow:row wrap;display:flex;height:27px}.qna-carousel-card::part(topic){padding:4px 12px;background:rgba(0,0,0,0.54);border-radius:6px;color:white;margin:0 5px 5px 0;transition:background-color ease-in-out 0.15s}.qna-carousel-card::part(topic):hover{background:rgba(0,0,0,0.75)}.qna-carousel-card::part(topic-card-img){width:268px;height:150px;background:linear-gradient(103.64deg,rgba(0,120,215,0.65) 16.52%,#2A6485 84.09%);border-radius:6px;margin:8px 16px 6px;color:white;font-weight:600;font-size:16px;line-height:22px;display:flex;text-align:center;align-items:center}.qna-carousel-card::part(trendTopics){margin:0 16px;overflow:hidden;flex-flow:row wrap;display:flex;height:50px}.qna-carousel-card::part(trendTopic){color:#0078D7;padding:4px 12px;background:rgba(0,120,215,0.05);border-radius:6px;margin:0 5px 5px 0;transition:background-color ease-in-out 0.15s;cursor:pointer}.qna-carousel-card::part(trendTopic):hover{background:rgba(0,120,215,0.1)}.qna-carousel-card::part(imgLarge){position:relative;margin:8px 16px 5px;border-radius:6px;overflow:hidden}.qna-carousel-card::part(imgTopRow){position:absolute;top:0px;left:0px;right:0px;display:flex;align-items:flex-start;height:60px;padding:10px 5px 0;border-radius:6px 6px 0px 0px;background:linear-gradient(180.01deg,rgba(53,52,60,0.8) 18.14%,rgba(53,52,60,0) 60.66%)}.qna-carousel-card::part(docsrc){display:flex;align-items:center;padding-bottom:4px;flex:1}.qna-carousel-card::part(srcttll){font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:#FFFFFF;padding-left:8px}.qna-carousel-card::part(srcttll),.qna-carousel-card::part(topic),.qna-carousel-card::part(trendTopic){font-family:"Segoe UI",Arial,Sans-Serif}.qna-carousel-card::part(iprglbl){width:20px;height:20px;border-radius:4px;background:rgba(0,0,0,0.55)}.qna-carousel-card::part(doctitle){font-size:16px;line-height:22px;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;text-overflow:ellipsis;padding:0 12px 5px 16px}@media (prefers-color-scheme:dark){.crdttl,.b55,.qna-carousel-card::part(srcttl){color:${ht.l}}.qip:hover,.qna-carousel-card::part(flsbqip):hover,.qna-carousel-card::part(flsal):hover{background:${dt.F7}}fluent-button path{fill:${ht.l}}.qna_ctr{background:${ct.p}}}.toggle-button{border-radius:16px;height:24px;min-width:24px;width:24px}`,ut={experienceConfigSchema:undefined};r.m.define(a.c.registry),s.m.define(a.c.registry),o.m.define(a.c.registry),n.m.define(a.c.registry),l.m.define(a.c.registry),h.m.define(a.c.registry),d.m.define(a.c.registry),c.m.define(a.c.registry),p.vQ.define(u.i.registry),g.FN.define(u.i.registry),v.iH.define(u.i.registry),f.dx.define(u.i.registry)},8092(t,i,e){e.d(i,{vQ(){return g}});var r=e(56911),a=e(60815),s=e(92135);(0,r.Cg)([a.sH],class{}.prototype,"tabContent",void 0);class o extends s.hN{contentDataChanged(){this.setTitles(this.activeTabIndex)}changeHandler(t){if(t.defaultPrevented)return!1;if(t.target instanceof s.hN){const i=t.target;return this.setTitles(i.activeTabIndex),!1}return!0}setTitles(t){if(!this.contentData||!this.contentData.length)return;const i=this.contentData.length,e=0===t?i-1:t-1,r=i-1===t?0:t+1;this.nextFlipperTitle=this.contentData[r].ariaLabel,this.previousFlipperTitle=this.contentData[e].ariaLabel}}(0,r.Cg)([a.sH],o.prototype,"contentData",void 0),(0,r.Cg)([a.sH],o.prototype,"nextFlipperTitle",void 0),(0,r.Cg)([a.sH],o.prototype,"previousFlipperTitle",void 0);var n=e(96950),l=e(39957);const h=n.qy`<msft-carousel-card-sequence-indicator class="sequence-indicator" part="sequence-indicator" aria-label=${(t,i)=>t.ariaLabel} slot="tab" id=${(t,i)=>t.tabId}></msft-carousel-card-sequence-indicator>`,d=n.qy`<msft-carousel-card-panel class="carousel-card-panel" part="carousel-card-panel" id=${(t,i)=>t.tabPanelId} slot="tabpanel">${(t,i)=>t.tabContent}</msft-carousel-card-panel>`,c=n.qy`<msft-carousel-card-wrapper exportparts="previous-flipper, tablist, next-flipper" class="carousel-card-wrapper" part="carousel-card-wrapper" layout="${t=>t.layout}" ?auto-scroll=${t=>t.autoScroll} ?activeindicator=${t=>t.activeindicator} auto-scroll-interval-ms=${t=>t.autoScrollIntervalMs} auto-scroll-delay-ms=${t=>t.autoScrollDelayMs} :nextFlipperTelemetryTag=${t=>t.nextFlipperTelemetryTag} :previousFlipperTelemetryTag=${t=>t.previousFlipperTelemetryTag} previous-flipper-title=${t=>t.previousFlipperTitle} next-flipper-title=${t=>t.nextFlipperTitle} :direction=${t=>t.direction} orientation=${t=>t.orientation} activeid=${t=>t.activeid} initial-id=${t=>t.initialId} @change=${(t,i)=>t.changeHandler(i.event)}>${(0,l.ux)(t=>t.contentData,d)} ${(0,l.ux)(t=>t.contentData,h)}</msft-carousel-card-wrapper>`,p=e(74849).A``;var u=e(99900);const g=o.compose({name:`${u.i.prefix}-carousel-card`,template:c,styles:p})},10103(t,i,e){e.d(i,{y(){return a}});var r=e(92011);class a extends r.L{}},12717(t,i,e){e.d(i,{m(){return y}});var r=e(84506),a=e(37180),s=e(74849),o=e(64187),n=e(60993),l=e(73477),h=e(22131),d=e(50882),c=e(48196),p=e(48751),u=e(45476),g=e(26920),v=e(36452),f=e(79288),b=e(14996);const x=s.A`
    ${(0,o.V)("inline-flex")} :host {
        width: calc(${c.D} * 1px);
        height: calc(${c.D} * 1px);
        justify-content: center;
        align-items: center;
        margin: 0;
        position: relative;
        fill: currentcolor;
        color: ${p.l};
        background: transparent;
        border: none;
        outline: none;
        padding: 0;
    }

    :host::before {
        content: "";
        opacity: 0.8;
        background: ${u.Wl};
        border: calc(${g.XA} * 1px) solid ${v.I2};
        border-radius: 50%;
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        transition: all 0.1s ease-in-out;
    }

    .next,
    .previous {
        position: relative;
        ${""} width: 16px;
        height: 16px;
    }

    :host([disabled]) {
        opacity: ${f.q};
        cursor: ${n.Z};
    }

    :host(:hover) {
        cursor: pointer;
    }

    :host(:hover)::before {
        background: ${u.oO};
        border-color: ${v.mb};
    }

    :host(:${l.N}) {
        outline: none;
    }

    :host(:${l.N})::before {
        box-shadow: 0 0 0 1px ${b.WN} inset;
        border-color: ${b.WN};
    }

    :host(:active)::before {
        background: ${u.wO};
        border-color: ${v.MY};
    }

    :host::-moz-focus-inner {
        border: 0;
    }
`.withBehaviors((0,h.mr)(s.A`
            :host {
                background: ${d.A.Canvas};
            }
            :host .next,
            :host .previous {
                color: ${d.A.ButtonText};
                fill: currentcolor;
            }
            :host::before {
                background: ${d.A.Canvas};
                border-color: ${d.A.ButtonText};
            }
            :host(:hover)::before {
                forced-color-adjust: none;
                background: ${d.A.Highlight};
                border-color: ${d.A.ButtonText};
                opacity: 1;
            }
            :host(:hover) .next,
            :host(:hover) .previous {
                forced-color-adjust: none;
                color: ${d.A.HighlightText};
                fill: currentcolor;
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled])::before,
            :host([disabled]:hover)::before,
            :host([disabled]) .next,
            :host([disabled]) .previous,
            :host([disabled]:hover) .next,
            :host([disabled]:hover) .previous {
                forced-color-adjust: none;
                background: ${d.A.Canvas};
                border-color: ${d.A.GrayText};
                color: ${d.A.GrayText};
                fill: ${d.A.GrayText};
            }
            :host(:${l.N})::before {
                forced-color-adjust: none;
                border-color: ${d.A.Highlight};
                box-shadow: 0 0 0 2px ${d.A.Field},
                    0 0 0 4px ${d.A.FieldText};
            }
        `));var $=e(60143),m=e(96950);const w=(0,$.B)({next:m.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z"
            />
        </svg>
    `,previous:m.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z"
            />
        </svg>
    `});class C extends r.d{}const y=C.compose({name:`${a.c.prefix}-flipper`,template:w,styles:x})},13509(t,i){i.A='<svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path clip-rule="evenodd" d="M7.5 9c0 .7-.24 1.33-.63 1.84l2.77 2.77a.37.37 0 1 1-.53.53l-2.77-2.77A3 3 0 1 1 7.5 9Zm-3 2.25a2.25 2.25 0 1 0 0-4.5 2.25 2.25 0 0 0 0 4.5Z"/><path clip-rule="evenodd" d="M4.13 2.25c-.21 0-.38.17-.38.38v2.7c-.26.05-.51.13-.75.23V2.63C3 2 3.5 1.5 4.13 1.5h3.8c.3 0 .6.12.8.33l2.94 2.94c.21.2.33.5.33.8v6.8c0 .63-.5 1.13-1.13 1.13h-.44c-.05-.15-.14-.3-.26-.42l-.33-.33h1.04c.2 0 .37-.17.37-.38V6H8.62C8 6 7.5 5.5 7.5 4.87V2.25H4.12Zm4.12.16v2.46c0 .21.17.38.38.38h2.46L8.25 2.41Z"/></svg>'},15961(t,i,e){e.d(i,{m(){return m}});var r=e(99751),a=e(37180),s=e(74849),o=e(64187),n=e(73477),l=e(22131),h=e(50882),d=e(48196),c=e(7896),p=e(41123),u=e(74838),g=e(48751),v=e(57416),f=e(26920),b=e(14996);const x=s.A`
    ${(0,o.V)("inline-flex")} :host {
        box-sizing: border-box;
        font-family: ${c.O};
        font-size: ${p.K};
        font-weight: 400;
        line-height: ${p.Z};
        height: calc(${d.D} * 1px);
        padding: 0 calc((6 + (${u.vR} * 2 * ${u.Br})) * 1px);
        color: ${g.l};
        border-radius: calc(${v.Pb} * 1px);
        border: calc(${f.XA} * 1px) solid transparent;
        align-items: center;
        justify-content: center;
        grid-row: 1;
        cursor: pointer;
    }

    :host([aria-selected="true"]) {
        z-index: 2;
    }

    :host(:hover),
    :host(:active) {
        color: ${g.l};
    }

    :host(:${n.N}) {
        outline: none;
        border: calc(${f.XA} * 1px) solid ${b.WN};
        box-shadow: 0 0 0 calc((${f.vd} - ${f.XA}) * 1px)
            ${b.WN};
    }

    :host(:focus) {
        outline: none;
    }

    :host(.vertical) {
        justify-content: end;
        grid-column: 2;
    }

    :host(.vertical[aria-selected="true"]) {
        z-index: 2;
    }

    :host(.vertical:hover),
    :host(.vertical:active) {
        color: ${g.l};
    }

    :host(.vertical:hover[aria-selected="true"]) {
    }
`.withBehaviors((0,l.mr)(s.A`
            :host {
                forced-color-adjust: none;
                border-color: transparent;
                color: ${h.A.ButtonText};
                fill: currentcolor;
            }
            :host(:hover),
            :host(.vertical:hover),
            :host([aria-selected="true"]:hover) {
                background: ${h.A.Highlight};
                color: ${h.A.HighlightText};
                fill: currentcolor;
            }
            :host([aria-selected="true"]) {
                background: ${h.A.HighlightText};
                color: ${h.A.Highlight};
                fill: currentcolor;
            }
            :host(:${n.N}) {
                border-color: ${h.A.ButtonText};
                box-shadow: none;
            }
        `)),$=(0,e(60347).M)(),m=r.s.compose({name:`${a.c.prefix}-tab`,template:$,styles:x})},20197(t,i,e){e.d(i,{V(){return n}});var r=e(61138),a=e(7896),s=e(74849),o=e(64187);const n=s.A`
    ${(0,o.V)("flex")} :host{box-sizing:border-box;font-family:${a.O};
        font-size: ${r.k};
        line-height: ${r.F};
        height: 100%;
        padding: var(--carousel-card-panel-padding);
    }
`},26813(t,i,e){e.d(i,{D(){return g},P(){return u}});var r=e(56911),a=e(60815),s=e(96950),o=e(92011),n=e(38493),l=e(55230),h=e(5096),d=e(50180),c=e(35106),p=e(88458);const u={vertical:"vertical",horizontal:"horizontal"};class g extends o.L{constructor(){super(...arguments),this.orientation=u.horizontal,this.hideActiveIndicator=!1,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=t=>"true"===t.getAttribute("aria-disabled"),this.isFocusableElement=t=>!this.isDisabledElement(t),this.setTabs=()=>{const t="gridColumn",i="gridRow",e=this.isHorizontal()?t:i;this.activeTabIndex=this.getActiveIndex(),this.showActiveIndicator=!1,this.tabs.forEach((r,a)=>{if("tab"===r.slot){const t=this.activeTabIndex===a&&this.isFocusableElement(r);!this.hideActiveIndicator&&this.isFocusableElement(r)&&(this.showActiveIndicator=!0);const i=this.tabIds[a],e=this.tabpanelIds[a];r.setAttribute("id",i),r.setAttribute("aria-selected",t?"true":"false"),r.setAttribute("aria-controls",e),r.addEventListener("click",this.handleTabClick),r.addEventListener("keydown",this.handleTabKeyDown),r.setAttribute("tabindex",t?"0":"-1"),t&&(this.activetab=r)}r.style[t]="",r.style[i]="",r.style[e]=`${a+1}`,this.isHorizontal()?r.classList.remove("vertical"):r.classList.add("vertical")})},this.setTabPanels=()=>{this.tabpanels?.forEach((t,i)=>{const e=this.tabIds[i],r=this.tabpanelIds[i];t.setAttribute("id",r),t.setAttribute("aria-labelledby",e),this.activeTabIndex!==i?(t.setAttribute("tabindex","-1"),t.setAttribute("hidden",""),t.setAttribute("aria-hidden","true")):(t.removeAttribute("tabindex"),t.removeAttribute("hidden"),t.removeAttribute("aria-hidden"))})},this.handleTabClick=t=>{const i=t.currentTarget;1===i.nodeType&&this.isFocusableElement(i)&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(i),this.setComponent())},this.handleTabKeyDown=t=>{if(this.isHorizontal())switch(t.key){case l.kT:t.preventDefault(),this.adjustBackward(t);break;case l.bb:t.preventDefault(),this.adjustForward(t)}else switch(t.key){case l.I5:t.preventDefault(),this.adjustBackward(t);break;case l.HX:t.preventDefault(),this.adjustForward(t)}switch(t.key){case l.kE:t.preventDefault(),this.adjust(-this.activeTabIndex);break;case l.FM:t.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1)}},this.adjustForward=t=>{const i=this.tabs;let e=0;for(e=this.activetab?i.indexOf(this.activetab)+1:1,e===i.length&&(e=0);e<i.length&&i.length>1;){if(this.isFocusableElement(i[e])){this.moveToTabByIndex(i,e);break}if(this.activetab&&e===i.indexOf(this.activetab))break;e+1>=i.length?e=0:e+=1}},this.adjustBackward=t=>{const i=this.tabs;let e=0;for(e=this.activetab?i.indexOf(this.activetab)-1:0,e=e<0?i.length-1:e;e>=0&&i.length>1;){if(this.isFocusableElement(i[e])){this.moveToTabByIndex(i,e);break}e-1<0?e=i.length-1:e-=1}},this.moveToTabByIndex=(t,i)=>{const e=t[i];this.activetab=e,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=i,e.focus(),this.setComponent()}}orientationChanged(){this.$fastController.isConnected&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}activeidChanged(t,i){this.$fastController.isConnected&&(this.tabs.length<=(this.tabpanels?.length??0)||this.tabs.length<=(this.lazyPanels?.length??0))&&(this.prevActiveTabIndex=this.tabs.findIndex(i=>i.id===t),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(){this.$fastController.isConnected&&(this.tabs.length<=(this.tabpanels?.length??0)||this.tabs.length<=(this.lazyPanels?.length??0))&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}lazyPanelsChanged(){this.$fastController.isConnected&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.handleActiveIndicatorPosition())}tabpanelsChanged(){this.$fastController.isConnected&&(this.tabpanels?.length??0)<=this.tabs.length&&(this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):0}getTabIds(){return this.tabs.map(t=>t.getAttribute("id")??`tab-${(0,d.NF)()}`)}getTabPanelIds(){return this.lazyPanels?this.lazyPanels.map(t=>t.id):(this.tabpanels||[]).map(t=>t.getAttribute("id")??`panel-${(0,d.NF)()}`)}setComponent(){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.focusTab(),this.change())}isHorizontal(){return this.orientation===u.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&!this.hideActiveIndicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;const t=this.isHorizontal()?"gridColumn":"gridRow",i=this.isHorizontal()?"translateX":"translateY",e=this.isHorizontal()?"offsetLeft":"offsetTop",r=this.activeIndicatorRef[e];this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`;const a=this.activeIndicatorRef[e];this.activeIndicatorRef.style[t]=`${this.prevActiveTabIndex+1}`;const s=a-r;this.activeIndicatorRef.style.transform=`${i}(${s}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",()=>{this.ticking=!1,this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${i}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")})}adjust(t){const i=this.tabs.filter(t=>!this.isDisabledElement(t)),e=i.indexOf(this.activetab),r=(0,h.AB)(0,i.length-1,e+t),a=this.tabs.indexOf(i[r]);a>-1&&this.moveToTabByIndex(this.tabs,a)}focusTab(){this.tabs[this.activeTabIndex].focus()}connectedCallback(){super.connectedCallback(),this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex()}}(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],g.prototype,"orientation",void 0),(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],g.prototype,"activeid",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Array)],g.prototype,"tabs",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Array)],g.prototype,"lazyPanels",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",s.kc)],g.prototype,"lazyPanelTemplate",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Array)],g.prototype,"tabpanels",void 0),(0,r.Cg)([(0,n.CF)({attribute:"hide-active-indicator",mode:"boolean"}),(0,r.Sn)("design:type",Object)],g.prototype,"hideActiveIndicator",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",HTMLElement)],g.prototype,"activeIndicatorRef",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Boolean)],g.prototype,"showActiveIndicator",void 0),(0,p.X)(g,c.qw)},29995(t,i,e){e.d(i,{M(){return n}});var r=e(96950),a=e(60402),s=e(82774),o=e(35106);function n(t={}){return r.qy`
        <a
            class="control"
            part="control"
            download="${t=>t.download}"
            href="${t=>t.href}"
            hreflang="${t=>t.hreflang}"
            ping="${t=>t.ping}"
            referrerpolicy="${t=>t.referrerpolicy}"
            rel="${t=>t.rel}"
            target="${t=>t.target}"
            type="${t=>t.type}"
            aria-atomic="${t=>t.ariaAtomic}"
            aria-busy="${t=>t.ariaBusy}"
            aria-controls="${t=>t.ariaControls}"
            aria-current="${t=>t.ariaCurrent}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-details="${t=>t.ariaDetails}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-errormessage="${t=>t.ariaErrormessage}"
            aria-expanded="${t=>t.ariaExpanded}"
            aria-flowto="${t=>t.ariaFlowto}"
            aria-haspopup="${t=>t.ariaHaspopup}"
            aria-hidden="${t=>t.ariaHidden}"
            aria-invalid="${t=>t.ariaInvalid}"
            aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
            aria-label="${t=>t.ariaLabel}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-live="${t=>t.ariaLive}"
            aria-owns="${t=>t.ariaOwns}"
            aria-relevant="${t=>t.ariaRelevant}"
            aria-roledescription="${t=>t.ariaRoledescription}"
            ${(0,a.K)("control")}
        >
            ${(0,o.LT)(t)}
            <span class="content" part="content">
                <slot ${(0,s.e)("defaultSlottedContent")}></slot>
            </span>
            ${(0,o.aO)(t)}
        </a>
    `}},31422(t,i){i.A='<svg width="14" height="14" viewBox="0 0 14 14"><path d="M.4.15A.5.5 0 0 0 .37.8l.05.05 2.69 2.7A6.66 6.66 0 0 0 .46 7.36a.5.5 0 0 0 .97.25 5.66 5.66 0 0 1 2.39-3.36l1.2 1.2A2.67 2.67 0 0 0 8.8 9.25l3.95 3.94a.5.5 0 0 0 .75-.65l-.04-.05L9.37 8.4l-.8-.8L6.66 5.7 4.74 3.77l-.76-.75L1.13.15a.5.5 0 0 0-.71 0Zm5.33 6.03 2.36 2.35a1.67 1.67 0 0 1-2.36-2.35Zm1.2-3.85A6.66 6.66 0 0 0 5 2.62l.83.82a5.67 5.67 0 0 1 6.6 4.18.5.5 0 0 0 .96-.24 6.67 6.67 0 0 0-6.46-5.05Zm.13 2.34 2.53 2.54a2.67 2.67 0 0 0-2.53-2.54Z" fill-opacity=".83"/></svg>'},32747(t,i,e){e.d(i,{j(){return g}});var r=e(74849),a=e(50882),s=e(64187),o=e(22131),n=e(41123),l=e(57416),h=e(37998),d=e(4283),c=e(7896),p=e(48751),u=e(70246);const g=r.A`
        ${(0,s.V)("grid")} :host{--elevation:4;box-sizing:border-box;font-family:${c.O};
            font-size: ${n.K};
            line-height: ${n.Z};
            color: ${p.l};
            background: ${u.k};
            border-radius: calc(${l.JU} * 1px);
            ${h.ET};overflow:hidden;height:100%;grid-template-columns:auto 1fr auto;grid-template-rows:auto 1fr;width:100%}:host(:hover) ::slotted([slot="previous-flipper"]),:host(:hover) .previous-flipper,:host(:hover) ::slotted([slot="next-flipper"]),:host(:hover) .next-flipper{opacity:1;transition:opacity 0.2s ease-in-out}.tablist{display:var(--hidden-tablist,grid);grid-template-rows:auto auto;grid-template-columns:auto;position:relative;width:max-content;align-self:center;justify-self:center;grid-row:1;grid-column:1 / span 3;z-index:3;cursor:pointer}::slotted([slot="previous-flipper"]),.previous-flipper{margin:8px;grid-column:1;grid-row:1 / span 2;align-self:center;z-index:2;opacity:0}::slotted([slot="next-flipper"]),.next-flipper{margin:8px;grid-column:3;grid-row:1 / span 2;align-self:center;z-index:2;opacity:0}:host([layout="1-column"]){--heading-font-size:${n.K};
            --heading-line-height: ${n.Z}}.activeIndicator{grid-row:2;grid-column:1;width:20px;height:3px;border-radius:calc(${l.Pb} * 1px);
            justify-self: center;
            background: ${d.IR}}.activeIndicatorTransition{transition:transform 0.2s ease-in-out}.tabpanel{grid-row:1/3;grid-column-start:1;grid-column-end:4;position:relative}`.withBehaviors((0,o.mr)(r.A` .activeIndicator{forced-color-adjust:none;background:${a.A.Highlight}}.tablist{background:${a.A.Canvas};
                }
            `))},34019(t,i,e){e.d(i,{dx(){return c}});var r=e(60347),a=e(99900),s=e(66449),o=e(74849),n=e(64187),l=e(94533);const h=o.A`
    ${l.K}
    ${(0,n.V)("inline-flex")} :host{min-height:4px;height:4px;width:4px;min-width:4px;margin:0;transition:transform 0.2s ease-in-out}:host([aria-selected="true"]){z-index:2;opacity:1;min-height:6px;min-width:6px;height:6px;width:6px}`;class d extends s.I{}const c=d.compose({name:`${a.i.prefix}-carousel-card-sequence-indicator`,template:(0,r.M)(),styles:h})},37510(t,i,e){e.d(i,{m(){return p}});var r=e(10103),a=e(37180),s=e(74849),o=e(64187),n=e(7896),l=e(61138),h=e(74838);const d=s.A`
    ${(0,o.V)("block")} :host {
        box-sizing: border-box;
        font-family: ${n.O};
        font-size: ${l.k};
        font-weight: 400;
        line-height: ${l.F};
        padding: 0 calc((6 + (${h.vR} * 2 * ${h.Br})) * 1px);
    }
`,c=(0,e(5675).S)(),p=r.y.compose({name:`${a.c.prefix}-tab-panel`,template:c,styles:d})},38319(t,i,e){e.d(i,{t(){return p}});var r=e(56911),a=e(13509),s=e(31422),o=e(80541),n=e(93552),l=e(77367),h=e(60815),d=e(71398),c=e(40865);class p{constructor(t,i,e,r,a){this.menuItems=[],this.isActionMenuOpen=!1,this.actionsMenuButtonElement=null,this.onOutsideClick=t=>{const i=t.composedPath()&&t.composedPath()[0];t.target instanceof this.currentSDClass||(0,c.W)(this.actionsMenuButtonElement,i)||this.toggleActionMenu(!1,null)},this.onKeydown=t=>{"Escape"===t.code&&this.toggleActionMenu(!1,null)},this.moreSettingAction=async()=>{this.toggleActionMenu(!1,null),this.goToPersonalizeSettingsCallback&&this.goToPersonalizeSettingsCallback()},this.hideSettingAction=async()=>{if(!this.segmentSdCardType)return!1;try{const t=await d.d.updateSegmentCardsEnableStatus([{cardType:this.segmentSdCardType,enabled:!1}]);return t&&this.refreshSDCardSection&&this.refreshSDCardSection(),this.toggleActionMenu(!1,null),t}catch(t){return l.YT.sendAppErrorEvent({...n.N2u,message:`Fail to hide ${this.segmentSdCardType} Card .`,pb:{...n.N2u.pb,customMessage:`Failed with exception : ${t}`}}),!1}},this.currentSDClass=t,this.settingMenuConfig=e,this.goToPersonalizeSettingsCallback=r,this.refreshSDCardSection=a,this.menuItems=this.getBaseActionMenuItems(),this.segmentSdCardType=i}updateMenuItems(t,i){this.menuItems=i?this.menuItems.concat(t):t.concat(this.menuItems)}toggleActionMenu(t,i){this.isActionMenuOpen=t,t?(this.actionsMenuButtonElement=i&&i.currentTarget,this.setAriaExpanded(t),document.addEventListener("click",this.onOutsideClick),document.addEventListener("keydown",this.onKeydown)):(this.setAriaExpanded(t),this.actionsMenuButtonElement=null,document.removeEventListener("click",this.onOutsideClick),document.removeEventListener("keydown",this.onKeydown))}setAriaExpanded(t){this.actionsMenuButtonElement&&(this.actionsMenuButtonElement.ariaExpanded=String(t))}getBaseActionMenuItems(){var t,i;if(!this.settingMenuConfig)return[];const e=[];if(null!==(t=this.settingMenuConfig.interestSetting)&&void 0!==t&&t.onClick){const t=this.settingMenuConfig.interestSetting;e.push({glyph:s.A,title:t.title,id:"dislike",onClick:t.onClick,telemetryTag:t.telemetryTag})}if(null!==(i=this.settingMenuConfig.dataProviderSetting)&&void 0!==i&&i.onClick){const t=this.settingMenuConfig.dataProviderSetting;e.push({glyph:a.A,title:t.title,id:"dataProvider",onClick:t.onClick,telemetryTag:t.telemetryTag})}if(this.settingMenuConfig.hideSetting){const t=this.settingMenuConfig.hideSetting;e.push({glyph:s.A,title:t.title,id:"hide",onClick:t.onClick?t.onClick:()=>this.hideSettingAction(),telemetryTag:t.telemetryTag})}if(this.settingMenuConfig.moreSetting){const t=this.settingMenuConfig.moreSetting;e.push({glyph:o.A,ariaLabel:t.ariaLabel,title:t.title,id:"more",onClick:t.onClick?t.onClick:()=>this.moreSettingAction(),telemetryTag:t.telemetryTag})}return e}}(0,r.Cg)([h.sH],p.prototype,"menuItems",void 0),(0,r.Cg)([h.sH],p.prototype,"isActionMenuOpen",void 0)},45899(t,i,e){e.d(i,{m(){return u}});var r=e(37180),a=e(56911),s=e(7511),o=e(38493);class n extends s._{appearanceChanged(t,i){t!==i&&(this.classList.add(i),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="neutral")}defaultSlottedContentChanged(){const t=this.defaultSlottedContent.filter(t=>t.nodeType===Node.ELEMENT_NODE);1===t.length&&t[0]instanceof SVGElement?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,a.Cg)([o.CF,(0,a.Sn)("design:type",String)],n.prototype,"appearance",void 0);var l=e(74849),h=e(25984),d=e(17767);const c=l.A`
    ${h._9}
`.withBehaviors((0,d.f)("accent",h.Vw),(0,d.f)("hypertext",h.aY),(0,d.f)("lightweight",h.ZI),(0,d.f)("outline",h.LA),(0,d.f)("stealth",h.ss)),p=(0,e(29995).M)(),u=n.compose({name:`${r.c.prefix}-anchor`,template:p,styles:c,shadowOptions:{delegatesFocus:!0}})},47264(t,i){i.A='<svg width="20" height="20" viewBox="0 0 20 20"><path d="M6 10a1.25 1.25 0 1 1-2.5 0A1.25 1.25 0 0 1 6 10zM11.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0zM15.25 11.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5z"/></svg>'},60143(t,i,e){e.d(i,{B(){return s}});var r=e(96950),a=e(18893);function s(t={}){const i={};return r.qy`
        <template
            role="button"
            aria-disabled="${t=>!!t.disabled||void 0}"
            tabindex="${t=>t.hiddenFromAT?-1:0}"
            @keyup="${(t,i)=>t.keyupHandler(i.event)}"
        >
            ${e=>function(t,e){let s=i[t];return s||(i[t]=s=r.qy`
                <span part="${t}" class="${t}">
                    <slot name="${t}">
                        ${(0,a.R)(e[t])}
                    </slot>
                </span>
            `),s}(e.direction,t)}
        </template>
    `}},60347(t,i,e){e.d(i,{M(){return s}});var r=e(96950),a=e(35106);function s(t={}){return r.qy`
        <template slot="tab" role="tab" aria-disabled="${t=>t.disabled}">
            ${(0,a.LT)(t)}
            <slot></slot>
            ${(0,a.aO)(t)}
        </template>
    `}},66449(t,i,e){e.d(i,{I(){return a}});var r=e(99751);class a extends r.s{}},70246(t,i,e){e.d(i,{k(){return c}});var r=e(45755),a=e(37820),s=e(97004),o=e(47691),n=e(356),l=e(31023);const{create:h}=r.G,d=h({name:"neutral-layer-card-container-recipe"},{evaluate(t){return function(t,i,e){const r=(0,a.qE)(t.closestIndexOf((0,s.Z)(i))-e,0,t.swatches.length-1);return t.get(r+e)}(t(l.r),t(n.l),t(o.E))}}),c=h("neutral-layer-card-container",t=>t(d).evaluate(t))},72017(t,i,e){var r=e(15420),a=e(56988),s=e(10405),o=Math.ceil,n=Math.max;i.A=function(t,i,e){i=(e?(0,a.A)(t,i,e):void 0===i)?1:n((0,s.A)(i),0);var l=null==t?0:t.length;if(!l||i<1)return[];for(var h=0,d=0,c=Array(o(l/i));h<l;)c[d++]=(0,r.A)(t,h,h+=i);return c}},77097(t,i,e){e.d(i,{iH(){return T}});var r=e(56911),a=e(38493),s=e(92135),o=e(26813),n=e(22192),l=e(96950),h=e(82774),d=e(69259),c=e(60402),p=e(31157);const u=()=>t=>t.orientation!==o.P.vertical?l.qy`<svg slot="previous" width="7" height="9" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg"><path d="M0.5 4.5C0.5 4.25781 0.557292 4.02865 0.671875 3.8125C0.786458 3.59635 0.94401 3.41927 1.14453 3.28125L4.92969 0.679687C5.09896 0.559896 5.28906 0.5 5.5 0.5C5.66406 0.5 5.82031 0.539062 5.96875 0.617187C6.13281 0.703125 6.26172 0.824219 6.35547 0.980469C6.45182 1.13672 6.5 1.30729 6.5 1.49219L6.5 7.51172C6.5 7.69401 6.45182 7.86328 6.35547 8.01953C6.26172 8.17578 6.13281 8.29818 5.96875 8.38672C5.81771 8.46224 5.66276 8.5 5.50391 8.5C5.29036 8.5 5.09896 8.4401 4.92969 8.32031L1.14453 5.71875C0.94401 5.58073 0.786458 5.40365 0.671875 5.1875C0.557291 4.97135 0.5 4.74219 0.5 4.5Z" /></svg><svg slot="next" width="7" height="9" viewBox="0 0 7 9" xmlns="http://www.w3.org/2000/svg"><path d="M0.5 1.49219C0.5 1.30729 0.546875 1.13672 0.640625 0.980468C0.736979 0.824218 0.86849 0.703125 1.03516 0.617187C1.18099 0.539062 1.33594 0.5 1.5 0.5C1.71094 0.5 1.90104 0.559896 2.07031 0.679687L5.85547 3.28125C6.05078 3.41667 6.20052 3.59245 6.30469 3.80859C6.40885 4.02474 6.46094 4.25521 6.46094 4.5C6.46094 4.74219 6.40885 4.97135 6.30469 5.1875C6.20052 5.40625 6.05078 5.58333 5.85547 5.71875L2.07031 8.32031C1.90104 8.4401 1.71094 8.5 1.5 8.5C1.34115 8.5 1.1862 8.46224 1.03516 8.38672C0.868489 8.29818 0.736979 8.17578 0.640625 8.01953C0.546875 7.86328 0.5 7.69401 0.5 7.51172L0.5 1.49219Z" /></svg>`:l.qy`<svg slot="previous" width="9" height="7" viewBox="0 0 9 7" xmlns="http://www.w3.org/2000/svg"><path d="M1.00192 6.60547C0.194077 6.60547 -0.28047 5.6973 0.180865 5.0341L2.81398 1.24898C3.41087 0.390957 4.68026 0.390967 5.27715 1.24899L7.91028 5.0341C8.37156 5.6973 7.89707 6.60547 7.08922 6.60547H1.00192Z" /></svg><svg slot="next" width="9" height="7" viewBox="0 0 9 7" xmlns="http://www.w3.org/2000/svg"><path d="M1.00192 0.605469C0.194077 0.605469 -0.280471 1.51367 0.180865 2.17683L2.81398 5.96196C3.41087 6.82002 4.68027 6.81992 5.27716 5.96196L7.91029 2.17682C8.37157 1.51367 7.89709 0.605469 7.08924 0.605469H1.00192Z" /></svg>`,g=l.qy`<template @mouseover="${(t,i)=>t.handleMouseOver(i.event)}" @mouseout="${(t,i)=>t.handleMouseOut(i.event)}" @focusin="${(t,i)=>t.handleFocusIn(i.event)}" @focusout="${(t,i)=>t.handleFocusOut(i.event)}"><slot name="previous-flipper"><fluent-flipper part="previous-flipper" class="previous-flipper" title="${t=>t.previousFlipperTitle}" direction="${t=>t.direction===p.O.rtl?"next":"previous"}" @keypress="${(t,i)=>t.slideKeyPressHandler(i.event,-1)}" @click="${(t,i)=>t.slideKeyPressHandler(i.event,-1)}" data-t="${t=>t.previousFlipperTelemetryTag}">${u()}</fluent-flipper></slot>${n.p}<div class="tablist" part="tablist" role="tablist"><slot class="tab" name="tab" part="tab" ${(0,h.e)("tabs")}></slot>${(0,d.z)(t=>t.activeindicator,l.qy`<div ${(0,c.K)("activeIndicatorRef")} class="activeIndicator" part="activeIndicator"></div>`)}</div><slot name="next-flipper"><fluent-flipper part="next-flipper" class="next-flipper" title="${t=>t.nextFlipperTitle}" direction="${t=>t.direction===p.O.rtl?"previous":"next"}" @keypress="${(t,i)=>t.slideKeyPressHandler(i.event,1)}" @click="${(t,i)=>t.slideKeyPressHandler(i.event,1)}" data-t="${t=>t.nextFlipperTelemetryTag}">${u()}</fluent-flipper></slot>${n.S}<div class="tabpanel"><slot name="tabpanel" part="tabpanel" ${(0,h.e)("tabpanels")}></slot></div></template>`;var v=e(26920),f=e(45476),b=e(74089),x=e(74849),$=e(64187),m=e(22131),w=e(32747);const C=x.A`
        ${w.j}

        ${(0,$.V)("grid")} :host{background:none;border-radius:0;box-shadow:none;grid-template-rows:1fr auto}::slotted([slot="previous-flipper"]),.previous-flipper{margin:0;height:38px;width:16px}::slotted([slot="next-flipper"]),.next-flipper{margin:0;height:38px;width:16px}.next-flipper::before,.previous-flipper::before{border-radius:3px;border:calc(${v.XA} * 1px) solid transparent;
            background: ${f.Wl}}.next-flipper:hover::before,.previous-flipper:hover::before{background:${f.oO}}.next-flipper:active::before,.previous-flipper:active::before{background:${f.wO}}.next-flipper::part(previous),.next-flipper::part(next),.previous-flipper::part(previous),.previous-flipper::part(next){width:auto;height:auto;display:flex;align-items:center}.tablist{grid-row:2;grid-gap:6px;padding:var(--sequence-indicator-padding,10px);align-items:center;justify-items:center;grid-template-rows:auto}.tabpanel{grid-row:1 / span 3;grid-column:1 / span 3;position:relative}:host([orientation="vertical"]){grid-template-rows:1fr auto 1fr;grid-template-columns:1fr auto}:host([orientation="vertical"]) .tabpanel{grid-row:1/3;grid-column-start:1;grid-column-end:4}:host([orientation="vertical"]) .tablist{grid-row-start:2;grid-row-end:2;grid-column:2;grid-template-rows:auto;padding:20px 0;justify-self:center}:host([orientation="vertical"]) .tabpanel{grid-column:1 / span 2;grid-row-start:1;grid-row-end:4}:host([orientation="vertical"]) .previous-flipper{grid-column:2;grid-row:1;align-self:flex-end;height:16px;width:20px;margin:0 2px}:host([orientation="vertical"]) .next-flipper{grid-column:2;grid-row:3;align-self:flex-start;height:16px;width:20px;margin:0 2px}`.withBehaviors((0,m.mr)(x.A` :host{forced-color-adjust:auto}.next-flipper:hover::before,.previous-flipper:hover::before{border-color:#2b2b2b;background:${b.XK}}.next-flipper:active::before,.previous-flipper:active::before{border-color:#2b2b2b;background:${b.XK}}@media (forced-colors:active) and (prefers-color-scheme:light){.next-flipper::part(previous),.next-flipper::part(next),.previous-flipper::part(previous),.previous-flipper::part(next){fill:#2b2b2b}}}`));var y=e(99900);class k extends s.hN{}(0,r.Cg)([(0,a.CF)({attribute:"previous-flipper-title"})],k.prototype,"previousFlipperTitle",void 0),(0,r.Cg)([(0,a.CF)({attribute:"next-flipper-title"})],k.prototype,"nextFlipperTitle",void 0);const T=k.compose({name:`${y.i.prefix}-carousel-card-wrapper`,template:g,styles:C})},80541(t,i){i.A='<svg width="17" height="17" viewBox="0 0 17 17"><path d="M.02 5.88A8.5 8.5 0 0 1 1.8 2.8a.5.5 0 0 1 .54-.13l1.92.68a1 1 0 0 0 1.32-.76l.37-2a.5.5 0 0 1 .39-.4 8.53 8.53 0 0 1 3.55 0 .5.5 0 0 1 .39.4l.37 2a1 1 0 0 0 1.32.76l1.91-.68a.5.5 0 0 1 .54.13 8.5 8.5 0 0 1 1.78 3.08.5.5 0 0 1-.15.54L14.5 7.74a1 1 0 0 0 0 1.52l1.55 1.32a.5.5 0 0 1 .15.54 8.5 8.5 0 0 1-1.78 3.08.5.5 0 0 1-.54.13l-1.91-.68a1 1 0 0 0-1.32.76l-.37 2a.5.5 0 0 1-.39.4 8.53 8.53 0 0 1-3.55 0 .5.5 0 0 1-.4-.4l-.36-2a1 1 0 0 0-1.32-.76l-1.92.68a.5.5 0 0 1-.54-.13 8.49 8.49 0 0 1-1.78-3.08.5.5 0 0 1 .16-.54l1.55-1.32a1 1 0 0 0 0-1.52L.18 6.42a.5.5 0 0 1-.16-.54Zm1.06 0 1.3 1.1a2 2 0 0 1 0 3.04l-1.3 1.1c.3.79.72 1.51 1.25 2.16l1.6-.58a2 2 0 0 1 2.64 1.53l.3 1.67a7.56 7.56 0 0 0 2.49 0l.3-1.67a2 2 0 0 1 2.64-1.53l1.6.57a7.5 7.5 0 0 0 1.24-2.15l-1.29-1.1a2 2 0 0 1 0-3.05l1.3-1.1a7.5 7.5 0 0 0-1.25-2.15l-1.6.57a2 2 0 0 1-2.64-1.52l-.3-1.67a7.55 7.55 0 0 0-2.49 0l-.3 1.67A2 2 0 0 1 3.93 4.3l-1.6-.57a7.5 7.5 0 0 0-1.25 2.15ZM5.62 8.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0Zm1 0a1.5 1.5 0 1 0 3 0 1.5 1.5 0 0 0-3 0Z" fill-opacity=".83"/></svg>'},84506(t,i,e){e.d(i,{d(){return n}});var r=e(56911),a=e(92011),s=e(38493);const o="next";class n extends a.L{constructor(){super(...arguments),this.hiddenFromAT=!0,this.direction=o}keyupHandler(t){if(!this.hiddenFromAT){const i=t.key;"Enter"!==i&&"Space"!==i||this.$emit("click",t)}}}(0,r.Cg)([(0,s.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],n.prototype,"disabled",void 0),(0,r.Cg)([(0,s.CF)({attribute:"aria-hidden",converter:s.Bs}),(0,r.Sn)("design:type",Boolean)],n.prototype,"hiddenFromAT",void 0),(0,r.Cg)([s.CF,(0,r.Sn)("design:type",String)],n.prototype,"direction",void 0)},91889(t,i,e){e.d(i,{b(){return a}});var r=e(10103);class a extends r.y{}},92135(t,i,e){e.d(i,{hN(){return p}});var r,a,s=e(56911),o=e(60815),n=e(92011),l=e(38493),h=e(55230),d=e(5096),c=e(72691);!function(t){t._1_column="1_column",t._2_column="2_column"}(r||(r={})),function(t){t.vertical="vertical",t.horizontal="horizontal"}(a||(a={}));class p extends n.L{constructor(){super(...arguments),this.slideKeyPressHandler=(t,i)=>{this.adjust(i)},this.layout=r._2_column,this.orientation=a.horizontal,this.activeindicator=!1,this.showActiveIndicator=!0,this.prevActiveTabIndex=0,this.activeTabIndex=0,this.ticking=!1,this.isHovered=!1,this.isFocused=!1,this.change=()=>{this.$emit("change",this.activetab)},this.isDisabledElement=t=>"true"===t.getAttribute("aria-disabled"),this.isFocusableElement=t=>!this.isDisabledElement(t),this.setTabs=()=>{const t=this.isHorizontal()?"gridColumn":"gridRow";this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex(),this.tabs.forEach((i,e)=>{if("tab"===i.slot&&this.isFocusableElement(i)){this.activeindicator&&(this.showActiveIndicator=!0);const t=this.tabIds[e],r=this.tabpanelIds[e];i.setAttribute("id","string"!=typeof t?`tab-${e+1}`:t),i.setAttribute("aria-selected",this.activeTabIndex===e?"true":"false"),i.setAttribute("aria-controls","string"!=typeof r?`panel-${e+1}`:r),i.addEventListener("click",this.handleTabClick),i.addEventListener("keydown",this.handleTabKeyDown),i.setAttribute("tabindex",this.activeTabIndex===e?"0":"-1"),this.activeTabIndex===e&&(this.activetab=i)}else this.showActiveIndicator=!1;i.style[t]=`${e+1}`,this.isHorizontal()?i.classList.remove("vertical"):i.classList.add("vertical")})},this.setTabPanels=()=>{this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.tabpanels.forEach((t,i)=>{const e=this.tabIds[i],r=this.tabpanelIds[i];t.setAttribute("id","string"!=typeof r?`panel-${i+1}`:r),t.setAttribute("aria-labelledby","string"!=typeof e?`tab-${i+1}`:e),this.activeTabIndex!==i?t.setAttribute("hidden",""):t.removeAttribute("hidden")})},this.handleTabClick=t=>{const i=t.currentTarget;1===i.nodeType&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=this.tabs.indexOf(i),this.setComponent()),t.preventDefault()},this.handleTabKeyDown=t=>{const i=t.key;if(this.isHorizontal())switch(i){case h.kT:t.preventDefault(),this.adjustBackward(t);break;case h.bb:t.preventDefault(),this.adjustForward(t)}else switch(i){case h.I5:t.preventDefault(),this.adjustBackward(t);break;case h.HX:t.preventDefault(),this.adjustForward(t)}switch(i){case h.kE:t.preventDefault(),this.adjust(-this.activeTabIndex);break;case h.FM:t.preventDefault(),this.adjust(this.tabs.length-this.activeTabIndex-1)}},this.adjustForward=t=>{const i=this.tabs;let e=0;for(e=this.activetab?i.indexOf(this.activetab)+1:1,e===i.length&&(e=0);e<i.length&&i.length>1;){if(this.isFocusableElement(i[e])){this.moveToTabByIndex(i,e);break}if(this.activetab&&e===i.indexOf(this.activetab))break;e+1>=i.length?e=0:e+=1}},this.adjustBackward=t=>{const i=this.tabs;let e=0;for(e=this.activetab?i.indexOf(this.activetab)-1:0,e=e<0?i.length-1:e;e>=0&&i.length>1;){if(this.isFocusableElement(i[e])){this.moveToTabByIndex(i,e);break}e-1<0?e=i.length-1:e-=1}},this.moveToTabByIndex=(t,i)=>{const e=t[i];this.activetab=e,this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=i,e.focus(),this.setComponent()}}autoScrollChanged(){this.$fastController.isConnected&&this.updateAutoScroll()}autoScrollIntervalMsChanged(){this.$fastController.isConnected&&this.updateAutoScroll()}handleChange(){this.direction=c.o.getValueFor(this)}connectedCallback(){super.connectedCallback(),this.tabIds=this.getTabIds(),this.tabpanelIds=this.getTabPanelIds(),this.activeTabIndex=this.getActiveIndex(),this.direction=c.o.getValueFor(this),c.o.subscribe(this),this.activeindicator||(this.activeindicator=!1),this.updateAutoScroll()}disconnectedCallback(){super.disconnectedCallback(),c.o.unsubscribe(this),window.clearTimeout(this.autoScrollTimer)}activeidChanged(){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabsChanged(){this.$fastController.isConnected&&this.tabs.length<=this.tabpanels.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition())}tabpanelsChanged(){this.$fastController.isConnected&&this.tabpanels.length<=this.tabs.length&&(this.setTabs(),this.setTabPanels(),this.handleActiveIndicatorPosition(),this.$emit("tabpanels-changed",this.tabpanels))}getActiveIndex(){return void 0!==this.activeid?-1===this.tabIds.indexOf(this.activeid)?0:this.tabIds.indexOf(this.activeid):this.initialId&&this.tabs&&this.tabs.length>0?(0,d.Vf)(0,this.tabs.length-1,this.initialId):0}getTabIds(){return void 0===this.tabs?[null]:this.tabs.map(t=>t.getAttribute("id"))}getTabPanelIds(){return void 0===this.tabpanels?[null]:this.tabpanels.map(t=>t.getAttribute("id"))}setComponent(t){this.activeTabIndex!==this.prevActiveTabIndex&&(this.activeid=this.tabIds[this.activeTabIndex],this.change(),this.setTabs(),this.handleActiveIndicatorPosition(),this.setTabPanels(),t||this.focusTab(),this.change())}isHorizontal(){return this.orientation===a.horizontal}handleActiveIndicatorPosition(){this.showActiveIndicator&&this.activeindicator&&this.activeTabIndex!==this.prevActiveTabIndex&&(this.ticking?this.ticking=!1:(this.ticking=!0,this.animateActiveIndicator()))}animateActiveIndicator(){this.ticking=!0;const t=this.isHorizontal()?"gridColumn":"gridRow",i=this.isHorizontal()?"translateX":"translateY",e=this.isHorizontal()?"offsetLeft":"offsetTop",r=this.activeIndicatorRef[e];this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`;const a=this.activeIndicatorRef[e];this.activeIndicatorRef.style[t]=`${this.prevActiveTabIndex+1}`;const s=a-r;this.activeIndicatorRef.style.transform=`${i}(${s}px)`,this.activeIndicatorRef.classList.add("activeIndicatorTransition"),this.activeIndicatorRef.addEventListener("transitionend",()=>{this.ticking=!1,this.activeIndicatorRef.style[t]=`${this.activeTabIndex+1}`,this.activeIndicatorRef.style.transform=`${i}(0px)`,this.activeIndicatorRef.classList.remove("activeIndicatorTransition")})}adjust(t,i){void 0!==this.tabs&&(this.prevActiveTabIndex=this.activeTabIndex,this.activeTabIndex=(0,d.Vf)(0,this.tabs.length-1,this.activeTabIndex+t),this.setComponent(i))}focusTab(){this.tabs[this.activeTabIndex].focus()}handleFocusIn(t){this.isFocused=!0,this.updateAutoScroll()}handleFocusOut(t){null!==t.relatedTarget&&this.contains(t.relatedTarget)||(this.isFocused=!1,this.updateAutoScroll())}handleMouseOver(t){this.isHovered=!0,this.updateAutoScroll()}handleMouseOut(t){this.isHovered=!1,this.updateAutoScroll()}updateAutoScroll(){let t=!1;this.isHovered||this.isFocused||!this.autoScroll||(t=!0),t&&void 0===this.autoScrollTimer&&(this.autoScrollTimer=window.setTimeout(()=>{this.autoScrollDelayMs&&(this.autoScrollDelayMs=0),this.adjust(1,!0),this.autoScrollTimer=void 0,this.updateAutoScroll()},(this.autoScrollDelayMs||0)+(this.autoScrollIntervalMs||6e3))),t||void 0===this.autoScrollTimer||(window.clearTimeout(this.autoScrollTimer),this.autoScrollTimer=void 0)}}(0,s.Cg)([l.CF],p.prototype,"layout",void 0),(0,s.Cg)([(0,l.CF)({attribute:"auto-scroll",mode:"boolean"})],p.prototype,"autoScroll",void 0),(0,s.Cg)([(0,l.CF)({attribute:"auto-scroll-interval-ms",converter:l.R$})],p.prototype,"autoScrollIntervalMs",void 0),(0,s.Cg)([(0,l.CF)({attribute:"auto-scroll-delay-ms",converter:l.R$})],p.prototype,"autoScrollDelayMs",void 0),(0,s.Cg)([o.sH],p.prototype,"nextFlipperTelemetryTag",void 0),(0,s.Cg)([o.sH],p.prototype,"previousFlipperTelemetryTag",void 0),(0,s.Cg)([o.sH],p.prototype,"direction",void 0),(0,s.Cg)([l.CF],p.prototype,"orientation",void 0),(0,s.Cg)([l.CF],p.prototype,"activeid",void 0),(0,s.Cg)([(0,l.CF)({attribute:"initial-id",converter:l.R$})],p.prototype,"initialId",void 0),(0,s.Cg)([o.sH],p.prototype,"tabs",void 0),(0,s.Cg)([o.sH],p.prototype,"tabpanels",void 0),(0,s.Cg)([(0,l.CF)({mode:"boolean"})],p.prototype,"activeindicator",void 0),(0,s.Cg)([o.sH],p.prototype,"activeIndicatorRef",void 0),(0,s.Cg)([o.sH],p.prototype,"showActiveIndicator",void 0)},93533(t,i,e){e.d(i,{m(){return w}});var r=e(26813),a=e(37180),s=e(74849),o=e(64187),n=e(22131),l=e(50882),h=e(7896),d=e(41123),c=e(48751),p=e(57416),u=e(4283);const g=s.A`
    ${(0,o.V)("grid")} :host {
        box-sizing: border-box;
        font-family: ${h.O};
        font-size: ${d.K};
        line-height: ${d.Z};
        color: ${c.l};
        grid-template-columns: auto 1fr auto;
        grid-template-rows: auto 1fr;
    }

    .tablist {
        display: grid;
        grid-template-rows: auto auto;
        grid-template-columns: auto;
        position: relative;
        width: max-content;
        align-self: end;
    }

    ::slotted([slot="start"]),
    ::slotted([slot="end"]) {
        align-self: center;
    }

    :host([orientation="horizontal"]) ::slotted([slot="end"]) {
        grid-column: 3;
    }

    .active-indicator {
        grid-row: 2;
        grid-column: 1;
        width: 20px;
        height: 3px;
        border-radius: calc(${p.Pb} * 1px);
        justify-self: center;
        background: ${u.IR};
    }

    .activeIndicatorTransition {
        transition: transform 0.2s ease-in-out;
    }

    .tabpanel {
        grid-row: 2;
        grid-column-start: 1;
        grid-column-end: 4;
        position: relative;
    }

    :host([orientation="vertical"]) {
        grid-template-rows: auto 1fr auto;
        grid-template-columns: auto 1fr;
    }

    :host([orientation="vertical"]) .tablist {
        grid-row-start: 2;
        grid-row-end: 2;
        display: grid;
        grid-template-rows: auto;
        grid-template-columns: auto 1fr;
        position: relative;
        width: max-content;
        justify-self: end;
        width: 100%;
    }

    :host([orientation="vertical"]) .tabpanel {
        grid-column: 2;
        grid-row-start: 1;
        grid-row-end: 4;
    }

    :host([orientation="vertical"]) ::slotted([slot="end"]) {
        grid-row: 3;
    }

    :host([orientation="vertical"]) .active-indicator {
        grid-column: 1;
        grid-row: 1;
        width: 3px;
        height: 20px;
        border-radius: calc(${p.Pb} * 1px);
        align-self: center;
        background: ${u.IR};
    }

    :host([orientation="vertical"]) .activeIndicatorTransition {
        transition: transform 0.2s linear;
    }
`.withBehaviors((0,n.mr)(s.A`
            .active-indicator,
            :host([orientation="vertical"]) .active-indicator {
                forced-color-adjust: none;
                background: ${l.A.Highlight};
            }
        `));var v=e(96950),f=e(82774),b=e(69259),x=e(60402),$=e(35106);const m=function(t={}){return v.qy`
        ${(0,$.LT)(t)}
        <div class="tablist" part="tablist" role="tablist">
            <slot name="tab" ${(0,f.e)("tabs")}></slot>

            ${(0,b.z)(t=>t.showActiveIndicator,v.qy`
                    <div
                        ${(0,x.K)("activeIndicatorRef")}
                        class="active-indicator"
                        part="active-indicator"
                    ></div>
                `)}
        </div>
        ${(0,$.aO)(t)}
        <div class="tabpanel" part="tabpanel">
            <slot name="tabpanel" ${(0,f.e)("tabpanels")}></slot>
        </div>
    `}(),w=r.D.compose({name:`${a.c.prefix}-tabs`,template:m,styles:g})},94533(t,i,e){e.d(i,{K(){return u}});var r=e(74849),a=e(50882),s=e(64187),o=e(22131),n=e(73477),l=e(14996),h=e(95239),d=e(7896),c=e(26920),p=e(48751);const u=r.A`
    ${(0,s.V)("inline-flex")} :host{box-sizing:border-box;font-family:${d.O};
        min-height: 6px;
        min-width: 6px;
        background-color: ${p.l};
        border-radius: 20px;
        opacity: 0.4;
        grid-row: 1;
        z-index: 1;
        margin: 10px 2px;
        border: calc(${c.XA} * 1px) solid transparent}:host([aria-selected="true"]){z-index:2;opacity:1;min-width:30px}:host(:hover),:host(:active){background:${p.l};
        opacity: 1;
    }

    :host(:${n.N}){outline:none;box-shadow:0 0 0 calc((${c.vd} - ${c.XA}) * 1px) ${h.p}, 0 0 0 calc((${c.vd} + ${c.XA}) * 1px)
            ${l.WN}}:host(:focus){outline:none}`.withBehaviors((0,o.mr)(r.A` :host{forced-color-adjust:none;background:${a.A.ButtonText};opacity:1}:host(:hover),:host([aria-selected="true"]:hover),:host([aria-selected="true"]){background:${a.A.Highlight};
            }
            :host(:${n.N}){border-color:${a.A.ButtonFace};
                box-shadow: 0 0 0 calc((${c.vd} - ${c.XA}) * 1px)
                rgba(0,0,0,1), 0 0 0 calc((${c.vd} + ${c.XA}) * 1px)
                ${a.A.ButtonText};
            }
        `))},97266(t,i,e){e.d(i,{e(){return s}});var r,a=e(48566);!function(t){t[t.Default=0]="Default",t[t.Medium=1]="Medium",t[t.MonthDate=2]="MonthDate",t[t.Weekday=3]="Weekday",t[t.Time=4]="Time"}(r||(r={}));class s{constructor(){this.dateFormatOptionsMap=new Map,this.setSupportsLocaleSpecifiers(),this.dateFormatOptionsMap.set(r.Medium,{year:"numeric",month:"short",day:"numeric"}),this.dateFormatOptionsMap.set(r.MonthDate,{month:"short",day:"numeric"}),this.dateFormatOptionsMap.set(r.Weekday,{weekday:"short"}),this.dateFormatOptionsMap.set(r.Time,{hour:"numeric",minute:"numeric"})}overrideDateFormat(t,i){t&&i&&this.dateFormatOptionsMap.set(t,i)}localizedDateString(t,i){return this.formatDate(t,r.Default,i)}localizedDateStringMedium(t,i){return this.formatDate(t,r.Medium,i)}localizedMonthDate(t,i){return this.formatDate(t,r.MonthDate,i)}localizedWeekday(t,i){return this.formatDate(t,r.Weekday,i)}formatTimeFromDate(t,i){return this.supportsLocaleSpecifiers&&this.dateFormatOptionsMap?t.toLocaleTimeString(i,this.dateFormatOptionsMap.get(r.Time)):t.toTimeString()}format(t){if(!t)return"";for(var i=arguments.length,e=new Array(i>1?i-1:0),r=1;r<i;r++)e[r-1]=arguments[r];return a.Qf.Format(t,...e)}localizedNumberString(t,i){return this.supportsLocaleSpecifiers?t.toLocaleString(i):t.toString()}formatDate(t,i,e){let a=null;if(this.supportsLocaleSpecifiers)if(i===r.Default)a=t.toLocaleDateString(e);else if(this.dateFormatOptionsMap){const r=this.dateFormatOptionsMap.get(i);a=t.toLocaleDateString(e,r)}return null===a&&(a=t.toDateString()),null!==a?a.replace(/\u200E/g,"").replace(/\u200F/g,""):a}setSupportsLocaleSpecifiers(){this.supportsLocaleSpecifiers=(()=>{try{(0).toLocaleString("i")}catch(t){return"RangeError"===t.name}return!1})()}}},98602(t,i,e){e.d(i,{FN(){return p}});var r=e(5675),a=e(99900),s=e(91889),o=e(74849),n=e(64187),l=e(22131),h=e(20197);const d=o.A`
        ${h.V}

        ${(0,n.V)("flex")} ::slotted(*){width:100%}`.withBehaviors((0,l.mr)(o.A` :host{forced-color-adjust:auto}`));class c extends s.b{}const p=c.compose({name:`${a.i.prefix}-carousel-card-panel`,template:(0,r.S)(),styles:d})},99751(t,i,e){e.d(i,{s(){return l}});var r=e(56911),a=e(92011),s=e(38493),o=e(35106),n=e(88458);class l extends a.L{}(0,r.Cg)([(0,s.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],l.prototype,"disabled",void 0),(0,n.X)(l,o.qw)}}]);