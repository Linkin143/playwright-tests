// © Microsoft Corporation. All rights reserved.
// Inline script entry point that will run on base html before any external script is loaded.
// @ts-ignore TS2882
import "@msnews/ssr-util/install-ssr-custom-elements";
import { ReplayablePubsub } from "@msnews/fundamentals";
import { defineMarkTTSR } from "@msnews/ssr-util";
import { setupLiteTelemetryFunctions, setLitePvShouldWaitForPageVisible, setupLiteTelemetryLoadTime, updateLiteTelemetryRIDIfCached, sendLiteActionEvent } from "@msnews/lite-telemetry";
import { logError } from "@msnews/page-error-handling";
if (window.isSSREnabled) {
    window._pageTimings ?? (window._pageTimings = {});
    defineMarkTTSR();
    // Disable browser's scroll position restoration -- so page won't autoscroll when refresh a SSR page
    // https://developer.mozilla.org/en-US/docs/Web/API/History/scrollRestoration
    history.scrollRestoration = "manual";
    setupLiteTelemetryFunctions();
    setupLiteTelemetryLoadTime();
    setLitePvShouldWaitForPageVisible(false);
    updateLiteTelemetryRIDIfCached();
    window.ssrLoadedExperience = new ReplayablePubsub();
    window.ssrLoadedBundles = new ReplayablePubsub();
    window.publishLoadedBundles = window.ssrLoadedExperience.bulkPublish.bind(window.ssrLoadedExperience);
    /** Listen to event fired when search box is added to the DOM, add search box form submit listener if form element is found */
    window.addEventListener("TTSR.SearchBox", () => {
        try {
            const outerSearchboxComponent = document.querySelector("entry-point")
                .shadowRoot.querySelector("msn-homepage-header")
                .shadowRoot.querySelector("cs-common-search-box");
            if (!outerSearchboxComponent) {
                throw new Error("Outer search box component not found");
            }
            const searchForm = outerSearchboxComponent.shadowRoot.querySelector("form");
            if (!searchForm) {
                throw new Error("Inner search box component not found");
            }
            const inputElement = searchForm.querySelector("input");
            const submitButton = searchForm.querySelector("fluent-button");
            const submitAndSendActionEvent = () => {
                searchForm.submit();
                sendLiteActionEvent(searchForm, "submit");
            };
            const onKeypress = (event) => {
                if (event.key === "Enter") {
                    event.preventDefault();
                    submitAndSendActionEvent();
                }
            };
            const onSubmitButtonClick = () => {
                submitAndSendActionEvent();
            };
            inputElement.addEventListener("keypress", onKeypress);
            submitButton.addEventListener("click", onSubmitButtonClick);
            window.addEventListener("SearchBoxHydrated", () => {
                inputElement.removeEventListener("keypress", onKeypress);
                submitButton.removeEventListener("click", onSubmitButtonClick);
            }, { once: true });
        }
        catch (e) {
            logError("Exception occurred while adding search box form submit event listener", 34018, { error: e.message });
        }
    }, { once: true });
}
//# sourceMappingURL=SSR-Extension.js.map