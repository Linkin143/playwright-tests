// © Microsoft Corporation. All rights reserved.
import { createObjectTelemetry, createObjectTelemetryEx } from "@msnews/experiences-telemetry";
import { TelemetryActionType, TelemetryBehaviorType, TelemetryType } from "@msnews/telemetry-contracts";
export const msnLogoTelemetryObject = createObjectTelemetry("msnLogo", TelemetryBehaviorType.Refresh, TelemetryActionType.Click, TelemetryType.ActionButton);
export const searchButtonTelemetryObject = createObjectTelemetry("searchButton", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ActionButton);
export const searchButtonViewTelemetryObject = createObjectTelemetry("searchButtonView", TelemetryBehaviorType.Show, TelemetryActionType.View, TelemetryType.ActionButton);
export const infopaneTelemetryObject = createObjectTelemetry("infopane", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const infopaneViewTelemetryObject = createObjectTelemetry("infopaneView", TelemetryBehaviorType.Show, TelemetryActionType.View, TelemetryType.ContentCard);
export const artical1TelemetryObject = createObjectTelemetry("artical1", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical1TelemetryObject = createObjectTelemetry("mobartical1", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const artical1ViewTelemetryObject = createObjectTelemetry("artical1View", TelemetryBehaviorType.Show, TelemetryActionType.View, TelemetryType.ContentCard);
export const artical2TelemetryObject = createObjectTelemetry("artical2", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical2TelemetryObject = createObjectTelemetry("mobartical2", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const artical2ViewTelemetryObject = createObjectTelemetry("artical2View", TelemetryBehaviorType.Show, TelemetryActionType.View, TelemetryType.ContentCard);
export const artical3TelemetryObject = createObjectTelemetry("artical3", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical3TelemetryObject = createObjectTelemetry("mobartical3", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const artical3ViewTelemetryObject = createObjectTelemetry("artical3View", TelemetryBehaviorType.Show, TelemetryActionType.View, TelemetryType.ContentCard);
export const artical4TelemetryObject = createObjectTelemetry("artical4", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical4TelemetryObject = createObjectTelemetry("mobartical4", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const artical5TelemetryObject = createObjectTelemetry("artical5", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical5TelemetryObject = createObjectTelemetry("mobartical5", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const artical6TelemetryObject = createObjectTelemetry("artical6", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical6TelemetryObject = createObjectTelemetry("mobartical6", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const artical7TelemetryObject = createObjectTelemetry("artical7", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical7TelemetryObject = createObjectTelemetry("mobartical7", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const artical8TelemetryObject = createObjectTelemetry("artical8", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical8TelemetryObject = createObjectTelemetry("mobartical8", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const artical9TelemetryObject = createObjectTelemetry("artical9", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical9TelemetryObject = createObjectTelemetry("mobartical9", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const artical10TelemetryObject = createObjectTelemetry("artical10", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobartical10TelemetryObject = createObjectTelemetry("mobartical10", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const nativeAds0TelemetryObject = createObjectTelemetry("nativeAds0", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobnativeAds0TelemetryObject = createObjectTelemetry("mobnativeAds0", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const nativeAds1TelemetryObject = createObjectTelemetry("nativeAds1", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobnativeAds1TelemetryObject = createObjectTelemetry("mobnativeAds1", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const nativeAds2TelemetryObject = createObjectTelemetry("nativeAds2", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobnativeAds2TelemetryObject = createObjectTelemetry("mobnativeAds2", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const nativeAds3TelemetryObject = createObjectTelemetry("nativeAds3", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const mobnativeAds3TelemetryObject = createObjectTelemetry("mobnativeAds3", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const bannerTelemetryObject = createObjectTelemetry("banner", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.ContentCard);
export const bannerViewTelemetryObject = createObjectTelemetry("bannerView", TelemetryBehaviorType.Show, TelemetryActionType.View, TelemetryType.Section);
export const footerTelemetryObject = createObjectTelemetry("footer", TelemetryBehaviorType.Navigate, TelemetryActionType.Click, TelemetryType.Footer);
export const mainTelemetryObject = createObjectTelemetryEx("main", {
    type: TelemetryType.Section
});
//# sourceMappingURL=IE11NTPHomepage.telemetry.js.map