"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-info-price-spotlight"],{1817(t,e,i){i.r(e),i.d(e,{MoneyInfoDateFilterChart(){return $}});var r=i(56911),a=i(27208),o=i(92707),n=i(60815);class l extends o.z{get isOneDayChart(){return!this.chartType||this.chartType===a.NB.OneDayOneMinute}get accentColor(){var t;if(this.isOneDayChart)return this.viewModel.accentColor;return(null===(t=this.getState().get(a.Xe.ChartDateFilterData))||void 0===t?void 0:t[this.chartType]).changePcntNumber>0?this.viewModel.positiveColor:this.viewModel.negativeColor}get baselinePrice(){var t;return this.isOneDayChart?null===(t=this.chartData)||void 0===t?void 0:t.chartBaseline:void 0}get chartData(){var t,e,i;if(this.isOneDayChart)return this.viewModel.chartData;const r=null===(t=this.getState().get(a.Xe.ChartDateFilterData))||void 0===t?void 0:t[this.chartType];return r?{chartSeries:null===(e=r.chartData)||void 0===e?void 0:e.series,pricesMaxCount:null===(i=r.chartData)||void 0===i?void 0:i.total,chartBaseline:r.pricePreviousClose,changePcnt:r.changePcnt}:{}}handleChangeFilter(t){this.viewModel.handleDateFilterChartChange(this.viewModel.quote.id,t)}updateChart(t){this.chartType=t}addSubscriptions(){super.addSubscriptions(),this.getState().subscribe(a.Xe.ChartDateFilterChartType,this.updateChart.bind(this),{signal:this.subscriptionController.signal})}}(0,r.Cg)([n.sH],l.prototype,"chartType",void 0);var s=i(92011),h=i(12640),d=i(74849),c=i(64003);const g=d.A` :host{--active-color:#235CCF}.filter button.selected,.filter button.selected:hover,.filter button.selected:active,.filter button.selected:focus{background-color:var(--active-color)}.filter button{color:#FFF}.sp-hero .filter button{color:#ADADAD}.sp-hero .filter button.selected{color:#FFF;background-color:#292929}`,p=d.A` :host{--active-color:#2169EB}.filter{display:flex;justify-content:space-between;margin-top:4px}.filter button.selected{background-color:var(--active-color);color:#FFF}.filter button{cursor:pointer;width:36px;height:18px;overflow:hidden;border-radius:20px;white-space:nowrap;padding:3px 6px;border:0px;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);background-color:var(--quote-background)}.filter button:hover{background-color:var(--quote-hover-background)}.filter button:active,.filter button:focus{background-color:var(--quote-active-background)}.no-data{display:flex;align-items:center;justify-content:center;width:244px;height:70px;box-sizing:border-box;padding-bottom:16px;color:${c.c}}.sp-hero .filter{margin-top:8px}.sp-hero .filter button{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);height:20px;width:34px;background-color:transparent;font-weight:400;color:#242424}.sp-hero .filter button.selected{background-color:#E0EDFF;font-weight:600}`.withBehaviors(new h.N(null,g));var u=i(96950),v=i(39957);const m=u.qy`<div class="filter">${(0,v.ux)(t=>t.viewModel.filterButtonsList,u.qy`<button class="${(t,e)=>t.id!==e.parent.chartType&&e.parent.chartType?"":"selected"}" data-t="${t=>t.telemetryTag}" @click=${(t,e)=>e.parent.handleChangeFilter(t.id)} title="${t=>t.title}" aria-current="${(t,e)=>t.id===e.parent.chartType||!e.parent.chartType}">${t=>t.title}</button>`)}</div>`,f=u.qy`<msn-stock-chart width=${t=>t.viewModel.chartWidth} height=${t=>t.viewModel.chartHeight} skip-transform=${()=>!0} fill-color=${t=>t.accentColor} baseline-color=${t=>t.viewModel.baselineColor} baseline-text=${t=>t.viewModel.previousCloseText} :changePcnt=${t=>t.viewModel.isSpotlightHero?"":t.viewModel.chartData.changePcnt??""} :isDarkModeTheme=${t=>t.viewModel.isDarkModeTheme} :baselinePrice=${t=>t.baselinePrice} :pricesMaxCount=${t=>t.chartData.pricesMaxCount} :enableBaselineText=${t=>t.viewModel.enableBaselineText&&t.isOneDayChart} :enableChangePcntText=${t=>t.isOneDayChart} :prices=${t=>{var e;return null===(e=t.chartData)||void 0===e?void 0:e.chartSeries}} :enableAnimation=${t=>t.viewModel.isChartAnimationEnabled} :fullAnimationDuration=${t=>t.viewModel.chartAnimationDuration} :hasConnectingLine=${t=>t.viewModel.isSpotlightHero} :lineWidth=${t=>t.viewModel.isSpotlightHero?1:1.5} :circleRadius=${t=>t.viewModel.isSpotlightHero?3:4} :baselineDashArray=${t=>t.viewModel.isSpotlightHero?"1 4":"3 5"}></msn-stock-chart>`,x=u.qy`<div class="no-data" style="width: ${t=>t.viewModel.chartWidth}px; height: ${t=>t.viewModel.chartHeight}px">${t=>t.viewModel.strings.dataIsNotAvailable}</div>`,b=u.qy`<template><div class="${t=>t.viewModel.isSpotlightHero?"sp-hero":""}">${t=>{var e;return null!==(e=t.chartData)&&void 0!==e&&null!==(e=e.chartSeries)&&void 0!==e&&e.length?f:x}} ${m}</div></template>`;let $=class extends l{};$=(0,r.Cg)([(0,s.E)({name:"date-filter-chart",template:b,styles:p,shadowOptions:{delegatesFocus:!0}})],$)},3322(t,e,i){i.r(e),i.d(e,{PriceSpotlight(){return I}});var r=i(56911),a=i(27208),o=i(92707),n=i(60815);class l extends o.z{constructor(){super(...arguments),this.chartType=a.NB.OneDayOneMinute}get chartData(){return this.viewModel.chartData}get hasLogoClass(){return this.viewModel.hasLogo?"small-logo":""}updateChartType(t){this.chartType=t}addSubscriptions(){var t;super.addSubscriptions(),null===(t=this.getState())||void 0===t||t.subscribe(a.Xe.ChartDateFilterChartType,this.updateChartType.bind(this),{signal:this.subscriptionController.signal})}get shouldUseChartChangePcnt(){return this.chartType&&this.chartType!==a.NB.OneDayOneMinute}get quoteDataByChartType(){var t,e;let i;var r,o;this.chartType===a.NB.OneDayOneMinute?i=null===(r=this.viewModel.chartData)||void 0===r?void 0:r.chartData:i=null===(o=this.getState())||void 0===o?void 0:o.get(a.Xe.ChartDateFilterData)[this.chartType];const n=this.shouldUseChartChangePcnt?null===(t=i)||void 0===t?void 0:t.changePcnt:null,l=this.shouldUseChartChangePcnt?null===(e=i)||void 0===e?void 0:e.changePcntNumber:null,s=n||this.viewModel.quote.changePcnt,h=l||this.viewModel.quote.changePcntNumber;return this.viewModel.getQuoteDataByChartType(this.chartType,s,h)}get changePcntColor(){return this.quoteDataByChartType.accentColor}get changePcnt(){return this.quoteDataByChartType.changePcnt}onSizeChange(t){}onChartDictChange(t){const e=this.viewModel.chartData;var i,r;e&&t&&(e.chartSeries=null==t||null===(i=t[this.viewModel.quote.id])||void 0===i||null===(i=i.chartData)||void 0===i?void 0:i.series,e.chartBaseline=null==t||null===(r=t[this.viewModel.quote.id])||void 0===r?void 0:r.pricePreviousClose,this.viewModel={...this.viewModel,chartData:e})}onQuoteItemDictChange(t){var e;const i=null===(e=this.viewModel)||void 0===e||null===(e=e.quote)||void 0===e?void 0:e.id,r=null==t?void 0:t[i];r&&(this.viewModel={...this.viewModel,quote:{...r}})}}(0,r.Cg)([n.sH],l.prototype,"chartType",void 0);var s=i(92011),h=i(48751),d=i(64003),c=i(86856),g=i(4968),p=i(12640),u=i(74849);const v=u.A`
`,m=u.A` .notf-icon{margin:0 0 0 6px}.ai-insight .notf-icon{margin:0 6px 0 0}.prct-change-wrap{margin:0px 6px 0px 0px}.text-block > div:nth-child(2){text-align:right}.text-block > div:nth-child(3){transform:rotate(180deg)}`,f=u.A` .vertical-logo img{border:1px solid rgba(0,0,0,0.09)}.text-block{background:#1F1F1F}.text-block:hover{background:rgba(255,255,255,0.1)}`,x=u.A` .wrap-link{text-decoration:none}.wrap-link:focus-visible{outline-offset:-1px}.wrapper{background:none;height:100%;border-radius:8px;padding:10px;box-sizing:border-box;${g.f}}.ai-insight .wrapper{background:none;border-radius:0;padding:0}.small.wrapper{display:grid;grid-template-columns:auto min-content;row-gap:2px;column-gap:4px}.small.wrapper.small-logo{grid-template-columns:40px auto min-content;align-items:center}.medium.wrapper,.large.wrapper{display:flex;flex-direction:column;align-items:space-between}.small .full-title,.small .price,.small .prct-change,.small .notf-text{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);color:${h.l}}.full-title{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.notellipsis{white-space:nowrap;overflow:visible}.price,.notf-text,.prct-change{font-weight:600}.small .full-title{color:${h.l}}.small .symb{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);color:${d.c};margin-top:2px}.small.small-logo .symb{margin-top:0px}.medium .full-title,.large .full-title{margin:0 6px;color:${d.c}}.small .price,.small .prct-change{text-align:end}.medium .price,.large .price{margin-bottom:2px;color:${h.l}}.medium .price{font-size:var(--type-ramp-plus-4-font-size,28px);line-height:var(--type-ramp-plus-4-line-height,36px)}.price-wrap{display:flex;align-items:baseline}.ai-insight .price-wrap{align-items:center}.prct-change-wrap{margin:0px 0px 0px 6px}.large .price{margin-bottom:2px;font-size:var(--type-ramp-plus-5-font-size,32px);line-height:var(--type-ramp-plus-5-line-height,40px)}._1x_1y .sm-font.price{font-size:var(--type-ramp-base-font-size,14px)}._1x_2y .sm-font.price,._1x_3y .sm-font.price{font-size:var(--type-ramp-plus-3-font-size,24px) !important;line-height:var(--type-ramp-plus-3-line-height,32px) !important}.notf{display:flex;align-items:center}.notf-icon{height:16px;width:16px;margin:0 6px 0 0}.ai-insight .notf-icon{margin:0 0 0 6px}.medium .notf-text,.medium .prct-change{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.large .notf-text,.large .prct-change{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px)}.symb{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);color:${h.l};font-weight:600}.large .notf-icon{height:20px;width:20px}.name-block{display:flex;align-items:baseline;max-width:268px}.chartBox{margin-top:auto;margin-bottom:0}.vertical-quote{width:248px;display:flex;align-items:center;margin-bottom:6px}.vertical-quote .full-title{margin:0}.vertical-name-block{flex:1;display:flex;flex-direction:column;min-width:0}.vertical-logo img,.small-logo-area img{height:40px;border-radius:50%;border:1px solid rgba(0,0,0,0.1);margin-right:12px;box-sizing:border-box}._1x_3y .vertical-logo img{height:56px;border-radius:50%;margin-right:16px}.sl-sm-left{min-width:0}.sl-sm-right{display:flex;flex-direction:column;align-items:flex-end}.small-logo .sl-sm-left{margin-left:8px}.small-logo .symb{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px)}._1x_3y .small-logo .symb{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px)}.ellipsis{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sp-hero .wrapper{padding:0px}.text-block{display:flex;align-items:center;justify-content:space-between;height:49px;width:268px;color:${h.l};;
        background: rgba(244, 244, 244, 1);
        border-radius: 8px;
        margin-top: 12px;
        margin-bottom: 8px;
        padding: 0 8px;
        box-sizing: border-box;
        ${g.f};text-decoration:none}.text-block:hover{background:#ebebeb}.text-block > div{display:inline-block;text-align:center;height:33px;width:212px;line-height:16px;font-size:12px;text-align:left;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis}`.withBehaviors(new p.N(null,f),new c.t(v,m));var b=i(96950),$=i(69259);const y=b.qy`<span class="notf-text" style="color: ${t=>{var e;return null===(e=t.quoteDataByChartType.notification)||void 0===e?void 0:e.accentColor}}">${t=>{var e;return null===(e=t.quoteDataByChartType.notification)||void 0===e?void 0:e.shortHeadline}}</span>`,w=b.qy` ${(0,$.z)(t=>t.quoteDataByChartType.notification,b.qy`<img class="notf-icon" src="${t=>{var e;return null===(e=t.quoteDataByChartType.notification)||void 0===e?void 0:e.iconUrl}}" alt=${t=>t.viewModel.secondaryName} />`)}
`,k=b.qy`<div class="price ${t=>t.viewModel.hasSmallPriceFont?"sm-font":""}">${t=>t.viewModel.quote.price}</div>`,C=b.qy`<div class="prct-change ellipsis" style="color: ${t=>t.changePcntColor}">&lrm;${t=>t.viewModel.quote.priceNumber?t.changePcnt:"-"}&lrm;</div>`,z=b.qy`<img loading="lazy" alt="${t=>t.viewModel.secondaryName}" src="${t=>t.viewModel.logoUrl}">`,D=b.qy`<div class="small-logo-area">${z}</div>`,P=b.qy` ${(0,$.z)(t=>t.quoteDataByChartType.notification,b.qy`<span class="notf">${w} ${y}</span>`)}
`,T=b.qy`<div class="wrapper small ${t=>t.hasLogoClass}">${(0,$.z)(t=>t.viewModel.hasLogo,D)}<div class="sl-sm-left"><div class="full-title ellipsis">${t=>t.viewModel.primaryName}</div><div class="ellipsis">${P} ${(0,$.z)(t=>!t.quoteDataByChartType.notification,b.qy`<div class="symb ellipsis">${t=>t.viewModel.secondaryName}</div>`)}</div></div><div class="sl-sm-right">${k} ${C}</div></div>`,F=b.qy`<div class="name-block"><div class="symb ellipsis">${t=>t.viewModel.primaryName}</div><div class="full-title notellipsis">${t=>t.viewModel.secondaryName}</div></div>`,M=b.qy`<div class="vertical-quote"><div class="vertical-logo">${z}</div><div class="vertical-name-block"><span class="symb ellipsis">${t=>t.viewModel.primaryName}</span><span class="full-title notellipsis">${t=>t.viewModel.secondaryName}</span></div></div>`,_=b.qy`<a class="text-block" href="${t=>{var e;return null===(e=t.viewModel.aiInsightItem)||void 0===e?void 0:e.insightClickThroughUrl}}" target="${t=>t.viewModel.openLinksInNewTab?"_blank":"_self"}" data-t="${t=>t.viewModel.aiInsightTelemetryTag}" title="${t=>{var e;return null===(e=t.viewModel.aiInsightItem)||void 0===e?void 0:e.insightStatement}}" aria-label="${t=>{var e;return null===(e=t.viewModel.aiInsightItem)||void 0===e?void 0:e.insightStatement}}"><ai-insight-badge :status=${t=>{var e;return null===(e=t.viewModel.aiInsightItem)||void 0===e?void 0:e.evaluationStatus}} :isDarkModeTheme=${t=>t.viewModel.isDarkModeTheme}></ai-insight-badge><div>${t=>{var e;return(null===(e=t.viewModel.aiInsightItem)||void 0===e?void 0:e.insightStatement)||""}}</div><img src="${t=>{var e;return null===(e=t.viewModel.aiInsightItem)||void 0===e?void 0:e.rightIcon}}" alt="" loading=lazy></a>`,N=b.qy`<div class=" wrapper ${t=>"_1x_2y"===t.viewModel.cardSize?"medium":"large"} ${t=>t.hasLogoClass} "><div class="main">${t=>t.viewModel.hasLogo?M:F}<div class="price-wrap">${k} ${(0,$.z)(t=>t.viewModel.isWithInsights,w)}<span class="prct-change-wrap ellipsis">${C}</span></div>${(0,$.z)(t=>!t.viewModel.isWithInsights,P)}</div>${(0,$.z)(t=>t.viewModel.dateFilterChartData,b.qy`<div class="chartBox"><date-filter-chart :viewModel="${t=>t.viewModel.dateFilterChartData}"></date-filter-chart></div>`)} ${(0,$.z)(t=>t.viewModel.isWithInsights,_)}</div>`,S=b.qy`<a class="wrap-link ${t=>t.viewModel.cardSize} ${t=>t.viewModel.isSpotlightHero?"sp-hero":""} ${t=>t.viewModel.isWithInsights?"ai-insight":""}" href="${t=>t.viewModel.destinationUrl}" target="${t=>t.viewModel.openLinksInNewTab?"_blank":"_self"}" data-t="${t=>t.viewModel.telemetryTag}" title="${t=>t.viewModel.tooltipText}" aria-label="${t=>{var e;return null===(e=t.viewModel.footerData.footerButton)||void 0===e?void 0:e.text}}" aria-live="polite" role="status">${t=>"_1x_1y"===t.viewModel.cardSize?T:N}</a>`,A=b.qy` ${(0,$.z)(t=>t&&t.viewModel,S)}
`;let I=class extends l{};I=(0,r.Cg)([(0,s.E)({name:"price-spotlight",template:A,styles:x,shadowOptions:{delegatesFocus:!0}})],I)},4968(t,e,i){i.d(e,{f(){return s}});var r=i(64187),a=i(74849),o=i(42792),n=i(99657),l=i(36452);const s=a.A.partial`position: relative; z-index: ${n.D};`;a.A`
    ${o.e}
    ${o.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${s}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},42792(t,e,i){i.d(e,{R7(){return v},e(){return p},kc(){return u},nH(){return g}});var r=i(57416),a=i(55153),o=i(95239),n=i(26920),l=i(48751),s=i(64187),h=i(22131),d=i(74849),c=i(50882);const g=d.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,p=d.A`
    ${(0,s.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${n.XA} * 1px) solid ${a.cu};
        border-radius: calc((${r.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${l.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,h.mr)(d.A`
            :host {
                background: ${c.A.Canvas};
                color: ${c.A.CanvasText};
            }
        `),v=d.A`
    ${p}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},44139(t,e,i){i.r(e),i.d(e,{DateFilterChartTransformer(){return r.i},MSNStockChartTransformer(){return a.u},PriceSpotlightTransformer(){return u}});var r=i(84953),a=i(88015),o=i(27208),n=i(49150),l=i(86449),s=i(30236),h=i(96950),d=i(58792),c=i(54229),g=i(22341),p=i(93552);class u extends o.IB{async transform(t){var e;this.quote=t.quote,this.previewType=t.previewType,this.notifications=null===(e=t.quoteNotificationDetails)||void 0===e?void 0:e[this.quote.id],this.cardSize=t.cardSize,this.isDarkModeTheme=(0,l.jJ)(),(0,l.ih)(this.quote,t.tabName);const i=await this.getCurrentViewModel(t);return{viewTemplate:h.qy`
                <price-spotlight
                    :viewModel="${i}"
                ></price-spotlight>`}}getNotificationsInfo(t){const e=this.getNotificationData(t);return e?{iconUrl:this.getNotfIconUrl(e,t),shortHeadline:e.shortHeadline,accentColor:(0,l.bQ)(e,{...this.quote,changePcntNumber:t},this.isDarkModeTheme,this.transformerProvider.config.swapGainLossColor)}:null}getNotificationData(t){const e=(0,l.U7)(this.previewType,this.notifications);if(null!=e&&e.length)return e[0];{const e={...this.quote,changePcntNumber:t};if(Boolean(this.quote.changePcntNumber))return(0,l.nW)(e,[],this.transformerProvider.strings,!0)}}getAccentColor(t){return(0,l.BK)(this.isDarkModeTheme,t||0,this.transformerProvider.config.swapGainLossColor)}get chartWidth(){return this.isWithInsights?268:244}get chartHeight(){return this.cardSize===n.uE._1x_2y?70:192}get logoUrl(){const{cryptos:t,deprecatedToNewCryptos:e}=this.transformerProvider.config;return(0,l.ue)(t,e,(0,l.EL)(this.quote)||"")}getNotfIconUrl(t,e){var i;return(0,s.kX)(this.transformerProvider.config.urls,e||0,null==t?void 0:t.notificationType,this.transformerProvider.config.swapGainLossColor,null==t||null===(i=t.notification)||void 0===i?void 0:i.signal)}get chartPricePreviousClose(){var t;return(null===(t=this.chartData)||void 0===t?void 0:t.chartBaselineLoc)||""}hasLogo(){const{cryptos:t,deprecatedToNewCryptos:e}=this.transformerProvider.config;return!(!(0,l.qA)(t,e,this.quote)||void 0===this.logoUrl)}getChartChangePcntNumber(t){var e,i;return(0,l.tc)(null===(e=t.chartData)||void 0===e?void 0:e.chartType,!1,null===(i=t.chartData)||void 0===i?void 0:i.changePcntNumber,t.quote.changePcntNumber)}async updateDateFilterChartData(t){if(!this.chartData)return void(this.dateFilterChartData=void 0);const e=this.getChartChangePcntNumber(t),i={experienceName:t.experienceName,chartData:this.chartData,accentColor:this.getAccentColor(e||0),quote:t.quote,chartHeight:this.chartHeight,chartWidth:this.chartWidth,telemetryObject:t.telemetryObject,previousCloseText:(0,l.Fq)(this.chartPricePreviousClose,this.transformerProvider.strings.previousClose)},r=await this.transformerProvider.generateView(i,o.Ai.DateFilterChart);this.dateFilterChartData=r.viewModel}async generateChartData(t){const{quote:e,chartData:i,cardSize:r}=t,a={quote:e,chartData:i,cardSize:r};return(await this.transformerProvider.generateView(a,o.Ai.MSNStockChart)).viewModel}getQuoteDataByChartType(t,e,i){return{accentColor:this.getAccentColor(i),notification:t===o.NB.OneDayOneMinute?this.getNotificationsInfo(i):null,changePcnt:this.getChangePcnt(t,e)}}getChangePcnt(t,e){var i;if(this.cardSize===n.uE._1x_1y)return e;const{changePcntPeriod5D:r,changePcntPeriod1W:a,changePcntPeriod1M:l,changePcntPeriod3M:s,changePcntPeriod1Y:h,changePcntPeriod5Y:d,changePcntPeriodAll:c}=this.transformerProvider.strings;return(null===(i={[o.NB.OneDayOneMinute]:"{0}",[o.NB.FiveDays]:r,[o.NB.OneWeekFifteenMinutes]:a,[o.NB.OneMonth]:l,[o.NB.ThreeMonth]:s,[o.NB.OneYear]:h,[o.NB.FiveYear]:d,[o.NB.All]:c}[t])||void 0===i?void 0:i.replace("{0}",e||""))||""}getPrimaryAndSecondaryName(t){return{primaryName:t.shortName||t.displayName||"",secondaryName:t.symbol||""}}getInsightItem(t){var e,i,r;const a=t.quote.aiInsightData;if(!a)return;const n=null==a||null===(e=a.insights)||void 0===e?void 0:e.filter(t=>{var e,i;return t.insightStatement&&(null===(e=t.details)||void 0===e?void 0:e.evaluationStatus)&&(null===(i=t.details)||void 0===i?void 0:i.evaluationStatus)!==o.Vs.nodata});let l=null==n?void 0:n.find(t=>{var e;return t.ruleId&&t.ruleId===(null===(e=this.aiInsight)||void 0===e?void 0:e.ruleId)});if(!l&&n&&n.length>0&&(l=n[Math.floor(Math.random()*n.length)]),l&&l.ruleId)return{insightId:l.insightId||"",insightStatement:l.insightStatement||"",rightIcon:`${(0,d.rA)().AssetsUrl}/staticsb/statics/latest/finance/icon/${this.isDarkModeTheme?"dark":"light"}/ArrowRight.svg`,insightClickThroughUrl:`${null===(i=t.footerData.footerLink)||void 0===i?void 0:i.navigationUrl}&airid=${l.ruleId}`,evaluationStatus:(null===(r=l.details)||void 0===r?void 0:r.evaluationStatus)||"",ruleId:l.ruleId};(0,g.vV)(p.ygO,`Money info ai insight data is not correct. insightData: ${a}, insightItem: ${l}`)}async getCurrentViewModel(t){var e,i;const r=(0,l.jX)(t.quote.displayName||"",t.quote.symbol,!0,this.transformerProvider.strings);this.cardSize!==n.uE._1x_1y&&(this.chartData=await this.generateChartData(t)),this.aiInsight=this.transformerProvider.config.shouldShowAiInsight?this.getInsightItem(t):void 0,this.isWithInsights=!!this.aiInsight&&this.cardSize===n.uE._1x_2y,await this.updateDateFilterChartData(t);const a=(null===(e=t.footerData.footerLink)||void 0===e?void 0:e.navigationUrl)||"",{primaryName:s,secondaryName:h}=this.getPrimaryAndSecondaryName(t.quote),{isChartAnimationEnabled:d,chartAnimationDuration:g,openLinksInNewTab:p}=this.transformerProvider.config;return this.aiInsight&&(0,c.ao)(o.KI.MoneyCardAiInsight,"1"),{cardSize:t.cardSize,experienceName:t.experienceName,isDarkModeTheme:this.isDarkModeTheme,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{name:o.CD.quoteItemClick,signature:t.signature,headline:a}),aiInsightTelemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{name:`${o.CD.seeWatchlistClick}_aiinsight`,signature:t.signature,headline:(null===(i=this.aiInsight)||void 0===i?void 0:i.insightClickThroughUrl)||""}),isSpotlightHero:(0,l.Fm)(t.experienceName),quote:t.quote,primaryName:s,secondaryName:h,getQuoteDataByChartType:this.getQuoteDataByChartType.bind(this),destinationUrl:a,tooltipText:r,chartHeight:this.chartHeight,chartData:this.chartData,dateFilterChartData:this.dateFilterChartData,isChartAnimationEnabled:d,chartAnimationDuration:g,chartWidth:this.chartWidth,previousCloseText:(0,l.Fq)(this.chartPricePreviousClose,this.transformerProvider.strings.previousClose),footerData:t.footerData,openLinksInNewTab:p,enableBaselineText:!0,enableChangePcntText:!0,hasLogo:this.hasLogo(),logoUrl:this.logoUrl,hasSmallPriceFont:(0,l.we)(this.cardSize,this.quote.price),aiInsightItem:this.aiInsight,isWithInsights:this.isWithInsights}}}Promise.resolve().then(i.bind(i,3322)),Promise.resolve().then(i.bind(i,92510)),Promise.resolve().then(i.bind(i,1817)),Promise.resolve().then(i.bind(i,78771))},78771(t,e,i){i.r(e),i.d(e,{AiInsightBadge(){return c}});var r=i(56911),a=i(31525),o=i(92011),n=i(60815),l=i(58792);let s=class extends o.L{getIcon(){const t=`${(0,l.rA)().AssetsUrl}/staticsb/statics/latest/finance/icon/${this.isDarkModeTheme?"dark":"light"}/`;switch(this.status){case"good":return`${t}DuePositive.svg`;case"bad":return`${t}DueNegative.svg`;case"neutral":return`${t}DueUnchange.svg`}return`${t}DueNodata.svg`}};(0,r.Cg)([n.sH],s.prototype,"status",void 0),(0,r.Cg)([n.sH],s.prototype,"isDarkModeTheme",void 0),(0,r.Cg)([n.sH],s.prototype,"alt",void 0),s=(0,r.Cg)([a.x],s);const h=i(74849).A` :host{display:inline-flex;align-items:center;width:16px;height:16px}`,d=i(96950).qy`<img src="${t=>t.getIcon()}" alt=${t=>t.alt||""} />`;let c=class extends s{};c=(0,r.Cg)([(0,o.E)({name:"ai-insight-badge",template:d,styles:h,shadowOptions:{delegatesFocus:!0}})],c)},84953(t,e,i){i.d(e,{i(){return n}});var r=i(27208),a=i(86449),o=i(85349);class n extends r.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getFilterButtonsList(t){const{cryptos:e,deprecatedToNewCryptos:i}=this.transformerProvider.config,o=(0,a.qA)(e,i,t.quote),{dateChartFilter1D:n,dateChartFilter5D:l,dateChartFilter1M:s,dateChartFilter3M:h,dateChartFilter1Y:d,dateChartFilter5Y:c,dateChartFilterAll:g}=this.transformerProvider.strings,{OneDayOneMinute:p,OneWeekFifteenMinutes:u,FiveDays:v,OneMonth:m,ThreeMonth:f,OneYear:x,FiveYear:b,All:$}=r.NB;return[{id:p,title:n},{id:o?u:v,title:l},{id:m,title:s},{id:x,title:d},{id:b,title:c},{id:$,title:g}].map(e=>({...e,telemetryTag:this.getButtonTelemetryTag(t,e.id)}))}getButtonTelemetryTag(t,e){return this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(t.telemetryObject,{name:r.CD.MoneyDateFilterChartButtonClick,headline:e},o.MS.Click)}async getViewModel(t){const{swapGainLossColor:e,isChartAnimationEnabled:i,chartAnimationDuration:r}=this.transformerProvider.config,o=(0,a.Fm)(t.experienceName);return{experienceName:t.experienceName,chartData:t.chartData,accentColor:t.accentColor,baselineColor:o?(0,a.Bp)((0,a.jJ)()):t.accentColor,quote:t.quote,isDarkModeTheme:(0,a.jJ)(),handleDateFilterChartChange:this.transformerProvider.handleDateFilterChartChange,positiveColor:(0,a.BK)((0,a.jJ)(),1,e),negativeColor:(0,a.BK)((0,a.jJ)(),-1,e),isChartAnimationEnabled:i,chartAnimationDuration:r,chartHeight:t.chartHeight,chartWidth:t.chartWidth,enableBaselineText:!0,previousCloseText:t.previousCloseText,filterButtonsList:this.getFilterButtonsList(t),isSpotlightHero:o,strings:{dataIsNotAvailable:this.transformerProvider.strings.dataIsNotAvailable},telemetryTag:""}}}},88015(t,e,i){i.d(e,{u(){return n}});var r=i(27208),a=i(49150),o=i(86449);class n extends r.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getChartFillColor(t){return t?(0,o.BK)((0,o.jJ)(),t.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor):""}chartPricePreviousClose(t){return t?t.pricePreviousClose:void 0}getChartWidth(t){return t.cardSize===a.uE._1x_1y?104:32}getChartHeight(t){return t.cardSize===a.uE._1x_1y?18:28}getChangePcnt(t){var e,i;return(0,o.tc)(null===(e=t.chartData)||void 0===e?void 0:e.chartType,!1,null===(i=t.chartData)||void 0===i?void 0:i.changePcnt,t.quote.changePcnt)}async getViewModel(t){var e,i,r;return{chartId:t.quote.id,chartWidth:this.getChartWidth(t),chartHeight:this.getChartHeight(t),chartFillColor:this.getChartFillColor(t.quote),chartData:t.chartData,baselineFillColor:this.getChartFillColor(t.quote),baseLineText:"",chartBaseline:this.chartPricePreviousClose(null==t?void 0:t.chartData),chartBaselineLoc:null==t||null===(e=t.chartData)||void 0===e?void 0:e.pricePreviousCloseLoc,isDarkModeTheme:!1,isSpotlight:!1,enableBaselineText:!0,enableChangePcntText:!0,changePcnt:this.getChangePcnt(t)||"",chartSeries:null===(i=t.chartData)||void 0===i||null===(i=i.chartData)||void 0===i?void 0:i.series,pricesMaxCount:null===(r=t.chartData)||void 0===r||null===(r=r.chartData)||void 0===r?void 0:r.total,telemetryTag:"",cardSize:t.cardSize}}}},92707(t,e,i){i.d(e,{z(){return s}});var r=i(56911),a=i(27208),o=i(60815),n=i(92011),l=i(31525);let s=class extends n.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return a.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const t=this.getState();t&&(t.subscribe(a.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(t){}onChartDictChange(t){}onShowNotificationTextChange(t){}onQuoteItemDictChange(t){}onCardWidthChanged(t){}};(0,r.Cg)([o.sH],s.prototype,"viewModel",void 0),s=(0,r.Cg)([l.x],s)},99657(t,e,i){i.d(e,{D(){return n},I(){return o}});var r=i(45755);const{create:a}=r.G,o=a("sloppy-click-z-index",1),n=a("click-z-index",1)}}]);