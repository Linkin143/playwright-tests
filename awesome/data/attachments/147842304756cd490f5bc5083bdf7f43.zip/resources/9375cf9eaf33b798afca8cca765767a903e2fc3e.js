// © Microsoft Corporation. All rights reserved.
import { ConnectorNamespaces_IrisData, ConnectorNamespaces_RewardsData, ConnectorNamespaces_WeatherCardData, ConnectorNamespaces_WeatherData, ExperienceIds_cardActionWC, ExperienceIds_breakingNewsWC, ExperienceIds_superBreakingNews, ExperienceIds_conditionalBannerHpWC, ExperienceIds_displayAdsWC, ExperienceIds_feedbackDialogWC, ExperienceIds_homepageFooter, ExperienceIds_languageToggleWC, ExperienceIds_msRewardsWC, ExperienceIds_nativeAdWC, ExperienceIds_notificationBellWC, ExperienceIds_pageRefreshWC, ExperienceIds_searchHistoryEdgeNextWC, ExperienceIds_socialBarWC, ExperienceIds_toastWC, ExperienceIds_weatherTodayMiniWC, ExperienceIds_publisherSubscribeFollowButton, ExperienceIds_codexBingChat, ExperienceIds_entryPointHpWC, ExperienceIds_superNav, ExperienceIds_waterfallViewFeed, ExperienceIds_nurturingBanner, ExperienceIds_pillWC } from "@msnews/experiences-constants";
import { getWebComponentElementName } from "@msnews/experiences-web-component-loader";
export const ssrExcludedExperiences = [
    ExperienceIds_breakingNewsWC,
    ExperienceIds_conditionalBannerHpWC,
    ExperienceIds_displayAdsWC,
    ExperienceIds_feedbackDialogWC,
    ExperienceIds_homepageFooter,
    ExperienceIds_languageToggleWC,
    ExperienceIds_msRewardsWC,
    ExperienceIds_nativeAdWC,
    ExperienceIds_notificationBellWC,
    ExperienceIds_pageRefreshWC,
    ExperienceIds_searchHistoryEdgeNextWC,
    ExperienceIds_socialBarWC,
    ExperienceIds_toastWC,
    ExperienceIds_weatherTodayMiniWC,
    ExperienceIds_cardActionWC,
    ExperienceIds_superBreakingNews,
    ExperienceIds_publisherSubscribeFollowButton,
    ExperienceIds_codexBingChat,
    ExperienceIds_nurturingBanner,
    ExperienceIds_pillWC
];
export const ssrExcludedConnectors = [
    ConnectorNamespaces_WeatherCardData,
    ConnectorNamespaces_WeatherData,
    ConnectorNamespaces_IrisData,
    ConnectorNamespaces_RewardsData
];
export const experiencesRefs = [
    {
        instanceId: "CasualGamesCard",
        configRef: {
            experienceType: "CasualGamesCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "DenseCard",
        configRef: {
            experienceType: "DenseCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "RecommendedSitesWC",
        configRef: {
            experienceType: "RecommendedSitesWC",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "SportsInfo",
        configRef: {
            experienceType: "SportsInfo",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "StackCard",
        configRef: {
            experienceType: "StackCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "MoneyInfo",
        configRef: {
            experienceType: "MoneyInfo",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "EntryPointHpWC",
        configRef: {
            experienceType: "EntryPointHpWC",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "MeStripeWC",
        configRef: {
            experienceType: "MeStripeWC",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "SuperNav",
        configRef: {
            experienceType: "SuperNav",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "WaterfallViewFeed",
        configRef: {
            experienceType: "WaterfallViewFeed",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "CommonHeaderWC",
        configRef: {
            experienceType: "CommonHeaderWC",
            instanceSrc: "default",
            sharedNs: "msn-ns"
        }
    },
    {
        instanceId: "TrafficCardWC",
        configRef: {
            experienceType: "TrafficCardWC",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "DigestCard",
        configRef: {
            experienceType: "DigestCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "WeatherCardWC",
        configRef: {
            experienceType: "WeatherCardWC",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "WeatherMinimapWC",
        configRef: {
            experienceType: "WeatherMinimapWC",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "DailyWonderCopilotCard",
        configRef: {
            experienceType: "DailyWonderCopilotCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "DailyBriefCard",
        configRef: {
            experienceType: "DailyBriefCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "DailyMomentsCard",
        configRef: {
            experienceType: "DailyMomentsCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "ShoppingCardWC",
        configRef: {
            experienceType: "ShoppingCardWC",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "ShoppingSdCard",
        configRef: {
            experienceType: "ShoppingSdCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "TopCommentsCard",
        configRef: {
            experienceType: "TopCommentsCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "TravelDestination",
        configRef: {
            experienceType: "TravelDestination",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "travelSdDestinationsCard",
        configRef: {
            experienceType: "TravelSdDestinationsCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "TravelSdFlightsCard",
        configRef: {
            experienceType: "TravelSdFlightsCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "TravelSdHotelsCard",
        configRef: {
            experienceType: "TravelSdHotelsCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "TrendingSearchCard",
        configRef: {
            experienceType: "TrendingSearchCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "RichCalendarCard",
        configRef: {
            experienceType: "RichCalendarCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "HealthTipWC",
        configRef: {
            experienceType: "HealthTipWC",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "SpotlightCardWC",
        configRef: {
            experienceType: "SpotlightCardWC",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "ShoppingRiverCard",
        configRef: {
            experienceType: "ShoppingRiverCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "MailSignoutBanner",
        configRef: {
            experienceType: "MailSignoutBanner",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "MomentInTimeHero",
        configRef: {
            experienceType: "MomentInTimeHero",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "WeatherHeroExperience",
        configRef: {
            experienceType: "WeatherHeroExperience",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "TrafficHero",
        configRef: {
            experienceType: "TrafficHero",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "SharedHeroNewsCard",
        configRef: {
            experienceType: "SharedHeroNewsCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "EntertainmentPremierCard",
        configRef: {
            experienceType: "EntertainmentPremierCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "CommunityCard",
        configRef: {
            experienceType: "CommunityCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "TravelSdThemesCard",
        configRef: {
            experienceType: "TravelSdThemesCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "BoostAdCard",
        configRef: {
            experienceType: "BoostAdCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "RealEstateCard",
        configRef: {
            experienceType: "RealEstateCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "PrismSdCard",
        configRef: {
            experienceType: "PrismSdCard",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "MarketplaceCardWC",
        configRef: {
            experienceType: "MarketplaceCardWC",
            instanceSrc: "default",
            sharedNs: "msn-ns"
        }
    },
    {
        instanceId: "WidgetsRegion",
        configRef: {
            experienceType: "WidgetsRegion",
            instanceSrc: "default"
        }
    },
    {
        instanceId: "ContentGroupCard",
        configRef: {
            experienceType: "ContentGroupCard",
            instanceSrc: "default"
        }
    }
];
export function getSsrExcludedElements() {
    const ssrExcludedElements = [
        "msn-native-ad-card-template-facade",
        "msn-native-ad-wc",
        "msn-native-ad-telemetry",
        "fluent-dialog",
        "fluent-select",
        "fluent-option",
        "fluent-dialog",
        "display-ads",
        "cs-contextual-feedback",
        // infopane 1.0
        "msn-info-pane",
        "msn-info-pane-tab",
        "msn-info-pane-panel",
        "msft-info-pane-slide",
        // msn-stock-chart uses d3 & ref to render chart, which is not SSR friendly
        "msn-stock-chart",
        "msn-market-selector",
        "msn-me-control",
        "nurturing-banner"
    ];
    return ssrExcludedElements;
}
export const renderTimeTrackingComponents = experiencesRefs.map((ref) => getWebComponentElementName(ref.configRef.experienceType));
export const hydrationTimeTrackingComponents = [
    ExperienceIds_entryPointHpWC,
    ExperienceIds_superNav,
    ExperienceIds_waterfallViewFeed
].map(getWebComponentElementName);
export const hydrationSubscribableComponents = [
    "waterfall-view-feed",
    "cs-responsive-infopane"
];
//# sourceMappingURL=experiencesRef.js.map