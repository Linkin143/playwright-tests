// © Microsoft Corporation. All rights reserved.
// This file will contain a dynamic import for each experience bundle that needs to be generated.
//
// DynamicBundles.registerExperience("interests", () => import(/* webpackChunkName: "interests" *//*"@msnews/interests")); <<
//                                                ^^^^^^ it needs to wrapped if you want to split into a separate chunk and to be lazy downloaded
//
// This is the place to list out which experiences will be lazy loaded for the Entry Point / page.
// This file must be included in the page experience by including the following line in the page experience page.ts file
// import "./bundler"
import { ExperienceIds_entryPointHpWC, ExperienceIds_casualGamesCard, ExperienceIds_sportsInfo, ExperienceIds_stackCard, ExperienceIds_commonHeaderWC, ExperienceIds_denseCard, ExperienceIds_recommendedSitesWC, ExperienceIds_superNav, ExperienceIds_waterfallViewFeed, ExperienceIds_trafficCardWC, ExperienceIds_meStripeWC, ExperienceIds_digestCard, ExperienceIds_weatherCardWC, ExperienceIds_weatherMinimapWC, ExperienceIds_dailyWonderCopilotCard, ExperienceIds_dailyBriefCard, ExperienceIds_dailyMomentsCard, ExperienceIds_mailSignoutBanner, ExperienceIds_moneyInfo, ExperienceIds_shoppingCardWC, ExperienceIds_shoppingSdCard, ExperienceIds_topCommentsCard, ExperienceIds_travelDestination, ExperienceIds_travelSdDestinationsCard, ExperienceIds_travelSdFlightsCard, ExperienceIds_travelSdHotelsCard, ExperienceIds_trendingSearchCard, ExperienceIds_richCalendarCard, ExperienceIds_healthTipWC, ExperienceIds_spotlightCardWC, ExperienceIds_shoppingRiverCard, ExperienceIds_momentInTimeHero, ExperienceIds_weatherHeroExperience, ExperienceIds_trafficHero, ExperienceIds_sharedHeroNewsCard, ExperienceIds_entertainmentPremierCard, ExperienceIds_communityCard, ExperienceIds_travelSdThemesCard, ExperienceIds_boostAdCard, ExperienceIds_realEstateCard, ExperienceIds_prismSdCard, ExperienceIds_marketplaceCardWC, ExperienceIds_contentGroupCard, ExperienceIds_widgetsRegion } from "@msnews/experiences-constants";
import { DynamicBundles } from "@msnews/core";
const { registerExperience } = DynamicBundles;
// for test only
export const registeredExperiences = [];
const registerSSRExperience = (experienceId, es6import) => {
    registerExperience(experienceId, es6import);
    registeredExperiences.push(experienceId);
};
registerSSRExperience(ExperienceIds_entryPointHpWC, () => import(/* webpackChunkName: "entry-point-hp-wc" */ "@msnews/entry-point-hp-wc"));
registerSSRExperience(ExperienceIds_meStripeWC, () => import(/* webpackChunkName: "me-stripe-wc" */ "@msnews/me-stripe-wc"));
registerSSRExperience(ExperienceIds_superNav, () => import(/* webpackChunkName: "super-nav" */ "@msnews/super-nav"));
registerSSRExperience(ExperienceIds_widgetsRegion, () => import(/* webpackChunkName: "widgets-region" */ "@msnews/widgets-region"));
registerSSRExperience(ExperienceIds_waterfallViewFeed, () => import(/* webpackMode: "lazy", webpackChunkName: "waterfall-view-feed" */ "@msnews/waterfall-view-feed"));
registerSSRExperience(ExperienceIds_commonHeaderWC, () => import(/* webpackChunkName: "common-header-wc" */ "@msnews/common-header-wc"));
registerSSRExperience(ExperienceIds_sportsInfo, () => import("@msnews/sports-info"));
registerSSRExperience(ExperienceIds_moneyInfo, () => import("@msnews/money-info"));
registerSSRExperience(ExperienceIds_stackCard, () => import("@msnews/stack-card"));
registerSSRExperience(ExperienceIds_casualGamesCard, () => import("@msnews/casual-games-card"));
registerSSRExperience(ExperienceIds_trafficCardWC, () => import("@msnews/traffic-card-wc"));
registerSSRExperience(ExperienceIds_denseCard, () => import("@msnews/dense-card"));
registerSSRExperience(ExperienceIds_recommendedSitesWC, () => import("@msnews/recommended-sites-wc"));
registerSSRExperience(ExperienceIds_digestCard, () => import("@msnews/digest-card"));
registerSSRExperience(ExperienceIds_weatherCardWC, () => import("@msnews/weather-card-wc"));
registerSSRExperience(ExperienceIds_weatherMinimapWC, () => import("@msnews/weather-minimap-wc"));
registerSSRExperience(ExperienceIds_dailyWonderCopilotCard, () => import(/* webpackChunkName: "daily-wonder-copilot-card" */ "@msnews/daily-wonder-copilot-card"));
registerSSRExperience(ExperienceIds_dailyBriefCard, () => import(/* webpackChunkName: "daily-brief-card" */ "@msnews/daily-brief-card"));
registerSSRExperience(ExperienceIds_dailyMomentsCard, () => import(/* webpackChunkName: "daily-moments-card" */ "@msnews/daily-moments-card"));
registerSSRExperience(ExperienceIds_shoppingCardWC, () => import("@msnews/shopping-card-wce"));
registerSSRExperience(ExperienceIds_shoppingSdCard, () => import("@msnews/shopping-sd-card"));
registerSSRExperience(ExperienceIds_topCommentsCard, () => import("@msnews/top-comments-card"));
registerSSRExperience(ExperienceIds_travelDestination, () => import("@msnews/travel-destination"));
registerSSRExperience(ExperienceIds_travelSdDestinationsCard, () => import("@msnews/travel-sd-destinations-card"));
registerSSRExperience(ExperienceIds_travelSdFlightsCard, () => import("@msnews/travel-sd-flights-card"));
registerSSRExperience(ExperienceIds_travelSdHotelsCard, () => import("@msnews/travel-sd-hotels-card"));
registerSSRExperience(ExperienceIds_trendingSearchCard, () => import("@msnews/trending-search-card"));
registerSSRExperience(ExperienceIds_richCalendarCard, () => import("@msnews/rich-calendar-card"));
registerSSRExperience(ExperienceIds_healthTipWC, () => import("@msnews/health-tip-wc"));
registerSSRExperience(ExperienceIds_spotlightCardWC, () => import("@msnews/spotlight-card-wc"));
registerSSRExperience(ExperienceIds_shoppingRiverCard, () => import("@msnews/shopping-river-card"));
registerSSRExperience(ExperienceIds_mailSignoutBanner, () => import("@msnews/mail-signout-banner"));
registerSSRExperience(ExperienceIds_momentInTimeHero, () => import("@msnews/moment-in-time-hero"));
registerSSRExperience(ExperienceIds_weatherHeroExperience, () => import("@msnews/weather-hero-experience"));
registerSSRExperience(ExperienceIds_trafficHero, () => import("@msnews/traffic-hero"));
registerSSRExperience(ExperienceIds_sharedHeroNewsCard, () => import("@msnews/shared-hero-news-card"));
registerSSRExperience(ExperienceIds_entertainmentPremierCard, () => import("@msnews/entertainment-premier-card"));
registerSSRExperience(ExperienceIds_communityCard, () => import("@msnews/community-card"));
registerSSRExperience(ExperienceIds_travelSdThemesCard, () => import("@msnews/travel-sd-themes-card"));
registerSSRExperience(ExperienceIds_boostAdCard, () => import("@msnews/boost-ad-card"));
registerSSRExperience(ExperienceIds_realEstateCard, () => import("@msnews/real-estate-card"));
registerSSRExperience(ExperienceIds_prismSdCard, () => import("@msnews/prism-sd-card"));
registerSSRExperience(ExperienceIds_marketplaceCardWC, () => import("@msnews/marketplace-card-wc"));
registerSSRExperience(ExperienceIds_contentGroupCard, () => import("@msnews/content-group-card"));
//# sourceMappingURL=node.bundler.js.map