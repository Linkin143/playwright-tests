"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["cs-core-desktop_responsive-list_dist_index_js"],{4968(e,t,i){i.d(t,{f(){return s}});var r=i(64187),a=i(74849),n=i(42792),o=i(99657),l=i(36452);const s=a.A.partial`position: relative; z-index: ${o.D};`;a.A`
    ${n.e}
    ${n.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${s}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(n.kc)},22162(e,t,i){var r;i.d(t,{j(){return r}}),function(e){e.image="image",e.provider="provider",e.socialBar="socialBar"}(r||(r={}))},66690(e,t,i){i.d(t,{csResponsiveList(){return Y}});var r=i(89580),a=i(48751),n=i(4283),o=i(74089),l=i(4968),s=i(74849),d=i(22131),c=i(4126),u=i(69904);const p=s.A` .container{display:grid;grid-template-columns:1fr 1fr}.articleContent{height:max-content}`,g=s.A`
.articleHeadingInfo:hover .articleTitle{text-decoration:underline}`,v=s.A` .articleTitle{font-size:${r.Y};
        line-height: ${r.v};-webkit-line-clamp:3}cs-attribution{margin-bottom:6px}`,b=s.A` .articleContent.selected{background:#EBEBEB}.articleContent:hover{background:#F5F5F5}.articleContent:active{background:#E0E0E0}@media (prefers-color-scheme:dark){.articleContent.selected{background:#383838}.articleContent:hover{background:#3D3D3D}.articleContent:active{background:#1F1F1F}}`,h=s.A`
.articleContent:hover{background:rgba(255,255,255,0.06)}.articleContent.selected{background:#26292E}`,m=s.A`
.container{height:100%}.articleContent{border-radius:8px;color:${a.l};display:grid;gap:12px;grid-template-columns:auto var(--responsive-list-image-size,20.9%);height:33.33%;overflow:hidden;text-decoration:none;padding:0px 16px}a.articleContent:focus-visible{outline-offset:-1px}.articleContent.noImage{grid-template-columns:auto}.articleContent.selected{background:#F6F9FC}a{${l.f}}.articleContent:hover{background:rgba(0,0,0,0.04)}.articleHeadingInfo{height:fit-content;margin:auto 0px;min-height:60px;overflow:hidden}cs-attribution{display:flex;margin-bottom:4px;max-width:100%}cs-attribution::part(content){color:var(--content-color,${a.l})}cs-attribution .attribution-image{height:16px;width:16px}cs-attribution .divider{padding-inline-end:1px}cs-attribution .time{margin-inline-start:2px;unicode-bidi:embed}cs-attribution .webContentIcon{filter:invert(var(--iconInvert,0));margin:0px 2px;opacity:0.5;vertical-align:bottom}.articleTag{padding:1px 4px 3px;white-space:nowrap;border-radius:6px;background:${n.IR};
    color: ${o.l_}}.articleTag.breaking{background:#E10303}.articleTitle{display:-webkit-box;font-size:${u.Kg};
    font-weight: 600;
    line-height: ${u.Z6};
    overflow: hidden;
    -webkit-line-clamp: var(--responsive-list-title-lineheight, 2);
    -webkit-box-orient: vertical;
}

.articleImageContainer {
    display: flex;
    position: relative;
    align-items: center;
    justify-content: center;
}

.articleImage {
    aspect-ratio: 1/1;
    border-radius: 8px;
    margin: auto;
    max-width: 72px;
    width: 100%;
    object-fit: var(--responsive-list-image-object-fit, unset);
}

.articleContent.oneItemList {
    height: 100%;
}

.articleContent.twoItemList {
    --responsive-list-image-size: 35.8%;
    height: 50%;
}

.twoItemList .articleHeadingInfo {
    min-height: 92px;
}

.twoItemList .articleTitle {
    --responsive-list-title-lineheight: 3;
}

.twoItemList .articleImage {
    max-width: 116px;
}

.playIndicator {
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, .2);
    border-radius: 50%;
    display: flex;
    padding: 5px;
    position: absolute;
}

.playIndicator img {
    filter: invert(1);
    width: 14px;
}

@container (width < 300px) {
    .articleHeadingInfo {
        min-height: min-content;
    }

    .articleTitle {
        --responsive-list-title-lineheight: 1;
    }
}
`.withBehaviors((0,d.G2)(h),new c.o("horizontalMode",!0,p),new c.o("useSubtleControlColors",!0,b),new c.o("useSubtleItemSize",!0,v),new c.o("underlineTitle",!0,g));var x=i(96950),f=i(69259),$=i(39957),w=i(14475),k=i(60402),C=i(22162),I=i(58792);const y=`${(0,I.rA)().StaticsUrl}/latest/fluent-icons/globe_16_regular.svg`,T=x.qy`<cs-attribution>${(0,f.z)(e=>e.attrBadge,x.qy`<span class="articleTag ${e=>{var t;return null===(t=e.attrBadge)||void 0===t?void 0:t.type}}" slot="image">${e=>{var t,i;return(null===(t=e.attrBadge)||void 0===t?void 0:t.localizedLabel)||(null===(i=e.attrBadge)||void 0===i?void 0:i.value)}}</span>`)} ${(0,f.z)(e=>{var t;return null===(t=e.providerData)||void 0===t?void 0:t.logoImage},x.qy`<img alt="${e=>{var t;return null===(t=e.providerData)||void 0===t?void 0:t.name}}" aria-hidden="true" class="attribution-image" decoding="${e=>e.enableLazyImage?"async":""}" loading="${e=>e.enableLazyImage?"lazy":""}" part="image" slot="image" src="${e=>{var t;return null===(t=e.providerData)||void 0===t?void 0:t.logoImage}}" title="${e=>{var t;return null===(t=e.providerData)||void 0===t?void 0:t.name}}" @load=${e=>e.visualReadinessCallback&&e.visualReadinessCallback(1,C.j.provider)} />`)} ${(0,f.z)(e=>e.providerData&&e.providerData.name,x.qy`<span style="unicode-bidi: embed;" class="attribution-text" title="${e=>{var t;return null===(t=e.providerData)||void 0===t?void 0:t.name}}">${e=>{var t;return null===(t=e.providerData)||void 0===t?void 0:t.name}}</span>`)} ${(0,f.z)(e=>e.isWebContent&&!e.metadata.videoMetadata,x.qy`<img class="webContentIcon" src="${y}">`)} ${(0,f.z)(e=>e.publishedDateTime,x.qy`<span aria-hidden="true" class="divider" focusable="false">·</span><span class="time">${e=>e.publishedDateTime}</span>`)}</cs-attribution>`,z=x.qy`<span class="playIndicator"><img aria-hidden="true" role="presentation" src="${(0,I.rA)().StaticsUrl}/latest/fluent-icons/play_16_filled.svg"></img></span>`,F=x.qy`<div class="articleImageContainer"><img class="articleImage" part="articleImage" src=${(e,t)=>{var i;return e.imageData?t.parent.getScaledListItemImage(e.imageData.source,null===(i=e.imageData)||void 0===i?void 0:i.options):""}} alt=${e=>{var t;return(null===(t=e.imageData)||void 0===t?void 0:t.altText)??""}}>${(0,f.z)((e,t)=>{var i;return(null===(i=t.parent.contentList)||void 0===i?void 0:i.length)>1&&"video"==e.contentType},z)}</div>`,L=x.qy` ${()=>T}<span class="articleTitle" ${(0,k.K)("articleContentRef")}>${e=>e.title}</span>`,E=x.qy`<span class="articleTitle" ${(0,k.K)("articleContentRef")}>${e=>e.title}</span>${()=>T}
`,S=x.qy`<a role="listitem" part="listContent" class=${(e,t)=>{var i;return((e,t,i)=>{let r="articleContent";return 1===e&&(r+=" oneItemList"),2===e&&(r+=" twoItemList"),t||(r+=" noImage"),i&&(r+=" selected"),r})(null===(i=t.parent.contentList)||void 0===i?void 0:i.length,!!e.imageData,e.selected||!1)}} href=${e=>e.destinationUrl} target="${(e,t)=>((e,t)=>t?w.z._self:e.openLinksInNewTab?w.z._blank:e.defaultAnchorTarget||w.z._self)(e,t.parent.config.enableOpenContentInSelf)}" title=${e=>e.title} data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.destination)||void 0===t?void 0:t.getMetadataTag()}}" @click="${(e,t)=>t.parent.clickHandler(e,t)}"><div class="articleHeadingInfo" part="listContentInfo">${(0,f.z)((e,t)=>t.parent.enableFlipTitleProvider,E,L)}</div>${(0,f.z)(e=>e.imageData,F)}</a>`,_=x.qy`<div class="container" role="list" data-t="${e=>{var t;return null===(t=e.listContainerTelemetry)||void 0===t?void 0:t.getMetadataTag()}}">${(0,f.z)(e=>null==e?void 0:e.contentList,x.qy` ${(0,$.ux)(e=>e.contentList,S,{positioning:!0})} `)}</div>`;var H=i(56911),j=i(92011),D=i(60815),B=i(38493),M=i(3083),R=i(10809),O=i(27160);class V extends j.L{connectedCallback(){this.config=R.D.getConfig(),this.enableFlipTitleProvider=this.config.enableFlipTitleProvider,this.underlineTitle=this.contentList&&this.contentList[0]&&this.contentList[0].underlineTitle,super.connectedCallback()}getScaledListItemImage(e,t){const i={width:100,height:100,enableDpiScaling:!1,...t};return(0,M.oQ)(e,i)}clickHandler(e,t){return e.useMobile&&!e.isMsnMobile?(e.mobileCardClickCallback(t.event,O.pL.Article,e,"article card"),!1):(e.contentClickCallback&&e.contentClickCallback(e,t),!0)}}(0,H.Cg)([D.sH],V.prototype,"contentList",void 0),(0,H.Cg)([D.sH],V.prototype,"listContainerTelemetry",void 0),(0,H.Cg)([(0,B.CF)({attribute:"horizontal-mode",mode:"boolean"})],V.prototype,"horizontalMode",void 0),(0,H.Cg)([(0,B.CF)({attribute:"use-subtle-control-colors",mode:"boolean"})],V.prototype,"useSubtleControlColors",void 0),(0,H.Cg)([(0,B.CF)({attribute:"use-subtle-item-size",mode:"boolean"})],V.prototype,"useSubtleItemSize",void 0),(0,H.Cg)([(0,B.CF)({attribute:"underline-title",mode:"boolean"})],V.prototype,"underlineTitle",void 0),(0,H.Cg)([(0,B.CF)({attribute:"enable-flip-title-provider",mode:"boolean"})],V.prototype,"enableFlipTitleProvider",void 0);const Y=V.compose({name:"responsive-list",styles:m,template:_})},69904(e,t,i){i.d(t,{Fr(){return u},IH(){return m},Kg(){return r},M_(){return h},Oc(){return v},TF(){return l},YO(){return d},YV(){return o},Z6(){return c},aV(){return s},bc(){return b},kS(){return a},le(){return g},tD(){return n},vr(){return p}});const r="14px",a="12px",n="10px",o="16px",l="20px",s="24px",d="28px",c="20px",u="16px",p="22px",g="24px",v="28px",b="32px",h="600",m="400"}}]);