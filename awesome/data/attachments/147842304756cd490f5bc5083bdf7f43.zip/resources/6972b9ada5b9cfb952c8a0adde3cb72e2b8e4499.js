"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["cs-core-desktop_ruby-widget-card_dist_index_js"],{140(e,t,i){i.d(t,{C(){return o}});const o={pill:"pill",shorts:"shorts",_05u:"0.5u",_1u:"1u",_15u:"1.5u",_1c:"1c",_2c:"2c",_3c:"3c",_4c:"4c"}},1349(e,t,i){i.d(t,{J(){return d},O(){return s}});var o=i(77367),n=i(85349),r=i(69781),a=i(10809);function s(e,t){const i=a.D.getConfig();null!=i&&i.enableMouseDwellTime&&(0,r.kM)(t,()=>o.YT.sendActionEvent(e,n.EG.Hover,n.MS.Open),null==i?void 0:i.mdtHoverThreshold)}function d(e,t){const i=a.D.getConfig();null!=i&&i.enableMouseDwellTime&&(0,r.pS)(t,()=>o.YT.sendActionEvent(e,n.EG.MouseLeave,n.MS.Open))}},3480(e,t,i){i.d(t,{R(){return a},X(){return s}});var o=i(96950),n=i(69259),r=i(58792);i(17288).F;const a=e=>o.qy`<button class="hide-card-button" data-t="${(null==e?void 0:e.telemetryTag)||""}" @click=${(e=>(t,i)=>{var o;null==e||null===(o=e.rubyHideController)||void 0===o||o.hide()})(e)} title=${(null==e?void 0:e.hideCardTooltip)||""} aria-label=${(null==e?void 0:e.hideCardTooltip)||""}><img alt="" aria-hidden="true" src="${(0,r.rA)().StaticsUrl}/latest/fluent-icons/dismiss_20_regular.svg"></img></button>`,s=e=>o.qy` ${(0,n.z)(e=>{var t;return"spinner"===(null===(t=e.rubyHideController)||void 0===t?void 0:t.hideCardState)},()=>o.qy`<div class="hide-card-overlay" @click=${(e,t)=>{var i;return null===(i=t.event)||void 0===i?void 0:i.stopPropagation()}}><msn-animated-done-spinner pre-text="${(null==e?void 0:e.updatingText)||"Updating your preferences"}" post-text="${(null==e?void 0:e.confirmationText)||"You will see less content like this"}" :spinnerCompletedCallback="${()=>null==e?void 0:e.spinnerCompletedCallback}"></msn-animated-done-spinner><fluent-button appearance="lightweight" class="undo-hide-button" data-t="${(null==e?void 0:e.undoTelemetryTag)||""}" @click=${(e=>(t,i)=>{var o,n;null==e||null===(o=e.rubyHideController)||void 0===o||o.unhide(null===(n=i.event)||void 0===n?void 0:n.currentTarget)})(e)}>${(null==e?void 0:e.undoText)||"Undo"}</fluent-button></div>`)}
`},5111(e,t,i){i.d(t,{Es(){return s},b$(){return c},gN(){return l},j9(){return n},t3(){return d}});var o=i(74849);const n="1.8135 / 1",r=o.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]) {
        aspect-ratio: 1;
    }

    :host([size="1.5u"]) .media-container {
        aspect-ratio: ${n};
    }
`,a=o.A`
    :host([size="3c"][ux-mode="billboard"]) .media,
    :host([size="4c"][ux-mode="billboard"]) .media {
        width: 100%;
    }
`,s="prg-lg-flex",d=o.A`${r}`,l=(o.A`
${r}
${a}
`,"prg-pr2-lg-flex"),c=o.A`${r}`;o.A`
${r}
${a}
`},7014(e,t,i){i.d(t,{m(){return V}});var o=i(56911),n=i(38493),r=i(60815),a=i(55230),s=i(92011),d=i(56863);class l extends s.L{}class c extends((0,d.dx)(l)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class u extends c{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(!this.readOnly)switch(e.key){case a.Mm:case a.gG:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,t){super.checkedChanged(e,t),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,o.Cg)([(0,n.CF)({attribute:"readonly",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],u.prototype,"readOnly",void 0),(0,o.Cg)([r.sH,(0,o.Sn)("design:type",Array)],u.prototype,"defaultSlottedNodes",void 0);var h=i(37180),v=i(74849),m=i(64187),b=i(60993),g=i(73477),p=i(22131),$=i(50882),x=i(48196),k=i(86856),w=i(7896),f=i(74838),y=i(79288),z=i(46203),C=i(26920),T=i(43774),_=i(95239),B=i(14996),j=i(48751),O=i(41123),S=i(74089),I=i(4283);const U=v.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,m.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${w.O};
        margin: calc(${f.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${y.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${b.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${x.D} / 2) + ${f.vR}) * 2px);
        height: calc(((${x.D} / 2) + ${f.vR}) * 1px);
        background: ${z.le};
        border-radius: calc(${x.D} * 1px);
        border: calc(${C.XA} * 1px) solid ${T.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${z.jM};
        border-color: ${T.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${z.RS};
        border-color: ${T.p4};
    }

    :host(:${g.N}) .switch {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${B.WN};
        border-color: ${B.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${x.D} - (${f.vR} * 5.5)) * 1px);
        width: calc((${x.D} - (${f.vR} * 5.5)) * 1px);
        top: calc(${f.vR} * 1px);
        background: ${j.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${j.l};
        cursor: pointer;
        font-size: ${O.K};
        line-height: ${O.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${j.l};
        font-size: ${O.K};
        line-height: ${O.Z};
        margin-inline-end: calc(${f.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${f.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${S.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${I.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${I.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${S.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${I.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${S.J_};
    }

    :host([aria-checked="true"]:${g.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${B.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new k.t(v.A`
            .checked-indicator {
                left: calc(${f.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${x.D} / 2) + ${f.vR}) + ${f.vR}) * 1px
                );
            }
        `,v.A`
            .checked-indicator {
                right: calc(${f.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${x.D} / 2) + ${f.vR}) + ${f.vR}) * 1px
                );
            }
        `),(0,p.mr)(v.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${$.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${$.A.Field};
                border-color: ${$.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${$.A.HighlightText};
                border-color: ${$.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${$.A.Highlight};
                border-color: ${$.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${$.A.HighlightText};
                border-color: ${$.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${$.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${$.A.Highlight};
            }
            :host(:${g.N}) .switch {
                border-color: ${$.A.Highlight};
                box-shadow: 0 0 0 2px ${$.A.Field},
                    0 0 0 4px ${$.A.FieldText};
            }
            :host([aria-checked="true"]:${g.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${$.A.Field},
                    0 0 0 4px ${$.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${$.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${$.A.Field};
                border-color: ${$.A.GrayText};
            }
            .status-message,
            .label {
                color: ${$.A.FieldText};
            }
        `));var A=i(96950),F=i(82774),E=i(18893);const D=function(e={}){return A.qy`
        <template
            role="switch"
            aria-checked="${e=>e.checked}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            tabindex="${e=>e.disabled?null:0}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <label
                part="label"
                class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,F.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,E.R)(e.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:A.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),V=class extends u{}.compose({name:`${h.c.prefix}-switch`,template:D,styles:U})},17288(e,t,i){i.d(t,{F(){return p}});var o=i(56911),n=i(2958),r=i(37180),a=i(7014),s=i(92011),d=i(38493);class l extends s.L{constructor(){super(...arguments),this.preText="",this.postText="",this.enableTwoLine=!1}connectedCallback(){super.connectedCallback(),this.spinnerCompleteTimer=window.setTimeout(()=>{this.spinnerCompletedCallback&&this.spinnerCompletedCallback()},3e3)}disconnectedCallback(){super.disconnectedCallback(),clearTimeout(this.spinnerCompleteTimer),this.spinnerCompleteTimer=void 0}}(0,o.Cg)([(0,d.CF)({attribute:"pre-text"})],l.prototype,"preText",void 0),(0,o.Cg)([(0,d.CF)({attribute:"post-text"})],l.prototype,"postText",void 0),(0,o.Cg)([(0,d.CF)({attribute:"enable-two-line",mode:"boolean"})],l.prototype,"enableTwoLine",void 0);var c=i(12640),u=i(92393),h=i(74849);const v=h.A` .spinner-background{stroke:rgba(0,0,0,0.07)}.meter{stroke:${u.W_}}.checkmark-background{fill:${u.W_}}.checkmark{fill:white}`,m=h.A` .spinner-background{stroke:rgba(255,255,255,0.54)}.meter{stroke:white}.checkmark-background{fill:white}.checkmark{fill:black}`,b=h.A` :host{display:flex;flex-direction:column;align-items:center}:host([card-size="_1x_1y"]) .text,:host([card-size="_2x_1y"]) .text,:host([card-size="0.5u"]) .text{display:none}:host([card-size="_1x_1y"]) svg,:host([card-size="_2x_1y"]) svg,:host([card-size="0.5u"]) svg{height:30px;width:30px}:host(.check-icon[card-size="_1x_1y"]),:host(.check-icon[card-size="_2x_1y"]),:host(.check-icon[card-size="0.5u"]){padding-top:0;padding-bottom:11px}svg{aspect-ratio:1 / 1;height:auto;margin:auto;width:var(--animated-spinner-size,48px)}.spinner-background{fill:none;stroke-width:2.5px}.meter{animation:spinner 3s linear;fill:none;stroke-dasharray:150;stroke-dashoffset:0;stroke-linecap:round;stroke-width:2.5px;transform:rotate(-90deg);transform-origin:50% 50%}@keyframes spinner{from{stroke-dashoffset:150}to{stroke-dashoffset:0}}.checkmark-background{animation:checkmark-background 4s linear;transform-origin:50% 50%}@keyframes checkmark-background{0%,75%{fill-opacity:0}78%{fill-opacity:1}}.checkmark{animation:checkmark 4s linear;animation-fill-mode:both;transform:translate(8px,8px);transform-origin:50% 50%}@keyframes checkmark{0%,75%{transform:scale(0) translate(8px,8px)}85%{transform:scale(1.25) translate(8px,8px)}100%{transform:scale(1) translate(8px,8px)}}span{display:block;font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);overflow:hidden;position:absolute;text-overflow:ellipsis;white-space:nowrap;width:236px}.two-line span{white-space:unset;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.two-line.text{height:40px}.text{height:20px;padding-top:8px;width:236px}.pre-text{animation:fadeout 1s;animation-delay:3s;animation-fill-mode:both}.post-text{animation:fadein 1s;animation-delay:3s;animation-fill-mode:both}@keyframes fadein{from{opacity:0}to{opacity:1}}@keyframes fadeout{from{opacity:1}to{opacity:0}}@media (-ms-high-contrast:active),(prefers-contrast:more){${v}
    }
`.withBehaviors(new c.N(v,m)),g=i(96950).qy`<svg part="icon" viewBox="0 0 48 48"><circle class="spinner-background" cx="24" cy="24" r="21.5" /><circle class="meter" cx="24" cy="24" r="21.5" /><circle class="checkmark-background" cx="24" cy="24" r="24"/><path class="checkmark" d="M11.3333 22.1144L6.27614 17.0572C5.75544 16.5365 4.91122 16.5365 4.39052 17.0572C3.86983 17.5779 3.86983 18.4221 4.39052 18.9428L10.3905 24.9428C10.9112 25.4635 11.7554 25.4635 12.2761 24.9428L26.9428 10.2761C27.4635 9.75545 27.4635 8.91122 26.9428 8.39052C26.4221 7.86983 25.5779 7.86983 25.0572 8.39052L11.3333 22.1144Z"/></svg><div part="text" class="text ${e=>e.enableTwoLine?"two-line":""}"><span part="pre-text"class="pre-text" role="alert">${e=>e.preText}</span><span part="post-text" class="post-text">${e=>e.postText}</span></div>`;let p=class extends l{};p=(0,o.Cg)([(0,s.E)({name:"msn-animated-done-spinner",template:g,styles:b})],p),n.m.define(r.c.registry),a.m.define(r.c.registry)},26248(e,t,i){i.d(t,{El(){return c},Fh(){return u},Fu(){return C},GO(){return n},U7(){return T},XA(){return z},ap(){return y},cw(){return b},dD(){return $},fc(){return h},gX(){return x},hq(){return m},jJ(){return k},lu(){return p},mU(){return g},n1(){return v},p7(){return s},pp(){return a},ti(){return r},uG(){return f},vJ(){return w},vq(){return d},w_(){return l}});var o=i(74849);o.A`
`;const n=o.A` :host{--smtc-gap-between-content-small:8px;--smtc-padding-card-default:20px}`,r="var(--smtc-background-card-on-primary-alt-rest)",a="var(--smtc-background-card-on-primary-default-rest)",s="var(--smtc-corner-image-on-page, var(--smtc-corner-card-rest))",d="var(--smtc-ctrl-badge-icon-size)",l="var(--smtc-ctrl-badge-size)",c="var(--smtc-foreground-ctrl-neutral-primary-rest)",u="var(--smtc-foreground-ctrl-on-brand-rest)",h="var(--smtc-foreground-ctrl-on-image-rest)",v="var(--smtc-gap-between-content-large)",m="var(--smtc-gap-between-content-small)",b="var(--smtc-gap-between-ctrl-lg-default)",g="var(--smtc-padding-content-medium)",p="var(--smtc-padding-content-none)",$="var(--smtc-stroke-divider-subtle, var(--smtc-stroke-divider-default))",x="var(--smtc-text-global-body1-font-size)",k="var(--smtc-text-global-body1-line-height)",w="var(--smtc-text-global-body2-font-size)",f="var(--smtc-text-global-body2-line-height)",y="var(--smtc-text-global-body3-font-size)",z="var(--smtc-text-global-body3-line-height)",C="var(--smtc-text-style-default-header-weight)",T="var(--smtc-text-style-default-regular-weight)"},29940(e,t,i){i.d(t,{n(){return r}});var o=i(96950),n=i(58792);const r=e=>o.qy`<button class="card-actions-button ${e.additionalClasses||""}" data-t="${t=>e.telemetryTag}" @click=${(t,i)=>{var o;return null===(o=e.onClick)||void 0===o?void 0:o.call(e,i.event)}} title=${t=>e.title} ?data-nopartialcontentview=${t=>Boolean(null==e?void 0:e.skipRepeatImpression)}><img alt="" aria-hidden="true" src="${(0,n.rA)().StaticsUrl}/latest/fluent-icons/more_horizontal_20_regular.svg"></img></button>`},42495(e,t,i){i.d(t,{c(){return o}});const o=i(74849).A`
    :host {
        transition-property: transform;
        transition-timing-function: cubic-bezier(.4, 0, 1, 1);
        transition-duration: .2s;
    }

    :host(:hover) {
        transform: matrix(1.025, 0, 0, 1.025, 0, 0);
    }

    .media, :host(:hover) .media,
    :host(:hover:not([grouped-item])) .media,
    :host(:not([in-playback-mode]):hover) .image-area {
        transform: none;
    }

    @media (prefers-reduced-motion: reduce) {
        :host {
            transition-duration: 0s;
        }
        :host(:hover) {
            transform: none;
        }
    }
`},43774(e,t,i){i.d(t,{p4(){return b},ls(){return g},vA(){return m},nF(){return v}});var o=i(45755),n=i(68009),r=i(95239);const{create:a}=o.G,s=a("neutral-stroke-strong-hover-delta",40),d=a("neutral-stroke-strong-active-delta",16),l=a("neutral-stroke-strong-focus-delta",25);var c=i(31023);const{create:u}=o.G,h=u({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,t,i,o,r,a){const s=(0,n.F)(t),d=e.colorContrast(t,i),l=e.closestIndexOf(d);return{rest:d,hover:e.get(l+s*o),active:e.get(l+s*r),focus:e.get(l+s*a)}}(e(c.r),e(r.p),3,e(s),e(d),e(l))}}),v=u("neutral-stroke-strong-rest",e=>e(h).evaluate(e).rest),m=u("neutral-stroke-strong-hover",e=>e(h).evaluate(e).hover),b=u("neutral-stroke-strong-active",e=>e(h).evaluate(e).active),g=u("neutral-stroke-strong-focus",e=>e(h).evaluate(e).focus)},45964(e,t,i){i.d(t,{_q(){return s},hU(){return l}});var o,n=i(93552),r=i(22341);function a(e,t){if(e instanceof Error){const i=e.toString();return t&&e.stack?`${i}, Stack: ${e.stack}`:i}return"string"==typeof e?e:function(e){if(void 0===e)return"undefined";try{return JSON.stringify(e)}catch{return"[serialization-error]"}}(e)}!function(e){e.LO="101",e.SD="102",e.HQ="103",e.HD="104",e.FHD="105",e["4K"]="107",e.Source="1001",e.SmoothStreaming="1004",e.HLS="1006",e.DASH="1007"}(o||(o={}));const s=(e,t)=>{try{const i=(e=>e&&Array.isArray(e)?e.filter(e=>{if(!e||"object"!=typeof e)return!1;const t=e.url&&"string"==typeof e.url&&e.url.trim().length>0,i=void 0!==e.fileSize&&"number"==typeof e.fileSize&&!isNaN(e.fileSize)&&isFinite(e.fileSize)&&e.fileSize>0;return t&&i}):[])(e);if(null==i||!i.length)return;const o=(e,t)=>{const i=e.fileSize,o=t.fileSize;return i<o?-1:i>o?1:0},n=i.sort(o);return void 0!==t&&t>=0&&n.length>0?n[Math.min(t,n.length-1)]:n.length>0?n[0]:void 0}catch(e){return void(0,r.vV)(n.A0q,"Error processing video files",a(e))}},d=["hover","scroll"],l=function(e,t,i,o){let a=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"",l=arguments.length>5?arguments[5]:void 0,c=arguments.length>6&&void 0!==arguments[6]&&arguments[6],u=arguments.length>7?arguments[7]:void 0,h=arguments.length>8&&void 0!==arguments[8]?arguments[8]:"msn",v=arguments.length>9?arguments[9]:void 0,m=arguments.length>10&&void 0!==arguments[10]&&arguments[10],b=arguments.length>11&&void 0!==arguments[11]&&arguments[11],g=arguments.length>12?arguments[12]:void 0,p=arguments.length>13?arguments[13]:void 0,$=arguments.length>14?arguments[14]:void 0,x=arguments.length>15?arguments[15]:void 0,k=arguments.length>16?arguments[16]:void 0,w=arguments.length>17?arguments[17]:void 0;const f=Array.isArray(o)?o:[],y=s(f,p);return{cardElement:e,config:{enableVideoCardHover:!0,enableVideoCardScroll:!0,capScrollPreview:c,enableVideoPreview:m,enableUserAutoPlaySettings:b,enablePauseOnComplete:w},logError(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"Generic Error Message";(0,r.vV)(n.fbJ,e,`Video Id: ${i}`)},previewTriggers:k||d,videoElement:t,videoData:{id:i,videoFile:y,title:a,videoDurationMs:l,motionThumbnailUrl:v,closedCaptions:$},overridePreviewElement:u,source:h,enablePreloadOnSetupTime:g,onHoverOtherVideoCallback:x}}},46580(e,t,i){i.d(t,{D(){return nt}});var o=i(56911),n=i(92011),r=i(60815),a=i(38493),s=i(67689),d=i(140),l=i(19359),c=i(85349);const u=Object.freeze({destination:"destination",cardAction:"Card Action Ellipsis",likeButton:"Upvote",likeButtonUndo:"UndoUpvote",dislikeButton:"Downvote",dislikeButtonUndo:"UndoDownvote",commentButton:"Comment",badge:"badge",likeButtonUndoHeadline:"Undo Upvote",dislikeButtonUndoHeadline:"Undo Downvote",commentHeadline:"Comments",hide:"hide",hideHeadline:"Hide",unhide:"unhide",unhideHeadline:"Undo Hide",showFewer:"showFewer",showFewerHeadline:"Downvote",undoShowFewer:"Undo",undoShowFewerHeadline:"Undo Downvote"});var h=i(77367),v=i(17857),m=i(31525),b=i(17918),g=i(45964),p=i(10809),$=i(94043),x=i(10910),k=i(3933),w=i(99691),f=i(76736),y=i(87056),z=i(79650),C=i(27160);let T=class extends n.L{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,s.h)(),this.i=!0,this._setupVideoPreview=async()=>{var e,t,o,n,r,a,s,d,l,c,u,h;if(!this.videoPreviewControls||!this.videoPreviewControls.videoData||!this.isVideo)return;if(!(null===(t=null===(e=this.videoPreviewControls)||void 0===e?void 0:e.videoData)||void 0===t?void 0:t.externalVideoFiles)&&"msn"===(null===(n=null===(o=this.videoPreviewControls)||void 0===o?void 0:o.videoData)||void 0===n?void 0:n.source))return;await(0,b.dT)();const{VideoPreviewController:v,waitForCondition:m}=await i.e("libs_feed-layout-common_dist_index_js").then(i.bind(i,55494));if(await m(()=>Boolean(this.videoElementRef)),!this.videoElementRef)return;const{externalVideoFiles:p,videoDuration:$,source:x,motionThumbnailUrl:k}=this.videoPreviewControls.videoData,w=new v((0,g.hU)(this,this.videoElementRef,this.id,p||[],this.heading,Number($),null===(r=this.config)||void 0===r?void 0:r.capScrollPreview,void 0,x,k,null===(a=this.config)||void 0===a?void 0:a.enableVideoPreview,null===(s=this.config)||void 0===s?void 0:s.enableUserAutoPlaySettings)),f=(null===(d=this.config)||void 0===d?void 0:d.enableVideoPreview)?null==w?void 0:w.videoPreviewUrl:(e=>{var t;if(e)return null===(t=(0,g._q)(e))||void 0===t?void 0:t.url})(null===(c=null===(l=this.videoPreviewControls)||void 0===l?void 0:l.videoData)||void 0===c?void 0:c.externalVideoFiles);this.videoPreviewControls=Object.assign(Object.assign({},this.videoPreviewControls),{videoLogError:null===(u=null==w?void 0:w.logError)||void 0===u?void 0:u.bind(w),videoTimeUpdateCb:null===(h=null==w?void 0:w.onTimeUpdate)||void 0===h?void 0:h.bind(w),isVideoPortrait:null==w?void 0:w.isPortrait,videoPreviewUrl:f})}}get hasMediaOrAugment(){return!!(this.imageSrc&&!this.imgFailed||this.shouldRenderVideoPreview||this.renderAugment)}get canRenderInsight(){const e=this.size===d.C._2c&&!this.immersive;return this.insight&&(e||!this.hasMediaOrAugment)}get isSegmentImmersive(){return this.renderAugment&&this.immersive}get strings(){var e;return(null===(e=this.config)||void 0===e?void 0:e.localizedStrings)||{}}get enableRubyHideCard(){var e;return Boolean(null===(e=this.config)||void 0===e?void 0:e.enableRubyHideCard)}get enableSocialButtons(){var e;return Boolean((0,$.S)()&&!(null===(e=this.config)||void 0===e?void 0:e.hideCardActionsIcon)&&(this.enableExpandedActions||this.enableWidgetNotInterested))}get showBottomSocialBar(){return Boolean(this.enableSocialButtons&&this.likeButtonProps&&this.commentButtonProps&&(!this.i&&this.dislikeButtonProps||this.i))}connectedCallback(){var e;super.connectedCallback(),this.init(),this.enableSpecialFWInCJK=!!(null===(e=this.config)||void 0===e?void 0:e.enableSpecialFWInCJK)}init(e){this.setupTelemetry(),this.setupConfig(),(0,$.S)()&&(0,x._Z)(this).then(()=>{var t;this.telemetry&&!e||this.setupTelemetry(),this.setupSocialConfig(),this.setTitleTooltip(),this.setupVideoPreview(),null===(t=this.visualReadinessCallback)||void 0===t||t.call(this)})}setupTelemetry(){var e;this.rootTelemetryObject&&(this.telemetry=((e,t)=>{let{id:i,title:o,url:n,cardTelemetryName:r,cardTelemetryContentType:a}=t;var s;const d=null===(s=null==e?void 0:e.contract)||void 0===s?void 0:s.ext,h={id:i,headline:o};return a&&(h.type=a),{componentRoot:e,card:r?(0,l.l)(r,h,c.MS.Navigate,c.EG.Click,d):null,destination:(0,l.l)(u.destination,h,c.MS.Navigate,c.EG.Click,c.MJ.Headline,n,d),cardAction:(0,l.l)(u.cardAction,h,c.MS.More,c.EG.Click,c.MJ.ActionButton,d),likeButton:(0,l.l)(u.likeButton,Object.assign(Object.assign({},h),{headline:u.likeButton}),c.MS.Like,c.EG.Click,c.MJ.ActionButton,d),likeButtonUndo:(0,l.l)(u.likeButtonUndo,Object.assign(Object.assign({},h),{headline:u.likeButtonUndoHeadline}),c.MS.Unlike,c.EG.Click,c.MJ.ActionButton,d),dislikeButton:(0,l.l)(u.dislikeButton,Object.assign(Object.assign({},h),{headline:u.dislikeButton}),c.MS.Dislike,c.EG.Click,c.MJ.ActionButton,d),dislikeButtonUndo:(0,l.l)(u.dislikeButtonUndo,Object.assign(Object.assign({},h),{headline:u.dislikeButtonUndoHeadline}),c.MS.Undislike,c.EG.Click,c.MJ.ActionButton,d),commentButton:(0,l.l)(u.commentButton,Object.assign(Object.assign({},h),{headline:u.commentHeadline}),c.MS.Navigate,c.EG.Click,c.MJ.ActionButton,d),badge:(0,l.l)(u.badge,h,c.MS.Navigate,c.EG.Click,c.MJ.ActionButton,d),hideAction:(0,l.l)(u.hide,Object.assign(Object.assign({},h),{headline:u.hideHeadline}),c.MS.Hide,c.EG.Click,c.MJ.ActionButton,d),unhideAction:(0,l.l)(u.unhide,Object.assign(Object.assign({},h),{headline:u.unhideHeadline}),c.MS.Unhide,c.EG.Click,c.MJ.ActionButton,d),showFewer:(0,l.l)(u.showFewer,Object.assign(Object.assign({},h),{headline:u.showFewerHeadline}),c.MS.Dislike,c.EG.Click,c.MJ.ActionButton,d),undoShowFewer:(0,l.l)(u.undoShowFewer,Object.assign(Object.assign({},h),{headline:u.undoShowFewerHeadline}),c.MS.Unhide,c.EG.Click,c.MJ.ActionButton,d)}})(this.rootTelemetryObject,{id:this.id,title:this.heading||"",url:this.href||"",cardTelemetryName:this.cardTelemetryName||"",cardTelemetryContentType:this.cardTelemetryContentType||0})),null===(e=null===h.YT||void 0===h.YT?void 0:h.YT.addOrUpdateTmplProperty)||void 0===e||e.call(h.YT,"ruby-widget-card-rendered","1")}setupConfig(){this.config=p.D.getConfig()}getRubyLikeCardData(){var e,t,i,o,n,r,a,s,d,l;if(this.enableWidgetNotInterested||(null===(e=this.cardActionPropsOverride)||void 0===e?void 0:e.disableHide)){const e=null===(o=null===(i=null===(t=this.telemetry)||void 0===t?void 0:t.likeButton)||void 0===i?void 0:i.contract)||void 0===o?void 0:o.ext;if((null==e?void 0:e.previewType)||(null===(n=this.cardActionPropsOverride)||void 0===n?void 0:n.rubyWidgetType))return{id:this.id||e.previewType||e.ct1s,locale:null===(a=null===(r=this.cardActionPropsOverride)||void 0===r?void 0:r.article)||void 0===a?void 0:a.locale,previewType:e.previewType,targetType:e.ct1s||(null===(s=this.cardActionPropsOverride)||void 0===s?void 0:s.ct1s),useVoteActions:!0}}return{id:this.id,locale:null===(l=null===(d=this.cardActionPropsOverride)||void 0===d?void 0:d.article)||void 0===l?void 0:l.locale}}setupSocialConfig(){var e,t,i,o,n,r,a,s,d,l,c,u,h,v,m,b,g,p,$;if(this.telemetry&&(this.enableExpandedActions||this.enableWidgetNotInterested)){const x=this.getRubyLikeCardData();this.rubyLikeController=new k.G(x),this.likeButtonProps={id:this.id,titleText:null===(e=this.strings)||void 0===e?void 0:e.rubyLikeTitleText,likeButtonTooltip:null===(t=this.strings)||void 0===t?void 0:t.rubyLikeButtonTooltipV2,telemetryTag:null===(i=this.telemetry.likeButton)||void 0===i?void 0:i.getMetadataTag(),telemetryTagUndo:null===(o=this.telemetry.likeButtonUndo)||void 0===o?void 0:o.getMetadataTag(),rubyLikeController:this.rubyLikeController,renderBottomTooltip:this.enableBottomSocialBar},this.enableBottomSocialBar&&(this.likeButtonProps=Object.assign(Object.assign({},this.likeButtonProps),{likeCount:null===(n=this.socialBarData)||void 0===n?void 0:n.upvotes,renderCount:!0}),this.i||(this.rubyDislikeController=new w.C(x),this.dislikeButtonProps={id:this.id,titleText:null===(r=this.strings)||void 0===r?void 0:r.rubyDislikeTitleText,dislikeButtonTooltip:null===(a=this.strings)||void 0===a?void 0:a.rubyDislikeButtonTooltip,telemetryTag:null===(s=this.telemetry.dislikeButton)||void 0===s?void 0:s.getMetadataTag(),telemetryTagUndo:null===(d=this.telemetry.dislikeButtonUndo)||void 0===d?void 0:d.getMetadataTag(),rubyDislikeController:this.rubyDislikeController,renderBottomTooltip:this.enableBottomSocialBar,dislikeCount:null===(l=this.socialBarData)||void 0===l?void 0:l.downvotes}),this.rubyCommentController=new f.c(x),this.commentButtonProps={id:this.id,commentButtonTooltip:null===(c=this.strings)||void 0===c?void 0:c.rubyCommentButtonTooltip,telemetryTag:null===(u=this.telemetry.commentButton)||void 0===u?void 0:u.getMetadataTag(),rubyCommentController:this.rubyCommentController,commentCount:(null===(h=this.socialBarData)||void 0===h?void 0:h.disabledComments)?0:null===(v=this.socialBarData)||void 0===v?void 0:v.comments,destinationUrl:(null===(m=this.socialBarData)||void 0===m?void 0:m.disabledComments)?this.href:`${this.href}#comments`,renderCount:!0}),this.enableRubyHideCard&&(this.rubyHideController=new y.V({id:this.id,locale:null===(g=null===(b=this.cardActionPropsOverride)||void 0===b?void 0:b.article)||void 0===g?void 0:g.locale}),this.hideCardButtonProps={telemetryTag:null===(p=this.telemetry.showFewer)||void 0===p?void 0:p.getMetadataTag(),hideCardTooltip:null===($=this.strings)||void 0===$?void 0:$.rubyHideCardTooltip,rubyHideController:this.rubyHideController})}}setTitleTooltip(){if(!this.headingRef)return;const e=this.headingRef.scrollHeight>this.headingRef.offsetHeight+2;this.title=e&&this.heading||""}idChanged(e,t){e&&e!==t&&this.init(!0)}badgeDataChanged(){var e;this.badgeAppearance=null===(e=this.badgeData)||void 0===e?void 0:e.appearance}immersiveChanged(){this.immersive&&this.imgFailed&&(this.immersive=!1,this.removeAttribute("immersive"))}async onMediaError(e){this.imageErrorCallback&&this.imageErrorCallback(e),this.handleMediaError()}onMediaLoaded(e){this.imageLoadedCallback&&this.imageLoadedCallback(e)}handleCardActionClick(e){var t;const i=[v.X.ManageInterests,v.X.Report];this.enableCuratedByCopilot&&i.unshift(v.X.CuratedByCopilot),this.enableHideActionInKumo&&!this.enableWidgetNotInterested&&i.unshift(v.X.Hide),this.enableWidgetNotInterested&&i.unshift(v.X.ShowFewer);const o=Object.assign({enabled:!0,buttonElement:e.currentTarget,article:{id:this.id||"",headlineTitle:this.heading||"",href:this.href||"",image:{alt:"",src:""},provider:{id:"",profileId:"",name:"",image:{alt:"",src:""}}},useCommunityReactionsForShowMoreLess:!0,updateFeedOnHide:this.enableHideActionInKumo,disableRelevantIssueCategory:!0},this.cardActionPropsOverride);this.enableExpandedActions||(o.actionsArrayOverride=i,o.ignoreReportDislike=!0),null===(t=this.initCardAction)||void 0===t||t.call(this,o)}async hideCardSpinnerCompleted(){var e,t;await(null===(e=this.hideCardDismissCallback)||void 0===e?void 0:e.call(this,z.I,null===(t=this.rubyHideController)||void 0===t?void 0:t.dismiss))}handleMediaError(){this.imageSrc=void 0,this.immersive=!1,this.imgFailed=!0}get setupVideoPreview(){return this._setupVideoPreview}get shouldRenderVideoPreview(){var e,t;return this.isVideo&&(null===(t=null===(e=this.videoPreviewControls)||void 0===e?void 0:e.videoData)||void 0===t?void 0:t.externalVideoFiles)}get isVideo(){return"video"===this.mediaType}get isVideoIndicatorInMainContainer(){return this.isVideo&&this.immersive}get isVideoInMediaContainer(){return this.isVideo&&!this.immersive}get isLittleKnownFactsCard(){return this.cardTelemetryName===C.pL.LittleKnownFactsCard||this.cardTelemetryName===C.pL.NewsLittleKnownFactsCard}get shouldRenderProviderSubtitleOnly(){var e;return(null===(e=this.config)||void 0===e?void 0:e.enableIconAndBrandName)&&this.isLittleKnownFactsCard}get isLittleKnownFactsWithSubtitle(){var e;return this.shouldRenderProviderSubtitleOnly&&(null===(e=this.subtitleData)||void 0===e?void 0:e.text)&&!this.imgFailed}dispose(){var e,t;null===(e=this.rubyLikeController)||void 0===e||e.dispose(),null===(t=this.rubyDislikeController)||void 0===t||t.dispose()}get hoverTelemetryId(){return this.id||"ruby-widget-card"}};(0,o.Cg)([r.sH],T.prototype,"badgeData",void 0),(0,o.Cg)([r.sH],T.prototype,"cardTelemetryName",void 0),(0,o.Cg)([r.sH],T.prototype,"cardTelemetryContentType",void 0),(0,o.Cg)([(0,a.CF)({attribute:"id"})],T.prototype,"id",void 0),(0,o.Cg)([(0,a.CF)({attribute:"insight"})],T.prototype,"insight",void 0),(0,o.Cg)([r.Jg],T.prototype,"hasMediaOrAugment",null),(0,o.Cg)([r.Jg],T.prototype,"canRenderInsight",null),(0,o.Cg)([(0,a.CF)({attribute:"heading"})],T.prototype,"heading",void 0),(0,o.Cg)([r.sH],T.prototype,"href",void 0),(0,o.Cg)([r.sH],T.prototype,"imageSrc",void 0),(0,o.Cg)([r.sH],T.prototype,"subtitleData",void 0),(0,o.Cg)([r.sH],T.prototype,"socialBarData",void 0),(0,o.Cg)([r.sH],T.prototype,"videoPreviewControls",void 0),(0,o.Cg)([(0,a.CF)({attribute:"immersive",mode:"boolean"})],T.prototype,"immersive",void 0),(0,o.Cg)([(0,a.CF)({attribute:"enable-4-lines-title",mode:"boolean"})],T.prototype,"enable4LinesTitle",void 0),(0,o.Cg)([(0,a.CF)({attribute:"media-type"})],T.prototype,"mediaType",void 0),(0,o.Cg)([r.sH],T.prototype,"rootTelemetryObject",void 0),(0,o.Cg)([(0,a.CF)({attribute:"render-augment",mode:"boolean"})],T.prototype,"renderAugment",void 0),(0,o.Cg)([(0,a.CF)({attribute:"render-custom-bg-element",mode:"boolean"})],T.prototype,"renderCustomBgElement",void 0),(0,o.Cg)([(0,a.CF)({attribute:"position-info-bottom",mode:"boolean"})],T.prototype,"positionInfoBottom",void 0),(0,o.Cg)([(0,a.CF)({attribute:"enlarged-image",mode:"boolean"})],T.prototype,"enlargedImage",void 0),(0,o.Cg)([(0,a.CF)({attribute:"enable-btm-social-bar",mode:"boolean"})],T.prototype,"enableBottomSocialBar",void 0),(0,o.Cg)([r.sH],T.prototype,"enableSpecialFWInCJK",void 0),(0,o.Cg)([r.sH],T.prototype,"containerPadding",void 0),(0,o.Cg)([r.Jg],T.prototype,"isSegmentImmersive",null),(0,o.Cg)([(0,a.CF)({attribute:"size"})],T.prototype,"size",void 0),(0,o.Cg)([(0,a.CF)({attribute:"enable-expanded-actions"})],T.prototype,"enableExpandedActions",void 0),(0,o.Cg)([r.sH],T.prototype,"config",void 0),(0,o.Cg)([r.sH],T.prototype,"imageErrorCallback",void 0),(0,o.Cg)([r.sH],T.prototype,"imageLoadedCallback",void 0),(0,o.Cg)([r.sH],T.prototype,"enableHideActionInKumo",void 0),(0,o.Cg)([r.sH],T.prototype,"enableWidgetNotInterested",void 0),(0,o.Cg)([r.sH],T.prototype,"enableCuratedByCopilot",void 0),(0,o.Cg)([(0,a.CF)({attribute:"badge-appearance"})],T.prototype,"badgeAppearance",void 0),(0,o.Cg)([r.sH],T.prototype,"imgFailed",void 0),(0,o.Cg)([r.sH],T.prototype,"telemetry",void 0),(0,o.Cg)([r.sH],T.prototype,"rubyLikeController",void 0),(0,o.Cg)([r.sH],T.prototype,"rubyDislikeController",void 0),(0,o.Cg)([r.sH],T.prototype,"rubyCommentController",void 0),(0,o.Cg)([r.sH],T.prototype,"rubyHideController",void 0),(0,o.Cg)([r.sH],T.prototype,"likeButtonProps",void 0),(0,o.Cg)([r.sH],T.prototype,"dislikeButtonProps",void 0),(0,o.Cg)([r.sH],T.prototype,"commentButtonProps",void 0),(0,o.Cg)([r.sH],T.prototype,"hideCardButtonProps",void 0),(0,o.Cg)([r.sH],T.prototype,"hideCardDismissCallback",void 0),(0,o.Cg)([r.Jg],T.prototype,"enableRubyHideCard",null),(0,o.Cg)([r.Jg],T.prototype,"enableSocialButtons",null),(0,o.Cg)([r.Jg],T.prototype,"showBottomSocialBar",null),(0,o.Cg)([r.Jg],T.prototype,"shouldRenderVideoPreview",null),(0,o.Cg)([r.Jg],T.prototype,"isVideo",null),(0,o.Cg)([r.Jg],T.prototype,"isVideoIndicatorInMainContainer",null),(0,o.Cg)([r.Jg],T.prototype,"isVideoInMediaContainer",null),(0,o.Cg)([r.Jg],T.prototype,"isLittleKnownFactsCard",null),(0,o.Cg)([r.Jg],T.prototype,"shouldRenderProviderSubtitleOnly",null),(0,o.Cg)([r.Jg],T.prototype,"isLittleKnownFactsWithSubtitle",null),(0,o.Cg)([r.Jg],T.prototype,"hoverTelemetryId",null),T=(0,o.Cg)([m.x],T);var _=i(96950),B=i(60402),j=i(69259),O=i(66591),S=i(29940),I=i(6497),U=i(48535),A=i(79119),F=i(3480),E=i(1349);const D=_.qy`<span class="video-indicator"><span class="video-indicator-img"><span class="video-indicator-icon"></span></span></span>`,V=_.qy`<video class="media" muted playsinline="true" slot="media" poster="${e=>e.imageSrc}" preload="none" @error="${e=>{var t,i;return null===(i=null===(t=e.videoPreviewControls)||void 0===t?void 0:t.videoLogError)||void 0===i?void 0:i.call(t,"")}}" src="${e=>{var t;return null===(t=e.videoPreviewControls)||void 0===t?void 0:t.videoPreviewUrl}}" type="video/mp4" @play="${(e,t)=>{var i,o;return null===(o=null===(i=t.event)||void 0===i?void 0:i.target)||void 0===o?void 0:o.setAttribute("is-playing","1")}}" @pause="${(e,t)=>{var i,o;return null===(o=null===(i=t.event)||void 0===i?void 0:i.target)||void 0===o?void 0:o.removeAttribute("is-playing")}}" @timeupdate="${e=>{var t,i;return null===(i=null===(t=e.videoPreviewControls)||void 0===t?void 0:t.videoTimeUpdateCb)||void 0===i?void 0:i.call(t)}}" ?is-portrait="${e=>{var t;return null===(t=e.videoPreviewControls)||void 0===t?void 0:t.isVideoPortrait}}" ${(0,B.K)("videoElementRef")}></video>`,P=_.qy`<img src=${e=>e.imageSrc} class="media" part="media" @error="${(e,t)=>e.onMediaError(t.event)}" @load="${(e,t)=>e.onMediaLoaded(t.event)}" loading="lazy" aria-hidden="true"></img>`,R=_.qy`<a aria-level="2" class="heading" href="${e=>e.href}" id="heading" role="heading" target="_blank" data-t=${e=>{var t;return null===(t=e.telemetry)||void 0===t?void 0:t.destination.getMetadataTag()}} ${(0,B.K)("headingRef")}>${e=>e.heading}</a>`,H=_.qy`<slot name="badge"></slot>`,L=_.qy`<img class="badge-icon" alt="" src="${e=>{var t;return null===(t=e.badgeData)||void 0===t?void 0:t.iconUrl}}"/>`,M=_.qy`<a class="badge" data-t=${e=>{var t;return null===(t=e.telemetry)||void 0===t?void 0:t.badge.getMetadataTag()}} href="${e=>e.href}" target="_blank">${(0,j.z)(e=>{var t;return null===(t=e.badgeData)||void 0===t?void 0:t.iconUrl},L)}<span class="badge-text">${e=>{var t;return null===(t=e.badgeData)||void 0===t?void 0:t.text}}</span></a>`,N=_.qy`<span class="insight">${e=>e.insight}</span>`,q=_.qy`<img class="subtitle-logo" alt="" src=${e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.logoUrl}}></img>`,K=_.qy`<img class="subtitle-logo" alt="" src=${e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.logoIconUrl}}></img>`,J=_.qy`<span class="suffix">${e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.suffix}}</span>`,W=_.qy`<a data-t=${e=>{var t,i;return(null===(t=e.subtitleData)||void 0===t?void 0:t.telemetryTag)||(null===(i=e.telemetry)||void 0===i?void 0:i.destination.getMetadataTag())}} href="${e=>{var t;return(null===(t=e.subtitleData)||void 0===t?void 0:t.href)||e.href}}" tabindex="${e=>{var t;return(null===(t=e.subtitleData)||void 0===t?void 0:t.href)?"0":"-1"}}" target="_blank" class=${e=>{var t,i;return(0,O.x)("subtitle-container",["dark",null===(t=e.subtitleData)||void 0===t?void 0:t.textDarkMode],["noclk",null===(i=e.subtitleData)||void 0===i?void 0:i.noClick])}}>${(0,j.z)(e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.logoIconUrl},K)}<span class="subtitle-text">${e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.publishText}}</span>${(0,j.z)(e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.suffix},J)}</a>`,G=_.qy`<a data-t=${e=>{var t,i;return(null===(t=e.subtitleData)||void 0===t?void 0:t.telemetryTag)||(null===(i=e.telemetry)||void 0===i?void 0:i.destination.getMetadataTag())}} href="${e=>{var t;return(null===(t=e.subtitleData)||void 0===t?void 0:t.href)||e.href}}" tabindex="${e=>{var t;return(null===(t=e.subtitleData)||void 0===t?void 0:t.href)?"0":"-1"}}" target="_blank" class=${e=>{var t,i;return(0,O.x)("subtitle-container",["dark",null===(t=e.subtitleData)||void 0===t?void 0:t.textDarkMode],["noclk",null===(i=e.subtitleData)||void 0===i?void 0:i.noClick])}}>${(0,j.z)(e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.logoUrl},q)}<span class=${e=>{var t;return(0,O.x)("subtitle",["hasActionIcon",!(null===(t=e.config)||void 0===t?void 0:t.hideCardActionsIcon)])}}>${e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.text}}</span>${(0,j.z)(e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.suffix},J)}</a>`,X=_.qy`<a class="badge" data-t=${e=>{var t,i;return(null===(t=e.subtitleData)||void 0===t?void 0:t.telemetryTag)||(null===(i=e.telemetry)||void 0===i?void 0:i.destination.getMetadataTag())}} href="${e=>{var t;return(null===(t=e.subtitleData)||void 0===t?void 0:t.href)||e.href}}" target="_blank"><span class="badge-text">${e=>{var t;return null===(t=e.subtitleData)||void 0===t?void 0:t.text}}</span></a>`,Y=_.qy` ${(0,j.z)(e=>e.isVideoInMediaContainer,D)} ${(0,j.z)(e=>e.shouldRenderVideoPreview,V)} ${(0,j.z)(e=>e.imageSrc&&!e.shouldRenderVideoPreview,P)}
`,Z=_.qy`<slot name="augment" class="augment"></slot>`,Q=_.qy`<slot name="info" class="info"></slot>`,ee=_.qy`<slot name="content" class="content"></slot>`,te=_.qy`<img src=${e=>e.imageSrc} class="augment-bg-image" alt=""></img>`,ie=_.qy` ${e=>{var t;return(0,S.n)({telemetryTag:null===(t=e.telemetry)||void 0===t?void 0:t.cardAction.getMetadataTag(),onClick(t){return e.handleCardActionClick(t)},title:e.strings.rubyActionButtonTooltip})}}
`,oe=_.qy` ${(0,j.z)(e=>e.isVideoIndicatorInMainContainer,D)}<div class="media-container">${(0,j.z)(e=>e.renderAugment,Z,Y)}</div>${(0,j.z)(e=>e.renderAugment&&e.imageSrc&&e.renderCustomBgElement,te)}
`,ne=_.qy`
${(0,j.z)(e=>e.likeButtonProps,e=>(0,I.O)(e.likeButtonProps))}
`,re=_.qy`
${(0,j.z)(e=>e.dislikeButtonProps,e=>(0,U.U)(e.dislikeButtonProps))}
`,ae=_.qy`
${(0,j.z)(e=>e.commentButtonProps,e=>(0,A.g)(e.commentButtonProps))}
`,se=_.qy`
${(0,j.z)(e=>e.hideCardButtonProps,e=>(0,F.R)(e.hideCardButtonProps))}
`,de=_.qy`<div class="ruby-social-bar">${ne} ${re} ${ae}</div>`,le=_.qy` ${(0,j.z)(e=>e.subtitleData,G,H)}
`,ce=_.qy`<div class="body" part="body">${(0,j.z)(e=>e.badgeData,M)} ${(0,j.z)(e=>e.isLittleKnownFactsWithSubtitle,X)} ${(0,j.z)(e=>e.renderCustomBgElement&&e.immersive,ee)}<div class="content-container">${(0,j.z)(e=>e.shouldRenderProviderSubtitleOnly,W,le)}<div class="text-container">${R} ${(0,j.z)(e=>e.canRenderInsight,N)} ${(0,j.z)(e=>!e.immersive,Q)}</div></div>${(0,j.z)(e=>e.showBottomSocialBar,de)} ${(0,j.z)(e=>e.rubyHideController,e=>{var t,i,o,n,r;return(0,F.X)({updatingText:null===(t=e.strings)||void 0===t?void 0:t.rubyHideCardUpdatingText,confirmationText:null===(i=e.strings)||void 0===i?void 0:i.rubyHideCardConfirmationText,spinnerCompletedCallback(){return e.hideCardSpinnerCompleted()},undoText:null===(o=e.strings)||void 0===o?void 0:o.rubyUndoButtonText,undoTelemetryTag:null===(r=null===(n=e.telemetry)||void 0===n?void 0:n.undoShowFewer)||void 0===r?void 0:r.getMetadataTag(),rubyHideController:e.rubyHideController})})}</div>`,ue=_.qy`<a class="overlay" data-t=${e=>{var t;return null===(t=e.telemetry)||void 0===t?void 0:t.destination.getMetadataTag()}} href="${e=>e.href}" target="_blank" tabindex="-1"></a>`,he=_.qy` ${(0,j.z)(e=>e.isSegmentImmersive&&e.subtitleData,G)} ${(0,j.z)(e=>e.hasMediaOrAugment,oe)} ${(0,j.z)(e=>!e.isSegmentImmersive,ce)} ${(0,j.z)(e=>{var t;return!(null===(t=e.rubyHideController)||void 0===t?void 0:t.hideCardState)},_.qy`<div class="card-actions-button-container">${(0,j.z)(e=>e.enableSocialButtons&&e.likeButtonProps&&!e.showBottomSocialBar,ne)} ${(0,j.z)(e=>{var t;return(0,$.S)()&&!(null===(t=e.config)||void 0===t?void 0:t.hideCardActionsIcon)},ie)} ${(0,j.z)(e=>{var t;return(0,$.S)()&&(null===(t=e.config)||void 0===t?void 0:t.enableRubyHideCard)&&e.hideCardButtonProps},se)}</div>`)} ${(0,j.z)(e=>{var t;return!e.renderAugment&&!(null===(t=e.rubyHideController)||void 0===t?void 0:t.hideCardState)},ue)}
`,ve=_.qy`<template data-t=${e=>{var t,i;return null===(i=null===(t=null==e?void 0:e.telemetry)||void 0===t?void 0:t.card)||void 0===i?void 0:i.getMetadataTag()}} @mouseenter=${e=>(0,E.O)(e,e.hoverTelemetryId)} @mouseleave=${e=>(0,E.J)(e,e.hoverTelemetryId)} class=${e=>(0,O.x)(["has-social-bar",e.showBottomSocialBar])}><div class="${e=>(0,O.x)("root",e.containerPadding||"")}">${he}</div></template>`;var me,be=i(32257),ge=i(29222),pe=i(13187),$e=i(35279),xe=i(87204),ke=i(26248),we=i(77345),fe=i(74849),ye=i(4126),ze=i(22131),Ce=i(24816),Te=i(77558),_e=i(58792),Be=i(97062),je=i(42495),Oe=i(78222),Se=i(5111),Ie=i(87944);const Ue=fe.A`
    ${Ce.n3} :host([size="1.5u"]) .media-container{aspect-ratio:1.91 / 1}:host([class="has-social-bar"]) .ruby-social-bar{padding-inline:${be.YUh};
        padding-block-end: ${ge.$rH};
    }
`,Ae=fe.A` #heading{font-weight:500}`,Fe=fe.A` :host([size="1u"]){height:100%;display:flex;--card-height:100%;contain-intrinsic-height:none;min-height:${pe.UJ};
        max-height: ${pe.gY}}:host([size="1u"]){aspect-ratio:${$e.du.toString()} / ${$e.C6.toString()}}:host([size="1u"]) .root{gap:${be.LbM};
        height: 100%;
        contain-intrinsic-height: none;
    }

    ${Be.v9}
`,Ee=fe.A` :host([immersive]),:host{min-width:inherit;max-width:inherit;width:100%}:host([size="0.5u"][immersive][render-augment]),:host([size="1u"][immersive][render-augment]),:host([size="1.5u"][immersive][render-augment]),:host{padding:0;place-items:center}:host([size="0.5u"][immersive][render-augment]){place-content:normal}:host([immersive][render-augment][size="2c"]){padding:0px}:host([size="2c"]) .media-container{aspect-ratio:2}.body,:host([immersive]) .media{width:100%}.root{width:calc(100% - 2 * ${xe.q_});
        min-width: calc(100% - 2 * ${xe.q_});
    }
`.withBehaviors(new ye.o("size","1u",Fe)),De=fe.A` :host([size="0.5u"]){--card-height:${(0,Ie.c)($e.Yc)};
        border-radius: ${ge.tF1};corner-shape:squircle;flex-direction:row-reverse;gap:10px}:host([size="0.5u"]) .media-container{display:flex;min-width:84px;width:84px}:host([size="0.5u"][immersive]) .media-container{width:100%}:host([size="0.5u"][immersive]) .heading{-webkit-line-clamp:1}:host([size="0.5u"]:not([immersive])) .media{height:84px;width:84px;align-self:center}:host([size="0.5u"]) .text-container{gap:0;justify-content:center}:host([size="0.5u"]) .insight{-webkit-line-clamp:1}:host([size="0.5u"]) .card-actions-button-container{inset-block-start:${be.YUh};
        inset-inline-end: ${be.YUh}}:host([size="0.5u"]:not([immersive])) ::slotted([slot="badge"]){margin-bottom:-18px;margin-right:-48px}:host([size="0.5u"][render-augment][immersive]) .root{padding:calc(${ge.$rH} + ${ge.Gkw}) 
            calc(${be.WCE} + ${ge.$rH});
        gap: ${be.LFA}}:host([size="0.5u"][render-augment][immersive]) .subtitle-container{min-height:26px;max-height:26px}:host([size="0.5u"]:not([render-augment])) .media-container{overflow:unset}:host([size="0.5u"]:not([immersive])) .media-container,:host([size="0.5u"]:not([immersive])) .text-container{margin-top:8px}.subtitle{font-size:${be.YXL};
        font-weight: 650;
    }
`,Ve=fe.A` :host([size="1u"]) .media-container{min-height:fit-content;aspect-ratio:1.8135 / 1}:host([size="1u"]) .content-container{gap:0}`,Pe=fe.A` :host([size="1.5u"]) .media-container{min-height:fit-content;aspect-ratio:1.59 / 1}:host([size="1.5u"]) .content-container{gap:0}`.withBehaviors(new ye.o("enableBottomSocialBar",!0,Ue)),Re=fe.A` :host([size="2c"]){--card-width:${pe.MY};flex-direction:row-reverse;gap:16px}:host([size="2c"]) .body{width:100%}:host([size="2c"]:not([immersive])) .media{height:100%}`,He=fe.A` .badge{background:${xe.ik}}.badge-text{color:${xe.Vj};
    }
`,Le=fe.A` .badge{padding-top:${be.UL_};
        padding-bottom: ${be._t4}}.badge-text{color:${be.SdH};
        font-size: ${be.lJ3};
        line-height: ${be.ESf};
    }
`,Me=fe.A`
    ${Le} .badge{background:#E8174B}`,Ne=fe.A`
    ${Le} .badge{background:#007AC7}`,qe=fe.A` .badge{--badge-margin:20px;display:flex;align-items:center;padding:0 calc(${be.w97} + 4px);
        border-radius: ${be.aJo};
        gap: 4px;
        position: absolute;
        inset-inline-start: calc(${ge.$rH} + var(--badge-margin));
        inset-block-start: calc(${ge.$rH} + var(--badge-margin));
        background: ${ge.RfR};
        z-index: ${Te.P.Above.toString()};
        height: ${ke.w_};text-decoration:none}:host(:not([immersive]):not([size="0.5u"])) .badge{margin:0}.badge-icon{height:${ke.vq};
        width: ${ke.vq}}.badge-text{color:${ge.kLb};
        font-size: ${be.Lgj};
        line-height: ${be.kyM};
        text-overflow: ellipsis;
        max-width: 180px;
        overflow: hidden;
        white-space: nowrap;
    }
`.withBehaviors(new ye.o("badgeAppearance","StatusDangerTint",He),new ye.o("badgeAppearance","shimmerForYou",Ne),new ye.o("badgeAppearance","shimmerBreakingNews",Me)),Ke=fe.A` .subtitle-container{min-height:20px;max-height:20px;overflow:hidden;font-weight:${ge.IH6};
        font-size: ${be.e1r};
        line-height: ${be.HoW};
        color: ${be.C6c};
        text-overflow: ellipsis;
        gap: 8px;
        margin-block: 4px;
        margin-block-end: ${be.fFM};display:flex;align-items:center;text-decoration:none}.subtitle-container.noclk{cursor:auto}.subtitle-logo{height:16px;width:16px;border-radius:${ge.cbN}}:host([size="0.5u"]:not([immersive])) .subtitle-container{margin-block-end:-18px;margin-inline-end:-48px}:host([immersive]:not([render-augment])) .subtitle-container{color:${ge.b0J}}:host([render-augment]:not([immersive])) .subtitle-container{z-index:${(Te.P.Above+1).toString()}}.suffix{margin-inline-start:4px}.subtitle-container.dark{color:${be.C6c}}.subtitle{-webkit-line-clamp:1;-webkit-box-orient:vertical;display:-webkit-box;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:246px}.subtitle.hasActionIcon{max-width:calc(100% - ${be.Szr})}.content-container .subtitle{max-width:246px}`,Je=fe.A` :host([immersive]){padding:0;border:none;--ruby-card-gradient:linear-gradient(to top,hsl(0,0%,0%) 0%,hsla(0,0%,0%,0.987) 9.6%,hsla(0,0%,0%,0.951) 16.8%,hsla(0,0%,0%,0.896) 21.9%,hsla(0,0%,0%,0.825) 25.6%,hsla(0,0%,0%,0.741) 28.1%,hsla(0,0%,0%,0.648) 30.2%,hsla(0,0%,0%,0.55) 32.1%,hsla(0,0%,0%,0.45) 34.3%,hsla(0,0%,0%,0.352) 37.4%,hsla(0,0%,0%,0.259) 41.9%,hsla(0,0%,0%,0.175) 48%,hsla(0,0%,0%,0.104) 56.5%,hsla(0,0%,0%,0.049) 67.6%,hsla(0,0%,0%,0.013) 82%,hsla(0,0%,0%,0) 100%)}:host([immersive]:not([render-augment])){--image-border-radius:24px}:host([immersive]:not([render-augment])) .media-container{border-radius:calc(${ge.MCQ} * ${ge.MU6})}:host([immersive]) .media-container{position:absolute;border-radius:unset}:host([immersive]) .video-indicator-img{margin-top:-64px}:host([size="0.5u"][immersive]) .video-indicator-img{margin-top:0px}:host([immersive]) .media{position:absolute;z-index:1;padding:0;height:var(--card-height);width:var(--card-width);border-radius:24px}:host([immersive]) .body{z-index:2;background-blend-mode:overlay;background:var(--ruby-card-gradient);gap:16px;padding-inline:20px;padding-block:20px;margin-top:auto;justify-content:flex-end;width:100%;border-radius:calc(${ge.MCQ} * ${ge.MU6});corner-shape:squircle}:host([immersive]:not([render-augment])) .root{width:100%;height:var(--card-height)}:host([immersive]) .text-container{justify-content:flex-end;height:fit-content;z-index:3}:host([immersive]) .heading{color:${ke.fc}}:host([immersive]) .content-container{justify-content:end}:host([immersive]) ::slotted([slot="badge"]){color:${ke.fc}}:host([immersive][render-augment]){padding:${ke.mU};flex-direction:column}:host([size="0.5u"][immersive][render-augment]){gap:12px}:host([immersive][render-augment]) .media-container{position:relative;border-radius:unset}:host([immersive]:not([render-augment])) .media-container{height:calc(var(--card-height) - 2 * ${xe.q_});
        width: calc(100% - 2 * ${xe.q_})}:host([render-augment][immersive]) .root{padding:calc(${be.WCE} + ${ge.$rH})}:host([render-augment][immersive]) .root.padding-sm{padding:${ge.$rH}}:host([render-augment][immersive]) .root.padding-none{padding:${be.F64}}:host([immersive][render-augment]) .subtitle-container{margin-block:0;z-index:${(Te.P.Default+1).toString()};
        font-size: ${be.Aps};
        line-height: ${be.LfE};
        font-weight: ${ge.fNx};min-height:unset;max-height:unset}:host([immersive][render-augment]) .root.padding-sm .subtitle-container{padding:${be.WCE};padding-block-end:0}.root{padding:0}:host([immersive][render-augment]) .subtitle-container::before{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;width:100%;z-index:${(Te.P.Default+1).toString()}}:host([immersive][render-custom-bg-element]) .content-container{height:unset}:host([render-augment][render-custom-bg-element]) .root{background:transparent}.augment-bg-image{position:absolute;top:${xe.q_};
        left: ${xe.q_};
        height: calc(var(--card-height) - 2 * ${xe.q_});
        width: calc(100% - 2 * ${xe.q_});
        border-radius: calc(${ge.MCQ} * ${ge.MU6});
        corner-shape: squircle;
        z-index: ${Te.P.Below.toString()};
    }
`,We=fe.A` :host([enlarged-image]:not([size="0.5u"])) .heading{-webkit-line-clamp:1}:host([enlarged-image]:not([size="0.5u"])) .body{height:unset}:host([size="0.5u"][enlarged-image]) .media-container{margin-top:0px !important}`,Ge=fe.A` :host([position-info-bottom]:not([immersive])) .heading{-webkit-line-clamp:2}:host([position-info-bottom]:not([immersive])) ::slotted([slot="info"]){position:absolute;bottom:20px}:host([size="0.5u"][position-info-bottom]) .media-container,:host([size="0.5u"][position-info-bottom]) .text-container{margin-top:0px !important}`,Xe=fe.A` :host([enable-4-lines-title]) .heading{-webkit-line-clamp:4}`,Ye=`${null===(me=(0,_e.rA)())||void 0===me?void 0:me.StaticsUrlWithBuild}icons/VideoPlayIndicator_24_White.svg`,Ze=fe.A` .video-indicator{position:absolute;height:100%;width:100%;align-items:center;justify-content:center;display:flex;pointer-events:none;z-index:3;transition:opacity 0.4s ease;opacity:1}:host:has(video[is-playing]) .video-indicator{opacity:0;transition-duration:1s}.video-indicator-img{position:absolute;box-sizing:border-box;display:flex;align-items:center;justify-content:center;height:${be.xo8};
        width: ${be.xo8};
        padding: 6px;
        border-radius: ${be.g6L};
        border: 1px solid ${ge.thz};
        background: 
            linear-gradient(0deg, ${ge.iG5} 0%, ${ge.iG5} 100%), 
            linear-gradient(0deg, ${ge.PWf} 0%, ${ge.PWf} 100%), 
            ${ge.rFv};background-blend-mode:normal,luminosity,saturation}.video-indicator-icon{display:block;width:24px;height:24px;background-color:${ge.b0J};
        mask: url(${Ye}) no-repeat center;
        -webkit-mask: url(${Ye}) no-repeat center}:host([immersive][size="0.5u"]) .video-indicator{height:36px;width:36px;inset-inline-end:24px;inset-block-end:24px}`,Qe=fe.A` :host{background:unset}.insight{color:#C7D2DA}::slotted([slot="badge"]){color:${ke.fc};
    }
`,et=fe.A`
    ${Ce.L} .card-actions-button-container{align-items:center;display:flex;gap:${be.VUD};
        position: absolute;
        inset-block-start: calc(${be.ACF} * 2);
        inset-inline-end: calc(${be.ACF} * 2);z-index:999}.card-actions-button-container .like-card-button,.card-actions-button-container .card-actions-button,.card-actions-button-container .hide-card-button{position:relative;inset-block-start:unset;inset-inline-end:unset}fluent-tooltip{margin-top:-12px !important;margin-right:-10px !important}`,tt=fe.A` :host{--card-height:${pe.tM};
        --card-width: ${pe.dd};
        --image-border-radius: 12px;
        display: grid;
        place-content: center;
        height: var(--card-height);
        width: var(--card-width);
        min-width: var(--card-width);
        border-radius: unset;
        background: unset;
        border: unset;
        gap: 12px;
        padding: ${ke.mU};contain-intrinsic-height:auto var(--card-height);box-sizing:border-box;contain:content;content-visibility:auto}:host(:hover) .media{filter:none}.root{background:${be.lHC};
        backdrop-filter: var(--background-card-stnp-filter, none);
        display: flex;
        flex-direction: column;
        gap: 12px;
        border: ${xe.q_} solid ${be.h7K};
        border-radius: calc(${ge.MCQ} * ${ge.MU6});
        corner-shape: squircle;
        height: calc(var(--card-height) - 2 * ${xe.q_});
        width: calc(var(--card-width) - 2 * ${xe.q_});
        padding: ${ge.$rH};box-sizing:border-box;overflow:hidden;position:relative}:host:has(.heading:focus-visible) .root{border-color:${be.X2Y}}.body{display:flex;flex-direction:column;justify-content:space-between;height:100%;gap:14px;box-sizing:border-box;margin-inline-end:auto;border-radius:${be.Q$E}}.media-container{height:100%;width:100%;position:relative;overflow:hidden;border-radius:${xe.tM};corner-shape:squircle}.media{height:100%;width:100%;border-radius:var(--image-border-radius);aspect-ratio:16/9;object-fit:cover;clip-path:inset(0% round var(--image-border-radius))}.content-container{display:flex;flex-direction:column;height:100%;padding:${be.YUh};padding-block-start:4px}.root:not(:has(.media-container)) .body:has(.badge) .content-container{padding-block-start:calc(20px + ${ke.w_} + 8px)}.text-container{display:flex;flex-direction:column;gap:8px;height:100%}.heading{overflow:hidden;color:${be.C6c};
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3;
        font-size: ${be.Aps};
        line-height: ${be.LfE};
        font-weight: ${ge.fNx};
        font-family: ${ge.sNZ};text-decoration:none}.heading:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;width:100%;z-index:${Te.P.Above.toString()};
        border-radius: ${be.Q$E}}.heading:focus-visible{outline:none;text-decoration:underline}.overlay{content:"";position:absolute;width:100%;height:100%;left:0;top:0;inset-inline-start:0;inset-block-start:0;z-index:${Te.P.Over.toString()};
        border-radius: ${be.Q$E}}.insight{overflow:hidden;color:#284052;display:-webkit-box;-webkit-line-clamp:6;-webkit-box-orient:vertical;font-size:${ke.vJ};
        line-height: ${ke.uG}}::slotted([slot="badge"]){min-height:24px;max-height:24px;overflow:hidden;font-weight:${ke.Fu};
        font-size: ${ke.ap};
        line-height: ${ke.XA};
        color: ${be.C6c};-webkit-line-clamp:1;-webkit-box-orient:vertical;display:-webkit-box;text-overflow:ellipsis}::slotted([slot="augment"]){height:100%;width:100%;position:absolute;overflow:hidden}${et}
    ${Ke}
    ${qe}
    ${je.c}
`.withBehaviors(new ye.o("size","0.5u",De),new ye.o("size","1u",Ve),new ye.o("size","1.5u",Pe),new ye.o("size","2c",Re),new ye.o("immersive",!0,Je),new ye.o("mediaType","video",Ze),new ye.o("positionInfoBottom",!0,Ge),new ye.o("enable4LinesTitle",!0,Xe),new ye.o("enlargedImage",!0,We),new ye.o("isAdaptiveThemeEnabled",!0,Ee),new ye.o("enableSpecialFWInCJK",!0,Ae),new we.P(Oe.ve,Oe.Y),new we.P(Oe.NM,Oe.uE),new we.P(Se.Es,Se.t3),new we.P(Se.gN,Se.b$),(0,ze.G2)(Qe));var it=i(65614);const ot=T.compose({name:"cx-ruby-widget-card",template:ve,styles:tt,shadowOptions:{delegatesFocus:!0}}),nt=()=>{ot.define(it.G.registry)}},48535(e,t,i){i.d(t,{U(){return u},v(){return s}});var o=i(66591),n=i(96950),r=i(69259),a=i(58792);function s(e){return`dislike-button-${e}`}const d=e=>{var t;return Boolean(null==e||null===(t=e.rubyDislikeController)||void 0===t?void 0:t.showFewerButtonSelected)},l=n.qy`<img alt="" aria-hidden="true" src="${(0,a.rA)().StaticsUrl}/latest/fluent-icons/thumb_dislike_20_filled.svg"></img>`,c=n.qy`<img alt="" aria-hidden="true" src="${(0,a.rA)().StaticsUrl}/latest/fluent-icons/thumb_dislike_20_regular.svg"></img>`,u=e=>{var t;return n.qy`<button class=${null!=e&&e.className?(e=>`${d(e)?"disliked":"not-disliked"}-${null==e?void 0:e.className}`)(e):(e=>(0,o.x)("like-card-button dislike-card-button",["render-bottom-tooltip",Boolean(null==e?void 0:e.renderBottomTooltip)]))(e)} data-t="${(d(e)?null==e?void 0:e.telemetryTagUndo:null==e?void 0:e.telemetryTag)||""}" @click=${(e=>(t,i)=>{var o;const n=i.event,r=0!==n.clientX||0!==n.clientY;null==e||null===(o=e.rubyDislikeController)||void 0===o||o.toggleShowFewer(t,r)})(e)||(()=>{})} ?ruby=${(null==e?void 0:e.ruby)||!1} title=${(null==e?void 0:e.dislikeButtonTooltip)||""} id=${s((null==e?void 0:e.id)||"")} aria-pressed=${t=>d(e)} aria-label=${(null==e?void 0:e.ariaLabel)||(null==e?void 0:e.dislikeButtonTooltip)||(null==e||null===(t=e.getInnerText)||void 0===t?void 0:t.call(e,d(e),null==e?void 0:e.innerText))||""}>${(0,r.z)(d(e),l,c)} ${(0,r.z)(!(null==e||!e.innerText),(e=>{var t;return n.qy`<span>${(null==e||null===(t=e.getInnerText)||void 0===t?void 0:t.call(e,d(e),null==e?void 0:e.innerText))||""}</span>`})(e))} ${(0,r.z)((e=>Boolean((d(e)||Boolean(null==e?void 0:e.dislikeCount))&&(null==e?void 0:e.renderCount)))(e),(e=>{var t,i;return n.qy`<span class="dislike-count" aria-hidden="true">${(null==e||null===(t=e.rubyDislikeController)||void 0===t||null===(i=t.getDownvoteCount)||void 0===i?void 0:i.call(t,null==e?void 0:e.dislikeCount))||""}</span>`})(e))}</button>`}},67689(e,t,i){i.d(t,{h(){return n}});var o=i(2827);function n(){return(0,o.oh)()}},76736(e,t,i){i.d(t,{c(){return n}});var o=i(66038);class n{constructor(e){this.card=e}getCommentCount(e){var t;return(0,o.t)(!1,e,null===(t=this.card)||void 0===t?void 0:t.locale)}}},78222(e,t,i){i.d(t,{NM(){return c},Y(){return l},uE(){return u},ve(){return d}});var o=i(32257),n=i(29222),r=i(74849);const a=r.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]) {
        aspect-ratio: 0.9518;
    }

    :host([size="1u"][ux-mode="billboard"]:not([variant="immersive"])) .image-attribution-container,
    :host([size="1c"][ux-mode="billboard"]:not([variant="immersive"])) .image-attribution-container,
    :host([size="1u"][ux-mode="billboard"]:not([variant="immersive"])) .media,
    :host([size="1c"][ux-mode="billboard"]:not([variant="immersive"])) .media,
    :host([size="1u"][ruby]) .ruby-image-container,
    :host([size="1u"]) .media-container {
        aspect-ratio: 1.875 / 1;
    }

    :host([size="1u"]:not([ux-mode="billboard"])) .media-container {
        margin-bottom: ${o.LbM};
    }

    :host([size="1.5u"]) .attribution, 
    :host([size="1.5u"]) .heading, 
    :host([size="1.5u"]) .insight,
    :host([size="1u"]:not([ruby])) .attribution, 
    :host([size="1u"]:not([ruby])) .heading, 
    :host([size="1u"]:not([ruby])) .insight {
        padding-inline: ${o.hW$};
    }

    :host([size="1u"][ruby]) .text {
        padding-block-start: ${o.LFA};
    }

    :host([size="1.5u"]:not([ruby]):not([ux-mode="billboard"])) .card-actions-button-container,
    :host([size="1u"]:not([ruby]):not([ux-mode="billboard"])) .card-actions-button-container {
        top: calc(${o.ACF} * 2);
        right: calc(${o.ACF} + ${n.UYK});
    }

    :host([size="1u"][ruby]) .card-actions-button-container {
        inset-block-start: calc(${o.ACF} * 2);
        margin-inline-end:  calc(${o.ACF} + ${n.UYK});
    }

    :host([size="1.5u"]) .ruby-social-bar,
    :host([size="1u"]) .ruby-social-bar {
        padding-inline: ${o.LFA};
    }
`,s=r.A`
    ${a}
    
    :host([size="1u"][ux-mode="billboard"]) .root,
    :host([size="1c"][ux-mode="billboard"]) .root {
        gap: ${o.LbM};
    }

    :host([size="1u"][ux-mode="billboard"]) cx-gem-facets-card::part(header),
    :host([size="1c"][ux-mode="billboard"]) cx-gem-facets-card::part(header) {
        margin-block-end: 0;
    }

    :host([size="1u"][ux-mode="billboard"]) cx-gem-facets-card::part(title-container),
    :host([size="1c"][ux-mode="billboard"]) cx-gem-facets-card::part(title-container) {
        gap: 0;
    }

    :host([ux-mode="billboard"]) .card-actions-button-container {
        inset-block-start: calc(${o.ACF} * 2);
        inset-inline-end:  calc(${o.ACF} * 2);
    }
`,d="prg-sm-flex",l=r.A`${a}`,c=(r.A`${s}`,"prg-pr2-sm-flex"),u=r.A`${a}`;r.A`${s}`},79119(e,t,i){i.d(t,{g(){return d}});var o=i(96950),n=i(69259),r=i(58792),a=i(42161);const s=o.qy`<img alt="" aria-hidden="true" src="${(0,r.rA)().StaticsUrl}/latest/fluent-icons/comment_20_regular.svg"></img>`,d=e=>{return o.qy`<button class="comment-button like-card-button" data-t="${(null==e?void 0:e.telemetryTag)||""}" title=${(null==e?void 0:e.commentButtonTooltip)||""} id=${t=(null==e?void 0:e.id)||"",`comment-button-${t}`} @click=${()=>(e=>{if(null==e||!e.destinationUrl)return;const t=(0,a.cc)(e.destinationUrl);window.open(t,"_blank")})(e)}>${s} ${(0,n.z)(Boolean((null==e?void 0:e.commentCount)&&e.renderCount),(e=>{var t,i;return o.qy`<span class="comment-count">${(null==e||null===(t=e.rubyCommentController)||void 0===t||null===(i=t.getCommentCount)||void 0===i?void 0:i.call(t,e.commentCount))||""}</span>`})(e))}</button>`;var t}},79650(e,t,i){i.d(t,{I(){return o}});const o=2e3},87056(e,t,i){i.d(t,{V(){return s}});var o=i(56911),n=i(60815),r=i(57702),a=i(77367);class s{constructor(e){this.dismiss=async()=>!this.hideCardState||("spinner"!==this.hideCardState||(this.hideCardState="pending-dismissal",this.hideCardState=void 0,!1)),this.card=e}async hide(){var e;const t=null===(e=this.card)||void 0===e?void 0:e.id;if(!t)return;this.hideCardState="spinner";const i={useCommunityReactions:!0,locale:this.card.locale};await(0,r.J6)().ShowFewer(t,i,void 0,this.card.targetType)}async unhide(e){var t;const i=null===(t=this.card)||void 0===t?void 0:t.id;if(!i)return;e&&(null===a.YT||void 0===a.YT||a.YT.sendActionEvent(e)),this.hideCardState=void 0;const o={useCommunityReactions:!0,locale:this.card.locale};(0,r.J6)().UnshowFewer(i,o)}}(0,o.Cg)([n.sH],s.prototype,"hideCardState",void 0)},97062(e,t,i){i.d(t,{v9(){return p}});var o=i(32257),n=i(35279),r=i(77345),a=i(74849);const s=a.A`
    :host([size="1.5u"]) cx-gem-facets-card[styling-mode="minimal"]::part(title-container),
    :host([size="1u"]) cx-gem-facets-card[styling-mode="minimal"]::part(title-container),
    :host([size="1c"]) cx-gem-facets-card[styling-mode="minimal"]::part(title-container) {
        gap: 0;
    }

    :host([size="1.5u"]) cx-gem-facets-card::part(header),
    :host([size="1c"]) cx-gem-facets-card::part(header),
    :host([size="1u"]) cx-gem-facets-card::part(header) {
        margin-block-end: 0px;
    }

    :host([size="1u"][ux-mode="billboard"]) .root,
    :host([size="1c"][ux-mode="billboard"]) .root {
        gap: ${o.LFA};
    }
`,d=a.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]),
    :host([size="1.5u"]) {
        aspect-ratio: ${n.du.toString()} / ${n.iB.toString()};
    }

    :host([size="2c"][ux-mode="billboard"]),
    :host([size="2c"][ruby]),
    :host([size="2c"]) {
        aspect-ratio: ${n.Mq.toString()} / ${n.iB.toString()};
    }

    :host([size="3c"][ux-mode="billboard"]) {
        aspect-ratio: ${n.Lj.toString()} / ${n.iB.toString()};
    }

    ${s}
`,l=a.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]),
    :host([size="1.5u"]) {
        aspect-ratio: ${n.du.toString()} / ${n.LX.toString()};
    }

    :host([size="2c"][ux-mode="billboard"]),
    :host([size="2c"][ruby]),
    :host([size="2c"]) {
        aspect-ratio: ${n.Mq.toString()} / ${n.LX.toString()};
    }

    :host([size="3c"][ux-mode="billboard"]) {
        aspect-ratio: ${n.Lj.toString()} / ${n.LX.toString()};
    }

    :host([size="1u"]:not([ruby])) .attribution {
        margin-block: calc(${o.fFM} + 2px);
    }

    :host([size="1u"][ruby]) .attribution {
        margin-block: 2px calc(${o.fFM} + 2px);
    }

    .heading {
        padding-block-start: 2px;
    }

    ${s}
`,c=a.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]),
    :host([size="1.5u"]) {
        aspect-ratio: ${n.du.toString()} / ${n.Gm.toString()};
    }

    :host([size="2c"][ux-mode="billboard"]),
    :host([size="2c"][ruby]),
    :host([size="2c"]) {
        aspect-ratio: ${n.Mq.toString()} / ${n.Gm.toString()};
    }

    :host([size="3c"][ux-mode="billboard"]) {
        aspect-ratio: ${n.Lj.toString()} / ${n.Gm.toString()};
    }
        
    ${s}
`,u=a.A`${d}`,h=a.A`${l}`,v=a.A`${c}`,m=a.A`${d}`,b=a.A`${l}`,g=a.A`${c}`,p=a.A`
`.withBehaviors(new r.P("prg-dense-t1",u),new r.P("prg-dense-t2",h),new r.P("prg-dense-t3",v),new r.P("prg-pr2-dense-t1",m),new r.P("prg-pr2-dense-t2",b),new r.P("prg-pr2-dense-t3",g))},99691(e,t,i){i.d(t,{C(){return h},t(){return u}});var o=i(56911),n=i(60815),r=i(57702),a=i(17857),s=i(48535),d=i(58792),l=i(15525),c=i(66038);const u="dislikeButtonClicked";class h{get showMoreFewerCardMetadata(){return this.card.previewType&&this.card.locale?{useVoteActions:!0,useCommunityReactions:!0,...this.card.previewType&&{previewType:this.card.previewType},locale:this.card.locale}:this.card.useVoteActions?{useVoteActions:!0,...this.card.previewType&&{previewType:this.card.previewType}}:{useCommunityReactions:!0,locale:this.card.locale}}constructor(e){var t,i;this.showFewerButtonSelected=!1,this.disableShowTooltip=!1,this.card=e;const{id:o="",disableShowTooltip:n}=e;this.disableShowTooltip=!!n;const s=`myReaction_${null===d.T3||void 0===d.T3?void 0:d.T3.UserId}_${o}_${null===d.T3||void 0===d.T3?void 0:d.T3.CurrentMarket}`;this.showFewerButtonSelected="dislike"===(null===l.Lg||void 0===l.Lg||null===(t=(0,l.Lg)())||void 0===t||null===(i=t.getItem)||void 0===i?void 0:i.call(t,s)),this.removeShowMoreFewerStatusListener=r.Pi.registerShowMoreFewerStatusListener(e=>{let{contentId:t,value:i}=e;t===this.card.id&&(this.showFewerButtonSelected=!!(i&&(i&a.J.showFewer)>0))})}dispose(){var e;null===(e=this.removeShowMoreFewerStatusListener)||void 0===e||e.call(this)}toggleShowFewer(e,t){var i;const o=null===(i=this.card)||void 0===i?void 0:i.id;if(!o)return;const n={targetId:o,metadata:this.showMoreFewerCardMetadata,targetType:this.card.targetType,getTargetElement(){var t;return null===(t=e.shadowRoot)||void 0===t?void 0:t.querySelector(`#${(0,s.v)(o)}`)},isDisliked:!this.showFewerButtonSelected,isMouseClick:t,disableShowTooltip:this.disableShowTooltip};document.dispatchEvent(new CustomEvent(u,{bubbles:!0,detail:n}))}getDownvoteCount(e){var t;return(0,c.t)(this.showFewerButtonSelected,e,null===(t=this.card)||void 0===t?void 0:t.locale)}}(0,o.Cg)([n.sH],h.prototype,"showFewerButtonSelected",void 0)}}]);