// © Microsoft Corporation. All rights reserved.
import { IsomorphicStorage } from "@msnews/isomorphic-util";
import { ColumnArrangement, fastBreakpointManager } from "@msnews/experiences-base";
import { UrlUtility, appEnvironment, headData } from "@msnews/core";
/**
 * The Midlevel Telemetry class
 */
export class MidlevelTelemetry {
    static get viewType() { return IsomorphicStorage.get(this.viewTypeKey); }
    static set viewType(value) { IsomorphicStorage.set(this.viewTypeKey, value); }
    /**
     * The track callbacks
     *
     * @static
     * @type {TrackCallbacks}
     * @memberof MidlevelTelemetry
     */
    static trackCallbacks() {
        switch (fastBreakpointManager().currentColumnArrangement) {
            case ColumnArrangement.c1:
            case ColumnArrangement.c2:
                MidlevelTelemetry.viewType = "size2column";
                break;
            case ColumnArrangement.c3:
                MidlevelTelemetry.viewType = "size3column";
                break;
            case ColumnArrangement.c4:
                MidlevelTelemetry.viewType = "size4column";
                break;
            default:
                // leave MidlevelTelemetry.viewType unchanged
                break;
        }
        return MidlevelTelemetry.viewType;
    }
    /**
     * Gets the track properties
     *
     * @param window
     * @param locationHref
     * @returns The track properties
     */
    static getTelemetryProperties(window, locationHref) {
        // TODO: replace getQueryParameterByName with more efficient method if multiple query param
        // inspection need to be done
        const enableTrack = !(UrlUtility.getQueryParameterByName("enableTrack", locationHref) === "false");
        const ocid = UrlUtility.getQueryParameterByName("ocid", locationHref) || "hpmsn";
        const activityId = appEnvironment.ActivityIdLowerCaseNoHypens;
        const autoRefresh = "0";
        let isMobile = "0";
        let isStaticPage = false;
        if (headData && headData.ClientSettings) {
            const clientSettings = headData.ClientSettings;
            if (clientSettings.static_page === "true") {
                isStaticPage = true;
            }
            isMobile = ((clientSettings.browser && clientSettings.browser.ismobile === "true") || clientSettings.deviceFormFactor === "phone" /* DeviceFormFactorType.Phone */) ? "1" : "0";
        }
        const flightId = (appEnvironment.CurrentRequestTargetScope && appEnvironment.CurrentRequestTargetScope.pageExperiments) ? appEnvironment.CurrentRequestTargetScope.pageExperiments.join(",") : undefined;
        const trackProperties = {
            // Properties from the current environment
            activityId: activityId,
            autoRefresh: autoRefresh,
            canvas: "Browser",
            channel: "homepage", // verify
            dDgk: "unknown",
            dImd: isMobile,
            domainId: "340",
            enable: enableTrack,
            environment: appEnvironment.Environment,
            flightid: flightId,
            isStaticPage: isStaticPage,
            localeCode: appEnvironment.CurrentMarket,
            pageName: "startpage",
            pageProduct: "prime",
            pageType: "hp",
            pageTitle: window.document.title,
            pageUrl: window.document.URL,
            serverImpressionGuid: activityId,
            tmpl: "",
            // TODO: Add AFD logs once PCS send back the data.
            // Following the spec: https://microsoft.sharepoint.com/:w:/t/DataandInsights/EawMe8a0XKxCkuBO19CGARIByn5roly2qWG76ZElsQq5VQ?e=4PQyuM
            afd: ""
        };
        if (ocid) {
            trackProperties.msnocid = ocid;
        }
        return trackProperties;
    }
    /**
     * Creates telemetry contract for page
     * @param {any} telemetryProperties
     * @param (boolean) isStaticPage
     * @param (boolean) isMobile
     * @param (string) locationHref - The window.location.href passed from requestContext
     */
    static getPageTelemetryContract(telemetryProperties, isStaticPage, isMobile, locationHref) {
        const pageTelemetryContract = {
            page: {
                appType: appEnvironment.AppType,
                name: telemetryProperties.pageName,
                config: telemetryProperties.pageConfiguration,
                product: telemetryProperties.pageProduct,
                type: telemetryProperties.pageType,
                isJSEnabled: true,
                isAutoRefresh: false,
                isStatic: isStaticPage,
                url: locationHref,
                canvas: telemetryProperties.canvas,
                ocid: telemetryProperties.msnocid || telemetryProperties.storeocid,
                isAdEnabled: false,
                content: {
                    vertical: "homepage",
                    category: telemetryProperties.department,
                    title: window.document.title,
                    id: "",
                    domainId: telemetryProperties.domainId
                },
                viewType: this.trackCallbacks()
            },
            flight: {
                id: appEnvironment.CurrentRequestTargetScope &&
                    appEnvironment.CurrentRequestTargetScope.pageExperiments &&
                    appEnvironment.CurrentRequestTargetScope.pageExperiments.join(",")
            },
            locale: {
                mkt: appEnvironment.CurrentMarket,
                lang: appEnvironment.MarketRequestInputLanguage,
                region: appEnvironment.MarketRequestInputRegion,
                geo_cc: appEnvironment.MarketRequestInputGeoCountry,
                mktReason: appEnvironment.MarketDetectionType
            },
            browser: {
                isMobile
            }
        };
        return pageTelemetryContract;
    }
}
/**
 * The view type
 */
MidlevelTelemetry.viewTypeKey = Symbol("viewType");
//# sourceMappingURL=MidlevelTelemetry.js.map