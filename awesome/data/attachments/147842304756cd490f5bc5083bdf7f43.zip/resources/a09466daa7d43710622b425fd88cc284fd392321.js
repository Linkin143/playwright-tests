"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-quote-vertical-quote-list"],{4968(t,e,i){i.d(e,{f(){return n}});var o=i(64187),s=i(74849),r=i(42792),a=i(99657),l=i(36452);const n=s.A.partial`position: relative; z-index: ${a.D};`;s.A`
    ${r.e}
    ${r.nH}

    ${(0,o.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${n}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(r.kc)},7525(t,e,i){i.r(e),i.d(e,{QuoteItem(){return N}});var o=i(56911),s=i(92707),r=i(31525),a=i(60815);let l=class extends s.z{get isNotfVisible(){return Boolean(this.viewModel.notification)}get isRotationVisible(){return Boolean(this.viewModel.notification)&&Boolean(this.showNotificationText)}get chartCntrStyle(){var t,e;return`width: ${null===(t=this.viewModel.chartData)||void 0===t?void 0:t.chartWidth}px; height: ${null===(e=this.viewModel.chartData)||void 0===e?void 0:e.chartHeight}px`}get chartData(){return this.viewModel.chartData}contentTemplate(t,e,i){return this.isSeeMore?t:"_1x_1y"===this.viewModel.cardSize?e:i}onChartDictChange(t){var e;const i=null===(e=this.viewModel)||void 0===e?void 0:e.chartData;var o,s;i&&t&&(i.chartSeries=null==t||null===(o=t[this.viewModel.id])||void 0===o||null===(o=o.chartData)||void 0===o?void 0:o.series,i.chartBaseline=null==t||null===(s=t[this.viewModel.id])||void 0===s?void 0:s.pricePreviousClose,this.viewModel={...this.viewModel,chartData:i})}onQuoteItemDictChange(t){var e,i,o;const s=null===(e=this.viewModel)||void 0===e?void 0:e.id,r=null==t||null===(i=t[s])||void 0===i?void 0:i.price,a=null==t||null===(o=t[s])||void 0===o?void 0:o.changePcnt;r&&a&&(this.viewModel={...this.viewModel,price:r,pricePctChange:a})}onShowNotificationTextChange(t){this.showNotificationText=t}stockNames(t){const{showStockNameOnFirstLine:e,shortName:i,displayName:o,symbol:s}=this.viewModel;return e?[i||o||"",s||""][t]:[s||"",i||o||""][t]}};(0,o.Cg)([a.sH],l.prototype,"showNotificationText",void 0),l=(0,o.Cg)([r.x],l);var n=i(92011),d=i(4968),h=i(12640),c=i(74849),u=i(48751),g=i(4283);const p=c.A` .card .disp-name{color:${u.l}}.see-more-text{color:#5FAFFF}`,v=c.A` .quote-item{display:grid;grid-gap:8px;grid-template-columns:var(--quote-grid-template-columns);column-gap:8px;background:var(--quote-background);border-radius:4px;padding:5px 10px;box-sizing:border-box;text-decoration:none;color:${u.l};
        outline-offset: -2px;
        ${d.f}}.quote-item.large{padding:10px 10px}.quote-item.card{height:66px;width:116px;border-radius:4px;grid-gap:6px;padding:6px}.quote-item.card .notf{max-width:104px;display:flex}.quote-item.card .notf-text{margin:0 4px}.top{height:12px;width:104px;display:flex;justify-content:space-between;align-items:center}.top-left{display:inline-block;width:calc(100% - 20px);font-size:10px}.icn{display:flex;align-items:center}.icn img{width:24px;height:24px}.middle{height:14px;display:flex;justify-content:space-between;align-items:center}.middle-right .prct-change{font-size:10px}.quote-item:hover{background:var(--quote-hover-background)}.quote-item:active{background:var(--quote-active-background)}.right{text-align:end}.notf-icon{width:12px;height:12px}.symb,.prct-change{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-weight:600}.symb{display:flex;align-items:center;column-gap:4px;white-space:nowrap}.symb-text{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.disp-name,.price,.notf-text{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.notf{font-weight:600}.add-button{display:flex;align-items:center}.price{font-weight:600}.disp-name{color:${u.l}}.card .disp-name{font-weight:600}.see-more-container{height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center}.see-more-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:${g.OS};
    }
`.withBehaviors(new h.N(null,p));var f=i(96950),m=i(69259),x=i(58792);const b=f.qy`<div class="notf-text" style="color: ${t=>t.viewModel.notification.accentColor}">${t=>t.viewModel.notification.shortHeadline}</div>`,w=f.qy`<img class="notf-icon" src="${t=>t.viewModel.notification.iconUrl}" alt=${t=>t.viewModel.displayName} />`,$=f.qy`<div class="notf">${w} ${b}</div>`,y=f.qy`<money-info-stock-chart :width=${t=>{var e;return null===(e=t.chartData)||void 0===e?void 0:e.chartWidth}} :height=${t=>{var e;return null===(e=t.chartData)||void 0===e?void 0:e.chartHeight}} :prices=${t=>{var e;return null===(e=t.chartData)||void 0===e?void 0:e.chartSeries}} :baselinePrice=${t=>{var e;return null===(e=t.chartData)||void 0===e?void 0:e.chartBaseline}} :lineColor=${t=>{var e;return null===(e=t.chartData)||void 0===e?void 0:e.chartFillColor}} :baselineColor=${t=>{var e;return null===(e=t.chartData)||void 0===e?void 0:e.baselineFillColor}} :pricesMaxCount=${()=>40}></money-info-stock-chart>`,k=f.qy`<div style="${t=>t.chartCntrStyle}">${(0,m.z)(t=>{var e;return(null===(e=t.viewModel.chartData)||void 0===e||null===(e=e.chartSeries)||void 0===e?void 0:e.length)>0},y)}</div>`,C=f.qy` ${(0,m.z)(t=>t.viewModel.followButton,f.qy`<div class="add-button"><follow-button :viewModel="${t=>{var e;return null===(e=t.viewModel.followButton)||void 0===e?void 0:e.viewModel}}"></follow-button></div>`)}
`,z=t=>f.qy`<div class="disp-name">${t}</div>`,M=f.qy`<a class="quote-item card" href="${t=>t.viewModel.quoteUrl}" title="${t=>t.viewModel.tooltipText}" target="_blank" data-t="${t=>t.viewModel.telemetryTag}"><div class="top"><div class="top-left">${t=>z(t.stockNames(0))}</div>${C}</div><div class="middle"><div class="middle-left"><div class="price">${t=>t.viewModel.price}</div></div><div class="middle-right"><div class="prct-change" style="color: ${t=>t.viewModel.accentColor}">${t=>t.viewModel.pricePctChange}</div></div></div><div class="bottom">${t=>t.isRotationVisible?$:k}</div></a>`,q=f.qy`<div class="icn"><img src="${t=>t.viewModel.iconUrl}" alt="${t=>t.viewModel.displayName}" loading=lazy /></div>`,T=f.qy`<a class="quote-item ${t=>"_1x_3y"===t.viewModel.cardSize?"large":""}" style="${t=>t.viewModel.gridTemplateColumns+(t=>{const e=(t-40)/2+5;return` height:${t}px; padding-top: ${e}px; padding-bottom: ${e}px; `})(t.viewModel.quoteHeight)}" href="${t=>t.viewModel.quoteUrl}" title="${t=>t.viewModel.tooltipText}" target="_blank" data-t="${t=>t.viewModel.telemetryTag}">${(0,m.z)(t=>t.viewModel.isIconVisible&&t.viewModel.iconUrl,q)}<div class="left"><div class="symb"><div class="symb-text">${t=>t.stockNames(0)}</div>${(0,m.z)(t=>t.isNotfVisible,w)}</div><div class="left-bottom">${(0,m.z)(t=>t.isNotfVisible,b)} ${(0,m.z)(t=>!t.isNotfVisible,f.qy`${t=>z(t.stockNames(1))}`)}</div></div>${(0,m.z)(t=>t.viewModel.isChartDataReady,f.qy`<div class="chart">${k}</div>`)}<div class="right"><div class="prct-change" style="color: ${t=>t.viewModel.accentColor}">&lrm;${t=>t.viewModel.pricePctChange}&lrm;</div><div class="price">${t=>t.viewModel.price}</div></div>${C}</a>`,F=f.qy` ${t=>t.contentTemplate(S,M,T)}
`,S=f.qy`<a class="quote-item card" href="${t=>t.viewModel.seeMoreLink}" title="${t=>t.viewModel.seeMoreText}" target="_blank" data-t="${t=>t.viewModel.telemetryTag}"><div class="see-more-container"><div aria-hidden="true" role="presentation"><img src="${(0,x.rA)().StaticsUrl}/latest/money/icons/SeeMoreArrow.svg" alt=${t=>t.viewModel.seeMoreText}></div><div class="see-more-text">${t=>t.viewModel.seeMoreText}</div></div></a>`,_=f.qy` ${(0,m.z)(t=>t&&null!=t.viewModel,F)}
`;let N=class extends l{};N=(0,o.Cg)([(0,n.E)({name:"quote-item",template:_,styles:v,shadowOptions:{delegatesFocus:!0}})],N)},21054(t,e,i){i.d(e,{j(){return s}});var o=i(27208);class s extends o.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}followClickHandler(t,e,i){this.transformerProvider.followClickHandler&&this.transformerProvider.followClickHandler(t,!0,e,i)}getViewModel(t){return{followClickHandler:()=>this.followClickHandler(t.itemId,t.itemName,t.itemUrl),isFollowed:t.isFollowed,itemId:t.itemId,size:t.size,telemetryTag:t.telemetryTag,followButtonTooltip:t.followButtonTooltip}}}},28211(t,e,i){i.r(e),i.d(e,{FollowButton(){return m}});var o=i(56911),s=i(95296),r=i(60815);class a extends s.m{constructor(){super(...arguments),this.justFollowed=!1}get isFollowed(){return this.viewModel.isFollowed||this.justFollowed}handleClick(){this.viewModel.followClickHandler&&(this.viewModel.followClickHandler(),this.justFollowed=!0)}}(0,o.Cg)([r.sH],a.prototype,"justFollowed",void 0);var l=i(92011),n=i(12640),d=i(74849);const h=d.A` :host{--add-border:#666666;--plus-sign:#FFFFFF;--completed:#3B4EC3}`,c=d.A` :host{--add-border:#D1D1D1;--plus-sign:#242424;--completed:#405CE8}.follow-button{height:16px;width:16px;display:flex;align-items:center;justify-content:center;padding:0;border:none;background:transparent;cursor:pointer}.follow-button.m{height:16px;width:16px}.follow-button.sm{height:12px;width:12px}.follow-button.m svg{min-width:20px;min-height:20px}.follow-button.m svg path{min-width:20px;min-height:20px}.follow-button.sm svg{min-width:16px;min-height:16px}.follow-button.sm svg path{min-width:12px;min-height:12px}.follow-button svg path:first-child{fill:var(--plus-sign)}.follow-button svg path:nth-child(2){fill:var(--add-border)}.follow-button.followed svg path:first-child{fill:var(--completed)}`.withBehaviors(new n.N(null,h));var u=i(75624),g=i(96950);const p=g.qy`${g.qy.partial('<svg width="20" height="20" viewBox="0 0 20 20" type="circle-completed"><path d="M10 1.67a8.33 8.33 0 1 1 0 16.66 8.33 8.33 0 0 1 0-16.66Zm2.68 5.8L8.96 11.2 7.32 9.56a.62.62 0 1 0-.89.88l2.09 2.09c.24.24.64.24.88 0l4.17-4.17a.62.62 0 1 0-.89-.89Z"/></svg>')}`,v=g.qy`${g.qy.partial(u.A)}`,f=g.qy`<button class="follow-button ${t=>t.isFollowed?"followed":""} ${t=>t.viewModel.size}" data-t="${t=>t.viewModel.telemetryTag}" @click=${t=>t.handleClick()} title="${t=>t.viewModel.followButtonTooltip}">${t=>t.isFollowed?p:v}</button>`;let m=class extends a{};m=(0,o.Cg)([(0,l.E)({name:"follow-button",template:f,styles:c,shadowOptions:{delegatesFocus:!0}})],m)},37790(t,e,i){i.r(e),i.d(e,{FollowButtonTransformer(){return o.j},MoneyInfoStockChartTransformer(){return s.M},QuoteItemTransformer(){return r.Z},VerticalQuoteListTransformer(){return d}});var o=i(21054),s=i(89213),r=i(81570),a=i(27208),l=i(86449),n=i(96950);class d extends a.IB{constructor(){super(...arguments),this.maxChangeStringLength=0,this.maxValueStringLength=0,this.quoteHeight=40,this.showWatchlistButton=!1,this.isIconVisible=!1,this.isSpotlightHeroCard=!1}async transform(t){this.maxChangeStringLength=this.transformerProvider.config.maxChangeStringLength,this.maxValueStringLength=this.transformerProvider.config.maxValueStringLength,this.fullWatchlistQuoteIds=new Set(t.fullWatchlistQuoteIds),this.notifications=t.quoteNotificationDetails,this.showWatchlistButton=t.showWatchlistButton,this.isSpotlightHeroCard=(0,l.Fm)(t.experienceName);const e=await this.getCurrentViewModel(t);return{viewTemplate:n.qy`
                <vertical-quote-list
                    :viewModel="${e}"
                ></vertical-quote-list>`}}getPlaceholdersCount(t,e){const i=this.getMaxQuoteItemCount(t);return Math.max(i-e-1,0)}async getCurrentViewModel(t){const e=await this.getQuotes(t);return{cardSize:t.cardSize,experienceName:t.experienceName,chartItemDict:t.chartItemDict,listWidth:(0,l.pM)(this.isSpotlightHeroCard),listHeight:(0,l.cf)(t.cardSize,this.isSpotlightHeroCard),placeHoldersCount:this.getPlaceholdersCount(t,e.length),quoteHeight:this.quoteHeight,quotes:e,showWatchlistButton:t.showWatchlistButton,tabName:t.tabName,telemetryTag:"",watchlistIds:t.watchlistIds,seeMoreText:this.transformerProvider.strings.seeMore,seeMoreLink:t.seeMoreLink,seeMoreTelemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{name:a.CD.seeMoreClick,signature:t.signature,headline:this.transformerProvider.strings.seeMore}),flipperHandler:this.transformerProvider.paginationFlipperClickHandler}}getMaxQuoteItemCount(t){switch(t.cardSize){case"_1x_3y":case"large":return this.transformerProvider.config.maxNumberOfQuotesLarge;case"_1x_1y":case"small":return this.transformerProvider.config.maxNumberOfQuotesSmall;default:return this.transformerProvider.config.maxNumberOfQuotesMedium}}async getQuotes(t){let e=t.quoteDetails||[];const i=this.getMaxQuoteItemCount(t);i<e.length&&(e=e.slice(0,i)),this.quoteHeight=(0,l.Wl)(t.cardSize,e.length<i),e.forEach(t=>this.updateMaxStringLengths(t)),this.isIconVisible=(0,l.qE)(t.tabName);const o=this.getGridTemplateColumns(),s=e.map(e=>{var i,s,r;const n=(0,l.EL)(e);if(!n)return;const d=null===(i=this.notifications)||void 0===i?void 0:i[n],h=(null===(s=this.fullWatchlistQuoteIds)||void 0===s?void 0:s.has(n))??!1,c=(0,l.jX)(e.displayName||"",e.symbol,h,this.transformerProvider.strings),u=null===(r=t.chartItemDict)||void 0===r?void 0:r[n],g={experienceName:t.experienceName,isFollowed:h,tooltipText:c,tabName:t.tabName,quoteNotifications:d,quote:e,isIconVisible:this.isIconVisible,showWatchlistButton:this.showWatchlistButton,quoteHeight:this.quoteHeight,gridTemplateColumns:o,chartData:u,watchlistIds:t.watchlistIds,cardSize:t.cardSize,signature:t.signature,parentTelemetryObject:t.telemetryObject};return this.transformerProvider.generateView(g,a.Ai.QuoteItem)});return(await Promise.all(s)).filter(l.z2)}getGridTemplateColumns(){const t=this.isSpotlightHeroCard?this.transformerProvider.config.spotlightHeroCardWidth:this.transformerProvider.config.sdCardWidth;let e=this.showWatchlistButton?4:3;e=this.isIconVisible?e+1:e;const i=this.isIconVisible?24:0,o=t-26-i-10-12-8*(e-1),s=this.showWatchlistButton?20:0,r=32,a=Math.max(8*this.maxChangeStringLength,6*this.maxValueStringLength);return`--quote-grid-template-columns: ${[i,o-r-a-s,r,a,s].filter(t=>t>0).map(t=>`${t}px`).join(" ")};`}updateMaxStringLengths(t){t.changePcnt&&t.changePcnt.length>this.maxChangeStringLength&&(this.maxChangeStringLength=t.changePcnt.length),t.price&&t.price.length>this.maxValueStringLength&&(this.maxValueStringLength=t.price.length)}}Promise.resolve().then(i.bind(i,55868)),Promise.resolve().then(i.bind(i,7525)),Promise.resolve().then(i.bind(i,67538)),Promise.resolve().then(i.bind(i,28211))},42792(t,e,i){i.d(e,{R7(){return v},e(){return g},kc(){return p},nH(){return u}});var o=i(57416),s=i(55153),r=i(95239),a=i(26920),l=i(48751),n=i(64187),d=i(22131),h=i(74849),c=i(50882);const u=h.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,g=h.A`
    ${(0,n.V)("flex")} :host {
        background: ${r.p};
        outline: calc(${a.XA} * 1px) solid ${s.cu};
        border-radius: calc((${o.JU} - ${a.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${l.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${s.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${s.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${a.XA} * 1px) ${s.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${s.QG} * 1px);
        height: calc(${s.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${s.QG} * 1px);
        height: calc((${s.l8} * 2px) + (${s.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${s.QG} * 2px) + (${s.Sn} * 1px));
        height: calc((${s.l8} * 2px) + (${s.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${s.QG} * 2px) + (${s.Sn} * 1px));
        height: calc(${s.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,p=(0,d.mr)(h.A`
            :host {
                background: ${c.A.Canvas};
                color: ${c.A.CanvasText};
            }
        `),v=h.A`
    ${g}
    ${u}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(p)},55868(t,e,i){i.r(e),i.d(e,{VerticalQuoteList(){return m}});var o=i(56911),s=i(27208),r=i(60815),a=i(92707),l=i(94043);class n extends a.z{constructor(){super(...arguments),this.currentMargin=0,this.onFocusIn=t=>{var e;const i=Array.from(this.verticalQuoteList.querySelectorAll("quote-item")).findIndex(t=>{var e,i,o,s,r,a;if(!t.shadowRoot)return!1;if(null!==(e=t.shadowRoot)&&void 0!==e&&null!==(i=e.querySelector)&&void 0!==i&&i.call(e,".quote-item:focus-visible"))return!0;const l=null===(o=t.shadowRoot)||void 0===o||null===(s=o.querySelector)||void 0===s?void 0:s.call(o,".quote-item follow-button");return!(null==l||null===(r=l.shadowRoot)||void 0===r||null===(a=r.querySelector)||void 0===a||!a.call(r,".follow-button:focus-visible"))});if(-1===i)return;const o=Math.floor(i/2)+1,r=null===(e=this.getState())||void 0===e?void 0:e.get(s.Xe.CurrentPageIndex);var a,l;o!==r&&(null===(a=(l=this.viewModel).flipperHandler)||void 0===a||a.call(l,o>r,t))}}disconnected(){this.currentMargin=0,super.disconnected(),(0,l.S)()&&this.verticalQuoteList.removeEventListener("focusin",this.onFocusIn)}connected(){super.connected(),"_1x_1y"===this.viewModel.cardSize&&(0,l.S)()&&this.verticalQuoteList.addEventListener("focusin",this.onFocusIn)}onCurrentPageIndexChange(t){const e=124*(this.viewModel.quotes.length+1)-8-268,i=248*(t-1);this.currentMargin=Math.min(i,e)}initHandlers(){super.initHandlers(),this.onCurrentPageIndexChangeScoped=this.onCurrentPageIndexChange.bind(this)}addSubscriptions(){super.addSubscriptions();const t=this.getState();t&&t.subscribe(s.Xe.CurrentPageIndex,this.onCurrentPageIndexChangeScoped,{signal:this.subscriptionController.signal})}get listStyles(){let t=`width: ${this.viewModel.listWidth}; height: ${this.viewModel.listHeight};`;return"_1x_1y"===this.viewModel.cardSize&&(t+=`inset-inline-end: ${this.currentMargin}px;`),t}}(0,o.Cg)([r.sH],n.prototype,"currentMargin",void 0),(0,o.Cg)([r.Jg],n.prototype,"listStyles",null);var d=i(92011);const h=i(74849).A` .wrap{position:relative}.vertical-quote-list{display:flex;flex-direction:column;justify-content:space-between;transition:left 700ms,right 700ms}.vertical-quote-list.small{display:flex;flex-direction:row;flex-wrap:nowrap;gap:8px;position:absolute}`;var c=i(96950),u=i(60402),g=i(39957),p=i(69259);const v=c.qy`<div class="wrap"><div class="vertical-quote-list ${t=>{var e;return"_1x_1y"===(null===(e=t.viewModel)||void 0===e?void 0:e.cardSize)?"small":""}}" style="${t=>t.listStyles}" ${(0,u.K)("verticalQuoteList")}>${(0,g.ux)(t=>t.viewModel.quotes,c.qy`<quote-item :viewModel="${t=>t.viewModel}"></quote-item>`)} ${(0,p.z)(t=>{var e;return"_1x_1y"===(null===(e=t.viewModel)||void 0===e?void 0:e.cardSize)},c.qy`<quote-item :viewModel="${t=>({isSeeMore:!0,seeMoreText:t.viewModel.seeMoreText,seeMoreLink:t.viewModel.seeMoreLink,telemetryTag:t.viewModel.seeMoreTelemetryTag})}" :isSeeMore="${()=>!0}"></quote-item>`)} ${(0,g.ux)(t=>new Array(t.viewModel.placeHoldersCount),c.qy`<div class="placeholder" style="height: ${(t,e)=>e.parent.viewModel.quoteHeight}px"></div>`)}</div></div>`,f=c.qy` ${(0,p.z)(t=>t&&t.viewModel,v)}
`;let m=class extends n{};m=(0,o.Cg)([(0,d.E)({name:"vertical-quote-list",template:f,styles:h,shadowOptions:{delegatesFocus:!0}})],m)},67538(t,e,i){i.r(e),i.d(e,{MoneyInfoStockChart(){return v}});var o=i(56911),s=i(92011),r=i(60815),a=i(22341),l=i(93552),n=i(31525),d=i(26220);let h=class extends s.L{connected(){try{this.initializeChart()}catch(t){(0,a.vV)(l.npu,t?t.message:"Unknown error")}}initializeChart(){if(this.canvasEl){const t=(0,d.mZ)();this.canvasEl.width=this.width*t,this.canvasEl.height=this.height*t,this.ctx=this.canvasEl.getContext("2d"),this.ctx.scale(t,t),this.canvasEl.style.width=`${this.width}px`,this.canvasEl.style.height=`${this.height}px`,this.drawChart()}}shouldShowBaseline(){if("number"!=typeof this.baselinePrice)return!1;const t=Math.min(...this.prices),e=Math.max(...this.prices);if(t===e)return!0;const i=t>this.baselinePrice?t-this.baselinePrice:this.baselinePrice-e;return i/(i+(e-t))<.5}drawChart(){if(!this.prices)return;const t=this.prices.slice();this.shouldShowBaseline()&&t.push(this.baselinePrice);let e=Math.min(...t),i=Math.max(...t);e===i&&(e-=1,i+=1);const o=Math.round(1e4*(i-e))/1e4,s=Math.max(this.pricesMaxCount||0,this.prices.length),r=this.prices.length/s,a=this.width*(this.isFullWidth?1:r);this.ctx.beginPath(),this.ctx.moveTo(0,this.height-(this.prices[0]-e)/o*this.height);for(let t=1;t<this.prices.length;t++){const i=t/(this.prices.length-1)*a,s=this.height-(this.prices[t]-e)/o*this.height;this.ctx.lineTo(i,s)}this.ctx.lineWidth=1.2,this.ctx.strokeStyle=this.lineColor,this.ctx.stroke(),this.ctx.lineTo(this.width,this.height),this.ctx.lineTo(0,this.height),this.ctx.closePath(),this.ctx.save(),this.ctx.clip();const l=this.ctx.createLinearGradient(0,0,0,this.height);l.addColorStop(0,`${this.lineColor}4D`),l.addColorStop(1,`${this.lineColor}00`),this.ctx.fillStyle=l,this.ctx.fillRect(0,0,a,this.height),this.ctx.restore(),this.ctx.beginPath(),this.ctx.moveTo(0,this.height-(this.baselinePrice-e)/o*this.height),this.ctx.lineTo(this.width,this.height-(this.baselinePrice-e)/o*this.height),this.ctx.strokeStyle=this.baselineColor,this.ctx.setLineDash(this.lineDash||[5,5]),this.ctx.stroke()}};(0,o.Cg)([r.sH],h.prototype,"prices",void 0),(0,o.Cg)([r.sH],h.prototype,"baselinePrice",void 0),(0,o.Cg)([r.sH],h.prototype,"width",void 0),(0,o.Cg)([r.sH],h.prototype,"height",void 0),(0,o.Cg)([r.sH],h.prototype,"lineColor",void 0),(0,o.Cg)([r.sH],h.prototype,"baselineColor",void 0),(0,o.Cg)([r.sH],h.prototype,"lineDash",void 0),h=(0,o.Cg)([n.x],h);const c=i(74849).A` 
`;var u=i(96950),g=i(60402);const p=u.qy`<template><canvas ${(0,g.K)("canvasEl")}></canvas></template>`;let v=class extends h{};v=(0,o.Cg)([(0,s.E)({name:"money-info-stock-chart",template:p,styles:c,shadowOptions:{delegatesFocus:!0}})],v)},75624(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" type="circle-add"><path d="M6 10c0-.28.22-.5.5-.5h3v-3a.5.5 0 0 1 1 0v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3A.5.5 0 0 1 6 10Z"/><path d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm0-1a7 7 0 1 1 0-14 7 7 0 0 1 0 14Z"/></svg>'},81570(t,e,i){i.d(e,{Z(){return l}});var o=i(27208),s=i(49150),r=i(86449),a=i(30236);class l extends o.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}get swapGainLossColor(){return this.transformerProvider.config.swapGainLossColor||!1}getNotificationData(t){var e;if(null!==(e=t.quoteNotifications)&&void 0!==e&&e.length){const e=t.quoteNotifications[0],i=e.notificationType;return[o.Ex.EarningRelease,o.Ex.PriceDrop,o.Ex.PriceSpike,o.Ex.PriceMovement,o.Ex.WatchlistSummary,o.Ex.MarketBrief,o.Ex.TechnicalIndicator,o.Ex.Sentiment,o.Ex.InstitutionalHolding].includes(i)?e:void 0}{const{pricePctNotfThresholdMarket:e,pricePctNotfBaseline:i,disableNotificationForVp:o}=this.transformerProvider.config;if((0,r.Uj)(t.quote,e,i,o))return(0,r.nW)(t.quote,[],this.transformerProvider.strings)}}getNotificationsInfo(t){const e=this.getNotificationData(t);return e?{iconUrl:this.getNotfIconUrl(t,e),shortHeadline:e.shortHeadline,accentColor:(0,r.bQ)(e,t.quote,(0,r.jJ)(),this.swapGainLossColor)}:null}getAccentColor(t){return(0,r.BK)((0,r.jJ)(),t.quote.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor)}async getFollowButton(t){if(t.showWatchlistButton){const e=(0,a.Xe)(this.transformerProvider.config.urls,o.Rf.Watchlist,t.quote.id),i={isFollowed:t.isFollowed,itemId:t.quote.id,itemName:t.quote.displayName||"",itemUrl:e,telemetryTag:this.transformerProvider.telemetryBuilder.createAddClickTelemetryTag(t.parentTelemetryObject,{name:o.CD.quoteAddedToWatchlist,signature:t.signature,headline:t.quote.id}),size:t.cardSize===s.uE._1x_1y?"sm":"m",followButtonTooltip:this.transformerProvider.strings.watchlistTooltipText};return await this.transformerProvider.generateView(i,o.Ai.FollowButton)}}getIconUrl(t){const{cryptos:e,deprecatedToNewCryptos:i}=this.transformerProvider.config;return t.quote.iconUrl?t.quote.iconUrl:t.quote.icon?t.quote.icon:t.tabName===o.Rf.Crypto?(0,r.ue)(e,i,t.quote.id):t.tabName===o.Rf.Currencies?(0,r.A0)(t.quote.currency||""):""}getNotfIconUrl(t,e){var i,o;return(0,a.kX)(this.transformerProvider.config.urls,(null===(i=t.quote)||void 0===i?void 0:i.changePcntNumber)||0,null==e?void 0:e.notificationType,this.transformerProvider.config.swapGainLossColor,null==e||null===(o=e.notification)||void 0===o?void 0:o.signal)}async getViewModel(t){(0,r.ih)(t.quote,t.tabName);const e=this.getNotificationsInfo(t),i=await this.getFollowButton(t),s=(0,a.Xe)(this.transformerProvider.config.urls,t.tabName||o.Rf.Watchlist,t.quote.id,this.getNotificationData(t),!0),l={quote:t.quote,chartData:t.chartData,cardSize:t.cardSize},n=o.Ai.MoneyInfoStockChart,d=await this.transformerProvider.generateView(l,n);return{accentColor:this.getAccentColor(t),experienceName:t.experienceName,cardSize:t.cardSize,chartData:d.viewModel,displayName:t.quote.displayName||"",followButton:i,gridTemplateColumns:t.gridTemplateColumns||"",hoverTelemetryTag:this.transformerProvider.telemetryBuilder.createHoverShowTelemetryTag(t.parentTelemetryObject,{name:o.CD.quoteItemClick,signature:t.signature,headline:t.quote.symbol,id:t.quote.id}),iconUrl:this.getIconUrl(t),id:t.quote.id,isChartDataReady:!0,isIconVisible:t.isIconVisible,notification:e,paddingVertical:(t.quoteHeight-40)/2,price:t.quote.price,pricePctChange:t.quote.changePcnt||"",quoteHeight:t.quoteHeight,quoteUrl:s,seeMoreText:this.transformerProvider.strings.seeMore,showChart:this.transformerProvider.config.enableInlineStockChart,symbol:t.quote.symbol,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.parentTelemetryObject,{name:o.CD.quoteItemClick,signature:t.signature,headline:t.quote.symbol,id:t.quote.id}),tooltipText:t.tooltipText,shortName:t.quote.shortName||"",showStockNameOnFirstLine:t.quote.securityType.toLowerCase()!==o.tr.Currency.toLowerCase()}}}},89213(t,e,i){i.d(e,{M(){return a}});var o=i(27208),s=i(49150),r=i(86449);class a extends o.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getChartFillColor(t){return t?(0,r.BK)((0,r.jJ)(),t.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor):""}chartPricePreviousClose(t){return t?t.pricePreviousClose:void 0}getChartWidth(t){return t.width?t.width:t.cardSize===s.uE._1x_1y?104:32}getChartHeight(t){return t.height?t.height:t.cardSize===s.uE._1x_1y?18:28}async getViewModel(t){var e,i;return{chartId:t.quote.id,chartWidth:this.getChartWidth(t),chartHeight:this.getChartHeight(t),chartFillColor:this.getChartFillColor(t.quote),baselineFillColor:this.getChartFillColor(t.quote),isFullWidth:t.isFullWidth,lineDash:t.lineDash,chartBaseline:this.chartPricePreviousClose(null==t?void 0:t.chartData),chartBaselineLoc:null==t||null===(e=t.chartData)||void 0===e?void 0:e.pricePreviousCloseLoc,chartSeries:null==t||null===(i=t.chartData)||void 0===i||null===(i=i.chartData)||void 0===i?void 0:i.series,cardSize:t.cardSize,telemetryTag:""}}}},92707(t,e,i){i.d(e,{z(){return n}});var o=i(56911),s=i(27208),r=i(60815),a=i(92011),l=i(31525);let n=class extends a.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return s.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const t=this.getState();t&&(t.subscribe(s.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(s.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(t){}onChartDictChange(t){}onShowNotificationTextChange(t){}onQuoteItemDictChange(t){}onCardWidthChanged(t){}};(0,o.Cg)([r.sH],n.prototype,"viewModel",void 0),n=(0,o.Cg)([l.x],n)},95296(t,e,i){i.d(e,{m(){return a}});var o=i(56911),s=i(60815),r=i(92011);class a extends r.L{}(0,o.Cg)([s.sH],a.prototype,"viewModel",void 0)},99657(t,e,i){i.d(e,{D(){return a},I(){return r}});var o=i(45755);const{create:s}=o.G,r=s("sloppy-click-z-index",1),a=s("click-z-index",1)}}]);