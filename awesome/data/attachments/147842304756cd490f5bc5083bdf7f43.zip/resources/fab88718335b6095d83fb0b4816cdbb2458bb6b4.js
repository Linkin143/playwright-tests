/*! For license information please see microsoft.4abc9b9a594fae03a52c.js.LICENSE.txt */
(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["microsoft"],{356(t,e,n){"use strict";n.d(e,{l(){return o}});var r=n(45755),i=n(97004);const{create:s}=r.G,o=s("base-layer-luminance",i.y.LightMode)},416(t,e,n){"use strict";n.d(e,{Y(){return a}});var r=n(96293),i=n(29194),s=n(10108);class o extends s.u{constructor(t){super(t),this.observerProperty=Symbol(),this.handleEvent=(t,e)=>{const n=e.target;this.updateTarget(this.getSource(n),this.computeNodes(n))},t.childList=!0}observe(t){let e=t[this.observerProperty];e||(e=new MutationObserver(this.handleEvent),e.toJSON=r.lQ,t[this.observerProperty]=e),e.target=t,e.observe(t,this.options)}disconnect(t){const e=t[this.observerProperty];e.target=null,e.disconnect()}getNodes(t){return"selector"in this.options?Array.from(t.querySelectorAll(this.options.selector)):Array.from(t.childNodes)}}function a(t){return(0,r.Kg)(t)&&(t={property:t}),new o(t)}i.dg.define(o)},2298(t,e,n){"use strict";function r(...t){return t.every(t=>t instanceof HTMLElement)}function i(t,e){if(!t||!e||!r(t))return;return Array.from(t.querySelectorAll(e)).filter(t=>null!==t.offsetParent)}n.d(e,{JL(){return i},sb(){return r}})},2958(t,e,n){"use strict";n.d(e,{m(){return Y}});var r=n(56911),i=n(22870),s=n(74849),o=n(22131),a=n(50882),l=n(92011),c=n(60815),u=n(38493),h=n(96950),d=n(64187),f=n(57606),p=n(5291),v=n(95239),g=n(48751),b=n(61201),m=n(31023),y=n(74838),w=n(72691),$=n(57416),x=n(26920),k=n(79288),C=n(62047),S=n(61138),E=n(41123),M=n(89580),F=n(71157),D=n(62198),O=n(37079),A=n(45755);const{create:T}=A.G,I=T("type-ramp-plus-5-font-size","32px"),B=T("type-ramp-plus-5-line-height","40px"),{create:N}=A.G,R=N("type-ramp-plus-6-font-size","40px"),L=N("type-ramp-plus-6-line-height","52px");var j=n(35901),P=n(90757),z=n(37947),H=n(17252),_=n(47691),V=n(14205),U=n(8315),W=n(356),q=n(6352),G=n(43404),K=n(37180);const X={toView:t=>null==t?null:t?.toColorString(),fromView(t){if(null==t)return null;const e=(0,i.Hs)(t);return e?p.q.create(e.r,e.g,e.b):null}},J=s.A`
    :host {
        background-color: ${v.p};
        color: ${g.l};
    }
`.withBehaviors((0,o.mr)(s.A`
            :host {
                background-color: ${a.A.Canvas};
                box-shadow: 0 0 0 1px ${a.A.CanvasText};
                color: ${a.A.CanvasText};
            }
        `));function Z(t){return(e,n)=>{e[n+"Changed"]=function(e,n){null!=n?t.setValueFor(this,n):t.deleteValueFor(this)}}}class Q extends l.L{constructor(){super(),this.noPaint=!1,c.cP.getNotifier(this).subscribe({handleChange:this.noPaintChanged.bind(this)},"fillColor")}noPaintChanged(){this.noPaint||void 0===this.fillColor?this.$fastController.removeStyles(J):this.$fastController.addStyles(J)}accentBaseColorChanged(t,e){null!=e?b.c.setValueFor(this,f.p.create(e)):b.c.deleteValueFor(this)}neutralBaseColorChanged(t,e){null!=e?m.r.setValueFor(this,f.p.create(e)):m.r.deleteValueFor(this)}}(0,r.Cg)([(0,u.CF)({attribute:"no-paint",mode:"boolean"}),(0,r.Sn)("design:type",Object)],Q.prototype,"noPaint",void 0),(0,r.Cg)([(0,u.CF)({attribute:"fill-color",converter:X}),Z(v.p),(0,r.Sn)("design:type",Object)],Q.prototype,"fillColor",void 0),(0,r.Cg)([(0,u.CF)({attribute:"accent-base-color",converter:X,mode:"fromView"}),(0,r.Sn)("design:type",Object)],Q.prototype,"accentBaseColor",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-base-color",converter:X,mode:"fromView"}),(0,r.Sn)("design:type",Object)],Q.prototype,"neutralBaseColor",void 0),(0,r.Cg)([c.sH,Z(m.r),(0,r.Sn)("design:type",Object)],Q.prototype,"neutralPalette",void 0),(0,r.Cg)([c.sH,Z(b.c),(0,r.Sn)("design:type",Object)],Q.prototype,"accentPalette",void 0),(0,r.Cg)([(0,u.CF)({converter:u.R$}),Z(y.Br),(0,r.Sn)("design:type",Number)],Q.prototype,"density",void 0),(0,r.Cg)([(0,u.CF)({attribute:"design-unit",converter:u.R$}),Z(y.vR),(0,r.Sn)("design:type",Number)],Q.prototype,"designUnit",void 0),(0,r.Cg)([(0,u.CF)({attribute:"direction"}),Z(w.o),(0,r.Sn)("design:type",String)],Q.prototype,"direction",void 0),(0,r.Cg)([(0,u.CF)({attribute:"base-height-multiplier",converter:u.R$}),Z(y.Ss),(0,r.Sn)("design:type",Number)],Q.prototype,"baseHeightMultiplier",void 0),(0,r.Cg)([(0,u.CF)({attribute:"base-horizontal-spacing-multiplier",converter:u.R$}),Z(y.a9),(0,r.Sn)("design:type",Number)],Q.prototype,"baseHorizontalSpacingMultiplier",void 0),(0,r.Cg)([(0,u.CF)({attribute:"control-corner-radius",converter:u.R$}),Z($.Pb),(0,r.Sn)("design:type",Number)],Q.prototype,"controlCornerRadius",void 0),(0,r.Cg)([(0,u.CF)({attribute:"stroke-width",converter:u.R$}),Z(x.XA),(0,r.Sn)("design:type",Number)],Q.prototype,"strokeWidth",void 0),(0,r.Cg)([(0,u.CF)({attribute:"focus-stroke-width",converter:u.R$}),Z(x.vd),(0,r.Sn)("design:type",Number)],Q.prototype,"focusStrokeWidth",void 0),(0,r.Cg)([(0,u.CF)({attribute:"disabled-opacity",converter:u.R$}),Z(k.q),(0,r.Sn)("design:type",Number)],Q.prototype,"disabledOpacity",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-minus-2-font-size"}),Z(C.t),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampMinus2FontSize",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-minus-2-line-height"}),Z(C.e),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampMinus2LineHeight",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-minus-1-font-size"}),Z(S.k),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampMinus1FontSize",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-minus-1-line-height"}),Z(S.F),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampMinus1LineHeight",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-base-font-size"}),Z(E.K),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampBaseFontSize",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-base-line-height"}),Z(E.Z),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampBaseLineHeight",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-1-font-size"}),Z(M.Y),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus1FontSize",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-1-line-height"}),Z(M.v),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus1LineHeight",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-2-font-size"}),Z(F.T),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus2FontSize",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-2-line-height"}),Z(F.O),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus2LineHeight",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-3-font-size"}),Z(D.a),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus3FontSize",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-3-line-height"}),Z(D.b),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus3LineHeight",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-4-font-size"}),Z(O.F),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus4FontSize",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-4-line-height"}),Z(O.w),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus4LineHeight",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-5-font-size"}),Z(I),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus5FontSize",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-5-line-height"}),Z(B),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus5LineHeight",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-6-font-size"}),Z(R),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus6FontSize",void 0),(0,r.Cg)([(0,u.CF)({attribute:"type-ramp-plus-6-line-height"}),Z(L),(0,r.Sn)("design:type",String)],Q.prototype,"typeRampPlus6LineHeight",void 0),(0,r.Cg)([(0,u.CF)({attribute:"accent-fill-rest-delta",converter:u.R$}),Z(j.yz),(0,r.Sn)("design:type",Number)],Q.prototype,"accentFillRestDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"accent-fill-hover-delta",converter:u.R$}),Z(j.MA),(0,r.Sn)("design:type",Number)],Q.prototype,"accentFillHoverDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"accent-fill-active-delta",converter:u.R$}),Z(j.uP),(0,r.Sn)("design:type",Number)],Q.prototype,"accentFillActiveDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"accent-fill-focus-delta",converter:u.R$}),Z(j._S),(0,r.Sn)("design:type",Number)],Q.prototype,"accentFillFocusDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"accent-foreground-rest-delta",converter:u.R$}),Z(P.kw),(0,r.Sn)("design:type",Number)],Q.prototype,"accentForegroundRestDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"accent-foreground-hover-delta",converter:u.R$}),Z(P.CX),(0,r.Sn)("design:type",Number)],Q.prototype,"accentForegroundHoverDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"accent-foreground-active-delta",converter:u.R$}),Z(P.mD),(0,r.Sn)("design:type",Number)],Q.prototype,"accentForegroundActiveDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"accent-foreground-focus-delta",converter:u.R$}),Z(P.em),(0,r.Sn)("design:type",Number)],Q.prototype,"accentForegroundFocusDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-rest-delta",converter:u.R$}),Z(z.DE),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillRestDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-hover-delta",converter:u.R$}),Z(z.l2),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillHoverDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-active-delta",converter:u.R$}),Z(z.L6),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillActiveDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-focus-delta",converter:u.R$}),Z(z.tN),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillFocusDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-input-rest-delta",converter:u.R$}),Z(H.DZ),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillInputRestDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-input-hover-delta",converter:u.R$}),Z(H.nK),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillInputHoverDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-input-active-delta",converter:u.R$}),Z(H.xK),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillInputActiveDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-input-focus-delta",converter:u.R$}),Z(H.dc),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillInputFocusDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-layer-rest-delta",converter:u.R$}),Z(_.E),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillLayerRestDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-stealth-rest-delta",converter:u.R$}),Z(V.q),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillStealthRestDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-stealth-hover-delta",converter:u.R$}),Z(V.oj),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillStealthHoverDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-stealth-active-delta",converter:u.R$}),Z(V.Ws),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillStealthActiveDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-stealth-focus-delta",converter:u.R$}),Z(V.Mc),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillStealthFocusDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-strong-hover-delta",converter:u.R$}),Z(U.YO),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillStrongHoverDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-strong-active-delta",converter:u.R$}),Z(U.WF),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillStrongActiveDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-fill-strong-focus-delta",converter:u.R$}),Z(U.k7),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralFillStrongFocusDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"base-layer-luminance",converter:u.R$}),Z(W.l),(0,r.Sn)("design:type",Number)],Q.prototype,"baseLayerLuminance",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-stroke-divider-rest-delta",converter:u.R$}),Z(q.X),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralStrokeDividerRestDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-stroke-rest-delta",converter:u.R$}),Z(G.uC),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralStrokeRestDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-stroke-hover-delta",converter:u.R$}),Z(G.iS),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralStrokeHoverDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-stroke-active-delta",converter:u.R$}),Z(G.C2),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralStrokeActiveDelta",void 0),(0,r.Cg)([(0,u.CF)({attribute:"neutral-stroke-focus-delta",converter:u.R$}),Z(G.Q2),(0,r.Sn)("design:type",Number)],Q.prototype,"neutralStrokeFocusDelta",void 0);const Y=Q.compose({name:`${K.c.prefix}-design-system-provider`,template:h.qy`
        <slot></slot>
    `,styles:s.A`
        ${(0,d.V)("block")}
    `})},4126(t,e,n){"use strict";n.d(e,{o(){return i}});var r=n(60815);class i{constructor(t,e,n){this.propertyName=t,this.value=e,this.styles=n}addedCallback(t){r.cP.getNotifier(t.source).subscribe(this,this.propertyName),this.handleChange(t.source,this.propertyName)}removedCallback(t){r.cP.getNotifier(t.source).unsubscribe(this,this.propertyName),t.removeStyles(this.styles)}handleChange(t,e){const n=t.$fastController;t[e]===this.value?n.addStyles(this.styles):n.removeStyles(this.styles)}}},4283(t,e,n){"use strict";n.d(e,{am(){return p},KJ(){return v},OS(){return f},IR(){return d}});var r=n(45755),i=n(95239),s=n(37947),o=n(31023),a=n(35901),l=n(61201),c=n(57065);const{create:u}=r.G,h=u({name:"accent-fill-recipe"},{evaluate(t,e){return(c.i.normal,(t,e)=>function(t,e,n,r,i,s){const o=t.source,a=t.closestIndexOf(o),l=a+1*r,c=a+1*i,u=a+1*s;return{rest:t.get(a),hover:t.get(l),active:t.get(c),focus:t.get(u)}}(t(l.c),t(o.r),e||t(i.p),t(a.MA),t(a.uP),t(a._S),t(s.DE),t(s.l2),t(s.L6)))(t,e)}}),d=u("accent-fill-rest",t=>t(h).evaluate(t).rest),f=u("accent-fill-hover",t=>t(h).evaluate(t).hover),p=u("accent-fill-active",t=>t(h).evaluate(t).active),v=u("accent-fill-focus",t=>t(h).evaluate(t).focus)},4731(t,e,n){"use strict";n.d(e,{m(){return a}});var r=n(37180),i=n(56063),s=n(69128),o=n(41817);const a=i.b.compose({name:`${r.c.prefix}-button`,template:o.v,styles:s.R,shadowOptions:{delegatesFocus:!0}})},5096(t,e,n){"use strict";function r(t,e,n){return n<t?e:n>e?t:n}function i(t,e,n){return Math.min(Math.max(n,t),e)}function s(t,e,n=0){return[e,n]=[e,n].sort((t,e)=>t-e),e<=t&&t<n}n.d(e,{AB(){return i},Vf(){return r},r4(){return s}})},5291(t,e,n){"use strict";n.d(e,{q(){return o}});var r=n(14848),i=n(87122),s=n(87989);const o=Object.freeze({create:(t,e,n)=>new a(t,e,n),from:t=>new a(t.r,t.g,t.b)});class a extends i.M{constructor(t,e,n){super(t,e,n,1),this.toColorString=this.toStringHexRGB,this.contrast=s.v.bind(null,this),this.createCSS=this.toColorString,this.relativeLuminance=(0,r.Z8)(this)}static fromObject(t){return new a(t.r,t.g,t.b)}}},5410(t,e,n){"use strict";n.d(e,{Ds(){return z},Fc(){return H},Hm(){return A},Q3(){return B},So(){return R},Ym(){return N},ee(){return P},oS(){return V},sq(){return _},vF(){return U}});var r=n(14777),i=n(58625),s=n(88383),o=n(62044),a=n(89449),l="on",c="attachEvent",u="addEventListener",h="detachEvent",d="removeEventListener",f="events",p="visibilitychange",v="pagehide",g="pageshow",b="unload",m="beforeunload",y=(0,i.Z)("aiEvtPageHide"),w=(0,i.Z)("aiEvtPageShow"),$=/\.[\.]+/g,x=/[\.]+$/,k=1,C=(0,i.T)("events"),S=/^([^.]*)(?:\.(.+)|)/;function E(t){return t&&t[r.W7]?t[r.W7](/^[\s\.]+|(?=[\s\.])[\.\s]+$/g,a.m5):t}function M(t,e){var n;if(e){var i=a.m5;(0,o.cy)(e)?(i=a.m5,(0,o.Iu)(e,function(t){(t=E(t))&&("."!==t[0]&&(t="."+t),i+=t)})):i=E(e),i&&("."!==i[0]&&(i="."+i),t=(t||a.m5)+i)}var s=S.exec(t||a.m5)||[];return(n={})[r.QM]=s[1],n.ns=(s[2]||a.m5).replace($,".").replace(x,a.m5)[r.sY](".").sort().join("."),n}function F(t,e,n){void 0===n&&(n=!0);var r=C.get(t,f,{},n),i=r[e];return i||(i=r[e]=[]),i}function D(t,e,n,i){t&&e&&e[r.QM]&&(t[d]?t[d](e[r.QM],n,i):t[h]&&t[h](l+e[r.QM],n))}function O(t,e,n,i){for(var s=e[r.oI];s--;){var o=e[s];o&&(n.ns&&n.ns!==o.evtName.ns||i&&!i(o)||(D(t,o.evtName,o[r.Yo],o.capture),e[r.Ic](s,1)))}}function A(t,e){return e?M("xx",(0,o.cy)(e)?[t].concat(e):[t,e]).ns[r.sY]("."):t}function T(t,e,n,i,s){var o;void 0===s&&(s=!1);var a=!1;if(t)try{var h=M(e,i);if(a=function(t,e,n,i){var s=!1;return t&&e&&e[r.QM]&&n&&(t[u]?(t[u](e[r.QM],n,i),s=!0):t[c]&&(t[c](l+e[r.QM],n),s=!0)),s}(t,h,n,s),a&&C.accept(t)){var d=((o={guid:k++,evtName:h})[r.Yo]=n,o.capture=s,o);F(t,h.type)[r.y5](d)}}catch(t){}return a}function I(t,e,n,i,s){if(void 0===s&&(s=!1),t)try{var a=M(e,i),l=!1;!function(t,e,n){if(e[r.QM])O(t,F(t,e[r.QM]),e,n);else{var i=C.get(t,f,{});(0,o.z)(i,function(r,i){O(t,i,e,n)}),0===(0,o.cG)(i)[r.oI]&&C.kill(t,f)}}(t,a,function(t){return!((!a.ns||n)&&t[r.Yo]!==n)&&(l=!0,!0)}),l||D(t,a,n,s)}catch(t){}}function B(t,e,n,r){return void 0===r&&(r=!1),T(t,e,n,null,r)}function N(t,e,n,r){void 0===r&&(r=!1),I(t,e,n,null,r)}function R(t,e,n){var r=!1,i=(0,s.zk)();i&&(r=T(i,t,e,n),r=T(i.body,t,e,n)||r);var o=(0,s.YE)();return o&&(r=T(o,t,e,n)||r),r}function L(t,e,n,i){var s=!1;return e&&t&&t[r.oI]>0&&(0,o.Iu)(t,function(t){t&&(n&&-1!==(0,o.rD)(n,t)||(s=R(t,e,i)||s))}),s}function j(t,e,n){t&&(0,o.cy)(t)&&(0,o.Iu)(t,function(t){t&&function(t,e,n){var r=(0,s.zk)();r&&(I(r,t,e,n),I(r.body,t,e,n));var i=(0,s.YE)();i&&I(i,t,e,n)}(t,e,n)})}function P(t,e,n){return function(t,e,n,i){var s=!1;return e&&t&&(0,o.cy)(t)&&!(s=L(t,e,n,i))&&n&&n[r.oI]>0&&(s=L(t,e,null,i)),s}([m,b,v],t,e,n)}function z(t,e){j([m,b,v],t,e)}function H(t,e,n){var r=A(y,n),i=L([v],t,e,r);return e&&-1!==(0,o.rD)(e,p)||(i=L([p],function(e){var n=(0,s.YE)();t&&n&&"hidden"===n.visibilityState&&t(e)},e,r)||i),!i&&e&&(i=H(t,null,n)),i}function _(t,e){var n=A(y,e);j([v],t,n),j([p],null,n)}function V(t,e,n){var r=A(w,n),i=L([g],t,e,r);return!(i=L([p],function(e){var n=(0,s.YE)();t&&n&&"visible"===n.visibilityState&&t(e)},e,r)||i)&&e&&(i=V(t,null,n)),i}function U(t,e){var n=A(w,e);j([g],t,n),j([p],null,n)}},5565(t,e,n){"use strict";n.d(e,{KF(){return w}});var r=n(56911),i=n(38493),s=n(58976);class o extends s.C{constructor(){super(...arguments),this.speed=1200,this.headingLevel=3}}(0,r.Cg)([i.CF],o.prototype,"speed",void 0),(0,r.Cg)([(0,i.CF)({attribute:"heading-level",mode:"fromView",converter:i.R$})],o.prototype,"headingLevel",void 0),(0,r.Cg)([i.CF],o.prototype,"heading",void 0);var a=n(96950),l=n(60402),c=n(82774),u=n(10108),h=n(69259),d=n(22192);const f=a.qy`<template>${d.p}<div class="heading-container" part="heading-container"><span class="header"><slot name="icon"></slot><slot name="heading"><span class="heading" role="heading" aria-level=${t=>t.headingLevel}>${t=>t.heading}</span><slot name="details"></slot></slot><slot name="description"></slot></span><slot name="action"></slot></div><div class="scroll-area"><div part="scroll-view" class="scroll-view" @scroll="${t=>t.scrolled()}" ${(0,l.K)("scrollContainer")}><div role="list" class="content-container" part="content-container" ${(0,l.K)("content")}><slot ${(0,c.e)({property:"scrollItems",filter:(0,u.Y)()})}></slot></div></div>${(0,h.z)(t=>"mobile"!==t.view,a.qy`<div class="scroll scroll-prev" part="scroll-prev" ${(0,l.K)("previousFlipperContainer")}><div class="scroll-action" @click="${t=>t.scrollToPrevious()}"><slot name="previous-flipper"><fluent-flipper direction="previous"></fluent-flipper></slot></div></div><div class="scroll scroll-next" part="scroll-next" ${(0,l.K)("nextFlipperContainer")}><div class="scroll-action" @click="${t=>t.scrollToNext()}"><slot name="next-flipper"><fluent-flipper></fluent-flipper></slot></div></div>`)}</div>${d.S}</template>`;var p=n(95239),v=n(71157),g=n(61138),b=n(97482);const m=n(74849).A`
    ${b.R} :host{--scroll-fade-next:${p.p}}.heading-container{display:grid;grid-template-columns:1fr auto;margin:0 0 12px}::slotted([slot="action"]){display:flex;align-items:flex-end}::slotted([slot="icon"]){margin-inline-end:8px}.header,.header ::slotted(h1),.header ::slotted(h2),.header ::slotted(h3),.header ::slotted(h4),.header ::slotted(h5),.header ::slotted(h6){font-size:var(--stripe-heading-font-size,${v.T});
        line-height: var(--stripe-heading-line-height, ${v.O});font-weight:600;margin:0}::slotted([slot="description"]){font-size:${g.k};
        line-height: ${g.F};
        margin: 8px 0 0;
    }
`;var y=n(99900);const w=o.compose({name:`${y.i.prefix}-stripe`,template:f,styles:m})},5793(t,e,n){"use strict";n.d(e,{A(){return u}});var r=n(56911),i=n(60815),s=n(23429),o=n(38493),a=n(55230),l=n(5096),c=n(17884);class u extends c.U{constructor(){super(...arguments),this.activeIndex=-1,this.rangeStartIndex=-1}get activeOption(){return this.options[this.activeIndex]}get checkedOptions(){return this.options?.filter(t=>t.checked)}get firstSelectedOptionIndex(){return this.options.indexOf(this.firstSelectedOption)}activeIndexChanged(t,e){this.ariaActiveDescendant=this.options[e]?.id??"",this.focusAndScrollOptionIntoView()}checkActiveIndex(){if(!this.multiple)return;const t=this.activeOption;t&&(t.checked=!0)}checkFirstOption(t=!1){t?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex+1),this.options.forEach((t,e)=>{t.checked=(0,l.r4)(e,this.rangeStartIndex)})):this.uncheckAllOptions(),this.activeIndex=0,this.checkActiveIndex()}checkLastOption(t=!1){t?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex),this.options.forEach((t,e)=>{t.checked=(0,l.r4)(e,this.rangeStartIndex,this.options.length)})):this.uncheckAllOptions(),this.activeIndex=this.options.length-1,this.checkActiveIndex()}connectedCallback(){super.connectedCallback(),this.addEventListener("focusout",this.focusoutHandler)}disconnectedCallback(){this.removeEventListener("focusout",this.focusoutHandler),super.disconnectedCallback()}checkNextOption(t=!1){t?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex),this.options.forEach((t,e)=>{t.checked=(0,l.r4)(e,this.rangeStartIndex,this.activeIndex+1)})):this.uncheckAllOptions(),this.activeIndex+=this.activeIndex<this.options.length-1?1:0,this.checkActiveIndex()}checkPreviousOption(t=!1){t?(-1===this.rangeStartIndex&&(this.rangeStartIndex=this.activeIndex),1===this.checkedOptions.length&&(this.rangeStartIndex+=1),this.options.forEach((t,e)=>{t.checked=(0,l.r4)(e,this.activeIndex,this.rangeStartIndex)})):this.uncheckAllOptions(),this.activeIndex-=this.activeIndex>0?1:0,this.checkActiveIndex()}clickHandler(t){if(!this.multiple)return super.clickHandler(t);const e=t.target?.closest("[role=option]");return e&&!e.disabled?(this.uncheckAllOptions(),this.activeIndex=this.options.indexOf(e),this.checkActiveIndex(),this.toggleSelectedForAllCheckedOptions(),!0):void 0}focusAndScrollOptionIntoView(){super.focusAndScrollOptionIntoView(this.activeOption)}focusinHandler(t){if(!this.multiple)return super.focusinHandler(t);this.shouldSkipFocus||t.target!==t.currentTarget||(this.uncheckAllOptions(),-1===this.activeIndex&&(this.activeIndex=-1!==this.firstSelectedOptionIndex?this.firstSelectedOptionIndex:0),this.checkActiveIndex(),this.setSelectedOptions(),this.focusAndScrollOptionIntoView()),this.shouldSkipFocus=!1}focusoutHandler(t){this.multiple&&this.uncheckAllOptions()}keydownHandler(t){if(!this.multiple)return super.keydownHandler(t);if(this.disabled)return!0;const{key:e,shiftKey:n}=t;switch(this.shouldSkipFocus=!1,e){case a.kE:return void this.checkFirstOption(n);case a.HX:return void this.checkNextOption(n);case a.I5:return void this.checkPreviousOption(n);case a.FM:return void this.checkLastOption(n);case a.J9:return this.focusAndScrollOptionIntoView(),!0;case a.F9:return this.uncheckAllOptions(),this.checkActiveIndex(),!0;case a.gG:if(t.preventDefault(),this.typeAheadExpired)return void this.toggleSelectedForAllCheckedOptions();default:return 1===e.length&&this.handleTypeAhead(`${e}`),!0}}mousedownHandler(t){if(t.offsetX>=0&&t.offsetX<=this.scrollWidth)return super.mousedownHandler(t)}multipleChanged(t,e){this.ariaMultiSelectable=e?"true":null,this.options?.forEach(t=>{t.checked=!e&&void 0}),this.setSelectedOptions()}setSelectedOptions(){this.multiple?this.$fastController.isConnected&&this.options&&(this.selectedOptions=this.options.filter(t=>t.selected),this.focusAndScrollOptionIntoView()):super.setSelectedOptions()}sizeChanged(t,e){const n=Math.max(0,parseInt(e?.toFixed()??"",10));n!==e&&s.L.enqueue(()=>{this.size=n})}toggleSelectedForAllCheckedOptions(){const t=this.checkedOptions.filter(t=>!t.disabled),e=!t.every(t=>t.selected);t.forEach(t=>t.selected=e),this.selectedIndex=this.options.indexOf(t[t.length-1]),this.setSelectedOptions()}typeaheadBufferChanged(t,e){if(this.multiple){if(this.$fastController.isConnected){const t=this.getTypeaheadMatches(),e=this.options.indexOf(t[0]);e>-1&&(this.activeIndex=e,this.uncheckAllOptions(),this.checkActiveIndex()),this.typeAheadExpired=!1}}else super.typeaheadBufferChanged(t,e)}uncheckAllOptions(t=!1){this.options.forEach(t=>t.checked=!this.multiple&&void 0),t||(this.rangeStartIndex=-1)}}(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Number)],u.prototype,"activeIndex",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],u.prototype,"multiple",void 0),(0,r.Cg)([(0,o.CF)({converter:o.R$}),(0,r.Sn)("design:type",Number)],u.prototype,"size",void 0)},5926(t,e,n){"use strict";n.d(e,{A(){return A}});var r=n(39813),i=n(58207),s=n(20468),o=n(88383),a=n(50090),l=n(14777),c=n(62044),u=n(89449),h=n(6608),d=n(39407),f=500;function p(t,e,n){e&&(0,c.cy)(e)&&e[l.oI]>0&&(e=e.sort(function(t,e){return t[u.Vo]-e[u.Vo]}),(0,c.Iu)(e,function(t){t[u.Vo]<f&&(0,c.$8)("Channel has invalid priority - "+t[l.Ju])}),t[l.y5]({queue:(0,c.N6)(e),chain:(0,h.PV)(e,n[l.GA],n)}))}var v=n(12839),g=n(58625),b=n(53894),m=n(13765),y=function(t){function e(){var n,r,a=t.call(this)||this;function h(){n=0,r=[]}return a.identifier="TelemetryInitializerPlugin",a.priority=199,h(),(0,i.A)(e,a,function(t,e){t.addTelemetryInitializer=function(t){var e={id:n++,fn:t};return r[l.y5](e),{remove(){(0,c.Iu)(r,function(t,n){if(t.id===e.id)return r[l.Ic](n,1),-1})}}},t[u.qT]=function(e,n){for(var i=!1,a=r[l.oI],u=0;u<a;++u){var h=r[u];if(h)try{if(!1===h.fn[l.y9](null,[e])){i=!0;break}}catch(t){(0,s.ZP)(n[l.e4](),1,64,"One of telemetry initializers failed, telemetry item will not be sent: "+(0,c.lL)(t),{exception:(0,o.mm)(t)},!0)}}i||t[l.$5](e,n)},t[l.tn]=function(){h()}}),a}return(0,r.qU)(e,t),e.__ieDyn=1,e}(n(58168).s),w=n(13023),$="Plugins must provide initialize method",x="_notificationManager",k="SDK is still unloading...",C={loggingLevelConsole:1};function S(t,e){return new m.NS(e)}function E(t,e){var n=!1;return(0,c.Iu)(e,function(e){if(e===t)return n=!0,-1}),n}var M=function(){function t(){var e,n,o,M,F,D,O,A,T,I,B,N,R,L,j,P,z,H,_,V,U=0;(0,i.A)(t,this,function(t){function i(){n=!1,e=(0,c.CP)(!0,{},C),t[l.GA]=e,t[l.Uw]=new s.wq(e),t[l.H7]=[],j=new y,o=[],M=null,F=null,D=null,O=null,A=null,I=null,T=[],B=null,N=null,R=null,L=!1,P=null,z=(0,g.Z)("AIBaseCore",!0),H=(0,w.P)(),V=null}function W(){return(0,h.i8)(K(),e,t)}function q(n){var r=function(t,e,n){var r,i=[],o={};return(0,c.Iu)(n,function(n){((0,c.hX)(n)||(0,c.hX)(n[l.mE]))&&(0,c.$8)($);var r=n[u.Vo],a=n[l.Ju];n&&r&&((0,c.hX)(o[r])?o[r]=a:(0,s.OG)(t,"Two extensions have same priority #"+r+" - "+o[r]+", "+a)),(!r||r<e)&&i[l.y5](n)}),(r={all:n})[u.eT]=i,r}(t[l.Uw],f,T);I=r[u.eT],A=null;var i=r.all;if(R=(0,c.N6)(function(t,e,n){var r=[];if(t&&(0,c.Iu)(t,function(t){return p(r,t,n)}),e){var i=[];(0,c.Iu)(e,function(t){t[u.Vo]>f&&i[l.y5](t)}),p(r,i,n)}return r}(N,i,t)),B){var o=(0,c.rD)(i,B);-1!==o&&i[l.Ic](o,1),-1!==(o=(0,c.rD)(I,B))&&I[l.Ic](o,1),B._setQueue(R)}else B=function(t,e){function n(){return(0,h.i8)(null,e[l.GA],e,null)}function r(t,e,n,r){var i=t?t[l.oI]+1:1;function s(){0===--i&&(r&&r(),r=null)}i>0&&(0,c.Iu)(t,function(t){if(t&&t.queue[l.oI]>0){var r=t.chain,o=e[l.$o](r);o[l.by](s),n(o)}else i--}),s()}var i=!1,s={identifier:"ChannelControllerPlugin",priority:f,initialize(e,n,r,s){i=!0,(0,c.Iu)(t,function(t){t&&t.queue[l.oI]>0&&(0,d.pI)((0,h.i8)(t.chain,e,n),r)})},isInitialized:()=>i,processTelemetry(e,i){r(t,i||n(),function(t){t[l.$5](e)},function(){i[l.$5](e)})},update(e,n){var i=n||{reason:0};return r(t,e,function(t){t[l.$5](i)},function(){e[l.$5](i)}),!0},pause(){r(t,n(),function(t){t.iterate(function(t){t.pause&&t.pause()})},null)},resume(){r(t,n(),function(t){t.iterate(function(t){t.resume&&t.resume()})},null)},teardown(e,n){var s=n||{reason:0,isAsync:!1};return r(t,e,function(t){t[l.$5](s)},function(){e[l.$5](s),i=!1}),!0},getChannel(e){var n=null;return t&&t[l.oI]>0&&(0,c.Iu)(t,function(t){if(t&&t.queue[l.oI]>0&&((0,c.Iu)(t.queue,function(t){if(t[l.Ju]===e)return n=t,-1}),n))return-1}),n},flush(e,i,s,o){var a=1,c=!1,u=null;function h(){a--,c&&0===a&&(u&&(clearTimeout(u),u=null),i&&i(c),i=null)}return o=o||5e3,r(t,n(),function(t){t.iterate(function(t){if(t[l.EX]){a++;var n=!1;t[l.EX](e,function(){n=!0,h()},s)||n||(e&&null==u?u=setTimeout(function(){u=null,h()},o):h())}})},function(){c=!0,h()}),!0},_setQueue(e){t=e}};return s}(R,t);i[l.y5](B),I[l.y5](B),t[l.H7]=(0,d.Xc)(i),B[l.mE](e,t,i),(0,d.pI)(W(),i),t[l.H7]=(0,c.N6)((0,d.Xc)(I||[])).slice(),n&&function(e){var n=(0,h.nU)(K(),t);t._updateHook&&!0===t._updateHook(n,e)||n[l.$5](e)}(n)}function G(e){var n,r=null,i=null;return(0,c.Iu)(t[l.H7],function(t){if(t[l.Ju]===e&&t!==B&&t!==j)return i=t,-1}),!i&&B&&(i=B.getChannel(e)),i&&((n={plugin:i})[l.kt]=function(t){(0,d.Cr)(i)[u.Hr]=!t},n.isEnabled=function(){var t=(0,d.Cr)(i);return!t[l.Ik]&&!t[u.Hr]},n.remove=function(t,e){var n;void 0===t&&(t=!0);var r=[i],s=((n={reason:1})[l.tI]=t,n);X(r,s,function(t){t&&q({reason:32,removed:r}),e&&e(t)})},r=n),r}function K(){if(!A){var n=(I||[]).slice();-1===(0,c.rD)(n,j)&&n[l.y5](j),A=(0,h.PV)((0,d.Xc)(n),e,t)}return A}function X(n,r,i){if(n&&n[l.oI]>0){var s=(0,h.PV)(n,e,t),o=(0,h.tS)(s,t);o[l.by](function(){var t=!1,e=[];(0,c.Iu)(T,function(r,i){E(r,n)?t=!0:e[l.y5](r)}),T=e;var r=[];N&&((0,c.Iu)(N,function(e,i){var s=[];(0,c.Iu)(e,function(e){E(e,n)?t=!0:s[l.y5](e)}),r[l.y5](s)}),N=r),i&&i(t)}),o[l.$5](r)}else i(!1)}function J(){var n=t[l.Uw]?t[l.Uw].queue:[];n&&((0,c.Iu)(n,function(n){var r,i=((r={})[l.RS]=P||"InternalMessageId: "+n[l.JR],r.iKey=(0,c.SA)(e[l.sl]),r.time=(0,c._u)(new Date),r.baseType=s.WD.dataType,r.baseData={message:n[l.pM]},r);t.track(i)}),n[l.oI]=0)}function Z(t,e,n,r){return B?B[l.EX](t,e,n||6,r):(e&&e(!1),!0)}function Q(e){var n=t[l.Uw];n?(0,s.ZP)(n,2,73,e):(0,c.$8)(e)}i(),t[l.tZ]=function(){return n},t[l.mE]=function(i,s,o,a){L&&(0,c.$8)(k),t[l.tZ]()&&(0,c.$8)("Core should not be initialized more than once"),e=i||{},t[l.GA]=e,(0,c.hX)(i[l.sl])&&(0,c.$8)("Please provide instrumentation key"),M=a,t[x]=a,function(){var t=(0,c.SA)(e.disableDbgExt);!0===t&&_&&(M[l.TP](_),_=null);M&&!_&&!0!==t&&(_=(0,b.M)(e),M[l.vR](_))}(),function(){var t=(0,c.SA)(e.enablePerfMgr);!t&&D&&(D=null);t&&(0,c.c2)(e,u.Yd,S)}(),(0,c.c2)(e,u.Bw,{}).NotificationManager=M,o&&(t[l.Uw]=o);var h=(0,c.c2)(e,u.jy,[]);(T=[])[l.y5].apply(T,(0,r.vz)((0,r.vz)([],s,!1),h,!1)),N=(0,c.c2)(e,u.LZ,[]),q(null),R&&0!==R[l.oI]||(0,c.$8)("No "+u.LZ+" available"),n=!0,t.releaseQueue()},t.getTransmissionControls=function(){var t=[];return R&&(0,c.Iu)(R,function(e){t[l.y5](e.queue)}),(0,c.N6)(t)},t.track=function(n){n.iKey=n.iKey||e[l.sl],n[l.fA]=n[l.fA]||(0,c._u)(new Date),n.ver=n.ver||"4.0",!L&&t[l.tZ]()?W()[l.$5](n):o[l.y5](n)},t[l.ps]=W,t[l.RF]=function(){var e;return M||(M=(0,a.AQ)(((e={})[l.vR]=function(t){},e[l.TP]=function(t){},e[u.fc]=function(t){},e[u.Yp]=function(t,e){},e[u.dI]=function(t,e){},e)),t[x]=M),M},t[l.vR]=function(t){M&&M[l.vR](t)},t[l.TP]=function(t){M&&M[l.TP](t)},t.getCookieMgr=function(){return O||(O=(0,v.xN)(e,t[l.Uw])),O},t.setCookieMgr=function(t){O=t},t[u.kI]=function(){if(!F&&!D&&(0,c.SA)(e.enablePerfMgr)){var n=(0,c.SA)(e[u.Yd]);(0,c.Tn)(n)&&(D=n(t,t[l.RF]()))}return F||D||(0,m.Z4)()},t.setPerfMgr=function(t){F=t},t.eventCnt=function(){return o[l.oI]},t.releaseQueue=function(){if(n&&o[l.oI]>0){var t=o;o=[],(0,c.Iu)(t,function(t){W()[l.$5](t)})}},t.pollInternalLogs=function(t){P=t||null;var n=(0,c.SA)(e.diagnosticLogInterval);return n&&n>0||(n=1e4),U&&clearInterval(U),U=setInterval(function(){J()},n)},t[l.Di]=function(){U&&(clearInterval(U),U=0,J())},(0,c.o$)(t,function(){return j},["addTelemetryInitializer"]),t.unload=function(e,r,s){var o;void 0===e&&(e=!0),n||(0,c.$8)("SDK is not initialized"),L&&(0,c.$8)(k);var a=((o={reason:50})[l.tI]=e,o.flushComplete=!1,o),u=(0,h.tS)(K(),t);function d(e){a.flushComplete=e,L=!0,H.run(u,a),t[l.Di](),u[l.$5](a)}u[l.by](function(){i(),r&&r(a)},t),Z(e,d,6,s)||d(!1)},t[l.AP]=G,t.addPlugin=function(t,e,n,r){if(!t)return r&&r(!1),void Q($);var i=G(t[l.Ju]);if(i&&!e)return r&&r(!1),void Q("Plugin ["+t[l.Ju]+"] is already loaded!");var s={reason:16};function o(e){T[l.y5](t),s.added=[t],q(s),r&&r(!0)}if(i){var a=[i.plugin];X(a,{reason:2,isAsync:!!n},function(t){t?(s.removed=a,s.reason|=32,o()):r&&r(!1)})}else o()},t.evtNamespace=function(){return z},t[l.EX]=Z,t.getTraceCtx=function(t){return V||(V=(0,d.u7)()),V},t.setTraceCtx=function(t){V=t||null},(0,c.RF)(t,"addUnloadCb",function(){return H},"add")})}return t.__ieDyn=1,t}(),F=n(18622),D=n(99577),O=function(t){function e(){var n=t.call(this)||this;return(0,i.A)(e,n,function(t,e){t.initialize=function(n,r,i,a){n&&!n.endpointUrl&&(n.endpointUrl=F.S),t.getWParam=function(){return D.g8||n.enableWParam?0:-1};try{e.initialize(n,r,i,a)}catch(e){(0,s.ZP)(t.logger,1,514,"Initialization Failed: "+(0,o.mm)(e)+"\n - Note: Channels must be provided through config.channels only")}},t.track=function(t){var n=t;if(n){var r=n.ext=n.ext||{};r.sdk=r.sdk||{},r.sdk.ver=D.xE}e.track(n)}}),n}return(0,r.qU)(e,t),e.__ieDyn=1,e}(M),A=O},5989(t,e,n){"use strict";n.d(e,{W(){return v}});var r=n(22192),i=n(58792),s=n(53697),o=n(96950),a=n(60402),l=n(69259);const c=`${(0,i.rA)().StaticsUrl}latest/fluent-icons/search_24_regular.svg`,u=o.qy`${o.qy.partial(s)}`,h=o.qy`<div class="clear-container cc-pa" style="${t=>""!==t.value?"":"display: none"}"><fluent-button class="clear-btn" id="clear_srch" data-targetid="ClearSearchButton" appearance="stealth" data-customhandled="true" title="${t=>t.clearTitle}" aria-label="${t=>t.clearLabel}" part="button" appearance="${t=>t.isOnImage?"stealth":"accent"}" ?disabled="${t=>""===t.value}" @focus=${t=>t.clearBtnOnFocus()} @blur=${t=>t.clearBtnOnBlurs()} @click="${(t,e)=>t.clearValue(e.event)}" @keypress=${(t,e)=>t.clearValue(e.event)} icon-only data-t="${t=>t.clearButtonTelemetryTag}">${u}</fluent-button></div>`,d=o.qy`<img class="search-icon-asset-img" src="${c}" aria-hidden="true" width="24" height="24" />`,f=o.qy`<fluent-button class="search-btn" part="button" part="button" title=${t=>t.buttonLabel} aria-label=${t=>t.buttonLabel} tabIndex=${t=>t.disabled?"-1":"0"} @click="${(t,e)=>t.submitSearch(e.event)}" @keypress="${(t,e)=>t.submitSearch(e.event)}" data-t="${t=>t.buttonTelemetryTag}" data-customhandled="true" appearance="stealth">${d}</fluent-button>`,p=o.qy`<div class="form-kumo" part="form"><div class="kumo-wrapper"><div class="core search-btn-on-left core-search-kumo" part="searchcore"><slot name="search-options-left"></slot>${f}<input class="control" type="search" id="q" name="q" part="control" title="${t=>t.title}" @input=${(t,e)=>t.handleTextInput(e.event)} @focus=${t=>t.inputOnFocus()} @blur=${t=>t.inputOnBlur()} aria-label="${t=>t.title}" placeholder=${t=>t.isRubySearchBox&&t.isInputFocused?"":t.placeholder} autocomplete=${t=>!t.isRubySearchBox&&t.autocomplete} ?required=${t=>t.required} ?disabled=${t=>t.disabled} ?readonly=${t=>t.readOnly} maxlength="${t=>t.maxlength}" minlength="${t=>t.minlength}" ?spellcheck="${t=>t.spellcheck}" ${(0,a.K)("control")} data-t="${t=>t.inputTelemetryTag}" />${h}</div></div></div>`;function v(t){return o.qy`<template tabindex="${t=>t.disabled?null:0}" class=" ${t=>t.readOnly?"readonly":""} ${t=>t.isOnImage?"onimage":""} " @focus=${t=>t.onFocus()} @blur=${t=>t.onBlurs()}>${(0,l.z)(t=>t.isRubySearchBox,p,function(t){const e=o.qy`<fluent-button class="${t=>t.isOnImage?"stealth":"accent"} ${t=>t.enableClearButton?"enable-clr-btn ":""}" part="button" title="${t=>t.buttonLabel}" aria-label="${t=>t.buttonLabel}" tabIndex="${t=>t.disabled?"-1":"0"}" appearance="${t=>t.isOnImage?"stealth":"accent"}" @click="${(t,e)=>t.submitSearch(e.event)}" @keypress="${(t,e)=>t.submitSearch(e.event)}" data-t="${t=>t.buttonTelemetryTag}"><span part="end" class="end-slot" ${(0,a.K)("endContainer")}><slot name="end" ${(0,a.K)("end")} @slotchange=${t=>t.handleEndContentChange()}>${t.endContent||""}</slot></span></fluent-button>`;return o.qy`<div class="root" part="root">${(0,l.z)(t=>t.isProngRubySearchBox,e)} ${r.p}<input class="control" part="control" type="search" id="${t=>t.id}" title="${t=>t.title}" name="${t=>t.name}" @input=${(t,e)=>t.handleTextInput(e.event)} aria-label="${t=>t.title}" placeholder=${t=>t.placeholder} autocomplete=${t=>t.autocomplete} ?required=${t=>t.required} ?disabled=${t=>t.disabled} ?readonly=${t=>t.readOnly} maxlength="${t=>t.maxlength}" minlength="${t=>t.minlength}" ?spellcheck="${t=>t.spellcheck}" ${(0,a.K)("control")} data-t="${t=>t.inputTelemetryTag}" /></div><div class="searchoptions"><slot name="search-options"></slot></div>${(0,l.z)(t=>t.showClearButton&&!t.isProngRubySearchBox,o.qy`<fluent-button class="${t=>t.isOnImage?"stealth":"accent"} ${t=>t.enableClearButton?"enable-clr-btn ":""}" title="${t=>t.clearTitle}" aria-label="${t=>t.clearLabel}" part="button" appearance="${t=>t.isOnImage?"stealth":"accent"}" ?disabled="${t=>""===t.value}" @focus=${t=>t.clearBtnOnFocus()} @blur=${t=>t.clearBtnOnBlurs()} @click="${(t,e)=>t.clearValue(e.event)}" @keypress=${(t,e)=>t.clearValue(e.event)} data-t="${t=>t.clearButtonTelemetryTag}"><span part="end" class="end-slot" ${(0,a.K)("endContainer")}><slot name="end" ${(0,a.K)("end")} @slotchange=${t=>t.handleEndContentChange()}>${t.clearContent||""}</slot></span></fluent-button>`)} ${(0,l.z)(t=>!t.showClearButton&&!t.isProngRubySearchBox,e)} `}(t))}</template>`}},6352(t,e,n){"use strict";n.d(e,{X(){return s}});var r=n(45755);const{create:i}=r.G,s=i("neutral-stroke-divider-rest-delta",8)},6608(t,e,n){"use strict";n.d(e,{PV(){return m},i8(){return v},nU(){return b},tS(){return g}});var r=n(14777),i=n(20468),s=n(88383),o=n(62044),a=n(89449),l=n(13765),c=n(39407),u="TelemetryPluginChain",h="_hasRun",d="_getTelCtx",f=0;function p(t,e,n,l){var c=null,u=[];null!==l&&(c=l?function(t,e,n){for(;t;){if(t[r.AP]()===n)return t;t=t[r.uR]()}return m([n],e[r.GA]||{},e)}(t,n,l):t);var h={_next(){var t=c;if(c=t?t[r.uR]():null,!t){var e=u;e&&e[r.oI]>0&&((0,o.Iu)(e,function(t){try{t.func[r.Ek](t.self,t.args)}catch(t){(0,i.ZP)(n[r.Uw],2,73,"Unexpected Exception during onComplete - "+(0,s.mm)(t))}}),u=[])}return t},ctx:{core(){return n},diagLog(){return(0,i.y0)(n,e)},getCfg(){return e},getExtCfg:d,getConfig(t,n,r){void 0===r&&(r=!1);var i,s=d(t,null);return s&&!(0,o.hX)(s[n])?i=s[n]:e&&!(0,o.hX)(e[n])&&(i=e[n]),(0,o.hX)(i)?r:i},hasNext(){return!!c},getNext(){return c},setNext(t){c=t},iterate(t){for(var e;e=h._next();){var n=e[r.AP]();n&&t(n)}},onComplete(t,e){for(var n=[],i=2;i<arguments.length;i++)n[i-2]=arguments[i];t&&u[r.y5]({func:t,self:(0,o.b0)(e)?h.ctx:e,args:n})}}};function d(t,n,r){var i;if(void 0===n&&(n={}),void 0===r&&(r=0),e){var s=e[a.Bw];s&&t&&(i=s[t])}if(i){if((0,o.Gv)(n)&&0!==r){var l=(0,o.CP)(!0,n,i);e&&2===r&&(0,o.z)(n,function(t){if((0,o.hX)(l[t])){var n=e[t];(0,o.hX)(n)||(l[t]=n)}}),i=l}}else i=n;return i}return h}function v(t,e,n,i){var s=p(t,e,n,i),l=s.ctx;return l[r.$5]=function(t){var e=s._next();return e&&e[a.qT](t,l),!e},l[r.$o]=function(t,i){return void 0===t&&(t=null),(0,o.cy)(t)&&(t=m(t,e,n,i)),v(t||l[r.uR](),e,n,i)},l}function g(t,e,n){var i=e[r.GA]||{},s=p(t,i,e,n),a=s.ctx;return a[r.$5]=function(t){var e=s._next();return e&&e.unload(a,t),!e},a[r.$o]=function(t,n){return void 0===t&&(t=null),(0,o.cy)(t)&&(t=m(t,i,e,n)),g(t||a[r.uR](),e,n)},a}function b(t,e,n){var i=e[r.GA]||{},s=p(t,i,e,n).ctx;return s[r.$5]=function(t){return s.iterate(function(e){(0,o.Tn)(e[r.HC])&&e[r.HC](s,t)})},s[r.$o]=function(t,n){return void 0===t&&(t=null),(0,o.cy)(t)&&(t=m(t,i,e,n)),b(t||s[r.uR](),e,n)},s}function m(t,e,n,p){var g=null,b=!p;if((0,o.cy)(t)&&t[r.oI]>0){var y=null;(0,o.Iu)(t,function(t){if(b||p!==t||(b=!0),b&&t&&(0,o.Tn)(t[a.qT])){var m=function(t,e,n){var p,g=null,b=(0,o.Tn)(t[a.qT]),m=(0,o.Tn)(t[r.YH]);p=t?t[r.Ju]+"-"+t[a.Vo]+"-"+f++:"Unknown-0-"+f++;var y={getPlugin(){return t},getNext(){return g},processTelemetry:x,unload:k,update:C,_id:p,_setNext(t){g=t}};function w(){var r;return t&&(0,o.Tn)(t[d])&&(r=t[d]()),r||(r=v(y,e,n)),r}function $(e,n,o,c,d){var f=!1,v=t?t[r.Ju]:u,b=e[h];return b||(b=e[h]={}),e.setNext(g),t&&(0,l.r2)(e[a.eT](),function(){return v+":"+o},function(){b[p]=!0;try{var t=g?g._id:a.m5;t&&(b[t]=!1),f=n(e)}catch(t){var l=!g||b[g._id];l&&(f=!0),g&&l||(0,i.ZP)(e[r.e4](),1,73,"Plugin ["+v+"] failed during "+o+" - "+(0,s.mm)(t)+", run flags: "+(0,s.mm)(b))}},c,d),f}function x(e,n){function i(n){if(!t||!b)return!1;var i=(0,c.Cr)(t);return!i[r.Ik]&&!i[a.Hr]&&(m&&t[r.YH](g),t[a.qT](e,n),!0)}$(n=n||w(),i,"processTelemetry",function(){return{item:e}},!e.sync)||n[r.$5](e)}function k(e,n){function i(){var i=!1;if(t){var s=(0,c.Cr)(t),o=t[a.eT]||s[a.eT];!t||o&&o!==e.core()||s[r.Ik]||(s[a.eT]=null,s[r.Ik]=!0,s[r.tZ]=!1,t[r.Ik]&&!0===t[r.Ik](e,n)&&(i=!0))}return i}$(e,i,"unload",function(){},n[r.tI])||e[r.$5](n)}function C(e,n){function i(){var i=!1;if(t){var s=(0,c.Cr)(t),o=t[a.eT]||s[a.eT];!t||o&&o!==e.core()||s[r.Ik]||t[r.HC]&&!0===t[r.HC](e,n)&&(i=!0)}return i}$(e,i,"update",function(){},!1)||e[r.$5](n)}return(0,o.N6)(y)}(t,e,n);g||(g=m),y&&y._setNext(m),y=m}})}return p&&!g?m([p],e,n):g}},6711(t,e,n){"use strict";n.d(e,{$P(){return l},DE(){return c},FX(){return a},L6(){return h},Mc(){return b},SL(){return f},Ws(){return g},l2(){return u},li(){return y},oR(){return s},oj(){return v},pW(){return m},q(){return p},ro(){return o},tN(){return d},vY(){return w}});var r=n(55609);function i(t){return e=>e&&void 0!==e[t]?e[t]:r.Ay[t]}const s=i("backgroundColor"),o=(i("accentBaseColor"),i("cornerRadius"),i("elevatedCornerRadius"),i("neutralPalette")),a=(i("accentPalette"),i("contrast"),i("designUnit"),i("baseHeightMultiplier"),i("baseHorizontalSpacingMultiplier"),i("direction"),i("outlineWidth")),l=i("focusOutlineWidth"),c=(i("disabledOpacity"),i("accentFillRestDelta"),i("accentFillHoverDelta"),i("accentFillActiveDelta"),i("accentFillFocusDelta"),i("accentFillSelectedDelta"),i("accentForegroundRestDelta"),i("accentForegroundHoverDelta"),i("accentForegroundActiveDelta"),i("accentForegroundFocusDelta"),i("neutralFillRestDelta")),u=i("neutralFillHoverDelta"),h=i("neutralFillActiveDelta"),d=i("neutralFillFocusDelta"),f=i("neutralFillSelectedDelta"),p=(i("neutralFillInputRestDelta"),i("neutralFillInputHoverDelta"),i("neutralFillInputActiveDelta"),i("neutralFillInputFocusDelta"),i("neutralFillInputSelectedDelta"),i("neutralFillStealthRestDelta")),v=i("neutralFillStealthHoverDelta"),g=i("neutralFillStealthActiveDelta"),b=i("neutralFillStealthFocusDelta"),m=i("neutralFillStealthSelectedDelta"),y=(i("neutralFillToggleHoverDelta"),i("neutralFillToggleActiveDelta"),i("neutralFillToggleFocusDelta"),i("baseLayerLuminance")),w=i("neutralFillCardDelta");i("neutralForegroundDarkIndex"),i("neutralForegroundLightIndex"),i("neutralForegroundHoverDelta"),i("neutralForegroundActiveDelta"),i("neutralForegroundFocusDelta"),i("neutralDividerRestDelta"),i("neutralOutlineRestDelta"),i("neutralOutlineHoverDelta"),i("neutralOutlineActiveDelta"),i("fontWeight"),i("neutralOutlineFocusDelta")},7040(t,e,n){"use strict";n.d(e,{Tk(){return m},dR(){return y},k6(){return w},pq(){return $}});var r,i,s,o=n(76989),a=n(87122),l=n(37820),c=n(6711),u=n(67860),h=n(24642);function d(t,e){return n=>-1===(0,c.li)(n)?e(n):t(n)}!function(t){t[t.L1=0]="L1",t[t.L1Alt=3]="L1Alt",t[t.L2=10]="L2",t[t.L3=13]="L3",t[t.L4=16]="L4"}(r||(r={})),function(t){t[t.L1=76]="L1",t[t.L1Alt=76]="L1Alt",t[t.L2=79]="L2",t[t.L3=82]="L3",t[t.L4=85]="L4"}(i||(i={})),function(t){t[t.LightMode=1]="LightMode",t[t.DarkMode=.23]="DarkMode"}(s||(s={}));const f=(0,u.F7)(c.ro,t=>{const e=(0,c.li)(t);return new a.M(e,e,e,1).toStringHexRGB()}),p=t=>(0,l.qE)((0,o.Re)(f,c.vY)(t),0,(0,c.ro)(t).length-1),v=(0,h.el)(c.DE,c.l2,c.L6),g=(0,h.el)((0,o.WQ)(f,c.vY),v),b=t=>{const e=.14,n=new a.M(e,e,e,1);return(0,u.F7)(c.ro,n.toStringHexRGB())(t)},m=(0,h.kT)(d((0,u.FD)((0,o.Re)(p,c.vY),c.ro),(0,u.jK)(c.ro)(0,(0,o.Re)(b,(0,o.lw)(c.vY,5))))),y=(0,h.kT)(d((0,u.FD)(p,c.ro),(0,u.jK)(c.ro)(0,(0,o.Re)(b,(0,o.lw)(c.vY,4))))),w=(0,h.kT)(d((0,u.FD)((0,o.WQ)(p,c.vY),c.ro),(0,u.jK)(c.ro)(c.vY,(0,o.Re)(b,(0,o.lw)(c.vY,3))))),$=((0,h.kT)(d((0,u.FD)(f,c.ro),(0,u.jK)(c.ro)(0,(0,o.Re)(b,(0,o.lw)(c.vY,3))))),(0,h.kT)(d((0,u.FD)(g,c.ro),(0,u.jK)(c.ro)(v,(0,o.Re)(b,(0,o.lw)(c.vY,2))))),(0,h.kT)(d((0,u.FD)((0,o.WQ)(g,c.vY),c.ro),(0,u.jK)(c.ro)((0,o.WQ)(v,c.vY),(0,o.Re)(b,c.vY)))),(0,h.kT)(d((0,u.FD)((0,o.WQ)(g,(0,o.lw)(c.vY,2)),c.ro),(0,u.jK)(c.ro)((0,o.WQ)(v,(0,o.lw)(c.vY,2)),b))))},7277(t){t.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12.01 2.25c.74 0 1.47.1 2.18.25.32.07.55.33.59.65l.17 1.53a1.38 1.38 0 001.92 1.11l1.4-.61c.3-.13.64-.06.85.17a9.8 9.8 0 012.2 3.8c.1.3 0 .63-.26.82l-1.24.92a1.38 1.38 0 000 2.22l1.24.92c.26.19.36.52.27.82a9.8 9.8 0 01-2.2 3.8.75.75 0 01-.85.17l-1.4-.62a1.38 1.38 0 00-1.93 1.12l-.17 1.52a.75.75 0 01-.58.65 9.52 9.52 0 01-4.4 0 .75.75 0 01-.57-.65l-.17-1.52a1.38 1.38 0 00-1.93-1.11l-1.4.62a.75.75 0 01-.85-.18 9.8 9.8 0 01-2.2-3.8c-.1-.3 0-.63.27-.82l1.24-.92a1.38 1.38 0 000-2.22l-1.24-.92a.75.75 0 01-.28-.82 9.8 9.8 0 012.2-3.8c.23-.23.57-.3.86-.17l1.4.62c.4.17.86.15 1.25-.08.38-.22.63-.6.68-1.04l.17-1.53a.75.75 0 01.58-.65c.72-.16 1.45-.24 2.2-.25zM12 9a3 3 0 100 6 3 3 0 000-6z"></path></svg>'},7511(t,e,n){"use strict";n.d(e,{I(){return h},_(){return u}});var r=n(56911),i=n(60815),s=n(92011),o=n(38493),a=n(29025),l=n(35106),c=n(88458);class u extends s.L{constructor(){super(...arguments),this.handleUnsupportedDelegatesFocus=()=>{window.ShadowRoot&&!window.ShadowRoot.prototype.hasOwnProperty("delegatesFocus")&&this.$fastController.definition.shadowOptions?.delegatesFocus&&(this.focus=()=>{this.control.focus()})}}connectedCallback(){super.connectedCallback(),this.handleUnsupportedDelegatesFocus()}}(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],u.prototype,"download",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],u.prototype,"href",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],u.prototype,"hreflang",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],u.prototype,"ping",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],u.prototype,"referrerpolicy",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],u.prototype,"rel",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],u.prototype,"target",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],u.prototype,"type",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Array)],u.prototype,"defaultSlottedContent",void 0);class h{}(0,r.Cg)([(0,o.CF)({attribute:"aria-expanded"}),(0,r.Sn)("design:type",Object)],h.prototype,"ariaExpanded",void 0),(0,c.X)(h,a.z),(0,c.X)(u,l.qw,h)},7813(t,e,n){"use strict";n.d(e,{I(){return d}});var r=n(96293),i=n(60815),s=n(19470),o=n(81263),a=n(38493);const l={mode:"open"},c={},u=new Set,h=s.Zx.getById(r.uL.elementRegistry,()=>(0,s.Mg)());class d{constructor(t,e=t.definition){var n;this.platformDefined=!1,(0,r.Kg)(e)&&(e={name:e}),this.type=t,this.name=e.name,this.template=e.template,this.registry=null!==(n=e.registry)&&void 0!==n?n:customElements;const s=t.prototype,u=a.O1.collect(t,e.attributes),d=new Array(u.length),f={},p={};for(let t=0,e=u.length;t<e;++t){const e=u[t];d[t]=e.attribute,f[e.name]=e,p[e.attribute]=e,i.cP.defineProperty(s,e)}Reflect.defineProperty(t,"observedAttributes",{value:d,enumerable:!0}),this.attributes=u,this.propertyLookup=f,this.attributeLookup=p,this.shadowOptions=void 0===e.shadowOptions?l:null===e.shadowOptions?void 0:{...l,...e.shadowOptions},this.elementOptions=void 0===e.elementOptions?c:{...c,...e.elementOptions},this.styles=o.v.normalize(e.styles),h.register(this)}get isDefined(){return this.platformDefined}define(t=this.registry){const e=this.type;return t.get(this.name)||(this.platformDefined=!0,t.define(this.name,e,this.elementOptions)),this}static compose(t,e){return u.has(t)||h.getByType(t)?new d(class extends t{},e):new d(t,e)}static registerBaseType(t){u.add(t)}}d.getByType=h.getByType,d.getForInstance=h.getForInstance},7896(t,e,n){"use strict";n.d(e,{O(){return s}});var r=n(45755);const{create:i}=r.G,s=i("body-font","Segoe UI, Segoe UI Midlevel, sans-serif")},7927(t,e,n){"use strict";n.d(e,{m(){return b}});var r=n(56911),i=n(92011),s=n(23429),o=n(38493),a=n(60815),l=n(31157),c=n(73473),u=n(42938);class h extends i.L{constructor(){super(...arguments),this.anchor="",this.viewport="",this.horizontalPositioningMode="uncontrolled",this.horizontalDefaultPosition="unset",this.horizontalViewportLock=!1,this.horizontalInset=!1,this.horizontalScaling="content",this.verticalPositioningMode="uncontrolled",this.verticalDefaultPosition="unset",this.verticalViewportLock=!1,this.verticalInset=!1,this.verticalScaling="content",this.fixedPlacement=!1,this.autoUpdateMode="anchor",this.anchorElement=null,this.viewportElement=null,this.initialLayoutComplete=!1,this.resizeDetector=null,this.baseHorizontalOffset=0,this.baseVerticalOffset=0,this.pendingPositioningUpdate=!1,this.pendingReset=!1,this.currentDirection=l.O.ltr,this.regionVisible=!1,this.forceUpdate=!1,this.updateThreshold=.5,this.update=()=>{this.pendingPositioningUpdate||this.requestPositionUpdates()},this.startObservers=()=>{this.stopObservers(),null!==this.anchorElement&&(this.requestPositionUpdates(),null!==this.resizeDetector&&(this.resizeDetector.observe(this.anchorElement),this.resizeDetector.observe(this)))},this.requestPositionUpdates=()=>{null===this.anchorElement||this.pendingPositioningUpdate||(h.intersectionService.requestPosition(this,this.handleIntersection),h.intersectionService.requestPosition(this.anchorElement,this.handleIntersection),null!==this.viewportElement&&h.intersectionService.requestPosition(this.viewportElement,this.handleIntersection),this.pendingPositioningUpdate=!0)},this.stopObservers=()=>{this.pendingPositioningUpdate&&(this.pendingPositioningUpdate=!1,h.intersectionService.cancelRequestPosition(this,this.handleIntersection),null!==this.anchorElement&&h.intersectionService.cancelRequestPosition(this.anchorElement,this.handleIntersection),null!==this.viewportElement&&h.intersectionService.cancelRequestPosition(this.viewportElement,this.handleIntersection)),null!==this.resizeDetector&&this.resizeDetector.disconnect()},this.getViewport=()=>{if("string"!=typeof this.viewport||""===this.viewport)return document.documentElement;const t=this.getRootNode();return t instanceof ShadowRoot?t.getElementById(this.viewport):document.getElementById(this.viewport)},this.getAnchor=()=>{const t=this.getRootNode();return t instanceof ShadowRoot?t.getElementById(this.anchor):document.getElementById(this.anchor)},this.handleIntersection=t=>{this.pendingPositioningUpdate&&(this.pendingPositioningUpdate=!1,this.applyIntersectionEntries(t)&&this.updateLayout())},this.applyIntersectionEntries=t=>{const e=t.find(t=>t.target===this),n=t.find(t=>t.target===this.anchorElement),r=t.find(t=>t.target===this.viewportElement);return void 0!==e&&void 0!==r&&void 0!==n&&(!!(!this.regionVisible||this.forceUpdate||void 0===this.regionRect||void 0===this.anchorRect||void 0===this.viewportRect||this.isRectDifferent(this.anchorRect,n.boundingClientRect)||this.isRectDifferent(this.viewportRect,r.boundingClientRect)||this.isRectDifferent(this.regionRect,e.boundingClientRect))&&(this.regionRect=e.boundingClientRect,this.anchorRect=n.boundingClientRect,this.viewportElement===document.documentElement?this.viewportRect=new DOMRectReadOnly(r.boundingClientRect.x+document.documentElement.scrollLeft,r.boundingClientRect.y+document.documentElement.scrollTop,r.boundingClientRect.width,r.boundingClientRect.height):this.viewportRect=r.boundingClientRect,this.updateRegionOffset(),this.forceUpdate=!1,!0))},this.updateRegionOffset=()=>{this.anchorRect&&this.regionRect&&(this.baseHorizontalOffset=this.baseHorizontalOffset+(this.anchorRect.left-this.regionRect.left)+(this.translateX-this.baseHorizontalOffset),this.baseVerticalOffset=this.baseVerticalOffset+(this.anchorRect.top-this.regionRect.top)+(this.translateY-this.baseVerticalOffset))},this.isRectDifferent=(t,e)=>Math.abs(t.top-e.top)>this.updateThreshold||Math.abs(t.right-e.right)>this.updateThreshold||Math.abs(t.bottom-e.bottom)>this.updateThreshold||Math.abs(t.left-e.left)>this.updateThreshold,this.handleResize=t=>{this.update()},this.reset=()=>{this.pendingReset&&(this.pendingReset=!1,null===this.anchorElement&&(this.anchorElement=this.getAnchor()),null===this.viewportElement&&(this.viewportElement=this.getViewport()),this.currentDirection=(0,u.u)(this),this.startObservers())},this.updateLayout=()=>{let t,e;if("uncontrolled"!==this.horizontalPositioningMode){const t=this.getPositioningOptions(this.horizontalInset);if("center"===this.horizontalDefaultPosition)e="center";else if("unset"!==this.horizontalDefaultPosition){let t=this.horizontalDefaultPosition;if("start"===t||"end"===t){const e=(0,u.u)(this);if(e!==this.currentDirection)return this.currentDirection=e,void this.initialize();t=this.currentDirection===l.O.ltr?"start"===t?"left":"right":"start"===t?"right":"left"}switch(t){case"left":e=this.horizontalInset?"insetStart":"start";break;case"right":e=this.horizontalInset?"insetEnd":"end"}}const n=void 0!==this.horizontalThreshold?this.horizontalThreshold:void 0!==this.regionRect?this.regionRect.width:0,r=void 0!==this.anchorRect?this.anchorRect.left:0,i=void 0!==this.anchorRect?this.anchorRect.right:0,s=void 0!==this.anchorRect?this.anchorRect.width:0,o=void 0!==this.viewportRect?this.viewportRect.left:0,a=void 0!==this.viewportRect?this.viewportRect.right:0;(void 0===e||"locktodefault"!==this.horizontalPositioningMode&&this.getAvailableSpace(e,r,i,s,o,a)<n)&&(e=this.getAvailableSpace(t[0],r,i,s,o,a)>this.getAvailableSpace(t[1],r,i,s,o,a)?t[0]:t[1])}if("uncontrolled"!==this.verticalPositioningMode){const e=this.getPositioningOptions(this.verticalInset);if("center"===this.verticalDefaultPosition)t="center";else if("unset"!==this.verticalDefaultPosition)switch(this.verticalDefaultPosition){case"top":t=this.verticalInset?"insetStart":"start";break;case"bottom":t=this.verticalInset?"insetEnd":"end"}const n=void 0!==this.verticalThreshold?this.verticalThreshold:void 0!==this.regionRect?this.regionRect.height:0,r=void 0!==this.anchorRect?this.anchorRect.top:0,i=void 0!==this.anchorRect?this.anchorRect.bottom:0,s=void 0!==this.anchorRect?this.anchorRect.height:0,o=void 0!==this.viewportRect?this.viewportRect.top:0,a=void 0!==this.viewportRect?this.viewportRect.bottom:0;(void 0===t||"locktodefault"!==this.verticalPositioningMode&&this.getAvailableSpace(t,r,i,s,o,a)<n)&&(t=this.getAvailableSpace(e[0],r,i,s,o,a)>this.getAvailableSpace(e[1],r,i,s,o,a)?e[0]:e[1])}const n=this.getNextRegionDimension(e,t),r=this.horizontalPosition!==e||this.verticalPosition!==t;if(this.setHorizontalPosition(e,n),this.setVerticalPosition(t,n),this.updateRegionStyle(),!this.initialLayoutComplete)return this.initialLayoutComplete=!0,void this.requestPositionUpdates();this.regionVisible||(this.regionVisible=!0,this.style.removeProperty("pointer-events"),this.style.removeProperty("opacity"),this.classList.toggle("loaded",!0),this.$emit("loaded",this,{bubbles:!1})),this.updatePositionClasses(),r&&this.$emit("positionchange",this,{bubbles:!1})},this.updateRegionStyle=()=>{this.style.width=this.regionWidth,this.style.height=this.regionHeight,this.style.transform=`translate(${this.translateX}px, ${this.translateY}px)`},this.updatePositionClasses=()=>{this.classList.toggle("top","start"===this.verticalPosition),this.classList.toggle("bottom","end"===this.verticalPosition),this.classList.toggle("inset-top","insetStart"===this.verticalPosition),this.classList.toggle("inset-bottom","insetEnd"===this.verticalPosition),this.classList.toggle("vertical-center","center"===this.verticalPosition),this.classList.toggle("left","start"===this.horizontalPosition),this.classList.toggle("right","end"===this.horizontalPosition),this.classList.toggle("inset-left","insetStart"===this.horizontalPosition),this.classList.toggle("inset-right","insetEnd"===this.horizontalPosition),this.classList.toggle("horizontal-center","center"===this.horizontalPosition)},this.setHorizontalPosition=(t,e)=>{if(void 0===t||void 0===this.regionRect||void 0===this.anchorRect||void 0===this.viewportRect)return;let n=0;switch(this.horizontalScaling){case"anchor":case"fill":n=this.horizontalViewportLock?this.viewportRect.width:e.width,this.regionWidth=`${n}px`;break;case"content":n=this.regionRect.width,this.regionWidth="unset"}let r=0;switch(t){case"start":this.translateX=this.baseHorizontalOffset-n,this.horizontalViewportLock&&this.anchorRect.left>this.viewportRect.right&&(this.translateX=this.translateX-(this.anchorRect.left-this.viewportRect.right));break;case"insetStart":this.translateX=this.baseHorizontalOffset-n+this.anchorRect.width,this.horizontalViewportLock&&this.anchorRect.right>this.viewportRect.right&&(this.translateX=this.translateX-(this.anchorRect.right-this.viewportRect.right));break;case"insetEnd":this.translateX=this.baseHorizontalOffset,this.horizontalViewportLock&&this.anchorRect.left<this.viewportRect.left&&(this.translateX=this.translateX-(this.anchorRect.left-this.viewportRect.left));break;case"end":this.translateX=this.baseHorizontalOffset+this.anchorRect.width,this.horizontalViewportLock&&this.anchorRect.right<this.viewportRect.left&&(this.translateX=this.translateX-(this.anchorRect.right-this.viewportRect.left));break;case"center":if(r=(this.anchorRect.width-n)/2,this.translateX=this.baseHorizontalOffset+r,this.horizontalViewportLock){const t=this.anchorRect.left+r,e=this.anchorRect.right-r;t<this.viewportRect.left&&!(e>this.viewportRect.right)?this.translateX=this.translateX-(t-this.viewportRect.left):e>this.viewportRect.right&&!(t<this.viewportRect.left)&&(this.translateX=this.translateX-(e-this.viewportRect.right))}}this.horizontalPosition=t},this.setVerticalPosition=(t,e)=>{if(void 0===t||void 0===this.regionRect||void 0===this.anchorRect||void 0===this.viewportRect)return;let n=0;switch(this.verticalScaling){case"anchor":case"fill":n=this.verticalViewportLock?this.viewportRect.height:e.height,this.regionHeight=`${n}px`;break;case"content":n=this.regionRect.height,this.regionHeight="unset"}let r=0;switch(t){case"start":this.translateY=this.baseVerticalOffset-n,this.verticalViewportLock&&this.anchorRect.top>this.viewportRect.bottom&&(this.translateY=this.translateY-(this.anchorRect.top-this.viewportRect.bottom));break;case"insetStart":this.translateY=this.baseVerticalOffset-n+this.anchorRect.height,this.verticalViewportLock&&this.anchorRect.bottom>this.viewportRect.bottom&&(this.translateY=this.translateY-(this.anchorRect.bottom-this.viewportRect.bottom));break;case"insetEnd":this.translateY=this.baseVerticalOffset,this.verticalViewportLock&&this.anchorRect.top<this.viewportRect.top&&(this.translateY=this.translateY-(this.anchorRect.top-this.viewportRect.top));break;case"end":this.translateY=this.baseVerticalOffset+this.anchorRect.height,this.verticalViewportLock&&this.anchorRect.bottom<this.viewportRect.top&&(this.translateY=this.translateY-(this.anchorRect.bottom-this.viewportRect.top));break;case"center":if(r=(this.anchorRect.height-n)/2,this.translateY=this.baseVerticalOffset+r,this.verticalViewportLock){const t=this.anchorRect.top+r,e=this.anchorRect.bottom-r;t<this.viewportRect.top&&!(e>this.viewportRect.bottom)?this.translateY=this.translateY-(t-this.viewportRect.top):e>this.viewportRect.bottom&&!(t<this.viewportRect.top)&&(this.translateY=this.translateY-(e-this.viewportRect.bottom))}}this.verticalPosition=t},this.getPositioningOptions=t=>t?["insetStart","insetEnd"]:["start","end"],this.getAvailableSpace=(t,e,n,r,i,s)=>{const o=e-i,a=s-(e+r);switch(t){case"start":return o;case"insetStart":return o+r;case"insetEnd":return a+r;case"end":return a;case"center":return 2*Math.min(o,a)+r}},this.getNextRegionDimension=(t,e)=>{const n={height:void 0!==this.regionRect?this.regionRect.height:0,width:void 0!==this.regionRect?this.regionRect.width:0};return void 0!==t&&"fill"===this.horizontalScaling?n.width=this.getAvailableSpace(t,void 0!==this.anchorRect?this.anchorRect.left:0,void 0!==this.anchorRect?this.anchorRect.right:0,void 0!==this.anchorRect?this.anchorRect.width:0,void 0!==this.viewportRect?this.viewportRect.left:0,void 0!==this.viewportRect?this.viewportRect.right:0):"anchor"===this.horizontalScaling&&(n.width=void 0!==this.anchorRect?this.anchorRect.width:0),void 0!==e&&"fill"===this.verticalScaling?n.height=this.getAvailableSpace(e,void 0!==this.anchorRect?this.anchorRect.top:0,void 0!==this.anchorRect?this.anchorRect.bottom:0,void 0!==this.anchorRect?this.anchorRect.height:0,void 0!==this.viewportRect?this.viewportRect.top:0,void 0!==this.viewportRect?this.viewportRect.bottom:0):"anchor"===this.verticalScaling&&(n.height=void 0!==this.anchorRect?this.anchorRect.height:0),n},this.startAutoUpdateEventListeners=()=>{window.addEventListener(c.zs,this.update,{passive:!0}),window.addEventListener(c.oQ,this.update,{passive:!0,capture:!0}),null!==this.resizeDetector&&null!==this.viewportElement&&this.resizeDetector.observe(this.viewportElement)},this.stopAutoUpdateEventListeners=()=>{window.removeEventListener(c.zs,this.update),window.removeEventListener(c.oQ,this.update),null!==this.resizeDetector&&null!==this.viewportElement&&this.resizeDetector.unobserve(this.viewportElement)}}anchorChanged(){this.initialLayoutComplete&&(this.anchorElement=this.getAnchor())}viewportChanged(){this.initialLayoutComplete&&(this.viewportElement=this.getViewport())}horizontalPositioningModeChanged(){this.requestReset()}horizontalDefaultPositionChanged(){this.updateForAttributeChange()}horizontalViewportLockChanged(){this.updateForAttributeChange()}horizontalInsetChanged(){this.updateForAttributeChange()}horizontalThresholdChanged(){this.updateForAttributeChange()}horizontalScalingChanged(){this.updateForAttributeChange()}verticalPositioningModeChanged(){this.requestReset()}verticalDefaultPositionChanged(){this.updateForAttributeChange()}verticalViewportLockChanged(){this.updateForAttributeChange()}verticalInsetChanged(){this.updateForAttributeChange()}verticalThresholdChanged(){this.updateForAttributeChange()}verticalScalingChanged(){this.updateForAttributeChange()}fixedPlacementChanged(){this.$fastController.isConnected&&this.initialLayoutComplete&&this.initialize()}autoUpdateModeChanged(t,e){this.$fastController.isConnected&&this.initialLayoutComplete&&("auto"===t&&this.stopAutoUpdateEventListeners(),"auto"===e&&this.startAutoUpdateEventListeners())}anchorElementChanged(){this.requestReset()}viewportElementChanged(){this.$fastController.isConnected&&this.initialLayoutComplete&&this.initialize()}connectedCallback(){super.connectedCallback(),"auto"===this.autoUpdateMode&&this.startAutoUpdateEventListeners(),this.initialize()}disconnectedCallback(){super.disconnectedCallback(),"auto"===this.autoUpdateMode&&this.stopAutoUpdateEventListeners(),this.stopObservers(),this.disconnectResizeDetector()}adoptedCallback(){this.initialize()}disconnectResizeDetector(){null!==this.resizeDetector&&(this.resizeDetector.disconnect(),this.resizeDetector=null)}initializeResizeDetector(){this.disconnectResizeDetector(),this.resizeDetector=new window.ResizeObserver(this.handleResize)}updateForAttributeChange(){this.$fastController.isConnected&&this.initialLayoutComplete&&(this.forceUpdate=!0,this.update())}initialize(){this.initializeResizeDetector(),null===this.anchorElement&&(this.anchorElement=this.getAnchor()),this.requestReset()}requestReset(){this.$fastController.isConnected&&!1===this.pendingReset&&(this.setInitialState(),s.L.enqueue(()=>this.reset()),this.pendingReset=!0)}setInitialState(){this.initialLayoutComplete=!1,this.regionVisible=!1,this.translateX=0,this.translateY=0,this.baseHorizontalOffset=0,this.baseVerticalOffset=0,this.viewportRect=void 0,this.regionRect=void 0,this.anchorRect=void 0,this.verticalPosition=void 0,this.horizontalPosition=void 0,this.style.opacity="0",this.style.pointerEvents="none",this.forceUpdate=!1,this.style.position=this.fixedPlacement?"fixed":"absolute",this.updatePositionClasses(),this.updateRegionStyle()}}h.intersectionService=new class{constructor(){this.intersectionDetector=null,this.observedElements=new Map,this.requestPosition=(t,e)=>{null!==this.intersectionDetector&&(this.observedElements.has(t)?this.observedElements.get(t)?.push(e):(this.observedElements.set(t,[e]),this.intersectionDetector.observe(t)))},this.cancelRequestPosition=(t,e)=>{const n=this.observedElements.get(t);if(void 0!==n){const t=n.indexOf(e);-1!==t&&n.splice(t,1)}},this.initializeIntersectionDetector=()=>{globalThis.IntersectionObserver&&(this.intersectionDetector=new IntersectionObserver(this.handleIntersection,{root:null,rootMargin:"0px",threshold:[0,1]}))},this.handleIntersection=t=>{if(null===this.intersectionDetector)return;const e=[],n=[];t.forEach(t=>{this.intersectionDetector?.unobserve(t.target);const r=this.observedElements.get(t.target);void 0!==r&&(r.forEach(r=>{let i=e.indexOf(r);-1===i&&(i=e.length,e.push(r),n.push([])),n[i].push(t)}),this.observedElements.delete(t.target))}),e.forEach((t,e)=>{t(n[e])})},this.initializeIntersectionDetector()}},(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],h.prototype,"anchor",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],h.prototype,"viewport",void 0),(0,r.Cg)([(0,o.CF)({attribute:"horizontal-positioning-mode"}),(0,r.Sn)("design:type",String)],h.prototype,"horizontalPositioningMode",void 0),(0,r.Cg)([(0,o.CF)({attribute:"horizontal-default-position"}),(0,r.Sn)("design:type",String)],h.prototype,"horizontalDefaultPosition",void 0),(0,r.Cg)([(0,o.CF)({attribute:"horizontal-viewport-lock",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],h.prototype,"horizontalViewportLock",void 0),(0,r.Cg)([(0,o.CF)({attribute:"horizontal-inset",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],h.prototype,"horizontalInset",void 0),(0,r.Cg)([(0,o.CF)({attribute:"horizontal-threshold"}),(0,r.Sn)("design:type",Number)],h.prototype,"horizontalThreshold",void 0),(0,r.Cg)([(0,o.CF)({attribute:"horizontal-scaling"}),(0,r.Sn)("design:type",String)],h.prototype,"horizontalScaling",void 0),(0,r.Cg)([(0,o.CF)({attribute:"vertical-positioning-mode"}),(0,r.Sn)("design:type",String)],h.prototype,"verticalPositioningMode",void 0),(0,r.Cg)([(0,o.CF)({attribute:"vertical-default-position"}),(0,r.Sn)("design:type",String)],h.prototype,"verticalDefaultPosition",void 0),(0,r.Cg)([(0,o.CF)({attribute:"vertical-viewport-lock",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],h.prototype,"verticalViewportLock",void 0),(0,r.Cg)([(0,o.CF)({attribute:"vertical-inset",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],h.prototype,"verticalInset",void 0),(0,r.Cg)([(0,o.CF)({attribute:"vertical-threshold"}),(0,r.Sn)("design:type",Number)],h.prototype,"verticalThreshold",void 0),(0,r.Cg)([(0,o.CF)({attribute:"vertical-scaling"}),(0,r.Sn)("design:type",String)],h.prototype,"verticalScaling",void 0),(0,r.Cg)([(0,o.CF)({attribute:"fixed-placement",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],h.prototype,"fixedPlacement",void 0),(0,r.Cg)([(0,o.CF)({attribute:"auto-update-mode"}),(0,r.Sn)("design:type",String)],h.prototype,"autoUpdateMode",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Object)],h.prototype,"anchorElement",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Object)],h.prototype,"viewportElement",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Boolean)],h.prototype,"initialLayoutComplete",void 0);var d=n(37180);const f=n(74849).A`
    :host {
        contain: layout;
        display: block;
    }
`;var p=n(96950),v=n(69259);const g=p.qy`
        <template data-loaded="${t=>t.initialLayoutComplete?"loaded":""}">
            ${(0,v.z)(t=>t.initialLayoutComplete,p.qy`
                    <slot></slot>
                `)}
        </template>
    `,b=h.compose({name:`${d.c.prefix}-anchored-region`,template:g,styles:f})},8107(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M10.06 2.45a1.5 1.5 0 00-2.39.35L5.65 6.59l-2.8.94a.5.5 0 00-.2.82l2.14 2.15-2.64 2.65L2 14l.85-.15 2.65-2.64 2.15 2.14a.5.5 0 00.82-.2l.94-2.8 3.78-2.03a1.5 1.5 0 00.35-2.38l-3.48-3.5z"></path></svg>'},8315(t,e,n){"use strict";n.d(e,{WF(){return a},YO(){return o},a9(){return s},k7(){return l}});var r=n(45755);const{create:i}=r.G,s=i("neutral-fill-strong-rest-delta",0),o=i("neutral-fill-strong-hover-delta",8),a=i("neutral-fill-strong-active-delta",-5),l=i("neutral-fill-strong-focus-delta",0)},10108(t,e,n){"use strict";n.d(e,{Y(){return o},u(){return a}});var r=n(19470),i=n(29194);const s=t=>1===t.nodeType,o=t=>t?e=>1===e.nodeType&&e.matches(t):s;class a extends i.Yi{get id(){return this._id}set id(t){this._id=t,this._controllerProperty=`${t}-c`}bind(t){const e=t.targets[this.targetNodeId];e[this._controllerProperty]=t,this.updateTarget(t.source,this.computeNodes(e)),this.observe(e),t.onUnbind(this)}unbind(t){const e=t.targets[this.targetNodeId];this.updateTarget(t.source,r.tR),this.disconnect(e),e[this._controllerProperty]=null}getSource(t){return t[this._controllerProperty].source}updateTarget(t,e){t[this.options.property]=e}computeNodes(t){let e=this.getNodes(t);return"filter"in this.options&&(e=e.filter(this.options.filter)),e}}},10735(t,e,n){"use strict";n.d(e,{T(){return u}});var r=n(45755),i=n(97004),s=n(47691),o=n(356),a=n(31023);const{create:l}=r.G,c=l({name:"neutral-layer-floating-recipe"},{evaluate(t){return function(t,e,n){const r=t.closestIndexOf((0,i.Z)(e))-n;return t.get(r-n)}(t(a.r),t(o.l),t(s.E))}}),u=l("neutral-layer-floating",t=>t(c).evaluate(t))},11152(t,e,n){"use strict";n.d(e,{R7(){return O},x7(){return F},x9(){return D}});var r=n(60993),i=n(64187),s=n(22131),o=n(73477),a=n(74849),l=n(50882),c=n(37998),u=n(48196),h=n(17767),d=n(57416),f=n(41123),p=n(64699),v=n(14996),g=n(74838),b=n(4283),m=n(79288),y=n(7896),w=n(74089),$=n(26920),x=n(37302),k=n(46203),C=n(45476),S=n(48751),E=n(10735),M=n(36452);const F=a.A`
    :host([appearance="filled"]) {
        background: ${x.F7};
        border-color: transparent;
    }

    :host([appearance="filled"]:hover:not([disabled])) {
        background: ${x.Xt};
        border-color: transparent;
    }

    :host([appearance="filled"]:${o.N}) {
        border-color: ${v.WN};
    }
`,D=a.A`
    ${(0,i.V)("inline-flex")} :host {
        --elevation: 14;
        background: ${k.le};
        border-radius: calc(${d.Pb} * 1px);
        border: calc(${$.XA} * 1px) solid ${M.I2};
        box-sizing: border-box;
        color: ${S.l};
        font-family: ${y.O};
        height: calc(${u.D} * 1px);
        position: relative;
        user-select: none;
        min-width: 250px;
        vertical-align: top;
    }

    .listbox {
        ${c.ET}
        background: ${E.T};
        border-radius: calc(${d.Pb} * 1px);
        box-sizing: border-box;
        display: inline-flex;
        flex-direction: column;
        left: 0;
        max-height: calc(var(--max-height) - (${u.D} * 1px));
        padding: calc(${g.vR} * 1px) 0;
        overflow-y: auto;
        position: fixed;
        top: 0;
        z-index: 1;
        margin: 1px 0;
    }

    .listbox[hidden] {
        display: none;
    }

    .control {
        align-items: center;
        box-sizing: border-box;
        cursor: pointer;
        display: flex;
        font-size: ${f.K};
        font-family: inherit;
        min-height: 100%;
        line-height: ${f.Z};
        padding: 0 calc(${g.vR} * 2.25px);
        width: 100%;
    }

    :host(:not([disabled]):hover) {
        background: ${k.jM};
        border-color: ${M.mb};
    }

    :host(:focus) {
        outline: none;
    }

    :host(:${o.N}) {
        border-color: ${v.WN};
        outline: none;
        box-shadow: 0 0 0 1px inset ${v.WN};
    }

    :host([open]:${o.N}) {
        border-color: ${M.I2};
        outline: none;
        box-shadow: none;
    }

    :host(:${o.N}) ::slotted([aria-selected="true"][role="option"]:not([disabled])) {
        box-shadow: 0 0 0 calc(${$.vd} * 1px) inset ${p.fF};
        border-color: ${v.WN};
        background: ${b.KJ};
        color: ${w.Bg};
    }

    :host([disabled]) {
        cursor: ${r.Z};
        opacity: ${m.q};
    }

    :host([disabled]) .control {
        cursor: ${r.Z};
        user-select: none;
    }

    :host([disabled]:hover) {
        background: ${C.Wl};
        color: ${S.l};
        fill: currentcolor;
    }

    :host(:not([disabled])) .control:active {
        background: ${k.RS};
        border-color: ${M.MY};
        border-radius: calc(${d.Pb} * 1px);
    }

    .selected-value {
        font-family: inherit;
        flex: 1 1 auto;
        text-align: start;
    }

    .indicator {
        flex: 0 0 auto;
        margin-inline-start: 1em;
    }

    ::slotted([name="listbox"]) {
        display: none;
        width: 100%;
    }

    :host([open]) ::slotted([name="listbox"]) {
        display: flex;
        position: absolute;
        ${c.ET}
    }

    ::slotted([slot="end"]) {
        margin-inline-start: auto;
    }

    ::slotted([slot="start"]),
    ::slotted([slot="end"]),
    .indicator,
    .select-indicator,
    ::slotted(svg) {
        ${""}
        fill: currentcolor;
        height: 1em;
        min-height: calc(${g.vR} * 4px);
        min-width: calc(${g.vR} * 4px);
        width: 1em;
    }

    ::slotted([role="option"]) {
        flex: 0 0 auto;
    }
`.withBehaviors((0,h.f)("filled",F),(0,s.mr)(a.A`
            :host([disabled]) {
                border-color: ${l.A.GrayText};
                background-color: ${l.A.ButtonFace};
                color: ${l.A.GrayText};
                opacity: 1;
                forced-color-adjust: none;
            }

            :host([disabled]:hover) {
                background: ${l.A.ButtonFace};
            }

            :host([disabled]) .control {
                color: ${l.A.GrayText};
                border-color: ${l.A.GrayText};
            }

            :host(:not([disabled]):hover) {
                background: ${l.A.ButtonFace};
                border-color: ${l.A.Highlight};
            }

            :host(:${o.N}) {
                forced-color-adjust: none;
                background: ${l.A.ButtonFace};
                border-color: ${l.A.Highlight};
                box-shadow: 0 0 0 1px inset ${l.A.Highlight};
                color: ${l.A.ButtonText};
                fill: currentcolor;
            }

            :host([open]) .listbox {
                background: ${l.A.ButtonFace};
                border: 1px solid ${l.A.ButtonText};
            }

            :host(:${o.N}) ::slotted([aria-selected="true"][role="option"]:not([disabled])) {
                background: ${l.A.Highlight};
                border-color: ${l.A.ButtonText};
                box-shadow: 0 0 0 calc(${$.vd} * 1px) inset
                    ${l.A.HighlightText};
                color: ${l.A.HighlightText};
                fill: currentcolor;
            }

            ::slotted([role="option"]:not([aria-selected="true"]):not([disabled]):hover) {
                forced-color-adjust: none;
                color: ${l.A.ButtonText};
                background: ${l.A.ButtonFace};
                border-color: ${l.A.Highlight};
                box-shadow: none;
            }
        `)),O=a.A`
    ${D}
`},12640(t,e,n){"use strict";n.d(e,{N(){return u},e(){return c}});var r=n(97004),i=n(95239),s=n(14848),o=n(22870),a=n(23429);const l=(0,n(18284).A)(t=>{let e=(0,o.Hs)(t);if(null!==e)return e;if(e=(0,o.QI)(t),null!==e)return e;throw new Error(`${t} cannot be converted to a ColorRGBA64. Color strings must be one of the following formats: "#RGB", "#RRGGBB", or "rgb(r, g, b)"`)});function c(t){return(0,s.Z8)(l(t))}class u{constructor(t,e){this.cache=new WeakMap,this.light=t,this.dark=e}connectedCallback(t){const e=t.source,n=this.cache.get(e);n?a.L.enqueue(()=>this.attach(e,n)):this.attach(e,new h(this.light,this.dark,e))}disconnectedCallback(t){const e=this.cache.get(t.source);e&&i.p.unsubscribe(e)}attach(t,e){const n=i.p.getValueFor(t);i.p.subscribe(e),e.attach(n),this.cache.set(t,e)}}class h{constructor(t,e,n){this.light=t,this.dark=e,this.source=n,this.attached=null}handleChange(t,e){try{this.attach("default"===e.target?t.default:t.getValueFor(this.source))}catch{}}attach(t){if(window.matchMedia("(forced-colors: active)").matches)return;const e=c(t.toColorString())<=r.y.DarkMode?"dark":"light";window.__theme=e,this.attached!==this[e]&&(null!==this.attached&&this.source.$fastController.removeStyles(this.attached),this.attached=this[e],null!==this.attached&&this.source.$fastController.addStyles(this.attached))}}},12839(t,e,n){"use strict";n.d(e,{It(){return I},d5(){return x},gi(){return M},um(){return S},xN(){return E}});var r=n(14777),i=n(20468),s=n(88383),o=n(62044),a=n(89449),l="toGMTString",c="toUTCString",u="cookie",h="expires",d="enabled",f="isCookieUseDisabled",p="disableCookiesUsage",v="_ckMgr",g=null,b=null,m=null,y=(0,s.YE)(),w={},$={};function x(t,e){var n=E[v]||$[v];return n||(n=E[v]=E(t,e),$[v]=n),n}function k(t){return!t||t.isEnabled()}function C(t,e){return!!(e&&t&&(0,o.cy)(t.ignoreCookies))&&-1!==t.ignoreCookies[r.Sj](e)}function S(t,e){var n;if(t)n=t.getCookieMgr();else if(e){var i=e[r.lK];n=i[v]?i[v]:E(e)}return n||(n=x(e,(t||{})[r.Uw])),n}function E(t,e){var n,i=function(t){var e=t[r.lK]=t[r.lK]||{};if((0,o.KY)(e,"domain",t.cookieDomain,o.Gh,o.hX),(0,o.KY)(e,"path",t.cookiePath||"/",null,o.hX),(0,o.hX)(e[d])){var n=void 0;(0,o.b0)(t[f])||(n=!t[f]),(0,o.b0)(t[p])||(n=!t[p]),e[d]=n}return e}(t||$),u=i.path||"/",g=i.domain,m=!1!==i[d],y=((n={isEnabled(){var t=m&&M(e),n=$[v];return t&&n&&y!==n&&(t=k(n)),t}})[r.kt]=function(t){m=!1!==t},n.set=function(t,e,n,d,f){var p=!1;if(k(y)&&!function(t,e){return!!(e&&t&&(0,o.cy)(t.blockedCookies)&&-1!==t.blockedCookies[r.Sj](e))||C(t,e)}(i,t)){var v={},m=(0,o.EH)(e||a.m5),w=m[r.Sj](";");if(-1!==w&&(m=(0,o.EH)(e[r.Re](0,w)),v=F(e[r.Re](w+1))),(0,o.KY)(v,"domain",d||g,o.zz,o.b0),!(0,o.hX)(n)){var $=(0,s.lT)();if((0,o.b0)(v[h])){var x=(0,o.x3)()+1e3*n;if(x>0){var S=new Date;S.setTime(x),(0,o.KY)(v,h,D(S,$?l:c)||D(S,$?l:c)||a.m5,o.zz)}}$||(0,o.KY)(v,"max-age",a.m5+n,null,o.b0)}var E=(0,s.g$)();E&&"https:"===E.protocol&&((0,o.KY)(v,"secure",null,null,o.b0),null===b&&(b=!I(((0,s.w3)()||{})[r.tX])),b&&(0,o.KY)(v,"SameSite","None",null,o.b0)),(0,o.KY)(v,"path",f||u,null,o.b0),(i.setCookie||T)(t,O(m,v)),p=!0}return p},n.get=function(t){var e=a.m5;return k(y)&&!C(i,t)&&(e=(i.getCookie||A)(t)),e},n.del=function(t,e){var n=!1;return k(y)&&(n=y.purge(t,e)),n},n.purge=function(t,n){var r,o=!1;if(M(e)){var l=((r={}).path=n||"/",r[h]="Thu, 01 Jan 1970 00:00:01 GMT",r);(0,s.lT)()||(l["max-age"]="0"),(i.delCookie||T)(t,O(a.m5,l)),o=!0}return o},n);return y[v]=y,y}function M(t){if(null===g){g=!1;try{g=void 0!==(y||{})[u]}catch(e){(0,i.ZP)(t,2,68,"Cannot access document.cookie - "+(0,o.lL)(e),{exception:(0,s.mm)(e)})}}return g}function F(t){var e={};if(t&&t[r.oI]){var n=(0,o.EH)(t)[r.sY](";");(0,o.Iu)(n,function(t){if(t=(0,o.EH)(t||a.m5)){var n=t[r.Sj]("=");-1===n?e[t]=null:e[(0,o.EH)(t[r.Re](0,n))]=(0,o.EH)(t[r.Re](n+1))}})}return e}function D(t,e){return(0,o.Tn)(t[e])?t[e]():null}function O(t,e){var n=t||a.m5;return(0,o.z)(e,function(t,e){n+="; "+t+((0,o.hX)(e)?a.m5:"="+e)}),n}function A(t){var e=a.m5;if(y){var n=y[u]||a.m5;m!==n&&(w=F(n),m=n),e=(0,o.EH)(w[t]||a.m5)}return e}function T(t,e){y&&(y[u]=t+"="+e)}function I(t){return!!(0,o.Kg)(t)&&(!(!(0,o.Ju)(t,"CPU iPhone OS 12")&&!(0,o.Ju)(t,"iPad; CPU OS 12"))||(!!((0,o.Ju)(t,"Macintosh; Intel Mac OS X 10_14")&&(0,o.Ju)(t,"Version/")&&(0,o.Ju)(t,"Safari"))||(!(!(0,o.Ju)(t,"Macintosh; Intel Mac OS X 10_14")||!(0,o.Cv)(t,"AppleWebKit/605.1.15 (KHTML, like Gecko)"))||(!(!(0,o.Ju)(t,"Chrome/5")&&!(0,o.Ju)(t,"Chrome/6"))||(!(!(0,o.Ju)(t,"UnrealEngine")||(0,o.Ju)(t,"Chrome"))||!(!(0,o.Ju)(t,"UCBrowser/12")&&!(0,o.Ju)(t,"UCBrowser/11")))))))}},12938(t,e,n){"use strict";n.d(e,{m(){return y}});var r=n(56911),i=n(92011),s=n(23429),o=n(60815),a=n(55230),l=n(2298),c=n(84471);class u extends i.L{constructor(){super(...arguments),this.currentFocused=null,this.handleFocus=t=>{if(!(this.slottedTreeItems.length<1))return t.target===this?(null===this.currentFocused&&(this.currentFocused=this.getValidFocusableItem()),void(null!==this.currentFocused&&c._.focusItem(this.currentFocused))):void(this.contains(t.target)&&(this.setAttribute("tabindex","-1"),this.currentFocused=t.target))},this.handleBlur=t=>{t.target instanceof HTMLElement&&(null===t.relatedTarget||!this.contains(t.relatedTarget))&&this.setAttribute("tabindex","0")},this.handleKeyDown=t=>{if(t.defaultPrevented)return;if(this.slottedTreeItems.length<1)return!0;const e=this.getVisibleNodes();switch(t.key){case a.kE:return void(e.length&&c._.focusItem(e[0]));case a.FM:return void(e.length&&c._.focusItem(e[e.length-1]));case a.kT:if(t.target&&this.isFocusableElement(t.target)){const e=t.target;e instanceof c._&&e.childItemLength>0&&e.expanded?e.expanded=!1:e instanceof c._&&e.parentElement instanceof c._&&c._.focusItem(e.parentElement)}return!1;case a.bb:if(t.target&&this.isFocusableElement(t.target)){const e=t.target;e instanceof c._&&e.childItemLength>0&&!e.expanded?e.expanded=!0:e instanceof c._&&e.childItemLength>0&&this.focusNextNode(1,t.target)}return;case a.HX:return void(t.target&&this.isFocusableElement(t.target)&&this.focusNextNode(1,t.target));case a.I5:return void(t.target&&this.isFocusableElement(t.target)&&this.focusNextNode(-1,t.target));case a.Mm:return void this.handleClick(t)}return!0},this.handleSelectedChange=t=>{if(t.defaultPrevented)return;if(!(t.target instanceof Element&&(0,c.W)(t.target)))return!0;const e=t.target;e.selected?(this.currentSelected&&this.currentSelected!==e&&(this.currentSelected.selected=!1),this.currentSelected=e):e.selected||this.currentSelected!==e||(this.currentSelected=null)},this.setItems=()=>{if(!this.treeView)return;const t=this.treeView.querySelector("[aria-selected='true']");this.currentSelected=t,null!==this.currentFocused&&this.contains(this.currentFocused)||(this.currentFocused=this.getValidFocusableItem()),this.nested=this.checkForNestedItems();this.getVisibleNodes().forEach(t=>{(0,c.W)(t)&&(t.nested=this.nested)})},this.isFocusableElement=t=>(0,c.W)(t),this.isSelectedElement=t=>t.selected}slottedTreeItemsChanged(){this.$fastController.isConnected&&this.setItems()}connectedCallback(){super.connectedCallback(),this.setAttribute("tabindex","0"),s.L.enqueue(()=>{this.setItems()})}handleClick(t){if(t.defaultPrevented)return;if(!(t.target instanceof Element&&(0,c.W)(t.target)))return!0;const e=t.target;e.disabled||(e.selected=!e.selected)}focusNextNode(t,e){const n=this.getVisibleNodes();if(!n)return;const r=n[n.indexOf(e)+t];(0,l.sb)(r)&&c._.focusItem(r)}getValidFocusableItem(){const t=this.getVisibleNodes();let e=t.findIndex(this.isSelectedElement);return-1===e&&(e=t.findIndex(this.isFocusableElement)),-1!==e?t[e]:null}checkForNestedItems(){return this.slottedTreeItems.some(t=>(0,c.W)(t)&&t.querySelector("[role='treeitem']"))}getVisibleNodes(){return(0,l.JL)(this,"[role='treeitem']")||[]}}(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Object)],u.prototype,"currentSelected",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Array)],u.prototype,"slottedTreeItems",void 0);var h=n(37180),d=n(74849),f=n(64187);const p=d.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,f.V)("flex")} :host {
        flex-direction: column;
        align-items: stretch;
        min-width: fit-content;
        font-size: 0;
    }

    :host:focus-visible {
        outline: none;
    }
`;var v=n(96950),g=n(60402),b=n(82774);const m=v.qy`
        <template
            role="tree"
            ${(0,g.K)("treeView")}
            @keydown="${(t,e)=>t.handleKeyDown(e.event)}"
            @focusin="${(t,e)=>t.handleFocus(e.event)}"
            @focusout="${(t,e)=>t.handleBlur(e.event)}"
            @click="${(t,e)=>t.handleClick(e.event)}"
            @selected-change="${(t,e)=>t.handleSelectedChange(e.event)}"
        >
            <slot ${(0,b.e)("slottedTreeItems")}></slot>
        </template>
    `,y=class extends u{}.compose({name:`${h.c.prefix}-tree-view`,template:m,styles:p})},13023(t,e,n){"use strict";n.d(e,{P(){return a}});var r=n(14777),i=n(20468),s=n(88383),o=n(62044);function a(){var t=[];return{add(e){e&&t[r.y5](e)},run(e,n){(0,o.Iu)(t,function(t){try{t(e,n)}catch(t){(0,i.ZP)(e[r.e4](),2,73,"Unexpected error calling unload handler - "+(0,s.mm)(t))}}),t=[]}}}},13312(t,e,n){"use strict";n.d(e,{_4(){return a},am(){return c},tA(){return l}});var r=n(56911),i=n(60815),s=n(92011),o=n(38493);const a={C1:"C1",C2:"C2",C3:"C3",C4:"C4",C5:"C5",C6:"C6"};class l extends s.L{constructor(){super(...arguments),this.layout=a.C4,this.childrenLayout=[],this.disabledKeyListeners=[]}layoutChanged(){this.updateLayout()}childTemplateMapChanged(){this.updateLayout()}dataChanged(){this.updateLayout()}layoutStylesChanged(t,e){t&&this.$fastController.removeStyles(t),this.$fastController.addStyles(e)}selectTemplate(t){if(t.childTemplateType)return this.childTemplateMap?.[t.childTemplateType]}updateLayout(){if(void 0===this.data)return;const t=this.data[this.layout];this.childrenLayout=this.data.defaultLayout.map(e=>({...e,...t?.find(t=>t.id===e.id)})).sort((t,e)=>t.childDOMOrder&&e.childDOMOrder?t.childDOMOrder-e.childDOMOrder:0)}handleKeyDown(t){const e=Array.from(this.getRootNode().querySelectorAll(this.tagName)).reduce((t,e)=>t.concat(Array.from(e.shadowRoot?.children||[])),[]).filter(t=>t.offsetWidth>0&&t.offsetHeight>0);return!(!this.disabledKeyListeners||!this.disabledKeyListeners.find(e=>e===t.key))||c(t,e)}}function c(t,e){const n=!!["ArrowDown","ArrowLeft","ArrowRight","ArrowUp","End","Home","PageUp","PageDown"].find(e=>e===t.key);if(t.defaultPrevented||!n||!e)return!0;const r=e.reduce((t,e,n)=>{const{offsetLeft:r,offsetHeight:i,offsetTop:s,offsetWidth:o}=e;return t.push({x:r,y:s,x2:r+o,y2:s+i,index:n}),t},[]),i=e.findIndex(e=>t.composedPath().find(t=>t===e))??0,s=t=>{const e=t.currentTarget;e&&(e.removeAttribute("tabindex"),e.removeEventListener("blur",s))},o=r.reduce((t,e,n)=>{const s=r[i||0],o={x:["ArrowLeft","ArrowRight"],y:["ArrowUp","ArrowDown"]},a=t=>Math.min(e[`${t}2`],s[`${t}2`])-Math.max(e[t],s[t]),l=t=>Math.abs(e[t]>=s[`${t}2`]?e[t]-s[`${t}2`]:s[t]-e[`${t}2`]);for(const r in o){const c=r,u=a("x"===c?"y":"x"),h=l(c);if(u>0){const r=e[c]>=s[`${c}2`]?1:0,a=o[c][r];n!==i&&(void 0===t[a]||(t[a]?.distance||0)>h)&&(t[a]=Object.assign({},e,{overlap:u,distance:h})),"y"===c&&("ArrowUp"===a?(!t.PageUp||t.PageUp.y>e.y)&&(t.PageUp=e):(!t.PageDown||t.PageDown.y2<e.y2)&&(t.PageDown=e))}}return(!t.Home||t.Home.x>e.x||t.Home.y>e.y)&&(t.Home=e),(!t.End||t.End.x<e.x||t.End.y<e.y)&&(t.End=e),t},{})[t.key];var a;return void 0!==o&&(a=o.index,e&&e.length>a&&(e[a].setAttribute("tabindex","0"),e[a].addEventListener("blur",s),e[a].focus())),!0}(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],l.prototype,"layout",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Array)],l.prototype,"childrenLayout",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Object)],l.prototype,"childTemplateMap",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Object)],l.prototype,"data",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Object)],l.prototype,"layoutStyles",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Array)],l.prototype,"disabledKeyListeners",void 0)},13765(t,e,n){"use strict";n.d(e,{NS(){return d},Z4(){return v},r2(){return p}});var r=n(58207),i=n(14777),s=n(62044),o=n(89449),a="ctx",l="ParentContextKey",c="ChildrenContextKey",u=null,h=function(){function t(e,n,r){var o,u=this,h=!1;(u.start=(0,s.x3)(),u[i.RS]=e,u[i.tI]=r,u[i.Zu]=function(){return!1},(0,s.Tn)(n))&&(h=(0,s.r)(u,"payload",function(){return!o&&(0,s.Tn)(n)&&(o=n(),n=null),o}));u[i.O_]=function(e){return e?e===t[l]||e===t[c]?u[e]:(u[a]||{})[e]:null},u[i.e_]=function(e,n){if(e)if(e===t[l])u[e]||(u[i.Zu]=function(){return!0}),u[e]=n;else if(e===t[c])u[e]=n;else{(u[a]=u[a]||{})[e]=n}},u[i.Ru]=function(){var e=0,r=u[i.O_](t[c]);if((0,s.cy)(r))for(var o=0;o<r[i.oI];o++){var a=r[o];a&&(e+=a[i.fA])}u[i.fA]=(0,s.x3)()-u.start,u.exTime=u[i.fA]-e,u[i.Ru]=function(){},!h&&(0,s.Tn)(n)&&(u.payload=n())}}return t.ParentContextKey="parent",t.ChildrenContextKey="childEvts",t}(),d=function(){function t(e){this.ctx={},(0,r.A)(t,this,function(t){t.create=function(t,e,n){return new h(t,e,n)},t.fire=function(t){t&&(t[i.Ru](),e&&(0,s.Tn)(e[o.l0])&&e[o.l0](t))},t[i.e_]=function(e,n){e&&((t[a]=t[a]||{})[e]=n)},t[i.O_]=function(e){return(t[a]||{})[e]}})}return t.__ieDyn=1,t}(),f="CoreUtils.doPerf";function p(t,e,n,r,s){if(t){var a=t;if(a[o.kI]&&(a=a[o.kI]()),a){var u=void 0,d=a[i.O_](f);try{if(u=a.create(e(),r,s)){if(d&&u[i.e_]&&(u[i.e_](h[l],d),d[i.O_]&&d[i.e_])){var p=d[i.O_](h[c]);p||(p=[],d[i.e_](h[c],p)),p[i.y5](u)}return a[i.e_](f,u),n(u)}}catch(t){u&&u[i.e_]&&u[i.e_]("exception",t)}finally{u&&a.fire(u),a[i.e_](f,d)}}}return n()}function v(){return u}},14205(t,e,n){"use strict";n.d(e,{Mc(){return l},Ws(){return a},oj(){return o},q(){return s}});var r=n(45755);const{create:i}=r.G,s=i("neutral-fill-stealth-rest-delta",0),o=i("neutral-fill-stealth-hover-delta",5),a=i("neutral-fill-stealth-active-delta",3),l=i("neutral-fill-stealth-focus-delta",0)},14338(t,e,n){"use strict";n.d(e,{h(){return i}});var r=n(37820);class i{constructor(t,e,n){this.l=t,this.a=e,this.b=n}static fromObject(t){return!t||isNaN(t.l)||isNaN(t.a)||isNaN(t.b)?null:new i(t.l,t.a,t.b)}equalValue(t){return this.l===t.l&&this.a===t.a&&this.b===t.b}roundToPrecision(t){return new i((0,r.l)(this.l,t),(0,r.l)(this.a,t),(0,r.l)(this.b,t))}toObject(){return{l:this.l,a:this.a,b:this.b}}}i.epsilon=216/24389,i.kappa=24389/27},14475(t,e,n){"use strict";n.d(e,{z(){return r}});const r={_self:"_self",_blank:"_blank",_parent:"_parent",_top:"_top"}},14777(t,e,n){"use strict";n.d(e,{$4(){return z},$5(){return p},$o(){return I},AP(){return w},Di(){return m},EX(){return $},Ek(){return G},GA(){return c},H7(){return x},HC(){return D},Ic(){return k},Ik(){return C},JR(){return S},Ju(){return o},OL(){return q},O_(){return Z},P5(){return tt},QM(){return K},RF(){return s},RS(){return i},Re(){return R},Rr(){return nt},Ru(){return Y},Sj(){return N},TP(){return b},Uw(){return h},W7(){return V},YH(){return T},Yo(){return X},Zu(){return J},a$(){return U},by(){return y},e4(){return A},e_(){return Q},fA(){return f},kt(){return P},lK(){return B},mE(){return r},oI(){return d},pM(){return E},ps(){return v},re(){return H},sY(){return j},sl(){return u},sx(){return W},tI(){return M},tX(){return L},tZ(){return l},tn(){return F},uR(){return O},vR(){return g},wi(){return et},y5(){return a},y9(){return _}});var r="initialize",i="name",s="getNotifyMgr",o="identifier",a="push",l="isInitialized",c="config",u="instrumentationKey",h="logger",d="length",f="time",p="processNext",v="getProcessTelContext",g="addNotificationListener",b="removeNotificationListener",m="stopPollingInternalLogs",y="onComplete",w="getPlugin",$="flush",x="_extensions",k="splice",C="teardown",S="messageId",E="message",M="isAsync",F="_doTeardown",D="update",O="getNext",A="diagLog",T="setNextPlugin",I="createNew",B="cookieCfg",N="indexOf",R="substring",L="userAgent",j="split",P="setEnabled",z="substr",H="nodeType",_="apply",V="replace",U="enableDebugExceptions",W="logInternalMessage",q="toLowerCase",G="call",K="type",X="handler",J="isChildEvt",Z="getCtx",Q="setCtx",Y="complete",tt="traceId",et="spanId",nt="traceFlags"},14848(t,e,n){"use strict";n.d(e,{Eq(){return b},Es(){return g},Gy(){return x},Mx(){return m},QX(){return v},SU(){return p},Z8(){return h},eK(){return $},k5(){return k},mi(){return w},s8(){return u},yN(){return f},ym(){return y}});var r=n(40778),i=n(15128),s=n(14338),o=n(54130),a=n(87122),l=n(27478),c=n(37820);function u(t){return.2126*t.r+.7152*t.g+.0722*t.b}function h(t){function e(t){return t<=.03928?t/12.92:Math.pow((t+.055)/1.055,2.4)}return u(new a.M(e(t.r),e(t.g),e(t.b),1))}const d=(t,e)=>(t+.05)/(e+.05);function f(t,e){const n=h(t),r=h(e);return n>r?d(n,r):d(r,n)}function p(t){const e=Math.max(t.r,t.g,t.b),n=Math.min(t.r,t.g,t.b),i=e-n;let s=0;0!==i&&(s=e===t.r?(t.g-t.b)/i%6*60:e===t.g?60*((t.b-t.r)/i+2):60*((t.r-t.g)/i+4)),s<0&&(s+=360);const o=(e+n)/2;let a=0;return 0!==i&&(a=i/(1-Math.abs(2*o-1))),new r.D(s,a,o)}function v(t,e=1){const n=(1-Math.abs(2*t.l-1))*t.s,r=n*(1-Math.abs(t.h/60%2-1)),i=t.l-n/2;let s=0,o=0,l=0;return t.h<60?(s=n,o=r,l=0):t.h<120?(s=r,o=n,l=0):t.h<180?(s=0,o=n,l=r):t.h<240?(s=0,o=r,l=n):t.h<300?(s=r,o=0,l=n):t.h<360&&(s=n,o=0,l=r),new a.M(s+i,o+i,l+i,e)}function g(t){const e=Math.max(t.r,t.g,t.b),n=e-Math.min(t.r,t.g,t.b);let r=0;0!==n&&(r=e===t.r?(t.g-t.b)/n%6*60:e===t.g?60*((t.b-t.r)/n+2):60*((t.r-t.g)/n+4)),r<0&&(r+=360);let s=0;return 0!==e&&(s=n/e),new i.D(r,s,e)}function b(t,e=1){const n=t.s*t.v,r=n*(1-Math.abs(t.h/60%2-1)),i=t.v-n;let s=0,o=0,l=0;return t.h<60?(s=n,o=r,l=0):t.h<120?(s=r,o=n,l=0):t.h<180?(s=0,o=n,l=r):t.h<240?(s=0,o=r,l=n):t.h<300?(s=r,o=0,l=n):t.h<360&&(s=n,o=0,l=r),new a.M(s+i,o+i,l+i,e)}function m(t){function e(t){return t<=.04045?t/12.92:Math.pow((t+.055)/1.055,2.4)}const n=e(t.r),r=e(t.g),i=e(t.b),s=.4124564*n+.3575761*r+.1804375*i,o=.2126729*n+.7151522*r+.072175*i,a=.0193339*n+.119192*r+.9503041*i;return new l.P(s,o,a)}function y(t,e=1){function n(t){return t<=.0031308?12.92*t:1.055*Math.pow(t,1/2.4)-.055}const r=n(3.2404542*t.x-1.5371385*t.y-.4985314*t.z),i=n(-.969266*t.x+1.8760108*t.y+.041556*t.z),s=n(.0556434*t.x-.2040259*t.y+1.0572252*t.z);return new a.M(r,i,s,e)}function w(t){return function(t){function e(t){return t>s.h.epsilon?Math.pow(t,1/3):(s.h.kappa*t+16)/116}const n=e(t.x/l.P.whitePoint.x),r=e(t.y/l.P.whitePoint.y),i=116*r-16,o=500*(n-r),a=200*(r-e(t.z/l.P.whitePoint.z));return new s.h(i,o,a)}(m(t))}function $(t,e=1){return y(function(t){const e=(t.l+16)/116,n=e+t.a/500,r=e-t.b/200,i=Math.pow(n,3),o=Math.pow(e,3),a=Math.pow(r,3);let c=0;c=i>s.h.epsilon?i:(116*n-16)/s.h.kappa;let u=0;u=t.l>s.h.epsilon*s.h.kappa?o:t.l/s.h.kappa;let h=0;return h=a>s.h.epsilon?a:(116*r-16)/s.h.kappa,c=l.P.whitePoint.x*c,u=l.P.whitePoint.y*u,h=l.P.whitePoint.z*h,new l.P(c,u,h)}(t),e)}function x(t){return function(t){let e=0;(Math.abs(t.b)>.001||Math.abs(t.a)>.001)&&(e=(0,c.nv)(Math.atan2(t.b,t.a))),e<0&&(e+=360);const n=Math.sqrt(t.a*t.a+t.b*t.b);return new o.b(t.l,n,e)}(w(t))}function k(t,e=1){return $(function(t){let e=0,n=0;return 0!==t.h&&(e=Math.cos((0,c.tR)(t.h))*t.c,n=Math.sin((0,c.tR)(t.h))*t.c),new s.h(t.l,e,n)}(t),e)}},14996(t,e,n){"use strict";n.d(e,{WN(){return c},_Y(){return u}});var r=n(45755),i=n(62036),s=n(95239),o=n(31023);const{create:a}=r.G,l=a({name:"focus-stroke-outer-recipe"},{evaluate(t){return(0,i.W)(t(o.r),t(s.p))}}),c=a("focus-stroke-outer",t=>t(l).evaluate(t)),u=c},15128(t,e,n){"use strict";n.d(e,{D(){return i}});var r=n(37820);class i{constructor(t,e,n){this.h=t,this.s=e,this.v=n}static fromObject(t){return!t||isNaN(t.h)||isNaN(t.s)||isNaN(t.v)?null:new i(t.h,t.s,t.v)}equalValue(t){return this.h===t.h&&this.s===t.s&&this.v===t.v}roundToPrecision(t){return new i((0,r.l)(this.h,t),(0,r.l)(this.s,t),(0,r.l)(this.v,t))}toObject(){return{h:this.h,s:this.s,v:this.v}}}},15454(t,e,n){"use strict";n.d(e,{J$(){return f},KU(){return d},OR(){return h},QV(){return a},Wy(){return c},_1(){return i},bA(){return s},hW(){return r},s6(){return l},vR(){return o},zi(){return u}});var r="function",i="object",s="undefined",o="prototype",a="hasOwnProperty",l=Object,c=l[o],u=l.assign,h=l.create,d=l.defineProperty,f=c[a]},16198(t,e,n){"use strict";n.d(e,{A(){return qt}});var r=n(39813),i=n(58207),s=n(99577),o=n(62044),a=n(58168),l=n(15454),c="call",u="toISOString",h="endsWith",d="startsWith",f="trim",p="toString",v=l.s6.freeze,g=(l.s6.seal,l.s6.keys,String[l.vR]),b=(g[f],g[h],g[d],Date[l.vR][u],Array.isArray),m=l.Wy[p],y=l.J$[p];function w(t){return!(!t||typeof t!==l._1)}function $(t,e){if(t)for(var n in t)l.J$[c](t,n)&&e[c](t,n,t[n])}y[c](l.s6),Object.getPrototypeOf;var x=b||function(t){return!(!t||"[object Array]"!==m[c](t))};function k(t){return t}({toString:null}).propertyIsEnumerable("toString");var C=v||k;function S(t){var e,n={};return $(t,function(t,e){n[t]=e[1],n[e[0]]=e[1]}),e=n,v&&$(e,function(t,e){(x(e)||w(e))&&v(e)}),C(e)}var E,M="locale",F="ver",D="name",O=S({UserExt:[0,"user"],DeviceExt:[1,"device"],TraceExt:[2,"trace"],WebExt:[3,"web"],AppExt:[4,"app"],OSExt:[5,"os"],SdkExt:[6,"sdk"],IntWebExt:[7,"intweb"],UtcExt:[8,"utc"],LocExt:[9,"loc"],CloudExt:[10,"cloud"],DtExt:[11,"dt"]}),A=S({id:[0,"id"],ver:[1,F],appName:[2,D],locale:[3,M],expId:[4,"expId"],env:[5,"env"]}),T=S({domain:[0,"domain"],browser:[1,"browser"],browserVer:[2,"browserVer"],screenRes:[3,"screenRes"],userConsent:[4,"userConsent"],consentDetails:[5,"consentDetails"]}),I=S({locale:[0,M],localId:[1,"localId"],id:[2,"id"]}),B=S({osName:[0,D],ver:[1,F]}),N=S({ver:[0,F],seq:[1,"seq"],installId:[2,"installId"],epoch:[3,"epoch"]}),R=S({msfpc:[0,"msfpc"],anid:[1,"anid"],serviceName:[2,"serviceName"]}),L=S({popSample:[0,"popSample"],eventFlags:[1,"eventFlags"]}),j=S({tz:[0,"tz"]}),P=S({sessionId:[0,"sesId"]}),z=S({localId:[0,"localId"],deviceClass:[1,"deviceClass"],make:[2,"make"],model:[3,"model"]}),H=S({role:[0,"role"],roleInstance:[1,"roleInstance"],roleVer:[2,"roleVer"]}),_=S({traceId:[0,"traceID"],traceName:[1,D],parentId:[2,"parentID"]}),V=S({traceId:[0,"traceId"],spanId:[1,"spanId"],traceFlags:[2,"traceFlags"]}),U=n(46543),W=n(20468),q=n(12839),G=n(69912),K=n(50090);function X(){return void 0===E&&(E=!!Z(0)),E}function J(){return X()?Z(0):null}function Z(t){var e,n,r=null;try{var i=(0,K.mS)();if(!i)return null;n=new Date,(r=0===t?i.localStorage:i.sessionStorage)&&(0,o.Tn)(r.setItem)&&(r.setItem(n,n),e=r.getItem(n)!==n,r.removeItem(n),e&&(r=null))}catch(t){r=null}return r}function Q(){return this.getId()}function Y(t){this.setId(t)}var tt=function(){function t(){(0,i.A)(t,this,function(t){t.setId=function(e){t.customId=e},t.getId=function(){return(0,o.Kg)(t.customId)?t.customId:t.automaticId}})}return t._staticInit=void(0,o.r)(t.prototype,"id",Q,Y),t}(),et="ai_session",nt=function(){function t(e,n){var r,a,l=(0,W.y0)(e),c=(0,q.um)(e);(0,i.A)(t,this,function(e){var i,u={sessionRenewalMs:(i=n).sessionRenewalMs&&function(){return i.sessionRenewalMs},sessionExpirationMs:i.sessionExpirationMs&&function(){return i.sessionExpirationMs},cookieDomain:i.cookieDomain&&function(){return i.cookieDomain},namePrefix:i.namePrefix&&function(){return i.namePrefix},sessionAsGuid:()=>i.sessionAsGuid,idLength:()=>i.idLength?i.idLength:22};function h(t){var n=e.automaticSession,r=t.split("|");r.length>0&&n.setId(r[0]);try{if(r.length>1){var i=+r[1];n.acquisitionDate=+new Date(i),n.acquisitionDate=n.acquisitionDate>0?n.acquisitionDate:0}if(r.length>2){var s=+r[2];n.renewalDate=+new Date(s),n.renewalDate=n.renewalDate>0?n.renewalDate:0}}catch(t){(0,W.ZP)(l,1,510,"Error parsing ai_session cookie, session will be reset: "+t)}0===n.renewalDate&&(0,W.ZP)(l,2,517,"AI session renewal date is 0, session will be reset.")}function d(){var t=e.automaticSession,n=(new Date).getTime(),r=e.config.sessionAsGuid();!(0,o.b0)(r)&&r?(0,o.Lm)(r)?t.setId((0,s.gj)()):t.setId((0,s.gj)(r)):t.setId((0,G.Si)(u&&u.idLength?u.idLength():22)),t.acquisitionDate=n,t.renewalDate=n,f(t.getId(),t.acquisitionDate,t.renewalDate),X()||(0,W.ZP)(l,2,505,"Browser does not support local storage. Session durations will be inaccurate.")}function f(t,n,i){var s=n+e.config.sessionExpirationMs(),o=i+e.config.sessionRenewalMs(),l=new Date,u=[t,n,i];s<o?l.setTime(s):l.setTime(o);var h=e.config.cookieDomain?e.config.cookieDomain():null;c.set(a(),u.join("|")+";expires="+l.toUTCString(),null,h),r=(new Date).getTime()}(0,o.Tn)(n.sessionExpirationMs)||(u.sessionExpirationMs=function(){return t.acquisitionSpan}),(0,o.Tn)(n.sessionRenewalMs)||(u.sessionRenewalMs=function(){return t.renewalSpan}),e.config=u,a=function(){return e.config.namePrefix&&e.config.namePrefix()?et+e.config.namePrefix():et},e.automaticSession=new tt,e.update=function(){e.automaticSession.getId()||function(){var t=c.get(a());if(t&&(0,o.Tn)(t.split))h(t);else{var n=function(t,e){var n=J();if(null!==n)try{return n.getItem(e)}catch(e){E=!1,(0,W.ZP)(t,1,503,"Browser failed read of local storage. "+e)}return null}(l,a());n&&h(n)}e.automaticSession.getId()||d()}();var n=e.automaticSession,i=e.config,s=(new Date).getTime(),u=s-n.acquisitionDate>i.sessionExpirationMs(),p=s-n.renewalDate>i.sessionRenewalMs();if(u||p)d();else{(!r||s-r>t.cookieUpdateInterval)&&(n.renewalDate=s,f(n.getId(),n.acquisitionDate,n.renewalDate))}},e.backup=function(){var t,n,r,i=e.automaticSession;t=i.getId(),n=i.acquisitionDate,r=i.renewalDate,function(t,e,n){var r=J();if(null!==r)try{return r.setItem(e,n),!0}catch(e){E=!1,(0,W.ZP)(t,1,504,"Browser failed write to local storage. "+e)}}(l,a(),[t,n,r].join("|"))}})}return t.acquisitionSpan=864e5,t.renewalSpan=18e5,t.cookieUpdateInterval=6e4,t}(),rt=n(88383),it=["AX","EX","SF","CS","CF","CT","CU","DC","DF","H5","HL","WS","WP"];function st(t,e){void 0===e&&(e=it);var n=null;if(t)for(var r=t.split(","),i=0;i<r.length;i++)ot(r[i],e)&&(n?n+=","+r[i]:n=r[i]);return n}function ot(t,e){if(void 0===e&&(e=it),!t||t.length<4)return!1;for(var n=!1,r=t.substring(0,3).toString().toUpperCase(),i=0;i<e.length;i++)if(e[i]+":"===r&&t.length<=256){n=!0;break}return n}function at(){return this.getExpId()}var lt=function(){function t(e,n){var r=null,o=it.slice(0),a="Treatments",l=(0,q.um)(n),c=e;(0,i.A)(t,this,function(t){if((0,rt.Wt)()){var n=(0,rt.YE)().documentElement;n&&(t.locale=n.lang)}function i(t){t!==r&&(r=st(t,o))}t.env=e.env?e.env:function(t){var e,n={},r=(0,rt.YE)();if(r){e=r&&r.querySelectorAll("meta");for(var i=0;i<e.length;i++){var s=e[i];if(s.name)if(0===s.name.toLowerCase().indexOf(t))n[s.name.replace(t,"")]=s.content}}return n}("awa-").env,t.getExpId=function(){return c.expId?(i(c.expId),r):(i((0,s.UM)(l,a)),r)}})}return t.validateAppExpId=st,t._staticInit=void(0,o.r)(t.prototype,"expId",at),t}(),ct=function(){},ut=function(){};function ht(){return this.getMsfpc()}function dt(){return this.getAnid()}var ft=function(){function t(e,n){var r=(0,q.um)(n);(0,i.A)(t,this,function(t){e.serviceName&&(t.serviceName=e.serviceName),t.getMsfpc=function(){return(0,s.UM)(r,"MSFPC")},t.getAnid=function(){return(0,s.UM)(r,"ANON").slice(0,34)}})}var e;return t._staticInit=(e=t.prototype,(0,o.r)(e,"msfpc",ht),void(0,o.r)(e,"anid",dt)),t}(),pt=function(){var t=(new Date).getTimezoneOffset(),e=t%60,n=(t-e)/60,r="+";n>0&&(r="-"),n=Math.abs(n),e=Math.abs(e),this.tz=r+(n<10?"0"+n:n.toString())+":"+(e<10?"0"+e:e.toString())},vt={WIN:/(windows|win32)/i,WINRT:/ arm;/i,WINPHONE:/windows\sphone\s\d+\.\d+/i,OSX:/(macintosh|mac os x)/i,IOS:/(ipad|iphone|ipod)(?=.*like mac os x)/i,LINUX:/(linux|joli|[kxln]?ubuntu|debian|[open]*suse|gentoo|arch|slackware|fedora|mandriva|centos|pclinuxos|redhat|zenwalk)/i,ANDROID:/android/i,CROS:/CrOS/i},gt={5.1:"XP","6.0":"Vista",6.1:"7",6.2:"8",6.3:"8.1","10.0":"10"},bt="([\\d,_,.]+)",mt="Unknown",yt=[{r:vt.WINPHONE,os:"Windows Phone"},{r:vt.WINRT,os:"Windows RT"},{r:vt.WIN,os:"Windows"},{r:vt.IOS,os:"iOS"},{r:vt.ANDROID,os:"Android"},{r:vt.LINUX,os:"Linux"},{r:vt.CROS,os:"Chrome OS"},{s:"x11",os:"Unix"},{s:"blackberry",os:"BlackBerry"},{s:"symbian",os:"Symbian"},{s:"nokia",os:"Nokia"},{r:vt.OSX,os:"Mac OS X"}];function wt(t,e){return"Windows"===e?$t(t,"Windows NT"):"Android"===e?$t(t,e):"Mac OS X"===e?function(t){var e=t.match(new RegExp("Mac OS X "+bt));if(e){var n=e[1].replace(/_/g,".");if(n){var r=xt(n);return r?n.split(r)[0]:n}}return mt}(t):"iOS"===e?function(t){var e=t.match(new RegExp("OS "+bt));if(e){var n=e[1].replace(/_/g,".");if(n){var r=xt(n);return r?n.split(r)[0]:n}}return mt}(t):mt}function $t(t,e){var n=t.match(new RegExp(e+" ([\\d,.]+)"));return n?gt[n[1]]?gt[n[1]]:n[1]:mt}function xt(t){return t.indexOf(".")>-1?".":t.indexOf("_")>-1?"_":null}var kt=function(t){if(t.populateOperatingSystemInfo){var e=this,n=(0,rt.w3)()||{},r=t.userAgent||n.userAgent||"",i=t.userAgentData||n.userAgentData||{};if(r){var s=function(t){for(var e=0;e<yt.length;e++){var n=yt[e];if(n.r&&t.match(n.r))return n.os;if(n.s&&-1!==t.indexOf(n.s))return n.os}return mt}(r.toLowerCase());e.name=s,e.ver=wt(r,s)}e.name&&e.name!==mt||!(0,o.Kg)(i.platform)||(e.name=i.platform)}},Ct=n(96271),St="MicrosoftApplicationsTelemetryDeviceId",Et=function(){function t(e,n){var r=0;(0,i.A)(t,this,function(t){var i=e.propertyStorageOverride;t.seq=r,t.epoch=(0,G.VN)(!1).toString();var o=(0,q.um)(n,e);if(o.isEnabled()||i){var a=function(t,e,n){return e?e.getProperty(n)||"":(0,s.UM)(t,n)}(o,i,St);a||(a=(0,Ct.aq)()),function(t,e,n,r){e?e.setProperty(n,r):t.set(n,r,31536e3)}(o,i,St,a),t.installId=a}else o.purge(St);t.getSequenceId=function(){return++r}})}return t.__ieDyn=1,t}(),Mt=function(t,e,n,r){var i=this;if(i.traceId=e||(0,Ct.cL)(),t.enableDistributedTracing&&!n&&(n=(0,Ct.cL)().substring(0,16)),i.parentId=n,t.enableApplicationInsightsTrace){i.name=r;var s=(0,rt.g$)();s&&s.pathname&&(i.name=s.pathname)}},Ft="setLocalId";function Dt(){return this.getLocalId()}function Ot(t){this[Ft](t)}var At=function(){function t(e,n,r){var a,l=n,c=(0,q.um)(r,e);(0,i.A)(t,this,function(n){if(c&&c.isEnabled()&&(p(),l.enableApplicationInsightsUser)){var r=(0,s.UM)(c,t.userCookieName);if(r){var i=r.split(t.cookieSeparator);i.length>0&&(n.id=i[0])}if(!n.id){n.id=(0,G.Si)(e&&!(0,o.b0)(e.idLength)?e.idLength:22);var u=(0,o._u)(new Date);n.accountAcquisitionDate=u;var h=[n.id,u],d=l.cookieDomain?l.cookieDomain:void 0;c.set(t.userCookieName,h.join(t.cookieSeparator),31536e3,d)}}if("undefined"!=typeof navigator){var f=navigator;n.locale=f.userLanguage||f.language}function p(){if(!l.hashIdentifiers&&!l.dropIdentifiers){var t=(0,s.UM)(c,"MUID");t&&(a="t:"+t)}return a}n.getLocalId=function(){return a||p()},n[Ft]=function(t){a=t}})}return t.cookieSeparator="|",t.userCookieName="ai_user",t._staticInit=void(0,o.r)(t.prototype,"localId",Dt,Ot),t}(),Tt=function(t){var e=this;e.popSample=100,e.eventFlags=0,t.hashIdentifiers&&(e.eventFlags=1048576|e.eventFlags),t.dropIdentifiers&&(e.eventFlags=2097152|e.eventFlags)},It="([\\d,.]+)",Bt="Unknown",Nt="Edg/",Rt=[{ua:"OPR/",b:"Opera"},{ua:"PhantomJS",b:"PhantomJS"},{ua:"Edge",b:"Edge"},{ua:Nt,b:"Edge"},{ua:"Electron",b:"Electron"},{ua:"Chrome",b:"Chrome"},{ua:"Trident",b:"MSIE"},{ua:"MSIE ",b:"MSIE"},{ua:"Firefox",b:"Firefox"},{ua:"Safari",b:"Safari"},{ua:"SkypeShell",b:"SkypeShell"}],Lt=[{br:"Microsoft Edge",b:"Edge"},{br:"Google Chrome",b:"Chrome"},{br:"Opera",b:"Opera"}];function jt(t,e){return e.indexOf(t)>-1}function Pt(t,e){for(var n=0;n<e.length;n++)if(t==e[n].brand)return e[n].version;return null}function zt(t,e){return"MSIE"===e?function(t){var e=t.match(new RegExp("MSIE "+It));if(e)return e[1];var n=t.match(new RegExp("rv:"+It));if(n)return n[1]}(t):function(t,e){"Safari"===t?t="Version":"Edge"===t&&jt(Nt,e)&&(t="Edg");var n=e.match(new RegExp(t+"/"+It));if(n)return n[1];if("Opera"===t&&(n=e.match(new RegExp("OPR/"+It))))return n[1];return Bt}(e,t)}function Ht(){return this.getUserConsent()}var _t=function(){function t(e,n){var r=(0,q.um)(n),a=e||{};(0,i.A)(t,this,function(t){var e=(0,rt.g$)();if(e){var n=e.hostname;n&&(t.domain="file:"===e.protocol?"local":n)}if(a.populateBrowserInfo){var i=a.userAgent,l=(a.userAgentData||{}).brands,c=(0,rt.w3)();c&&(i=i||c.userAgent||"",l=l||(c.userAgentData||{}).brands),function(e,n){if((0,o.cy)(n))try{for(var r=0;r<Lt.length;r++){var i=Pt(Lt[r].br,n);if(i)return t.browser=Lt[r].b,void(t.browserVer=i)}}catch(t){}if(e){var s=function(t){if(t)for(var e=0;e<Rt.length;e++)if(jt(Rt[e].ua,t))return Rt[e].b;return Bt}(e);t.browser=s,t.browserVer=zt(e,s)}}(i,l);var u=function(){var t={h:0,w:0},e=(0,rt.zk)();return e&&e.screen&&(t.h=screen.height,t.w=screen.width),t}();t.screenRes=u.w+"X"+u.h}t.getUserConsent=function(){return a.userConsented||!!(0,s.UM)(r,a.userConsentCookieName||"MSCC")},t.getUserConsentDetails=function(){try{var t=a.callback;if(t&&t.userConsentDetails){var e=t.userConsentDetails();if(e)return JSON.stringify({Required:e.Required||!1,Analytics:e.Analytics||!1,SocialMedia:e.SocialMedia||!1,Advertising:e.Advertising||!1})}}catch(t){}return null},(0,o.r)(t,"userConsent",t.getUserConsent)})}return t._staticInit=void(0,o.r)(t.prototype,"userConsent",Ht),t}();function Vt(t,e,n,r,i){var s=e.ext[O[t]];return s&&(0,o.z)(r,function(t,e){if((0,o.Kg)(e)||(0,o.Et)(e)||(0,o.Lm)(e)){var r=s[n[t]];!i&&(r||(0,o.Kg)(r)||(0,o.Et)(r)||(0,o.Lm)(r))&&(e=r),s[n[t]]=e}}),s}var Ut=function(){function t(e,n,r){(0,i.A)(t,this,function(t){t.app=new lt(n,r),t.cloud=new ct,t.user=new At(e,n,r),t.os=new kt(n),t.web=new _t(n,r);var i=new Et(e,r),s=new ft(n,r),a=new Tt(n);t.loc=new pt,t.device=new ut;var l=new nt(r,n);t.session=new tt;var c,u,h,d=(c=new Mt(n),u=v(),h=c||{},{getName:()=>h.name,setName(t){u&&u.setName(t),h.name=t},getTraceId:()=>h.traceId,setTraceId(t){u&&u.setTraceId(t),(0,U.hX)(t)&&(h.traceId=t)},getSpanId:()=>h.parentId,setSpanId(t){u&&u.setSpanId(t),(0,U.wN)(t)&&(h.parentId=t)},getTraceFlags:()=>h.traceFlags,setTraceFlags(t){u&&u.setTraceFlags(t),h.traceFlags=t}}),f=!(n||{}).eventContainExtFields;function p(){var e=t.session;if(e&&(0,o.Kg)(e.customId))return e.customId;l.update();var n=l.automaticSession;if(n){var r=n.getId();r&&(0,o.Kg)(r)&&(e.automaticId=r)}return e.automaticId}function v(){var t=d;return r&&r.getTraceCtx&&(t=r.getTraceCtx(!1)||d),t}t.getTraceCtx=function(){return d},t.getSessionId=p,t.applyApplicationContext=function(e){var n,r=t.app;Vt(4,e,A,((n={})[0]=r.id,n[1]=r.ver,n[2]=r.name,n[3]=r.locale,n[4]=r.getExpId(),n[5]=r.env,n),f)},t.applyUserContext=function(e){var n,r=t.user;Vt(0,e,I,((n={})[1]=r.getLocalId(),n[0]=r.locale,n[2]=r.id,n),f)},t.applyWebContext=function(e){var n,r=t.web;Vt(3,e,T,((n={})[0]=r.domain,n[1]=r.browser,n[2]=r.browserVer,n[3]=r.screenRes,n[5]=r.getUserConsentDetails(),n[4]=r.getUserConsent(),n),f)},t.applyOsContext=function(e){var n,r=t.os;Vt(5,e,B,((n={})[0]=r.name,n[1]=r.ver,n),f)},t.applySdkContext=function(t){var e;Vt(6,t,N,((e={})[2]=i.installId,e[1]=i.getSequenceId(),e[3]=i.epoch,e),f)},t.applyIntWebContext=function(t){var e;Vt(7,t,R,((e={})[0]=s.getMsfpc(),e[1]=s.getAnid(),e[2]=s.serviceName,e),f)},t.applyUtcContext=function(t){var e,n=((e={})[0]=a.popSample,e);a.eventFlags>0&&(n[1]=a.eventFlags),Vt(8,t,L,n,f)},t.applyLocContext=function(e){var n;Vt(9,e,j,((n={})[0]=t.loc.tz,n),f)},t.applySessionContext=function(t){var e;Vt(4,t,P,((e={})[0]=p(),e),f)},t.applyDeviceContext=function(e){var n,r=t.device;Vt(1,e,z,((n={})[0]=r.localId,n[2]=r.make,n[3]=r.model,n[1]=r.deviceClass,n),f)},t.applyCloudContext=function(e){var n,r=t.cloud;Vt(10,e,H,((n={})[0]=r.role,n[1]=r.roleInstance,n[2]=r.roleVer,n),f)},t.applyAITraceContext=function(t){var e;if(n.enableApplicationInsightsTrace){var r=v();r&&Vt(2,t,_,((e={})[0]=r.getTraceId(),e[1]=r.getName(),e[2]=r.getSpanId(),e),!1)}},t.applyDistributedTraceContext=function(t){var e,n=v();if(n){var r=((e={})[0]=n.getTraceId(),e[1]=n.getSpanId(),e),i=n.getTraceFlags();(0,o.hX)(i)||(r[2]=i),Vt(11,t,V,r,!1)}}})}return t.__ieDyn=1,t}(),Wt=[O[4],O[0],O[3],O[5],O[6],O[7],O[8],O[9],O[1],O[2],O[11],O[10]],qt=function(t){function e(){var n,r,a,l=t.call(this)||this;return l.identifier="SystemPropertiesCollector",l.priority=3,l.version="3.2.8",(0,i.A)(e,l,function(t,e){function i(){n=null,r={}}i(),t.initialize=function(r,i,s){e.initialize(r,i,s),a=t._getTelCtx().getExtCfg(t.identifier),n=new Ut(r,a,i),i&&i.setTraceCtx&&i.setTraceCtx(n.getTraceCtx())},t.processTelemetry=function(e,i){(0,s.u9)(e,t.identifier),i=t._getTelCtx(i);var l,c,u=e.ext=e.ext?e.ext:{};e.data=e.data?e.data:{},(0,o.Iu)(Wt,function(t){u[t]=u[t]||{}}),n&&(n.applyApplicationContext(e),n.applyUserContext(e),n.applyWebContext(e),n.applyOsContext(e),n.applySdkContext(e),n.applyIntWebContext(e),n.applyUtcContext(e),n.applyLocContext(e),n.applySessionContext(e),n.applyDeviceContext(e),a.enableApplicationInsightsTrace&&n.applyAITraceContext(e),a.enableDistributedTracing&&n.applyDistributedTraceContext(e),n.applyCloudContext(e)),(0,o.Iu)((0,o.cG)(u),function(t){0===(0,o.cG)(u[t]).length&&delete u[t]}),l=r,c=e.data,l&&(0,o.z)(l,function(t,e){c[t]||(c[t]=e)}),t.processNext(e,i)},t.getPropertiesContext=function(){return n},t.setProperty=function(t,e){r[t]=e},t._doTeardown=function(t,e){var r=(t||{}).core();if(r&&r.getTraceCtx&&n){var s=r.getTraceCtx(!1);s&&s===n.getTraceCtx()&&r.setTraceCtx(null)}i()}}),l}return(0,r.qU)(e,t),e.__ieDyn=1,e}(a.s)},16253(t){t.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M4.4 4.55l.07-.08a.75.75 0 01.98-.07l.08.07L12 10.94l6.47-6.47a.75.75 0 111.06 1.06L13.06 12l6.47 6.47c.27.27.3.68.07.98l-.07.08a.75.75 0 01-.98.07l-.08-.07L12 13.06l-6.47 6.47a.75.75 0 01-1.06-1.06L10.94 12 4.47 5.53a.75.75 0 01-.07-.98l.07-.08-.07.08z"></path></svg>'},17252(t,e,n){"use strict";n.d(e,{DZ(){return s},dc(){return l},nK(){return o},xK(){return a}});var r=n(45755);const{create:i}=r.G,s=i("neutral-fill-input-rest-delta",0),o=i("neutral-fill-input-hover-delta",0),a=i("neutral-fill-input-active-delta",0),l=i("neutral-fill-input-focus-delta",0)},17767(t,e,n){"use strict";n.d(e,{f(){return i}});var r=n(4126);function i(t,e){return new r.o("appearance",t,e)}},17884(t,e,n){"use strict";n.d(e,{r(){return f},U(){return d}});var r=n(56911),i=n(92011),s=n(60815),o=n(38493),a=n(55230),l=n(50180),c=n(82239),u=n(29025),h=n(88458);class d extends i.L{constructor(){super(...arguments),this._options=[],this.selectedIndex=-1,this.selectedOptions=[],this.shouldSkipFocus=!1,this.typeaheadBuffer="",this.typeaheadExpired=!0,this.typeaheadTimeout=-1}get firstSelectedOption(){return this.selectedOptions[0]??null}get hasSelectableOptions(){return this.options.length>0&&!this.options.every(t=>t.disabled)}get length(){return this.options?.length??0}get options(){return s.cP.track(this,"options"),this._options}set options(t){this._options=t,s.cP.notify(this,"options")}get typeAheadExpired(){return this.typeaheadExpired}set typeAheadExpired(t){this.typeaheadExpired=t}clickHandler(t){const e=t.target.closest("option,[role=option]");if(e&&!e.disabled)return this.selectedIndex=this.options.indexOf(e),!0}focusAndScrollOptionIntoView(t=this.firstSelectedOption){this.contains(document.activeElement)&&null!==t&&(t.focus(),requestAnimationFrame(()=>{t.scrollIntoView({block:"nearest"})}))}focusinHandler(t){this.shouldSkipFocus||t.target!==t.currentTarget||(this.setSelectedOptions(),this.focusAndScrollOptionIntoView()),this.shouldSkipFocus=!1}getTypeaheadMatches(){const t=this.typeaheadBuffer.replace(/[.*+\-?^${}()|[\]\\]/g,"\\$&"),e=new RegExp(`^${t}`,"gi");return this.options.filter(t=>t.text.trim().match(e))}getSelectableIndex(t=this.selectedIndex,e){const n=t>e?-1:t<e?1:0,r=t+n;let i=null;switch(n){case-1:i=this.options.reduceRight((t,e,n)=>!t&&!e.disabled&&n<r?e:t,i);break;case 1:i=this.options.reduce((t,e,n)=>!t&&!e.disabled&&n>r?e:t,i)}return this.options.indexOf(i)}handleChange(t,e){if("selected"===e)d.slottedOptionFilter(t)&&(this.selectedIndex=this.options.indexOf(t)),this.setSelectedOptions()}handleTypeAhead(t){this.typeaheadTimeout&&window.clearTimeout(this.typeaheadTimeout),this.typeaheadTimeout=window.setTimeout(()=>this.typeaheadExpired=!0,d.TYPE_AHEAD_TIMEOUT_MS),t.length>1||(this.typeaheadBuffer=`${this.typeaheadExpired?"":this.typeaheadBuffer}${t}`)}keydownHandler(t){if(this.disabled)return!0;this.shouldSkipFocus=!1;const e=t.key;switch(e){case a.kE:t.shiftKey||(t.preventDefault(),this.selectFirstOption());break;case a.HX:t.shiftKey||(t.preventDefault(),this.selectNextOption());break;case a.I5:t.shiftKey||(t.preventDefault(),this.selectPreviousOption());break;case a.FM:t.preventDefault(),this.selectLastOption();break;case a.J9:return this.focusAndScrollOptionIntoView(),!0;case a.Mm:case a.F9:return!0;case a.gG:if(this.typeaheadExpired)return!0;default:return 1===e.length&&this.handleTypeAhead(`${e}`),!0}}mousedownHandler(t){return this.shouldSkipFocus=!this.contains(document.activeElement),!0}multipleChanged(t,e){this.ariaMultiSelectable=e?"true":null}selectedIndexChanged(t,e){if(this.hasSelectableOptions){if(this.options[this.selectedIndex]?.disabled&&"number"==typeof t){const n=this.getSelectableIndex(t,e),r=n>-1?n:t;return this.selectedIndex=r,void(e===r&&this.selectedIndexChanged(e,r))}this.setSelectedOptions()}else this.selectedIndex=-1}selectedOptionsChanged(t,e){const n=e.filter(d.slottedOptionFilter);this.options?.forEach(t=>{const e=s.cP.getNotifier(t);e.unsubscribe(this,"selected"),t.selected=n.includes(t),e.subscribe(this,"selected")})}selectFirstOption(){this.disabled||(this.selectedIndex=this.options?.findIndex(t=>!t.disabled)??-1)}selectLastOption(){this.disabled||(this.selectedIndex=function(t,e){let n=t.length;for(;n--;)if(e(t[n],n,t))return n;return-1}(this.options,t=>!t.disabled))}selectNextOption(){!this.disabled&&this.selectedIndex<this.options.length-1&&(this.selectedIndex+=1)}selectPreviousOption(){!this.disabled&&this.selectedIndex>0&&(this.selectedIndex=this.selectedIndex-1)}setDefaultSelectedOption(){this.selectedIndex=this.options?.findIndex(t=>t.defaultSelected)??-1}setSelectedOptions(){this.options?.length&&(this.selectedOptions=[this.options[this.selectedIndex]],this.ariaActiveDescendant=this.firstSelectedOption?.id??"",this.focusAndScrollOptionIntoView())}slottedOptionsChanged(t,e){this.options=e.reduce((t,e)=>((0,c.nA)(e)&&t.push(e),t),[]);const n=`${this.options.length}`;this.options.forEach((t,e)=>{t.id||(t.id=(0,l.NF)("option-")),t.ariaPosInSet=`${e+1}`,t.ariaSetSize=n}),this.$fastController.isConnected&&(this.setSelectedOptions(),this.setDefaultSelectedOption())}typeaheadBufferChanged(t,e){if(this.$fastController.isConnected){const t=this.getTypeaheadMatches();if(t.length){const e=this.options.indexOf(t[0]);e>-1&&(this.selectedIndex=e)}this.typeaheadExpired=!1}}}d.slottedOptionFilter=t=>(0,c.nA)(t)&&!t.hidden,d.TYPE_AHEAD_TIMEOUT_MS=1e3,(0,r.Cg)([(0,o.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],d.prototype,"disabled",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Number)],d.prototype,"selectedIndex",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Array)],d.prototype,"selectedOptions",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Array)],d.prototype,"slottedOptions",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",String)],d.prototype,"typeaheadBuffer",void 0);class f{}(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Object)],f.prototype,"ariaActiveDescendant",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Object)],f.prototype,"ariaDisabled",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Object)],f.prototype,"ariaExpanded",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Object)],f.prototype,"ariaMultiSelectable",void 0),(0,h.X)(f,u.z),(0,h.X)(d,f)},18622(t,e,n){"use strict";n.d(e,{S(){return i},m5(){return r}});var r="",i="https://browser.events.data.microsoft.com/OneCollector/1.0/"},18893(t,e,n){"use strict";n.d(e,{R(){return i}});var r=n(96950);function i(t){return t?"string"==typeof t?new r.dj(t):"inline"in t?t.inline():t:r.dj.empty}},18931(t,e,n){"use strict";n.d(e,{V7(){return v},lT(){return x}});var r=n(93800),i=n(60815),s=n(19470),o=n(81263),a=n(47429),l=n(7813),c=n(34188);const u={bubbles:!0,composed:!0,cancelable:!0},h="isConnected",d=new WeakMap;function f(t){var e,n;return null!==(n=null!==(e=t.shadowRoot)&&void 0!==e?e:d.get(t))&&void 0!==n?n:null}let p;class v extends r.S{constructor(t,e){super(t),this.boundObservables=null,this.needsInitialization=!0,this.hasExistingShadowRoot=!1,this._template=null,this.stage=3,this.guardBehaviorConnection=!1,this.behaviors=null,this.behaviorsConnected=!1,this._mainStyles=null,this.$fastController=this,this.view=null,this.source=t,this.definition=e;const n=e.shadowOptions;if(void 0!==n){let e=t.shadowRoot;e?this.hasExistingShadowRoot=!0:(e=t.attachShadow(n),"closed"===n.mode&&d.set(t,e))}const r=i.cP.getAccessors(t);if(r.length>0){const e=this.boundObservables=Object.create(null);for(let n=0,i=r.length;n<i;++n){const i=r[n].name,s=t[i];void 0!==s&&(delete t[i],e[i]=s)}}}get isConnected(){return i.cP.track(this,h),1===this.stage}setNeedsInitialization(t){this.needsInitialization=t}get context(){var t,e;return null!==(e=null===(t=this.view)||void 0===t?void 0:t.context)&&void 0!==e?e:i.ao.default}get isBound(){var t,e;return null!==(e=null===(t=this.view)||void 0===t?void 0:t.isBound)&&void 0!==e&&e}get sourceLifetime(){var t;return null===(t=this.view)||void 0===t?void 0:t.sourceLifetime}get template(){var t;if(null===this._template){const e=this.definition;this.source.resolveTemplate?this._template=this.source.resolveTemplate():e.template&&(this._template=null!==(t=e.template)&&void 0!==t?t:null)}return"function"==typeof this._template&&(this._template=this._template(this.source)),this._template}set template(t){this._template!==t&&(this._template=t,"function"==typeof this._template&&(this._template=this._template(this.source)),this.needsInitialization||this.renderTemplate(this._template))}get mainStyles(){var t;if(null===this._mainStyles){const e=this.definition;this.source.resolveStyles?this._mainStyles=this.source.resolveStyles():e.styles&&(this._mainStyles=null!==(t=e.styles)&&void 0!==t?t:null)}return this._mainStyles}set mainStyles(t){this._mainStyles!==t&&(null!==this._mainStyles&&this.removeStyles(this._mainStyles),this._mainStyles=t,this.needsInitialization||this.addStyles(t))}onUnbind(t){var e;null===(e=this.view)||void 0===e||e.onUnbind(t)}addBehavior(t){var e,n;const r=null!==(e=this.behaviors)&&void 0!==e?e:this.behaviors=new Map,i=null!==(n=r.get(t))&&void 0!==n?n:0;0===i?(r.set(t,1),t.addedCallback&&t.addedCallback(this),!t.connectedCallback||this.guardBehaviorConnection||1!==this.stage&&0!==this.stage||t.connectedCallback(this)):r.set(t,i+1)}removeBehavior(t,e=!1){const n=this.behaviors;if(null===n)return;const r=n.get(t);void 0!==r&&(1===r||e?(n.delete(t),t.disconnectedCallback&&3!==this.stage&&t.disconnectedCallback(this),t.removedCallback&&t.removedCallback(this)):n.set(t,r-1))}addStyles(t){var e;if(!t)return;const n=this.source;if(t instanceof HTMLElement){(null!==(e=f(n))&&void 0!==e?e:this.source).append(t)}else if(!t.isAttachedTo(n)){const e=t.behaviors;if(t.addStylesTo(n),null!==e)for(let t=0,n=e.length;t<n;++t)this.addBehavior(e[t])}}removeStyles(t){var e;if(!t)return;const n=this.source;if(t instanceof HTMLElement){(null!==(e=f(n))&&void 0!==e?e:n).removeChild(t)}else if(t.isAttachedTo(n)){const e=t.behaviors;if(t.removeStylesFrom(n),null!==e)for(let t=0,n=e.length;t<n;++t)this.removeBehavior(e[t])}}connect(){3===this.stage&&(this.stage=0,this.bindObservables(),this.connectBehaviors(),this.needsInitialization?(this.renderTemplate(this.template),this.addStyles(this.mainStyles),this.needsInitialization=!1):null!==this.view&&this.view.bind(this.source),this.stage=1,i.cP.notify(this,h))}bindObservables(){if(null!==this.boundObservables){const t=this.source,e=this.boundObservables,n=Object.keys(e);for(let r=0,i=n.length;r<i;++r){const i=n[r];t[i]=e[i]}this.boundObservables=null}}connectBehaviors(){if(!1===this.behaviorsConnected){const t=this.behaviors;if(null!==t){this.guardBehaviorConnection=!0;for(const e of t.keys())e.connectedCallback&&e.connectedCallback(this);this.guardBehaviorConnection=!1}this.behaviorsConnected=!0}}disconnectBehaviors(){if(!0===this.behaviorsConnected){const t=this.behaviors;if(null!==t)for(const e of t.keys())e.disconnectedCallback&&e.disconnectedCallback(this);this.behaviorsConnected=!1}}disconnect(){1===this.stage&&(this.stage=2,i.cP.notify(this,h),null!==this.view&&this.view.unbind(),this.disconnectBehaviors(),this.stage=3)}onAttributeChangedCallback(t,e,n){const r=this.definition.attributeLookup[t];void 0!==r&&r.onAttributeChangedCallback(this.source,n)}emit(t,e,n){return 1===this.stage&&this.source.dispatchEvent(new CustomEvent(t,{detail:e,...u,...n}))}renderTemplate(t){var e;const n=this.source,r=null!==(e=f(n))&&void 0!==e?e:n;if(null!==this.view)this.view.dispose(),this.view=null;else if(!this.needsInitialization||this.hasExistingShadowRoot){this.hasExistingShadowRoot=!1;for(let t=r.firstChild;null!==t;t=r.firstChild)r.removeChild(t)}t&&(this.view=t.render(n,r,n),this.view.sourceLifetime=i.Nx.coupled)}static forCustomElement(t){const e=t.$fastController;if(void 0!==e)return e;const n=l.I.getForInstance(t);if(void 0===n)throw s.Zx.error(1401);return t.$fastController=new p(t,n)}static setStrategy(t){p=t}}function g(t){var e;return"adoptedStyleSheets"in t?t:null!==(e=f(t))&&void 0!==e?e:t.getRootNode()}(0,s.rV)(v),v.setStrategy(v);class b{constructor(t){const e=b.styleSheetCache;this.sheets=t.map(t=>{if(t instanceof CSSStyleSheet)return t;let n=e.get(t);return void 0===n&&(n=new CSSStyleSheet,n.replaceSync(t),e.set(t,n)),n})}addStylesTo(t){const e=g(t);e.adoptedStyleSheets=[...e.adoptedStyleSheets,...this.sheets]}removeStylesFrom(t){const e=g(t),n=this.sheets;e.adoptedStyleSheets=e.adoptedStyleSheets.filter(t=>-1===n.indexOf(t))}}b.styleSheetCache=new Map;let m=0;function y(t){return t===document?document.body:t}o.v.setDefaultStrategy(o.v.supportsAdoptedStyleSheets?b:class{constructor(t){this.styles=t,this.styleClass="fast-"+ ++m}addStylesTo(t){t=y(g(t));const e=this.styles,n=this.styleClass;for(let r=0;r<e.length;r++){const i=document.createElement("style");i.innerHTML=e[r],i.className=n,t.append(i)}}removeStylesFrom(t){const e=(t=y(g(t))).querySelectorAll(`.${this.styleClass}`);for(let n=0,r=e.length;n<r;++n)t.removeChild(e[n])}});const w="defer-hydration",$="needs-hydration";class x extends v{static hydrationObserverHandler(t){for(const e of t)x.hydrationObserver.unobserve(e.target),e.target.$fastController.connect()}connect(){var t,e;if(void 0===this.needsHydration&&(this.needsHydration=null!==this.source.getAttribute($)),this.source.hasAttribute(w))return void x.hydrationObserver.observe(this.source,{attributeFilter:[w]});if(!this.needsHydration)return void super.connect();if(3!==this.stage)return;this.stage=0,this.bindObservables(),this.connectBehaviors();const n=this.source,r=null!==(t=f(n))&&void 0!==t?t:n;if(this.template)if((0,c.VS)(this.template)){let t=r.firstChild,i=r.lastChild;null===n.shadowRoot&&(c.fB.isElementBoundaryStartMarker(t)&&(t.data="",t=t.nextSibling),c.fB.isElementBoundaryEndMarker(i)&&(i.data="",i=i.previousSibling)),this.view=this.template.hydrate(t,i,n),null===(e=this.view)||void 0===e||e.bind(this.source)}else this.renderTemplate(this.template);this.addStyles(this.mainStyles),this.stage=1,this.source.removeAttribute($),this.needsInitialization=this.needsHydration=!1,i.cP.notify(this,h)}disconnect(){super.disconnect(),x.hydrationObserver.unobserve(this.source)}static install(){v.setStrategy(x)}}x.hydrationObserver=new a.ss(x.hydrationObserverHandler)},19249(t,e,n){"use strict";n.d(e,{m(){return R}});var r=n(37180),i=n(56911),s=n(76881),o=n(38493);class a extends s.Og{appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="outline")}}(0,i.Cg)([o.CF,(0,i.Sn)("design:type",String)],a.prototype,"appearance",void 0);var l=n(74849),c=n(22131),u=n(50882),h=n(64187),d=n(73477),f=n(60993),p=n(61484),v=n(48196),g=n(17767),b=n(37302),m=n(7896),y=n(48751),w=n(46203),$=n(57416),x=n(26920),k=n(36452),C=n(74838),S=n(41123),E=n(14996),M=n(79288);const F=l.A`
    :host([appearance="filled"]) .root {
        background: ${b.F7};
        border-color: transparent;
    }

    :host([appearance="filled"]:hover:not([disabled])) .root {
        background: ${b.Xt};
        border-color: transparent;
    }

    :host([appearance="filled"]:focus-within:not([disabled])) .root {
        border-color: transparent;
        box-shadow: none;
    }
    ${p.p}
`.withBehaviors((0,c.mr)(l.A`
            :host([appearance="filled"]) .root {
                background: ${u.A.Field};
                border-color: ${u.A.FieldText};
            }
            :host([appearance="filled"]:hover:not([disabled])) .root,
            :host([appearance="filled"]:focus-within:not([disabled])) .root {
                background: ${u.A.Field};
                border-color: ${u.A.FieldText};
            }
            :host([appearance="filled"]:active:not([disabled])) .root {
                background: ${u.A.Field};
                border-color: ${u.A.FieldText};
            }
            :host([appearance="filled"]:not([disabled]):active)::after,
            :host(
                    [appearance="filled"]:not([disabled]):focus-within:not(:active)
                )::after {
                border-bottom-color: ${u.A.Highlight};
            }
            :host([appearance="filled"][disabled]) .root {
                border-color: ${u.A.GrayText};
                background: ${u.A.Field};
            }
        `)),D=l.A`
    ${(0,h.V)("inline-block")} :host {
        font-family: ${m.O};
        outline: none;
        user-select: none;
        position: relative;
    }

    .root {
        box-sizing: border-box;
        position: relative;
        display: flex;
        flex-direction: row;
        color: ${y.l};
        background: ${w.le};
        border-radius: calc(${$.Pb} * 1px);
        border: calc(${x.XA} * 1px) solid ${k.I2};
        height: calc(${v.D} * 1px);
    }

    .control {
        -webkit-appearance: none;
        background: transparent;
        border: 0;
        height: calc(100% - 4px);
        width: 100%;
        margin-top: auto;
        margin-bottom: auto;
        border: none;
        padding: 0 calc(${C.vR} * 2px + 1px);
        color: ${y.l};
        font-family: inherit;
        font-size: ${S.K};
        line-height: ${S.Z};
    }

    .control:hover,
    .control:${d.N},
    .control:disabled,
    .control:active {
        outline: none;
    }

    .label {
        display: block;
        color: ${y.l};
        cursor: pointer;
        font-size: ${S.K};
        line-height: ${S.Z};
        margin-bottom: 4px;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    ::slotted([slot="start"]),
    ::slotted([slot="end"]) {
        display: flex;
        margin: auto;
        fill: currentcolor;
    }

    ::slotted(svg) {
        ${""} width: 16px;
        height: 16px;
    }

    ::slotted([slot="start"]) {
        margin-inline-start: 11px;
    }

    ::slotted([slot="end"]) {
        margin-inline-end: 11px;
    }

    :host(:hover:not([disabled])) .root {
        background: ${w.jM};
        border-color: ${k.mb};
    }

    :host(:focus-within:not([disabled])) .root {
        border-color: ${E.WN};
        box-shadow: 0 0 0 1px ${E.WN} inset;
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${f.Z};
    }

    :host([disabled]) {
        opacity: ${M.q};
    }
`.withBehaviors((0,g.f)("filled",F),(0,c.mr)(l.A`
            .root {
                forced-color-adjust: none;
                background: ${u.A.Field};
                border-color: ${u.A.FieldText};
            }
            :host(:hover:not([disabled])) .root {
                background: ${u.A.Field};
                border-color: ${u.A.Highlight};
            }
            ::slotted([slot="start"]),
            ::slotted([slot="end"]) {
                fill: ${u.A.ButtonText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .root {
                border-color: ${u.A.GrayText};
                background: ${u.A.Field};
            }
            :host(:focus-within:enabled) .root {
                border-color: ${u.A.Highlight};
                box-shadow: 0 0 0 1px ${u.A.Highlight} inset;
            }
            .control {
                color: ${u.A.ButtonText};
            }
            ::placeholder,
            ::-webkit-input-placeholder {
                color: ${u.A.FieldText};
            }
            :host([disabled]) ::placeholder,
            :host([disabled]) ::-webkit-input-placeholder,
            :host([disabled]) .label {
                color: ${u.A.GrayText};
            }
        `));var O=n(96950),A=n(82774),T=n(60402),I=n(35106),B=n(79109);const N=function(t={}){return O.qy`
        <label
            part="label"
            for="control"
            class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
        >
            <slot
                ${(0,A.e)({property:"defaultSlottedNodes",filter:B.g})}
            ></slot>
        </label>
        <div class="root" part="root">
            ${(0,I.LT)(t)}
            <input
                class="control"
                part="control"
                id="control"
                @input="${t=>t.handleTextInput()}"
                @change="${t=>t.handleChange()}"
                ?autofocus="${t=>t.autofocus}"
                ?disabled="${t=>t.disabled}"
                list="${t=>t.list}"
                maxlength="${t=>t.maxlength}"
                name="${t=>t.name}"
                minlength="${t=>t.minlength}"
                pattern="${t=>t.pattern}"
                placeholder="${t=>t.placeholder}"
                ?readonly="${t=>t.readOnly}"
                ?required="${t=>t.required}"
                size="${t=>t.size}"
                ?spellcheck="${t=>t.spellcheck}"
                :value="${t=>t.value}"
                type="${t=>t.type}"
                aria-atomic="${t=>t.ariaAtomic}"
                aria-busy="${t=>t.ariaBusy}"
                aria-controls="${t=>t.ariaControls}"
                aria-current="${t=>t.ariaCurrent}"
                aria-describedby="${t=>t.ariaDescribedby}"
                aria-details="${t=>t.ariaDetails}"
                aria-disabled="${t=>t.ariaDisabled}"
                aria-errormessage="${t=>t.ariaErrormessage}"
                aria-flowto="${t=>t.ariaFlowto}"
                aria-haspopup="${t=>t.ariaHaspopup}"
                aria-hidden="${t=>t.ariaHidden}"
                aria-invalid="${t=>t.ariaInvalid}"
                aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
                aria-label="${t=>t.ariaLabel}"
                aria-labelledby="${t=>t.ariaLabelledby}"
                aria-live="${t=>t.ariaLive}"
                aria-owns="${t=>t.ariaOwns}"
                aria-relevant="${t=>t.ariaRelevant}"
                aria-roledescription="${t=>t.ariaRoledescription}"
                ${(0,T.K)("control")}
            />
            ${(0,I.aO)(t)}
        </div>
    `}(),R=a.compose({name:`${r.c.prefix}-text-field`,template:N,styles:D,shadowOptions:{delegatesFocus:!0}})},19470(t,e,n){"use strict";n.d(e,{Zx(){return o},iX(){return c},Mg(){return l},tR(){return a},rV(){return u}});var r=n(96293);!function(){if("undefined"==typeof globalThis)if("undefined"!=typeof global)global.globalThis=global;else if("undefined"!=typeof self)self.globalThis=self;else if("undefined"!=typeof window)window.globalThis=window;else{const t=new Function("return this")();t.globalThis=t}}();const i={configurable:!1,enumerable:!1,writable:!1},s=globalThis.window||globalThis;void 0===s.FAST&&Reflect.defineProperty(s,"FAST",{value:Object.create(null),...i});const o=s.FAST;if(void 0===o.getById){const t=Object.create(null);Reflect.defineProperty(o,"getById",{value(e,n){let r=t[e];return void 0===r&&(r=n?t[e]=n():null),r},...i})}void 0===o.error&&Object.assign(o,{warn(){},error:t=>new Error(`Error ${t}`),addMessages(){}});const a=Object.freeze([]);function l(){const t=new WeakMap;return Object.freeze({register:e=>!t.has(e.type)&&(t.set(e.type,e),!0),getByType:e=>t.get(e),getForInstance(e){if(null!=e)return t.get(e.constructor)}})}function c(){const t=new WeakMap;return function(e){let n=t.get(e);if(void 0===n){let r=Reflect.getPrototypeOf(e);for(;void 0===n&&null!==r;)n=t.get(r),r=Reflect.getPrototypeOf(r);n=void 0===n?[]:n.slice(0),t.set(e,n)}return n}}function u(t){t.prototype.toJSON=r.lQ}},20468(t,e,n){"use strict";n.d(e,{OG(){return g},WD(){return h},ZP(){return v},wq(){return f},y0(){return d}});var r=n(58207),i=n(14777),s=n(53894),o=n(88383),a=n(62044),l=n(89449);function c(t){return t?'"'+t[i.W7](/\"/g,l.m5)+'"':l.m5}function u(t,e){var n=(0,o.U5)();if(n){var r="log";n[t]&&(r=t),(0,a.Tn)(n[r])&&n[r](e)}}var h=function(){function t(t,e,n,r){void 0===n&&(n=!1);var s=this;s[i.JR]=t,s[i.pM]=(n?"AI: ":"AI (Internal): ")+t;var a=l.m5;(0,o.Z)()&&(a=(0,o.hm)().stringify(r));var u=(e?" message:"+c(e):l.m5)+(r?" props:"+c(a):l.m5);s[i.pM]+=u}return t.dataType="MessageData",t}();function d(t,e){return(t||{})[i.Uw]||new f(e)}var f=function(){function t(e){this.identifier="DiagnosticLogger",this.queue=[];var n,c,d,f,p=0,v={};(0,r.A)(t,this,function(t){function r(e,n){if(!(p>=d)){var r=!0,s="AITR_"+n[i.JR];if(v[s]?r=!1:v[s]=!0,r&&(e<=c&&(t.queue[i.y5](n),p++,g(1===e?"error":"warn",n)),p===d)){var o="Internal events throttle limit per PageView reached for this app.",a=new h(23,o,!1);t.queue[i.y5](a),1===e?t[l.Zi](o):t[l.Tj](o)}}}function g(t,n){var r=(0,s.$)(e||{});r&&r[i.e4]&&r[i.e4](t,n)}!function(t){n=(0,a.SA)(t.loggingLevelConsole,0),c=(0,a.SA)(t.loggingLevelTelemetry,1),d=(0,a.SA)(t.maxMessageLimit,25),f=(0,a.SA)(t[i.a$],!1)}(e||{}),t.consoleLoggingLevel=function(){return n},t.telemetryLoggingLevel=function(){return c},t.maxInternalMessageLimit=function(){return d},t[i.a$]=function(){return f},t.throwInternal=function(e,s,c,u,d){void 0===d&&(d=!1);var p=new h(s,c,d,u);if(f)throw(0,o.mm)(p);var b=1===e?l.Zi:l.Tj;if((0,a.b0)(p[i.pM]))g("throw"+(1===e?"Critical":"Warning"),p);else{if(d){var m=+p[i.JR];!v[m]&&n>=e&&(t[b](p[i.pM]),v[m]=!0)}else n>=e&&t[b](p[i.pM]);r(e,p)}},t[l.Tj]=function(t){u("warn",t),g("warning",t)},t[l.Zi]=function(t){u("error",t),g("error",t)},t.resetInternalMessageCount=function(){p=0,v={}},t[i.sx]=r})}return t.__ieDyn=1,t}();function p(t){return t||new f}function v(t,e,n,r,i,s){void 0===s&&(s=!1),p(t).throwInternal(e,n,r,i,s)}function g(t,e){p(t)[l.Tj](e)}},21131(t,e,n){"use strict";n.d(e,{IN(){return l}});var r=n(42277),i=n(68244),s=n(50214);const o=i.F.create({trustedType:{createHTML:t=>t.indexOf("<img")>-1&&-1==t.indexOf(":src")&&(t.indexOf('src="fast-')>-1||t.indexOf("src=fast-")>-1)?t.replaceAll("src=",":src="):t}}),a=i.F.create({trustedType:{createHTML:t=>(0,s.v)(t,"base-html-policy")}});function l(){const t=navigator.userAgent.toLowerCase();t.indexOf("chrome")>-1||t.indexOf("edg")>-1?r.d.setPolicy(a):r.d.setPolicy(o)}},21743(t,e,n){"use strict";n.d(e,{E(){return c}});var r=n(96950),i=n(60402),s=n(82774),o=n(17884),a=n(35106),l=n(18893);function c(t={}){return r.qy`
        <template
            aria-disabled="${t=>t.ariaDisabled}"
            autocomplete="${t=>t.autocomplete}"
            ?open="${t=>t.open}"
            tabindex="${t=>t.disabled?null:"0"}"
            @click="${(t,e)=>t.clickHandler(e.event)}"
            @focusout="${(t,e)=>t.focusoutHandler(e.event)}"
            @keydown="${(t,e)=>t.keydownHandler(e.event)}"
        >
            <div class="control" part="control">
                ${(0,a.LT)(t)}
                <slot name="control">
                    <input
                        aria-activedescendant="${t=>t.open?t.ariaActiveDescendant:null}"
                        aria-autocomplete="${t=>t.ariaAutoComplete}"
                        aria-controls="${t=>t.ariaControls}"
                        aria-disabled="${t=>t.ariaDisabled}"
                        aria-expanded="${t=>t.ariaExpanded}"
                        aria-haspopup="listbox"
                        class="selected-value"
                        part="selected-value"
                        placeholder="${t=>t.placeholder}"
                        role="combobox"
                        type="text"
                        ?disabled="${t=>t.disabled}"
                        :value="${t=>t.value}"
                        @input="${(t,e)=>t.inputHandler(e.event)}"
                        @keyup="${(t,e)=>t.keyupHandler(e.event)}"
                        ${(0,i.K)("control")}
                    />
                    <div class="indicator" part="indicator" aria-hidden="true">
                        <slot name="indicator">
                            ${(0,l.R)(t.indicator)}
                        </slot>
                    </div>
                </slot>
                ${(0,a.aO)(t)}
            </div>
            <div
                class="listbox"
                id="${t=>t.listboxId}"
                part="listbox"
                role="listbox"
                ?disabled="${t=>t.disabled}"
                ?hidden="${t=>!t.open}"
                ${(0,i.K)("listbox")}
            >
                <slot
                    ${(0,s.e)({filter:o.U.slottedOptionFilter,flatten:!0,property:"slottedOptions"})}
                ></slot>
            </div>
        </template>
    `}},22020(t,e,n){"use strict";n.d(e,{NA(){return g},qQ(){return m},xW(){return b},Sk(){return y}});var r=n(34188);class i extends Error{constructor(t,e,n){super(t),this.factories=e,this.node=n}}function s(t){return t.nodeType===Node.COMMENT_NODE}function o(t){return t.nodeType===Node.TEXT_NODE}function a(t,e){const n=document.createRange();return n.setStart(t,0),n.setEnd(e,s(e)||o(e)?e.data.length:e.childNodes.length),n}function l(t,e,n){const s=r.fB.parseAttributeBinding(t);if(null!==s){for(const r of s){if(!e[r])throw new i(`HydrationView was unable to successfully target factory on ${t.nodeName} inside ${t.getRootNode().host.nodeName}. This likely indicates a template mismatch between SSR rendering and hydration.`,e,t);u(e[r],t,n)}t.removeAttribute(r.fB.attributeMarkerName)}}function c(t,e,n,a,l){if(r.fB.isElementBoundaryStartMarker(t))!function(t,e){const n=r.fB.parseElementBoundaryStartMarker(t.data);let i=e.nextSibling();for(;null!==i;){if(s(i)){const t=r.fB.parseElementBoundaryEndMarker(i.data);if(t&&t===n)break}i=e.nextSibling()}}(t,e);else if(r.fB.isContentBindingStartMarker(t.data)){const c=r.fB.parseContentBindingStartMarker(t.data);if(null===c)return;const[h,d]=c,f=n[h];if(!f)throw new i(`HydrationView was unable to successfully target factory on ${t.nodeName} for ${t.data}. This likely indicates a template mismatch between SSR rendering and hydration.`,n,e.root);const p=[];let v=e.nextSibling();t.data="";const g=v;for(;null!==v;){if(s(v)){const t=r.fB.parseContentBindingEndMarker(v.data);if(t&&t[1]===d)break}p.push(v),v=e.nextSibling()}if(null===v){const e=t.getRootNode();throw new Error(`Error when hydrating inside ${function(t){return t instanceof DocumentFragment&&"mode"in t}(e)?e.host.nodeName:e.nodeName}: current should never be null. This is a SSR software defect`)}if(v.data="",1===p.length&&o(p[0]))u(f,p[0],a);else{v!==g&&null!==v.previousSibling&&(l[f.targetNodeId]={first:g,last:v.previousSibling});u(f,v.parentNode.insertBefore(document.createTextNode(""),v),a)}}}function u(t,e,n){if(void 0===t.targetNodeId)throw new Error("Factory could not be target to the node");n[t.targetNodeId]=e}var h,d=n(60815),f=n(19470);function p(t,e){const n=t.parentNode;let r,i=t;for(;i!==e;){if(r=i.nextSibling,!r)throw new Error(`Unmatched first/last child inside ${e.getRootNode().host.nodeName}. This is a SSR software defect`);n.removeChild(i),i=r}n.removeChild(e)}class v{constructor(){this.index=0,this.length=0}get event(){return d.ao.getEvent()}get isEven(){return this.index%2==0}get isOdd(){return this.index%2!=0}get isFirst(){return 0===this.index}get isInMiddle(){return!this.isFirst&&!this.isLast}get isLast(){return this.index===this.length-1}eventDetail(){return this.event.detail}eventTarget(){return this.event.target}}class g extends v{constructor(t,e,n){super(),this.fragment=t,this.factories=e,this.targets=n,this.behaviors=null,this.unbindables=[],this.source=null,this.isBound=!1,this.sourceLifetime=d.Nx.unknown,this.context=this,this.firstChild=t.firstChild,this.lastChild=t.lastChild}appendTo(t){t.appendChild(this.fragment)}insertBefore(t){if(this.fragment.hasChildNodes())t.parentNode.insertBefore(this.fragment,t);else{const e=this.lastChild;if(t.previousSibling===e)return;const n=t.parentNode;let r,i=this.firstChild;for(;i!==e;)r=i.nextSibling,n.insertBefore(i,t),i=r;n.insertBefore(e,t)}}remove(){const t=this.fragment,e=this.lastChild;let n,r=this.firstChild;for(;r!==e;)n=r.nextSibling,t.appendChild(r),r=n;t.appendChild(e)}dispose(){p(this.firstChild,this.lastChild),this.unbind()}onUnbind(t){this.unbindables.push(t)}bind(t,e=this){if(this.source===t)return;let n=this.behaviors;if(null===n){this.source=t,this.context=e,this.behaviors=n=new Array(this.factories.length);const r=this.factories;for(let t=0,e=r.length;t<e;++t){const e=r[t].createBehavior();e.bind(this),n[t]=e}}else{null!==this.source&&this.evaluateUnbindables(),this.isBound=!1,this.source=t,this.context=e;for(let t=0,e=n.length;t<e;++t)n[t].bind(this)}this.isBound=!0}unbind(){this.isBound&&null!==this.source&&(this.evaluateUnbindables(),this.source=null,this.context=this,this.isBound=!1)}evaluateUnbindables(){const t=this.unbindables;for(let e=0,n=t.length;e<n;++e)t[e].unbind(this);t.length=0}static disposeContiguousBatch(t){if(0!==t.length){p(t[0].firstChild,t[t.length-1].lastChild);for(let e=0,n=t.length;e<n;++e)t[e].unbind()}}}(0,f.rV)(g),d.cP.defineProperty(g.prototype,"index"),d.cP.defineProperty(g.prototype,"length");const b={unhydrated:"unhydrated",hydrating:"hydrating",hydrated:"hydrated"};class m extends Error{constructor(t,e,n,r){super(t),this.factory=e,this.fragment=n,this.templateString=r}}class y extends v{constructor(t,e,n,i){super(),this.firstChild=t,this.lastChild=e,this.sourceTemplate=n,this.hostBindingTarget=i,this[h]=r.vB,this.context=this,this.source=null,this.isBound=!1,this.sourceLifetime=d.Nx.unknown,this.unbindables=[],this.fragment=null,this.behaviors=null,this._hydrationStage=b.unhydrated,this._bindingViewBoundaries={},this._targets={},this.factories=n.compile().factories}get hydrationStage(){return this._hydrationStage}get targets(){return this._targets}get bindingViewBoundaries(){return this._bindingViewBoundaries}insertBefore(t){if(null!==this.fragment)if(this.fragment.hasChildNodes())t.parentNode.insertBefore(this.fragment,t);else{const e=this.lastChild;if(t.previousSibling===e)return;const n=t.parentNode;let r,i=this.firstChild;for(;i!==e;)r=i.nextSibling,n.insertBefore(i,t),i=r;n.insertBefore(e,t)}}appendTo(t){null!==this.fragment&&t.appendChild(this.fragment)}remove(){const t=this.fragment||(this.fragment=document.createDocumentFragment()),e=this.lastChild;let n,r=this.firstChild;for(;r!==e;){if(n=r.nextSibling,!n)throw new Error(`Unmatched first/last child inside ${e.getRootNode().host.nodeName}. This is a SSR software defect`);t.appendChild(r),r=n}t.appendChild(e)}bind(t,e=this){if(this.hydrationStage!==b.hydrated&&(this._hydrationStage=b.hydrating),this.source===t)return;let n=this.behaviors;if(null===n){this.source=t,this.context=e;try{const{targets:t,boundaries:e}=function(t,e,n){const r=a(t,e),i=r.commonAncestorContainer,s=document.createTreeWalker(i,NodeFilter.SHOW_ELEMENT+NodeFilter.SHOW_COMMENT+NodeFilter.SHOW_TEXT,{acceptNode(t){return 0===r.comparePoint(t,0)?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_REJECT}}),o={},u={};let h=s.currentNode=t;for(;null!==h;){switch(h.nodeType){case Node.ELEMENT_NODE:l(h,n,o);break;case Node.COMMENT_NODE:c(h,s,n,o,u)}h=s.nextNode()}return r.detach(),{targets:o,boundaries:u}}(this.firstChild,this.lastChild,this.factories);this._targets=t,this._bindingViewBoundaries=e}catch(t){if(t instanceof i){let e=this.sourceTemplate.html;"string"!=typeof e&&(e=e.innerHTML),t.templateString=e}throw t}this.behaviors=n=new Array(this.factories.length);const r=this.factories;for(let t=0,e=r.length;t<e;++t){const e=r[t];if("h"===e.targetNodeId&&this.hostBindingTarget&&u(e,this.hostBindingTarget,this._targets),!(e.targetNodeId in this.targets)){let t=this.sourceTemplate.html;throw"string"!=typeof t&&(t=t.innerHTML),new m(`HydrationView was unable to successfully target bindings inside ${this.firstChild.getRootNode().host.nodeName}.This is likely a hydration software defect.`,e,a(this.firstChild,this.lastChild).cloneContents(),t)}{const r=e.createBehavior();r.bind(this),n[t]=r}}}else{null!==this.source&&this.evaluateUnbindables(),this.isBound=!1,this.source=t,this.context=e;for(let t=0,e=n.length;t<e;++t)n[t].bind(this)}this.isBound=!0,this._hydrationStage=b.hydrated}unbind(){this.isBound&&null!==this.source&&(this.evaluateUnbindables(),this.source=null,this.context=this,this.isBound=!1)}dispose(){p(this.firstChild,this.lastChild),this.unbind()}onUnbind(t){this.unbindables.push(t)}evaluateUnbindables(){const t=this.unbindables;for(let e=0,n=t.length;e<n;++e)t[e].unbind(this);t.length=0}}h=r.vB,(0,f.rV)(y)},22131(t,e,n){"use strict";n.d(e,{C7(){return a},G2(){return o},mr(){return s},s5(){return i}});class r{constructor(t){this.listenerCache=new WeakMap,this.query=t}connectedCallback(t){const{query:e}=this;let n=this.listenerCache.get(t);n||(n=this.constructListener(t),this.listenerCache.set(t,n)),n.bind(e)(),e.addEventListener("change",n)}disconnectedCallback(t){const e=this.listenerCache.get(t);e&&this.query.removeEventListener("change",e)}}class i extends r{constructor(t,e){super(t),this.styles=e}static with(t){return e=>new i(t,e)}constructListener(t){let e=!1;const n=this.styles;return function(){const{matches:r}=this;r&&!e?(t.addStyles(n),e=r):!r&&e&&(t.removeStyles(n),e=r)}}removedCallback(t){t.removeStyles(this.styles)}}const s=i.with(window.matchMedia("(forced-colors)")),o=i.with(window.matchMedia("(prefers-color-scheme: dark)")),a=i.with(window.matchMedia("(prefers-color-scheme: light)"))},22192(t,e,n){"use strict";n.d(e,{S(){return i},p(){return s}});var r=n(96950);const i=r.qy`
<span part="end" class="end">
    <slot name="end"></slot>
</span>
`,s=r.qy`
<span part="start" class="start">
    <slot name="start"></slot>
</span>
`},22448(t,e,n){"use strict";n.d(e,{z(){return o}});var r=n(56911),i=n(65923),s=n(38493);class o extends i.th{connectedCallback(){super.connectedCallback(),this.startColumnCount||(this.startColumnCount=1)}}(0,r.Cg)([(0,s.CF)({attribute:"start-column-count"}),(0,r.Sn)("design:type",Object)],o.prototype,"startColumnCount",void 0)},22683(t,e,n){"use strict";n.d(e,{Rq(){return h},hb(){return u}});var r=n(45755),i=n(68009),s=n(95239),o=n(6352),a=n(31023);const{create:l}=r.G,c=l({name:"neutral-stroke-divider-recipe"},{evaluate(t,e){return function(t,e,n){return t.get(t.closestIndexOf(e)+(0,i.F)(e)*n)}(t(a.r),e||t(s.p),t(o.X))}}),u=l("neutral-stroke-divider-rest",t=>t(c).evaluate(t)),h=u},22870(t,e,n){"use strict";n.d(e,{Bi(){return u},wD(){return d},H0(){return v},Hs(){return f},QI(){return p}});var r=n(87122),i=n(37820);const s={aliceblue:{r:.941176,g:.972549,b:1},antiquewhite:{r:.980392,g:.921569,b:.843137},aqua:{r:0,g:1,b:1},aquamarine:{r:.498039,g:1,b:.831373},azure:{r:.941176,g:1,b:1},beige:{r:.960784,g:.960784,b:.862745},bisque:{r:1,g:.894118,b:.768627},black:{r:0,g:0,b:0},blanchedalmond:{r:1,g:.921569,b:.803922},blue:{r:0,g:0,b:1},blueviolet:{r:.541176,g:.168627,b:.886275},brown:{r:.647059,g:.164706,b:.164706},burlywood:{r:.870588,g:.721569,b:.529412},cadetblue:{r:.372549,g:.619608,b:.627451},chartreuse:{r:.498039,g:1,b:0},chocolate:{r:.823529,g:.411765,b:.117647},coral:{r:1,g:.498039,b:.313725},cornflowerblue:{r:.392157,g:.584314,b:.929412},cornsilk:{r:1,g:.972549,b:.862745},crimson:{r:.862745,g:.078431,b:.235294},cyan:{r:0,g:1,b:1},darkblue:{r:0,g:0,b:.545098},darkcyan:{r:0,g:.545098,b:.545098},darkgoldenrod:{r:.721569,g:.52549,b:.043137},darkgray:{r:.662745,g:.662745,b:.662745},darkgreen:{r:0,g:.392157,b:0},darkgrey:{r:.662745,g:.662745,b:.662745},darkkhaki:{r:.741176,g:.717647,b:.419608},darkmagenta:{r:.545098,g:0,b:.545098},darkolivegreen:{r:.333333,g:.419608,b:.184314},darkorange:{r:1,g:.54902,b:0},darkorchid:{r:.6,g:.196078,b:.8},darkred:{r:.545098,g:0,b:0},darksalmon:{r:.913725,g:.588235,b:.478431},darkseagreen:{r:.560784,g:.737255,b:.560784},darkslateblue:{r:.282353,g:.239216,b:.545098},darkslategray:{r:.184314,g:.309804,b:.309804},darkslategrey:{r:.184314,g:.309804,b:.309804},darkturquoise:{r:0,g:.807843,b:.819608},darkviolet:{r:.580392,g:0,b:.827451},deeppink:{r:1,g:.078431,b:.576471},deepskyblue:{r:0,g:.74902,b:1},dimgray:{r:.411765,g:.411765,b:.411765},dimgrey:{r:.411765,g:.411765,b:.411765},dodgerblue:{r:.117647,g:.564706,b:1},firebrick:{r:.698039,g:.133333,b:.133333},floralwhite:{r:1,g:.980392,b:.941176},forestgreen:{r:.133333,g:.545098,b:.133333},fuchsia:{r:1,g:0,b:1},gainsboro:{r:.862745,g:.862745,b:.862745},ghostwhite:{r:.972549,g:.972549,b:1},gold:{r:1,g:.843137,b:0},goldenrod:{r:.854902,g:.647059,b:.12549},gray:{r:.501961,g:.501961,b:.501961},green:{r:0,g:.501961,b:0},greenyellow:{r:.678431,g:1,b:.184314},grey:{r:.501961,g:.501961,b:.501961},honeydew:{r:.941176,g:1,b:.941176},hotpink:{r:1,g:.411765,b:.705882},indianred:{r:.803922,g:.360784,b:.360784},indigo:{r:.294118,g:0,b:.509804},ivory:{r:1,g:1,b:.941176},khaki:{r:.941176,g:.901961,b:.54902},lavender:{r:.901961,g:.901961,b:.980392},lavenderblush:{r:1,g:.941176,b:.960784},lawngreen:{r:.486275,g:.988235,b:0},lemonchiffon:{r:1,g:.980392,b:.803922},lightblue:{r:.678431,g:.847059,b:.901961},lightcoral:{r:.941176,g:.501961,b:.501961},lightcyan:{r:.878431,g:1,b:1},lightgoldenrodyellow:{r:.980392,g:.980392,b:.823529},lightgray:{r:.827451,g:.827451,b:.827451},lightgreen:{r:.564706,g:.933333,b:.564706},lightgrey:{r:.827451,g:.827451,b:.827451},lightpink:{r:1,g:.713725,b:.756863},lightsalmon:{r:1,g:.627451,b:.478431},lightseagreen:{r:.12549,g:.698039,b:.666667},lightskyblue:{r:.529412,g:.807843,b:.980392},lightslategray:{r:.466667,g:.533333,b:.6},lightslategrey:{r:.466667,g:.533333,b:.6},lightsteelblue:{r:.690196,g:.768627,b:.870588},lightyellow:{r:1,g:1,b:.878431},lime:{r:0,g:1,b:0},limegreen:{r:.196078,g:.803922,b:.196078},linen:{r:.980392,g:.941176,b:.901961},magenta:{r:1,g:0,b:1},maroon:{r:.501961,g:0,b:0},mediumaquamarine:{r:.4,g:.803922,b:.666667},mediumblue:{r:0,g:0,b:.803922},mediumorchid:{r:.729412,g:.333333,b:.827451},mediumpurple:{r:.576471,g:.439216,b:.858824},mediumseagreen:{r:.235294,g:.701961,b:.443137},mediumslateblue:{r:.482353,g:.407843,b:.933333},mediumspringgreen:{r:0,g:.980392,b:.603922},mediumturquoise:{r:.282353,g:.819608,b:.8},mediumvioletred:{r:.780392,g:.082353,b:.521569},midnightblue:{r:.098039,g:.098039,b:.439216},mintcream:{r:.960784,g:1,b:.980392},mistyrose:{r:1,g:.894118,b:.882353},moccasin:{r:1,g:.894118,b:.709804},navajowhite:{r:1,g:.870588,b:.678431},navy:{r:0,g:0,b:.501961},oldlace:{r:.992157,g:.960784,b:.901961},olive:{r:.501961,g:.501961,b:0},olivedrab:{r:.419608,g:.556863,b:.137255},orange:{r:1,g:.647059,b:0},orangered:{r:1,g:.270588,b:0},orchid:{r:.854902,g:.439216,b:.839216},palegoldenrod:{r:.933333,g:.909804,b:.666667},palegreen:{r:.596078,g:.984314,b:.596078},paleturquoise:{r:.686275,g:.933333,b:.933333},palevioletred:{r:.858824,g:.439216,b:.576471},papayawhip:{r:1,g:.937255,b:.835294},peachpuff:{r:1,g:.854902,b:.72549},peru:{r:.803922,g:.521569,b:.247059},pink:{r:1,g:.752941,b:.796078},plum:{r:.866667,g:.627451,b:.866667},powderblue:{r:.690196,g:.878431,b:.901961},purple:{r:.501961,g:0,b:.501961},red:{r:1,g:0,b:0},rosybrown:{r:.737255,g:.560784,b:.560784},royalblue:{r:.254902,g:.411765,b:.882353},saddlebrown:{r:.545098,g:.270588,b:.07451},salmon:{r:.980392,g:.501961,b:.447059},sandybrown:{r:.956863,g:.643137,b:.376471},seagreen:{r:.180392,g:.545098,b:.341176},seashell:{r:1,g:.960784,b:.933333},sienna:{r:.627451,g:.321569,b:.176471},silver:{r:.752941,g:.752941,b:.752941},skyblue:{r:.529412,g:.807843,b:.921569},slateblue:{r:.415686,g:.352941,b:.803922},slategray:{r:.439216,g:.501961,b:.564706},slategrey:{r:.439216,g:.501961,b:.564706},snow:{r:1,g:.980392,b:.980392},springgreen:{r:0,g:1,b:.498039},steelblue:{r:.27451,g:.509804,b:.705882},tan:{r:.823529,g:.705882,b:.54902},teal:{r:0,g:.501961,b:.501961},thistle:{r:.847059,g:.74902,b:.847059},tomato:{r:1,g:.388235,b:.278431},transparent:{r:0,g:0,b:0,a:0},turquoise:{r:.25098,g:.878431,b:.815686},violet:{r:.933333,g:.509804,b:.933333},wheat:{r:.960784,g:.870588,b:.701961},white:{r:1,g:1,b:1},whitesmoke:{r:.960784,g:.960784,b:.960784},yellow:{r:1,g:1,b:0},yellowgreen:{r:.603922,g:.803922,b:.196078}},o=/^rgb\(\s*((?:(?:25[0-5]|2[0-4]\d|1\d\d|\d{1,2})\s*,\s*){2}(?:25[0-5]|2[0-4]\d|1\d\d|\d{1,2})\s*)\)$/i,a=/^rgba\(\s*((?:(?:25[0-5]|2[0-4]\d|1\d\d|\d{1,2})\s*,\s*){3}(?:0|1|0?\.\d*)\s*)\)$/i,l=/^#((?:[0-9a-f]{6}|[0-9a-f]{3}))$/i,c=/^#((?:[0-9a-f]{8}|[0-9a-f]{4}))$/i;function u(t){return l.test(t)}function h(t){return function(t){return c.test(t)}(t)}function d(t){return o.test(t)}function f(t){const e=l.exec(t);if(null===e)return null;let n=e[1];if(3===n.length){const t=n.charAt(0),e=n.charAt(1),r=n.charAt(2);n=t.concat(t,e,e,r,r)}const s=parseInt(n,16);return isNaN(s)?null:new r.M((0,i.S8)((16711680&s)>>>16,0,255),(0,i.S8)((65280&s)>>>8,0,255),(0,i.S8)(255&s,0,255),1)}function p(t){const e=o.exec(t);if(null===e)return null;const n=e[1].split(",");return new r.M((0,i.S8)(Number(n[0]),0,255),(0,i.S8)(Number(n[1]),0,255),(0,i.S8)(Number(n[2]),0,255),1)}function v(t){const e=t.toLowerCase();return u(e)?f(e):h(e)?function(t){const e=c.exec(t);if(null===e)return null;let n=e[1];if(4===n.length){const t=n.charAt(0),e=n.charAt(1),r=n.charAt(2),i=n.charAt(3);n=t.concat(t,e,e,r,r,i,i)}const s=parseInt(n,16);return isNaN(s)?null:new r.M((0,i.S8)((16711680&s)>>>16,0,255),(0,i.S8)((65280&s)>>>8,0,255),(0,i.S8)(255&s,0,255),(0,i.S8)((4278190080&s)>>>24,0,255))}(e):d(e)?p(e):function(t){return a.test(t)}(e)?function(t){const e=a.exec(t);if(null===e)return null;const n=e[1].split(",");return 4===n.length?new r.M((0,i.S8)(Number(n[0]),0,255),(0,i.S8)(Number(n[1]),0,255),(0,i.S8)(Number(n[2]),0,255),Number(n[3])):null}(e):function(t){return s.hasOwnProperty(t)}(e)?function(t){const e=s[t.toLowerCase()];return e?new r.M(e.r,e.g,e.b,e.hasOwnProperty("a")?e.a:void 0):null}(e):null}},23429(t,e,n){"use strict";n.d(e,{L(){return i}});var r=n(96293);const i=n(19470).Zx.getById(r.uL.updateQueue,()=>{const t=[],e=[];let n=!0;function r(){if(e.length)throw e.shift()}function i(i){try{i.call()}catch(i){if(!n)throw t.length=0,i;e.push(i),setTimeout(r,0)}}function s(){let e=0;for(;e<t.length;)if(i(t[e]),e++,e>1024){for(let n=0,r=t.length-e;n<r;n++)t[n]=t[n+e];t.length-=e,e=0}t.length=0}function o(e){t.push(e),t.length<2&&(n?globalThis.requestAnimationFrame(s):s())}return Object.freeze({enqueue:o,next(){return new Promise(o)},process:s,setMode(t){return n=t}})})},23837(t,e,n){"use strict";n.d(e,{FASTElement(){return r.L}});var r=n(92011)},24458(t,e,n){"use strict";n.d(e,{HW(){return u},M3(){return l},m_(){return c}});var r=n(45755),i=n(95239),s=n(47691),o=n(31023);const{create:a}=r.G,l=a({name:"neutral-fill-layer-recipe"},{evaluate(t,e){return function(t,e,n){const r=t.closestIndexOf(e);return t.get(r-n)}(t(o.r),e||t(i.p),t(s.E))}}),c=a("neutral-fill-layer-rest",t=>t(l).evaluate(t)),u=c},24642(t,e,n){"use strict";n.d(e,{Nk(){return f},TF(){return r},el(){return p},kT(){return a},o1(){return u},qE(){return v},sP(){return l},v2(){return d},vp(){return h}});var r,i=n(14848),s=n(22870),o=n(18284);function a(t){const e=(0,o.A)(t);return function(t){return"function"==typeof t?n=>e(Object.assign({},n,{backgroundColor:t(n)})):e(t)}}function l(t,e){const n=(0,o.A)(e);return e=>"function"==typeof e?r=>n(Object.assign({},r,{backgroundColor:e(r)}))[t]:n(e)[t]}!function(t){t.rest="rest",t.hover="hover",t.active="active",t.focus="focus",t.selected="selected"}(r||(r={}));const c=(0,o.A)(t=>{let e=(0,s.Hs)(t);if(null!==e)return e;if(e=(0,s.QI)(t),null!==e)return e;throw new Error(`${t} cannot be converted to a ColorRGBA64. Color strings must be one of the following formats: "#RGB", "#RRGGBB", or "rgb(r, g, b)"`)});function u(t){return(0,s.Bi)(t)||(0,s.wD)(t)}function h(t,e){return c(t).equalValue(c(e))}const d=(0,o.A)((t,e)=>(0,i.yN)(c(t),c(e)),(t,e)=>t+e);function f(t){return(0,i.Z8)(c(t))}function p(...t){return e=>Math.max.apply(null,t.map(t=>t(e)))}const v=(t,e,n)=>Math.min(Math.max(t,e),n)},25984(t,e,n){"use strict";n.d(e,{LA(){return M},Vw(){return C},ZI(){return E},_9(){return k},aY(){return S},ss(){return F}});var r=n(64187),i=n(22131),s=n(73477),o=n(74849),a=n(50882),l=n(48196),c=n(41123),u=n(57416),h=n(64699),d=n(74838),f=n(14996),p=n(4283),v=n(92393),g=n(7896),b=n(74089),m=n(26920),y=n(37302),w=n(45476),$=n(48751),x=n(36452);const k=o.A`
    ${(0,r.V)("inline-flex")} :host {
        font-family: ${g.O};
        outline: none;
        font-size: ${c.K};
        line-height: ${c.Z};
        height: calc(${l.D} * 1px);
        min-width: calc(${l.D} * 1px);
        background-color: ${y.F7};
        color: ${$.l};
        border-radius: calc(${u.Pb} * 1px);
        fill: currentcolor;
        cursor: pointer;
    }

    .control {
        background: transparent;
        height: inherit;
        flex-grow: 1;
        box-sizing: border-box;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        padding: 0 calc((10 + (${d.vR} * 2 * ${d.Br})) * 1px);
        white-space: nowrap;
        outline: none;
        text-decoration: none;
        border: calc(${m.XA} * 1px) solid transparent;
        color: inherit;
        border-radius: inherit;
        fill: inherit;
        cursor: inherit;
        font-family: inherit;
    }

    .control,
    ::slotted([slot="end"]),
    ::slotted([slot="start"]) {
        font: inherit;
    }

    :host([icon-only]) .control,
    .control.icon-only {
        padding: 0;
        line-height: 0;
    }

    :host(:hover) {
        background-color: ${y.Xt};
    }

    :host(:active) {
        background-color: ${y.X4};
    }

    ${""}
    .control:${s.N} {
        border: calc(${m.XA} * 1px) solid ${f.WN};
        box-shadow: 0 0 0 calc((${m.vd} - ${m.XA}) * 1px)
            ${f.WN};
    }

    .control::-moz-focus-inner {
        border: 0;
    }

    .content {
        pointer-events: none;
    }

    ::slotted([slot="start"]),
    ::slotted([slot="end"]) {
        display: flex;
        pointer-events: none;
    }

    ::slotted(svg) {
        ${""} width: 16px;
        height: 16px;
        pointer-events: none;
    }

    ::slotted([slot="start"]) {
        margin-inline-end: 11px;
    }

    ::slotted([slot="end"]) {
        margin-inline-start: 11px;
    }
`.withBehaviors((0,i.mr)(o.A`
        :host,
        :host([appearance="neutral"]) .control {
          background-color: ${a.A.ButtonFace};
          border-color: ${a.A.ButtonText};
          color: ${a.A.ButtonText};
          fill: currentcolor;
        }

        :host(:not([disabled][href]):hover),
        :host([appearance="neutral"]:not([disabled]):hover) .control {
          forced-color-adjust: none;
          background-color: ${a.A.Highlight};
          color: ${a.A.HighlightText};
        }

        .control:${s.N},
        :host([appearance="outline"]) .control:${s.N},
        :host([appearance="neutral"]:${s.N}) .control {
          forced-color-adjust: none;
          background-color: ${a.A.Highlight};
          border-color: ${a.A.ButtonText};
          box-shadow: 0 0 0 calc((${m.vd} - ${m.XA}) * 1px) ${a.A.ButtonText};
          color: ${a.A.HighlightText};
        }

        .control:not([disabled]):hover,
        :host([appearance="outline"]) .control:hover {
          border-color: ${a.A.ButtonText};
        }

        :host([href]) .control {
          border-color: ${a.A.LinkText};
          color: ${a.A.LinkText};
        }

        :host([href]) .control:hover,
        :host(.neutral[href]) .control:hover,
        :host(.outline[href]) .control:hover,
        :host([href]) .control:${s.N}{
          forced-color-adjust: none;
          background: ${a.A.ButtonFace};
          border-color: ${a.A.LinkText};
          box-shadow: 0 0 0 1px ${a.A.LinkText} inset;
          color: ${a.A.LinkText};
          fill: currentcolor;
        }
    `)),C=o.A`
    :host([appearance="accent"]) {
        background: ${p.IR};
        color: ${b.l_};
    }

    :host([appearance="accent"]:hover) {
        background: ${p.OS};
        color: ${b.XK};
    }

    :host([appearance="accent"]:active) .control:active {
        background: ${p.am};
        color: ${b.J_};
    }

    :host([appearance="accent"]) .control:${s.N} {
        box-shadow: 0 0 0 calc(${m.vd} * 1px) inset ${h.fF},
            0 0 0 calc((${m.vd} - ${m.XA}) * 1px) ${f.WN};
    }
`.withBehaviors((0,i.mr)(o.A`
            :host([appearance="accent"]) .control {
                forced-color-adjust: none;
                background: ${a.A.Highlight};
                color: ${a.A.HighlightText};
            }

            :host([appearance="accent"]) .control:hover,
            :host([appearance="accent"]:active) .control:active {
                background: ${a.A.HighlightText};
                border-color: ${a.A.Highlight};
                color: ${a.A.Highlight};
            }

            :host([appearance="accent"]) .control:${s.N} {
                border-color: ${a.A.ButtonText};
                box-shadow: 0 0 0 2px ${a.A.HighlightText} inset;
            }

            :host([appearance="accent"][href]) .control {
                background: ${a.A.LinkText};
                color: ${a.A.HighlightText};
            }

            :host([appearance="accent"][href]) .control:hover {
                background: ${a.A.ButtonFace};
                border-color: ${a.A.LinkText};
                box-shadow: none;
                color: ${a.A.LinkText};
                fill: currentcolor;
            }

            :host([appearance="accent"][href]) .control:${s.N} {
                border-color: ${a.A.LinkText};
                box-shadow: 0 0 0 2px ${a.A.HighlightText} inset;
            }
        `)),S=o.A`
    :host([appearance="hypertext"]) {
        height: auto;
        font-size: inherit;
        line-height: inherit;
        background: transparent;
        min-width: 0;
    }

    :host([appearance="hypertext"]) .control {
        display: inline;
        padding: 0;
        border: none;
        box-shadow: none;
        border-radius: 0;
        line-height: 1;
    }
    :host a.control:not(:link) {
        background-color: transparent;
        cursor: default;
    }
    :host([appearance="hypertext"]) .control:link,
    :host([appearance="hypertext"]) .control:visited {
        background: transparent;
        color: ${v.W_};
        border-bottom: calc(${m.XA} * 1px) solid ${v.W_};
    }
    :host([appearance="hypertext"]) .control:hover {
        border-bottom-color: ${v.YL};
    }
    :host([appearance="hypertext"]) .control:active {
        border-bottom-color: ${v.QL};
    }
    :host([appearance="hypertext"]) .control:${s.N} {
        border-bottom: calc(${m.vd} * 1px) solid ${f.WN};
        margin-bottom: calc(calc(${m.XA} - ${m.vd}) * 1px);
    }
`.withBehaviors((0,i.mr)(o.A`
            :host([appearance="hypertext"]) .control:${s.N} {
                color: ${a.A.LinkText};
                border-bottom-color: ${a.A.LinkText};
            }
        `)),E=o.A`
    :host([appearance="lightweight"]) {
        background: transparent;
        color: ${v.W_};
    }

    :host([appearance="lightweight"]) .control {
        padding: 0;
        height: initial;
        border: none;
        box-shadow: none;
        border-radius: 0;
    }

    :host([appearance="lightweight"]:hover) {
        color: ${v.YL};
    }

    :host([appearance="lightweight"]:active) {
        color: ${v.QL};
    }

    :host([appearance="lightweight"]) .content {
        position: relative;
    }

    :host([appearance="lightweight"]) .content::before {
        content: "";
        display: block;
        height: calc(${m.XA} * 1px);
        position: absolute;
        top: calc(1em + 3px);
        width: 100%;
    }

    :host([appearance="lightweight"]:hover) .content::before {
        background: ${v.YL};
    }

    :host([appearance="lightweight"]:active) .content::before {
        background: ${v.QL};
    }

    :host([appearance="lightweight"]) .control:${s.N} .content::before {
        background: ${$.l};
        height: calc(${m.vd} * 1px);
    }
`.withBehaviors((0,i.mr)(o.A`
            :host([appearance="lightweight"]) {
                color: ${a.A.ButtonText};
            }
            :host([appearance="lightweight"]) .control:hover,
        :host([appearance="lightweight"]) .control:${s.N} {
                forced-color-adjust: none;
                background: ${a.A.ButtonFace};
                color: ${a.A.Highlight};
            }
            :host([appearance="lightweight"]) .control:hover .content::before,
        :host([appearance="lightweight"]) .control:${s.N} .content::before {
                background: ${a.A.Highlight};
            }

            :host([appearance="lightweight"][href]) .control:hover,
        :host([appearance="lightweight"][href]) .control:${s.N} {
                background: ${a.A.ButtonFace};
                box-shadow: none;
                color: ${a.A.LinkText};
            }

            :host([appearance="lightweight"][href]) .control:hover .content::before,
        :host([appearance="lightweight"][href]) .control:${s.N} .content::before {
                background: ${a.A.LinkText};
            }
        `)),M=o.A`
    :host([appearance="outline"]) {
        background: transparent;
        border-color: ${x.I2};
    }

    :host([appearance="outline"]:hover) {
        border-color: ${x.mb};
    }

    :host([appearance="outline"]:active) {
        border-color: ${x.MY};
    }

    :host([appearance="outline"]) .control {
        border-color: inherit;
    }

    :host([appearance="outline"]) .control:${s.N} {
        box-shadow: 0 0 0 calc((${m.vd} - ${m.XA}) * 1px)
            ${f.WN};
        border-color: ${f.WN};
    }
`.withBehaviors((0,i.mr)(o.A`
            :host([appearance="outline"]) {
                border-color: ${a.A.ButtonText};
            }
            :host([appearance="outline"][href]) {
                border-color: ${a.A.LinkText};
            }
        `)),F=o.A`
    :host([appearance="stealth"]) {
        background: ${w.Wl};
    }

    :host([appearance="stealth"]:hover) {
        background: ${w.oO};
    }

    :host([appearance="stealth"]:active) {
        background: ${w.wO};
    }
`.withBehaviors((0,i.mr)(o.A`
            :host([appearance="stealth"]),
            :host([appearance="stealth"]) .control {
                forced-color-adjust: none;
                background: ${a.A.ButtonFace};
                border-color: transparent;
                color: ${a.A.ButtonText};
                fill: currentcolor;
            }

            :host([appearance="stealth"]:hover) .control {
                background: ${a.A.Highlight};
                border-color: ${a.A.Highlight};
                color: ${a.A.HighlightText};
                fill: currentcolor;
            }

            :host([appearance="stealth"]:${s.N}) .control {
                background: ${a.A.Highlight};
                box-shadow: 0 0 0 1px ${a.A.Highlight};
                color: ${a.A.HighlightText};
                fill: currentcolor;
            }

            :host([appearance="stealth"][href]) .control {
                color: ${a.A.LinkText};
            }

            :host([appearance="stealth"]:hover[href]) .control,
        :host([appearance="stealth"]:${s.N}[href]) .control {
                background: ${a.A.LinkText};
                border-color: ${a.A.LinkText};
                color: ${a.A.HighlightText};
                fill: currentcolor;
            }

            :host([appearance="stealth"]:${s.N}[href]) .control {
                box-shadow: 0 0 0 1px ${a.A.LinkText};
            }
        `))},26384(t,e,n){"use strict";n.d(e,{G(){return f}});var r=n(56911),i=n(88458),s=n(35106),o=n(38493),a=n(60815),l=n(56863),c=n(92011);class u extends c.L{}class h extends((0,l.rf)(u)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}var d=n(10910);class f extends h{constructor(){var t;super(...arguments),t=this,this.clearButtonCallback=()=>{},this.clearButtonFocusCallback=()=>{},this.clearButtonBlurCallback=()=>{},this.isRubySearchBox=!1,this.isProngRubySearchBox=!1,this.isInputFocused=!1,this.inputOnFocus=()=>{this.isInputFocused=!0},this.inputOnBlur=function(){t.isInputFocused=!1}}readOnlyChanged(){this.proxy instanceof HTMLElement&&(this.proxy.readOnly=this.readOnly)}autocompleteChanged(){this.proxy instanceof HTMLElement&&(this.proxy.autocomplete=this.autocomplete)}autofocusChanged(){this.proxy instanceof HTMLElement&&(this.proxy.autofocus=this.autofocus)}placeholderChanged(){this.proxy instanceof HTMLElement&&(this.proxy.placeholder=this.placeholder)}maxlengthChanged(){this.proxy instanceof HTMLElement&&(this.proxy.maxLength=this.maxlength)}minlengthChanged(){this.proxy instanceof HTMLElement&&(this.proxy.minLength=this.minlength)}sizeChanged(){this.proxy instanceof HTMLElement&&(this.proxy.size=this.size)}spellcheckChanged(){this.proxy instanceof HTMLElement&&(this.proxy.spellcheck=this.spellcheck)}handleEndContentChange(){this.endContainer.classList.toggle("end",this.end.assignedNodes().length>0)}valueChanged(){this.$fastController.isConnected&&this.setFormValue(this.value),this.proxy instanceof HTMLElement&&(this.proxy.value=this.value),this.$emit("change")}submitSearch(t){var e;this.$emit("submit"),null===(e=this.form)||void 0===e||e.submit(),this.searchBoxEventHandler&&this.searchBoxEventHandler(t)}connectedCallback(){super.connectedCallback(),this.autofocus&&this.focus(),this.setFormValue(this.value,this.value),(0,d._Z)(this).then(()=>{this.control&&null!==this.control.value&&(this.value=this.control.value)})}handleTextInput(t){this.control&&null!==this.control.value&&(this.value=this.control.value,this.searchBoxEventHandler&&this.searchBoxEventHandler(t))}onFocus(){this.enableClearButton&&(this.showClearButton=!0)}onBlurs(){this.enableClearButton&&(this.showClearButton=!1)}clearBtnOnFocus(){this.clearButtonFocusCallback()}clearBtnOnBlurs(){this.clearButtonBlurCallback()}clearValue(t){this.control&&(this.control.value="",this.clearButtonCallback(),this.searchBoxClearHandler&&this.searchBoxClearHandler(t))}}(0,r.Cg)([(0,o.CF)({attribute:"readonly",mode:"boolean"})],f.prototype,"readOnly",void 0),(0,r.Cg)([o.CF],f.prototype,"autocomplete",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"})],f.prototype,"autofocus",void 0),(0,r.Cg)([o.CF],f.prototype,"placeholder",void 0),(0,r.Cg)([(0,o.CF)({converter:o.R$})],f.prototype,"maxlength",void 0),(0,r.Cg)([(0,o.CF)({converter:o.R$})],f.prototype,"minlength",void 0),(0,r.Cg)([(0,o.CF)({converter:o.R$})],f.prototype,"size",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"})],f.prototype,"spellcheck",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"})],f.prototype,"isOnImage",void 0),(0,r.Cg)([(0,o.CF)({attribute:"clear-title"})],f.prototype,"clearTitle",void 0),(0,r.Cg)([(0,o.CF)({attribute:"clear-label"})],f.prototype,"clearLabel",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"})],f.prototype,"enableClearButton",void 0),(0,r.Cg)([a.sH],f.prototype,"showClearButton",void 0),(0,r.Cg)([a.sH],f.prototype,"clearButtonCallback",void 0),(0,r.Cg)([a.sH],f.prototype,"clearButtonFocusCallback",void 0),(0,r.Cg)([a.sH],f.prototype,"clearButtonBlurCallback",void 0),(0,r.Cg)([a.sH],f.prototype,"isRubySearchBox",void 0),(0,r.Cg)([a.sH],f.prototype,"isProngRubySearchBox",void 0),(0,r.Cg)([a.sH],f.prototype,"isInputFocused",void 0),(0,r.Cg)([(0,o.CF)({attribute:"button-label"})],f.prototype,"buttonLabel",void 0),(0,r.Cg)([a.sH],f.prototype,"buttonTelemetryTag",void 0),(0,r.Cg)([a.sH],f.prototype,"inputTelemetryTag",void 0),(0,r.Cg)([a.sH],f.prototype,"clearButtonTelemetryTag",void 0),(0,r.Cg)([a.sH],f.prototype,"searchBoxEventHandler",void 0),(0,r.Cg)([a.sH],f.prototype,"searchBoxClearHandler",void 0),(0,r.Cg)([a.sH],f.prototype,"defaultSlottedNodes",void 0),(0,i.X)(f,s.qw)},26633(t,e,n){"use strict";n.d(e,{b(){return $}});var r=n(56911),i=n(92011),s=n(23429),o=n(60815),a=n(38493),l=n(55230),c=["input","select","textarea","a[href]","button","[tabindex]:not(slot)","audio[controls]","video[controls]",'[contenteditable]:not([contenteditable="false"])',"details>summary:first-of-type","details"],u=c.join(","),h="undefined"==typeof Element,d=h?function(){}:Element.prototype.matches||Element.prototype.msMatchesSelector||Element.prototype.webkitMatchesSelector,f=!h&&Element.prototype.getRootNode?function(t){return t.getRootNode()}:function(t){return t.ownerDocument},p=function(t,e){return t.tabIndex<0&&(e||/^(AUDIO|VIDEO|DETAILS)$/.test(t.tagName)||t.isContentEditable)&&isNaN(parseInt(t.getAttribute("tabindex"),10))?0:t.tabIndex},v=function(t){return"INPUT"===t.tagName},g=function(t){return function(t){return v(t)&&"radio"===t.type}(t)&&!function(t){if(!t.name)return!0;var e,n=t.form||f(t),r=function(t){return n.querySelectorAll('input[type="radio"][name="'+t+'"]')};if("undefined"!=typeof window&&void 0!==window.CSS&&"function"==typeof window.CSS.escape)e=r(window.CSS.escape(t.name));else try{e=r(t.name)}catch(t){return console.error("Looks like you have a radio button with a name attribute containing invalid CSS selector characters and need the CSS.escape polyfill: %s",t.message),!1}var i=function(t,e){for(var n=0;n<t.length;n++)if(t[n].checked&&t[n].form===e)return t[n]}(e,t.form);return!i||i===t}(t)},b=function(t){var e=t.getBoundingClientRect(),n=e.width,r=e.height;return 0===n&&0===r},m=function(t,e){return!(e.disabled||function(t){return v(t)&&"hidden"===t.type}(e)||function(t,e){var n=e.displayCheck,r=e.getShadowRoot;if("hidden"===getComputedStyle(t).visibility)return!0;var i=d.call(t,"details>summary:first-of-type")?t.parentElement:t;if(d.call(i,"details:not([open]) *"))return!0;var s=f(t).host,o=(null==s?void 0:s.ownerDocument.contains(s))||t.ownerDocument.contains(t);if(n&&"full"!==n){if("non-zero-area"===n)return b(t)}else{if("function"==typeof r){for(var a=t;t;){var l=t.parentElement,c=f(t);if(l&&!l.shadowRoot&&!0===r(l))return b(t);t=t.assignedSlot?t.assignedSlot:l||c===t.ownerDocument?l:c.host}t=a}if(o)return!t.getClientRects().length}return!1}(e,t)||function(t){return"DETAILS"===t.tagName&&Array.prototype.slice.apply(t.children).some(function(t){return"SUMMARY"===t.tagName})}(e)||function(t){if(/^(INPUT|BUTTON|SELECT|TEXTAREA)$/.test(t.tagName))for(var e=t.parentElement;e;){if("FIELDSET"===e.tagName&&e.disabled){for(var n=0;n<e.children.length;n++){var r=e.children.item(n);if("LEGEND"===r.tagName)return!!d.call(e,"fieldset[disabled] *")||!r.contains(t)}return!0}e=e.parentElement}return!1}(e))},y=function(t,e){return!(g(e)||p(e)<0||!m(t,e))},w=function(t,e){if(e=e||{},!t)throw new Error("No node provided");return!1!==d.call(t,u)&&y(e,t)};class $ extends i.L{constructor(){super(...arguments),this.modal=!1,this.hidden=!1,this.noFocusTrap=!1,this.noFocusTrapChanged=()=>{this.$fastController.isConnected&&this.updateTrapFocus()},this.isTrappingFocus=!1,this.handleDocumentKeydown=t=>{if(!t.defaultPrevented&&!this.hidden)switch(t.key){case l.F9:this.dismiss(),t.preventDefault();break;case l.J9:this.handleTabKeyDown(t)}},this.handleDocumentFocus=t=>{!t.defaultPrevented&&this.shouldForceFocus(t.target)&&(this.focusFirstElement(),t.preventDefault())},this.handleTabKeyDown=t=>{if(this.noFocusTrap||this.hidden)return;const e=this.getTabQueueBounds();return 0!==e.length?1===e.length?(e[0].focus(),void t.preventDefault()):void(t.shiftKey&&t.target===e[0]?(e[e.length-1].focus(),t.preventDefault()):t.shiftKey||t.target!==e[e.length-1]||(e[0].focus(),t.preventDefault())):void 0},this.getTabQueueBounds=()=>$.reduceTabbableItems([],this),this.focusFirstElement=()=>{const t=this.getTabQueueBounds();t.length>0?t[0].focus():this.dialog instanceof HTMLElement&&this.dialog.focus()},this.shouldForceFocus=t=>this.isTrappingFocus&&!this.contains(t),this.shouldTrapFocus=()=>!this.noFocusTrap&&!this.hidden,this.updateTrapFocus=t=>{const e=void 0===t?this.shouldTrapFocus():t;e&&!this.isTrappingFocus?(this.isTrappingFocus=!0,document.addEventListener("focusin",this.handleDocumentFocus),s.L.enqueue(()=>{this.shouldForceFocus(document.activeElement)&&this.focusFirstElement()})):!e&&this.isTrappingFocus&&(this.isTrappingFocus=!1,document.removeEventListener("focusin",this.handleDocumentFocus))}}dismiss(){this.$emit("dismiss"),this.$emit("cancel")}show(){this.hidden=!1}hide(){this.hidden=!0,this.$emit("close")}connectedCallback(){super.connectedCallback(),document.addEventListener("keydown",this.handleDocumentKeydown),this.notifier=o.cP.getNotifier(this),this.notifier.subscribe(this,"hidden"),this.updateTrapFocus()}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("keydown",this.handleDocumentKeydown),this.updateTrapFocus(!1),this.notifier.unsubscribe(this,"hidden")}handleChange(t,e){if("hidden"===e)this.updateTrapFocus()}static reduceTabbableItems(t,e){return"-1"===e.getAttribute("tabindex")?t:w(e)||$.isFocusableFastElement(e)&&$.hasTabbableShadow(e)?(t.push(e),t):e.childElementCount?t.concat(Array.from(e.children).reduce($.reduceTabbableItems,[])):t}static isFocusableFastElement(t){return!!t.$fastController?.definition.shadowOptions?.delegatesFocus}static hasTabbableShadow(t){return Array.from(t.shadowRoot?.querySelectorAll("*")??[]).some(t=>w(t))}}(0,r.Cg)([(0,a.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],$.prototype,"modal",void 0),(0,r.Cg)([(0,a.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],$.prototype,"hidden",void 0),(0,r.Cg)([(0,a.CF)({attribute:"no-focus-trap",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],$.prototype,"noFocusTrap",void 0),(0,r.Cg)([(0,a.CF)({attribute:"aria-describedby"}),(0,r.Sn)("design:type",String)],$.prototype,"ariaDescribedby",void 0),(0,r.Cg)([(0,a.CF)({attribute:"aria-labelledby"}),(0,r.Sn)("design:type",String)],$.prototype,"ariaLabelledby",void 0),(0,r.Cg)([(0,a.CF)({attribute:"aria-label"}),(0,r.Sn)("design:type",String)],$.prototype,"ariaLabel",void 0)},26920(t,e,n){"use strict";n.d(e,{$P(){return l},FX(){return a},XA(){return s},vd(){return o}});var r=n(45755);const{create:i}=r.G,s=i("stroke-width",1),o=i("focus-stroke-width",2),a=s,l=o},27478(t,e,n){"use strict";n.d(e,{P(){return i}});var r=n(37820);class i{constructor(t,e,n){this.x=t,this.y=e,this.z=n}static fromObject(t){return!t||isNaN(t.x)||isNaN(t.y)||isNaN(t.z)?null:new i(t.x,t.y,t.z)}equalValue(t){return this.x===t.x&&this.y===t.y&&this.z===t.z}roundToPrecision(t){return new i((0,r.l)(this.x,t),(0,r.l)(this.y,t),(0,r.l)(this.z,t))}toObject(){return{x:this.x,y:this.y,z:this.z}}}i.whitePoint=new i(.95047,1,1.08883)},29025(t,e,n){"use strict";n.d(e,{z(){return s}});var r=n(56911),i=n(38493);class s{}(0,r.Cg)([(0,i.CF)({attribute:"aria-atomic"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaAtomic",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-busy"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaBusy",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-controls"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaControls",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-current"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaCurrent",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-describedby"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaDescribedby",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-details"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaDetails",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-disabled"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaDisabled",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-errormessage"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaErrormessage",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-flowto"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaFlowto",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-haspopup"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaHaspopup",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-hidden"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaHidden",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-invalid"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaInvalid",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-keyshortcuts"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaKeyshortcuts",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-label"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaLabel",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-labelledby"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaLabelledby",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-live"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaLive",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-owns"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaOwns",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-relevant"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaRelevant",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-roledescription"}),(0,r.Sn)("design:type",Object)],s.prototype,"ariaRoledescription",void 0)},29194(t,e,n){"use strict";n.d(e,{Yi(){return l},dg(){return a}});var r=n(42277),i=n(19470),s=n(35727);const o=(0,i.Mg)(),a=Object.freeze({getForInstance:o.getForInstance,getByType:o.getByType,define:(t,e)=>((e=e||{}).type=t,o.register(e),t),assignAspect(t,e){if(e)switch(t.sourceAspect=e,e[0]){case":":t.targetAspect=e.substring(1),t.aspectType="classList"===t.targetAspect?r.D.tokenList:r.D.property;break;case"?":t.targetAspect=e.substring(1),t.aspectType=r.D.booleanAttribute;break;case"@":t.targetAspect=e.substring(1),t.aspectType=r.D.event;break;default:t.targetAspect=e,t.aspectType=r.D.attribute}else t.aspectType=r.D.content}});class l{constructor(t){this.options=t}createHTML(t){return s.VK.attribute(t(this))}createBehavior(){return this}}(0,i.rV)(l)},29503(t){t.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M10 2.75a7.25 7.25 0 015.63 11.82l4.9 4.9a.75.75 0 01-.98 1.13l-.08-.07-4.9-4.9A7.25 7.25 0 1110 2.75zm0 1.5a5.75 5.75 0 100 11.5 5.75 5.75 0 000-11.5z"></path></svg>'},29586(t,e,n){"use strict";n.d(e,{R(){return x}});var r=n(60993),i=n(64187),s=n(22131),o=n(73477),a=n(74849),l=n(50882),c=n(48196),u=n(57416),h=n(41123),d=n(64699),f=n(74838),p=n(14996),v=n(4283),g=n(79288),b=n(7896),m=n(74089),y=n(26920),w=n(37302),$=n(48751);const x=a.A`
    ${(0,i.V)("inline-flex")} :host {
        font-family: ${b.O};
        border-radius: calc(${u.Pb} * 1px);
        border: calc(${y.vd} * 1px) solid transparent;
        box-sizing: border-box;
        color: ${$.l};
        cursor: pointer;
        fill: currentcolor;
        font-size: ${h.K};
        height: calc(${c.D} * 1px);
        line-height: ${h.Z};
        margin: 0 calc(${f.vR} * 1px);
        outline: none;
        overflow: hidden;
        align-items: center;
        padding: 0 calc(${f.vR} * 2.25px);
        user-select: none;
        white-space: nowrap;
    }

    :host(:${o.N}) {
        box-shadow: 0 0 0 calc(${y.vd} * 1px) inset ${d.fF};
        border-color: ${p.WN};
        background: ${v.KJ};
        color: ${m.Bg};
    }

    :host([aria-selected="true"]) {
        background: ${v.IR};
        color: ${m.l_};
    }

    :host(:hover) {
        background: ${v.OS};
        color: ${m.XK};
    }

    :host(:active) {
        background: ${v.am};
        color: ${m.J_};
    }

    :host(:not([aria-selected="true"]):hover) {
        background: ${w.Xt};
        color: ${$.l};
    }

    :host(:not([aria-selected="true"]):active) {
        background: ${w.X4};
        color: ${$.l};
    }

    :host([disabled]) {
        cursor: ${r.Z};
        opacity: ${g.q};
    }

    :host([disabled]:hover) {
        background-color: inherit;
    }

    .content {
        grid-column-start: 2;
        justify-self: start;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    ::slotted([slot="start"]),
    ::slotted([slot="end"]),
    ::slotted(svg) {
        display: flex;
    }

    ::slotted(svg) {
        ${""}
        height: calc(${f.vR} * 4px);
        width: calc(${f.vR} * 4px);
    }

    ::slotted([slot="end"]) {
        margin-inline-start: 1ch;
    }

    ::slotted([slot="start"]) {
        margin-inline-end: 1ch;
    }
`.withBehaviors((0,s.mr)(a.A`
            :host {
                border-color: transparent;
                color: ${l.A.ButtonText};
                forced-color-adjust: none;
            }

            :host(:not([aria-selected="true"]):hover),
            :host([aria-selected="true"]) {
                background: ${l.A.Highlight};
                color: ${l.A.HighlightText};
            }

            :host([disabled]),
            :host([disabled]:not([aria-selected="true"]):hover) {
                background: ${l.A.Canvas};
                color: ${l.A.GrayText};
                fill: currentcolor;
                opacity: 1;
            }
        `))},31023(t,e,n){"use strict";n.d(e,{r(){return a}});var r=n(45755),i=n(57606),s=n(86627);const{create:o}=r.G,a=o({name:"neutral-palette"},i.p.create(s.zW))},31157(t,e,n){"use strict";var r;n.d(e,{O(){return r}}),function(t){t.ltr="ltr",t.rtl="rtl"}(r||(r={}))},32625(t,e,n){"use strict";n.d(e,{a(){return o}});var r=n(19470),i=n(72454);class s extends i.O{createObserver(){return this}bind(t){return this.evaluate(t.source,t.context)}}function o(t,e){return new s(t,e)}(0,r.rV)(s)},34188(t,e,n){"use strict";n.d(e,{VS(){return v},fB(){return u},vB(){return p}});const r=/fe-b\$\$start\$\$(\d+)\$\$(.+)\$\$fe-b/,i=/fe-b\$\$end\$\$(\d+)\$\$(.+)\$\$fe-b/,s=/fe-repeat\$\$start\$\$(\d+)\$\$fe-repeat/,o=/fe-repeat\$\$end\$\$(\d+)\$\$fe-repeat/,a=/fe-eb\$\$start\$\$(.+)\$\$fe-eb/,l=/fe-eb\$\$end\$\$(.+)\$\$fe-eb/;function c(t){return t&&t.nodeType===Node.COMMENT_NODE}const u=Object.freeze({attributeMarkerName:"data-fe-b",attributeBindingSeparator:" ",contentBindingStartMarker:(t,e)=>`fe-b$$start$$${t}$$${e}$$fe-b`,contentBindingEndMarker:(t,e)=>`fe-b$$end$$${t}$$${e}$$fe-b`,repeatStartMarker:t=>`fe-repeat$$start$$${t}$$fe-repeat`,repeatEndMarker:t=>`fe-repeat$$end$$${t}$$fe-repeat`,isContentBindingStartMarker:t=>r.test(t),isContentBindingEndMarker:t=>i.test(t),isRepeatViewStartMarker:t=>s.test(t),isRepeatViewEndMarker:t=>o.test(t),isElementBoundaryStartMarker:t=>c(t)&&a.test(t.data),isElementBoundaryEndMarker:t=>c(t)&&l.test(t.data),parseAttributeBinding(t){const e=t.getAttribute(this.attributeMarkerName);return null===e?e:e.split(this.attributeBindingSeparator).map(t=>parseInt(t))},parseContentBindingStartMarker:t=>f(r,t),parseContentBindingEndMarker:t=>f(i,t),parseRepeatStartMarker:t=>h(s,t),parseRepeatEndMarker:t=>h(o,t),parseElementBoundaryStartMarker:t=>d(a,t),parseElementBoundaryEndMarker:t=>d(l,t)});function h(t,e){const n=t.exec(e);return null===n?n:parseInt(n[1])}function d(t,e){const n=t.exec(e);return null===n?n:n[1]}function f(t,e){const n=t.exec(e);return null===n?n:[parseInt(n[1]),n[2]]}const p=Symbol.for("fe-hydration");function v(t){return t[p]===p}},35106(t,e,n){"use strict";n.d(e,{LT(){return l},aO(){return a},qw(){return o}});var r=n(96950),i=n(60402),s=n(18893);class o{}function a(t){return r.qy`
        <slot name="end" ${(0,i.K)("end")}>${(0,s.R)(t.end)}</slot>
    `.inline()}function l(t){return r.qy`
        <slot name="start" ${(0,i.K)("start")}>${(0,s.R)(t.start)}</slot>
    `.inline()}},35727(t,e,n){"use strict";n.d(e,{Hn(){return l},VK(){return c},iX(){return u}});const r=`fast-${Math.random().toString(36).substring(2,8)}`,i=`${r}{`,s=`}${r}`,o=s.length;let a=0;const l=()=>`${r}-${++a}`,c=Object.freeze({interpolation(t){return`${i}${t}${s}`},attribute(t){return`${l()}="${i}${t}${s}"`},comment(t){return`\x3c!--${i}${t}${s}--\x3e`}}),u=Object.freeze({parse(t,e){const n=t.split(i);if(1===n.length)return null;const r=[];for(let t=0,i=n.length;t<i;++t){const i=n[t],a=i.indexOf(s);let l;if(-1===a)l=i;else{const t=i.substring(0,a);r.push(e[t]),l=i.substring(a+o)}""!==l&&r.push(l)}return r}})},35901(t,e,n){"use strict";n.d(e,{MA(){return o},_S(){return l},uP(){return a},yz(){return s}});var r=n(45755);const{create:i}=r.G,s=i("accent-fill-rest-delta",0),o=i("accent-fill-hover-delta",4),a=i("accent-fill-active-delta",-5),l=i("accent-fill-focus-delta",0)},36452(t,e,n){"use strict";n.d(e,{IH(){return g},U7(){return v},Ez(){return p},MY(){return d},u4(){return f},mb(){return h},I2(){return u}});var r=n(45755),i=n(68009),s=n(95239),o=n(43404),a=n(31023);const{create:l}=r.G,c=l({name:"neutral-stroke-recipe"},{evaluate(t){return function(t,e,n,r,s,o){const a=t.closestIndexOf(e),l=(0,i.F)(e),c=a+l*n,u=c+l*(r-n),h=c+l*(s-n),d=c+l*(o-n);return{rest:t.get(c),hover:t.get(u),active:t.get(h),focus:t.get(d)}}(t(a.r),t(s.p),t(o.uC),t(o.iS),t(o.C2),t(o.Q2))}}),u=l("neutral-stroke-rest",t=>t(c).evaluate(t).rest),h=l("neutral-stroke-hover",t=>t(c).evaluate(t).hover),d=l("neutral-stroke-active",t=>t(c).evaluate(t).active),f=l("neutral-stroke-focus",t=>t(c).evaluate(t).focus),p=u,v=h,g=d},37079(t,e,n){"use strict";n.d(e,{F(){return s},w(){return o}});var r=n(45755);const{create:i}=r.G,s=i("type-ramp-plus-4-font-size","28px"),o=i("type-ramp-plus-4-line-height","36px")},37180(t,e,n){"use strict";n.d(e,{c(){return r}});const r=Object.freeze({prefix:"fluent",shadowRootMode:"open",registry:customElements})},37302(t,e,n){"use strict";n.d(e,{X4(){return h},rM(){return d},Xt(){return u},jO(){return l},F7(){return c}});var r=n(45755),i=n(95239),s=n(37947),o=n(31023);const{create:a}=r.G,l=a({name:"neutral-fill-recipe"},{evaluate(t,e){return function(t,e,n,r,i,s){const o=t.closestIndexOf(e),a=o>=Math.max(n,r,i,s)?-1:1;return{rest:t.get(o+a*n),hover:t.get(o+a*r),active:t.get(o+a*i),focus:t.get(o+a*s)}}(t(o.r),e||t(i.p),t(s.DE),t(s.l2),t(s.L6),t(s.tN))}}),c=a("neutral-fill-rest",t=>t(l).evaluate(t).rest),u=a("neutral-fill-hover",t=>t(l).evaluate(t).hover),h=a("neutral-fill-active",t=>t(l).evaluate(t).active),d=a("neutral-fill-focus",t=>t(l).evaluate(t).focus)},37767(t,e,n){"use strict";n.d(e,{k(){return o}});var r=n(42277),i=n(68244),s=n(50214);const o=i.F.create({trustedType:{createHTML:t=>(0,s.v)(t,"svgPassThroughPolicy")},guards:{aspects:{[r.D.property]:{innerHTML:(t,e,n,r)=>function(t,e,n){for(var i=arguments.length,o=new Array(i>3?i-3:0),a=3;a<i;a++)o[a-3]=arguments[a];r(t,e,(0,s.v)(n,"svgPassThroughPolicy"),...o)}}}}})},37820(t,e,n){"use strict";function r(t,e,n){return isNaN(t)||t<=e?e:t>=n?n:t}function i(t,e,n){return isNaN(t)||t<=e?0:t>=n?1:t/(n-e)}function s(t,e,n){return isNaN(t)?e:e+t*(n-e)}function o(t){return t*(Math.PI/180)}function a(t){return t*(180/Math.PI)}function l(t){const e=Math.round(r(t,0,255)).toString(16);return 1===e.length?"0"+e:e}function c(t,e,n){return isNaN(t)||t<=0?e:t>=1?n:e+t*(n-e)}function u(t,e,n){if(t<=0)return e%360;if(t>=1)return n%360;const r=(e-n+360)%360;return r<=(n-e+360)%360?(e-r*t+360)%360:(e+r*t+360)%360}function h(t,e){const n=Math.pow(10,e);return Math.round(t*n)/n}n.d(e,{Cc(){return c},IG(){return l},NU(){return s},S8(){return i},c5(){return u},l(){return h},nv(){return a},qE(){return r},tR(){return o}}),Math.PI},37947(t,e,n){"use strict";n.d(e,{DE(){return s},L6(){return a},l2(){return o},tN(){return l}});var r=n(45755);const{create:i}=r.G,s=i("neutral-fill-rest-delta",7),o=i("neutral-fill-hover-delta",10),a=i("neutral-fill-active-delta",5),l=i("neutral-fill-focus-delta",0)},37998(t,e,n){"use strict";n.d(e,{ET(){return r}});const r="box-shadow: 0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0, 0, 0, calc(.11 * (2 - var(--background-luminance, 1)))), 0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0, 0, 0, calc(.13 * (2 - var(--background-luminance, 1))));"},38493(t,e,n){"use strict";n.d(e,{$u(){return u},Bs(){return h},CF(){return g},IJ(){return d},O1(){return v},R$(){return p}});var r=n(60815),i=n(96293),s=n(23429),o=n(42277),a=n(19470);const l="boolean",c="reflect",u=Object.freeze({locate:(0,a.iX)()}),h={toView:t=>t?"true":"false",fromView:t=>null!=t&&"false"!==t&&!1!==t&&0!==t},d={toView:t=>"boolean"==typeof t?t.toString():"",fromView:t=>[null,void 0,void 0].includes(t)?null:h.fromView(t)};function f(t){if(null==t)return null;const e=1*t;return isNaN(e)?null:e}const p={toView(t){const e=f(t);return e?e.toString():e},fromView:f};class v{constructor(t,e,n=e.toLowerCase(),r=c,i){this.guards=new Set,this.Owner=t,this.name=e,this.attribute=n,this.mode=r,this.converter=i,this.fieldName=`_${e}`,this.callbackName=`${e}Changed`,this.hasCallback=this.callbackName in t.prototype,r===l&&void 0===i&&(this.converter=h)}setValue(t,e){const n=t[this.fieldName],r=this.converter;void 0!==r&&(e=r.fromView(e)),n!==e&&(t[this.fieldName]=e,this.tryReflectToAttribute(t),this.hasCallback&&t[this.callbackName](n,e),t.$fastController.notify(this.name))}getValue(t){return r.cP.track(t,this.name),t[this.fieldName]}onAttributeChangedCallback(t,e){this.guards.has(t)||(this.guards.add(t),this.setValue(t,e),this.guards.delete(t))}tryReflectToAttribute(t){const e=this.mode,n=this.guards;n.has(t)||"fromView"===e||s.L.enqueue(()=>{n.add(t);const r=t[this.fieldName];switch(e){case c:const e=this.converter;o.d.setAttribute(t,this.attribute,void 0!==e?e.toView(r):r);break;case l:o.d.setBooleanAttribute(t,this.attribute,r)}n.delete(t)})}static collect(t,...e){const n=[];e.push(u.locate(t));for(let r=0,s=e.length;r<s;++r){const s=e[r];if(void 0!==s)for(let e=0,r=s.length;e<r;++e){const r=s[e];(0,i.Kg)(r)?n.push(new v(t,r)):n.push(new v(t,r.property,r.attribute,r.mode,r.converter))}}return n}}function g(t,e){let n;function r(t,e){arguments.length>1&&(n.property=e),u.locate(t.constructor).push(n)}return arguments.length>1?(n={},void r(t,e)):(n=void 0===t?{}:t,r)}},39407(t,e,n){"use strict";n.d(e,{Cr(){return c},Xc(){return h},pI(){return u},u7(){return d}});var r=n(14777),i=n(58625),s=n(62044),o=n(89449),a=n(46543),l=(0,i.T)("plugin");function c(t){return l.get(t,"state",{},!0)}function u(t,e){for(var n,i=[],a=null,l=t[r.uR]();l;){var u=l[r.AP]();if(u){a&&(0,s.Tn)(a[r.YH])&&(0,s.Tn)(u[o.qT])&&a[r.YH](u);((0,s.Tn)(u[r.tZ])?u[r.tZ]():(n=c(u))[r.tZ])||i[r.y5](u),a=u,l=l[r.uR]()}}(0,s.Iu)(i,function(i){var s=t[o.eT]();i[r.mE](t.getCfg(),s,e,t[r.uR]()),n=c(i),i[o.eT]||n[o.eT]||(n[o.eT]=s),n[r.tZ]=!0,delete n[r.Ik]})}function h(t){return t.sort(function(t,e){var n=0;if(e){var r=(0,s.Tn)(e[o.qT]);(0,s.Tn)(t[o.qT])?n=r?t[o.Vo]-e[o.Vo]:1:r&&(n=-1)}else n=t?1:-1;return n})}function d(t){var e={};return{getName(){return e[r.RS]},setName(n){t&&t.setName(n),e[r.RS]=n},getTraceId(){return e[r.P5]},setTraceId(n){t&&t.setTraceId(n),(0,a.hX)(n)&&(e[r.P5]=n)},getSpanId(){return e[r.wi]},setSpanId(n){t&&t.setSpanId(n),(0,a.wN)(n)&&(e[r.wi]=n)},getTraceFlags(){return e[r.Rr]},setTraceFlags(n){t&&t.setTraceFlags(n),e[r.Rr]=n}}}},39692(t,e,n){"use strict";n.d(e,{f(){return a}});var r=n(96293),i=n(72454),s=n(93809),o=n(32625);function a(t){return(0,r.Tn)(t)?(0,s.U)(t):t instanceof i.O?t:(0,o.a)(()=>t)}},39813(t,e,n){"use strict";n.d(e,{Im(){return s},qU(){return a},vz(){return l}});var r=n(15454),i=n(50090),s=(((0,i.mS)()||{}).Symbol,((0,i.mS)()||{}).Reflect,r.zi||function(t){for(var e,n=1,i=arguments.length;n<i;n++)for(var s in e=arguments[n])r.Wy[r.QV].call(e,s)&&(t[s]=e[s]);return t}),o=function(t,e){return o=r.s6.setPrototypeOf||{__proto__:[]}instanceof Array&&function(t,e){t.__proto__=e}||function(t,e){for(var n in e)e[r.QV](n)&&(t[n]=e[n])},o(t,e)};function a(t,e){function n(){this.constructor=t}typeof e!==r.hW&&null!==e&&(0,i.zk)("Class extends value "+String(e)+" is not a constructor or null"),o(t,e),t[r.vR]=null===e?(0,i.AQ)(e):(n[r.vR]=e[r.vR],new n)}function l(t,e){for(var n=0,r=e.length,i=t.length;n<r;n++,i++)t[i]=e[n];return t}},39957(t,e,n){"use strict";n.d(e,{RR(){return O},ux(){return A}});var r=n(34188),i=n(19470),s=n(93800),o=n(60815),a=n(23429);class l{constructor(t,e,n){this.index=t,this.removed=e,this.addedCount=n}adjustTo(t){let e=this.index;const n=t.length;return e>n?e=n-this.addedCount:e<0&&(e=n+this.removed.length+e-this.addedCount),this.index=e<0?0:e,this}}const c=Object.freeze({reset:1,splice:2,optimized:3}),u=new l(0,i.tR,0);u.reset=!0;const h=[u];function d(t,e,n,r){return e<n||r<t?-1:e===n||r===t?0:t<n?e<r?e-n:r-n:r<e?r-t:e-t}function f(t,e,n,r,s,o){let a=0,c=0;const u=Math.min(n-e,o-s);if(0===e&&0===s&&(a=function(t,e,n){for(let r=0;r<n;++r)if(t[r]!==e[r])return r;return n}(t,r,u)),n===t.length&&o===r.length&&(c=function(t,e,n){let r=t.length,i=e.length,s=0;for(;s<n&&t[--r]===e[--i];)s++;return s}(t,r,u-a)),s+=a,o-=c,(n-=c)-(e+=a)===0&&o-s===0)return i.tR;if(e===n){const t=new l(e,[],0);for(;s<o;)t.removed.push(r[s++]);return[t]}if(s===o)return[new l(e,[],n-e)];const h=function(t){let e=t.length-1,n=t[0].length-1,r=t[e][n];const i=[];for(;e>0||n>0;){if(0===e){i.push(2),n--;continue}if(0===n){i.push(3),e--;continue}const s=t[e-1][n-1],o=t[e-1][n],a=t[e][n-1];let l;l=o<a?o<s?o:s:a<s?a:s,l===s?(s===r?i.push(0):(i.push(1),r=s),e--,n--):l===o?(i.push(3),e--,r=o):(i.push(2),n--,r=a)}return i.reverse()}(function(t,e,n,r,i,s){const o=s-i+1,a=n-e+1,l=new Array(o);let c,u;for(let t=0;t<o;++t)l[t]=new Array(a),l[t][0]=t;for(let t=0;t<a;++t)l[0][t]=t;for(let n=1;n<o;++n)for(let s=1;s<a;++s)t[e+s-1]===r[i+n-1]?l[n][s]=l[n-1][s-1]:(c=l[n-1][s]+1,u=l[n][s-1]+1,l[n][s]=c<u?c:u);return l}(t,e,n,r,s,o)),d=[];let f,p=e,v=s;for(let t=0;t<h.length;++t)switch(h[t]){case 0:void 0!==f&&(d.push(f),f=void 0),p++,v++;break;case 1:void 0===f&&(f=new l(p,[],0)),f.addedCount++,p++,f.removed.push(r[v]),v++;break;case 2:void 0===f&&(f=new l(p,[],0)),f.addedCount++,p++;break;case 3:void 0===f&&(f=new l(p,[],0)),f.removed.push(r[v]),v++}return void 0!==f&&d.push(f),d}function p(t,e){let n=!1,r=0;for(let i=0;i<e.length;i++){const s=e[i];if(s.index+=r,n)continue;const o=d(t.index,t.index+t.removed.length,s.index,s.index+s.addedCount);if(o>=0){e.splice(i,1),i--,r-=s.addedCount-s.removed.length,t.addedCount+=s.addedCount-o;const a=t.removed.length+s.removed.length-o;if(t.addedCount||a){let e=s.removed;if(t.index<s.index){const n=t.removed.slice(0,s.index-t.index);n.push(...e),e=n}if(t.index+t.removed.length>s.index+s.addedCount){const n=t.removed.slice(s.index+s.addedCount-t.index);e.push(...n)}t.removed=e,s.index<t.index&&(t.index=s.index)}else n=!0}else if(t.index<s.index){n=!0,e.splice(i,0,t),i++;const o=t.addedCount-t.removed.length;s.index+=o,r+=o}}n||e.push(t)}let v=Object.freeze({support:c.optimized,normalize:(t,e,n)=>void 0===t?void 0===n?i.tR:function(t,e){let n=[];const r=[];for(let t=0,n=e.length;t<n;t++)p(e[t],r);for(let e=0,i=r.length;e<i;++e){const i=r[e];1!==i.addedCount||1!==i.removed.length?n=n.concat(f(t,i.index,i.index+i.addedCount,i.removed,0,i.removed.length)):i.removed[0]!==t[i.index]&&n.push(i)}return n}(e,n):h,pop(t,e,n,r){const i=t.length>0,s=n.apply(t,r);return i&&e.addSplice(new l(t.length,[s],0)),s},push(t,e,n,r){const i=n.apply(t,r);return e.addSplice(new l(t.length-r.length,[],r.length).adjustTo(t)),i},reverse(t,e,n,r){const i=n.apply(t,r);return e.reset(t),i},shift(t,e,n,r){const i=t.length>0,s=n.apply(t,r);return i&&e.addSplice(new l(0,[s],0)),s},sort(t,e,n,r){const i=n.apply(t,r);return e.reset(t),i},splice(t,e,n,r){const i=n.apply(t,r);return e.addSplice(new l(+r[0],i,r.length>2?r.length-2:0).adjustTo(t)),i},unshift(t,e,n,r){const i=n.apply(t,r);return e.addSplice(new l(0,[],r.length).adjustTo(t)),i}});function g(t,e,n){Reflect.defineProperty(t,e,{value:n,enumerable:!1})}Object.freeze({reset:h,setDefaultStrategy(t){v=t}});class b extends s.l{constructor(t){super(t),this.oldCollection=void 0,this.splices=void 0,this.needsQueue=!0,this._strategy=null,this._lengthObserver=void 0,this.call=this.flush,g(t,"$fastController",this)}get strategy(){return this._strategy}set strategy(t){this._strategy=t}get lengthObserver(){let t=this._lengthObserver;if(void 0===t){const e=this.subject;this._lengthObserver=t={length:e.length,handleChange(){this.length!==e.length&&(this.length=e.length,o.cP.notify(t,"length"))}},this.subscribe(t)}return t}subscribe(t){this.flush(),super.subscribe(t)}addSplice(t){void 0===this.splices?this.splices=[t]:this.splices.push(t),this.enqueue()}reset(t){this.oldCollection=t,this.enqueue()}flush(){var t;const e=this.splices,n=this.oldCollection;void 0===e&&void 0===n||(this.needsQueue=!0,this.splices=void 0,this.oldCollection=void 0,this.notify((null!==(t=this._strategy)&&void 0!==t?t:v).normalize(n,this.subject,e)))}enqueue(){this.needsQueue&&(this.needsQueue=!1,a.L.enqueue(this))}}let m=!1;const y=Object.freeze({enable(){if(m)return;m=!0,o.cP.setArrayObserverFactory(t=>new b(t));const t=Array.prototype;t.$fastPatch||(g(t,"$fastPatch",1),[t.pop,t.push,t.reverse,t.shift,t.sort,t.splice,t.unshift].forEach(e=>{t[e.name]=function(...t){var n;const r=this.$fastController;return void 0===r?e.apply(this,t):(null!==(n=r.strategy)&&void 0!==n?n:v)[e.name](this,r,e,t)}}))}});var w=n(39692),$=n(29194),x=n(35727),k=n(22020);const C=Object.freeze({positioning:!1,recycle:!0});function S(t,e,n,r){t.context.parent=r.source,t.context.parentContext=r.context,t.bind(e[n])}function E(t,e,n,r){t.context.parent=r.source,t.context.parentContext=r.context,t.context.length=e.length,t.context.index=n,t.bind(e[n])}function M(t){return t.nodeType===Node.COMMENT_NODE}class F extends Error{constructor(t,e){super(t),this.propertyBag=e}}class D{constructor(t){this.directive=t,this.items=null,this.itemsObserver=null,this.bindView=S,this.views=[],this.itemsBindingObserver=t.dataBinding.createObserver(this,t),this.templateBindingObserver=t.templateBinding.createObserver(this,t),t.options.positioning&&(this.bindView=E)}bind(t){this.location=t.targets[this.directive.targetNodeId],this.controller=t,this.items=this.itemsBindingObserver.bind(t),this.template=this.templateBindingObserver.bind(t),this.observeItems(!0),(0,r.VS)(this.template)&&(0,r.VS)(t)&&t.hydrationStage!==k.xW.hydrated?this.hydrateViews(this.template):this.refreshAllViews(),t.onUnbind(this)}unbind(){null!==this.itemsObserver&&this.itemsObserver.unsubscribe(this),this.unbindAllViews()}handleChange(t,e){if(e===this.itemsBindingObserver)this.items=this.itemsBindingObserver.bind(this.controller),this.observeItems(),this.refreshAllViews();else if(e===this.templateBindingObserver)this.template=this.templateBindingObserver.bind(this.controller),this.refreshAllViews(!0);else{if(!e[0])return;e[0].reset?this.refreshAllViews():this.updateViews(e)}}observeItems(t=!1){if(!this.items)return void(this.items=i.tR);const e=this.itemsObserver,n=this.itemsObserver=o.cP.getNotifier(this.items),r=e!==n;r&&null!==e&&e.unsubscribe(this),(r||t)&&n.subscribe(this)}updateViews(t){const e=this.views,n=this.bindView,r=this.items,i=this.template,s=this.controller,o=this.directive.options.recycle,a=[];let l=0,c=0;for(let u=0,h=t.length;u<h;++u){const h=t[u],d=h.removed;let f=0,p=h.index;const v=p+h.addedCount,g=e.splice(h.index,d.length),b=c=a.length+g.length;for(;p<v;++p){const t=e[p],u=t?t.firstChild:this.location;let h;o&&c>0?(f<=b&&g.length>0?(h=g[f],f++):(h=a[l],l++),c--):h=i.create(),e.splice(p,0,h),n(h,r,p,s),h.insertBefore(u)}g[f]&&a.push(...g.slice(f))}for(let t=l,e=a.length;t<e;++t)a[t].dispose();if(this.directive.options.positioning)for(let t=0,n=e.length;t<n;++t){const r=e[t].context;r.length=n,r.index=t}}refreshAllViews(t=!1){const e=this.items,n=this.template,r=this.location,i=this.bindView,s=this.controller;let o=e.length,a=this.views,l=a.length;if(0!==o&&!t&&this.directive.options.recycle||(k.NA.disposeContiguousBatch(a),l=0),0===l){this.views=a=new Array(o);for(let t=0;t<o;++t){const o=n.create();i(o,e,t,s),a[t]=o,o.insertBefore(r)}}else{let t=0;for(;t<o;++t)if(t<l){const r=a[t];if(!r){const e=new XMLSerializer;throw new F(`View is null or undefined inside ${this.location.getRootNode().host.nodeName}. This is a SSR software defect`,{index:t,hydrationStage:this.controller.hydrationStage,itemsLength:o,viewsState:a.map(t=>t?"hydrated":"empty"),viewTemplateString:e.serializeToString(n.create().fragment),rootNodeContent:e.serializeToString(this.location.getRootNode())})}i(r,e,t,s)}else{const o=n.create();i(o,e,t,s),a.push(o),o.insertBefore(r)}const c=a.splice(t,l-t);for(t=0,o=c.length;t<o;++t)c[t].dispose()}}unbindAllViews(){const t=this.views;for(let e=0,n=t.length;e<n;++e){const n=t[e];if(!n){const n=new XMLSerializer;throw new F(`View is null or undefined inside ${this.location.getRootNode().host.nodeName}. This is a SSR software defect`,{index:e,hydrationStage:this.controller.hydrationStage,viewsState:t.map(t=>t?"hydrated":"empty"),rootNodeContent:n.serializeToString(this.location.getRootNode())})}n.unbind()}}hydrateViews(t){if(!this.items)return;this.views=new Array(this.items.length);let e=this.location.previousSibling;for(;null!==e;){if(!M(e)){e=e.previousSibling;continue}const n=r.fB.parseRepeatEndMarker(e.data);if(null===n){e=e.previousSibling;continue}e.data="";const i=e.previousSibling;if(!i)throw new Error(`Error when hydrating inside ${this.location.getRootNode().host.nodeName}: end should never be null. This is a SSR software defect`);let s=i,o=0;for(;null!==s;){if(M(s))if(r.fB.isRepeatViewEndMarker(s.data))o++;else if(r.fB.isRepeatViewStartMarker(s.data)){if(!o){if(r.fB.parseRepeatStartMarker(s.data)!==n)throw new Error(`Error when hydrating inside ${this.location.getRootNode().host.nodeName}: Mismatched start and end markers. This is a SSR software defect`);s.data="",e=s.previousSibling,s=s.nextSibling;const o=t.hydrate(s,i);this.views[n]=o,this.bindView(o,this.items,n,this.controller);break}o--}s=s.previousSibling}if(!s)throw new Error(`Error when hydrating inside ${this.location.getRootNode().host.nodeName}:start should never be null. This is a SSR software defect`)}}}class O{constructor(t,e,n){this.dataBinding=t,this.templateBinding=e,this.options=n,y.enable()}createHTML(t){return x.VK.comment(t(this))}createBehavior(){return new D(this)}}function A(t,e,n=C){const r=(0,w.f)(t),i=(0,w.f)(e);return new O(r,i,{...C,...n})}$.dg.define(O)},40228(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M5 8a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0zm3 1a1 1 0 100-2 1 1 0 000 2z"></path></svg>'},40778(t,e,n){"use strict";n.d(e,{D(){return i}});var r=n(37820);class i{constructor(t,e,n){this.h=t,this.s=e,this.l=n}static fromObject(t){return!t||isNaN(t.h)||isNaN(t.s)||isNaN(t.l)?null:new i(t.h,t.s,t.l)}equalValue(t){return this.h===t.h&&this.s===t.s&&this.l===t.l}roundToPrecision(t){return new i((0,r.l)(this.h,t),(0,r.l)(this.s,t),(0,r.l)(this.l,t))}toObject(){return{h:this.h,s:this.s,l:this.l}}}},40865(t,e,n){"use strict";function r(t,e){let n=e;for(;null!==n;){if(n===t)return!0;n=i(n)}return!1}function i(t){const e=t.parentElement;if(e)return e;{const e=t.getRootNode();if(e.host instanceof HTMLElement)return e.host}return null}n.d(e,{W(){return r},Z(){return i}})},41123(t,e,n){"use strict";n.d(e,{K(){return s},Z(){return o}});var r=n(45755);const{create:i}=r.G,s=i("type-ramp-base-font-size","14px"),o=i("type-ramp-base-line-height","20px")},41817(t,e,n){"use strict";n.d(e,{v(){return a}});var r=n(96950),i=n(60402),s=n(82774),o=n(35106);const a=function(t={}){return r.qy`
        <button
            class="control"
            part="control"
            ?autofocus="${t=>t.autofocus}"
            ?disabled="${t=>t.disabled}"
            form="${t=>t.formId}"
            formaction="${t=>t.formaction}"
            formenctype="${t=>t.formenctype}"
            formmethod="${t=>t.formmethod}"
            ?formnovalidate="${t=>t.formnovalidate}"
            formtarget="${t=>t.formtarget}"
            name="${t=>t.name}"
            type="${t=>t.type}"
            value="${t=>t.value}"
            aria-atomic="${t=>t.ariaAtomic}"
            aria-busy="${t=>t.ariaBusy}"
            aria-controls="${t=>t.ariaControls}"
            aria-current="${t=>t.ariaCurrent}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-details="${t=>t.ariaDetails}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-errormessage="${t=>t.ariaErrormessage}"
            aria-expanded="${t=>t.ariaExpanded}"
            aria-flowto="${t=>t.ariaFlowto}"
            aria-haspopup="${t=>t.ariaHaspopup}"
            aria-hidden="${t=>t.ariaHidden}"
            aria-invalid="${t=>t.ariaInvalid}"
            aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
            aria-label="${t=>t.ariaLabel}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-live="${t=>t.ariaLive}"
            aria-owns="${t=>t.ariaOwns}"
            aria-pressed="${t=>t.ariaPressed}"
            aria-relevant="${t=>t.ariaRelevant}"
            aria-roledescription="${t=>t.ariaRoledescription}"
            ${(0,i.K)("control")}
        >
            ${(0,o.LT)(t)}
            <span class="content" part="content">
                <slot ${(0,s.e)("defaultSlottedContent")}></slot>
            </span>
            ${(0,o.aO)(t)}
        </button>
    `}()},41922(t,e,n){"use strict";n.d(e,{A(){return bt}});var r=n(39813),i=n(58207),s=n(13765),o=n(5410),a=n(58625),l=n(99577),c=n(62044),u=n(88383),h=(0,n(96423).Hj)({Unknown:0,NonRetryableStatus:1,InvalidEvent:2,SizeLimitExceeded:3,KillSwitch:4,QueueFull:5}),d=n(20468),f=n(58168),p="REAL_TIME",v="",g="POST",b="drop",m="send",y="requeue",w="rspFail",$="application/x-json-stream",x="cache-control",k="content-type",C="kill-tokens",S="kill-duration",E="time-delta-millis",M="client-version",F="client-id",D="time-delta-to-apply-millis",O="upload-time",A="apikey",T="AuthMsaDeviceTicket",I="AuthXToken",B="msfpc",N="trace",R="user";function L(t){var e=(t.ext||{}).intweb;return e&&(0,l.yD)(e[B])?e[B]:null}function j(t){for(var e=null,n=0;null===e&&n<t.length;n++)e=L(t[n]);return e}var P=function(){function t(e,n){var r=n?[].concat(n):[],i=this,s=j(r);i.iKey=function(){return e},i.Msfpc=function(){return s||v},i.count=function(){return r.length},i.events=function(){return r},i.addEvent=function(t){return!!t&&(r.push(t),s||(s=L(t)),!0)},i.split=function(n,i){var o;if(n<r.length){var a=r.length-n;(0,c.hX)(i)||(a=i<a?i:a),o=r.splice(n,a),s=j(r)}return new t(e,o)}}return t.create=function(e,n){return new t(e,n)},t}(),z=function(){function t(){var e=!0,n=!0,r=!0,s="use-collector-delta",o=!1;(0,i.A)(t,this,function(t){t.allowRequestSending=function(){return e},t.firstRequestSent=function(){r&&(r=!1,o||(e=!1))},t.shouldAddClockSkewHeaders=function(){return n},t.getClockSkewHeaderValue=function(){return s},t.setClockSkew=function(t){o||(t?(s=t,n=!0,o=!0):n=!1,e=!0)}})}return t.__ieDyn=1,t}(),H=function(){function t(){var e={};(0,i.A)(t,this,function(t){t.setKillSwitchTenants=function(t,n){if(t&&n)try{var r=(o=t.split(","),a=[],o&&(0,c.Iu)(o,function(t){a.push((0,c.EH)(t))}),a);if("this-request-only"===n)return r;for(var i=1e3*parseInt(n,10),s=0;s<r.length;++s)e[r[s]]=(0,c.x3)()+i}catch(t){return[]}var o,a;return[]},t.isTenantKilled=function(t){var n=e,r=(0,c.EH)(t);return void 0!==n[r]&&n[r]>(0,c.x3)()||(delete n[r],!1)}})}return t.__ieDyn=1,t}(),_=n(15454);function V(t){var e,n=Math.floor(1200*Math.random())+2400;return e=Math.pow(2,t)*n,Math.min(e,6e5)}var U,W=2e6,q=Math.min(W,65e3),G="metadata",K="f",X=/\./,J=function(){function t(e,n,r,o){var a="data",u="baseData",h=!!o,d=!0,f=n,p={};(0,i.A)(t,this,function(t){function n(t,e,i,s,o,a,u){(0,c.z)(t,function(t,d){var v=null;if(d||(0,l.yD)(d)){var g=i,b=t,m=o,y=e;if(h&&!s&&X.test(t)){var w=t.split("."),$=w.length;if($>1){m&&(m=m.slice());for(var x=0;x<$-1;x++){var k=w[x];y=y[k]=y[k]||{},g+="."+k,m&&m.push(k)}b=w[$-1]}}var C=s&&function(t){var e=p[t];return void 0===e&&(t.length>=7&&(e=(0,c.tG)(t,"ext.metadata")||(0,c.tG)(t,"ext.web")),p[t]=e),e}(g);if(v=!C&&f&&f.handleField(g,b)?f.value(g,b,d,r):(0,l.TC)(b,d,r)){var S=v.value;if(y[b]=S,a&&a(m,b,v),u&&"object"==typeof S&&!(0,c.cy)(S)){var E=m;E&&(E=E.slice()).push(b),n(d,S,g+"."+b,s,E,a,u)}}}})}t.createPayload=function(t,e,n,r,i,s){return{apiKeys:[],payloadBlob:v,overflow:null,sizeExceed:[],failedEvts:[],batches:[],numEvents:0,retryCnt:t,isTeardown:e,isSync:n,isBeacon:r,sendType:s,sendReason:i}},t.appendPayload=function(n,r,i){var o=n&&r&&!n.overflow;return o&&(0,s.r2)(e,function(){return"Serializer:appendPayload"},function(){for(var e=r.events(),s=n.payloadBlob,o=n.numEvents,a=!1,l=[],u=[],h=n.isBeacon,d=h?65e3:3984588,f=h?q:W,p=0,v=0;p<e.length;){var g=e[p];if(g){if(o>=i){n.overflow=r.split(p);break}var b=t.getEventBlob(g);if(b&&b.length<=f){var m=b.length;if(s.length+m>d){n.overflow=r.split(p);break}s&&(s+="\n"),s+=b,++v>20&&(s.substr(0,1),v=0),a=!0,o++}else b?l.push(g):u.push(g),e.splice(p,1),p--}p++}if(l&&l.length>0&&n.sizeExceed.push(P.create(r.iKey(),l)),u&&u.length>0&&n.failedEvts.push(P.create(r.iKey(),u)),a){n.batches.push(r),n.payloadBlob=s,n.numEvents=o;var y=r.iKey();-1===(0,c.rD)(n.apiKeys,y)&&n.apiKeys.push(y)}},function(){return{payload:n,theBatch:{iKey:r.iKey(),evts:r.events()},max:i}}),o},t.getEventBlob=function(t){try{return(0,s.r2)(e,function(){return"Serializer.getEventBlob"},function(){var e={};e.name=t.name,e.time=t.time,e.ver=t.ver,e.iKey="o:"+(0,l.EO)(t.iKey);var r={},i=t.ext;i&&(e.ext=r,(0,c.z)(i,function(t,e){n(e,r[t]={},"ext."+t,!0,null,null,!0)}));var s=e[a]={};s.baseType=t.baseType;var o=s[u]={};return n(t.baseData,o,u,!1,[u],function(t,e,n){Z(r,t,e,n)},d),n(t.data,s,a,!1,[],function(t,e,n){Z(r,t,e,n)},d),JSON.stringify(e)},function(){return{item:t}})}catch(t){return null}}})}return t.__ieDyn=1,t}();function Z(t,e,n,r){if(r&&t){var i=(0,l.Go)(r.value,r.kind,r.propertyType);if(i>-1){var s=t[G];s||(s=t[G]={f:{}});var o=s[K];if(o||(o=s[K]={}),e)for(var a=0;a<e.length;a++){var u=e[a];o[u]||(o[u]={f:{}});var h=o[u][K];h||(h=o[u][K]={}),o=h}o=o[n]={},(0,c.cy)(r.value)?o.a={t:i}:o.t=i}}}var Q="sendAttempt",Y="&NoResponseBody=true",tt=((U={})[1]=y,U[100]=y,U[200]="sent",U[8004]=b,U[8003]=b,U),et={},nt={};function rt(t,e,n){et[t]=e,!1!==n&&(nt[e]=t)}function it(t){try{return t.responseText}catch(t){}return v}function st(t,e){var n=!1;if(t&&e){var r=(0,c.cG)(t);if(r&&r.length>0)for(var i=e.toLowerCase(),s=0;s<r.length;s++){var o=r[s];if(o&&(0,c.mQ)(e,o)&&o.toLowerCase()===i){n=!0;break}}}return n}function ot(t,e,n,r){e&&n&&n.length>0&&(r&&et[e]?(t.hdrs[et[e]]=n,t.useHdrs=!0):t.url+="&"+e+"="+n)}function at(t,e){return e&&((0,c.Et)(e)?t=[e].concat(t):(0,c.cy)(e)&&(t=e.concat(t))),t}rt(T,T,!1),rt(M,M),rt(F,"Client-Id"),rt(A,A),rt(D,D),rt(O,O),rt(I,I);var lt=function(){function t(e,n,r,o,a){this._responseHandlers=[];var h,f,p,y,T,I,N,R,L,j,P="?cors=true&"+k.toLowerCase()+"="+$,U=new H,W=!1,q=new z,G=!1,K=0,X=!0,Z=[],et={},rt=[],lt=null,ct=!1,ut=!1,ht=!1;(0,i.A)(t,this,function(t){var i=!0;function z(t,e){for(var n=0,r=null,i=0;null==r&&i<t.length;)1===(n=t[i])?(0,u.PV)()?r=H:(0,u.xk)()&&(r=ft):2===n&&(0,u.R7)(e)&&(!e||e&&!R)?r=dt:G&&3===n&&(0,u.Uf)()&&(r=vt),i++;return r?{_transport:n,_isSync:e,sendPOST:r}:null}function H(t,e,n){var r=new XDomainRequest;r.open(g,t.urlString),t.timeout&&(r.timeout=t.timeout),r.onload=function(){var t=it(r);pt(e,200,{},t),Mt(t)},r.onerror=function(){pt(e,400,{})},r.ontimeout=function(){pt(e,500,{})},r.onprogress=function(){},n?r.send(t.data):a.set(function(){r.send(t.data)},0)}function dt(t,e,n){var r,s=t.urlString,o=!1,l=!1,u=((r={body:t.data,method:g}).Microsoft_ApplicationInsights_BypassAjaxInstrumentation=!0,r);n&&(u.keepalive=!0,2===t._sendReason&&(o=!0,j&&(s+=Y))),i&&(u.credentials="include"),t.headers&&(0,c.cG)(t.headers).length>0&&(u.headers=t.headers),fetch(s,u).then(function(t){var n={},r=v,i=t.headers;i&&i.forEach(function(t,e){n[e]=t}),t.body&&t.text().then(function(t){r=t}),l||(l=!0,pt(e,t.status,n,r),Mt(r))}).catch(function(t){l||(l=!0,pt(e,0,{}))}),o&&!l&&(l=!0,pt(e,200,{})),!l&&t.timeout>0&&a.set(function(){l||(l=!0,pt(e,500,{}))},t.timeout)}function ft(t,e,n){var r=t.urlString;function s(t,e,n){if(!t[n]&&e&&e.getResponseHeader){var r=e.getResponseHeader(n);r&&(t[n]=(0,c.EH)(r))}return t}function o(t){var e={};return t.getAllResponseHeaders?e=function(t){var e={};if((0,c.Kg)(t)){var n=(0,c.EH)(t).split(/[\r\n]+/);(0,c.Iu)(n,function(t){if(t){var n=t.indexOf(": ");if(-1!==n){var r=(0,c.EH)(t.substring(0,n)).toLowerCase(),i=(0,c.EH)(t.substring(n+1));e[r]=i}else e[(0,c.EH)(t)]=1}})}return e}(t.getAllResponseHeaders()):(e=s(e,t,E),e=s(e,t,S),e=s(e,t,"kill-duration-seconds")),e}function a(t,n){pt(e,t.status,o(t),n)}n&&t.disableXhrSync&&(n=!1);var u=(0,l.H$)(g,r,i,!0,n,t.timeout);(0,c.z)(t.headers,function(t,e){u.setRequestHeader(t,e)}),u.onload=function(){var t=it(u);a(u,t),Mt(t)},u.onerror=function(){a(u)},u.ontimeout=function(){a(u)},u.send(t.data)}function pt(t,e,n,r){try{t(e,n,r)}catch(t){(0,d.ZP)(f,2,518,(0,u.mm)(t))}}function vt(t,e,n){var r=200,i=t._thePayload,s=t.urlString+(j?Y:v);try{var o=(0,u.w3)();if(!o.sendBeacon(s,t.data))if(i){var a=[];(0,c.Iu)(i.batches,function(t){if(a&&t&&t.count()>0){for(var e=t.events(),n=0;n<e.length;n++)if(!o.sendBeacon(s,lt.getEventBlob(e[n]))){a.push(t.split(n));break}}else a.push(t.split(0))}),Ft(a,8003,i.sendType,!0)}else r=0}catch(t){(0,d.OG)(f,"Failed to send telemetry using sendBeacon API. Ex:"+(0,u.mm)(t)),r=0}finally{pt(e,r,{},v)}}function gt(t){return 2===t||3===t}function bt(t){return ut&&gt(t)&&(t=2),t}function mt(){return!W&&K<n}function yt(){var t=rt;return rt=[],t}function wt(t,e,n){var r=!1;return t&&t.length>0&&!W&&p[e]&&lt&&(r=0!==e||mt()&&(n>0||q.allowRequestSending())),r}function $t(t){var e={};return t&&(0,c.Iu)(t,function(t,n){e[n]={iKey:t.iKey(),evts:t.events()}}),e}function xt(t,n,r,i,o){if(t&&0!==t.length)if(W)Ft(t,1,i);else{i=bt(i);try{var a=t,c=0!==i;(0,s.r2)(y,function(){return"HttpManager:_sendBatches"},function(s){s&&(t=t.slice(0));for(var a=[],u=null,h=(0,l.WB)(),d=p[i]||(c?p[1]:p[0]),f=d&&d._transport,v=L&&(ut||gt(i)||3===f||d._isSync&&2===f);wt(t,i,n);){var g=t.shift();g&&g.count()>0&&(U.isTenantKilled(g.iKey())?a.push(g):(u=u||lt.createPayload(n,r,c,v,o,i),lt.appendPayload(u,g,e)?null!==u.overflow&&(t=[u.overflow].concat(t),u.overflow=null,St(u,h,(0,l.WB)(),o),h=(0,l.WB)(),u=null):(St(u,h,(0,l.WB)(),o),h=(0,l.WB)(),t=[g].concat(t),u=null)))}u&&St(u,h,(0,l.WB)(),o),t.length>0&&(rt=t.concat(rt)),Ft(a,8004,i)},function(){return{batches:$t(a),retryCount:n,isTeardown:r,isSynchronous:c,sendReason:o,useSendBeacon:gt(i),sendType:i}},!c)}catch(t){(0,d.ZP)(f,2,48,"Unexpected Exception sending batch: "+(0,u.mm)(t))}}}function kt(t,e){var n={url:P,hdrs:{},useHdrs:!1};e?(n.hdrs=(0,l.X$)(n.hdrs,et),n.useHdrs=(0,c.cG)(n.hdrs).length>0):(0,c.z)(et,function(t,e){nt[t]?ot(n,nt[t],e,!1):(n.hdrs[t]=e,n.useHdrs=!0)}),ot(n,F,"NO_AUTH",e),ot(n,M,l.xE,e);var r=v;(0,c.Iu)(t.apiKeys,function(t){r.length>0&&(r+=","),r+=t}),ot(n,A,r,e),ot(n,O,(0,c.x3)().toString(),e);var i=function(t){for(var e=0;e<t.batches.length;e++){var n=t.batches[e].Msfpc();if(n)return encodeURIComponent(n)}return v}(t);if((0,l.yD)(i)&&(n.url+="&ext.intweb.msfpc="+i),q.shouldAddClockSkewHeaders()&&ot(n,D,q.getClockSkewHeaderValue(),e),y.getWParam){var s=y.getWParam();s>=0&&(n.url+="&w="+s)}for(var o=0;o<Z.length;o++)n.url+="&"+Z[o].name+"="+Z[o].value;return n}function Ct(t,e,n){t[e]=t[e]||{},t[e][h.identifier]=n}function St(e,n,i,o){if(e&&e.payloadBlob&&e.payloadBlob.length>0){var a=!!t.sendHook,v=p[e.sendType];!gt(e.sendType)&&e.isBeacon&&2===e.sendReason&&(v=p[2]||p[3]||v);var g=ht;(e.isBeacon||3===v._transport)&&(g=!1);var b=kt(e,g);g=g||b.useHdrs;var m=(0,l.WB)();(0,s.r2)(y,function(){return"HttpManager:_doPayloadSend"},function(){for(var p=0;p<e.batches.length;p++)for(var w=e.batches[p].events(),M=0;M<w.length;M++){var F=w[M];if(ct){var D=F.timings=F.timings||{};Ct(D,"sendEventStart",m),Ct(D,"serializationStart",n),Ct(D,"serializationCompleted",i)}F[Q]>0?F[Q]++:F[Q]=1}Ft(e.batches,1e3+(o||0),e.sendType,!0);var O={data:e.payloadBlob,urlString:b.url,headers:b.hdrs,_thePayload:e,_sendReason:o,timeout:I,disableXhrSync:N,disableFetchKeepAlive:R};g&&(st(O.headers,x)||(O.headers[x]="no-cache, no-store"),st(O.headers,k)||(O.headers[k]=$));var A=null;v&&(A=function(n){q.firstRequestSent();var i=function(n,i){!function(e,n,i,s){var o=9e3,a=null,u=!1,d=!1;try{var f=!0;if(typeof e!==_.bA){if(n){q.setClockSkew(n[E]);var p=n[S]||n["kill-duration-seconds"];(0,c.Iu)(U.setKillSwitchTenants(n[C],p),function(t){(0,c.Iu)(i.batches,function(e){if(e.iKey()===t){a=a||[];var n=e.split(0);i.numEvents-=n.count(),a.push(n)}})})}if(200==e||204==e)return void(o=200);((g=e)>=300&&g<500&&408!=g&&429!=g||501==g||505==g||i.numEvents<=0)&&(f=!1),o=9e3+e%1e3}if(f){o=100;var v=i.retryCnt;0===i.sendType&&(v<r?(u=!0,Et(function(){0===i.sendType&&K--,xt(i.batches,v+1,i.isTeardown,ut?2:i.sendType,5)},ut,V(v))):(d=!0,ut&&(o=8001)))}}finally{u||(q.setClockSkew(),function(e,n,r,i){try{i&&h._backOffTransmission(),200===n&&(i||e.isSync||h._clearBackOff(),function(t){if(ct){var e=(0,l.WB)();(0,c.Iu)(t,function(t){t&&t.count()>0&&function(t,e){ct&&(0,c.Iu)(t,function(t){Ct(t.timings=t.timings||{},"sendEventCompleted",e)})}(t.events(),e)})}}(e.batches)),Ft(e.batches,n,e.sendType,!0)}finally{0===e.sendType&&(K--,5!==r&&t.sendQueuedRequests(e.sendType,r))}}(i,o,s,d)),Ft(a,8004,i.sendType)}var g}(n,i,e,o)},s=e.isTeardown||e.isSync;try{v.sendPOST(n,i,s),t.sendListener&&t.sendListener(O,n,s,e.isBeacon)}catch(t){(0,d.OG)(f,"Unexpected exception sending payload. Ex:"+(0,u.mm)(t)),pt(i,0,{})}}),(0,s.r2)(y,function(){return"HttpManager:_doPayloadSend.sender"},function(){if(A)if(0===e.sendType&&K++,a&&!e.isBeacon&&3!==v._transport){var n={data:O.data,urlString:O.urlString,headers:(0,l.X$)({},O.headers),timeout:O.timeout,disableXhrSync:O.disableXhrSync,disableFetchKeepAlive:O.disableFetchKeepAlive},r=!1;(0,s.r2)(y,function(){return"HttpManager:_doPayloadSend.sendHook"},function(){try{t.sendHook(n,function(t){r=!0,X||t._thePayload||(t._thePayload=t._thePayload||O._thePayload,t._sendReason=t._sendReason||O._sendReason),A(t)},e.isSync||e.isTeardown)}catch(t){r||A(O)}})}else A(O)})},function(){return{thePayload:e,serializationStart:n,serializationCompleted:i,sendReason:o}},e.isSync)}e.sizeExceed&&e.sizeExceed.length>0&&Ft(e.sizeExceed,8003,e.sendType),e.failedEvts&&e.failedEvts.length>0&&Ft(e.failedEvts,8002,e.sendType)}function Et(t,e,n){e?t():a.set(t,n)}function Mt(e){var n=t._responseHandlers;try{for(var r=0;r<n.length;r++)try{n[r](e)}catch(t){(0,d.ZP)(f,1,519,"Response handler failed: "+t)}if(e){var i=JSON.parse(e);(0,l.yD)(i.webResult)&&(0,l.yD)(i.webResult[B])&&T.set("MSFPC",i.webResult[B],31536e3)}}catch(t){}}function Ft(t,e,n,r){if(t&&t.length>0&&o){var i=o[function(t){var e=tt[t];(0,l.yD)(e)||(e="oth",t>=9e3&&t<=9999?e=w:t>=8e3&&t<=8999?e=b:t>=1e3&&t<=1999&&(e=m));return e}(e)];if(i){var a=0!==n;(0,s.r2)(y,function(){return"HttpManager:_sendBatchesNotification"},function(){Et(function(){try{i.call(o,t,e,a,n)}catch(t){(0,d.ZP)(f,1,74,"send request notification failed: "+t)}},r||a,0)},function(){return{batches:$t(t),reason:e,isSync:a,sendSync:r,sendType:n}},!a)}}}t.initialize=function(t,e,n,r,s){var o;s||(s={}),P=t+P,ht=!!(0,c.b0)(s.avoidOptions)||!s.avoidOptions,y=e,T=e.getCookieMgr(),ct=!y.config.disableEventTimings;var a=!!y.config.enableCompoundKey;f=(h=n).diagLog();var l=s.valueSanitizer,v=s.stringifyObjects;(0,c.b0)(s.enableCompoundKey)||(a=!!s.enableCompoundKey),I=s.xhrTimeout,N=!!s.disableXhrSync,R=!!s.disableFetchKeepAlive,j=!1!==s.addNoResponse,G=!(0,u.lV)(),lt=new J(y,l,v,a),(0,c.hX)(s.useSendBeacon)||(G=!!s.useSendBeacon);var g=r,b=s.alwaysUseXhrOverride?r:null,m=s.alwaysUseXhrOverride?r:null,w=[3,2];if(!r){X=!1;var $=(0,u.g$)();$&&$.protocol&&"file:"===$.protocol.toLowerCase()&&(i=!1);var x=[];(0,u.lV)()?(x=[2,1],w=[2,1,3]):x=[1,2,3],(r=z(x=at(x,s.transports),!1))||(0,d.OG)(f,"No available transport to send events"),g=z(x,!0)}b||(b=z(w=at(w,s.unloadTransports),!0)),L=!X&&(G&&(0,u.Uf)()||!R&&(0,u.R7)(!0)),(o={})[0]=r,o[1]=g||z([1,2,3],!0),o[2]=b||g||z([1],!0),o[3]=m||z([2,3],!0)||g||z([1],!0),p=o},t._getDbgPlgTargets=function(){return[p[0],U,lt,p]},t.addQueryStringParameter=function(t,e){for(var n=0;n<Z.length;n++)if(Z[n].name===t)return void(Z[n].value=e);Z.push({name:t,value:e})},t.addHeader=function(t,e){et[t]=e},t.canSendRequest=function(){return mt()&&q.allowRequestSending()},t.sendQueuedRequests=function(t,e){(0,c.b0)(t)&&(t=0),ut&&(t=bt(t),e=2),wt(rt,t,0)&&xt(yt(),0,!1,t,e||0)},t.isCompletelyIdle=function(){return!W&&0===K&&0===rt.length},t.setUnloading=function(t){ut=t},t.addBatch=function(t){if(t&&t.count()>0){if(U.isTenantKilled(t.iKey()))return!1;rt.push(t)}return!0},t.teardown=function(){rt.length>0&&xt(yt(),0,!0,2,2)},t.pause=function(){W=!0},t.resume=function(){W=!1,t.sendQueuedRequests(0,4)},t.sendSynchronousBatch=function(t,e,n){t&&t.count()>0&&((0,c.hX)(e)&&(e=1),ut&&(e=bt(e),n=2),xt([t],0,!1,e,n||0))}})}return t.__ieDyn=1,t}();function ct(t,e){for(var n=[],r=2;r<arguments.length;r++)n[r-2]=arguments[r];return setTimeout(t,e,n)}function ut(t){clearTimeout(t)}function ht(t,e){return{set:t||ct,clear:e||ut}}var dt="eventsDiscarded",ft="overrideInstrumentationKey",pt="maxEventRetryAttempts",vt="maxUnloadEventRetryAttempts",gt=function(t){function e(){var n,r=t.call(this)||this;r.identifier="PostChannel",r.priority=1011,r.version="3.2.8";var f,v,g,b,m,y,w,$=!1,x=[],k=null,C=!1,S=0,E=500,M=0,F=1e4,D={},O=p,A=null,I=null,B=0,L=0,j={},z=-1,H=!0,_=!1,U=6,W=2;return(0,i.A)(e,r,function(t,e){function r(t){"beforeunload"!==(t||(0,u.zk)().event).type&&(_=!0,v.setUnloading(_)),Y(2,2)}function i(t){_=!1,v.setUnloading(_)}function q(t,e){if(t.sendAttempt||(t.sendAttempt=0),t.latency||(t.latency=1),t.ext&&t.ext[N]&&delete t.ext[N],t.ext&&t.ext[R]&&t.ext[R].id&&delete t.ext[R].id,H&&(l.u9,t.ext=(0,c.hW)(t.ext),t.baseData&&(t.baseData=(0,c.hW)(t.baseData)),t.data&&(t.data=(0,c.hW)(t.data))),t.sync)if(B||C)t.latency=3,t.sync=!1;else if(v)return H&&(t=(0,c.hW)(t)),void v.sendSynchronousBatch(P.create(t.iKey,[t]),!0===t.sync?1:t.sync,3);var n=t.latency,r=M,i=F;4===n&&(r=S,i=E);var s=!1;if(r<i)s=!nt(t,e);else{var o=1,a=20;4===n&&(o=4,a=1),s=!0,function(t,e,n,r){for(;n<=e;){var i=tt(t,e,!0);if(i&&i.count()>0){var s=i.split(0,r),o=s.count();if(o>0)return 4===n?S-=o:M-=o,bt(dt,[s],h.QueueFull),!0}n++}return rt(),!1}(t.iKey,t.latency,o,a)&&(s=!nt(t,e))}s&&gt(dt,[t],h.QueueFull)}function G(t,e,n){var r=it(t,e,n);return v.sendQueuedRequests(e,n),r}function K(){return M>0}function X(){if(z>=0&&it(z,0,m)&&v.sendQueuedRequests(0,m),S>0&&!I&&!C){var t=D[O][2];t>=0&&(I=Z(function(){I=null,G(4,0,1),X()},t))}var e=D[O][1];!A&&!k&&e>=0&&!C&&(K()?A=Z(function(){A=null,G(0===L?3:1,0,1),L++,L%=2,X()},e):L=0)}function J(){n=null,$=!1,x=[],k=null,C=!1,S=0,E=500,M=0,F=1e4,D={},O=p,A=null,I=null,B=0,L=0,f=null,j={},g=void 0,b=0,z=-1,m=null,H=!0,_=!1,U=6,W=2,y=null,w=ht(),v=new lt(500,2,1,{requeue:ct,send:mt,sent:yt,drop:wt,rspFail:$t,oth:xt},w),at(),j[4]={batches:[],iKeyMap:{}},j[3]={batches:[],iKeyMap:{}},j[2]={batches:[],iKeyMap:{}},j[1]={batches:[],iKeyMap:{}},kt()}function Z(t,e){0===e&&B&&(e=1);var n=1e3;return B&&(n=V(B-1)),w.set(t,e*n)}function Q(){return null!==A&&(w.clear(A),A=null,L=0,!0)}function Y(t,e){Q(),k&&(w.clear(k),k=null),C||G(1,t,e)}function tt(t,e,n){var r=j[e];r||(r=j[e=1]);var i=r.iKeyMap[t];return!i&&n&&(i=P.create(t),r.batches.push(i),r.iKeyMap[t]=i),i}function et(e,n){v.canSendRequest()&&!B&&(g>0&&M>g&&(n=!0),n&&null==k&&t.flush(e,null,20))}function nt(t,e){H&&(t=(0,c.hW)(t));var n=t.latency,r=tt(t.iKey,n,!0);return!!r.addEvent(t)&&(4!==n?(M++,e&&0===t.sendAttempt&&et(!t.sync,b>0&&r.count()>=b)):S++,!0)}function rt(){for(var t=0,e=0,n=function(n){var r=j[n];r&&r.batches&&(0,c.Iu)(r.batches,function(r){4===n?t+=r.count():e+=r.count()})},r=1;r<=4;r++)n(r);M=e,S=t}function it(e,n,r){var i=!1,o=0===n;return!o||v.canSendRequest()?(0,s.r2)(t.core,function(){return"PostChannel._queueBatches"},function(){for(var t=[],n=4;n>=e;){var r=j[n];r&&r.batches&&r.batches.length>0&&((0,c.Iu)(r.batches,function(e){v.addBatch(e)?i=i||e&&e.count()>0:t=t.concat(e.events()),4===n?S-=e.count():M-=e.count()}),r.batches=[],r.iKeyMap={}),n--}t.length>0&&gt(dt,t,h.KillSwitch),i&&z>=e&&(z=-1,m=0)},function(){return{latency:e,sendType:n,sendReason:r}},!o):(z=z>=0?Math.min(z,e):e,m=Math.max(m,r)),i}function st(t,e){G(1,0,e),rt(),ot(function(){t&&t(),x.length>0?k=Z(function(){k=null,st(x.shift(),e)},0):(k=null,X())})}function ot(t){v.isCompletelyIdle()?t():k=Z(function(){k=null,ot(t)},.25)}function at(){(D={})[p]=[2,1,0],D.NEAR_REAL_TIME=[6,3,0],D.BEST_EFFORT=[18,9,0]}function ct(e,n){var r=[],i=U;_&&(i=W),(0,c.Iu)(e,function(e){e&&e.count()>0&&(0,c.Iu)(e.events(),function(e){e&&(e.sync&&(e.latency=4,e.sync=!1),e.sendAttempt<i?((0,l.u9)(e,t.identifier),q(e,!1)):r.push(e))})}),r.length>0&&gt(dt,r,h.NonRetryableStatus),_&&Y(2,2)}function ut(e,n){var r=t._notificationManager||{},i=r[e];if(i)try{i.apply(r,n)}catch(n){(0,d.ZP)(t.diagLog(),1,74,e+" notification failed: "+n)}}function gt(t,e){for(var n=[],r=2;r<arguments.length;r++)n[r-2]=arguments[r];e&&e.length>0&&ut(t,[e].concat(n))}function bt(t,e){for(var n=[],r=2;r<arguments.length;r++)n[r-2]=arguments[r];e&&e.length>0&&(0,c.Iu)(e,function(e){e&&e.count()>0&&ut(t,[e.events()].concat(n))})}function mt(t,e,n){t&&t.length>0&&ut("eventsSendRequest",[e>=1e3&&e<=1999?e-1e3:0,!0!==n])}function yt(t,e){bt("eventsSent",t,e),X()}function wt(t,e){bt(dt,t,e>=8e3&&e<=8999?e-8e3:h.Unknown)}function $t(t){bt(dt,t,h.NonRetryableStatus),X()}function xt(t,e){bt(dt,t,h.Unknown),X()}function kt(){b=n&&n.disableAutoBatchFlushLimit?0:Math.max(1500,F/6)}J(),t._getDbgPlgTargets=function(){return[v]},t.initialize=function(u,h,d){(0,s.r2)(h,function(){return"PostChannel:initialize"},function(){var s=h;e.initialize(u,h,d);try{h.addUnloadCb;y=(0,o.Hm)((0,a.Z)(t.identifier),h.evtNamespace&&h.evtNamespace());var p=t._getTelCtx();u.extensionConfig[t.identifier]=u.extensionConfig[t.identifier]||{},n=p.getExtCfg(t.identifier),w=ht(n.setTimeoutOverride,n.clearTimeoutOverride),H=!n.disableOptimizeObj&&(0,l.F2)(),function(t){var e=t.getWParam;t.getWParam=function(){var t=0;return n.ignoreMc1Ms0CookieProcessing&&(t|=2),t|e()}}(s),n.eventsLimitInMem>0&&(F=n.eventsLimitInMem),n.immediateEventLimit>0&&(E=n.immediateEventLimit),n.autoFlushEventsLimit>0&&(g=n.autoFlushEventsLimit),(0,c.Et)(n[pt])&&(U=n[pt]),(0,c.Et)(n[vt])&&(W=n[vt]),kt(),n.httpXHROverride&&n.httpXHROverride.sendPOST&&(f=n.httpXHROverride),(0,l.yD)(u.anonCookieName)&&v.addQueryStringParameter("anoncknm",u.anonCookieName),v.sendHook=n.payloadPreprocessor,v.sendListener=n.payloadListener;var b=n.overrideEndpointUrl?n.overrideEndpointUrl:u.endpointUrl;t._notificationManager=h.getNotifyMgr(),v.initialize(b,t.core,t,f,n);var m=u.disablePageUnloadEvents||[];(0,o.ee)(r,m,y),(0,o.Fc)(r,m,y),(0,o.oS)(i,u.disablePageShowEvents,y)}catch(e){throw t.setInitialized(!1),e}},function(){return{coreConfig:u,core:h,extensions:d}})},t.processTelemetry=function(e,r){(0,l.u9)(e,t.identifier);var i=(r=t._getTelCtx(r)).getExtCfg(t.identifier),s=!!n.disableTelemetry;i&&(s=s||!!i.disableTelemetry);var o=e;s||$||(n[ft]&&(o.iKey=n[ft]),i&&i[ft]&&(o.iKey=i[ft]),q(o,!0),_?Y(2,2):X()),t.processNext(o,r)},t._doTeardown=function(t,e){Y(2,2),$=!0,v.teardown(),(0,o.Ds)(null,y),(0,o.sq)(null,y),(0,o.vF)(null,y),J()},t.setEventQueueLimits=function(t,e){F=t>0?t:1e4,g=e>0?e:0,kt();var n=M>t;if(!n&&b>0)for(var r=1;!n&&r<=3;r++){var i=j[r];i&&i.batches&&(0,c.Iu)(i.batches,function(t){t&&t.count()>=b&&(n=!0)})}et(!0,n)},t.pause=function(){Q(),C=!0,v.pause()},t.resume=function(){C=!1,v.resume(),X()},t.addResponseHandler=function(t){v._responseHandlers.push(t)},t._loadTransmitProfiles=function(t){Q(),at(),O=p,X(),(0,c.z)(t,function(t,e){var n=e.length;if(n>=2){var r=n>2?e[2]:0;if(e.splice(0,n-2),e[1]<0&&(e[0]=-1),e[1]>0&&e[0]>0){var i=e[0]/e[1];e[0]=Math.ceil(i)*e[1]}r>=0&&e[1]>=0&&r>e[1]&&(r=e[1]),e.push(r),D[t]=e}})},t.flush=function(t,e,n){if(void 0===t&&(t=!0),!C)if(n=n||1,t)null==k?(Q(),it(1,0,n),k=Z(function(){k=null,st(e,n)},0)):x.push(e);else{var r=Q();G(1,1,n),null!=e&&e(),r&&X()}},t.setMsaAuthTicket=function(t){v.addHeader(T,t)},t.hasEvents=K,t._setTransmitProfile=function(t){O!==t&&void 0!==D[t]&&(Q(),O=t,X())},t._backOffTransmission=function(){B<4&&(B++,Q(),X())},t._clearBackOff=function(){B&&(B=0,Q(),X())},(0,c.r)(t,"_setTimeoutOverride",function(){return w.set},function(t){w=ht(t,w.clear)}),(0,c.r)(t,"_clearTimeoutOverride",function(){return w.clear},function(t){w=ht(w.set,t)})}),r}return(0,r.qU)(e,t),e.__ieDyn=1,e}(f.s),bt=gt},42277(t,e,n){"use strict";n.d(e,{D(){return i},d(){return c}});var r=n(19470);const i=Object.freeze({none:0,attribute:1,booleanAttribute:2,property:3,content:4,tokenList:5,event:6}),s=t=>t,o=globalThis.trustedTypes?globalThis.trustedTypes.createPolicy("fast-html",{createHTML:s}):{createHTML:s};let a=Object.freeze({createHTML:t=>o.createHTML(t),protect:(t,e,n,r)=>r});const l=a,c=Object.freeze({get policy(){return a},setPolicy(t){if(a!==l)throw r.Zx.error(1201);a=t},setAttribute(t,e,n){null==n?t.removeAttribute(e):t.setAttribute(e,n)},setBooleanAttribute(t,e,n){n?t.setAttribute(e,""):t.removeAttribute(e)}})},42938(t,e,n){"use strict";n.d(e,{u(){return i}});var r=n(31157);const i=t=>"rtl"===t.closest("[dir]")?.dir?r.O.rtl:r.O.ltr},43404(t,e,n){"use strict";n.d(e,{C2(){return a},Q2(){return l},iS(){return o},uC(){return s}});var r=n(45755);const{create:i}=r.G,s=i("neutral-stroke-rest-delta",25),o=i("neutral-stroke-hover-delta",40),a=i("neutral-stroke-active-delta",16),l=i("neutral-stroke-focus-delta",25)},43919(t,e,n){"use strict";n.d(e,{j(){return r}});const r={menuitem:"menuitem",menuitemcheckbox:"menuitemcheckbox",menuitemradio:"menuitemradio"};r.menuitem,r.menuitemcheckbox,r.menuitemradio},43944(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10 2a8 8 0 110 16 8 8 0 010-16zm0 1a7 7 0 100 14 7 7 0 000-14zm0 9.5a.75.75 0 110 1.5.75.75 0 010-1.5zM10 6a.5.5 0 01.5.41V11a.5.5 0 01-1 .09V6.5c0-.28.22-.5.5-.5z"></path></svg>'},44767(t,e,n){"use strict";n.d(e,{m(){return F}});var r=n(37180),i=n(56911),s=n(92011),o=n(23429),a=n(60815),l=n(2298),c=n(55230),u=n(43919),h=n(65923);class d extends s.L{constructor(){super(...arguments),this.expandedItem=null,this.focusIndex=-1,this.isNestedMenu=()=>null!==this.parentElement&&(0,l.sb)(this.parentElement)&&"menuitem"===this.parentElement.getAttribute("role"),this.handleFocusOut=t=>{if(!this.contains(t.relatedTarget)&&void 0!==this.menuItems){this.collapseExpandedItem();const t=this.menuItems.findIndex(this.isFocusableElement);this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.menuItems[t].setAttribute("tabindex","0"),this.focusIndex=t}},this.handleItemFocus=t=>{const e=t.target;void 0!==this.menuItems&&e!==this.menuItems[this.focusIndex]&&(this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.focusIndex=this.menuItems.indexOf(e),e.setAttribute("tabindex","0"))},this.handleExpandedChanged=t=>{if(t.defaultPrevented||null===t.target||void 0===this.menuItems||this.menuItems.indexOf(t.target)<0)return;t.preventDefault();const e=t.target;null===this.expandedItem||e!==this.expandedItem||!1!==e.expanded?e.expanded&&(null!==this.expandedItem&&this.expandedItem!==e&&(this.expandedItem.expanded=!1),this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.expandedItem=e,this.focusIndex=this.menuItems.indexOf(e),e.setAttribute("tabindex","0")):this.expandedItem=null},this.changeHandler=t=>{if(void 0===this.menuItems)return;const e=t.target,n=this.menuItems.indexOf(e);if(-1!==n&&"menuitemradio"===e.role&&!0===e.checked){for(let t=n-1;t>=0;--t){const e=this.menuItems[t],n=e.getAttribute("role");if(n===u.j.menuitemradio&&(e.checked=!1),"separator"===n)break}const t=this.menuItems.length-1;for(let e=n+1;e<=t;++e){const t=this.menuItems[e],n=t.getAttribute("role");if(n===u.j.menuitemradio&&(t.checked=!1),"separator"===n)break}}},this.isMenuItemElement=t=>t instanceof h.th||(0,l.sb)(t)&&t.getAttribute("role")in d.focusableElementRoles,this.isFocusableElement=t=>this.isMenuItemElement(t)}itemsChanged(t,e){this.$fastController.isConnected&&void 0!==this.menuItems&&this.setItems()}connectedCallback(){super.connectedCallback(),o.L.enqueue(()=>{this.setItems()}),this.addEventListener("change",this.changeHandler)}disconnectedCallback(){super.disconnectedCallback(),this.removeItemListeners(),this.menuItems=void 0,this.removeEventListener("change",this.changeHandler)}focus(){this.setFocus(0,1)}collapseExpandedItem(){null!==this.expandedItem&&(this.expandedItem.expanded=!1,this.expandedItem=null)}handleMenuKeyDown(t){if(!t.defaultPrevented&&void 0!==this.menuItems)switch(t.key){case c.HX:return void this.setFocus(this.focusIndex+1,1);case c.I5:return void this.setFocus(this.focusIndex-1,-1);case c.FM:return void this.setFocus(this.menuItems.length-1,-1);case c.kE:return void this.setFocus(0,1);default:return!0}}removeItemListeners(t=this.items){t.forEach(t=>{t.removeEventListener("focus",this.handleItemFocus),t.removeEventListener("expanded-changed",this.handleExpandedChanged),a.cP.getNotifier(t).unsubscribe(this,"hidden")})}setItems(){const t=Array.from(this.children);this.removeItemListeners(t),t.forEach(t=>a.cP.getNotifier(t).subscribe(this,"hidden"));const e=t.filter(t=>!t.hasAttribute("hidden"));this.menuItems=e;const n=this.menuItems.filter(this.isMenuItemElement);n.length&&(this.focusIndex=0),n.forEach((t,e)=>{t.setAttribute("tabindex",0===e?"0":"-1"),t.addEventListener("expanded-change",this.handleExpandedChanged),t.addEventListener("focus",this.handleItemFocus)})}handleChange(t,e){"hidden"===e&&this.setItems()}setFocus(t,e){if(void 0!==this.menuItems)for(;t>=0&&t<this.menuItems.length;){const n=this.menuItems[t];if(this.isFocusableElement(n)){this.focusIndex>-1&&this.menuItems.length>=this.focusIndex-1&&this.menuItems[this.focusIndex].setAttribute("tabindex","-1"),this.focusIndex=t,n.setAttribute("tabindex","0"),n.focus();break}t+=e}}}d.focusableElementRoles=u.j,(0,i.Cg)([a.sH,(0,i.Sn)("design:type",Array)],d.prototype,"items",void 0);var f=n(95239),p=n(22448),v=n(10735);class g extends d{setItems(){super.setItems();const t=this.menuItems?.filter(this.isMenuItemElement);t?.forEach((e,n)=>{const r=t?.reduce((t,e)=>{const n=g.elementIndent(e);return Math.max(t,n)},0);e instanceof p.z&&(e.startColumnCount=r)})}static elementIndent(t){const e=t.getAttribute("role"),n=t.querySelector("[slot=start]");return e&&e!==u.j.menuitem?n?2:1:n?1:0}connectedCallback(){super.connectedCallback(),f.p.setValueFor(this,v.T)}}var b=n(74849),m=n(64187),y=n(37998),w=n(26920),$=n(57416),x=n(74838),k=n(22683);const C=b.A`
    ${(0,m.V)("block")} :host {
        --elevation: 11;
        background: ${f.p};
        border: calc(${w.XA} * 1px) solid transparent;
        border-radius: ${$.JU};
        ${y.ET}
        margin: 0;
        border-radius: calc(${$.Pb} * 1px);
        padding: calc(${x.vR} * 1px) 0;
        max-width: 368px;
        min-width: 64px;
    }

    :host([slot="submenu"]) {
        width: max-content;
        margin: 0 calc(${x.vR} * 1px);
    }

    ::slotted(hr) {
        box-sizing: content-box;
        height: 0;
        margin: 0;
        border: none;
        border-top: calc(${w.XA} * 1px) solid ${k.hb};
    }
`;var S=n(96950),E=n(82774);const M=S.qy`
        <template
            slot="${t=>t.slot?t.slot:t.isNestedMenu()?"submenu":void 0}"
            role="menu"
            @keydown="${(t,e)=>t.handleMenuKeyDown(e.event)}"
            @focusout="${(t,e)=>t.handleFocusOut(e.event)}"
        >
            <slot ${(0,E.e)("items")}></slot>
        </template>
    `,F=g.compose({name:`${r.c.prefix}-menu`,template:M,styles:C})},45476(t,e,n){"use strict";n.d(e,{wO(){return d},oO(){return h},EE(){return c},Wl(){return u}});var r=n(45755),i=n(95239),s=n(37947),o=n(14205),a=n(31023);const{create:l}=r.G,c=l({name:"neutral-fill-stealth-recipe"},{evaluate(t,e){return function(t,e,n,r,i,s,o,a,l,c){const u=Math.max(n,r,i,s,o,a,l,c),h=t.closestIndexOf(e),d=h>=u?-1:1;return{rest:t.get(h+d*n),hover:t.get(h+d*r),active:t.get(h+d*i),focus:t.get(h+d*s)}}(t(a.r),e||t(i.p),t(o.q),t(o.oj),t(o.Ws),t(o.Mc),t(s.DE),t(s.l2),t(s.L6),t(s.tN))}}),u=l("neutral-fill-stealth-rest",t=>t(c).evaluate(t).rest),h=l("neutral-fill-stealth-hover",t=>t(c).evaluate(t).hover),d=l("neutral-fill-stealth-active",t=>t(c).evaluate(t).active);l("neutral-fill-stealth-focus",t=>t(c).evaluate(t).focus)},45755(t,e,n){"use strict";n.d(e,{G(){return k}});var r=n(56911),i=n(60815),s=n(93800),o=n(92011),a=n(61963),l=n(47429);class c{constructor(t){this.value=t,this.notifier=i.cP.getNotifier(this),this.dependencies=new Set,this.binding=i.cP.binding(t,this),this.binding.setMode(!1)}static getOrCreate(t){let e=c.cache.get(t);return e||(e=new c(t),c.cache.set(t,e),e)}evaluate(t,e){return this.binding.observe(n=>{if(this.dependencies.add(n),e===n){if(t.parent)return t.parent.getTokenValue(n);throw new Error("DesignTokenNode has encountered a circular token reference. Avoid this by setting the token value for an ancestor node.")}return t.getTokenValue(n)})}handleChange(){this.notifier.notify(void 0)}}c.cache=new WeakMap;class u{constructor(t,e,n,r){this.token=t,this.evaluator=e,this.node=n,this.subscriber=r,this.value=e.evaluate(n,t),this.subscriber&&i.cP.getNotifier(this.evaluator).subscribe(this.subscriber)}dispose(){this.subscriber&&i.cP.getNotifier(this.evaluator).unsubscribe(this.subscriber)}update(){return this.value=this.evaluator.evaluate(this.node,this.token),this}}class h{constructor(t,e,n,r){this.target=t,this.type=e,this.token=n,this.value=r}notify(){i.cP.getNotifier(this.token).notify(this)}}class d{constructor(){this._parent=null,this._children=new Set,this._values=new Map,this._derived=new Map,this.dependencyGraph=new Map}static isDerivedTokenValue(t){return"function"==typeof t}static isDerivedFor(t,e){return t._derived.has(e)}static collectDerivedContext(t){const e=new Map;if(null===t.parent)return e;let n=d.getAssignedTokensForNode(t),r=t.parent;do{const t=d.getAssignedTokensForNode(r);for(let i=0,s=t.length;i<s;i++){const s=t[i];!n.includes(s)&&d.isDerivedFor(r,s)&&e.set(s,r._derived.get(s))}n=Array.from(new Set(n.concat(t))),r=r.parent}while(null!==r);return e}static getLocalTokenValue(t,e){return d.isAssigned(t,e)?d.isDerivedFor(t,e)?t._derived.get(e).value:t._values.get(e):void 0}static getOrCreateDependencyGraph(t,e){let n=t.dependencyGraph.get(e);return n||(n=new Set,t.dependencyGraph.set(e,n),n)}static notify(){const t=this._notifications;this._notifications=[];for(const e of t)e.notify()}static queueNotification(...t){this._notifications.push(...t)}static getAssignedTokensForNode(t){return Array.from(t._values.keys())}static composeAssignedTokensForNode(t){const e=new Set(d.getAssignedTokensForNode(t));let n=t.parent;for(;null!==n;){const t=d.getAssignedTokensForNode(n);for(const n of t)e.add(n);n=n.parent}return Array.from(e)}static isAssigned(t,e){return t._values.has(e)}get parent(){return this._parent}get children(){return Array.from(this._children)}appendChild(t){let e=null;null!==t.parent&&(e=d.composeAssignedTokensForNode(t.parent),t.parent._children.delete(t));const n=d.composeAssignedTokensForNode(this),r=d.collectDerivedContext(this);t._parent=this,this._children.add(t);for(const i of n){let n=0;if(null!==e){const t=e.indexOf(i);-1!==t&&(n=1,e.splice(t,1))}t.dispatch(new h(this,n,i,r.get(i)?.evaluator.value))}if(null!==e&&e.length>0)for(const n of e)t.dispatch(new h(this,2,n,r.get(n)?.evaluator.value));d.notify()}removeChild(t){if(t.parent===this){const e=d.composeAssignedTokensForNode(this);t._parent=null,this._children.delete(t);for(const n of e)t.dispatch(new h(this,2,n));d.notify()}}dispose(){this.parent&&(this.parent._children.delete(this),this._parent=null);for(const[,t]of this._derived)t.dispose()}setTokenValue(t,e){const n=d.isAssigned(this,t)||d.isDerivedFor(this,t)?1:0,r=d.getLocalTokenValue(this,t);this._values.set(t,e),d.isDerivedFor(this,t)&&this.tearDownDerivedTokenValue(t);const i=d.isDerivedTokenValue(e),s=d.collectDerivedContext(this);let o;if(i){o=this.setupDerivedTokenValue(t,e,!0).value}else o=e;r!==o&&d.queueNotification(new h(this,n,t,e)),this.dispatch(new h(this,n,t,e)),s.forEach((t,e)=>{if(!d.isDerivedFor(this,e)){d.getLocalTokenValue(this,e)!==(t=this.setupDerivedTokenValue(e,t.evaluator.value)).value&&d.queueNotification(new h(this,1,e,t.evaluator.value)),this.dispatch(new h(this,0,e,t.evaluator.value))}}),d.notify()}getTokenValue(t){let e,n=this;for(;null!==n;){if(d.isDerivedFor(n,t)){e=n._derived.get(t).value;break}if(d.isAssigned(n,t)){e=n._values.get(t);break}n=n._parent}if(void 0!==e)return e;throw new Error(`No value set for token '${t.name??t}' in node tree.`)}deleteTokenValue(t){if(d.isAssigned(this,t)){const e=d.getLocalTokenValue(this,t);let n;this._values.delete(t),this.tearDownDerivedTokenValue(t);try{n=this.getTokenValue(t)}catch(t){n=void 0}d.queueNotification(new h(this,2,t)),e!==n&&this.dispatch(new h(this,2,t)),d.notify()}}dispatch(t){if(this!==t.target){const{token:e}=t,n=d.isAssigned(this,e),r=n&&this._derived.get(e)?.evaluator.dependencies.has(e);if(n&&!r)return;2===t.type&&!n&&d.isDerivedFor(this,e)&&(this.tearDownDerivedTokenValue(e),d.queueNotification(new h(this,2,e))),r&&(t=new h(this,1,e,this._derived.get(e)?.evaluator.value));const{value:i}=t;if(i&&d.isDerivedTokenValue(i)){const n=c.getOrCreate(i).dependencies;let r=!1;for(const t of n)if(d.isAssigned(this,t)){r=!0;break}if(r){const n=this._derived.get(e)?.value,r=this.setupDerivedTokenValue(e,i);if(n!==r.value){const i=new h(this,void 0===n?0:1,e,r.evaluator.value);d.queueNotification(i),t=i}}}}this.collectLocalChangeRecords(t).forEach(t=>{d.queueNotification(t),this.dispatch(t)}),this.notifyChildren(t)}collectLocalChangeRecords(t){const e=new Map;for(const n of d.getOrCreateDependencyGraph(this,t.token))n.value!==n.update().value&&e.set(n.token,new h(this,1,n.token,n.evaluator.value));return e}notifyChildren(...t){if(this.children.length)for(let e=0,n=this.children.length;e<n;e++)for(let n=0;n<t.length;n++)this.children[e].dispatch(t[n])}tearDownDerivedTokenValue(t){if(d.isDerivedFor(this,t)){const e=this._derived.get(t);e.dispose(),this._derived.delete(t),e.evaluator.dependencies.forEach(t=>{d.getOrCreateDependencyGraph(this,t).delete(e)})}}setupDerivedTokenValue(t,e,n=!1){const r=new u(t,c.getOrCreate(e),this,n?{handleChange:()=>{if(r.value!==r.update().value){const t=new h(this,1,r.token,r.evaluator.value);d.queueNotification(t),this.dispatch(t),d.notify()}}}:void 0);return this._derived.set(t,r),r.evaluator.dependencies.forEach(e=>{e!==t&&d.getOrCreateDependencyGraph(this,e).add(r)}),r}}d._notifications=[];var f=n(23429),p=n(81263);class v{setProperty(t,e){f.L.enqueue(()=>this.target.setProperty(t,e))}removeProperty(t){f.L.enqueue(()=>this.target.removeProperty(t))}}class g extends v{constructor(){super();const t=new CSSStyleSheet;this.target=t.cssRules[t.insertRule(":root{}")].style,document.adoptedStyleSheets=[...document.adoptedStyleSheets,t]}}class b extends v{constructor(){super(),this.style=document.createElement("style"),document.head.appendChild(this.style);const{sheet:t}=this.style;if(t){const e=t.insertRule(":root{}",t.cssRules.length);this.target=t.cssRules[e].style}}}class m{constructor(t){this.store=new Map,this.target=null;const e=t.$fastController;this.style=document.createElement("style"),e.addStyles(this.style),i.cP.getNotifier(e).subscribe(this,"isConnected"),this.handleChange(e,"isConnected")}targetChanged(){if(null!==this.target)for(const[t,e]of this.store.entries())this.target.setProperty(t,e)}setProperty(t,e){this.store.set(t,e),f.L.enqueue(()=>{null!==this.target&&this.target.setProperty(t,e)})}removeProperty(t){this.store.delete(t),f.L.enqueue(()=>{null!==this.target&&this.target.removeProperty(t)})}handleChange(t,e){const{sheet:n}=this.style;if(n){const t=n.insertRule(":host{}",n.cssRules.length);this.target=n.cssRules[t].style}else this.target=null}}(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Object)],m.prototype,"target",void 0);class y{setProperty(t,e){y.properties[t]=e;for(const n of y.roots.values())n.setProperty(t,e)}removeProperty(t){delete y.properties[t];for(const e of y.roots.values())e.removeProperty(t)}static registerRoot(t){const{roots:e}=y;if(!e.has(t)){e.add(t);for(const e in y.properties)t.setProperty(e,y.properties[e])}}static unregisterRoot(t){const{roots:e}=y;if(e.has(t)){e.delete(t);for(const e in y.properties)t.removeProperty(e)}}}y.roots=new Set,y.properties={};const w=new WeakMap,$=p.v.supportsAdoptedStyleSheets?class extends v{constructor(t){super();const e=new CSSStyleSheet;this.target=e.cssRules[e.insertRule(":host{}")].style,t.$fastController.addStyles(new p.v([e]))}}:m,x=Object.freeze({getOrCreate(t){if(w.has(t))return w.get(t);let e;return e=t instanceof Document?p.v.supportsAdoptedStyleSheets?new g:new b:new $(t),w.set(t,e),e}});class k{constructor(t){this.subscriberNotifier={handleChange:(t,e)=>{const n={target:e.target===M.defaultNode||Reflect.get(e.target,E)===E?"default":e.target.target,token:this};this.subscribers.notify(n)}},this.name=t.name,i.cP.getNotifier(this).subscribe(this.subscriberNotifier)}get $value(){return this.default}get default(){return M.defaultOverridesNode.getTokenValue(this)}get subscribers(){return this._subscribers||(this._subscribers=new s.l(this)),this._subscribers}static isCSSDesignTokenConfiguration(t){return"string"==typeof t.cssCustomPropertyName}static create(t,e){let n;return n="string"==typeof t?new C({name:t,cssCustomPropertyName:t}):k.isCSSDesignTokenConfiguration(t)?new C(t):new k(t),void 0!==e&&M.defaultNode.setTokenValue(n,e),n}static withStrategy(t){M.withStrategy(t)}static registerDefaultStyleTarget(t=document){(t instanceof o.L||t instanceof Document)&&(t=x.getOrCreate(t)),y.registerRoot(t)}static unregisterDefaultStyleTarget(t=document){(t instanceof o.L||t instanceof Document)&&(t=x.getOrCreate(t)),y.unregisterRoot(t)}static clear(){M.clear()}getValueFor(t){return M.getOrCreate(t).getTokenValue(this)}setValueFor(t,e){M.getOrCreate(t).setTokenValue(this,this.normalizeValue(e))}deleteValueFor(t){return M.getOrCreate(t).deleteTokenValue(this),this}withDefault(t){return t=this.normalizeValue(t),d.isAssigned(M.defaultNode,this)||M.defaultNode.setTokenValue(this,t),M.defaultOverridesNode.setTokenValue(this,t),this}subscribe(t){this.subscribers.subscribe(t)}unsubscribe(t){this.subscribers.unsubscribe(t)}alias(t){return e=>e(t)}normalizeValue(t){return t instanceof k&&(t=this.alias(t)),t}}let C=class extends k{constructor(t){super(t),this.cssReflector={handleChange:(t,e)=>{const n=e.target===M.defaultNode||Reflect.get(e.target,E)===E?M.rootStyleSheetTarget:e.target instanceof M?x.getOrCreate(e.target.target):null;n&&(2===e.type?n.removeProperty(this.cssCustomProperty):n.setProperty(this.cssCustomProperty,this.resolveCSSValue(e.target.getTokenValue(this))))}},this.cssCustomProperty=`--${t.cssCustomPropertyName}`,this.cssVar=`var(${this.cssCustomProperty})`,i.cP.getNotifier(this).subscribe(this.cssReflector)}createCSS(){return this.cssVar}resolveCSSValue(t){return t&&"function"==typeof t.createCSS?t.createCSS():t}};C=(0,r.Cg)([(0,a.t)(),(0,r.Sn)("design:paramtypes",[Object])],C);const S={contains:l.Wu,parent(t){let e=(0,l.Zo)(t);for(;null!==e;){if(e instanceof o.L)return e;e=(0,l.Zo)(e)}return null}},E=Symbol();class M extends d{constructor(t){super(),this.target=t,this.setTokenValue=this.lazyAttachToDefault(super.setTokenValue),this.getTokenValue=this.lazyAttachToDefault(this.getTokenValue),this.deleteTokenValue=this.lazyAttachToDefault(super.deleteTokenValue)}static get strategy(){return void 0===this._strategy&&M.withStrategy(S),this._strategy}static get defaultOverridesNode(){let t=M.overridesNodes.get(document);return t||(t=new d,M.overridesNodes.set(document,t),M.defaultNode.appendChild(t),Reflect.defineProperty(t,E,{value:E,enumerable:!1,configurable:!1}),t)}static clear(){!function t(e){for(const n of e.children)t(n);e.dispose()}(M.defaultOverridesNode),M.overridesNodes.delete(document)}connectedCallback(t){let e=M.findParent(t.source);if(null===e&&(e=M.defaultOverridesNode),e!==this.parent){const n=[];for(const r of e.children)r instanceof M&&M.strategy.contains(t.source,r.target)&&n.push(r);e.appendChild(this);for(const t of n)this.appendChild(t)}}disconnectedCallback(t){this.dispose()}static getOrCreate(t){let e=M.cache.get(t);return e||(e=new M(t),M.cache.set(t,e),t.$fastController.addBehavior(M.strategy),t.$fastController.addBehavior(e),e)}static withStrategy(t){this._strategy=t}static findParent(t){let e=M.strategy.parent(t);for(;null!==e;){const t=M.cache.get(e);if(t)return t;e=M.strategy.parent(e)}return null}lazyAttachToDefault(t){return(...e)=>(null===this.parent&&M.defaultOverridesNode.appendChild(this),t.apply(this,e))}getTokenValue(t){try{return super.getTokenValue(t)}catch(t){const e=(t?.message??"Unknown error")+`Target node: ${this.target?.tagName}.  IsFastConnected: ${this.target?.$fastController?.isConnected}. IsConnected: ${this.target?.isConnected}`;throw new Error(e)}}}M.overridesNodes=new WeakMap,M.defaultNode=new d,M.rootStyleSheetTarget=new y,M.cache=new WeakMap},46203(t,e,n){"use strict";n.d(e,{RS(){return d},jM(){return h},le(){return u}});var r=n(45755),i=n(68009),s=n(95239),o=n(17252),a=n(31023);const{create:l}=r.G,c=l({name:"neutral-fill-input-recipe"},{evaluate(t,e){return function(t,e,n,r,s,o){const a=(0,i.F)(e),l=t.closestIndexOf(e);return{rest:t.get(l-a*n),hover:t.get(l-a*r),active:t.get(l-a*s),focus:t.get(l-a*o)}}(t(a.r),e||t(s.p),t(o.DZ),t(o.nK),t(o.xK),t(o.dc))}}),u=l("neutral-fill-input-rest",t=>t(c).evaluate(t).rest),h=l("neutral-fill-input-hover",t=>t(c).evaluate(t).hover),d=l("neutral-fill-input-active",t=>t(c).evaluate(t).active);l("neutral-fill-input-focus",t=>t(c).evaluate(t).focus)},46543(t,e,n){"use strict";n.d(e,{hX(){return a},wN(){return l}});var r=n(14777),i="00000000000000000000000000000000",s="0000000000000000";function o(t,e,n){return!(!t||t[r.oI]!==e||t===n)&&!!t.match(/^[\da-f]*$/)}function a(t){return o(t,32,i)}function l(t){return o(t,16,s)}},47429(t,e,n){"use strict";n.d(e,{Wu(){return a},Zo(){return o},ss(){return l},yF(){return c}});var r=n(42277),i=n(60815),s=n(35727);function o(t){const e=t.parentElement;if(e)return e;{const e=t.getRootNode();if(e.host instanceof HTMLElement)return e.host}return null}function a(t,e){let n=e;for(;null!==n;){if(n===t)return!0;n=o(n)}return!1}class l extends MutationObserver{constructor(t){super(function(t){this.callback.call(null,t.filter(t=>this.observedNodes.has(t.target)))}),this.callback=t,this.observedNodes=new Set}observe(t,e){this.observedNodes.add(t),super.observe(t,e)}unobserve(t){this.observedNodes.delete(t),this.observedNodes.size<1&&this.disconnect()}}const c=Object.freeze({create(t){const e=[],n={};let o=null,a=!1;return{source:t,context:i.ao.default,targets:n,get isBound(){return a},addBehaviorFactory(t,e){var n,i,o,a;const l=t;l.id=null!==(n=l.id)&&void 0!==n?n:(0,s.Hn)(),l.targetNodeId=null!==(i=l.targetNodeId)&&void 0!==i?i:(0,s.Hn)(),l.targetTagName=null!==(o=e.tagName)&&void 0!==o?o:null,l.policy=null!==(a=l.policy)&&void 0!==a?a:r.d.policy,this.addTarget(l.targetNodeId,e),this.addBehavior(l.createBehavior())},addTarget(t,e){n[t]=e},addBehavior(t){e.push(t),a&&t.bind(this)},onUnbind(t){null===o&&(o=[]),o.push(t)},connectedCallback(t){a||(a=!0,e.forEach(t=>t.bind(this)))},disconnectedCallback(t){a&&(a=!1,null!==o&&o.forEach(t=>t.unbind(this)))}}}})},47691(t,e,n){"use strict";n.d(e,{E(){return s}});var r=n(45755);const{create:i}=r.G,s=i("neutral-fill-layer-rest-delta",3)},48196(t,e,n){"use strict";n.d(e,{D(){return s}});var r=n(74849),i=n(74838);const s=r.A.partial`(${i.Ss} + ${i.Br}) * ${i.vR}`},48751(t,e,n){"use strict";n.d(e,{l(){return l}});var r=n(45755),i=n(95239),s=n(31023);const{create:o}=r.G,a=o({name:"neutral-foreground-recipe"},{evaluate(t){return e=t(s.r),n=t(i.p),e.colorContrast(n,14);var e,n}}),l=o("neutral-foreground-rest",t=>t(a).evaluate(t))},49399(t,e,n){"use strict";n.d(e,{H(){return i}});const r=(-.1+Math.sqrt(.21))/2;function i(t){return t.relativeLuminance<=r}},50090(t,e,n){"use strict";n.d(e,{AQ(){return a},mS(){return s},zk(){return o}});var r=n(15454),i=null;function s(t){void 0===t&&(t=!0);var e=!1===t?null:i;return e||(typeof globalThis!==r.bA&&(e=globalThis),e||typeof self===r.bA||(e=self),e||typeof window===r.bA||(e=window),e||typeof n.g===r.bA||(e=n.g),i=e),e}function o(t){throw new TypeError(t)}function a(t){var e=r.OR;if(e)return e(t);if(null==t)return{};var n=typeof t;function i(){}return n!==r._1&&n!==r.hW&&o("Object prototype may only be an Object:"+t),i[r.vR]=t,new i}},50180(t,e,n){"use strict";n.d(e,{GP(){return s},NF(){return i},oT(){return o}});let r=0;function i(t=""){return`${t}${r++}`}function s(t,...e){return t.replace(/{(\d+)}/g,function(t,n){if(n>=e.length)return t;const r=e[n];return"number"==typeof r||r?r:""})}function o(t){return!t||!t.trim()}},50214(t,e,n){"use strict";function r(t,e){if("undefined"==typeof window||!window.document||window.isRenderServiceEnv)return t;const n=window.trustedTypes;if(!n||!n.createPolicy)return t;const r=window.trustedTypePolicies||(window.trustedTypePolicies={});if(r[e])return r[e].createHTML(t);const i=window.trustedTypes.createPolicy(e,{createHTML(t){return t}});return r[e]=i,i.createHTML(t)}n.d(e,{v(){return r}})},50882(t,e,n){"use strict";var r;n.d(e,{A(){return r}}),function(t){t.Canvas="Canvas",t.CanvasText="CanvasText",t.LinkText="LinkText",t.VisitedText="VisitedText",t.ActiveText="ActiveText",t.ButtonFace="ButtonFace",t.ButtonText="ButtonText",t.Field="Field",t.FieldText="FieldText",t.Highlight="Highlight",t.HighlightText="HighlightText",t.GrayText="GrayText"}(r||(r={}))},53697(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M4.09 4.22l.06-.07a.5.5 0 01.63-.06l.07.06L10 9.29l5.15-5.14a.5.5 0 01.63-.06l.07.06c.18.17.2.44.06.63l-.06.07L10.71 10l5.14 5.15c.18.17.2.44.06.63l-.06.07a.5.5 0 01-.63.06l-.07-.06L10 10.71l-5.15 5.14a.5.5 0 01-.63.06l-.07-.06a.5.5 0 01-.06-.63l.06-.07L9.29 10 4.15 4.85a.5.5 0 01-.06-.63l.06-.07-.06.07z"></path></svg>'},53894(t,e,n){"use strict";n.d(e,{$(){return c},M(){return u}});var r,i=n(14777),s=n(88383),o=["eventsSent","eventsDiscarded","eventsSendRequest","perfEvent"],a=null;function l(t,e){return function(){var n=arguments,r=c(e);if(r){var s=r.listener;s&&s[t]&&s[t][i.y9](s,n)}}}function c(t){var e,n=a;return n||!0===t.disableDbgExt||(n=a||((e=(0,s.EH)("Microsoft"))&&(a=e.ApplicationInsights),a)),n?n.ChromeDbgExt:null}function u(t){if(!r){r={};for(var e=0;e<o[i.oI];e++)r[o[e]]=l(o[e],t)}return r}},54130(t,e,n){"use strict";n.d(e,{b(){return i}});var r=n(37820);class i{constructor(t,e,n){this.l=t,this.c=e,this.h=n}static fromObject(t){return!t||isNaN(t.l)||isNaN(t.c)||isNaN(t.h)?null:new i(t.l,t.c,t.h)}equalValue(t){return this.l===t.l&&this.c===t.c&&this.h===t.h}roundToPrecision(t){return new i((0,r.l)(this.l,t),(0,r.l)(this.c,t),(0,r.l)(this.h,t))}toObject(){return{l:this.l,c:this.c,h:this.h}}}},54546(t){t.exports='<svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12.01 2.25c.74 0 1.47.1 2.18.25.32.07.55.33.59.65l.17 1.53a1.38 1.38 0 001.92 1.11l1.4-.61c.3-.13.64-.06.85.17a9.8 9.8 0 012.2 3.8c.1.3 0 .63-.26.82l-1.24.92a1.38 1.38 0 000 2.22l1.24.92c.26.19.36.52.27.82a9.8 9.8 0 01-2.2 3.8.75.75 0 01-.85.17l-1.4-.62a1.38 1.38 0 00-1.93 1.12l-.17 1.52a.75.75 0 01-.58.65 9.52 9.52 0 01-4.4 0 .75.75 0 01-.57-.65l-.17-1.52a1.38 1.38 0 00-1.93-1.11l-1.4.62a.75.75 0 01-.85-.18 9.8 9.8 0 01-2.2-3.8c-.1-.3 0-.63.27-.82l1.24-.92a1.38 1.38 0 000-2.22l-1.24-.92a.75.75 0 01-.28-.82 9.8 9.8 0 012.2-3.8c.23-.23.57-.3.86-.17l1.4.62c.4.17.86.15 1.25-.08.38-.22.63-.6.68-1.04l.17-1.53a.75.75 0 01.58-.65c.72-.16 1.45-.24 2.2-.25zm0 1.5c-.45 0-.9.04-1.35.12l-.11.97a2.89 2.89 0 01-4.02 2.33l-.9-.4A8.3 8.3 0 004.28 9.1l.8.59a2.88 2.88 0 010 4.64l-.8.59a8.3 8.3 0 001.35 2.32l.9-.4a2.88 2.88 0 014.02 2.32l.1.99c.9.15 1.8.15 2.7 0l.1-.99a2.88 2.88 0 014.02-2.32l.9.4a8.3 8.3 0 001.36-2.32l-.8-.59a2.88 2.88 0 010-4.64l.8-.59a8.3 8.3 0 00-1.35-2.32l-.9.4a2.88 2.88 0 01-4.02-2.32l-.11-.98c-.45-.08-.9-.11-1.34-.12zM12 8.25a3.75 3.75 0 110 7.5 3.75 3.75 0 010-7.5zm0 1.5a2.25 2.25 0 100 4.5 2.25 2.25 0 000-4.5z"></path></svg>'},55153(t,e,n){"use strict";n.d(e,{QG(){return a},Sn(){return l},cu(){return c},l8(){return o}});var r=n(45755),i=n(97004),s=n(356);const o=r.G.create("card-base-height",146),a=r.G.create("card-base-width",300),l=r.G.create("card-base-gap",14),c=r.G.create("card-stroke-color",t=>t(s.l)===i.y.DarkMode?"rgba(0,0,0,0.1)":"rgba(0,0,0,0.0578)")},55230(t,e,n){"use strict";n.d(e,{Ac(){return d},F9(){return u},FM(){return l},HX(){return i},I5(){return a},Is(){return b},J9(){return g},Mm(){return c},bb(){return o},f_(){return f},gG(){return v},kE(){return h},kT(){return s},lS(){return r},oK(){return p}});const r="Control",i="ArrowDown",s="ArrowLeft",o="ArrowRight",a="ArrowUp",l="End",c="Enter",u="Escape",h="Home",d="F2",f="PageDown",p="PageUp",v=" ",g="Tab",b={ArrowDown:i,ArrowLeft:s,ArrowRight:o,ArrowUp:a}},55609(t,e,n){"use strict";var r;n.d(e,{OB(){return c},Ay(){return u},cX(){return a}}),function(t){t.ltr="ltr",t.rtl="rtl"}(r||(r={}));var i=n(9790),s=n(22870);const o={steps:94,clipLight:0,clipDark:0},a=(Object.assign({},o),Object.assign(Object.assign({},o),{baseColor:(0,s.Hs)("#0078D4")}),{light:100,semilight:200,normal:400,semibold:600,bold:700}),l={backgroundColor:"#FFFFFF",contrast:0,density:0,designUnit:4,baseHeightMultiplier:8,baseHorizontalSpacingMultiplier:3,direction:r.ltr,cornerRadius:2,elevatedCornerRadius:4,focusOutlineWidth:2,fontWeight:a,disabledOpacity:.3,outlineWidth:1,neutralPalette:["#FFFFFF","#FCFCFC","#FAFAFA","#F7F7F7","#F5F5F5","#F2F2F2","#EFEFEF","#EDEDED","#EAEAEA","#E8E8E8","#E5E5E5","#E2E2E2","#E0E0E0","#DDDDDD","#DBDBDB","#D8D8D8","#D6D6D6","#D3D3D3","#D0D0D0","#CECECE","#CBCBCB","#C9C9C9","#C6C6C6","#C3C3C3","#C1C1C1","#BEBEBE","#BCBCBC","#B9B9B9","#B6B6B6","#B4B4B4","#B1B1B1","#AFAFAF","#ACACAC","#A9A9A9","#A7A7A7","#A4A4A4","#A2A2A2","#9F9F9F","#9D9D9D","#9A9A9A","#979797","#959595","#929292","#909090","#8D8D8D","#8A8A8A","#888888","#858585","#838383","#808080","#7D7D7D","#7B7B7B","#787878","#767676","#737373","#717171","#6E6E6E","#6B6B6B","#696969","#666666","#646464","#616161","#5F5F5F","#5C5C5C","#5A5A5A","#575757","#545454","#525252","#4F4F4F","#4D4D4D","#4A4A4A","#484848","#454545","#424242","#404040","#3D3D3D","#3B3B3B","#383838","#363636","#333333","#313131","#2E2E2E","#2B2B2B","#292929","#262626","#242424","#212121","#1E1E1E","#1B1B1B","#181818","#151515","#121212","#101010","#000000"],accentPalette:["#FFFFFF","#FBFDFE","#F6FAFE","#F2F8FD","#EEF6FC","#E9F4FB","#E5F1FB","#E1EFFA","#DCEDF9","#D8EAF8","#D4E8F8","#CFE6F7","#CBE4F6","#C7E1F6","#C2DFF5","#BEDDF4","#BADAF3","#B6D8F3","#B1D6F2","#ADD4F1","#A9D1F0","#A4CFF0","#A0CDEF","#9CCAEE","#97C8EE","#93C6ED","#8FC4EC","#8AC1EB","#86BFEB","#82BDEA","#7DBAE9","#79B8E8","#75B6E8","#70B3E7","#6CB1E6","#68AFE5","#63ADE5","#5FAAE4","#5BA8E3","#56A6E3","#52A3E2","#4EA1E1","#499FE0","#459DE0","#419ADF","#3D98DE","#3896DD","#3493DD","#3091DC","#2B8FDB","#278DDB","#238ADA","#1E88D9","#1A86D8","#1683D8","#1181D7","#0D7FD6","#097DD5","#047AD5","#0078D4","#0075CF","#0072C9","#006FC4","#006CBE","#0069B9","#0066B4","#0063AE","#0060A9","#005CA3","#00599E","#005699","#005393","#00508E","#004D88","#004A83","#00477D","#004478","#004173","#003E6D","#003B68","#003862","#00355D","#003258","#002F52","#002B4D","#002847","#002542","#00223C","#001F36","#001B30","#00182B","#001525","#00121F","#000000"],accentBaseColor:"#0078D4",accentFillRestDelta:0,accentFillHoverDelta:4,accentFillActiveDelta:-5,accentFillFocusDelta:0,accentFillSelectedDelta:12,accentForegroundRestDelta:0,accentForegroundHoverDelta:6,accentForegroundActiveDelta:-4,accentForegroundFocusDelta:0,neutralFillRestDelta:7,neutralFillHoverDelta:10,neutralFillActiveDelta:5,neutralFillFocusDelta:0,neutralFillSelectedDelta:7,neutralFillInputRestDelta:0,neutralFillInputHoverDelta:0,neutralFillInputActiveDelta:0,neutralFillInputFocusDelta:0,neutralFillInputSelectedDelta:0,neutralFillStealthRestDelta:0,neutralFillStealthHoverDelta:5,neutralFillStealthActiveDelta:3,neutralFillStealthFocusDelta:0,neutralFillStealthSelectedDelta:7,neutralFillToggleHoverDelta:8,neutralFillToggleActiveDelta:-5,neutralFillToggleFocusDelta:0,baseLayerLuminance:-1,neutralFillCardDelta:3,neutralForegroundDarkIndex:93,neutralForegroundLightIndex:0,neutralForegroundHoverDelta:0,neutralForegroundActiveDelta:0,neutralForegroundFocusDelta:0,neutralDividerRestDelta:8,neutralOutlineRestDelta:25,neutralOutlineHoverDelta:40,neutralOutlineActiveDelta:16,neutralOutlineFocusDelta:25};function c(t,e){return(0,i.A)(t)?t(e):t}var u=l},56063(t,e,n){"use strict";n.d(e,{b(){return b}});var r=n(56911),i=n(38493),s=n(60815),o=n(29025),a=n(35106),l=n(88458),c=n(92011),u=n(56863);class h extends c.L{}class d extends((0,u.rf)(h)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}const f="submit",p="reset";class v extends d{constructor(){super(...arguments),this.handleSubmission=()=>{if(!this.form)return;const t=this.proxy.isConnected;t||this.attachProxy(),"function"==typeof this.form.requestSubmit?this.form.requestSubmit(this.proxy):this.proxy.click(),t||this.detachProxy()},this.handleFormReset=()=>{this.form?.reset()},this.handleUnsupportedDelegatesFocus=()=>{window.ShadowRoot&&!window.ShadowRoot.prototype.hasOwnProperty("delegatesFocus")&&this.$fastController.definition.shadowOptions?.delegatesFocus&&(this.focus=()=>{this.control.focus()})}}formactionChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formAction=this.formaction)}formenctypeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formEnctype=this.formenctype)}formmethodChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formMethod=this.formmethod)}formnovalidateChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formNoValidate=this.formnovalidate)}formtargetChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.formTarget=this.formtarget)}typeChanged(t,e){this.proxy instanceof HTMLInputElement&&(this.proxy.type=this.type),e===f&&this.addEventListener("click",this.handleSubmission),t===f&&this.removeEventListener("click",this.handleSubmission),e===p&&this.addEventListener("click",this.handleFormReset),t===p&&this.removeEventListener("click",this.handleFormReset)}validate(){super.validate(this.control)}connectedCallback(){super.connectedCallback(),this.proxy.setAttribute("type",this.type),this.handleUnsupportedDelegatesFocus()}}(0,r.Cg)([(0,i.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],v.prototype,"autofocus",void 0),(0,r.Cg)([(0,i.CF)({attribute:"form"}),(0,r.Sn)("design:type",String)],v.prototype,"formId",void 0),(0,r.Cg)([i.CF,(0,r.Sn)("design:type",String)],v.prototype,"formaction",void 0),(0,r.Cg)([i.CF,(0,r.Sn)("design:type",String)],v.prototype,"formenctype",void 0),(0,r.Cg)([i.CF,(0,r.Sn)("design:type",String)],v.prototype,"formmethod",void 0),(0,r.Cg)([(0,i.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],v.prototype,"formnovalidate",void 0),(0,r.Cg)([i.CF,(0,r.Sn)("design:type",String)],v.prototype,"formtarget",void 0),(0,r.Cg)([i.CF,(0,r.Sn)("design:type",String)],v.prototype,"type",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Array)],v.prototype,"defaultSlottedContent",void 0);class g{}(0,r.Cg)([(0,i.CF)({attribute:"aria-expanded"}),(0,r.Sn)("design:type",Object)],g.prototype,"ariaExpanded",void 0),(0,r.Cg)([(0,i.CF)({attribute:"aria-pressed"}),(0,r.Sn)("design:type",Object)],g.prototype,"ariaPressed",void 0),(0,l.X)(g,o.z),(0,l.X)(v,a.qw,g);class b extends v{constructor(){super(...arguments),this.iconOnly=!1}appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="neutral")}defaultSlottedContentChanged(){const t=this.defaultSlottedContent.filter(t=>t.nodeType===Node.ELEMENT_NODE);1===t.length&&t[0]instanceof SVGElement?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,r.Cg)([i.CF,(0,r.Sn)("design:type",String)],b.prototype,"appearance",void 0),(0,r.Cg)([(0,i.CF)({attribute:"icon-only",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],b.prototype,"iconOnly",void 0)},56863(t,e,n){"use strict";n.d(e,{dx(){return f},rf(){return d}});var r=n(19470),i=n(60815),s=n(23429),o=n(38493),a=n(55230);const l="form-associated-proxy",c="ElementInternals",u=c in window&&"setFormValue"in window[c].prototype,h=new WeakMap;function d(t){const e=class extends t{constructor(...t){super(...t),this.dirtyValue=!1,this.disabled=!1,this.proxyEventsToBlock=["change","click"],this.proxyInitialized=!1,this.required=!1,this.initialValue=this.initialValue||"",this.elementInternals||(this.formResetCallback=this.formResetCallback.bind(this))}static get formAssociated(){return u}get validity(){return this.elementInternals?this.elementInternals.validity:this.proxy.validity}get form(){return this.elementInternals?this.elementInternals.form:this.proxy.form}get validationMessage(){return this.elementInternals?this.elementInternals.validationMessage:this.proxy.validationMessage}get willValidate(){return this.elementInternals?this.elementInternals.willValidate:this.proxy.willValidate}get labels(){if(this.elementInternals)return Object.freeze(Array.from(this.elementInternals.labels));if(this.proxy instanceof HTMLElement&&this.proxy.ownerDocument&&this.id){const t=this.proxy.labels,e=Array.from(this.proxy.getRootNode().querySelectorAll(`[for='${this.id}']`)),n=t?e.concat(Array.from(t)):e;return Object.freeze(n)}return r.tR}valueChanged(t,e){this.dirtyValue=!0,this.proxy instanceof HTMLElement&&(this.proxy.value=this.value),this.currentValue=this.value,this.setFormValue(this.value),this.validate()}currentValueChanged(){this.value=this.currentValue}initialValueChanged(t,e){this.dirtyValue||(this.value=this.initialValue,this.dirtyValue=!1)}disabledChanged(t,e){this.proxy instanceof HTMLElement&&(this.proxy.disabled=this.disabled),s.L.enqueue(()=>this.classList.toggle("disabled",this.disabled))}nameChanged(t,e){this.proxy instanceof HTMLElement&&(this.proxy.name=this.name)}requiredChanged(t,e){this.proxy instanceof HTMLElement&&(this.proxy.required=this.required),s.L.enqueue(()=>this.classList.toggle("required",this.required)),this.validate()}get elementInternals(){if(!u)return null;let t=h.get(this);return t||(t=this.attachInternals(),h.set(this,t)),t}connectedCallback(){super.connectedCallback(),this.addEventListener("keypress",this._keypressHandler),this.value||(this.value=this.initialValue,this.dirtyValue=!1),this.elementInternals||(this.attachProxy(),this.form&&this.form.addEventListener("reset",this.formResetCallback))}disconnectedCallback(){super.disconnectedCallback(),this.proxyEventsToBlock.forEach(t=>this.proxy.removeEventListener(t,this.stopPropagation)),!this.elementInternals&&this.form&&this.form.removeEventListener("reset",this.formResetCallback)}checkValidity(){return this.elementInternals?this.elementInternals.checkValidity():this.proxy.checkValidity()}reportValidity(){return this.elementInternals?this.elementInternals.reportValidity():this.proxy.reportValidity()}setValidity(t,e,n){this.elementInternals?this.elementInternals.setValidity(t,e,n):"string"==typeof e&&this.proxy.setCustomValidity(e)}formDisabledCallback(t){this.disabled=t}formResetCallback(){this.value=this.initialValue,this.dirtyValue=!1}attachProxy(){this.proxyInitialized||(this.proxyInitialized=!0,this.proxy.style.display="none",this.proxyEventsToBlock.forEach(t=>this.proxy.addEventListener(t,this.stopPropagation)),this.proxy.disabled=this.disabled,this.proxy.required=this.required,"string"==typeof this.name&&(this.proxy.name=this.name),"string"==typeof this.value&&(this.proxy.value=this.value),this.proxy.setAttribute("slot",l),this.proxySlot=document.createElement("slot"),this.proxySlot.setAttribute("name",l)),this.shadowRoot?.appendChild(this.proxySlot),this.appendChild(this.proxy)}detachProxy(){this.removeChild(this.proxy),this.shadowRoot?.removeChild(this.proxySlot)}validate(t){this.proxy instanceof HTMLElement&&this.setValidity(this.proxy.validity,this.proxy.validationMessage,t)}setFormValue(t,e){this.elementInternals&&this.elementInternals.setFormValue(t,e||t)}_keypressHandler(t){if(t.key===a.Mm)if(this.form instanceof HTMLFormElement){const t=this.form.querySelector("[type=submit]");t?.click()}}stopPropagation(t){t.stopPropagation()}};return(0,o.CF)({mode:"boolean"})(e.prototype,"disabled"),(0,o.CF)({mode:"fromView",attribute:"value"})(e.prototype,"initialValue"),(0,o.CF)({attribute:"current-value"})(e.prototype,"currentValue"),(0,o.CF)(e.prototype,"name"),(0,o.CF)({mode:"boolean"})(e.prototype,"required"),(0,i.sH)(e.prototype,"value"),e}function f(t){class e extends(d(t)){}class n extends e{constructor(...t){super(t),this.dirtyChecked=!1,this.checkedAttribute=!1,this.checked=!1,this.dirtyChecked=!1}checkedAttributeChanged(){this.defaultChecked=this.checkedAttribute}defaultCheckedChanged(){this.dirtyChecked||(this.checked=this.defaultChecked,this.dirtyChecked=!1)}checkedChanged(t,e){this.dirtyChecked||(this.dirtyChecked=!0),this.currentChecked=this.checked,this.updateForm(),this.proxy instanceof HTMLInputElement&&(this.proxy.checked=this.checked),void 0!==t&&this.$emit("change"),this.validate()}currentCheckedChanged(t,e){this.checked=this.currentChecked}updateForm(){const t=this.checked?this.value:null;this.setFormValue(t,t)}connectedCallback(){super.connectedCallback(),this.updateForm()}formResetCallback(){super.formResetCallback(),this.checked=!!this.checkedAttribute,this.dirtyChecked=!1}}return(0,o.CF)({attribute:"checked",mode:"boolean"})(n.prototype,"checkedAttribute"),(0,o.CF)({attribute:"current-checked",converter:o.Bs})(n.prototype,"currentChecked"),(0,i.sH)(n.prototype,"defaultChecked"),(0,i.sH)(n.prototype,"checked"),n}},57065(t,e,n){"use strict";n.d(e,{i(){return r}});const r={normal:4.5,large:7}},57209(){var t;!function(t){var e=function(){function t(){}return t.getGlobal=function(){return"undefined"!=typeof globalThis&&globalThis?globalThis:"undefined"!=typeof self&&self?self:"undefined"!=typeof window&&window?window:null},t.hasWindow=function(){return Boolean("object"==typeof window&&window)},t.getGlobalInst=function(t){if("window"===t&&this.hasWindow())return window;var e=this.getGlobal();return e&&e[t]?e[t]:null},t}();t.getGlobalWindow=e}(t||(t={})),function(t){var e=function(){function t(){}return t.trackerConfig={useTelemetryService:!1,selectorMethod:".",directFunctionCall:!0,impressionIdParamName:"",publisherName:"msnperegrine"},t}();t.Config=e}(t||(t={})),t||(t={}),function(t){var e=function(){this.element=null,this.trackBeacons=[]};t.VideoTrackEvents=e}(t||(t={})),function(t){var e=function(){function t(){}return t.appinsights={stagingConnectionString:"9b1500b8-3f89-4126-8af8-cd9020439a04",prodConnectionString:"922c1827-2168-46e4-b953-34fef5deff39"},t.msn={videoViewIdMacro:"VIDEO_VIEW_ID"},t}();t.Constants=e}(t||(t={})),function(t){t._window=t.getGlobalWindow.getGlobalInst("window");var e=function(){function e(){}return e.isDebug=function(t){return"true"===this.getQueryParam("na-debug",t.location.search)},e.getRid=function(e){if(t.config.publisherName.indexOf("msn")>=0)for(var n=0;n<e.beacons.length;n++){if(0==e.beacons[n].url.indexOf("https://srtb.msn.com"))return this.getQueryParam("rid",e.beacons[n].url)}return e.impid},e.replaceQueryParam=function(t,e,n){var r=this.getQueryParam(t,n),i=t.concat("=").concat(r),s=t.concat("=").concat(e);return n&&n.indexOf(i)>=0?n.replace(i,s):n},e.getQueryParam=function(t,e){var n=this.getQueryParams(new RegExp("^"+this.escapeRegExp(t)+"$"),e);return n&&n.length>0?n[0].value:null},e.getQueryParams=function(t,e){return e&&e.indexOf("?")>=0&&(e=e.substring(e.indexOf("?")+1)),this.getKeyValuePairs(t,e,"&")},e.getKeyValuePairs=function(t,e,n){if(!e||!t||!t.test)return[];for(var r=[],i=e.split(n),s=0;s<i.length;s++){var o=i[s],a=o.indexOf("=");if(-1!==a){var l=o.substring(0,a).trim(),c=o.substring(a+1).trim();t.test(l)&&r.push({name:l,value:c})}}return r},e.escapeRegExp=function(t){return t?t.replace(this.regexSpecialCharsRegex,"\\$1"):t},e.consoleLog=function(t,e){this.isDebug(e)&&console.log(t)},e.JSONstringify=function(t){if("function"==typeof JSON.stringify)return JSON.stringify(t)},e.getMetaContentByName=function(e,n){try{n||(n=t._window);for(var r=n.document.getElementsByTagName("meta"),i=0;i<r.length;i++)if(r[i].getAttribute("name")===e)return r[i].getAttribute("content");return""}catch(t){return""}},e.loadScript=function(t,e){var n=document.getElementsByTagName("head")[0],r=document.createElement("script");r.type="text/javascript",r.src=t,r.onload=e,r.onreadystatechange=function(){"complete"===this.readyState&&e()},n.appendChild(r)},e.fireBeacon=function(e){e&&t._window&&t._window.Image&&((new t._window.Image).src=e)},e.addQueryParam=function(t,e,n){return t+=-1==t.indexOf("?")?"?":"&",t+=e+"="+n},e.isIE=function(t){return t.navigator.userAgent.indexOf("MSIE ")>-1},e.getCurrentScriptTag=function(t){if(!t)return null;if((e=t.document.currentScript)&&e.src)return e.src;var e,n=t.document.getElementsByTagName("script");if(n&&n.length>0&&-1!=(e=n[n.length-1]).src.indexOf("nativeads/msantracker"))return e.src;var r="",i=t.document.querySelector("script[src*='nativeads/msantracker']");return i&&(r=i.src),r},e.isMSN=function(t){return t?-1!=t.location.href.indexOf("msn.com"):null},e.isStagingEnv=function(t){if(!t)return null;var e=this.getCurrentScriptTag(t);return!!e&&-1!=e.indexOf("nativeads/staging/")},e.getPublisherName=function(t){return t?this.getQueryParam("publisherName",t):""},e.inIframe=function(){try{return t._window.self!==t._window.top}catch(t){return!0}},e.getTargetWindow=function(){return this.inIframe()?t._window.parent:t._window},e.isDocumentReady=function(t){return!!t&&(!(!t.navigator.userAgent||-1===t.navigator.userAgent.indexOf("Android")||"loaded"!=t.document.readyState)||"complete"==t.document.readyState)},e.getVideoViewId=function(){return this.getGuid().replace(/-/g,"")},e.getGuid=function(){return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(t){var e=16*Math.random()|0;return("x"===t?e:3&e|8).toString(16)})},e.regexSpecialCharsRegex="/([.*+?^=!:${}()|[]/\\])/g",e}();t.utils=e}(t||(t={})),function(t){var e=function(){function e(){}return e.initialize=function(t){},e.logEvent=function(t,e,n){this.logEventForMSN(t,e,n)},e.logEventForMSN=function(e,n,r){if(n&&r){var i=void 0;this.elementsToTrack&&e&&this.elementsToTrack[e]&&(i=this.elementsToTrack[e]),r.publishername=t.config.publisherName;var s=this.targetWindow.btoa(t.utils.JSONstringify(r)).substring(0,1800),o="https://srtb.msn.com/log?r="+i+"&n="+n+"&d="+encodeURIComponent(s);t.utils.fireBeacon(o),r.rid=i,t.utils.consoleLog("TelemetryEvent: "+n+" "+t.utils.JSONstringify(r),this.targetWindow)}},e.setElementToTrack=function(t,e){t&&e&&(this.elementsToTrack[t]=e)},e.logAdView=function(t,e,n){var r={elementId:e,percentage:n.percentage,duration:n.duration,type:n.type,triggerType:n.triggerType,url:n.url};this.logEvent(t,"mt_view",r)},e.logVideoAdPlay=function(t,e,n){var r={elementId:e,percentage:n.percentage,duration:n.duration,type:n.type,triggerType:n.triggerType,url:n.url};this.logEvent(t,"mt_view",r)},e.logAdClick=function(t,e,n){var r={elementId:e,type:n.type,url:n.url};this.logEvent(t,"mt_click",r)},e.targetWindow=t._window,e.elementsToTrack={},e}();t.Telemetry=e}(t||(t={})),function(t){var e=function(){function e(){}return e.trackElement=function(t,n,r,i,s){var o=e.DEFAULT_PERCENTINVIEW,a=e.DEFAULT_DURATIONINVIEW;return i&&(i.percentage&&(o=i.percentage),i.duration&&(a=i.duration)),e.elementsToTrack.push({selector:t,element:n,targetWindow:r,percentInView:o,milliSecondsInView:a,viewBeacon:i,action:s}),null==e.processing&&(e.processing=setInterval(e.process,e.interval)),this},e.process=function(){try{if(e.elementsToTrack.length>0){for(var n=0;n<e.elementsToTrack.length;n++)e.appearedElements.indexOf(n)<0&&e.elementsWaitingForTimeout.indexOf(n)<0&&e.isElementInView(e.elementsToTrack[n])&&(e.elementsWaitingForTimeout.push(n),setTimeout(e.checkAfterTimeout,e.elementsToTrack[n].milliSecondsInView,e.elementsToTrack[n],n));e.elementsToTrack.length===e.appearedElements.length&&e.stopProcessing()}}catch(n){var r=e.elementsToTrack;r.length>0&&r[0]&&r[0].viewBeacon?t.Telemetry.logEvent(r[0].viewBeacon.guid,"mt_err",{msg:n.message,details:r[0].viewBeacon}):t.Telemetry.logEvent("","mt_err",{msg:n.message})}},e.checkAfterTimeout=function(t,n){e.appearedElements.indexOf(n)<0&&e.isElementInView(t)&&(e.appearedElements.push(n),t.action.call(void 0,t.selector,t.viewBeacon,t.targetWindow)),e.elementsWaitingForTimeout.splice(e.elementsWaitingForTimeout.indexOf(n),1)},e.isElementInView=function(n){var r=n.targetWindow,i=r.document;if(!n.element)return!1;var s,o=n.element,a=i.getElementsByTagName("body");a&&(s=a[0]);var l=o.getBoundingClientRect();if(!l)return!1;var c=-1===l.left?0:l.left,u=-1===l.top?0:l.top,h=o.offsetHeight,d=o.offsetWidth,f=i.elementFromPoint(c+d/2,u+h/2);if("msnperegrine"!=t.config.publisherName&&(!f||f&&o!==f&&!o.contains(f)))return!1;var p=r.innerHeight||i.clientWidth||s.clientWidth,v=r.innerWidth||i.clientHeight||s.clientHeight,g=r.pageYOffset,b=g+p,m=u+r.scrollY,y=m+h,w=r.pageXOffset,$=w+v,x=c+r.scrollX,k={pTop:g,pBottom:b,pLeft:w,pRight:$,eTop:m,eBottom:y,eLeft:x,eRight:x+d,eWidth:d,eHeight:h,percentInView:n.percentInView};return e.validateIsElementInView(k)},e.validateIsElementInView=function(t){if(t.eBottom<=t.pTop||t.eTop>=t.pBottom||t.eRight<=t.pLeft||t.eLeft>=t.pRight)return!1;var e=0,n=0,r=0,i=0;t.pTop>t.eTop&&t.pTop<t.eBottom&&(e=t.pTop-t.eTop),t.pBottom<t.eBottom&&t.pBottom>t.eTop&&(r=t.eBottom-t.pBottom),t.pLeft>t.eLeft&&t.pLeft<t.eRight&&(i=t.pLeft-t.eLeft),t.pRight<t.eRight&&t.pRight>t.eLeft&&(n=t.eRight-t.pRight);var s=i+n;return(e+r)*t.eWidth+s*t.eHeight<=t.eHeight*t.eWidth*(100-t.percentInView)/100},e.stopProcessing=function(){clearInterval(e.processing),e.processing=null},e.DEFAULT_PERCENTINVIEW=50,e.DEFAULT_DURATIONINVIEW=1e3,e.elementsToTrack=[],e.appearedElements=[],e.elementsWaitingForTimeout=[],e.processing=null,e.interval=100,e}();t.AppearUtils=e}(t||(t={})),function(t){var e=function(){function e(){}return e.trackElement=function(n,r,i,s,o,a){for(var l=t.utils.getVideoViewId(),c=[],u=0;u<s.length;u++){var h=s[u];if(e.toTrackUrlCounts=e.toTrackUrlCounts+1,"videoView"!=h.type){var d=t.utils.getQueryParam("rlink",h.url),f=decodeURIComponent(d),p=t.utils.replaceQueryParam("vi",l,f),v=encodeURIComponent(p);h.url=t.utils.replaceQueryParam("rlink",v,h.url)}c.push({selector:n,element:r,videoParenentElement:o,videoBeacon:h,action:a,targetWindow:i,percentInView:h.percentage?h.percentage:50})}return e.elementsToTrack.push({element:r,trackBeacons:c}),null==e.processing&&(e.processing=setInterval(e.process,e.interval)),r.onplay=function(){e.refreshBeaconsWhenStart(r,i)},r.onseeking=function(){e.refreshBeaconsWhenStart(r,i)},this},e.untrackElement=function(t){var n=e.getElementBeaconsIndex(e.elementsToTrack,t);n>=0&&e.elementsToTrack.splice(n,1)},e.getElementBeaconsIndex=function(t,e){if(t&&t.length>0)for(var n=0;n<t.length;n++)if(t[n].element==e)return n;return-1},e.refreshBeaconsWhenStart=function(n,r){if(n&&0==n.currentTime){var i=t.utils.getVideoViewId(),s=e.getElementBeaconsIndex(e.elementsToTrack,n);if(s>=0){for(var o=e.elementsToTrack[s].trackBeacons,a=[],l=0;l<o.length;l++){var c=o[l],u=c.videoBeacon;if("videoView"!=u.type){e.trackedBeacons.indexOf(u.url)>=0&&(e.toTrackUrlCounts=e.toTrackUrlCounts+1);var h=t.utils.getQueryParam("rlink",u.url),d=decodeURIComponent(h),f=t.utils.replaceQueryParam("vi",i,d),p=encodeURIComponent(f);u.url=t.utils.replaceQueryParam("rlink",p,u.url)}a.push({selector:c.selector,element:c.element,videoParenentElement:c.videoParenentElement,videoBeacon:u,action:c.action,targetWindow:r,percentInView:c.percentInView?c.percentInView:50})}e.elementsToTrack[s].trackBeacons=a}null==e.processing&&(e.processing=setInterval(e.process,e.interval))}},e.process=function(){try{if(e.elementsToTrack&&e.elementsToTrack.length>0){for(var n=0;n<e.elementsToTrack.length;n++)for(var r=e.elementsToTrack[n].trackBeacons,i=0;i<r.length;i++){var s=r[i];e.trackedBeacons.indexOf(s.videoBeacon.url)<0&&e.trackPlay(s)}e.toTrackUrlCounts===e.trackedBeacons.length&&e.stopProcessing()}}catch(n){var o=e.elementsToTrack;if(o&&o.length>0&&o[0].trackBeacons&&o[0].trackBeacons[0].videoBeacon){var a=o[0].trackBeacons[0].videoBeacon;t.Telemetry.logEvent(a.guid,"mt_err",{msg:n.message,details:a})}else t.Telemetry.logEvent("","mt_err",{msg:n.message})}},e.trackPlay=function(n){var r=n.element,i=n.videoBeacon.duration,s=1e3*r.currentTime,o=n.videoBeacon.type,a={targetWindow:n.targetWindow,element:n.videoParenentElement?n.videoParenentElement:n.element,percentInView:n.percentInView};t.AppearUtils.isElementInView(a)&&e.trackedBeacons.indexOf(n.videoBeacon.url)<0&&("videoView"==o?this.checkPlayedTime(r)>=i&&(n.action.call(void 0,n.selector,n.videoBeacon),e.trackedBeacons.push(n.videoBeacon.url)):(0==i&&s>i||i>0&&this.checkCurrentTime(s,i))&&(n.action.call(void 0,n.selector,n.videoBeacon),e.trackedBeacons.push(n.videoBeacon.url)))},e.checkCurrentTime=function(t,e){return t>=e-50&&t<=e+50},e.checkPlayedTime=function(t){var e=0;if(t.played&&t.played.length>0)for(var n=0;n<t.played.length;n++)e+=t.played.end(n)-t.played.start(n);return 1e3*e},e.stopProcessing=function(){clearInterval(e.processing),e.processing=null},e.elementsToTrack=[],e.trackedBeacons=[],e.processing=null,e.interval=100,e.toTrackUrlCounts=0,e}();t.PlayUtils=e}(t||(t={})),function(t){var e=function(){this.type="view",this.url="",this.guid="",this.triggerType="view",this.percentage=50,this.duration=1e3};t.ViewBeacon=e}(t||(t={})),function(t){var e=function(){this.type="videoView",this.url="",this.guid="",this.triggerType="play",this.percentage=50,this.duration=0};t.VideoBeacon=e}(t||(t={})),function(t){var e=function(){this.impid="",this.rid="",this.beacons=[]};t.TrackableElement=e}(t||(t={})),function(t){function e(e){var r=new t.TrackableElement,i=new URLSearchParams(t.scriptSrc);if(i){var s="";if(i.has("v")){if(s=i.get("v"),i.has("d")){var o=i.get("d");t.Telemetry.logEvent("","mt_info",{msg:"Version",clientVersion:o})}var a=decodeURI(s),l=new URLSearchParams(a),c=t.config.impressionIdParamName;if(l.has(c)&&(r.impid=l.get(c)),""!=r.impid){l.has("rId")&&(r.rid=l.get("rId"));var u=new t.ViewBeacon;u.url=a,r.beacons=[u],n([r],e,!1)}else t.Telemetry.logEvent("","mt_err",{msg:"view_id is empty or null",url:a})}else t.Telemetry.logEvent("","mt_err",{msg:"viewability beacon not present",url:t.scriptSrc})}else t.Telemetry.logEvent("","mt_err",{msg:"invalid script src url for params",url:t.scriptSrc})}function n(e,n,i){void 0===i&&(i=!0),!e&&e&&e.length>0?t.Telemetry.logEvent("","mt_err",{msg:"elements null or empty"}):e.forEach(function(e){var i=t.utils.getGuid();if(e.rid||(e.rid=t.utils.getRid(e)),t.Telemetry.setElementToTrack(i,e.rid),e.beacons&&e.impid){var s=e.impid;"msn"==t.config.publisherName&&(s="bing-"+e.impid);var o=!0;e.element&&(o=!1);var a=t.config.selectorMethod+""+s;if(o){var l=n.document.querySelector(a);l&&(e.element=l)}if(e.element)r(e,a,n,s,i);else{t.Telemetry.logEvent(i,"mt_err",{msg:"No element with id or element, setting an interval to wait",id:s,selector:a});var c=setInterval(function(){var o=n.document.querySelector(a);o&&(t.Telemetry.logEvent(i,"mt_info",{msg:"Found element after retry",element:a}),clearInterval(c),e.element=o,r(e,a,n,s,i))},100)}}else t.Telemetry.logEvent(i,"mt_err",{msg:"Beacon or imp id is empty or null"})})}function r(e,n,r,i,s){var o=e.beacons,a=[];o&&o.length>0&&o.forEach(function(o){t.Telemetry.logEvent(s,"mt_info",{msg:"Beacon Information",id:i,beaconUrl:o.url}),o.guid=s,"play"==o.triggerType?a.push(o):function(e,n,r,i){var s=this;if(e.triggerType&&"view"!==e.triggerType)if("click"===e.type){n.element.addEventListener("click",function(n){t.Telemetry.logAdClick(e.guid,s.id,e),t.utils.fireBeacon(e.url)})}else t.Telemetry.logEvent(e.guid,"mt_err",{msg:"Unsupported tracker event",impid:n.impid});else{var o=e;t.AppearUtils.trackElement(r,n.element,i,o,function(e,n,r){var i=e.split(t.config.selectorMethod)[1];t.Telemetry.logAdView(n.guid,i,n),t.utils.fireBeacon(n.url),console.log("[MSAN view beacon fired] "+n.url)})}}(o,e,n,r)}),a&&a.length>0&&function(e,n,r,i){var s=e;t.PlayUtils.trackElement(r,n.element,i,s,n.videoParenentElement,function(e,n){var r=e.split(t.config.selectorMethod)[1];t.Telemetry.logVideoAdPlay(n.guid,r,n),t.utils.fireBeacon(n.url),console.log("[MSAN video beacon fired] "+n.url)})}(a,e,n,r)}t.config=null,t.isInitialized=!1,t.scriptSrc="",t.Initialize=function(){t.config=t.Config.trackerConfig,t.Telemetry.initialize(t._window),"msnperegrine"!=t.config.publisherName&&t.Telemetry.logEvent("","mt_info",{msg:"MSANTracker JS Inserted"});var n=t.utils.getCurrentScriptTag(t._window);if(n){if(t.scriptSrc=n,!t.isInitialized&&!t.config.directFunctionCall)var r=setInterval(function(){t.utils.isDocumentReady(t._window)&&(t.isInitialized=!0,t.Telemetry.logEvent("","mt_info",{msg:"Document in ready state"}),clearInterval(r),e(t._window))},100)}else"msnperegrine"!=t.config.publisherName&&t.Telemetry.logEvent("","mt_err",{msg:"Cannot find current script src"})},t.ProcessTrackers=e,t.TrackElements=function(e,r,i){if(void 0===i&&(i=!0),t.Telemetry.logEvent("","mt_info",{msg:"MSANTracker function called",directCall:i}),e||t.Telemetry.logEvent("","mt_err",{msg:"elements null or empty"}),!t.isInitialized&&i)var s=setInterval(function(){t.utils.isDocumentReady(r)&&(t.isInitialized=!0,t.Telemetry.logEvent("","mt_info",{msg:"Document in ready state"}),clearInterval(s),n(e,r,i))},100);else i&&n(e,r,i)}}(t||(t={})),t._window&&(t.Initialize(),t._window.MSANTracker=t)},57416(t,e,n){"use strict";n.d(e,{JU(){return o},Pb(){return s}});var r=n(45755);const{create:i}=r.G,s=i("control-corner-radius",4),o=i("layer-corner-radius",4)},57606(t,e,n){"use strict";n.d(e,{p(){return M}});var r,i=n(37820),s=n(87122),o=n(14848),a=n(54130);function l(t,e,n=18){const r=(0,o.Gy)(t);let i=r.c+e*n;return i<0&&(i=0),(0,o.k5)(new a.b(r.l,i,r.h))}function c(t,e){return t*e}function u(t,e){return new s.M(c(t.r,e.r),c(t.g,e.g),c(t.b,e.b),1)}function h(t,e){return t<.5?(0,i.qE)(2*e*t,0,1):(0,i.qE)(1-2*(1-e)*(1-t),0,1)}function d(t,e){return new s.M(h(t.r,e.r),h(t.g,e.g),h(t.b,e.b),1)}!function(t){t[t.Burn=0]="Burn",t[t.Color=1]="Color",t[t.Darken=2]="Darken",t[t.Dodge=3]="Dodge",t[t.Lighten=4]="Lighten",t[t.Multiply=5]="Multiply",t[t.Overlay=6]="Overlay",t[t.Screen=7]="Screen"}(r||(r={}));var f,p=n(40778),v=n(15128),g=n(14338),b=n(27478);function m(t,e,n,r){if(isNaN(t)||t<=0)return n;if(t>=1)return r;switch(e){case f.HSL:return(0,o.QX)(function(t,e,n){return isNaN(t)||t<=0?e:t>=1?n:new p.D((0,i.c5)(t,e.h,n.h),(0,i.Cc)(t,e.s,n.s),(0,i.Cc)(t,e.l,n.l))}(t,(0,o.SU)(n),(0,o.SU)(r)));case f.HSV:return(0,o.Eq)(function(t,e,n){return isNaN(t)||t<=0?e:t>=1?n:new v.D((0,i.c5)(t,e.h,n.h),(0,i.Cc)(t,e.s,n.s),(0,i.Cc)(t,e.v,n.v))}(t,(0,o.Es)(n),(0,o.Es)(r)));case f.XYZ:return(0,o.ym)(function(t,e,n){return isNaN(t)||t<=0?e:t>=1?n:new b.P((0,i.Cc)(t,e.x,n.x),(0,i.Cc)(t,e.y,n.y),(0,i.Cc)(t,e.z,n.z))}(t,(0,o.Mx)(n),(0,o.Mx)(r)));case f.LAB:return(0,o.eK)(function(t,e,n){return isNaN(t)||t<=0?e:t>=1?n:new g.h((0,i.Cc)(t,e.l,n.l),(0,i.Cc)(t,e.a,n.a),(0,i.Cc)(t,e.b,n.b))}(t,(0,o.mi)(n),(0,o.mi)(r)));case f.LCH:return(0,o.k5)(function(t,e,n){return isNaN(t)||t<=0?e:t>=1?n:new a.b((0,i.Cc)(t,e.l,n.l),(0,i.Cc)(t,e.c,n.c),(0,i.c5)(t,e.h,n.h))}(t,(0,o.Gy)(n),(0,o.Gy)(r)));default:return function(t,e,n){return isNaN(t)||t<=0?e:t>=1?n:new s.M((0,i.Cc)(t,e.r,n.r),(0,i.Cc)(t,e.g,n.g),(0,i.Cc)(t,e.b,n.b),(0,i.Cc)(t,e.a,n.a))}(t,n,r)}}!function(t){t[t.RGB=0]="RGB",t[t.HSL=1]="HSL",t[t.HSV=2]="HSV",t[t.XYZ=3]="XYZ",t[t.LAB=4]="LAB",t[t.LCH=5]="LCH"}(f||(f={}));class y{constructor(t){if(null==t||0===t.length)throw new Error("The stops argument must be non-empty");this.stops=this.sortColorScaleStops(t)}static createBalancedColorScale(t){if(null==t||0===t.length)throw new Error("The colors argument must be non-empty");const e=new Array(t.length);for(let n=0;n<t.length;n++)0===n?e[n]={color:t[n],position:0}:n===t.length-1?e[n]={color:t[n],position:1}:e[n]={color:t[n],position:n*(1/(t.length-1))};return new y(e)}getColor(t,e=f.RGB){if(1===this.stops.length)return this.stops[0].color;if(t<=0)return this.stops[0].color;if(t>=1)return this.stops[this.stops.length-1].color;let n=0;for(let e=0;e<this.stops.length;e++)this.stops[e].position<=t&&(n=e);let r=n+1;r>=this.stops.length&&(r=this.stops.length-1);return m((t-this.stops[n].position)*(1/(this.stops[r].position-this.stops[n].position)),e,this.stops[n].color,this.stops[r].color)}trim(t,e,n=f.RGB){if(t<0||e>1||e<t)throw new Error("Invalid bounds");if(t===e)return new y([{color:this.getColor(t,n),position:0}]);const r=[];for(let n=0;n<this.stops.length;n++)this.stops[n].position>=t&&this.stops[n].position<=e&&r.push(this.stops[n]);if(0===r.length)return new y([{color:this.getColor(t),position:t},{color:this.getColor(e),position:e}]);r[0].position!==t&&r.unshift({color:this.getColor(t),position:t}),r[r.length-1].position!==e&&r.push({color:this.getColor(e),position:e});const i=e-t,s=new Array(r.length);for(let e=0;e<r.length;e++)s[e]={color:r[e].color,position:(r[e].position-t)/i};return new y(s)}findNextColor(t,e,n=!1,r=f.RGB,i=.005,s=32){isNaN(t)||t<=0?t=0:t>=1&&(t=1);const a=this.getColor(t,r),l=n?0:1,c=this.getColor(l,r);if((0,o.yN)(a,c)<=e)return l;let u=n?0:t,h=n?t:0,d=l,p=0;for(;p<=s;){d=Math.abs(h-u)/2+u;const t=this.getColor(d,r),s=(0,o.yN)(a,t);if(Math.abs(s-e)<=i)return d;s>e?n?u=d:h=d:n?h=d:u=d,p++}return d}clone(){const t=new Array(this.stops.length);for(let e=0;e<t.length;e++)t[e]={color:this.stops[e].color,position:this.stops[e].position};return new y(t)}sortColorScaleStops(t){return t.sort((t,e)=>{const n=t.position,r=e.position;return n<r?-1:n>r?1:0})}}var w=n(22870);class ${constructor(t){this.config=Object.assign({},$.defaultPaletteConfig,t),this.palette=[],this.updatePaletteColors()}updatePaletteGenerationValues(t){let e=!1;for(const n in t)this.config[n]&&(this.config[n].equalValue?this.config[n].equalValue(t[n])||(this.config[n]=t[n],e=!0):t[n]!==this.config[n]&&(this.config[n]=t[n],e=!0));return e&&this.updatePaletteColors(),e}updatePaletteColors(){const t=this.generatePaletteColorScale();for(let e=0;e<this.config.steps;e++)this.palette[e]=t.getColor(e/(this.config.steps-1),this.config.interpolationMode)}generatePaletteColorScale(){const t=(0,o.SU)(this.config.baseColor),e=new y([{position:0,color:this.config.scaleColorLight},{position:.5,color:this.config.baseColor},{position:1,color:this.config.scaleColorDark}]).trim(this.config.clipLight,1-this.config.clipDark);let n=e.getColor(0),r=e.getColor(1);if(t.s>=this.config.saturationAdjustmentCutoff&&(n=l(n,this.config.saturationLight),r=l(r,this.config.saturationDark)),0!==this.config.multiplyLight){const t=u(this.config.baseColor,n);n=m(this.config.multiplyLight,this.config.interpolationMode,n,t)}if(0!==this.config.multiplyDark){const t=u(this.config.baseColor,r);r=m(this.config.multiplyDark,this.config.interpolationMode,r,t)}if(0!==this.config.overlayLight){const t=d(this.config.baseColor,n);n=m(this.config.overlayLight,this.config.interpolationMode,n,t)}if(0!==this.config.overlayDark){const t=d(this.config.baseColor,r);r=m(this.config.overlayDark,this.config.interpolationMode,r,t)}return this.config.baseScalePosition?this.config.baseScalePosition<=0?new y([{position:0,color:this.config.baseColor},{position:1,color:r.clamp()}]):this.config.baseScalePosition>=1?new y([{position:0,color:n.clamp()},{position:1,color:this.config.baseColor}]):new y([{position:0,color:n.clamp()},{position:this.config.baseScalePosition,color:this.config.baseColor},{position:1,color:r.clamp()}]):new y([{position:0,color:n.clamp()},{position:.5,color:this.config.baseColor},{position:1,color:r.clamp()}])}}$.defaultPaletteConfig={baseColor:(0,w.Hs)("#808080"),steps:11,interpolationMode:f.RGB,scaleColorLight:new s.M(1,1,1,1),scaleColorDark:new s.M(0,0,0,1),clipLight:.185,clipDark:.16,saturationAdjustmentCutoff:.05,saturationLight:.35,saturationDark:1.25,overlayLight:0,overlayDark:.25,multiplyLight:0,multiplyDark:0,baseScalePosition:.5},$.greyscalePaletteConfig={baseColor:(0,w.Hs)("#808080"),steps:11,interpolationMode:f.RGB,scaleColorLight:new s.M(1,1,1,1),scaleColorDark:new s.M(0,0,0,1),clipLight:0,clipDark:0,saturationAdjustmentCutoff:0,saturationLight:0,saturationDark:0,overlayLight:0,overlayDark:0,multiplyLight:0,multiplyDark:0,baseScalePosition:.5},$.defaultPaletteConfig.scaleColorLight,$.defaultPaletteConfig.scaleColorDark;class x{constructor(t){this.palette=[],this.config=Object.assign({},x.defaultPaletteConfig,t),this.regenPalettes()}regenPalettes(){let t=this.config.steps;(isNaN(t)||t<3)&&(t=3);const e=.14,n=new s.M(e,e,e,1),r=new $(Object.assign(Object.assign({},$.greyscalePaletteConfig),{baseColor:n,baseScalePosition:86/94,steps:t})).palette,i=((0,o.s8)(this.config.baseColor)+(0,o.SU)(this.config.baseColor).l)/2,a=this.matchRelativeLuminanceIndex(i,r)/(t-1),l=this.matchRelativeLuminanceIndex(e,r)/(t-1),c=(0,o.SU)(this.config.baseColor),u=(0,o.QX)(p.D.fromObject({h:c.h,s:c.s,l:e})),h=(0,o.QX)(p.D.fromObject({h:c.h,s:c.s,l:.06})),d=new Array(5);d[0]={position:0,color:new s.M(1,1,1,1)},d[1]={position:a,color:this.config.baseColor},d[2]={position:l,color:u},d[3]={position:.99,color:h},d[4]={position:1,color:new s.M(0,0,0,1)};const v=new y(d);this.palette=new Array(t);for(let e=0;e<t;e++){const n=v.getColor(e/(t-1),f.RGB);this.palette[e]=n}}matchRelativeLuminanceIndex(t,e){let n=Number.MAX_VALUE,r=0,i=0;const s=e.length;for(;i<s;i++){const s=Math.abs((0,o.s8)(e[i])-t);s<n&&(n=s,r=i)}return r}}x.defaultPaletteConfig={baseColor:(0,w.Hs)("#808080"),steps:94};var k=n(5291);function C(t,e,n=0,r=t.length-1){if(r===n)return t[n];const i=Math.floor((r-n)/2)+n;return e(t[i])?C(t,e,n,i):C(t,e,i+1,r)}var S=n(68009),E=n(87989);const M=Object.freeze({create:t=>F.from(t)});class F{constructor(t,e){this.closestIndexCache=new Map,this.source=t,this.swatches=e,this.reversedSwatches=Object.freeze([...this.swatches].reverse()),this.lastIndex=this.swatches.length-1}colorContrast(t,e,n,r){void 0===n&&(n=this.closestIndexOf(t));let i=this.swatches;const s=this.lastIndex;let o=n;void 0===r&&(r=(0,S.F)(t));return-1===r&&(i=this.reversedSwatches,o=s-o),C(i,n=>(0,E.v)(t,n)>=e,o,s)}get(t){return this.swatches[t]||this.swatches[(0,i.qE)(t,0,this.lastIndex)]}closestIndexOf(t){if(this.closestIndexCache.has(t.relativeLuminance))return this.closestIndexCache.get(t.relativeLuminance);let e=this.swatches.indexOf(t);if(-1!==e)return this.closestIndexCache.set(t.relativeLuminance,e),e;const n=this.swatches.reduce((e,n)=>Math.abs(n.relativeLuminance-t.relativeLuminance)<Math.abs(e.relativeLuminance-t.relativeLuminance)?n:e);return e=this.swatches.indexOf(n),this.closestIndexCache.set(t.relativeLuminance,e),e}static from(t){return new F(t,Object.freeze(new x({baseColor:s.M.fromObject(t)}).palette.map(t=>{const e=(0,w.Hs)(t.toStringHexRGB());return k.q.create(e.r,e.g,e.b)})))}}},58168(t,e,n){"use strict";n.d(e,{s(){return u}});var r=n(58207),i=n(14777),s=n(62044),o=n(89449),a=n(6608),l=n(13023),c="getPlugin",u=function(){function t(){var e,n,u,h,d,f=this;function p(t){void 0===t&&(t=null);var e=t;if(!e){var r=n||(0,a.i8)(null,{},f[o.eT]);e=u&&u[c]?r[i.$o](null,u[c]):r[i.$o](null,u)}return e}function v(t,e,r){t&&(0,s.KY)(t,o.Bw,[],null,s.hX),!r&&e&&(r=e[i.ps]()[i.uR]());var l=u;u&&u[c]&&(l=u[c]()),f[o.eT]=e,n=(0,a.i8)(r,t,e,l)}function g(){e=!1,f[o.eT]=null,n=null,u=null,d=[],h=(0,l.P)()}g(),(0,r.A)(t,f,function(t){t[i.mE]=function(t,n,r,i){v(t,n,i),e=!0},t[i.Ik]=function(e,n){var r,l=t[o.eT];if(l&&(!e||l===e[o.eT]())){var f,p=!1,v=e||(0,a.tS)(null,l,u&&u[c]?u[c]():u),b=n||((r={reason:0})[i.tI]=!1,r);return t[i.tn]&&!0===t[i.tn](v,b,m)?f=!0:m(),f}function m(){if(!p){p=!0,h.run(v,n);var t=d;d=[],(0,s.Iu)(t,function(t){t.rm()}),!0===f&&v[i.$5](b),g()}}},t[i.HC]=function(e,n){var r=t[o.eT];if(r&&(!e||r===e[o.eT]())){var s,l=!1,h=e||(0,a.nU)(null,r,u&&u[c]?u[c]():u),d=n||{reason:0};return t._doUpdate&&!0===t._doUpdate(h,d,f)?s=!0:f(),s}function f(){l||(l=!0,v(h.getCfg(),h.core(),h[i.uR]()))}},t._addHook=function(t){t&&((0,s.cy)(t)?d=d.concat(t):d[i.y5](t))},(0,s.RF)(t,"_addUnloadCb",function(){return h},"add")}),f[i.e4]=function(t){return p(t)[i.e4]()},f[i.tZ]=function(){return e},f.setInitialized=function(t){e=t},f[i.YH]=function(t){u=t},f[i.$5]=function(t,e){e?e[i.$5](t):u&&(0,s.Tn)(u[o.qT])&&u[o.qT](t,null)},f._getTelCtx=p}return t.__ieDyn=1,t}()},58207(t,e,n){"use strict";var r;n.d(e,{A(){return P}});var i,s="undefined",o="constructor",a="prototype",l="function",c="_dynInstFuncs",u="_isDynProxy",h="_dynClass",d="_dynCls$",f="_dynInstChk",p=f,v="_dfOpts",g="_unknown_",b="__proto__",m="_dyn"+b,y="__dynProto$Gbl",w="_dynInstProto",$="useBaseInst",x="setInstFuncs",k=Object,C=k.getPrototypeOf,S=k.getOwnPropertyNames,E=(typeof globalThis!==s&&(i=globalThis),i||typeof self===s||(i=self),i||typeof window===s||(i=window),i||typeof n.g===s||(i=n.g),i||{}),M=E[y]||(E[y]={o:(r={},r[x]=!0,r[$]=!0,r),n:1e3});function F(t,e){return t&&k[a].hasOwnProperty.call(t,e)}function D(t){return t&&(t===k[a]||t===Array[a])}function O(t){return D(t)||t===Function[a]}function A(t){var e;if(t){if(C)return C(t);var n=t[b]||t[a]||(t[o]?t[o][a]:null);e=t[m]||n,F(t,m)||(delete t[w],e=t[m]=t[w]||t[m],t[w]=n)}return e}function T(t,e){var n=[];if(S)n=S(t);else for(var r in t)"string"==typeof r&&F(t,r)&&n.push(r);if(n&&n.length>0)for(var i=0;i<n.length;i++)e(n[i])}function I(t,e,n){return e!==o&&typeof t[e]===l&&(n||F(t,e))&&e!==b&&e!==a}function B(t){throw new TypeError("DynamicProto: "+t)}function N(){return Object.create?(t=null,(e=Object.create)?e(t):{}):{};var t,e}function R(t,e){for(var n=t.length-1;n>=0;n--)if(t[n]===e)return!0;return!1}function L(t,e,n,r,i){function s(t,e){var n=function(){var r=function(t,e,n,r){var i=null;if(t&&F(n,h)){var s=t[c]||N();if((i=(s[n[h]]||N())[e])||B("Missing ["+e+"] "+l),!i[f]&&!1!==s[p]){for(var o=!F(t,e),a=A(t),u=[];o&&a&&!O(a)&&!R(u,a);){var d=a[e];if(d){o=d===r;break}u.push(a),a=A(a)}try{o&&(t[e]=i),i[f]=1}catch(t){s[p]=!1}}}return i}(this,e,t,n)||function(t,e,n){var r=e[t];return r===n&&(r=A(e)[t]),typeof r!==l&&B("["+t+"] is not a "+l),r}(e,t,n);return r.apply(this,arguments)};return n[u]=1,n}if(!D(t)){var o=n[c]=n[c]||N();if(!D(o)){var a=o[e]=o[e]||N();!1!==o[p]&&(o[p]=!!i),D(a)||T(n,function(e){I(n,e,!1)&&n[e]!==r[e]&&(a[e]=n[e],delete n[e],(!F(t,e)||t[e]&&!t[e][u])&&(t[e]=s(t,e)))})}}}function j(t,e){return F(t,a)?t.name||e||g:((t||{})[o]||{}).name||e||g}function P(t,e,n,r){F(t,a)||B("theClass is an invalid class definition.");var i=t[a];(function(t,e){if(C){for(var n=[],r=A(e);r&&!O(r)&&!R(n,r);){if(r===t)return!0;n.push(r),r=A(r)}return!1}return!0})(i,e)||B("["+j(t)+"] not in hierarchy of ["+j(e)+"]");var s=null;F(i,h)?s=i[h]:(s=d+j(t,"_")+"$"+M.n,M.n++,i[h]=s);var o=P[v],l=!!o[$];l&&r&&void 0!==r[$]&&(l=!!r[$]);var f=function(t){var e=N();return T(t,function(n){!e[n]&&I(t,n,!1)&&(e[n]=t[n])}),e}(e),g=function(t,e,n,r){function i(t,e,n){var i=e[n];if(i[u]&&r){var s=t[c]||{};!1!==s[p]&&(i=(s[e[h]]||{})[n]||i)}return function(){return i.apply(t,arguments)}}var s=N();T(n,function(t){s[t]=i(e,n,t)});for(var o=A(t),a=[];o&&!O(o)&&!R(a,o);)T(o,function(t){!s[t]&&I(o,t,!C)&&(s[t]=i(e,o,t))}),a.push(o),o=A(o);return s}(i,e,f,l);n(e,g);var b=!!C&&!!o[x];b&&r&&(b=!!r[x]),L(i,s,e,f,!1!==b)}P[v]=M.o},58625(t,e,n){"use strict";n.d(e,{T(){return v},Z(){return p}});var r=n(15454),i=n(14777),s=n(62044),o=n(89449),a=n(69912),l=r.KU,c="2.8.9",u="."+(0,a.Si)(6),h=0;function d(t){return 1===t[i.re]||9===t[i.re]||!+t[i.re]}function f(t,e){var n=e[t.id];if(!n){n={};try{d(e)&&(function(t,e,n){if(l)try{return l(t,e,{value:n,enumerable:!1,configurable:!0}),!0}catch(t){}return!1}(e,t.id,n)||(e[t.id]=n))}catch(t){}}return n}function p(t,e){return void 0===e&&(e=!1),(0,s.cH)(t+h+++(e?"."+c:o.m5)+u)}function v(t){var e={id:p("_aiData-"+(t||o.m5)+"."+c),accept(t){return d(t)},get(t,n,r,i){var o=t[e.id];return o?o[(0,s.cH)(n)]:(i&&((o=f(e,t))[(0,s.cH)(n)]=r),r)},kill(t,e){if(t&&t[e])try{delete t[e]}catch(t){}}};return e}},58976(t,e,n){"use strict";n.d(e,{C(){return s}});var r=n(96751),i=n(97482);class s extends r.I{connectedCallback(){super.connectedCallback(),"mobile"!==this.view&&this.$fastController.addStyles(i.g)}}},60402(t,e,n){"use strict";n.d(e,{K(){return s}});var r=n(29194);class i extends r.Yi{bind(t){t.source[this.options]=t.targets[this.targetNodeId]}}r.dg.define(i);const s=t=>new i(t)},60815(t,e,n){"use strict";n.d(e,{Jg(){return u},Nx(){return a},ao(){return d},cP(){return l},sH(){return c}});var r=n(96293),i=n(19470),s=n(23429),o=n(93800);const a=Object.freeze({unknown:void 0,coupled:1}),l=i.Zx.getById(r.uL.observable,()=>{const t=s.L.enqueue,e=/(:|&&|\|\||if|\?\.)/,n=new WeakMap;let l,c=t=>{throw i.Zx.error(1101)};function u(t){var e;let r=null!==(e=t.$fastController)&&void 0!==e?e:n.get(t);return void 0===r&&(Array.isArray(t)?r=c(t):n.set(t,r=new o.S(t))),r}const h=(0,i.iX)();class d{constructor(t){this.name=t,this.field=`_${t}`,this.callback=`${t}Changed`}getValue(t){return void 0!==l&&l.watch(t,this.name),t[this.field]}setValue(t,e){const n=this.field,i=t[n];if(i!==e){t[n]=e;const s=t[this.callback];(0,r.Tn)(s)&&s.call(t,i,e),u(t).notify(this.name)}}}class f extends o.l{constructor(t,e,n=!1){super(t,e),this.expression=t,this.isVolatileBinding=n,this.needsRefresh=!0,this.needsQueue=!0,this.isAsync=!0,this.first=this,this.last=null,this.propertySource=void 0,this.propertyName=void 0,this.notifier=void 0,this.next=void 0}setMode(t){this.isAsync=this.needsQueue=t}bind(t){this.controller=t;const e=this.observe(t.source,t.context);return!t.isBound&&this.requiresUnbind(t)&&t.onUnbind(this),e}requiresUnbind(t){return t.sourceLifetime!==a.coupled||this.first!==this.last||this.first.propertySource!==t.source}unbind(t){this.dispose()}observe(t,e){this.needsRefresh&&null!==this.last&&this.dispose();const n=l;let r;l=this.needsRefresh?this:void 0,this.needsRefresh=this.isVolatileBinding;try{r=this.expression(t,e)}finally{l=n}return r}disconnect(){this.dispose()}dispose(){if(null!==this.last){let t=this.first;for(;void 0!==t;)t.notifier.unsubscribe(this,t.propertyName),t=t.next;this.last=null,this.needsRefresh=this.needsQueue=this.isAsync}}watch(t,e){const n=this.last,r=u(t),i=null===n?this.first:{};if(i.propertySource=t,i.propertyName=e,i.notifier=r,r.subscribe(this,e),null!==n){if(!this.needsRefresh){let e;l=void 0,e=n.propertySource[n.propertyName],l=this,t===e&&(this.needsRefresh=!0)}n.next=i}this.last=i}handleChange(){this.needsQueue?(this.needsQueue=!1,t(this)):this.isAsync||this.call()}call(){null!==this.last&&(this.needsQueue=this.isAsync,this.notify(this))}*records(){let t=this.first;for(;void 0!==t;)yield t,t=t.next}}return(0,i.rV)(f),Object.freeze({setArrayObserverFactory(t){c=t},getNotifier:u,track(t,e){l&&l.watch(t,e)},trackVolatile(){l&&(l.needsRefresh=!0)},notify(t,e){u(t).notify(e)},defineProperty(t,e){(0,r.Kg)(e)&&(e=new d(e)),h(t).push(e),Reflect.defineProperty(t,e.name,{enumerable:!0,get(){return e.getValue(this)},set(t){e.setValue(this,t)}})},getAccessors:h,binding(t,e,n=this.isVolatileBinding(t)){return new f(t,e,n)},isVolatileBinding:t=>e.test(t.toString())})});function c(t,e){l.defineProperty(t,e)}function u(t,e,n){return Object.assign({},n,{get(){return l.trackVolatile(),n.get.apply(this)}})}const h=i.Zx.getById(r.uL.contextEvent,()=>{let t=null;return{get:()=>t,set(e){t=e}}}),d=Object.freeze({default:{index:0,length:0,get event(){return d.getEvent()},eventDetail(){return this.event.detail},eventTarget(){return this.event.target}},getEvent:()=>h.get(),setEvent(t){h.set(t)}})},60993(t,e,n){"use strict";n.d(e,{Z(){return r}});const r="not-allowed"},61138(t,e,n){"use strict";n.d(e,{F(){return o},k(){return s}});var r=n(45755);const{create:i}=r.G,s=i("type-ramp-minus-1-font-size","12px"),o=i("type-ramp-minus-1-line-height","16px")},61201(t,e,n){"use strict";n.d(e,{c(){return a}});var r=n(45755),i=n(57606),s=n(86627);const{create:o}=r.G,a=o({name:"accent-palette"},i.p.create(s.Eq))},61484(t,e,n){"use strict";n.d(e,{p(){return a}});var r=n(74849),i=n(57416),s=n(4283),o=n(26920);const a=r.A`
    :host([appearance="filled"]:not([disabled]):active)::after,
    :host([appearance="filled"]:not([disabled]):focus-within:not(:active))::after {
        content: "";
        position: absolute;
        bottom: 0;
        border-bottom: calc(${o.vd} * 1px) solid ${s.IR};
        border-bottom-left-radius: calc(${i.Pb} * 1px);
        border-bottom-right-radius: calc(${i.Pb} * 1px);
        z-index: 2;
        transition: all 300ms cubic-bezier(0.1, 0.9, 0.2, 1);
    }

    :host([appearance="filled"]:not([disabled]):active)::after {
        left: 50%;
        width: 40%;
        transform: translateX(-50%);
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
    }

    :host([appearance="filled"]:not([disabled]):focus-within:not(:active))::after {
        left: 0;
        width: 100%;
    }
`},61607(t,e,n){"use strict";n.d(e,{oq(){return h}});var r=n(41667);function i(t,...e){return n=>e.reduce((t,e,r)=>t.replace(new RegExp(`\\{${r}\\}`,"g"),e(n)),t)}function s(t){return(0,r.A)(t)?`${t} !important`:e=>s(t(e))}var o=n(87944),a=n(76989),l=n(93333);function c(){return(0,l.S)()&&(window.matchMedia("(forced-colors: none)").matches||window.matchMedia("(forced-colors: active)").matches)}var u=n(6711);var h;!function(t){t.text="WindowText",t.forcedColorLink="LinkText",t.msLink="-ms-hotlight",t.disabledText="GrayText",t.selectedText="HighlightText",t.selectedBackground="Highlight",t.buttonText="ButtonText",t.buttonBackground="ButtonFace",t.background="Window"}(h||(h={}));const d={"-ms-high-contrast-adjust":"none"},f=c()?"LinkText !important":"-ms-hotlight !important";Object.assign({background:h.buttonBackground,border:"none",color:h.buttonText,fill:h.buttonText},d),Object.assign({background:h.buttonBackground,"border-color":h.buttonText,color:h.buttonText,fill:h.buttonText},d),Object.assign({background:h.selectedBackground,"border-color":h.selectedBackground,color:h.selectedText,fill:h.selectedText},d),h.background,s(h.buttonBackground),s(h.disabledText),s(h.disabledText),s(h.buttonBackground),s(h.disabledText),s(h.disabledText),s(h.disabledText),s(h.disabledText),s(h.disabledText),s(h.disabledText),h.buttonText,i("0 0 0 {0} inset {1}",(0,o.c)(u.FX),()=>h.buttonText),i("0 0 0 2px Background, 0 0 0 {0} {1}",(0,o.c)((0,a.WQ)(u.$P,2)),()=>h.buttonText),s(h.buttonText),i("0 0 0 {0} inset {1}",(0,o.c)(u.$P),()=>h.buttonBackground),h.selectedBackground,h.selectedText,h.selectedText,h.selectedText,h.selectedBackground,h.selectedBackground,h.selectedBackground,s(h.text),s(h.text),s(h.buttonText),s(h.buttonText),s(h.selectedText),s(h.selectedText),s(h.selectedBackground),s(h.selectedBackground),i("{0} solid {1}",(0,o.c)(u.FX),()=>h.text),h.buttonText,h.buttonBackground,i("0 0 0 {0} inset {1}",(0,o.c)(u.FX),()=>f),h.background,h.buttonText,h.buttonBackground,h.selectedText,h.selectedBackground,h.buttonBackground,h.selectedText,h.selectedBackground,h.selectedText},61963(t,e,n){"use strict";n.d(e,{t(){return s},x(){return i}});const r=(0,n(19470).Mg)(),i=Object.freeze({getForInstance:r.getForInstance,getByType:r.getByType,define:t=>(r.register({type:t}),t)});function s(){return function(t){i.define(t)}}},62036(t,e,n){"use strict";n.d(e,{W(){return i},f(){return s}});var r=n(68009);function i(t,e){return t.colorContrast(e,3.5)}function s(t,e,n){return t.colorContrast(n,3.5,t.closestIndexOf(t.source),-1*(0,r.F)(e))}},62044(t,e,n){"use strict";n.d(e,{$8(){return bt},$P(){return W},CP(){return xt},Cv(){return _},EH(){return rt},Ed(){return I},Et(){return X},Gh(){return R},Gv(){return j},Iu(){return Y},Ju(){return U},KT(){return nt},KY(){return ft},Kg(){return K},Lm(){return J},N6(){return ut},RF(){return yt},SA(){return vt},Tn(){return P},W$(){return et},_u(){return Q},b0(){return B},bJ(){return G},c2(){return pt},cG(){return ot},cH(){return z},cy(){return q},hW(){return $t},hX(){return N},lL(){return dt},mQ(){return L},o$(){return wt},ol(){return ct},r(){return at},rD(){return tt},tG(){return V},x3(){return ht},z(){return H},zz(){return gt}});var r=n(15454),i=n(50090),s=n(14777),o=n(89449),a="toISOString",l="endsWith",c="startsWith",u="indexOf",h="map",d="reduce",f="trim",p="toString",v="__proto__",g="constructor",b=r.KU,m=r.s6.freeze,y=(r.s6.seal,r.s6.keys),w=String[r.vR],$=w[f],x=w[l],k=w[c],C=Date[r.vR][a],S=Array.isArray,E=r.Wy[p],M=r.J$[p],F=M[s.Ek](r.s6),D=/-([a-z])/g,O=/([^\w\d_$])/g,A=/^(\d+[\w\d_$])/,T=Object.getPrototypeOf;function I(t,e){return typeof t===e}function B(t){return void 0===t||typeof t===r.bA}function N(t){return null===t||B(t)}function R(t){return!N(t)}function L(t,e){return!(!t||!r.J$[s.Ek](t,e))}function j(t){return!(!t||typeof t!==r._1)}function P(t){return!(!t||typeof t!==r.hW)}function z(t){var e=t;return e&&K(e)&&(e=(e=(e=e[s.W7](D,function(t,e){return e.toUpperCase()}))[s.W7](O,"_"))[s.W7](A,function(t,e){return"_"+e})),e}function H(t,e){if(t)for(var n in t)r.J$[s.Ek](t,n)&&e[s.Ek](t,n,t[n])}function _(t,e){var n=!1;return t&&e&&!(n=t===e)&&(n=x?t[l](e):function(t,e){var n=!1,r=e?e[s.oI]:0,i=t?t[s.oI]:0;if(r&&i&&i>=r&&!(n=t===e)){for(var o=i-1,a=r-1;a>=0;a--){if(t[o]!=e[a])return!1;o--}n=!0}return n}(t,e)),n}function V(t,e){var n=!1;return t&&e&&!(n=t===e)&&(n=k?t[c](e):function(t,e){var n=!1,r=e?e[s.oI]:0;if(t&&r&&t[s.oI]>=r&&!(n=t===e)){for(var i=0;i<r;i++)if(t[i]!==e[i])return!1;n=!0}return n}(t,e)),n}function U(t,e){return!(!t||!e)&&-1!==t[s.Sj](e)}function W(t){return!(!t||"[object Date]"!==E[s.Ek](t))}var q=S||function(t){return!(!t||"[object Array]"!==E[s.Ek](t))};function G(t){return!(!t||"[object Error]"!==E[s.Ek](t))}function K(t){return"string"==typeof t}function X(t){return"number"==typeof t}function J(t){return"boolean"==typeof t}function Z(t){var e=!1;if(t&&"object"==typeof t){var n=T?T(t):function(t){if(t){if(T)return T(t);var e=t[v]||t[r.vR]||t[g];if(e)return e}return null}(t);n?(n[g]&&r.J$[s.Ek](n,g)&&(n=n[g]),e=typeof n===r.hW&&M[s.Ek](n)===F):e=!0}return e}function Q(t){if(t)return C?t[a]():function(t){if(t&&t.getUTCFullYear){var e=function(t){var e=String(t);return 1===e[s.oI]&&(e="0"+e),e};return t.getUTCFullYear()+"-"+e(t.getUTCMonth()+1)+"-"+e(t.getUTCDate())+"T"+e(t.getUTCHours())+":"+e(t.getUTCMinutes())+":"+e(t.getUTCSeconds())+"."+String((t.getUTCMilliseconds()/1e3).toFixed(3)).slice(2,5)+"Z"}}(t)}function Y(t,e,n){var r=t[s.oI];try{for(var i=0;i<r&&(!(i in t)||-1!==e[s.Ek](n||t,t[i],i,t));i++);}catch(t){}}function tt(t,e,n){if(t){if(t[u])return t[u](e,n);var r=t[s.oI],i=n||0;try{for(var o=Math.max(i>=0?i:r-Math.abs(i),0);o<r;o++)if(o in t&&t[o]===e)return o}catch(t){}}return-1}function et(t,e,n){var r;if(t){if(t[h])return t[h](e,n);var i=t[s.oI],o=n||t;r=new Array(i);try{for(var a=0;a<i;a++)a in t&&(r[a]=e[s.Ek](o,t[a],t))}catch(t){}}return r}function nt(t,e,n){var r;if(t){if(t[d])return t[d](e,n);var i=t[s.oI],o=0;if(arguments[s.oI]>=3)r=n;else{for(;o<i&&!(o in t);)o++;r=t[o++]}for(;o<i;)o in t&&(r=e(r,t[o],o,t)),o++}return r}function rt(t){return t&&(t=$&&t[f]?t[f]():t[s.W7]?t[s.W7](/^\s+|(?=\s)\s+$/g,o.m5):t),t}var it=!{toString:null}.propertyIsEnumerable("toString"),st=["toString","toLocaleString","valueOf","hasOwnProperty","isPrototypeOf","propertyIsEnumerable","constructor"];function ot(t){var e=typeof t;if(e===r.hW||e===r._1&&null!==t||(0,i.zk)("objKeys called on non-object"),!it&&y)return y(t);var n=[];for(var o in t)t&&r.J$[s.Ek](t,o)&&n[s.y5](o);if(it)for(var a=st[s.oI],l=0;l<a;l++)t&&r.J$[s.Ek](t,st[l])&&n[s.y5](st[l]);return n}function at(t,e,n,r){if(b)try{var i={enumerable:!0,configurable:!0};return n&&(i.get=n),r&&(i.set=r),b(t,e,i),!0}catch(t){}return!1}function lt(t){return t}function ct(t){return m&&H(t,function(t,e){(q(e)||j(e))&&m(e)}),ut(t)}var ut=m||lt;function ht(){var t=Date;return t.now?t.now():(new t).getTime()}function dt(t){return G(t)?t[s.RS]:o.m5}function ft(t,e,n,r,i){var s=n;return t&&((s=t[e])===n||i&&!i(s)||r&&!r(n)||(s=n,t[e]=s)),s}function pt(t,e,n){var r;return t?!(r=t[e])&&N(r)&&(r=B(n)?{}:n,t[e]=r):r=B(n)?{}:n,r}function vt(t,e){return N(t)?e:t}function gt(t){return!!t}function bt(t){throw new Error(t)}function mt(t,e){var n=null,r=null;return P(t)?n=t:r=t,function(){var t=arguments;if(n&&(r=n()),r)return r[e][s.y9](r,t)}}function yt(t,e,n,r,i){t&&e&&n&&(!1!==i||B(t[e]))&&(t[e]=mt(n,r))}function wt(t,e,n,r){return t&&e&&j(t)&&q(n)&&Y(n,function(n){K(n)&&yt(t,n,e,n,r)}),t}function $t(t){return t&&r.zi&&(t=(0,r.s6)((0,r.zi)({},t))),t}function xt(t,e,n,i,o,a){var l=arguments,c=l[0]||{},u=l[s.oI],h=!1,d=1;for(u>0&&J(c)&&(h=c,c=l[d]||{},d++),j(c)||(c={});d<u;d++){var f=l[d],p=q(f),v=j(f);for(var g in f){if(p&&g in f||v&&r.J$[s.Ek](f,g)){var b=f[g],m=void 0;if(h&&b&&((m=q(b))||Z(b))){var y=c[g];m?q(y)||(y=[]):Z(y)||(y={}),b=xt(h,y,b)}void 0!==b&&(c[g]=b)}}}return c}},62047(t,e,n){"use strict";n.d(e,{e(){return o},t(){return s}});var r=n(45755);const{create:i}=r.G,s=i("type-ramp-minus-2-font-size","10px"),o=i("type-ramp-minus-2-line-height","14px")},62198(t,e,n){"use strict";n.d(e,{a(){return s},b(){return o}});var r=n(45755);const{create:i}=r.G,s=i("type-ramp-plus-3-font-size","24px"),o=i("type-ramp-plus-3-line-height","32px")},64003(t,e,n){"use strict";n.d(e,{c(){return l},g(){return a}});var r=n(45755),i=n(95239),s=n(31023);const{create:o}=r.G,a=o({name:"neutral-foreground-hint-recipe"},{evaluate(t){return e=t(s.r),n=t(i.p),e.colorContrast(n,4.5);var e,n}}),l=o("neutral-foreground-hint",t=>t(a).evaluate(t))},64187(t,e,n){"use strict";n.d(e,{V(){return i}});const r=":host([hidden]){display:none}";function i(t){return`${r}:host{display:${t}}`}},64332(t,e,n){"use strict";n.d(e,{DI(){return y},cH(){return z},WQ(){return k}});var r=n(19470);if(!("metadata"in Reflect)){const t=new Map;Reflect.metadata=function(t,e){return function(n){Reflect.defineMetadata(t,e,n)}},Reflect.defineMetadata=function(e,n,r){let i=t.get(r);void 0===i&&t.set(r,i=new Map),i.set(e,n)},Reflect.getOwnMetadata=function(e,n){const r=t.get(n);if(void 0!==r)return r.get(e)}}const i="annotation:paramtypes",s=Object.freeze({getDesignParamTypes(t){var e;return null!==(e=Reflect.getOwnMetadata("design:paramtypes",t))&&void 0!==e?e:r.tR},getAnnotationParamTypes(t){var e;return null!==(e=Reflect.getOwnMetadata(i,t))&&void 0!==e?e:r.tR},getOrCreateAnnotationParamTypes(t){let e=this.getAnnotationParamTypes(t);return e===r.tR&&Reflect.defineMetadata(i,e=[],t),e}}),o=new Map,a="context-request";let l;const c=Object.freeze({eventType:a,for(t){let e=o.get(t);return void 0===e&&(e=c.create(t),o.set(t,e)),e},create(t,e){const n=function(t,e,i){if(null==t||void 0!==new.target)throw r.Zx.error(1501,{name:n.name});if(e)c.defineProperty(t,e,n);else{s.getOrCreateAnnotationParamTypes(t)[i]=n}};return n.$isInterface=!0,n.initialValue=e,Reflect.defineProperty(n,"name",{value:t}),n.handle=(t,e)=>c.handle(t,e,n),n.provide=(t,e)=>c.provide(t,n,e),n.get=t=>c.get(t,n),n.request=(t,e,r)=>c.request(t,n,e,r),n.toString=()=>`Context<${n.name}>`,n},setDefaultRequestStrategy(t){l=t},get(t,e){var n;let r;return l(t,e,t=>r=t,!1),null!==(n=r)&&void 0!==n?n:e.initialValue},request(t,e,n,r=!1){l(t,e,n,r)},dispatch(t,e,n,r=!1){t.dispatchEvent(new u(e,n,r))},provide(t,e,n){c.handle(t,t=>{t.stopImmediatePropagation(),t.callback(n)},e)},handle(t,e,n){n?t.addEventListener(a,t=>{t.context===n&&e(t)}):t.addEventListener(a,e)},defineProperty(t,e,n){const r=Symbol.for(`fast:di:${e}`);Reflect.defineProperty(t,e,{get(){var t;return null!==(t=this[r])&&void 0!==t?t:this[r]=c.get(this,n)}})}});c.setDefaultRequestStrategy(c.dispatch);class u extends Event{constructor(t,e,n){super(a,{bubbles:!0,composed:!0}),this.context=t,this.callback=e,this.multiple=n}}class h{constructor(t,e){this.container=t,this.key=e}instance(t){return this.registerResolver(0,t)}singleton(t){return this.registerResolver(1,t)}transient(t){return this.registerResolver(2,t)}callback(t){return this.registerResolver(3,t)}cachedCallback(t){return this.registerResolver(3,P(t))}aliasTo(t){return this.registerResolver(5,t)}registerResolver(t,e){const{container:n,key:r}=this;return this.container=this.key=void 0,n.registerResolver(r,new M(r,t,e))}}function d(t){const e=t.slice(),n=Object.keys(t),r=n.length;let i;for(let s=0;s<r;++s)i=n[s],G(i)||(e[i]=t[i]);return e}const f=Object.freeze({none(t){throw r.Zx.error(1512,{key:t})},singleton:t=>new M(t,1,t),transient:t=>new M(t,2,t)}),p=Object.freeze({default:Object.freeze({parentLocator(){return null},async asyncRegistrationLocator(){return null},responsibleForOwnerRequests:!1,defaultResolver:f.singleton})}),v=new Map,g=new WeakMap;let b=null,m=0;const y=Object.freeze({installAsContextRequestStrategy(t){c.setDefaultRequestStrategy((e,n,r)=>{r(y.findResponsibleContainer(e,t).get(n))})},createContainer:t=>new L(null,Object.assign({},p.default,t)),findResponsibleContainer(t,e){const n=t.$$container$$;return n&&n.responsibleForOwnerRequests?n:y.findParentContainer(t,e)},findParentContainer(t,e){if(m<1)return e?e():y.getOrCreateDOMContainer();let n;return c.dispatch(t,$,t=>n=t),null!=n?n:e?e():y.getOrCreateDOMContainer()},getOrCreateDOMContainer(t,e){if(!t)return"undefined"!=typeof window?(g.has(window)||g.set(window,new L(window,Object.assign({},p.default,e,{parentLocator(){return null}}))),g.get(window)):b||(b=new L(null,Object.assign({},p.default,e,{parentLocator(){return null}})));let n=t.$$container$$;return void 0===n&&(m++,n=new L(t,Object.assign({},p.default,e,{parentLocator:y.findParentContainer}))),n},getDependencies(t){let e=v.get(t);if(void 0===e){const n=t.inject;if(void 0===n){const n=s.getDesignParamTypes(t),i=s.getAnnotationParamTypes(t);if(n===r.tR)if(i===r.tR){const n=Object.getPrototypeOf(t);e="function"==typeof n&&n!==Function.prototype?d(y.getDependencies(n)):[]}else e=d(i);else if(i===r.tR)e=d(n);else{e=d(n);let t,r=i.length;for(let n=0;n<r;++n)t=i[n],void 0!==t&&(e[n]=t);const s=Object.keys(i);let o;r=s.length;for(let t=0;t<r;++t)o=s[t],G(o)||(e[o]=i[o])}}else e=d(n);v.set(t,e)}return e},defineProperty(t,e,n,i=!1){const s=Symbol.for(`fast:di:${e}`);Reflect.defineProperty(t,e,{get(){let t=this[s];if(void 0===t){const o=this instanceof Node?y.findResponsibleContainer(this):y.getOrCreateDOMContainer();if(t=o.get(n),this[s]=t,i){const i=this.$fastController;if(!i)throw r.Zx.error(1514);const o=()=>{y.findResponsibleContainer(this).get(n)!==this[s]&&(this[s]=t,i.notify(e))};i.subscribe({handleChange:o},"isConnected")}}return t}})},createContext(t,e){const n="function"==typeof t?t:e,i="string"==typeof t?t:t&&"friendlyName"in t&&t.friendlyName||V,o="string"!=typeof t&&(t&&"respectConnection"in t&&t.respectConnection||!1),a=function(t,e,n){if(null==t||void 0!==new.target)throw r.Zx.error(1501,{name:a.name});if(e)y.defineProperty(t,e,a,o);else{s.getOrCreateAnnotationParamTypes(t)[n]=a}};return a.$isInterface=!0,Reflect.defineProperty(a,"name",{value:null!=i?i:V}),null!=n&&(a.register=function(t,e){return n(new h(t,null!=e?e:a))}),a.toString=function(){return`DIContext<${a.name}>`},a},inject:(...t)=>function(e,n,r){if("number"==typeof r){const n=s.getOrCreateAnnotationParamTypes(e),i=t[0];void 0!==i&&(n[r]=i)}else if(n)y.defineProperty(e,n,t[0]);else{const n=r?s.getOrCreateAnnotationParamTypes(r.value):s.getOrCreateAnnotationParamTypes(e);let i;for(let e=0;e<t.length;++e)i=t[e],void 0!==i&&(n[e]=i)}},transient:t=>(t.register=function(e){return z.transient(t,t).register(e)},t.registerInRequestor=!1,t),singleton:(t,e=C)=>(t.register=function(e){return z.singleton(t,t).register(e)},t.registerInRequestor=e.scoped,t)}),w=y.createContext("Container"),$=w;function x(t){return function(e){const n=function(t,e,r){y.inject(n)(t,e,r)};return n.$isResolver=!0,n.resolve=function(n,r){return t(e,n,r)},n}}const k=y.inject,C={scoped:!1};function S(t,e,n){y.inject(S)(t,e,n)}function E(t,e){return e.getFactory(t).construct(e)}x((t,e,n)=>()=>n.get(t)),x((t,e,n)=>n.has(t,!0)?n.get(t):void 0),S.$isResolver=!0,S.resolve=()=>{},x((t,e,n)=>{const r=E(t,e),i=new M(t,0,r);return n.registerResolver(t,i),r}),x((t,e,n)=>E(t,e));class M{constructor(t,e,n){this.key=t,this.strategy=e,this.state=n,this.resolving=!1}get $isResolver(){return!0}register(t){return t.registerResolver(this.key,this)}resolveAsync(t,e){switch(this.strategy){case 1:if(this.resolving)throw r.Zx.error(1513,{name:this.state.name});return this.resolving=!0,t.getFactory(this.state).constructAsync(e).then(t=>(this.state=t,this.strategy=0,this.resolving=!1,t));case 2:{const n=t.getFactory(this.state);if(null===n)throw r.Zx.error(1502,{key:this.key});return n.constructAsync(e)}default:return Promise.resolve(this.resolve(t,e))}}resolve(t,e){switch(this.strategy){case 0:return this.state;case 1:if(this.resolving)throw r.Zx.error(1513,{name:this.state.name});return this.resolving=!0,this.state=t.getFactory(this.state).construct(e),this.strategy=0,this.resolving=!1,this.state;case 2:{const n=t.getFactory(this.state);if(null===n)throw r.Zx.error(1502,{key:this.key});return n.construct(e)}case 3:return this.state(t,e,this);case 4:return this.state[0].resolve(t,e);case 5:return e.get(this.state);default:throw r.Zx.error(1503,{strategy:this.strategy})}}getFactory(t){var e,n,r;switch(this.strategy){case 1:case 2:return t.getFactory(this.state);case 5:return null!==(r=null===(n=null===(e=t.getResolver(this.state))||void 0===e?void 0:e.getFactory)||void 0===n?void 0:n.call(e,t))&&void 0!==r?r:null;default:return null}}}function F(t){return this.get(t)}function D(t,e){return e(t)}class O{constructor(t,e){this.Type=t,this.dependencies=e,this.transformers=null}async constructAsync(t,e){const n=await Promise.all(this.dependencies.map(e=>t.getAsync(e)));return this.constructCore(n,e)}construct(t,e){const n=this.dependencies.map(F,t);return this.constructCore(n,e)}constructCore(t,e){let n;return n=void 0===e?new this.Type(...t):new this.Type(...t,...e),null===this.transformers?n:this.transformers.reduce(D,n)}registerTransformer(t){(this.transformers||(this.transformers=[])).push(t)}}const A={$isResolver:!0,resolve:(t,e)=>e,resolveAsync(t,e){return Promise.resolve(e)}};function T(t){return"function"==typeof t.register}function I(t){return function(t){return T(t)&&"boolean"==typeof t.registerInRequestor}(t)&&t.registerInRequestor}function B(t){return void 0!==t.prototype}const N=new Set(["Array","ArrayBuffer","Boolean","DataView","Date","Error","EvalError","Float32Array","Float64Array","Function","Int8Array","Int16Array","Int32Array","Map","Number","Object","Promise","RangeError","ReferenceError","RegExp","Set","SharedArrayBuffer","String","SyntaxError","TypeError","Uint8Array","Uint8ClampedArray","Uint16Array","Uint32Array","URIError","WeakMap","WeakSet"]),R=new Map;class L{constructor(t,e){this.owner=t,this.config=e,this._parent=void 0,this.registerDepth=0,this.isHandlingContextRequests=!1,this.resolvers=new Map,this.resolvers.set(w,A),t&&(t.$$container$$=this,"addEventListener"in t&&c.handle(t,t=>{if(this.isHandlingContextRequests)try{const e=this.get(t.context);t.stopImmediatePropagation(),t.callback(e)}catch(t){}else t.context===w&&t.composedPath()[0]!==this.owner&&(t.stopImmediatePropagation(),t.callback(this))}))}get parent(){return void 0===this._parent&&(this._parent=this.config.parentLocator(this.owner)),this._parent}get depth(){return null===this.parent?0:this.parent.depth+1}get responsibleForOwnerRequests(){return this.config.responsibleForOwnerRequests}handleContextRequests(t){this.isHandlingContextRequests=t}register(...t){if(100===++this.registerDepth)throw r.Zx.error(1504);let e,n,i,s,o;for(let r=0,a=t.length;r<a;++r)if(e=t[r],U(e))if(T(e))e.register(this);else if(B(e))z.singleton(e,e).register(this);else for(n=Object.keys(e),s=0,o=n.length;s<o;++s)i=e[n[s]],U(i)&&(T(i)?i.register(this):this.register(i));return--this.registerDepth,this}registerResolver(t,e){H(t);const n=this.resolvers,r=n.get(t);return null==r?n.set(t,e):r instanceof M&&4===r.strategy?r.state.push(e):n.set(t,new M(t,4,[r,e])),e}registerTransformer(t,e){const n=this.getResolver(t);if(null==n)return!1;if(n.getFactory){const t=n.getFactory(this);return null!=t&&(t.registerTransformer(e),!0)}return!1}getResolver(t,e=!0){if(H(t),void 0!==t.resolve)return t;let n,r=this;for(;null!=r;){if(n=r.resolvers.get(t),null!=n)return n;if(null==r.parent){const n=I(t)?this:r;return e?this.jitRegister(t,n):null}r=r.parent}return null}has(t,e=!1){return!!this.resolvers.has(t)||!(!e||null==this.parent)&&this.parent.has(t,!0)}async getAsync(t){if(H(t),t.$isResolver)return t.resolveAsync(this,this);let e,n=this;for(;null!=n;){if(e=n.resolvers.get(t),null!=e)return e.resolveAsync(n,this);if(null==n.parent){const i=await this.config.asyncRegistrationLocator(t);if(!i)throw r.Zx.error(1505,{key:t});const s=I(t)?this:n;return e=i.register(s),e.resolveAsync(n,this)}n=n.parent}throw r.Zx.error(1505,{key:t})}get(t){if(H(t),t.$isResolver)return t.resolve(this,this);let e,n=this;for(;null!=n;){if(e=n.resolvers.get(t),null!=e)return e.resolve(n,this);if(null==n.parent){const r=I(t)?this:n;return e=this.jitRegister(t,r),e.resolve(n,this)}n=n.parent}throw r.Zx.error(1505,{key:t})}getAll(t,e=!1){H(t);const n=this;let i,s=n;if(e){let e=r.tR;for(;null!=s;)i=s.resolvers.get(t),null!=i&&(e=e.concat(_(i,s,n))),s=s.parent;return e}for(;null!=s;){if(i=s.resolvers.get(t),null!=i)return _(i,s,n);if(s=s.parent,null==s)return r.tR}return r.tR}getFactory(t){let e=R.get(t);if(void 0===e){if(W(t))throw r.Zx.error(1506,{name:t.name});R.set(t,e=new O(t,y.getDependencies(t)))}return e}registerFactory(t,e){R.set(t,e)}createChild(t){return new L(null,Object.assign({},this.config,t,{parentLocator:()=>this}))}jitRegister(t,e){if("function"!=typeof t)throw r.Zx.error(1507,{value:t});if(N.has(t.name))throw r.Zx.error(1508,{value:t.name});if(T(t)){const n=t.register(e);if(!(n instanceof Object)||null==n.resolve){const n=e.resolvers.get(t);if(null!=n)return n;throw r.Zx.error(1510)}return n}if(t.$isInterface)throw r.Zx.error(1509,{value:t.name});{const n=this.config.defaultResolver(t,e);return e.resolvers.set(t,n),n}}}const j=new WeakMap;function P(t){return function(e,n,r){if(j.has(r))return j.get(r);const i=t(e,n,r);return j.set(r,i),i}}const z=Object.freeze({instance:(t,e)=>new M(t,0,e),singleton:(t,e)=>new M(t,1,e),transient:(t,e)=>new M(t,2,e),callback:(t,e)=>new M(t,3,e),cachedCallback:(t,e)=>new M(t,3,P(e)),aliasTo:(t,e)=>new M(e,5,t)});function H(t){if(null==t)throw r.Zx.error(1511)}function _(t,e,n){if(t instanceof M&&4===t.strategy){const r=t.state;let i=r.length;const s=new Array(i);for(;i--;)s[i]=r[i].resolve(e,n);return s}return[t.resolve(e,n)]}const V="(anonymous)";function U(t){return"object"==typeof t&&null!==t||"function"==typeof t}const W=function(){const t=new WeakMap;let e=!1,n="",r=0;return function(i){return e=t.get(i),void 0===e&&(n=i.toString(),r=n.length,e=r>=29&&r<=100&&125===n.charCodeAt(r-1)&&n.charCodeAt(r-2)<=32&&93===n.charCodeAt(r-3)&&101===n.charCodeAt(r-4)&&100===n.charCodeAt(r-5)&&111===n.charCodeAt(r-6)&&99===n.charCodeAt(r-7)&&32===n.charCodeAt(r-8)&&101===n.charCodeAt(r-9)&&118===n.charCodeAt(r-10)&&105===n.charCodeAt(r-11)&&116===n.charCodeAt(r-12)&&97===n.charCodeAt(r-13)&&110===n.charCodeAt(r-14)&&88===n.charCodeAt(r-15),t.set(i,e)),e}}(),q={};function G(t){switch(typeof t){case"number":return t>=0&&(0|t)===t;case"string":{const e=q[t];if(void 0!==e)return e;const n=t.length;if(0===n)return q[t]=!1;let r=0;for(let e=0;e<n;++e)if(r=t.charCodeAt(e),0===e&&48===r&&n>1||r<48||r>57)return q[t]=!1;return q[t]=!0}default:return!1}}},64699(t,e,n){"use strict";n.d(e,{fF(){return u}});var r=n(45755),i=n(62036),s=n(95239),o=n(61201),a=n(14996);const{create:l}=r.G,c=l({name:"focus-stroke-inner-recipe"},{evaluate(t){return(0,i.f)(t(o.c),t(s.p),t(a.WN))}}),u=l("focus-stroke-inner",t=>t(c).evaluate(t))},65007(t,e,n){"use strict";n.d(e,{m(){return u}});var r=n(82239),i=n(37180),s=n(29586),o=n(96950),a=n(82774),l=n(35106);const c=function(t={}){return o.qy`
        <template
            aria-checked="${t=>t.ariaChecked}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-posinset="${t=>t.ariaPosInSet}"
            aria-selected="${t=>t.ariaSelected}"
            aria-setsize="${t=>t.ariaSetSize}"
            role="option"
        >
            ${(0,l.LT)(t)}
            <span class="content" part="content">
                <slot ${(0,a.e)("content")}></slot>
            </span>
            ${(0,l.aO)(t)}
        </template>
    `}(),u=r.Re.compose({name:`${i.c.prefix}-option`,template:c,styles:s.R})},65614(t,e,n){"use strict";n.d(e,{G(){return r}});const r=Object.freeze({prefix:"cs",shadowRootMode:"open",registry:customElements})},65636(t,e,n){"use strict";n.d(e,{m(){return F}});var r=n(37180),i=n(56911),s=n(50106),o=n(23429),a=n(60815),l=n(38493),c=n(50180),u=n(55230),h=n(17884),d=n(35106),f=n(88458),p=n(5793),v=n(56863);class g extends p.A{}class b extends((0,v.rf)(g)){constructor(){super(...arguments),this.proxy=document.createElement("select")}}class m extends b{constructor(){super(...arguments),this.open=!1,this.shiftListbox="0",this.listboxId=(0,c.NF)("listbox-")}shiftListboxChanged(t,e){void 0!==e&&this.setPositioning()}openChanged(t,e){if(this.collapsible){if(this.open)return this.ariaControls=this.listboxId,this.ariaExpanded="true",o.L.enqueue(()=>this.setPositioning()),this.focusAndScrollOptionIntoView(),this.indexWhenOpened=this.selectedIndex,void o.L.enqueue(()=>this.focus());this.cleanup?.(),this.ariaControls="",this.ariaExpanded="false"}}get collapsible(){return!(this.multiple||"number"==typeof this.size)}get value(){return a.cP.track(this,"value"),this._value}set value(t){const e=`${this._value}`;if(this._options?.length){const e=this._options.findIndex(e=>e.value===t),n=this._options[this.selectedIndex]?.value??null,r=this._options[e]?.value??null;-1!==e&&n===r||(t="",this.selectedIndex=e),t=this.firstSelectedOption?.value??t}e!==t&&(this._value=t,super.valueChanged(e,t),a.cP.notify(this,"value"),this.updateDisplayValue())}updateValue(t){this.$fastController.isConnected&&(this.value=this.firstSelectedOption?.value??""),t&&(this.$emit("input"),this.$emit("change",this,{bubbles:!0,composed:void 0}))}selectedIndexChanged(t,e){super.selectedIndexChanged(t,e),this.updateValue()}setPositioning(){this.$fastController.isConnected&&(this.cleanup=(0,s.ll)(this,this.listbox,async()=>{const t=this.shiftListbox?parseFloat(this.shiftListbox):0,{middlewareData:e,x:n,y:r}=await(0,s.rD)(this.control,this.listbox,{placement:"bottom",strategy:"fixed",middleware:[(0,s.UU)(),(0,s.BN)({padding:t}),(0,s.Ej)({apply:({availableHeight:t,rects:e})=>{Object.assign(this.listbox.style,{maxHeight:`${t}px`,minWidth:`${e.reference.width}px`})}}),(0,s.jD)()]});e.hide?.referenceHidden?this.open=!1:Object.assign(this.listbox.style,{position:"fixed",top:"0",left:"0",transform:`translate(${n}px, ${r}px)`})}))}get displayValue(){return a.cP.track(this,"displayValue"),this.firstSelectedOption?.text??""}disabledChanged(t,e){super.disabledChanged&&super.disabledChanged(t,e),this.ariaDisabled=this.disabled?"true":"false"}formResetCallback(){this.setProxyOptions(),super.setDefaultSelectedOption(),-1===this.selectedIndex&&(this.selectedIndex=0)}clickHandler(t){if(!this.disabled){if(this.open){const e=t.target.closest("option,[role=option]");if(e&&e.disabled)return}return super.clickHandler(t),this.open=this.collapsible&&!this.open,this.open||this.indexWhenOpened===this.selectedIndex||this.updateValue(!0),!0}}focusoutHandler(t){if(super.focusoutHandler(t),!this.open)return!0;const e=t.relatedTarget;this.isSameNode(e)?this.focus():this.options?.includes(e)||(this.open=!1,this.indexWhenOpened!==this.selectedIndex&&this.updateValue(!0))}handleChange(t,e){super.handleChange(t,e),"value"===e&&this.updateValue()}slottedOptionsChanged(t,e){this.options.forEach(t=>{a.cP.getNotifier(t).unsubscribe(this,"value")}),super.slottedOptionsChanged(t,e),this.options.forEach(t=>{a.cP.getNotifier(t).subscribe(this,"value")}),this.setProxyOptions(),this.updateValue()}mousedownHandler(t){return t.offsetX>=0&&t.offsetX<=this.listbox?.scrollWidth?super.mousedownHandler(t):this.collapsible}multipleChanged(t,e){super.multipleChanged(t,e),this.proxy&&(this.proxy.multiple=e)}selectedOptionsChanged(t,e){super.selectedOptionsChanged(t,e),this.options?.forEach((t,e)=>{const n=this.proxy?.options.item(e);n&&(n.selected=t.selected)})}setDefaultSelectedOption(){const t=this.options??Array.from(this.children).filter(h.U.slottedOptionFilter),e=t?.findIndex(t=>t.hasAttribute("selected")||t.selected||t.value===this.value);this.selectedIndex=-1===e?0:e}setProxyOptions(){this.proxy instanceof HTMLSelectElement&&this.options&&(this.proxy.options.length=0,this.options.forEach(t=>{const e=t.proxy||(t instanceof HTMLOptionElement?t.cloneNode():null);e&&this.proxy.options.add(e)}))}keydownHandler(t){super.keydownHandler(t);const e=t.key||t.key.charCodeAt(0);switch(e){case u.gG:t.preventDefault(),this.collapsible&&this.typeAheadExpired&&(this.open=!this.open);break;case u.kE:case u.FM:t.preventDefault();break;case u.Mm:t.preventDefault(),this.open=!this.open;break;case u.F9:this.collapsible&&this.open&&(t.preventDefault(),this.open=!1);break;case u.J9:return this.collapsible&&this.open&&(t.preventDefault(),this.open=!1),!0}return this.open||this.indexWhenOpened===this.selectedIndex||(this.updateValue(!0),this.indexWhenOpened=this.selectedIndex),!(e===u.HX||e===u.I5)}connectedCallback(){super.connectedCallback(),this.addEventListener("contentchange",this.updateDisplayValue)}disconnectedCallback(){this.removeEventListener("contentchange",this.updateDisplayValue),this.cleanup?.(),super.disconnectedCallback()}sizeChanged(t,e){super.sizeChanged(t,e),this.proxy&&(this.proxy.size=e)}updateDisplayValue(){this.collapsible&&a.cP.notify(this,"displayValue")}}(0,i.Cg)([(0,l.CF)({attribute:"open",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],m.prototype,"open",void 0),(0,i.Cg)([(0,l.CF)({attribute:"shift-listbox"}),(0,i.Sn)("design:type",String)],m.prototype,"shiftListbox",void 0),(0,i.Cg)([a.Jg,(0,i.Sn)("design:type",Boolean),(0,i.Sn)("design:paramtypes",[])],m.prototype,"collapsible",null),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",HTMLElement)],m.prototype,"control",void 0);class y{}(0,i.Cg)([a.sH,(0,i.Sn)("design:type",Object)],y.prototype,"ariaControls",void 0),(0,f.X)(y,h.r),(0,f.X)(m,d.qw,y);class w extends m{appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="outline")}}(0,i.Cg)([(0,l.CF)({mode:"fromView"}),(0,i.Sn)("design:type",String)],w.prototype,"appearance",void 0);var $=n(11152),x=n(96950),k=n(69259),C=n(60402),S=n(82774),E=n(18893);const M=function(t={}){return x.qy`
        <template
            aria-activedescendant="${t=>t.ariaActiveDescendant}"
            aria-controls="${t=>t.ariaControls}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-expanded="${t=>t.ariaExpanded}"
            aria-haspopup="${t=>t.collapsible?"listbox":null}"
            aria-multiselectable="${t=>t.ariaMultiSelectable}"
            ?open="${t=>t.open}"
            role="combobox"
            tabindex="${t=>t.disabled?null:"0"}"
            @click="${(t,e)=>t.clickHandler(e.event)}"
            @focusin="${(t,e)=>t.focusinHandler(e.event)}"
            @focusout="${(t,e)=>t.focusoutHandler(e.event)}"
            @keydown="${(t,e)=>t.keydownHandler(e.event)}"
            @mousedown="${(t,e)=>t.mousedownHandler(e.event)}"
        >
            ${(0,k.z)(t=>t.collapsible,x.qy`
                    <div
                        class="control"
                        part="control"
                        ?disabled="${t=>t.disabled}"
                        ${(0,C.K)("control")}
                    >
                        ${(0,d.LT)(t)}
                        <slot name="button-container">
                            <div class="selected-value" part="selected-value">
                                <slot name="selected-value">${t=>t.displayValue}</slot>
                            </div>
                            <div aria-hidden="true" class="indicator" part="indicator">
                                <slot name="indicator">
                                    ${(0,E.R)(t.indicator)}
                                </slot>
                            </div>
                        </slot>
                        ${(0,d.aO)(t)}
                    </div>
                `)}
            <div
                class="listbox"
                id="${t=>t.listboxId}"
                part="listbox"
                role="listbox"
                ?disabled="${t=>t.disabled}"
                ?hidden="${t=>!!t.collapsible&&!t.open}"
                ${(0,C.K)("listbox")}
            >
                <slot
                    ${(0,S.e)({filter:h.U.slottedOptionFilter,flatten:!0,property:"slottedOptions"})}
                ></slot>
            </div>
        </template>
    `}({indicator:x.qy`
        <svg
            class="select-indicator"
            part="select-indicator"
            viewBox="0 0 12 7"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                d="M11.85.65c.2.2.2.5 0 .7L6.4 6.84a.55.55 0 01-.78 0L.14 1.35a.5.5 0 11.71-.7L6 5.8 11.15.65c.2-.2.5-.2.7 0z"
            />
        </svg>
    `}),F=w.compose({name:`${r.c.prefix}-select`,template:M,styles:$.R7})},65923(t,e,n){"use strict";n.d(e,{th(){return f}});var r=n(56911),i=n(50106),s=n(60815),o=n(23429),a=n(92011),l=n(38493),c=n(55230),u=n(35106),h=n(88458),d=n(43919);class f extends a.L{constructor(){super(...arguments),this.role=d.j.menuitem,this.focusSubmenuOnLoad=!1,this.handleMenuItemKeyDown=t=>{if(t.defaultPrevented)return!1;switch(t.key){case c.Mm:case c.gG:return this.invoke(),!1;case c.bb:return this.expandAndFocus(),!1;case c.F9:case c.kT:if(this.expanded)return this.closeSubMenu(),!1}return!0},this.handleMenuItemClick=t=>(t.defaultPrevented||this.disabled||this.invoke(),!1),this.submenuLoaded=()=>{this.focusSubmenuOnLoad&&(this.focusSubmenuOnLoad=!1,this.submenu&&(this.submenu.focus(),this.setAttribute("tabindex","-1")))},this.handleMouseOver=t=>(this.disabled||!this.hasSubmenu||this.expanded||(this.expanded=!0),!1),this.handleMouseOut=t=>(!this.expanded||this.contains(document.activeElement)||(this.expanded=!1),!1),this.closeSubMenu=()=>{this.expanded=!1,this.focus()},this.expandAndFocus=()=>{this.hasSubmenu&&(this.focusSubmenuOnLoad=!0,this.expanded=!0)},this.invoke=()=>{if(!this.disabled)switch(this.role){case d.j.menuitemcheckbox:this.checked=!this.checked;break;case d.j.menuitem:if(this.hasSubmenu){this.expandAndFocus();break}this.$emit("change");break;case d.j.menuitemradio:this.checked||(this.checked=!0)}}}expandedChanged(t,e){this.$fastController.isConnected&&(e&&this.submenu&&this.updateSubmenu(),this.$emit("expanded-change",this,{bubbles:!1}))}checkedChanged(t,e){this.$fastController.isConnected&&this.$emit("change")}get hasSubmenu(){return!!this.submenu}slottedSubmenuChanged(t,e){e.length&&(this.submenu=e[0],this.updateSubmenu())}disconnectedCallback(){this.cleanup?.(),super.disconnectedCallback()}updateSubmenu(){this.cleanup?.(),this.submenu&&this.expanded&&o.L.enqueue(()=>{this.cleanup=(0,i.ll)(this,this.submenuContainer,async()=>{const t=["left-start","right-start"],{x:e,y:n}=await(0,i.rD)(this,this.submenuContainer,{middleware:[(0,i.BN)(),(0,i.Ej)({apply({availableWidth:e,rects:n}){e<n.floating.width&&t.push("bottom-end","top-end")}}),(0,i.UU)({fallbackPlacements:t})],placement:"right-start",strategy:"fixed"});Object.assign(this.submenuContainer.style,{left:`${e}px`,position:"fixed",top:`${n}px`}),this.submenuLoaded()})})}}(0,r.Cg)([(0,l.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],f.prototype,"disabled",void 0),(0,r.Cg)([(0,l.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],f.prototype,"expanded",void 0),(0,r.Cg)([l.CF,(0,r.Sn)("design:type",String)],f.prototype,"role",void 0),(0,r.Cg)([(0,l.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],f.prototype,"checked",void 0),(0,r.Cg)([(0,l.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],f.prototype,"hidden",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Array)],f.prototype,"slottedSubmenu",void 0),(0,r.Cg)([s.sH,(0,r.Sn)("design:type",Object)],f.prototype,"submenu",void 0),(0,h.X)(f,u.qw)},66591(t,e,n){"use strict";function r(...t){return t.reduce((t,e)=>{const n=t.length?" ":"",i=Array.isArray(e)&&e[1]?r.call(null,e[0]):"function"==typeof e?e():"string"==typeof e?e:"";return i.length?t+n+i:t},"")}n.d(e,{x(){return r}})},67860(t,e,n){"use strict";n.d(e,{A2(){return f},EC(){return g},F7(){return l},FD(){return u},HE(){return p},jK(){return h},ud(){return c},xL(){return v},yB(){return a}});var r,i=n(55609),s=n(6711),o=n(24642);function a(t,e){return n=>{if(!(0,o.o1)(e))return-1;const r=(0,i.OB)(t,n),s=r.indexOf(e);return-1!==s?s:r.findIndex(t=>(0,o.o1)(t)&&(0,o.vp)(e,t))}}function l(t,e){return n=>{const r=(0,i.OB)(t,n),s=(0,i.OB)(e,n),l=a(r,s)(n);let c;if(-1!==l)return l;try{c=(0,o.Nk)(s)}catch(t){c=-1}return-1===c?0:r.map((t,e)=>({luminance:(0,o.Nk)(t),index:e})).reduce((t,e)=>Math.abs(e.luminance-c)<Math.abs(t.luminance-c)?e:t).index}}function c(t){return(0,o.Nk)((0,s.oR)(t))<=(-.1+Math.sqrt(.21))/2}function u(t,e){return"function"==typeof t?n=>e(n)[(0,o.qE)(t(n),0,e(n).length-1)]:e[(0,o.qE)(t,0,e.length-1)]}function h(t){return(e,n)=>r=>u(c(r)?(0,i.OB)(n,r):(0,i.OB)(e,r),t(r))}function d(t,e,n=0,r=t.length-1){if(r===n)return t[n];const i=Math.floor((r-n)/2)+n;return e(t[i])?d(t,e,n,i):d(t,e,i+1,r)}function f(t){return e=>n=>r=>s=>a=>{const l=(0,i.OB)(t,a),c=(0,i.OB)(e,a),u=c.length,h=(0,o.qE)(n(l,c,a),0,u-1),f=r(h,c,a);const p=[].concat(c),v=u-1;let g=h;return-1===f&&(p.reverse(),g=v-g),d(p,function(t){return s((0,o.v2)(l,t))},g,v)}}function p(t,e,n){return l(e,t)(n)}function v(t){return l(s.ro,(0,s.oR)(t))(t)}function g(t){return e=>e>=t}!function(t){t.neutral="neutral",t.accent="accent"}(r||(r={}))},68009(t,e,n){"use strict";n.d(e,{F(){return i}});var r=n(49399);function i(t){return(0,r.H)(t)?-1:1}},68244(t,e,n){"use strict";n.d(e,{F(){return p}});var r=n(42277),i=n(96293),s=n(19470);function o(t,e,n,r){return(t,e,n,...s)=>{(0,i.Kg)(n)&&(n=n.replace("javascript:","")),r(t,e,n,...s)}}function a(t,e,n,r){throw s.Zx.error(1209,{aspectName:n,tagName:null!=t?t:"text"})}const l={onabort:a,onauxclick:a,onbeforeinput:a,onbeforematch:a,onblur:a,oncancel:a,oncanplay:a,oncanplaythrough:a,onchange:a,onclick:a,onclose:a,oncontextlost:a,oncontextmenu:a,oncontextrestored:a,oncopy:a,oncuechange:a,oncut:a,ondblclick:a,ondrag:a,ondragend:a,ondragenter:a,ondragleave:a,ondragover:a,ondragstart:a,ondrop:a,ondurationchange:a,onemptied:a,onended:a,onerror:a,onfocus:a,onformdata:a,oninput:a,oninvalid:a,onkeydown:a,onkeypress:a,onkeyup:a,onload:a,onloadeddata:a,onloadedmetadata:a,onloadstart:a,onmousedown:a,onmouseenter:a,onmouseleave:a,onmousemove:a,onmouseout:a,onmouseover:a,onmouseup:a,onpaste:a,onpause:a,onplay:a,onplaying:a,onprogress:a,onratechange:a,onreset:a,onresize:a,onscroll:a,onsecuritypolicyviolation:a,onseeked:a,onseeking:a,onselect:a,onslotchange:a,onstalled:a,onsubmit:a,onsuspend:a,ontimeupdate:a,ontoggle:a,onvolumechange:a,onwaiting:a,onwebkitanimationend:a,onwebkitanimationiteration:a,onwebkitanimationstart:a,onwebkittransitionend:a,onwheel:a},c={elements:{a:{[r.D.attribute]:{href:o},[r.D.property]:{href:o}},area:{[r.D.attribute]:{href:o},[r.D.property]:{href:o}},button:{[r.D.attribute]:{formaction:o},[r.D.property]:{formAction:o}},embed:{[r.D.attribute]:{src:a},[r.D.property]:{src:a}},form:{[r.D.attribute]:{action:o},[r.D.property]:{action:o}},frame:{[r.D.attribute]:{src:o},[r.D.property]:{src:o}},iframe:{[r.D.attribute]:{src:o},[r.D.property]:{src:o,srcdoc:a}},input:{[r.D.attribute]:{formaction:o},[r.D.property]:{formAction:o}},link:{[r.D.attribute]:{href:a},[r.D.property]:{href:a}},object:{[r.D.attribute]:{codebase:a,data:a},[r.D.property]:{codeBase:a,data:a}},script:{[r.D.attribute]:{src:a,text:a},[r.D.property]:{src:a,text:a,innerText:a,textContent:a}},style:{[r.D.property]:{innerText:a,textContent:a}}},aspects:{[r.D.attribute]:{...l},[r.D.property]:{innerHTML:a,...l},[r.D.event]:{...l}}};function u(t,e){const n={};for(const r in e){const i=t[r],s=e[r];switch(i){case null:break;case void 0:n[r]=s;break;default:n[r]=i}}for(const e in t)e in n||(n[e]=t[e]);return Object.freeze(n)}function h(t,e){const n={};for(const r in e){const i=t[r],s=e[r];switch(i){case null:break;case void 0:n[r]=u(s,{});break;default:n[r]=u(i,s)}}for(const e in t)e in n||(n[e]=u(t[e],{}));return Object.freeze(n)}function d(t,e){const n={};for(const r in e){const i=t[r],s=e[r];switch(i){case null:break;case void 0:n[r]=h(i,{});break;default:n[r]=h(i,s)}}for(const e in t)e in n||(n[e]=h(t[e],{}));return Object.freeze(n)}function f(t,e,n,r,i){const s=t[n];if(s){const t=s[r];if(t)return t(e,n,r,i)}}const p=Object.freeze({create(t={}){var e,n;const r=null!==(e=t.trustedType)&&void 0!==e?e:function(){const t=t=>t;return globalThis.trustedTypes?globalThis.trustedTypes.createPolicy("fast-html",{createHTML:t}):{createHTML:t}}(),i=(s=null!==(n=t.guards)&&void 0!==n?n:{},o=c,Object.freeze({elements:s.elements?d(s.elements,o.elements):o.elements,aspects:s.aspects?h(s.aspects,o.aspects):o.aspects}));var s,o;return Object.freeze({createHTML:t=>r.createHTML(t),protect(t,e,n,r){var s;const o=(null!=t?t:"").toLowerCase(),a=i.elements[o];if(a){const i=f(a,t,e,n,r);if(i)return i}return null!==(s=f(i.aspects,t,e,n,r))&&void 0!==s?s:r}})}})},69128(t,e,n){"use strict";n.d(e,{R(){return v}});var r=n(60993),i=n(22131),s=n(74849),o=n(50882),a=n(25984),l=n(17767),c=n(79288),u=n(4283),h=n(92393),d=n(37302),f=n(45476),p=n(36452);const v=s.A`
    :host([disabled]),
    :host([disabled]:hover),
    :host([disabled]:active) {
        opacity: ${c.q};
        background-color: ${d.F7};
        cursor: ${r.Z};
    }

    ${a._9}
`.withBehaviors((0,i.mr)(s.A`
            :host([disabled]),
            :host([disabled]:hover),
            :host([disabled]:active),
            :host([disabled]) .control,
            :host([disabled]) .control:hover,
            :host([appearance="neutral"][disabled]:hover) .control {
                forced-color-adjust: none;
                background-color: ${o.A.ButtonFace};
                border-color: ${o.A.GrayText};
                color: ${o.A.GrayText};
                opacity: 1;
            }
        `),(0,l.f)("accent",s.A`
            :host([appearance="accent"][disabled]),
            :host([appearance="accent"][disabled]:hover),
            :host([appearance="accent"][disabled]:active) {
                background: ${u.IR};
            }

            ${a.Vw}
        `.withBehaviors((0,i.mr)(s.A`
                    :host([appearance="accent"][disabled]) .control,
                    :host([appearance="accent"][disabled]) .control:hover {
                        background: ${o.A.ButtonFace};
                        border-color: ${o.A.GrayText};
                        color: ${o.A.GrayText};
                    }
                `))),(0,l.f)("lightweight",s.A`
            :host([appearance="lightweight"][disabled]:hover),
            :host([appearance="lightweight"][disabled]:active) {
                background-color: transparent;
                color: ${h.W_};
            }

            :host([appearance="lightweight"][disabled]) .content::before,
            :host([appearance="lightweight"][disabled]:hover) .content::before,
            :host([appearance="lightweight"][disabled]:active) .content::before {
                background: transparent;
            }

            ${a.ZI}
        `.withBehaviors((0,i.mr)(s.A`
                    :host([appearance="lightweight"][disabled]) .control {
                        forced-color-adjust: none;
                        color: ${o.A.GrayText};
                    }

                    :host([appearance="lightweight"][disabled])
                        .control:hover
                        .content::before {
                        background: none;
                    }
                `))),(0,l.f)("outline",s.A`
            :host([appearance="outline"][disabled]:hover),
            :host([appearance="outline"][disabled]:active) {
                background: transparent;
                border-color: ${p.I2};
            }

            ${a.LA}
        `.withBehaviors((0,i.mr)(s.A`
                    :host([appearance="outline"][disabled]) .control {
                        border-color: ${o.A.GrayText};
                    }
                `))),(0,l.f)("stealth",s.A`
            :host([appearance="stealth"][disabled]),
            :host([appearance="stealth"][disabled]:hover),
            :host([appearance="stealth"][disabled]:active) {
                background: ${f.Wl};
            }

            ${a.ss}
        `.withBehaviors((0,i.mr)(s.A`
                    :host([appearance="stealth"][disabled]),
                    :host([appearance="stealth"][disabled]:hover) {
                        background: ${o.A.ButtonFace};
                    }

                    :host([appearance="stealth"][disabled]) .control {
                        background: ${o.A.ButtonFace};
                        border-color: transparent;
                        color: ${o.A.GrayText};
                    }
                `))))},69259(t,e,n){"use strict";n.d(e,{z(){return o}});var r=n(96293);const i=()=>null;function s(t){return void 0===t?i:(0,r.Tn)(t)?t:()=>t}function o(t,e,n){const i=(0,r.Tn)(t)?t:()=>t,o=s(e),a=s(n);return(t,e)=>i(t,e)?o(t,e):a(t,e)}},69400(t,e,n){"use strict";n.d(e,{m(){return v}});var r=n(26633),i=n(37180),s=n(74849),o=n(37998),a=n(57416),l=n(95239),c=n(26920);const u=s.A`
    :host([hidden]) {
        display: none;
    }

    :host {
        --elevation: 14;
        --dialog-height: 480px;
        --dialog-width: 640px;
        display: block;
    }

    .overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.3);
        touch-action: none;
    }

    .positioning-region {
        display: flex;
        justify-content: center;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        overflow: auto;
    }

    .control {
        ${o.ET}
        margin-top: auto;
        margin-bottom: auto;
        border-radius: calc(${a.JU} * 1px);
        width: var(--dialog-width);
        height: var(--dialog-height);
        background: ${l.p};
        z-index: 1;
        border: calc(${c.XA} * 1px) solid transparent;
    }
`;var h=n(96950),d=n(69259),f=n(60402);const p=h.qy`
        <div class="positioning-region" part="positioning-region">
            ${(0,d.z)(t=>t.modal,h.qy`
                    <div
                        class="overlay"
                        part="overlay"
                        role="presentation"
                        @click="${t=>t.dismiss()}"
                    ></div>
                `)}
            <div
                role="dialog"
                tabindex="-1"
                class="control"
                part="control"
                aria-modal="${t=>t.modal?t.modal:void 0}"
                aria-describedby="${t=>t.ariaDescribedby}"
                aria-labelledby="${t=>t.ariaLabelledby}"
                aria-label="${t=>t.ariaLabel}"
                ${(0,f.K)("dialog")}
            >
                <slot></slot>
            </div>
        </div>
    `,v=r.b.compose({name:`${i.c.prefix}-dialog`,template:p,styles:u})},69912(t,e,n){"use strict";n.d(e,{Si(){return m},VN(){return v},Z1(){return p},k5(){return b},yc(){return g}});var r=n(14777),i=n(88383),s=n(62044),o=n(89449),a=4294967296,l=4294967295,c=!1,u=123456789,h=987654321;function d(t){t<0&&(t>>>=0),u=123456789+t&l,h=987654321-t&l,c=!0}function f(){try{var t=2147483647&(0,s.x3)();d((Math.random()*a^t)+t)}catch(t){}}function p(t){return t>0?Math.floor(v()/l*(t+1))>>>0:0}function v(t){var e=0,n=(0,i.MY)()||(0,i.iN)();return n&&n.getRandomValues&&(e=n.getRandomValues(new Uint32Array(1))[0]&l),0===e&&(0,i.lT)()&&(c||f(),e=b()&l),0===e&&(e=Math.floor(a*Math.random()|0)),t||(e>>>=0),e}function g(t){t?d(t):f()}function b(t){var e=((h=36969*(65535&h)+(h>>16)&l)<<16)+(65535&(u=18e3*(65535&u)+(u>>16)&l))>>>0&l;return t||(e>>>=0),e}function m(t){void 0===t&&(t=22);for(var e=v()>>>0,n=0,i=o.m5;i[r.oI]<t;)n++,i+="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(63&e),e>>>=6,5===n&&(e=(v()<<2&4294967295|3&e)>>>0,n=0);return i}},70394(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M2.59 2.72l.06-.07a.5.5 0 01.63-.06l.07.06L8 7.29l4.65-4.64a.5.5 0 01.7.7L8.71 8l4.64 4.65c.18.17.2.44.06.63l-.06.07a.5.5 0 01-.63.06l-.07-.06L8 8.71l-4.65 4.64a.5.5 0 01-.7-.7L7.29 8 2.65 3.35a.5.5 0 01-.06-.63l.06-.07-.06.07z"></path></svg>'},71157(t,e,n){"use strict";n.d(e,{O(){return o},T(){return s}});var r=n(45755);const{create:i}=r.G,s=i("type-ramp-plus-2-font-size","20px"),o=i("type-ramp-plus-2-line-height","28px")},71481(t,e,n){"use strict";var r=n(34188),i=n(96950),s=n(22020);Object.defineProperties(i.kc.prototype,{[r.vB]:{value:r.vB,enumerable:!1,configurable:!1},hydrate:{value(t,e,n){return new s.Sk(t,e,this,n)},enumerable:!0,configurable:!1}})},71804(t,e,n){"use strict";var r=n(93333),i=n(75084);e.A=new class{constructor(){this._breakpoints=i.KL,this._defaultBreakpoint=0,this.subscriptions=[],this.update=()=>{const t=(0,r.S)()?(0,i.UE)(window.innerWidth,this._breakpoints):this.defaultBreakpoint;this.breakpoint!==t&&(this.breakpoint=t,this.notifySubscribers(this.breakpoint)),this.openRequestAnimationFrame=!1},this.currentBreakpoint=()=>this.breakpoint,this.requestFrame=()=>{this.openRequestAnimationFrame||(this.openRequestAnimationFrame=!0,window.requestAnimationFrame(this.update))},(0,r.S)()?(this.breakpoint=(0,i.UE)(window.innerWidth,this._breakpoints),window.addEventListener("resize",this.requestFrame)):this.breakpoint=this.defaultBreakpoint}get breakpoints(){return this._breakpoints}set breakpoints(t){this._breakpoints=t,this.update()}get defaultBreakpoint(){return this._defaultBreakpoint}set defaultBreakpoint(t){this._defaultBreakpoint=t,this.update()}subscribe(t){this.subscriptions.includes(t)||this.subscriptions.push(t)}unsubscribe(t){this.subscriptions=this.subscriptions.filter(e=>t!==e)}notifySubscribers(t){this.subscriptions.forEach(e=>{e(t)})}}},72454(t,e,n){"use strict";n.d(e,{O(){return r}});class r{constructor(t,e,n=!1){this.evaluate=t,this.policy=e,this.isVolatile=n}}},72691(t,e,n){"use strict";n.d(e,{o(){return o}});var r=n(45755),i=n(31157);const{create:s}=r.G,o=s("direction",i.O.ltr)},73079(t,e,n){"use strict";n.d(e,{m(){return T}});var r=n(37180),i=n(22448),s=n(74849),o=n(64187),a=n(73477),l=n(60993),c=n(22131),u=n(50882),h=n(48196),d=n(7896),f=n(74838),p=n(48751),v=n(41123),g=n(57416),b=n(26920),m=n(14996),y=n(45476),w=n(79288),$=n(64003);const x=s.A`
    ${(0,o.V)("grid")} :host {
        contain: layout;
        overflow: visible;
        font-family: ${d.O};
        outline: none;
        box-sizing: border-box;
        height: calc(${h.D} * 1px);
        grid-template-columns: minmax(42px, auto) 1fr minmax(42px, auto);
        grid-template-rows: auto;
        justify-items: center;
        align-items: center;
        padding: 0;
        margin: 0 calc(${f.vR} * 1px);
        white-space: nowrap;
        color: ${p.l};
        fill: currentcolor;
        cursor: pointer;
        font-size: ${v.K};
        line-height: ${v.Z};
        border-radius: calc(${g.Pb} * 1px);
        border: calc(${b.XA} * 1px) solid transparent;
        position: relative;
    }

    :host([start-column-count="0"]) {
        grid-template-columns: auto 1fr minmax(42px, auto);
    }

    :host([start-column-count="0"]) .content {
        grid-column: 1;
        grid-row: 1;
        margin-inline-start: 10px;
    }

    :host([start-column-count="0"]) .expand-collapse-glyph-container {
        grid-column: 5;
        grid-row: 1;
    }

    :host([start-column-count="2"]) {
        grid-template-columns:
            minmax(42px, auto) minmax(42px, auto) 1fr minmax(42px, auto)
            minmax(42px, auto);
    }

    :host([start-column-count="2"]) .content {
        grid-column: 3;
        grid-row: 1;
        margin-inline-start: 10px;
    }

    :host([start-column-count="2"]) .expand-collapse-glyph-container {
        grid-column: 5;
        grid-row: 1;
    }

    :host([start-column-count="2"]) ::slotted([slot="start"]) {
        grid-column: 2;
    }

    :host([start-column-count="2"]) ::slotted([slot="end"]) {
        grid-column: 4;
    }

    :host(:${a.N}) {
        border: calc(${b.XA} * 1px) solid ${m.WN};
        box-shadow: 0 0 0 calc((${b.vd} - ${b.XA}) * 1px)
            ${m.WN};
    }

    :host(:hover) {
        background: ${y.oO};
    }

    :host([aria-checked="true"]),
    :host(:active),
    :host([aria-expanded="true"]) {
        background: ${y.wO};
        color: ${p.l};
        z-index: 2;
    }

    :host([disabled]) {
        cursor: ${l.Z};
        opacity: ${w.q};
    }

    :host([disabled]:hover) ::slotted([slot="start"]),
    :host([disabled]:hover) ::slotted([slot="end"]),
    :host([disabled]:hover)::slotted(svg) {
        fill: currentcolor;
    }

    .content {
        grid-column-start: 2;
        justify-self: start;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    ::slotted([slot="start"]),
    ::slotted([slot="end"]) {
        display: flex;
        justify-content: center;
    }

    ::slotted([slot="end"]) {
        grid-column: 3;
    }

    ::slotted(svg) {
        ${""} width: 16px;
        height: 16px;
        display: flex;
    }

    :host(:hover) ::slotted([slot="start"]),
    :host(:hover) ::slotted([slot="end"]),
    :host(:hover)::slotted(svg),
    :host(:active) ::slotted([slot="start"]),
    :host(:active) ::slotted([slot="end"]),
    :host(:active)::slotted(svg) {
        fill: ${p.l};
    }

    :host([start-column-count="0"][aria-haspopup="menu"]) {
        display: grid;
        grid-template-columns: minmax(42px, auto) auto 1fr minmax(42px, auto) minmax(
                42px,
                auto
            );
        align-items: center;
        min-height: 32px;
    }

    :host([start-column-count="1"][aria-haspopup="menu"]),
    :host([start-column-count="1"][role="menuitemcheckbox"]),
    :host([start-column-count="1"][role="menuitemradio"]) {
        display: grid;
        grid-template-columns: minmax(42px, auto) auto 1fr minmax(42px, auto) minmax(
                42px,
                auto
            );
        align-items: center;
        min-height: 32px;
    }

    :host([start-column-count="2"]:not([aria-haspopup="menu"])) ::slotted([slot="end"]) {
        grid-column: 5;
    }

    :host .input-container,
    :host .expand-collapse-glyph-container {
        display: none;
    }

    :host([aria-haspopup="menu"]) .expand-collapse-glyph-container,
    :host([role="menuitemcheckbox"]) .input-container,
    :host([role="menuitemradio"]) .input-container {
        display: grid;
        margin-inline-end: 10px;
    }

    :host([aria-haspopup="menu"]) .content,
    :host([role="menuitemcheckbox"]) .content,
    :host([role="menuitemradio"]) .content {
        grid-column-start: 3;
    }

    :host([aria-haspopup="menu"][start-column-count="0"]) .content {
        grid-column-start: 1;
    }

    :host([aria-haspopup="menu"]) ::slotted([slot="end"]),
    :host([role="menuitemcheckbox"]) ::slotted([slot="end"]),
    :host([role="menuitemradio"]) ::slotted([slot="end"]) {
        grid-column-start: 4;
    }

    :host .expand-collapse,
    :host .checkbox,
    :host .radio {
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        width: 20px;
        height: 20px;
        box-sizing: border-box;
        outline: none;
        margin-inline-start: 10px;
    }

    :host .checkbox {
        border-radius: calc(${g.Pb} * 1px);
    }

    :host .radio {
        border-radius: 999px;
    }

    :host .checkbox-indicator,
    :host .radio-indicator,
    ::slotted([slot="checkbox-indicator"]),
    ::slotted([slot="radio-indicator"]) {
        display: none;
    }

    ::slotted([slot="end"]:not(svg)) {
        margin-inline-end: 10px;
        color: ${$.c};
    }

    :host([aria-checked="true"]) .checkbox-indicator,
    :host([aria-checked="true"]) ::slotted([slot="checkbox-indicator"]) {
        width: 100%;
        height: 100%;
        display: block;
        fill: ${p.l};
        pointer-events: none;
    }

    :host([aria-checked="true"]) .radio-indicator {
        display: block;
        pointer-events: none;
    }

    :host([aria-checked="true"]) ::slotted([slot="radio-indicator"]) {
        display: block;
        pointer-events: none;
    }

    .submenu-container {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1;
    }
`.withBehaviors((0,c.mr)(s.A`
            :host {
                forced-color-adjust: none;
                border-color: transparent;
                color: ${u.A.ButtonText};
                fill: ${u.A.ButtonText};
            }
            :host(:hover) {
                background: ${u.A.Highlight};
                color: ${u.A.HighlightText};
            }
            :host(:hover) ::slotted([slot="start"]),
            :host(:hover) ::slotted([slot="end"]),
            :host(:hover)::slotted(svg),
            :host(:active) ::slotted([slot="start"]),
            :host(:active) ::slotted([slot="end"]),
            :host(:active)::slotted(svg) {
                fill: ${u.A.HighlightText};
            }

            :host([aria-expanded="true"]) {
                background: ${u.A.Highlight};
                border-color: ${u.A.Highlight};
                color: ${u.A.HighlightText};
            }

            :host(:${a.N}) {
                background: ${u.A.Highlight};
                border-color: ${u.A.ButtonText};
                box-shadow: 0 0 0 calc(${b.XA} * 1px) inset
                    ${u.A.HighlightText};
                color: ${u.A.HighlightText};
                fill: currentcolor;
            }

            :host([disabled]),
            :host([disabled]:hover),
            :host([disabled]:hover) ::slotted([slot="start"]),
            :host([disabled]:hover) ::slotted([slot="end"]),
            :host([disabled]:hover)::slotted(svg) {
                background: ${u.A.Canvas};
                color: ${u.A.GrayText};
                fill: currentcolor;
                opacity: 1;
            }

            :host .expanded-toggle,
            :host .checkbox,
            :host .radio {
                border-color: ${u.A.ButtonText};
                background: ${u.A.HighlightText};
            }

            :host([checked="true"]) .checkbox,
            :host([checked="true"]) .radio {
                background: ${u.A.HighlightText};
                border-color: ${u.A.HighlightText};
            }

            :host(:hover) .expanded-toggle,
            :host(:hover) .checkbox,
            :host(:hover) .radio,
            :host(:${a.N}) .expanded-toggle,
            :host(:${a.N}) .checkbox,
            :host(:${a.N}) .radio,
            :host([checked="true"]:hover) .checkbox,
            :host([checked="true"]:hover) .radio,
            :host([checked="true"]:${a.N}) .checkbox,
            :host([checked="true"]:${a.N}) .radio {
                border-color: ${u.A.HighlightText};
            }

            :host([aria-checked="true"]) {
                background: ${u.A.Highlight};
                color: ${u.A.HighlightText};
            }

            :host([aria-checked="true"]) .checkbox-indicator,
            :host([aria-checked="true"]) ::slotted([slot="checkbox-indicator"]),
            :host([aria-checked="true"]) ::slotted([slot="radio-indicator"]) {
                fill: ${u.A.Highlight};
            }

            :host([aria-checked="true"]) .radio-indicator {
                background: ${u.A.Highlight};
            }
        `));var k=n(96950),C=n(69259),S=n(60402),E=n(82774),M=n(10108),F=n(35106),D=n(18893),O=n(43919);const A=function(t={}){return k.qy`
    <template
        aria-haspopup="${t=>t.hasSubmenu?"menu":void 0}"
        aria-checked="${t=>t.role!==O.j.menuitem?t.checked:void 0}"
        aria-disabled="${t=>t.disabled}"
        aria-expanded="${t=>t.expanded}"
        @keydown="${(t,e)=>t.handleMenuItemKeyDown(e.event)}"
        @click="${(t,e)=>t.handleMenuItemClick(e.event)}"
        @mouseover="${(t,e)=>t.handleMouseOver(e.event)}"
        @mouseout="${(t,e)=>t.handleMouseOut(e.event)}"
    >
            ${(0,C.z)(t=>t.role===O.j.menuitemcheckbox,k.qy`
                    <div part="input-container" class="input-container">
                        <span part="checkbox" class="checkbox">
                            <slot name="checkbox-indicator">
                                ${(0,D.R)(t.checkboxIndicator)}
                            </slot>
                        </span>
                    </div>
                `)}
            ${(0,C.z)(t=>t.role===O.j.menuitemradio,k.qy`
                    <div part="input-container" class="input-container">
                        <span part="radio" class="radio">
                            <slot name="radio-indicator">
                                ${(0,D.R)(t.radioIndicator)}
                            </slot>
                        </span>
                    </div>
                `)}
        </div>
        ${(0,F.LT)(t)}
        <span class="content" part="content">
            <slot></slot>
        </span>
        ${(0,F.aO)(t)}
        ${(0,C.z)(t=>t.hasSubmenu,k.qy`
                <div
                    part="expand-collapse-glyph-container"
                    class="expand-collapse-glyph-container"
                >
                    <span part="expand-collapse" class="expand-collapse">
                        <slot name="expand-collapse-indicator">
                            ${(0,D.R)(t.expandCollapseGlyph)}
                        </slot>
                    </span>
                </div>
            `)}
        <span
            ?hidden="${t=>!t.expanded}"
            class="submenu-container"
            part="submenu-container"
            ${(0,S.K)("submenuContainer")}
        >
            <slot name="submenu" ${(0,E.e)({property:"slottedSubmenu",filter:(0,M.Y)("[role='menu']")})}></slot>
        </span>
    </template>
    `}({checkboxIndicator:k.qy`
        <svg
            aria-hidden="true"
            part="checkbox-indicator"
            class="checkbox-indicator"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M8.143 12.6697L15.235 4.5L16.8 5.90363L8.23812 15.7667L3.80005 11.2556L5.27591 9.7555L8.143 12.6697Z"
            />
        </svg>
    `,expandCollapseGlyph:k.qy`
        <svg
            viewBox="0 0 16 16"
            xmlns="http://www.w3.org/2000/svg"
            class="expand-collapse-glyph"
            part="expand-collapse-glyph"
        >
            <path
                d="M5.00001 12.3263C5.00124 12.5147 5.05566 12.699 5.15699 12.8578C5.25831 13.0167 5.40243 13.1437 5.57273 13.2242C5.74304 13.3047 5.9326 13.3354 6.11959 13.3128C6.30659 13.2902 6.4834 13.2152 6.62967 13.0965L10.8988 8.83532C11.0739 8.69473 11.2153 8.51658 11.3124 8.31402C11.4096 8.11146 11.46 7.88966 11.46 7.66499C11.46 7.44033 11.4096 7.21853 11.3124 7.01597C11.2153 6.81341 11.0739 6.63526 10.8988 6.49467L6.62967 2.22347C6.48274 2.10422 6.30501 2.02912 6.11712 2.00691C5.92923 1.9847 5.73889 2.01628 5.56823 2.09799C5.39757 2.17969 5.25358 2.30817 5.153 2.46849C5.05241 2.62882 4.99936 2.8144 5.00001 3.00369V12.3263Z"
            />
        </svg>
    `,radioIndicator:k.qy`
        <svg
            aria-hidden="true"
            part="radio-indicator"
            class="radio-indicator"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M8.143 12.6697L15.235 4.5L16.8 5.90363L8.23812 15.7667L3.80005 11.2556L5.27591 9.7555L8.143 12.6697Z"
            />
        </svg>
    `}),T=i.z.compose({name:`${r.c.prefix}-menu-item`,template:A,styles:x})},73473(t,e,n){"use strict";n.d(e,{Gh(){return o},b4(){return s},bt(){return r},ks(){return i},oQ(){return l},zs(){return a}});const r="focus",i="focusin",s="focusout",o="keydown",a="resize",l="scroll"},73477(t,e,n){"use strict";n.d(e,{N(){return r}});const r="focus-visible"},74089(t,e,n){"use strict";n.d(e,{J_(){return d},Bg(){return f},XK(){return h},l_(){return u}});var r=n(45755),i=n(4283),s=n(57065),o=n(86627);const a=t=>(e,n)=>function(t,e){return t.contrast(o.ON)>=e?o.ON:o.Ql}(n||e(i.IR),t),{create:l}=r.G,c=l({name:"foreground-on-accent-recipe"},{evaluate(t,e){return a(s.i.normal)(t,e)}}),u=l("foreground-on-accent-rest",t=>t(c).evaluate(t,t(i.IR))),h=l("foreground-on-accent-hover",t=>t(c).evaluate(t,t(i.OS))),d=l("foreground-on-accent-active",t=>t(c).evaluate(t,t(i.am))),f=l("foreground-on-accent-focus",t=>t(c).evaluate(t,t(i.KJ)))},74838(t,e,n){"use strict";n.d(e,{Br(){return a},Ss(){return s},a9(){return o},vR(){return l}});var r=n(45755);const{create:i}=r.G,s=i("base-height-multiplier",8),o=i("base-horizontal-spacing-multiplier",3),a=i("density",0),l=i("design-unit",4)},74849(t,e,n){"use strict";n.d(e,{A(){return p}});var r=n(96293),i=n(72454),s=n(93809),o=n(61963),a=n(81263);function l(t,e,n){e.source.style.setProperty(t.targetAspect,n.bind(e))}class c{constructor(t,e){this.dataBinding=t,this.targetAspect=e}createCSS(t){return t(this),`var(${this.targetAspect})`}addedCallback(t){var e;const n=t.source;if(!n.$cssBindings){n.$cssBindings=new Map;const t=n.setAttribute;n.setAttribute=(e,r)=>{t.call(n,e,r),"style"===e&&n.$cssBindings.forEach((t,e)=>l(e,t.controller,t.observer))}}const r=null!==(e=t[this.targetAspect])&&void 0!==e?e:t[this.targetAspect]=this.dataBinding.createObserver(this,this);r.controller=t,t.source.$cssBindings.set(this,{controller:t,observer:r})}connectedCallback(t){l(this,t,t[this.targetAspect])}removedCallback(t){t.source.$cssBindings&&t.source.$cssBindings.delete(this)}handleChange(t,e){l(this,e.controller,e)}}o.x.define(c);const u=`${Math.random().toString(36).substring(2,8)}`;let h=0;const d=()=>`--v${u}${++h}`;function f(t,e){const n=[];let l="";const u=[],h=t=>{u.push(t)};for(let u=0,f=t.length-1;u<f;++u){l+=t[u];let f=e[u];(0,r.Tn)(f)?f=new c((0,s.U)(f),d()).createCSS(h):f instanceof i.O?f=new c(f,d()).createCSS(h):void 0!==o.x.getForInstance(f)&&(f=f.createCSS(h)),f instanceof a.v||f instanceof CSSStyleSheet?(""!==l.trim()&&(n.push(l),l=""),n.push(f)):l+=f}return l+=t[t.length-1],""!==l.trim()&&n.push(l),{styles:n,behaviors:u}}const p=(t,...e)=>{const{styles:n,behaviors:r}=f(t,e),i=new a.v(n);return r.length?i.withBehaviors(...r):i};class v{constructor(t,e){this.behaviors=e,this.css="";const n=t.reduce((t,e)=>((0,r.Kg)(e)?this.css+=e:t.push(e),t),[]);n.length&&(this.styles=new a.v(n))}createCSS(t){return this.behaviors.forEach(t),this.styles&&t(this),this.css}addedCallback(t){t.addStyles(this.styles)}removedCallback(t){t.removeStyles(this.styles)}}o.x.define(v),p.partial=(t,...e)=>{const{styles:n,behaviors:r}=f(t,e);return new v(n,r)}},75084(t,e,n){"use strict";n.d(e,{KL(){return r},UE(){return i}});const r=[0,540,768,1084,1400,1779];function i(t,e=r){for(let n=e.length-1;n>=0;n--)if(t>=e[n])return n}},76881(t,e,n){"use strict";n.d(e,{gs(){return g},Og(){return v}});var r=n(56911),i=n(23429),s=n(38493),o=n(60815),a=n(29025),l=n(35106),c=n(88458),u=n(92011),h=n(56863);class d extends u.L{}class f extends((0,h.rf)(d)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}const p="text";class v extends f{constructor(){super(...arguments),this.type=p}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly,this.validate())}autofocusChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.autofocus=this.autofocus,this.validate())}placeholderChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.placeholder=this.placeholder)}typeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.type=this.type,this.validate())}listChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.setAttribute("list",this.list),this.validate())}maxlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.maxLength=this.maxlength,this.validate())}minlengthChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.minLength=this.minlength,this.validate())}patternChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.pattern=this.pattern,this.validate())}sizeChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.size=this.size)}spellcheckChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.spellcheck=this.spellcheck)}connectedCallback(){super.connectedCallback(),this.proxy.setAttribute("type",this.type),this.validate(),this.autofocus&&i.L.enqueue(()=>{this.focus()})}select(){this.control.select(),this.$emit("select")}handleTextInput(){this.value=this.control.value}handleChange(){this.$emit("change")}validate(){super.validate(this.control)}}(0,r.Cg)([(0,s.CF)({attribute:"readonly",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],v.prototype,"readOnly",void 0),(0,r.Cg)([(0,s.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],v.prototype,"autofocus",void 0),(0,r.Cg)([s.CF,(0,r.Sn)("design:type",String)],v.prototype,"placeholder",void 0),(0,r.Cg)([s.CF,(0,r.Sn)("design:type",String)],v.prototype,"type",void 0),(0,r.Cg)([s.CF,(0,r.Sn)("design:type",String)],v.prototype,"list",void 0),(0,r.Cg)([(0,s.CF)({converter:s.R$}),(0,r.Sn)("design:type",Number)],v.prototype,"maxlength",void 0),(0,r.Cg)([(0,s.CF)({converter:s.R$}),(0,r.Sn)("design:type",Number)],v.prototype,"minlength",void 0),(0,r.Cg)([s.CF,(0,r.Sn)("design:type",String)],v.prototype,"pattern",void 0),(0,r.Cg)([(0,s.CF)({converter:s.R$}),(0,r.Sn)("design:type",Number)],v.prototype,"size",void 0),(0,r.Cg)([(0,s.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],v.prototype,"spellcheck",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Array)],v.prototype,"defaultSlottedNodes",void 0);class g{}(0,c.X)(g,a.z),(0,c.X)(v,l.qw,g)},76989(t,e,n){"use strict";function r(t){return(...e)=>n=>{const r=e[0];let i="function"==typeof r?r(n):r;for(let r=1;r<e.length;r++){const s=e[r];i=t(i,"function"==typeof s?s(n):s)}return i}}n.d(e,{Re(){return l},WQ(){return a},lw(){return c}});const i=r((t,e)=>t+e),s=r((t,e)=>t-e),o=r((t,e)=>t*e);function a(...t){return i.apply(this,t)}function l(...t){return s.apply(this,t)}function c(...t){return o.apply(this,t)}r((t,e)=>t/e)},79109(t,e,n){"use strict";n.d(e,{g(){return r}});const r=t=>t.nodeType!==Node.TEXT_NODE||!!t.nodeValue?.trim().length},79288(t,e,n){"use strict";n.d(e,{q(){return s}});var r=n(45755);const{create:i}=r.G,s=i("disabled-opacity",.3)},79631(t,e,n){"use strict";n.d(e,{Ur(){return N},eM(){return R}});var r=n(99900),i=n(26384),s=n(96950),o=n(5989),a=n(50882),l=n(48751),c=n(92393),u=n(57416),h=n(45476),d=n(86856),f=n(10735),p=n(7896),v=n(37998),g=n(74838),b=n(14996),m=n(64003),y=n(74849),w=n(22131),$=n(64187),x=n(73477),k=n(60993),C=n(4126),S=n(44453),E=n(32257),M=n(87204),F=n(29222),D=n(24282);const O=y.A` fluent-button{border-radius:0 var(--search-box-radius) var(--search-box-radius) 0}.enable-clr-btn::part(control){border-bottom-right-radius:24px;border-top-right-radius:24px}.searchoptions{right:70px}`,A=y.A` fluent-button{border-radius:var(--search-box-radius) 0 0 var(--search-box-radius)}.enable-clr-btn::part(control){border-bottom-left-radius:24px;border-top-left-radius:24px}.searchoptions{left:70px}`,T=(y.A` .core-search-kumo .search-btn::part(control){color:${S.Nd}}.core.core-search-kumo{border:8px solid ${S.RY};
        background: ${S.nw};
        box-shadow:  0px 1px 2px 0px ${S.o7} inset}.core.core-search-kumo svg{fill:${S.Nd}}.core.core-search-kumo .search-btn.stealth > .search-icon-asset-img{filter:${S.JU} !important;
        background-color: transparent;
        content: unset;
    }
}
`,y.A`
@media (forced-colors:active){.core.core-search-kumo{border:8px solid #FFF}}`,y.A` .root{border:1px solid #C8CCD3;border-radius:12px}.control::placeholder{font-size:12px;color:#6C7077}fluent-button::part(control){padding-right:0px !important;padding-left:0px !important;margin-inline-start:12px}`),I=y.A` :host{display:block}.form-kumo{position:relative;height:40px;box-shadow:none;backdrop-filter:none;border-radius:32px;border-end-start-radius:${E.lb8};
        border-start-start-radius: ${E.lb8}}.kumo-wrapper{height:40px;border-end-start-radius:${E.lb8};
        border-start-start-radius: ${E.lb8}}.search-hidden{visibility:hidden}@keyframes blink{0%{opacity:1}61.55%{opacity:0}}.fake-cursor{background:${l.l};position:absolute;width:1px;top:12px;bottom:12px;margin-inline-start:56px;margin-inline-end:16px;animation:blink 1.3s step-end infinite}.search-icon{display:flex;justify-content:center;align-items:center}.core{display:flex;height:100%;--search-box-radius:22px;user-select:none;--elevation:4;border-radius:var(--search-box-radius);transition:none;position:relative;overflow:hidden;background:${f.T};
        font-family: ${p.O};
        ${v.ET}}.core #q{-webkit-appearance:none;outline:none;background:transparent;border:0;margin-top:auto;margin-bottom:auto;border:none;padding:calc(${g.vR} * 2px + 2px) 12px calc(${g.vR} * 2px + 2px) 12px;
        color: ${l.l};font-size:16px;font-weight:400;line-height:24px;width:100%;font-family:inherit;flex:1;padding-inline-start:16px}.core #q:placeholder-shown{text-overflow:ellipsis}.core .search-btn .search-btn-txt{font-size:16px;font-weight:400}.core-search-kumo .search-btn::part(control){color:${S.T3}}.core-search-kumo .search-btn::part(content){height:20px;width:20px}.core-search-kumo .search-btn::part(control):active,.core-search-kumo .search-btn:active{background-color:initial}.core .search-btn{height:inherit;min-width:auto}.core .search-btn::part(control){width:100%}.core.core-search-kumo{border-radius:50px;--search-box-radius:44px;border:8px solid ${S.$C};
        background: ${S.jr};
        box-shadow: 0px 1px 2px 0px ${S.y6} inset;box-sizing:border-box}.core.core-search-kumo .clear-btn{min-width:20px;height:${E.Szr};background:transparent}.core.core-search-kumo .clear-container{margin-inline-end:0px;height:${E.Szr}}.core.core-search-kumo .clear-container #clear_srch svg{fill:${E.LUZ}}.core.core-search-kumo .search-btn.stealth > .search-icon-asset-img{filter:${M.a1}}.core.core-search-kumo .search-btn::part(control):focus-visible{box-shadow:0 0 0 2px inset ${b.WN}}.core.search-btn-on-left.core-search-kumo{border:${E.KUh} solid ${E.giY};
        background: ${E.GTW};
        border-radius: ${E.lb8};padding:0px;align-items:center;box-shadow:none}.core.search-btn-on-left.core-search-kumo .search-btn{border-end-start-radius:${E.lb8};
        border-start-start-radius: ${E.lb8};border-start-end-radius:0;border-end-end-radius:0;background:transparent;height:40px}.core.search-btn-on-left.core-search-kumo .search-btn::part(control){color:${S.T3};
        border: none;
        padding: 0px ${F.Gkw} 0px ${E.ACF} !important;
        height: 40px;
        border-end-start-radius: ${E.lb8};
        border-start-start-radius: ${E.lb8}}.core.search-btn-on-left #q{padding-inline-start:6px}.core.search-btn-on-left.core-search-kumo #q{font-weight:${D.Tn};
        color: ${E.Adh};
        caret-color: ${E.Adh};
        font-size: ${E.vtK};
        line-height: ${E.EXe};padding:0px}.core.search-btn-on-left.core-search-kumo #q::placeholder{color:${E.Adh}}.core.search-btn-on-left .search-btn.stealth > svg{fill:${m.c}}.core .search-btn.stealth{background:transparent}.core .search-btn > svg{height:24px;width:24px}.core.core-search-kumo .search-btn > svg{height:20px;width:20px;color:${S.OF}}.core.core-search-kumo svg{fill:${S.OF}}.core .search-btn.stealth > svg{fill:var(--search-svg-fill,${c.W_})}.core input[type="search"]::-webkit-search-decoration,.core input[type="search"]::-webkit-search-cancel-button,.core input[type="search"]::-webkit-search-results-button,.core input[type="search"]::-webkit-search-results-decoration{display:none}.clear-container{display:flex;align-items:center;z-index:2;height:46px}.core-search-kumo .cc-pa{padding-inline:0}.clear-btn{background:transparent;height:30px;min-width:20px}fluent-button::part(control){padding-inline-start:unset !important;padding-inline-end:${F.Gkw} !important;
        border-start-end-radius: ${E.lb8};
        border-end-end-radius: ${E.lb8}}.clear-btn > svg{width:20px;height:20px}.clear-container{display:flex;align-items:center;z-index:2;height:30px;margin-top:auto;margin-bottom:auto}`.withBehaviors((0,w.mr)(y.A` .core.search-btn-on-left.core-search-kumo #q::placeholder{color:${a.A.FieldText};
        }
    `)),B=y.A`
    ${(0,$.V)("inline-flex")} :host{--search-box-radius:calc(${u.Pb} * 2px);
        font-family: ${p.O};
        outline: none;
        user-select: none;
        --elevation: 4;
        border-radius: var(--search-box-radius);
        transition: all 0.2s ease-in-out;
        position: relative;
        background: ${f.T};
        ${v.ET}}.root{box-sizing:border-box;position:relative;display:flex;flex-direction:row;color:${m.c};border-radius:var(--search-box-radius) 0 0 var(--search-box-radius)}.control{-webkit-appearance:none;background:transparent;border:0;margin-top:auto;margin-bottom:auto;border:none;padding:calc(${g.vR} * 2px + 2px) 12px;
        color: ${l.l};
        ${""} font-size:15px;font-weight:400;letter-spacing:inherit;line-height:24px;width:100%;word-spacing:inherit;z-index:1}.control::placeholder{color:${a.A.GrayText}}.searchoptions{position:absolute;z-index:900}input[type="search"]::-webkit-search-decoration,input[type="search"]::-webkit-search-cancel-button,input[type="search"]::-webkit-search-results-button,input[type="search"]::-webkit-search-results-decoration{display:none}.control:hover,.control:${x.N},.control:disabled,.control:active{outline:none}.before-content,.after-content{${""} width: 16px;
        height: 16px;
        margin: auto;
        fill: ${l.l}}.end-slot{display:flex;justify-content:center;align-items:center}fluent-button{height:auto;position:relative}fluent-button.stealth{background:transparent}fluent-button.stealth:hover{background:${h.oO}}fluent-button::part(control){padding-right:24px !important;padding-left:24px !important}:host(:hover:not([disabled])){--elevation:6;${v.ET}}:host([isonimage]) .end-slot slot[name="end"] > svg{fill:${c.W_}}:host([isonimage]) fluent-button.stealth:hover{background:transparent}:host([disabled]) .label,:host([readOnly]) .label,:host([readOnly]) .control,:host([disabled]) .control{cursor:${k.Z}}:host([disabled]){opacity:var(--disabled-opacity)}:host([disabled]) fluent-button{pointer-events:none}.enable-clr-btn{width:78px}.enable-clr-btn::part(control){padding-right:0px !important;padding-left:0px !important}.enable-clr-btn .end-slot{margin-left:15px}`.withBehaviors(new d.t(O,A),(0,w.G2)(y.A` :host([isonimage]) .end-slot slot[name="end"] > svg{fill:${l.l}}.control::placeholder{color:var(--dark-fill-color-text-secondary,rgba(255,255,255,0.79))}`),(0,w.mr)(y.A` :host{forced-color-adjust:none;background:${a.A.Field};
                    box-shadow: ${a.A.FieldText} 0px 0px 0px 1px}:host(:hover:not([disabled])){box-shadow:${a.A.Highlight} 0px 0px 0px 1px}:host([isonimage]) .end-slot slot[name="end"] > svg{fill:${a.A.ButtonText}}:host([isonimage]) fluent-button.stealth:hover svg{fill:${a.A.HighlightText}}:host([disabled]){box-shadow:${a.A.GrayText} 0px 0px 0px 1px;opacity:1}:host([disabled]) .label{color:${a.A.ButtonText}}input::placeholder{color:${a.A.FieldText}}:host([disabled]) fluent-button::part(control){background:${a.A.ButtonFace};
                    color: ${a.A.GrayText};fill:currentColor}.control{color:${a.A.FieldText};fill:currentColor}.enable-clr-btn::part(control):focus-visible{border-color:${a.A.Highlight};
                    box-shadow: 0 0 0 calc((var(--focus-stroke-width) - var(--stroke-width)) * 1px) ${a.A.Highlight};
                }
            `),new C.o("isRubySearchBox",!0,I),new C.o("isProngRubySearchBox",!0,T)),N=i.G.compose({name:`${r.i.prefix}-search-box`,template:(0,o.W)({endContent:s.qy`
        <svg
            width="20"
            height="20"
            viewBox="3 3 14 14"
            xmlns="http://www.w3.org/2000/svg"
        >
            <path
                d="M8.5 3a5.5 5.5 0 014.23 9.02l4.12 4.13a.5.5 0 01-.63.76l-.07-.06-4.13-4.12A5.5 5.5 0 118.5 3zm0 1a4.5 4.5 0 100 9 4.5 4.5 0 000-9z"
            />
        </svg>
        `,clearContent:s.qy`<svg width="18" height="18" viewBox="0 0 12 12"><path d="M6.85 6 12 11.15l-.85.85L6 6.85.85 12 0 11.15 5.15 6 0 .85.85 0 6 5.15 11.15 0l.85.85L6.85 6Z"></path></svg>`}),styles:B,shadowOptions:{delegatesFocus:!0}}),R=B},79737(t,e,n){"use strict";n.d(e,{nS(){return i}});var r=n(92011);new Map;class i{constructor(t){this.target=t}}r.L},81263(t,e,n){"use strict";var r;let i;function s(t){return t.map(t=>t instanceof o?s(t.styles):[t]).reduce((t,e)=>t.concat(e),[])}n.d(e,{v(){return o}});class o{constructor(t){this.styles=t,this.targets=new WeakSet,this._strategy=null,this.behaviors=t.map(t=>t instanceof o?t.behaviors:null).reduce((t,e)=>null===e?t:null===t?e:t.concat(e),null)}get strategy(){return null===this._strategy&&this.withStrategy(i),this._strategy}addStylesTo(t){this.strategy.addStylesTo(t),this.targets.add(t)}removeStylesFrom(t){this.strategy.removeStylesFrom(t),this.targets.delete(t)}isAttachedTo(t){return this.targets.has(t)}withBehaviors(...t){return this.behaviors=null===this.behaviors?t:this.behaviors.concat(t),this}withStrategy(t){return this._strategy=new t(s(this.styles)),this}static setDefaultStrategy(t){i=t}static normalize(t){return void 0===t?void 0:Array.isArray(t)?new o(t):t instanceof o?t:new o([t])}}o.supportsAdoptedStyleSheets=!(null===(r=globalThis.CSS)||void 0===r?void 0:r.supports("background","-webkit-named-image(i)"))&&Array.isArray(document.adoptedStyleSheets)&&"replace"in CSSStyleSheet.prototype},82239(t,e,n){"use strict";n.d(e,{Re(){return d},nA(){return h}});var r=n(56911),i=n(60815),s=n(92011),o=n(38493),a=n(2298),l=n(29025),c=n(35106),u=n(88458);function h(t){return(0,a.sb)(t)&&("option"===t.getAttribute("role")||t instanceof HTMLOptionElement)}class d extends s.L{constructor(t,e,n,r){super(),this.defaultSelected=!1,this.dirtySelected=!1,this.selected=this.defaultSelected,this.dirtyValue=!1,t&&(this.textContent=t),e&&(this.initialValue=e),n&&(this.defaultSelected=n),r&&(this.selected=r),this.proxy=new Option(`${this.textContent}`,this.initialValue,this.defaultSelected,this.selected),this.proxy.disabled=this.disabled}checkedChanged(t,e){this.ariaChecked="boolean"!=typeof e?null:e?"true":"false"}contentChanged(t,e){this.proxy instanceof HTMLOptionElement&&(this.proxy.textContent=this.textContent),this.$emit("contentchange",null,{bubbles:!0})}defaultSelectedChanged(){this.dirtySelected||(this.selected=this.defaultSelected,this.proxy instanceof HTMLOptionElement&&(this.proxy.selected=this.defaultSelected))}disabledChanged(t,e){this.ariaDisabled=this.disabled?"true":"false",this.proxy instanceof HTMLOptionElement&&(this.proxy.disabled=this.disabled)}selectedAttributeChanged(){this.defaultSelected=this.selectedAttribute,this.proxy instanceof HTMLOptionElement&&(this.proxy.defaultSelected=this.defaultSelected)}selectedChanged(){this.ariaSelected=this.selected?"true":"false",this.dirtySelected||(this.dirtySelected=!0),this.proxy instanceof HTMLOptionElement&&(this.proxy.selected=this.selected)}initialValueChanged(t,e){this.dirtyValue||(this.value=this.initialValue,this.dirtyValue=!1)}get label(){return this.value??this.text}get text(){return this.textContent?.replace(/\s+/g," ").trim()??""}set value(t){const e=`${t??""}`;this._value=e,this.dirtyValue=!0,this.proxy instanceof HTMLOptionElement&&(this.proxy.value=e),i.cP.notify(this,"value")}get value(){return i.cP.track(this,"value"),this._value??this.text}get form(){return this.proxy?this.proxy.form:null}}(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Boolean)],d.prototype,"checked",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Array)],d.prototype,"content",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Boolean)],d.prototype,"defaultSelected",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],d.prototype,"disabled",void 0),(0,r.Cg)([(0,o.CF)({attribute:"selected",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],d.prototype,"selectedAttribute",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Boolean)],d.prototype,"selected",void 0),(0,r.Cg)([(0,o.CF)({attribute:"value",mode:"fromView"}),(0,r.Sn)("design:type",String)],d.prototype,"initialValue",void 0);class f{}(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Object)],f.prototype,"ariaChecked",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Object)],f.prototype,"ariaPosInSet",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Object)],f.prototype,"ariaSelected",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Object)],f.prototype,"ariaSetSize",void 0),(0,u.X)(f,l.z),(0,u.X)(d,c.qw,f)},82774(t,e,n){"use strict";n.d(e,{e(){return l}});var r=n(96293),i=n(29194),s=n(10108);const o="slotchange";class a extends s.u{observe(t){t.addEventListener(o,this)}disconnect(t){t.removeEventListener(o,this)}getNodes(t){return t.assignedNodes(this.options)}handleEvent(t){const e=t.currentTarget;this.updateTarget(this.getSource(e),this.computeNodes(e))}}function l(t){return(0,r.Kg)(t)&&(t={property:t}),new a(t)}i.dg.define(a)},83781(t,e,n){"use strict";n.d(e,{t(){return r}});const r={horizontal:"horizontal",vertical:"vertical"}},84471(t,e,n){"use strict";n.d(e,{W(){return u},_(){return h}});var r=n(56911),i=n(60815),s=n(92011),o=n(38493),a=n(2298),l=n(35106),c=n(88458);function u(t){return(0,a.sb)(t)&&t.isTreeItem}class h extends s.L{constructor(){super(...arguments),this.expanded=!1,this.isTreeItem=!0,this.focusable=!1,this.nested=!1,this.isNestedItem=()=>u(this.parentElement),this.handleExpandCollapseButtonClick=t=>{this.disabled||t.defaultPrevented||(this.expanded=!this.expanded)},this.handleFocus=t=>{this.setAttribute("tabindex","0")},this.handleBlur=t=>{this.setAttribute("tabindex","-1")}}expandedChanged(t,e){this.$fastController.isConnected&&this.$emit("expanded-change",this)}selectedChanged(t,e){this.$fastController.isConnected&&this.$emit("selected-change",this)}itemsChanged(t,e){this.$fastController.isConnected&&this.items.forEach(t=>{u(t)&&(t.nested=!0)})}static focusItem(t){t.focusable=!0,t.focus()}get childItemLength(){return this.$fastController.isConnected?this.childItems?.filter(t=>u(t)).length:0}}(0,r.Cg)([(0,o.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],h.prototype,"expanded",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],h.prototype,"selected",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],h.prototype,"disabled",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Boolean)],h.prototype,"focusable",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Array)],h.prototype,"childItems",void 0),(0,r.Cg)([i.sH,(0,r.Sn)("design:type",Array)],h.prototype,"items",void 0),(0,r.Cg)([(0,o.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],h.prototype,"nested",void 0),(0,c.X)(h,l.qw)},86627(t,e,n){"use strict";n.d(e,{Eq(){return c},ON(){return s},Ql(){return o},zW(){return a}});var r=n(22870),i=n(5291);const s=i.q.create(1,1,1),o=i.q.create(0,0,0),a=i.q.create(.5,.5,.5),l=(0,r.Hs)("#0078D4"),c=i.q.create(l.r,l.g,l.b)},86699(t,e,n){"use strict";n.d(e,{q(){return h}});var r=n(10108),i=n(96950),s=n(60402),o=n(69259),a=n(82774),l=n(416),c=n(35106),u=n(18893);function h(t={}){return i.qy`
        <template
            role="treeitem"
            slot="${t=>t.isNestedItem()?"item":void 0}"
            tabindex="-1"
            aria-expanded="${t=>t.childItems&&t.childItemLength>0?t.expanded:void 0}"
            aria-selected="${t=>t.selected}"
            aria-disabled="${t=>t.disabled}"
            @focusin="${(t,e)=>t.handleFocus(e.event)}"
            @focusout="${(t,e)=>t.handleBlur(e.event)}"
            ${(0,l.Y)({property:"childItems",filter:(0,r.Y)()})}
        >
            <div class="positioning-region" part="positioning-region">
                <div class="content-region" part="content-region">
                    ${(0,o.z)(t=>t.childItems&&t.childItemLength>0,i.qy`
                            <div
                                aria-hidden="true"
                                class="expand-collapse-button"
                                part="expand-collapse-button"
                                @click="${(t,e)=>t.handleExpandCollapseButtonClick(e.event)}"
                                ${(0,s.K)("expandCollapseButton")}
                            >
                                <slot name="expand-collapse-glyph">
                                    ${(0,u.R)(t.expandCollapseGlyph)}
                                </slot>
                            </div>
                        `)}
                    ${(0,c.LT)(t)}
                    <slot></slot>
                    ${(0,c.aO)(t)}
                </div>
            </div>
            ${(0,o.z)(t=>t.childItems&&t.childItemLength>0&&t.expanded,i.qy`
                    <div role="group" class="items" part="items">
                        <slot name="item" ${(0,a.e)("items")}></slot>
                    </div>
                `)}
        </template>
    `}},86856(t,e,n){"use strict";n.d(e,{t(){return s}});var r=n(23429),i=n(72691);class s{constructor(t,e){this.cache=new WeakMap,this.ltr=t,this.rtl=e}connectedCallback(t){r.L.enqueue(()=>{this.attach(t.source)})}disconnectedCallback(t){const e=this.cache.get(t.source);e&&i.o.unsubscribe(e)}attach(t){if("object"!=typeof globalThis.process&&!t.isConnected)return;const e=this.cache.get(t)||new o(this.ltr,this.rtl,t),n=i.o.getValueFor(t);i.o.subscribe(e),e.attach(n),this.cache.set(t,e)}}class o{constructor(t,e,n){this.ltr=t,this.rtl=e,this.source=n,this.attached=null}handleChange(t,e){this.attach("default"===e.target?t.default:t.getValueFor(e.target))}attach(t){this.attached!==this[t]&&(null!==this.attached&&this.source.$fastController.removeStyles(this.attached),this.attached=this[t],null!==this.attached&&this.source.$fastController.addStyles(this.attached))}}},87122(t,e,n){"use strict";n.d(e,{M(){return i}});var r=n(37820);class i{constructor(t,e,n,r){this.r=t,this.g=e,this.b=n,this.a="number"!=typeof r||isNaN(r)?1:r}static fromObject(t){return!t||isNaN(t.r)||isNaN(t.g)||isNaN(t.b)?null:new i(t.r,t.g,t.b,t.a)}equalValue(t){return this.r===t.r&&this.g===t.g&&this.b===t.b&&this.a===t.a}toStringHexRGB(){return"#"+[this.r,this.g,this.b].map(this.formatHexValue).join("")}toStringHexRGBA(){return this.toStringHexRGB()+this.formatHexValue(this.a)}toStringHexARGB(){return"#"+[this.a,this.r,this.g,this.b].map(this.formatHexValue).join("")}toStringWebRGB(){return`rgb(${Math.round((0,r.NU)(this.r,0,255))},${Math.round((0,r.NU)(this.g,0,255))},${Math.round((0,r.NU)(this.b,0,255))})`}toStringWebRGBA(){return`rgba(${Math.round((0,r.NU)(this.r,0,255))},${Math.round((0,r.NU)(this.g,0,255))},${Math.round((0,r.NU)(this.b,0,255))},${(0,r.qE)(this.a,0,1)})`}roundToPrecision(t){return new i((0,r.l)(this.r,t),(0,r.l)(this.g,t),(0,r.l)(this.b,t),(0,r.l)(this.a,t))}clamp(){return new i((0,r.qE)(this.r,0,1),(0,r.qE)(this.g,0,1),(0,r.qE)(this.b,0,1),(0,r.qE)(this.a,0,1))}toObject(){return{r:this.r,g:this.g,b:this.b,a:this.a}}formatHexValue(t){return(0,r.IG)((0,r.NU)(t,0,255))}}},87944(t,e,n){"use strict";n.d(e,{c(){return s}});var r=n(9790);const i=function(t="px"){return e=>e+t}();function s(t){return(0,r.A)(t)?e=>i(t(e)):i(t)}},87989(t,e,n){"use strict";function r(t,e){const n=t.relativeLuminance>e.relativeLuminance?t:e,r=t.relativeLuminance>e.relativeLuminance?e:t;return(n.relativeLuminance+.05)/(r.relativeLuminance+.05)}n.d(e,{v(){return r}})},88383(t,e,n){"use strict";n.d(e,{EH(){return M},FJ(){return R},MY(){return P},PV(){return q},R7(){return W},U5(){return N},Uf(){return U},Wt(){return O},YE(){return A},Z(){return L},g$(){return B},hm(){return j},iN(){return z},lT(){return _},lV(){return H},mm(){return V},w3(){return I},xk(){return G},zk(){return D}});var r=n(15454),i=n(50090),s=n(14777),o=n(62044),a=n(89449),l="window",c="document",u="navigator",h="location",d="console",f="performance",p="JSON",v="crypto",g="msCrypto",b="ReactNative",m="msie",y="trident/",w="XMLHttpRequest",$=null,x=null,k=!1,C=null,S=null;function E(t,e){var n=!1;if(t){try{if(!(n=e in t)){var i=t[r.vR];i&&(n=e in i)}}catch(t){}if(!n)try{var s=new t;n=!(0,o.b0)(s[e])}catch(t){}}return n}function M(t){var e=(0,i.mS)();return e&&e[t]?e[t]:t===l&&F()?window:null}function F(){return Boolean(typeof window===r._1&&window)}function D(){return F()?window:M(l)}function O(){return Boolean(typeof document===r._1&&document)}function A(){return O()?document:M(c)}function T(){return Boolean(typeof navigator===r._1&&navigator)}function I(){return T()?navigator:M(u)}function B(t){if(t&&k){var e=M("__mockLocation");if(e)return e}return typeof location===r._1&&location?location:M(h)}function N(){return typeof console!==r.bA?console:M(d)}function R(){return M(f)}function L(){return Boolean(typeof JSON===r._1&&JSON||null!==M(p))}function j(){return L()?JSON||M(p):null}function P(){return M(v)}function z(){return M(g)}function H(){var t=I();return!(!t||!t.product)&&t.product===b}function _(){var t=I();if(t&&(t[s.tX]!==x||null===$)){var e=((x=t[s.tX])||a.m5)[s.OL]();$=(0,o.Ju)(e,m)||(0,o.Ju)(e,y)}return $}function V(t){var e=Object[r.vR].toString[s.Ek](t),n=a.m5;return"[object Error]"===e?n="{ stack: '"+t.stack+"', message: '"+t.message+"', name: '"+t[s.RS]+"'":L()&&(n=j().stringify(t)),e+n}function U(){return null===S&&(S=T()&&Boolean(I().sendBeacon)),S}function W(t){var e=!1;try{e=!!M("fetch");var n=M("Request");e&&t&&n&&(e=E(n,"keepalive"))}catch(t){}return e}function q(){return null===C&&(C=typeof XDomainRequest!==r.bA)&&G()&&(C=C&&!E(M(w),"withCredentials")),C}function G(){var t=!1;try{t=!!M(w)}catch(t){}return t}},88458(t,e,n){"use strict";n.d(e,{X(){return i}});var r=n(38493);function i(t,...e){const n=r.$u.locate(t);e.forEach(e=>{Object.getOwnPropertyNames(e.prototype).forEach(n=>{"constructor"!==n&&Object.defineProperty(t.prototype,n,Object.getOwnPropertyDescriptor(e.prototype,n))});r.$u.locate(e).forEach(t=>n.push(t))})}},89449(t,e,n){"use strict";n.d(e,{Bw(){return l},Hr(){return a},LZ(){return i},Tj(){return b},Vo(){return h},Yd(){return o},Yp(){return f},Zi(){return g},dI(){return p},eT(){return s},fc(){return d},jy(){return c},kI(){return m},l0(){return v},m5(){return r},qT(){return u}});var r="",i="channels",s="core",o="createPerfMgr",a="disabled",l="extensionConfig",c="extensions",u="processTelemetry",h="priority",d="eventsSent",f="eventsDiscarded",p="eventsSendRequest",v="perfEvent",g="errorToConsole",b="warnToConsole",m="getPerfMgr"},89580(t,e,n){"use strict";n.d(e,{Y(){return s},v(){return o}});var r=n(45755);const{create:i}=r.G,s=i("type-ramp-plus-1-font-size","16px"),o=i("type-ramp-plus-1-line-height","22px")},90757(t,e,n){"use strict";n.d(e,{CX(){return o},em(){return l},kw(){return s},mD(){return a}});var r=n(45755);const{create:i}=r.G,s=i("accent-foreground-rest-delta",0),o=i("accent-foreground-hover-delta",6),a=i("accent-foreground-active-delta",-4),l=i("accent-foreground-focus-delta",0)},91326(t,e,n){"use strict";n.d(e,{XA(){return k}});var r,i=n(39813),s=n(96423),o=n(62044),a="Failed",l=a+"MonitorAjax",c="Track",u="Start",h="Stop",d="Event",f="AuthContext",p="Exception",v="Local",g="Session",b="Storage",m="Browser",y="Cannot",w="Buffer",$="InstrumentationKey",x=((0,s.Hj)({CRITICAL:1,WARNING:2}),(0,s.Hj)(((r={})[m+"DoesNotSupport"+v+b]=0,r[m+y+"Read"+v+b]=1,r[m+y+"Read"+g+b]=2,r[m+y+"Write"+v+b]=3,r[m+y+"Write"+g+b]=4,r[m+a+"RemovalFrom"+v+b]=5,r[m+a+"RemovalFrom"+g+b]=6,r[y+"SendEmptyTelemetry"]=7,r.ClientPerformanceMathError=8,r["ErrorParsingAI"+g+"Cookie"]=9,r.ErrorPVCalc=10,r[p+"WhileLoggingError"]=11,r[a+"AddingTelemetryTo"+w]=12,r[l+"Abort"]=13,r[l+"Dur"]=14,r[l+"Open"]=15,r[l+"RSC"]=16,r[l+"Send"]=17,r[l+"GetCorrelationHeader"]=18,r[a+"ToAddHandlerForOnBeforeUnload"]=19,r[a+"ToSendQueuedTelemetry"]=20,r[a+"ToReportDataLoss"]=21,r["Flush"+a]=22,r.MessageLimitPerPVExceeded=23,r.MissingRequiredFieldSpecification=24,r.NavigationTimingNotSupported=25,r.OnError=26,r[g+"RenewalDateIsZero"]=27,r.SenderNotInitialized=28,r[u+c+d+a]=29,r[h+c+d+a]=30,r[u+c+a]=31,r[h+c+a]=32,r.TelemetrySampledAndNotSent=33,r[c+d+a]=34,r[c+p+a]=35,r[c+"Metric"+a]=36,r[c+"PV"+a]=37,r[c+"PV"+a+"Calc"]=38,r[c+"Trace"+a]=39,r["Transmission"+a]=40,r[a+"ToSet"+b+w]=41,r[a+"ToRestore"+b+w]=42,r.InvalidBackendResponse=43,r[a+"ToFixDepricatedValues"]=44,r.InvalidDurationValue=45,r.TelemetryEnvelopeInvalid=46,r.CreateEnvelopeError=47,r[y+"SerializeObject"]=48,r[y+"SerializeObjectNonSerializable"]=49,r.CircularReferenceDetected=50,r["Clear"+f+a]=51,r[p+"Truncated"]=52,r.IllegalCharsInName=53,r.ItemNotInArray=54,r.MaxAjaxPerPVExceeded=55,r.MessageTruncated=56,r.NameTooLong=57,r.SampleRateOutOfRange=58,r["Set"+f+a]=59,r["Set"+f+a+"AccountName"]=60,r.StringValueTooLong=61,r.StartCalledMoreThanOnce=62,r.StopCalledWithoutStart=63,r["TelemetryInitializer"+a]=64,r.TrackArgumentsNotSpecified=65,r.UrlTooLong=66,r[g+b+w+"Full"]=67,r[y+"AccessCookie"]=68,r.IdTooLong=69,r.InvalidEvent=70,r[l+"SetRequestHeader"]=71,r["Send"+m+"InfoOnUserInit"]=72,r["Plugin"+p]=73,r["Notification"+p]=74,r.SnippetScriptLoadFailure=99,r["Invalid"+$]=100,r[y+"ParseAiBlobValue"]=101,r.InvalidContentBlob=102,r[c+"PageAction"+d+a]=103,r[a+"AddingCustomDefinedRequestContext"]=104,r["InMemory"+b+w+"Full"]=105,r[$+"Deprecation"]=106,r))),k=((0,s.Hj)({NotSet:0,Pii_DistinguishedName:1,Pii_GenericData:2,Pii_IPV4Address:3,Pii_IPv6Address:4,Pii_MailSubject:5,Pii_PhoneNumber:6,Pii_QueryString:7,Pii_SipAddress:8,Pii_SmtpAddress:9,Pii_Identity:10,Pii_Uri:11,Pii_Fqdn:12,Pii_IPV4AddressLegacy:13,CustomerContent_GenericContent:32}),(0,s.Hj)({Normal:1,CostDeferred:2,RealTime:3,Immediate:4}));(0,s.Hj)({Unspecified:0,String:1,Int32:2,UInt32:3,Int64:4,UInt64:5,Double:6,Bool:7,Guid:8,DateTime:9}),(0,s.Hj)({Normal:1,Critical:2}),(0,s.Hj)({NONE:0,ERROR:1,WARNING:2,INFORMATION:3}),(0,o.N6)((0,i.Im)((0,i.Im)({},x),(0,s.Hj)({AuthHandShakeError:501,AuthRedirectFail:502,BrowserCannotReadLocalStorage:503,BrowserCannotWriteLocalStorage:504,BrowserDoesNotSupportLocalStorage:505,CannotParseBiBlobValue:506,CannotParseDataAttribute:507,CVPluginNotAvailable:508,DroppedEvent:509,ErrorParsingAISessionCookie:510,ErrorProvidedChannels:511,FailedToGetCookies:512,FailedToInitializeCorrelationVector:513,FailedToInitializeSDK:514,InvalidContentBlob:515,InvalidCorrelationValue:516,SessionRenewalDateIsZero:517,SendPostOnCompleteFailure:518,PostResponseHandler:519,SDKNotInitialized:520})))},92011(t,e,n){"use strict";n.d(e,{E(){return c},L(){return l}});var r=n(96293),i=n(18931),s=n(7813);function o(t){const e=class extends t{constructor(){super(),i.V7.forCustomElement(this)}$emit(t,e,n){return this.$fastController.emit(t,e,n)}connectedCallback(){this.$fastController.connect()}disconnectedCallback(){this.$fastController.disconnect()}attributeChangedCallback(t,e,n){this.$fastController.onAttributeChangedCallback(t,e,n)}};return s.I.registerBaseType(e),e}function a(t,e){return(0,r.Tn)(t)?s.I.compose(t,e).define().type:s.I.compose(this,t).define().type}const l=Object.assign(o(HTMLElement),{from(t){return o(t)},define:a,compose(t,e){return(0,r.Tn)(t)?s.I.compose(t,e):s.I.compose(this,t)}});function c(t){return function(e){a(e,t)}}},92393(t,e,n){"use strict";n.d(e,{QL(){return p},iL(){return v},YL(){return f},W_(){return d}});var r=n(45755),i=n(68009),s=n(95239),o=n(90757),a=n(61201),l=n(57065);const{create:c}=r.G,u=t=>(e,n)=>function(t,e,n,r,s,o,a){const l=t.source,c=t.closestIndexOf(l),u=(0,i.F)(e),h=c+(1===u?Math.min(r,s):Math.max(u*r,u*s)),d=t.colorContrast(e,n,h,u),f=t.closestIndexOf(d),p=f+u*Math.abs(r-s);let v,g;return(1===u?r<s:u*r>u*s)?(v=f,g=p):(v=p,g=f),{rest:t.get(v),hover:t.get(g),active:t.get(v+u*o),focus:t.get(v+u*a)}}(e(a.c),n||e(s.p),t,e(o.kw),e(o.CX),e(o.mD),e(o.em)),h=c({name:"accent-foreground-recipe"},{evaluate(t,e){return u(l.i.normal)(t,e)}}),d=c("accent-foreground-rest",t=>t(h).evaluate(t).rest),f=c("accent-foreground-hover",t=>t(h).evaluate(t).hover),p=c("accent-foreground-active",t=>t(h).evaluate(t).active),v=c("accent-foreground-focus",t=>t(h).evaluate(t).focus)},92508(t){t.exports='<svg width="12" height="12" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg"><path d="M5.7 3.28A1 1 0 004 4v4.02a1 1 0 001.7.7l2.04-2a1 1 0 000-1.42l-2.04-2z"></path></svg>'},93800(t,e,n){"use strict";n.d(e,{S(){return i},l(){return r}});class r{constructor(t,e){this.sub1=void 0,this.sub2=void 0,this.spillover=void 0,this.subject=t,this.sub1=e}has(t){return void 0===this.spillover?this.sub1===t||this.sub2===t:-1!==this.spillover.indexOf(t)}subscribe(t){const e=this.spillover;if(void 0===e){if(this.has(t))return;if(void 0===this.sub1)return void(this.sub1=t);if(void 0===this.sub2)return void(this.sub2=t);this.spillover=[this.sub1,this.sub2,t],this.sub1=void 0,this.sub2=void 0}else{-1===e.indexOf(t)&&e.push(t)}}unsubscribe(t){const e=this.spillover;if(void 0===e)this.sub1===t?this.sub1=void 0:this.sub2===t&&(this.sub2=void 0);else{const n=e.indexOf(t);-1!==n&&e.splice(n,1)}}notify(t){const e=this.spillover,n=this.subject;if(void 0===e){const e=this.sub1,r=this.sub2;void 0!==e&&e.handleChange(n,t),void 0!==r&&r.handleChange(n,t)}else for(let r=0,i=e.length;r<i;++r)e[r].handleChange(n,t)}}class i{constructor(t){this.subscribers={},this.subjectSubscribers=null,this.subject=t}notify(t){var e,n;null===(e=this.subscribers[t])||void 0===e||e.notify(t),null===(n=this.subjectSubscribers)||void 0===n||n.notify(t)}subscribe(t,e){var n,i;let s;s=e?null!==(n=this.subscribers[e])&&void 0!==n?n:this.subscribers[e]=new r(this.subject):null!==(i=this.subjectSubscribers)&&void 0!==i?i:this.subjectSubscribers=new r(this.subject),s.subscribe(t)}unsubscribe(t,e){var n,r;e?null===(n=this.subscribers[e])||void 0===n||n.unsubscribe(t):null===(r=this.subjectSubscribers)||void 0===r||r.unsubscribe(t)}}},93809(t,e,n){"use strict";n.d(e,{F(){return a},U(){return o}});var r=n(60815),i=n(72454);class s extends i.O{createObserver(t){return r.cP.binding(this.evaluate,t,this.isVolatile)}}function o(t,e,n=r.cP.isVolatileBinding(t)){return new s(t,e,n)}function a(t,e){const n=new s(t);return n.options=e,n}},95239(t,e,n){"use strict";n.d(e,{p(){return o}});var r=n(45755),i=n(95639);const{create:s}=r.G,o=s("fill-color",t=>t(i.Ef))},95639(t,e,n){"use strict";n.d(e,{Ef(){return c}});var r=n(45755),i=n(97004),s=n(356),o=n(31023);const{create:a}=r.G,l=a({name:"neutral-layer-1-recipe"},{evaluate(t){return e=t(o.r),n=t(s.l),e.get(e.closestIndexOf((0,i.Z)(n)));var e,n}}),c=a("neutral-layer-1",t=>t(l).evaluate(t))},96271(t,e,n){"use strict";n.d(e,{UU(){return p},aq(){return f},cL(){return v}});var r,i=n(50090),s=n(14777),o=n(12839),a=n(88383),l=n(5410),c=n(62044),u=n(89449),h=n(69912),d=null;function f(){var t=v();return t[s.Re](0,8)+"-"+t[s.Re](8,12)+"-"+t[s.Re](12,16)+"-"+t[s.Re](16,20)+"-"+t[s.Re](20)}function p(){var t=(0,a.FJ)();return t&&t.now?t.now():(0,c.x3)()}function v(){for(var t,e=["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"],n=u.m5,r=0;r<4;r++)n+=e[15&(t=(0,h.VN)())]+e[t>>4&15]+e[t>>8&15]+e[t>>12&15]+e[t>>16&15]+e[t>>20&15]+e[t>>24&15]+e[t>>28&15];var i=e[8+(3&(0,h.VN)())|0];return n[s.$4](0,8)+n[s.$4](9,4)+"4"+n[s.$4](13,3)+i+n[s.$4](16,3)+n[s.$4](19,12)}var g={_canUseCookies:void 0,isTypeof:c.Ed,isUndefined:c.b0,isNullOrUndefined:c.hX,hasOwnProperty:c.mQ,isFunction:c.Tn,isObject:c.Gv,isDate:c.$P,isArray:c.cy,isError:c.bJ,isString:c.Kg,isNumber:c.Et,isBoolean:c.Lm,toISOString:c._u,arrForEach:c.Iu,arrIndexOf:c.rD,arrMap:c.W$,arrReduce:c.KT,strTrim:c.EH,objCreate:i.AQ,objKeys:c.cG,objDefineAccessors:c.r,addEventHandler:l.So,dateNow:c.x3,isIE:a.lT,disableCookies(){b()[s.kt](!1)},newGuid:f,perfNow:p,newId:h.Si,randomValue:h.Z1,random32:h.VN,mwcRandomSeed:h.yc,mwcRandom32:h.k5,generateW3CId:v};function b(t,e){var n=(0,o.d5)(t,e),i=g._canUseCookies;return null===d&&(d=[],r=i,(0,c.r)(g,"_canUseCookies",function(){return r},function(t){r=t,(0,c.Iu)(d,function(e){e[s.kt](t)})})),-1===(0,c.rD)(d,n)&&d[s.y5](n),(0,c.Lm)(i)&&n[s.kt](i),(0,c.Lm)(r)&&n[s.kt](r),n}l.Q3,l.Q3,l.Ym,l.Ym},96293(t,e,n){"use strict";let r;n.d(e,{Kg(){return a},Tn(){return o},lQ(){return l},uL(){return s}});const i="fast-kernel";try{if(document.currentScript)r=document.currentScript.getAttribute(i);else{const t=document.getElementsByTagName("script");r=t[t.length-1].getAttribute(i)}}catch(t){r="isolate"}let s;switch(r){case"share":s=Object.freeze({updateQueue:1,observable:2,contextEvent:3,elementRegistry:4});break;case"share-v2":s=Object.freeze({updateQueue:1.2,observable:2.2,contextEvent:3.2,elementRegistry:4.2});break;default:const t=`-${Math.random().toString(36).substring(2,8)}`;s=Object.freeze({updateQueue:`1.2${t}`,observable:`2.2${t}`,contextEvent:`3.2${t}`,elementRegistry:`4.2${t}`})}const o=t=>"function"==typeof t,a=t=>"string"==typeof t,l=()=>{}},96423(t,e,n){"use strict";n.d(e,{Hj(){return i}});var r=n(62044);function i(t){var e={};return(0,r.z)(t,function(t,n){e[t]=n,e[n]=t}),(0,r.ol)(e)}},96600(t,e,n){"use strict";n.d(e,{m(){return N}});var r=n(84471),i=n(37180),s=n(74849),o=n(64187),a=n(73477),l=n(60993),c=n(22131),u=n(50882),h=n(48196),d=n(86856),f=n(26920),p=n(74838),v=n(48751),g=n(45476),b=n(7896),m=n(14996),y=n(57416),w=n(41123),$=n(79288),x=n(37302),k=n(92393),C=n(45755);const S=C.G.create("tree-item-expand-collapse-hover",t=>{const e=t(g.EE);return e.evaluate(t,e.evaluate(t).hover).hover}),E=C.G.create("tree-item-expand-collapse-selected-hover",t=>{const e=t(x.jO);return t(g.EE).evaluate(t,e.evaluate(t).rest).hover}),M=s.A`
    .expand-collapse-glyph {
        transform: rotate(0deg);
    }
    :host([nested]) .expand-collapse-button {
        left: var(--expand-collapse-button-nested-width, calc(${h.D} * -1px));
    }
    :host([selected])::after {
        left: calc(${f.vd} * 1px);
    }
    :host([expanded]) > .positioning-region .expand-collapse-glyph {
        transform: rotate(45deg);
    }
`,F=s.A`
    .expand-collapse-glyph {
        transform: rotate(180deg);
    }
    :host([nested]) .expand-collapse-button {
        right: var(--expand-collapse-button-nested-width, calc(${h.D} * -1px));
    }
    :host([selected])::after {
        right: calc(${f.vd} * 1px);
    }
    :host([expanded]) > .positioning-region .expand-collapse-glyph {
        transform: rotate(135deg);
    }
`,D=s.A.partial`((${p.Ss} / 2) * ${p.vR}) + ((${p.vR} * ${p.Br}) / 2)`,O=s.A`
    ${(0,o.V)("block")} :host {
        contain: content;
        position: relative;
        outline: none;
        color: ${v.l};
        background: ${g.Wl};
        cursor: pointer;
        font-family: ${b.O};
        --expand-collapse-button-size: calc(${h.D} * 1px);
        --tree-item-nested-width: 0;
    }

    :host(:focus) > .positioning-region {
        outline: none;
    }

    :host(:focus) .content-region {
        outline: none;
    }

    .positioning-region {
        display: flex;
        position: relative;
        box-sizing: border-box;
        border: calc(${f.XA} * 1px) solid transparent;
        height: calc((${h.D} + 1) * 1px);
    }

    :host(:${a.N}) .positioning-region {
        border: calc(${f.XA} * 1px) solid ${m.WN};
        border-radius: calc(${y.Pb} * 1px);
        color: ${v.l};
    }

    .positioning-region::before {
        content: "";
        display: block;
        width: var(--tree-item-nested-width);
        flex-shrink: 0;
    }

    .positioning-region:hover {
        background: ${g.oO};
    }

    .positioning-region:active {
        background: ${g.wO};
    }

    .content-region {
        display: inline-flex;
        align-items: center;
        white-space: nowrap;
        width: 100%;
        height: calc(${h.D} * 1px);
        margin-inline-start: calc(${p.vR} * 2px + 8px);
        font-size: ${w.K};
        line-height: ${w.Z};
        font-weight: 400;
    }

    .items {
        display: none;
        ${""} font-size: calc(1em + (${p.vR} + 16) * 1px);
    }

    .expand-collapse-button {
        background: none;
        border: none;
        outline: none;
        ${""} width: calc((${D} + (${p.vR} * 2)) * 1px);
        height: calc((${D} + (${p.vR} * 2)) * 1px);
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        cursor: pointer;
        margin: 0 6px;
    }

    .expand-collapse-glyph {
        width: 16px;
        height: 16px;
        transition: transform 0.1s linear;
        pointer-events: none;
        fill: ${v.l};
    }

    ::slotted([slot="start"]),
    ::slotted([slot="end"]) {
        display: flex;
        fill: currentcolor;
    }

    ::slotted(svg) {
        ${""} width: 16px;
        height: 16px;
    }

    ::slotted([slot="start"]) {
        ${""} margin-inline-end: calc(${p.vR} * 2px + 2px);
    }

    ::slotted([slot="end"]) {
        ${""} margin-inline-start: calc(${p.vR} * 2px + 2px);
    }

    :host([aria-expanded="true"]) > .items {
        display: block;
    }

    :host([disabled]) .content-region {
        opacity: ${$.q};
        cursor: ${l.Z};
    }

    :host([nested]) .content-region {
        position: relative;
        margin-inline-start: var(--expand-collapse-button-size);
    }

    :host([nested]) .expand-collapse-button {
        position: absolute;
    }

    :host([nested]) .expand-collapse-button:hover {
        background: ${S};
    }

    :host([selected]) .positioning-region {
        background: ${x.F7};
    }

    :host([selected]) .expand-collapse-button:hover {
        background: ${E};
    }

    :host([selected])::after {
        content: "";
        display: block;
        position: absolute;
        top: calc((${h.D} / 4) * 1px);
        width: 3px;
        height: calc((${h.D} / 2) * 1px);
        ${""} background: ${k.W_};
        border-radius: calc(${y.Pb} * 1px);
    }

    ::slotted(fluent-tree-item) {
        --tree-item-nested-width: 1em;
        --expand-collapse-button-nested-width: calc(${h.D} * -1px);
    }
`.withBehaviors(new d.t(M,F),(0,c.mr)(s.A`
            :host {
                forced-color-adjust: none;
                border-color: transparent;
                background: ${u.A.Field};
                color: ${u.A.FieldText};
            }
            :host .content-region {
                color: ${u.A.FieldText};
            }
            :host .content-region .expand-collapse-glyph,
            :host .content-region ::slotted([slot="start"]),
            :host .content-region ::slotted([slot="end"]) {
                fill: ${u.A.FieldText};
            }
            :host .positioning-region:hover,
            :host([selected]) .positioning-region {
                background: ${u.A.Highlight};
            }
            :host .positioning-region:hover .content-region,
            :host([selected]) .positioning-region .content-region {
                color: ${u.A.HighlightText};
            }
            :host .positioning-region:hover .content-region .expand-collapse-glyph,
            :host .positioning-region:hover .content-region ::slotted([slot="start"]),
            :host .positioning-region:hover .content-region ::slotted([slot="end"]),
            :host([selected]) .content-region .expand-collapse-glyph,
            :host([selected]) .content-region ::slotted([slot="start"]),
            :host([selected]) .content-region ::slotted([slot="end"]) {
                fill: ${u.A.HighlightText};
            }
            :host([selected])::after {
                background: ${u.A.Field};
            }
            :host(:${a.N}) .positioning-region {
                border-color: ${u.A.FieldText};
                box-shadow: 0 0 0 2px inset ${u.A.Field};
                color: ${u.A.FieldText};
            }
            :host([disabled]) .content-region,
            :host([disabled]) .positioning-region:hover .content-region {
                opacity: 1;
                color: ${u.A.GrayText};
            }
            :host([disabled]) .content-region .expand-collapse-glyph,
            :host([disabled]) .content-region ::slotted([slot="start"]),
            :host([disabled]) .content-region ::slotted([slot="end"]),
            :host([disabled])
                .positioning-region:hover
                .content-region
                .expand-collapse-glyph,
            :host([disabled])
                .positioning-region:hover
                .content-region
                ::slotted([slot="start"]),
            :host([disabled])
                .positioning-region:hover
                .content-region
                ::slotted([slot="end"]) {
                fill: ${u.A.GrayText};
            }
            :host([disabled]) .positioning-region:hover {
                background: ${u.A.Field};
            }
            .expand-collapse-glyph,
            ::slotted([slot="start"]),
            ::slotted([slot="end"]) {
                fill: ${u.A.FieldText};
            }
            :host([nested]) .expand-collapse-button:hover {
                background: ${u.A.Field};
            }
            :host([nested]) .expand-collapse-button:hover .expand-collapse-glyph {
                fill: ${u.A.FieldText};
            }
        `));var A=n(86699),T=n(96950);const I=(0,A.q)({expandCollapseGlyph:T.qy`
        <svg
            viewBox="0 0 16 16"
            xmlns="http://www.w3.org/2000/svg"
            class="expand-collapse-glyph"
        >
            <path
                d="M5.00001 12.3263C5.00124 12.5147 5.05566 12.699 5.15699 12.8578C5.25831 13.0167 5.40243 13.1437 5.57273 13.2242C5.74304 13.3047 5.9326 13.3354 6.11959 13.3128C6.30659 13.2902 6.4834 13.2152 6.62967 13.0965L10.8988 8.83532C11.0739 8.69473 11.2153 8.51658 11.3124 8.31402C11.4096 8.11146 11.46 7.88966 11.46 7.66499C11.46 7.44033 11.4096 7.21853 11.3124 7.01597C11.2153 6.81341 11.0739 6.63526 10.8988 6.49467L6.62967 2.22347C6.48274 2.10422 6.30501 2.02912 6.11712 2.00691C5.92923 1.9847 5.73889 2.01628 5.56823 2.09799C5.39757 2.17969 5.25358 2.30817 5.153 2.46849C5.05241 2.62882 4.99936 2.8144 5.00001 3.00369V12.3263Z"
            />
        </svg>
    `});class B extends r._{}const N=B.compose({name:`${i.c.prefix}-tree-item`,template:I,styles:O})},96751(t,e,n){"use strict";n.d(e,{I(){return h}});var r=n(56911),i=n(92011),s=n(23429),o=n(38493),a=n(60815),l=n(88458),c=n(35106);const u="ease-in-out";class h extends i.L{constructor(){super(...arguments),this.framesPerSecond=60,this.updatingItems=!1,this.speed=600,this.easing=u,this.flippersHiddenFromAT=!1,this.scrolling=!1,this.resizeDetector=null}get frameTime(){return 1e3/this.framesPerSecond}scrollingChanged(t,e){if(this.scrollContainer){const t=1==this.scrolling?"scrollstart":"scrollend";this.$emit(t,this.scrollContainer.scrollLeft)}}get isRtl(){return this.scrollItems.length>1&&this.scrollItems[0].offsetLeft>this.scrollItems[1].offsetLeft}connectedCallback(){super.connectedCallback(),this.initializeResizeDetector()}disconnectedCallback(){this.disconnectResizeDetector(),super.disconnectedCallback()}scrollItemsChanged(t,e){e&&!this.updatingItems&&s.L.enqueue(()=>this.setStops())}disconnectResizeDetector(){this.resizeDetector&&(this.resizeDetector.disconnect(),this.resizeDetector=null)}initializeResizeDetector(){this.disconnectResizeDetector(),this.resizeDetector=new window.ResizeObserver(this.resized.bind(this)),this.resizeDetector.observe(this)}updateScrollStops(){this.updatingItems=!0;const t=this.scrollItems.reduce((t,e)=>e instanceof HTMLSlotElement?t.concat(e.assignedElements()):(t.push(e),t),[]);this.scrollItems=t,this.updatingItems=!1}setStops(){this.updateScrollStops();const{scrollContainer:t}=this,{scrollLeft:e}=t,{width:n,left:r}=t.getBoundingClientRect();this.width=n;let i=0,s=this.scrollItems.map((t,n)=>{const{left:s,width:o}=t.getBoundingClientRect(),a=Math.round(s+e-r),l=Math.round(a+o);return this.isRtl?-l:(i=l,0===n?0:a)}).concat(i);s=this.fixScrollMisalign(s),s.sort((t,e)=>Math.abs(t)-Math.abs(e)),this.scrollStops=s,this.setFlippers()}validateStops(t=!0){const e=()=>!!this.scrollStops.find(t=>Math.abs(t)>0);return!e()&&t&&this.setStops(),e()}fixScrollMisalign(t){if(this.isRtl&&t.some(t=>t>0)){t.sort((t,e)=>e-t);const e=t[0];t=t.map(t=>t-e)}return t}setFlippers(){const t=this.scrollContainer.scrollLeft;this.previousFlipperContainer?.classList.toggle("disabled",0===t),this.scrollStops&&this.nextFlipperContainer?.classList.toggle("disabled",this.validateStops(!1)&&Math.abs(t)+this.width>=this.content?.offsetWidth||(this.scrollContainer?.offsetWidth??0)>=(this.content?.offsetWidth??0))}scrollInView(t,e=0,n){if("number"!=typeof t&&t&&(t=this.scrollItems.findIndex(e=>e===t||e.contains(t))),void 0!==t){n=n??e;const{scrollContainer:r,scrollStops:i,scrollItems:s}=this,{scrollLeft:o}=this.scrollContainer,{width:a}=r.getBoundingClientRect(),l=i[t],{width:c}=s[t].getBoundingClientRect(),u=l+c,h=o+e>l;if(h||o+a-n<u){const t=[...i].sort((t,e)=>h?e-t:t-e).find(t=>h?t+e<l:t+a-(n??0)>u)??0;this.scrollToPosition(t)}}}keyupHandler(t){switch(t.key){case"ArrowLeft":this.scrollToPrevious();break;case"ArrowRight":this.scrollToNext()}}scrollToPrevious(){this.validateStops();const t=this.scrollContainer.scrollLeft;let e=0;e=this.isRtl?this.scrollStops.findIndex((e,n)=>e<=t&&(n===this.scrollStops.length-1||this.scrollStops[n+1]<t)):this.scrollStops.findIndex((e,n)=>e>=t&&(n===this.scrollStops.length-1||this.scrollStops[n+1]>t));const n=Math.abs(this.scrollStops[e+1]);let r=this.scrollStops.findIndex(t=>Math.abs(t)+this.width>n);(r>=e||-1===r)&&(r=e>0?e-1:0),this.scrollToPosition(this.scrollStops[r],t)}scrollToNext(){this.validateStops();const t=this.scrollContainer.scrollLeft,e=this.scrollStops.findIndex(e=>Math.abs(e)>=Math.abs(t)),n=this.scrollStops.findIndex(e=>Math.abs(t)+this.width<=Math.abs(e));let r=e;n>e+2?r=n-2:e<this.scrollStops.length-2&&(r=e+1),this.scrollToPosition(this.scrollStops[r],t)}scrollToPosition(t,e=this.scrollContainer.scrollLeft){if(this.scrolling)return;this.scrolling=!0;const n=this.duration??Math.abs(t-e)/this.speed+"s";this.content.style.setProperty("transition-duration",n);const r=parseFloat(getComputedStyle(this.content).getPropertyValue("transition-duration")),i=e=>{e&&e.target!==e.currentTarget||(this.content.style.setProperty("transition-duration","0s"),this.content.style.removeProperty("transform"),this.scrollContainer.style.setProperty("scroll-behavior","auto"),this.scrollContainer.scrollLeft=t,this.setFlippers(),this.content.removeEventListener("transitionend",i),this.scrolling=!1)};if(0===r)return void i();this.content.addEventListener("transitionend",i);const s=this.scrollContainer.scrollWidth-this.scrollContainer.clientWidth;let o=this.scrollContainer.scrollLeft-Math.min(t,s);this.isRtl&&(o=this.scrollContainer.scrollLeft+Math.min(Math.abs(t),s)),this.content.style.setProperty("transition-property","transform"),this.content.style.setProperty("transition-timing-function",this.easing),this.content.style.setProperty("transform",`translateX(${o}px)`)}resized(){this.resizeTimeout&&(this.resizeTimeout=clearTimeout(this.resizeTimeout)),this.resizeTimeout=setTimeout(()=>{this.width=this.scrollContainer.offsetWidth,this.setFlippers()},this.frameTime)}scrolled(){this.scrollTimeout&&(this.scrollTimeout=clearTimeout(this.scrollTimeout)),this.scrollTimeout=setTimeout(()=>{this.setFlippers()},this.frameTime)}getScrollStops(){return this.scrollStops}getWidth(){return this.width}}(0,r.Cg)([(0,o.CF)({converter:o.R$}),(0,r.Sn)("design:type",Number)],h.prototype,"speed",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],h.prototype,"duration",void 0),(0,r.Cg)([o.CF,(0,r.Sn)("design:type",String)],h.prototype,"easing",void 0),(0,r.Cg)([(0,o.CF)({attribute:"flippers-hidden-from-at",converter:o.Bs}),(0,r.Sn)("design:type",Boolean)],h.prototype,"flippersHiddenFromAT",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Boolean)],h.prototype,"scrolling",void 0),(0,r.Cg)([a.sH,(0,r.Sn)("design:type",Array)],h.prototype,"scrollItems",void 0),(0,r.Cg)([(0,o.CF)({attribute:"view"}),(0,r.Sn)("design:type",String)],h.prototype,"view",void 0),(0,l.X)(h,c.qw)},96950(t,e,n){"use strict";n.d(e,{dj(){return D},kc(){return A},qy(){return T}});var r=n(19470),i=n(96293),s=n(72454),o=n(32625),a=n(93809),l=n(34188),c=n(42277),u=n(60815),h=n(29194),d=n(35727),f=n(22020);const p={[c.D.attribute]:c.d.setAttribute,[c.D.booleanAttribute]:c.d.setBooleanAttribute,[c.D.property](t,e,n){return t[e]=n},[c.D.content](t,e,n,r){if(null==n&&(n=""),function(t){return void 0!==t.create}(n)){t.textContent="";let e=t.$fastView;if(void 0===e)if((0,l.VS)(r)&&(0,l.VS)(n)&&void 0!==r.bindingViewBoundaries[this.targetNodeId]&&r.hydrationStage!==f.xW.hydrated){const t=r.bindingViewBoundaries[this.targetNodeId];e=n.hydrate(t.first,t.last)}else e=n.create();else t.$fastTemplate!==n&&(e.isComposed&&(e.remove(),e.unbind()),e=n.create());e.isComposed?e.needsBindOnly&&(e.needsBindOnly=!1,e.bind(r.source,r.context)):(e.isComposed=!0,e.bind(r.source,r.context),e.insertBefore(t),t.$fastView=e,t.$fastTemplate=n)}else{const e=t.$fastView;void 0!==e&&e.isComposed&&(e.isComposed=!1,e.remove(),e.needsBindOnly?e.needsBindOnly=!1:e.unbind()),t.textContent=n}},[c.D.tokenList](t,e,n){var r;const i=`${this.id}-t`,s=null!==(r=t[i])&&void 0!==r?r:t[i]={v:0,cv:Object.create(null)},o=s.cv;let a=s.v;const l=t[e];if(null!=n&&n.length){const t=n.split(/\s+/);for(let e=0,n=t.length;e<n;++e){const n=t[e];""!==n&&(o[n]=a,l.add(n))}}if(s.v=a+1,0!==a){a-=1;for(const t in o)o[t]===a&&l.remove(t)}},[c.D.event](){}};class v{constructor(t){this.dataBinding=t,this.updateTarget=null,this.aspectType=c.D.content}createHTML(t){return d.VK.interpolation(t(this))}createBehavior(){var t;if(null===this.updateTarget){const e=p[this.aspectType],n=null!==(t=this.dataBinding.policy)&&void 0!==t?t:this.policy;if(!e)throw r.Zx.error(1205);this.data=`${this.id}-d`,this.updateTarget=n.protect(this.targetTagName,this.aspectType,this.targetAspect,e)}return this}bind(t){var e;const n=t.targets[this.targetNodeId],r=(0,l.VS)(t)&&t.hydrationStage&&t.hydrationStage!==f.xW.hydrated;switch(this.aspectType){case c.D.event:n[this.data]=t,n.addEventListener(this.targetAspect,this,this.dataBinding.options);break;case c.D.content:t.onUnbind(this);default:const i=null!==(e=n[this.data])&&void 0!==e?e:n[this.data]=this.dataBinding.createObserver(this,this);if(i.target=n,i.controller=t,r&&(this.aspectType===c.D.attribute||this.aspectType===c.D.booleanAttribute)){i.bind(t);break}this.updateTarget(n,this.targetAspect,i.bind(t),t)}}unbind(t){const e=t.targets[this.targetNodeId].$fastView;void 0!==e&&e.isComposed&&(e.unbind(),e.needsBindOnly=!0)}handleEvent(t){const e=t.currentTarget[this.data];if(e.isBound){u.ao.setEvent(t);const n=this.dataBinding.evaluate(e.source,e.context);u.ao.setEvent(null),!0!==n&&t.preventDefault()}}handleChange(t,e){const n=e.target,r=e.controller;this.updateTarget(n,this.targetAspect,e.bind(r),r)}}h.dg.define(v,{aspected:!0});const g=(t,e)=>`${t}.${e}`,b={},m={index:0,node:null};function y(t){t.startsWith("fast-")||r.Zx.warn(1204,{name:t})}const w=new Proxy(document.createElement("div"),{get(t,e){y(e);const n=Reflect.get(t,e);return(0,i.Tn)(n)?n.bind(t):n},set:(t,e,n)=>(y(e),Reflect.set(t,e,n))});class ${constructor(t,e,n){this.fragment=t,this.directives=e,this.policy=n,this.proto=null,this.nodeIds=new Set,this.descriptors={},this.factories=[]}addFactory(t,e,n,r,i){var s,o;this.nodeIds.has(n)||(this.nodeIds.add(n),this.addTargetDescriptor(e,n,r)),t.id=null!==(s=t.id)&&void 0!==s?s:(0,d.Hn)(),t.targetNodeId=n,t.targetTagName=i,t.policy=null!==(o=t.policy)&&void 0!==o?o:this.policy,this.factories.push(t)}freeze(){return this.proto=Object.create(null,this.descriptors),this}addTargetDescriptor(t,e,n){const r=this.descriptors;if("r"===e||"h"===e||r[e])return;if(!r[t]){const e=t.lastIndexOf("."),n=t.substring(0,e),r=parseInt(t.substring(e+1));this.addTargetDescriptor(n,t,r)}let i=b[e];if(!i){const r=`_${e}`;b[e]=i={get(){var e;return null!==(e=this[r])&&void 0!==e?e:this[r]=this[t].childNodes[n]}}}r[e]=i}createView(t){const e=this.fragment.cloneNode(!0),n=Object.create(this.proto);n.r=e,n.h=null!=t?t:w;for(const t of this.nodeIds)n[t];return new f.NA(e,this.factories,n)}}function x(t,e,n,r,i,s=!1){const a=n.attributes,l=t.directives;for(let c=0,u=a.length;c<u;++c){const f=a[c],p=f.value,g=d.iX.parse(p,l);let b=null;null===g?s&&(b=new v((0,o.a)(()=>p,t.policy)),h.dg.assignAspect(b,f.name)):b=E.aggregate(g,t.policy),null!==b&&(n.removeAttributeNode(f),c--,u--,t.addFactory(b,e,r,i,n.tagName))}}function k(t,e,n){let r=0,i=e.firstChild;for(;i;){const e=C(t,n,i,r);i=e.node,r=e.index}}function C(t,e,n,r){const s=g(e,r);switch(n.nodeType){case 1:x(t,e,n,s,r),k(t,n,s);break;case 3:return function(t,e,n,r,s){const o=d.iX.parse(e.textContent,t.directives);if(null===o)return m.node=e.nextSibling,m.index=s+1,m;let a,l=a=e;for(let e=0,c=o.length;e<c;++e){const c=o[e];0!==e&&(s++,r=g(n,s),a=l.parentNode.insertBefore(document.createTextNode(""),l.nextSibling)),(0,i.Kg)(c)?a.textContent=c:(a.textContent=" ",h.dg.assignAspect(c),t.addFactory(c,n,r,s,null)),l=a}return m.index=s+1,m.node=l.nextSibling,m}(t,n,e,s,r);case 8:const o=d.iX.parse(n.data,t.directives);null!==o&&t.addFactory(E.aggregate(o),e,s,r,null)}return m.index=r+1,m.node=n.nextSibling,m}const S="TEMPLATE",E={compile(t,e,n=c.d.policy,r){let s;if((0,i.Kg)(t)){s=document.createElement(S),s.innerHTML=n.createHTML(t);const e=s.content.firstElementChild;null!==e&&e.tagName===S&&(s=e)}else s=t;s.content.firstChild||s.content.lastChild||s.content.appendChild(document.createComment(""));const o=document.adoptNode(s.content),a=new $(o,e,n);var l,u;return x(a,"",s,"h",0,!0),l=o.firstChild,u=e,(l&&8==l.nodeType&&null!==d.iX.parse(l.data,u)||1===o.childNodes.length&&Object.keys(e).length>0)&&o.insertBefore(document.createComment(""),o.firstChild),k(a,o,"r"),m.node=null,a.freeze()},setDefaultStrategy(t){this.compile=t},aggregate(t,e=c.d.policy){if(1===t.length)return t[0];let n,r,s=!1;const o=t.length,l=t.map(t=>(0,i.Kg)(t)?()=>t:(n=t.sourceAspect||n,s=s||t.dataBinding.isVolatile,r=r||t.dataBinding.policy,t.dataBinding.evaluate)),u=new v((0,a.U)((t,e)=>{let n="";for(let r=0;r<o;++r)n+=l[r](t,e);return n},null!=r?r:e,s));return h.dg.assignAspect(u,n),u}},M=/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/,F=Object.create(null);class D{constructor(t,e=F){this.html=t,this.factories=e}createHTML(t){const e=this.factories;for(const n in e)t(e[n]);return this.html}}function O(t,e,n,r=h.dg.getForInstance(t)){if(r.aspected){const n=M.exec(e);null!==n&&h.dg.assignAspect(t,n[2])}return t.createHTML(n)}D.empty=new D(""),h.dg.define(D);class A{constructor(t,e={},n,r){this.policy=r,this.result=null,this.html=t,this.factories=e,this.opCodes=n}compile(){return null===this.result&&(this.result=E.compile(this.html,this.factories,this.policy,this.opCodes)),this.result}create(t){return this.compile().createView(t)}inline(){return new D((0,i.Kg)(this.html)?this.html:this.html.innerHTML,this.factories)}withPolicy(t){if(this.result)throw r.Zx.error(1208);if(this.policy)throw r.Zx.error(1207);return this.policy=t,this}render(t,e,n){const r=this.create(n);return r.bind(t),r.appendTo(e),r}static createFromOpCodes(t){return new A("",void 0,t,void 0)}static create(t,e,n){let r="";const i=Object.create(null),s=t=>{var e;const n=null!==(e=t.id)&&void 0!==e?e:t.id=(0,d.Hn)();return i[n]=t,n};for(let n=0,i=t.length-1;n<i;++n){const i=t[n],o=e[n];let a;r+=i;let l=A.createBindingDirectiveFromExpression(o);l||(a=h.dg.getForInstance(o),l=o),r+=O(l,i,s,a)}return new A(r+t[t.length-1],i,void 0,n)}static createBindingDirective(t,e){let n;const r=t=>{var e;const r=null!==(e=t.id)&&void 0!==e?e:t.id=(0,d.Hn)();return n=t,r};{const n=t,i=e;let s,o=A.createBindingDirectiveFromExpression(i);o||(s=h.dg.getForInstance(i),o=i),O(o,n,r,s)}return n}static createBindingDirectiveFromExpression(t){let e;if((0,i.Tn)(t))e=new v((0,a.U)(t));else if(t instanceof s.O)e=new v(t);else if(!h.dg.getForInstance(t)){const n=t;e=new v((0,o.a)(()=>n))}return e}}(0,r.rV)(A);const T=(t,...e)=>{if(Array.isArray(t)&&Array.isArray(t.raw))return A.create(t,e);throw r.Zx.error(1206)};T.partial=t=>new D(t)},97004(t,e,n){"use strict";n.d(e,{Z(){return s},y(){return r}});var r,i=n(5291);function s(t){return i.q.create(t,t,t)}!function(t){t[t.LightMode=1]="LightMode",t[t.DarkMode=.23]="DarkMode"}(r||(r={}))},97482(t,e,n){"use strict";n.d(e,{R(){return c},g(){return l}});var r=n(64187),i=n(74849),s=n(86856);const o=i.A`
    .scroll-prev {
        right: auto;
        left: 0;
    }

    .scroll.scroll-next::before,
    .scroll-next .scroll-action {
        left: auto;
        right: 0;
    }

    .scroll.scroll-next::before {
        background: linear-gradient(to right, transparent, var(--scroll-fade-next));
    }

    .scroll-next .scroll-action {
        transform: translate(50%, -50%);
    }
`,a=i.A`
    .scroll.scroll-next {
        right: auto;
        left: 0;
    }

    .scroll.scroll-next::before {
        background: linear-gradient(to right, var(--scroll-fade-next), transparent);
        left: auto;
        right: 0;
    }

    .scroll.scroll-prev::before {
        background: linear-gradient(to right, transparent, var(--scroll-fade-previous));
    }

    .scroll-prev .scroll-action {
        left: auto;
        right: 0;
        transform: translate(50%, -50%);
    }
`,l=i.A`
    .scroll-area {
        position: relative;
    }

    div.scroll-view {
        overflow-x: hidden;
    }

    .scroll {
        bottom: 0;
        pointer-events: none;
        position: absolute;
        right: 0;
        top: 0;
        user-select: none;
        width: 100px;
    }

    .scroll.disabled {
        display: none;
    }

    .scroll::before,
    .scroll-action {
        left: 0;
        position: absolute;
    }

    .scroll::before {
        background: linear-gradient(to right, var(--scroll-fade-previous), transparent);
        content: "";
        display: block;
        height: 100%;
        width: 100%;
    }

    .scroll-action {
        pointer-events: auto;
        right: auto;
        top: 50%;
        transform: translate(-50%, -50%);
    }

    ::slotted(fluent-flipper) {
        opacity: 0;
        transition: opacity 0.2s ease-in-out;
    }

    .scroll-area:hover ::slotted(fluent-flipper) {
        opacity: 1;
    }
`.withBehaviors(new s.t(o,a)),c=i.A`
    ${(0,r.V)("block")} :host {
        --scroll-align: center;
        --scroll-item-spacing: 4px;
        contain: layout;
        position: relative;
    }

    .scroll-view {
        overflow-x: auto;
        scrollbar-width: none;
    }

    ::-webkit-scrollbar {
        display: none;
    }

    .content-container {
        align-items: var(--scroll-align);
        display: inline-flex;
        flex-wrap: nowrap;
        position: relative;
    }

    .content-container ::slotted(*) {
        margin-right: var(--scroll-item-spacing);
    }

    .content-container ::slotted(*:last-child) {
        margin-right: 0;
    }
`},98228(t,e,n){"use strict";n.d(e,{a(){return w}});var r=n(56911),i=n(50106),s=n(23429),o=n(60815),a=n(38493),l=n(50180),c=n(5096),u=n(17884),h=n(35106),d=n(88458),f=n(56863);class p extends u.U{}class v extends((0,f.rf)(p)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}const g="inline",b="list",m="both",y="none";class w extends v{constructor(){super(...arguments),this._value="",this.filteredOptions=[],this.filter="",this.listboxId=(0,l.NF)("listbox-"),this.open=!1}formResetCallback(){super.formResetCallback(),this.setDefaultSelectedOption(),this.firstSelectedOption?this.updateValue():this.value=this.initialValue??""}validate(){super.validate(this.control)}get isAutocompleteInline(){return this.autocomplete===g||this.isAutocompleteBoth}get isAutocompleteList(){return this.autocomplete===b||this.isAutocompleteBoth}get isAutocompleteBoth(){return this.autocomplete===m}openChanged(){if(this.open)return this.ariaControls=this.listboxId,this.ariaExpanded="true",s.L.enqueue(()=>this.setPositioning()),this.focusAndScrollOptionIntoView(),void s.L.enqueue(()=>this.focus());this.ariaControls="",this.ariaExpanded="false"}get options(){return o.cP.track(this,"options"),this.filteredOptions.length?this.filteredOptions:this._options}set options(t){this._options=t,o.cP.notify(this,"options")}placeholderChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.placeholder=this.placeholder)}get value(){return o.cP.track(this,"value"),this._value}set value(t){const e=`${this._value}`;if(this.$fastController.isConnected&&this.options){const e=this.options.findIndex(e=>e.text.toLowerCase()===t.toLowerCase()),n=this.options[this.selectedIndex]?.text,r=this.options[e]?.text;this.selectedIndex=n!==r?e:this.selectedIndex,t=this.firstSelectedOption?.text||t}e!==t&&(this._value=t,super.valueChanged(e,t),o.cP.notify(this,"value"))}clickHandler(t){if(!this.disabled){if(this.open){const e=t.target.closest("option,[role=option]");if(!e||e.disabled)return;this.selectedOptions=[e],this.control.value=e.text,this.clearSelectionRange(),this.updateValue(!0)}return this.open=!this.open,this.open&&this.control.focus(),!0}}connectedCallback(){super.connectedCallback(),this.value&&(this.initialValue=this.value)}disabledChanged(t,e){super.disabledChanged&&super.disabledChanged(t,e),this.ariaDisabled=this.disabled?"true":"false"}disconnectedCallback(){this.cleanup?.(),super.disconnectedCallback()}filterOptions(){this.autocomplete&&this.autocomplete!==y||(this.filter="");const t=this.filter.toLowerCase();this.filteredOptions=this._options.filter(t=>t.text.toLowerCase().startsWith(this.filter.toLowerCase())),this.isAutocompleteList&&(this.filteredOptions.length||t||(this.filteredOptions=this._options),this._options.forEach(t=>{t.hidden=!this.filteredOptions.includes(t)}))}focusAndScrollOptionIntoView(){this.contains(document.activeElement)&&(this.control.focus(),this.firstSelectedOption&&requestAnimationFrame(()=>{this.firstSelectedOption?.scrollIntoView({block:"nearest"})}))}focusoutHandler(t){if(this.updateValue(),!this.open)return!0;const e=t.relatedTarget;this.isSameNode(e)?this.focus():this.options&&this.options.includes(e)||(this.open=!1)}inputHandler(t){if(this.filter=this.control.value,this.filterOptions(),"deleteContentBackward"===t.inputType||!this.filter.length)return!0;this.isAutocompleteList&&!this.open&&(this.open=!0),this.isAutocompleteInline&&this.filteredOptions.length&&(this.selectedOptions=[this.filteredOptions[0]],this.selectedIndex=this.options.indexOf(this.firstSelectedOption),this.setInlineSelection())}keydownHandler(t){const e=t.key;if(t.ctrlKey||t.shiftKey)return!0;switch(e){case"Enter":this.updateValue(!0),this.isAutocompleteInline&&(this.filter=this.value),this.open=!1,this.clearSelectionRange();break;case"Escape":if(this.isAutocompleteInline||(this.selectedIndex=-1),this.open){this.open=!1;break}this.value="",this.control.value="",this.filter="",this.filterOptions();break;case"Tab":if(this.updateValue(),!this.open)return!0;t.preventDefault(),this.open=!1;break;case"ArrowUp":case"ArrowDown":if(this.filterOptions(),!this.open){this.open=!0;break}this.filteredOptions.length>0&&super.keydownHandler(t),this.isAutocompleteInline&&(this.updateValue(),this.setInlineSelection());break;default:return!0}}keyupHandler(t){switch(t.key){case"ArrowLeft":case"ArrowRight":case"Backspace":case"Delete":case"Home":case"End":this.filter=this.control.value,this.selectedIndex=-1,this.filterOptions()}}selectedIndexChanged(t,e){if(this.$fastController.isConnected){if((e=(0,c.AB)(-1,this.options.length-1,e))!==this.selectedIndex)return void(this.selectedIndex=e);super.selectedIndexChanged(t,e)}}selectPreviousOption(){!this.disabled&&this.selectedIndex>=0&&(this.selectedIndex=this.selectedIndex-1)}setDefaultSelectedOption(){if(this.$fastController.isConnected&&this.options){const t=this.options.findIndex(t=>null!==t.getAttribute("selected")||t.selected);this.selectedIndex=t,!this.dirtyValue&&this.firstSelectedOption?this.value=this.firstSelectedOption.text:this.value="",this.setSelectedOptions()}}setInlineSelection(){this.firstSelectedOption&&(this.control.value=this.firstSelectedOption.text,this.control.focus(),this.control.setSelectionRange(this.filter.length,this.control.value.length,"backward"))}setPositioning(){this.$fastController.isConnected&&(this.cleanup=(0,i.ll)(this,this.listbox,async()=>{const{middlewareData:t,x:e,y:n}=await(0,i.rD)(this,this.listbox,{placement:"bottom",strategy:"fixed",middleware:[(0,i.UU)(),(0,i.Ej)({apply:({availableHeight:t,rects:e})=>{Object.assign(this.listbox.style,{maxHeight:`${t}px`,width:`${e.reference.width}px`})}}),(0,i.jD)()]});if(t.hide?.referenceHidden)return this.open=!1,void this.cleanup();Object.assign(this.listbox.style,{position:"fixed",top:"0",left:"0",transform:`translate(${e}px, ${n}px)`})}))}selectedOptionsChanged(t,e){this.$fastController.isConnected&&this._options.forEach(t=>{t.selected=e.includes(t)})}slottedOptionsChanged(t,e){super.slottedOptionsChanged(t,e),this.updateValue()}updateValue(t){this.$fastController.isConnected&&(this.value=this.firstSelectedOption?.text||this.control.value),t&&this.$emit("change")}clearSelectionRange(){const t=this.control.value.length;this.control.setSelectionRange(t,t)}}(0,r.Cg)([(0,a.CF)({attribute:"autocomplete",mode:"fromView"}),(0,r.Sn)("design:type",Object)],w.prototype,"autocomplete",void 0),(0,r.Cg)([(0,a.CF)({attribute:"open",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],w.prototype,"open",void 0),(0,r.Cg)([a.CF,(0,r.Sn)("design:type",String)],w.prototype,"placeholder",void 0);class ${}(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Object)],$.prototype,"ariaAutoComplete",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Object)],$.prototype,"ariaControls",void 0),(0,d.X)($,u.r),(0,d.X)(w,h.qw,$)},98264(t,e,n){"use strict";n.d(e,{m(){return b}});var r=n(56911),i=n(92011),s=n(38493),o=n(83781);const a="separator";class l extends i.L{constructor(){super(...arguments),this.role=a,this.orientation=o.t.horizontal}}(0,r.Cg)([s.CF,(0,r.Sn)("design:type",String)],l.prototype,"role",void 0),(0,r.Cg)([s.CF,(0,r.Sn)("design:type",String)],l.prototype,"orientation",void 0);var c=n(37180),u=n(74849),h=n(64187),d=n(74838),f=n(26920),p=n(22683);const v=u.A`
    ${(0,h.V)("block")} :host {
        box-sizing: content-box;
        height: 0;
        margin: calc(${d.vR} * 1px) 0;
        border: none;
        border-top: calc(${f.XA} * 1px) solid ${p.hb};
    }
`,g=n(96950).qy`
        <template
            role="${t=>t.role}"
            aria-orientation="${t=>t.orientation}"
        ></template>
    `,b=class extends l{}.compose({name:`${c.c.prefix}-divider`,template:g,styles:v})},99577(t,e,n){"use strict";n.d(e,{EO(){return $},F2(){return T},Go(){return k},H$(){return I},TC(){return x},UM(){return C},WB(){return M},X$(){return E},g8(){return y},gj(){return S},u9(){return O},xE(){return p},yD(){return w}});var r,i=n(15454),s=n(69912),o=n(96271),a=n(62044),l=n(5410),c=n(88383),u=n(12839),h=n(50090),d=n(18622),f="3.2.8",p="1DS-Web-JS-"+f,v="Microsoft_ApplicationInsights_BypassAjaxInstrumentation",g="withCredentials",b="timeout",m=((r={})[0]=0,r[2]=6,r[1]=1,r[3]=7,r[4098]=6,r[4097]=1,r[4099]=7,r),y=Boolean((0,c.YE)());function w(t){return!(t===d.m5||(0,a.hX)(t))}function $(t){if(t){var e=t.indexOf("-");if(e>-1)return t.substring(0,e)}return d.m5}function x(t,e,n){if(!e&&!w(e)||"string"!=typeof t)return null;var r=typeof e;if("string"===r||"number"===r||"boolean"===r||(0,a.cy)(e))e={value:e};else if("object"!==r||i.J$.call(e,"value")){if((0,a.hX)(e.value)||e.value===d.m5||!(0,a.Kg)(e.value)&&!(0,a.Et)(e.value)&&!(0,a.Lm)(e.value)&&!(0,a.cy)(e.value))return null}else e={value:n?JSON.stringify(e):e};if((0,a.cy)(e.value)&&!D(e.value))return null;if(!(0,a.hX)(e.kind)){if((0,a.cy)(e.value)||!F(e.kind))return null;e.value=e.value.toString()}return e}function k(t,e,n){var r=-1;if(!(0,a.b0)(t))if(e>0&&(32===e?r=8192:e<=13&&(r=e<<5)),function(t){if(t>=0&&t<=9)return!0;return!1}(n))-1===r&&(r=0),r|=n;else{var i=m[A(t)]||-1;-1!==r&&-1!==i?r|=i:6===i&&(r=i)}return r}function C(t,e,n){var r;return void 0===n&&(n=!0),t&&(r=t.get(e),n&&r&&decodeURIComponent&&(r=decodeURIComponent(r))),r||d.m5}function S(t){void 0===t&&(t="D");var e=(0,o.aq)();return"B"===t?e="{"+e+"}":"P"===t?e="("+e+")":"N"===t&&(e=e.replace(/-/g,d.m5)),e}function E(t,e,n,r,s){var o={},l=!1,c=0,u=arguments.length,h=arguments;for("[object Boolean]"===Object[i.vR].toString.call(h[0])&&(l=h[0],c++);c<u;c++){t=h[c];(0,a.z)(t,function(t,e){l&&e&&(0,a.Gv)(e)?(0,a.cy)(e)?(o[t]=o[t]||[],(0,a.Iu)(e,function(e,n){e&&(0,a.Gv)(e)?o[t][n]=E(!0,o[t][n],e):o[t][n]=e})):o[t]=E(!0,o[t],e):o[t]=e})}return o}Boolean((0,c.zk)());var M=o.UU;function F(t){return 0===t||t>0&&t<=13||32===t}function D(t){return t.length>0}function O(t,e){var n=t;n.timings=n.timings||{},n.timings.processTelemetryStart=n.timings.processTelemetryStart||{},n.timings.processTelemetryStart[e]=M()}function A(t){var e=0;if(null!=t){var n=typeof t;"string"===n?e=1:"number"===n?e=2:"boolean"===n?e=3:n===i._1&&(e=4,(0,a.cy)(t)?(e=4096,t.length>0&&(e|=A(t[0]))):i.J$.call(t,"value")&&(e=8192|A(t.value)))}return e}function T(){return!!(0,c.EH)("chrome")}function I(t,e,n,r,i,s){function o(t,e,n){try{t[e]=n}catch(t){}}void 0===r&&(r=!1),void 0===i&&(i=!1);var a=new XMLHttpRequest;return r&&o(a,v,r),n&&o(a,g,n),a.open(t,e,!i),n&&o(a,g,n),!i&&s&&o(a,b,s),a}i.bA,i._1,i.bA,a.Iu,a.rD,a.W$,a.KT,a.cG,a._u,c.lV,a.Kg,a.Et,a.Lm,a.Tn,a.cy,a.Gv,a.EH,c.Uf,a._u,c.PV,u.gi,u.It,a.r,l.ee,l.So,a.Cv,a.z,a.Ed,a.b0,a.hX,a.mQ,a.Tn,a.Gv,a.$P,a.cy,a.bJ,a.Kg,a.Et,a.Lm,a._u,a.Iu,a.rD,a.W$,a.KT,a.EH,h.AQ,a.cG,a.r,l.So,a.x3,c.lT,o.aq,o.UU,s.Si,s.Z1,s.VN,s.yc,s.k5,o.cL},99900(t,e,n){"use strict";n.d(e,{i(){return r},u(){return i}});const r=Object.freeze({prefix:"msft",shadowRootMode:"open",registry:customElements}),i=Object.freeze({prefix:"msn",shadowRootMode:"open",registry:customElements})}}]);