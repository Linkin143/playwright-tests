"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-golf"],{4968(e,t,r){r.d(t,{f(){return l}});var a=r(64187),i=r(74849),o=r(42792),n=r(99657),s=r(36452);const l=i.A.partial`position: relative; z-index: ${n.D};`;i.A`
    ${o.e}
    ${o.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},17471(e,t,r){r.r(t),r.d(t,{SportsTable(){return M}});var a=r(56911),i=r(92011),o=r(48751),n=r(62047),s=r(41123),l=r(61138),d=r(86856),c=r(74849),p=r(22131),h=r(4968),g=r(12640);const u=c.A` .table-card{color:rgba(255,255,255,1)}.card-header{color:rgba(255,255,255,1)}.card-header-tag{box-shadow:inset 0px 0px 0px 2px rgba(255,153,164,1)}.card-header-tag >span:nth-of-type(1){background:rgba(255,153,164,1);color:rgba(68,39,38,1)}.card-header-tag >span:nth-of-type(2){background:rgba(68,39,38,1);color:rgba(255,153,164,1)}.table-cell{border-top:1px solid rgba(255,255,255,0.07)}.no-border{border-top:none}.underlay{opacity:0.16}`,x=c.A` .line >img{margin-left:2px}.line >img.extra-margin{margin-left:4px}.line{padding-right:0px;padding-left:4px}.head-cell{padding-right:0px;padding-left:4px}.card-header-tag >span:nth-of-type(2){border-top-right-radius:0;border-bottom-right-radius:0;border-top-left-radius:3px;border-bottom-left-radius:3px}`,f=c.A` .table-container{text-decoration:none}.clickable{${h.f}}.table-card{margin-top:8px;width:268px;height:fit-content;background:none;color:${o.l};border-radius:8px;padding:8px 12px;box-sizing:border-box}.table-card.fill-card{margin-top:0px;padding:0px 12px;background:inherit}.card-header{display:flex;justify-content:space-between;align-items:baseline;padding:0 0 8px;color:${o.l}}.card-header >div{display:flex;font-size:12px;font-weight:600}.card-header-tag{height:18px;line-height:${n.e};box-shadow:inset 0px 0px 0px 4px rgba(196,43,28,1);border-radius:4px;padding:2px 2px;box-sizing:border-box}.card-header-tag >span{display:inline-block;font-size:${n.t};font-weight:600;box-sizing:border-box;padding:0px 2px}.card-header-tag >span:nth-of-type(1){background:rgba(196,43,28,1);color:rgba(255,255,255,1)}.card-header-tag >span:nth-of-type(2){background:rgba(255,255,255,1);color:rgba(196,43,28,1);border-top-right-radius:3px;border-bottom-right-radius:3px}.grid-table{display:grid;width:244px;grid-template-columns:minmax(20px,auto) 1fr minmax(auto,42px) minmax(auto,70px);grid-template-rows:repeat(9,28px)}.table-cell{position:relative;border-top:1px solid rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.line{font-size:${n.t};font-style:normal;font-weight:400;display:flex;align-items:center;padding:0 4px 0 0;width:100%;z-index:1}.line.large-font{font-size:${s.K}}.line > div{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.pre-text{font-size:${n.t};font-weight:600;width:14px;min-width:14px;padding-right:6px}.pre-text.large-font{font-size:${s.K};font-weight:400;width:16px}.head-cell{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;border-top:1px solid rgba(0,0,0,0.06);font-size:${l.k};font-style:normal;font-weight:600;display:flex;align-items:center;padding:0 4px 0 0}.hidden{display:none}.no-border{border-top:none}.overflow{overflow:visible}.line > sup{margin:0 0 4px 1px}.right{justify-content:end}.center{justify-content:center}.left{justify-content:start}.top{align-items:flex-start}.middle{align-items:center}.bottom{align-items:flex-end}.bold{font-weight:600}.line > img{margin-right:2px;height:16px;width:16px}.line > img.extra-margin{margin-right:4px}.iconround > img{border-radius:50%}img.icon-20{height:20px;width:20px;min-width:20px}.line > img.icon-24{height:24px;width:24px;min-width:24px}.font-xs{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.font-s{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.font-m{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.font-l{font-size:var(--smtc-text-ramp-lg-item-body-font-size,16px);line-height:var(--smtc-text-ramp-lg-item-body-line-height,26px)}.align-right{justify-content:flex-end;padding-right:0}.secondary{color:var(--smtc-foreground-ctrl-neutral-secondary-rest,#4c4642)}.underlay{position:absolute;top:-2px;height:calc(100% + 4px);width:100%;background:#0178A7;opacity:0.08}.first-column .underlay{border-radius:12px 0px 0px 12px;width:calc(100% + 4px);left:-4px}.last-column .underlay{border-radius:0px 12px 12px 0px}.no-padding .line,.no-padding .head-cell{padding:0px}.full-width .table-card{width:100%}.cplt .table-card{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320)}`.withBehaviors(new d.t(null,x),new g.N(null,u),(0,p.mr)(c.A` :host{forced-color-adjust:auto}`));var b=r(96950),m=r(39957),v=r(69259);const $=b.qy`
    ${e=>void 0!==e.viewModel.data.title?b.qy`
        <div class="card-header" style="${e=>e.viewModel.headerStyles}">
            <div style="${e=>e.viewModel.data.titleStyles}">${e=>e.viewModel.data.title}</div>
            ${e=>void 0!==e.viewModel.data.subTitle?b.qy`
                <div class="card-header-tag">
                    <span>${e=>e.viewModel.data.tagName}</span>
                    <span>${e=>e.viewModel.data.subTitle}</span>
                </div>`:""}
            ${e=>void 0!==e.viewModel.data.subTitleText?b.qy`
                <div style="${e=>e.viewModel.data.subTitleStyles}">
                    <span>${e=>e.viewModel.data.subTitleText}</span>
                </div>`:""}
        </div>
    `:""}
`,y=b.qy`
    ${(0,m.ux)(e=>e.getHeaderValues(),b.qy`
        <div class="head-cell ${e=>void 0!==e.class?e.class:""}" style="${e=>e.textStyles}">
            ${e=>void 0!==e.icon?b.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null}"
            />`:""}
            ${e=>e.value}
        </div>
    `)}
`,w=b.qy`
    ${(0,m.ux)(e=>e.getAllBodyCells(),()=>b.qy`
    <div class="table-cell ${e=>void 0!==e.cellClass?e.cellClass:""}">
        ${e=>e.isHightlighted?b.qy`<div class="underlay"></div>`:""}
        <div class="line ${e=>void 0!==e.class?e.class:""}">
            ${e=>void 0!==e.preText?b.qy`<div class="pre-text ${e=>void 0!==e.preTextClass?e.preTextClass:""}" style="${e=>e.preTextStyles}">${e.preText}</div>`:""}
            ${e=>void 0!==e.icon?b.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null} ${e=>e.icon?"":"hidden"}"
                onerror="this.style.display='none'"
            />`:""}
            ${e=>b.qy`<div style="${e=>e.textStyles}" title=${e=>e.value}>${e.value}</div>`}
            ${e=>void 0!==e.index?b.qy`<sup>${e.index}</sup>`:""}
        </div>
        <div class="line ${e=>void 0!==e.classL2?e.classL2:""}">
            ${e=>b.qy`<div>${e.valueL2}</div>`}
        </div>
    </div>
`)}
`,k=b.qy`
    <a
        class="${e=>e.viewModel.clickThroughUrl?"clickable":""} table-container ${e=>e.viewModel.tableClass}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="${e=>e.viewModel.clickThroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}" 
    >
        ${e=>e.viewModel.isHeaderAboveTheTable?$:""}
        <div
            class="table-card ${e=>e.viewModel.fillFullCard?"fill-card":""}"
            style="${e=>e.viewModel.tableStyles}"
        >
            ${e=>e.viewModel.isHeaderAboveTheTable?"":$}
            <div class="grid-table"
                style="${e=>`\n                    grid-template-columns: ${e.viewModel.columnStyle};\n                    grid-template-rows: ${e.viewModel.rowStyle};\n                    ${e.viewModel.gridStyles};\n                `}">
                ${e=>e.getHeaderValues().length>0?y:""}
                ${w}
            </div>
        </div>
    </a>
`,z=b.qy`
    ${(0,v.z)(e=>null!=e.viewModel,k)}
`;var S=r(92079);class T extends S.a{constructor(){super(...arguments),this.getKeys=()=>this.viewModel.data.keys,this.getHeaderValues=()=>{const{header:e}=this.viewModel.data;return e?this.getKeys().map(t=>e[t]):[]},this.isLarge=()=>"_1x_3y"===this.viewModel.cardSize,this.getAllBodyCells=()=>{const e=[],t=this.getKeys();return this.viewModel.data.body.forEach(r=>{t.forEach(t=>e.push(r[t]))}),e}}}let M=class extends T{};M=(0,a.Cg)([(0,i.E)({name:"sports-table",template:z,styles:f,shadowOptions:{delegatesFocus:!0}})],M)},42792(e,t,r){r.d(t,{R7(){return x},e(){return g},kc(){return u},nH(){return h}});var a=r(57416),i=r(55153),o=r(95239),n=r(26920),s=r(48751),l=r(64187),d=r(22131),c=r(74849),p=r(50882);const h=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,g=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${n.XA} * 1px) solid ${i.cu};
        border-radius: calc((${a.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${i.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${i.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${i.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${i.QG} * 1px);
        height: calc(${i.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${i.QG} * 1px);
        height: calc((${i.l8} * 2px) + (${i.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${i.QG} * 2px) + (${i.Sn} * 1px));
        height: calc((${i.l8} * 2px) + (${i.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${i.QG} * 2px) + (${i.Sn} * 1px));
        height: calc(${i.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,d.mr)(c.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),x=c.A`
    ${g}
    ${h}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},42966(e,t,r){r.d(t,{U(){return s}});var a=r(49150),i=r(23587),o=r(79811),n=r(58792);class s extends i.Bc{constructor(){super(...arguments),this.getSubTitle=e=>{const{matchData:t}=e,{state:r}=t.gameState;return t.winner&&r===i.T0.Final&&e.cardSize===a.uE._1x_1y?`1 ${t.winner}`:t.gameSubTitle},this.getDes=e=>{const{matchData:t}=e,{state:r}=t.gameState;if(r===i.T0.PreGame||r===i.T0.InProgress){const e=(0,o.yn)(t.gameStartDateTime),r=t.gameEndDateTime?(0,o.yn)(t.gameEndDateTime):null,a=e.toLocaleString(n.T3.CurrentMarket||"en-us",{month:"short"}),i=r?r.toLocaleString(n.T3.CurrentMarket||"en-us",{month:"short"}):null,s=`${a} ${e.getDate()}`;let l="";return r&&(l=a===i?`-${r.getDate()}`:`-${i} ${r.getDate()}`),`${s}${l}`}return r===i.T0.Live?this.transformerProvider.strings.inProgress:r===i.T0.Final?this.transformerProvider.strings.sportsStateFinal:""},this.getDesLine2=e=>{const{matchData:t}=e,{state:r}=t.gameState;if(r===i.T0.Final){const e=(0,o.yn)(t.gameEndDateTime);return`${e.toLocaleString(n.T3.CurrentMarket||"en-us",{month:"short"})} ${e.getDate()}`}}}async transform(e){this.isInDarkMode=(0,o.jJ)();return{viewModel:await this.getCurrentViewModel(e)}}async getCurrentViewModel(e){const{telemetryBuilder:t}=this.transformerProvider,{state:r}=e.matchData.gameState,a=(0,o.iK)(e.matchData.gameIcon,!1,this.transformerProvider.config.teamImageInfoEnhanced);return{isDarkModeTheme:this.isInDarkMode,telemetryTag:t.createNavClickTelemetryTag(e.parentTelemetryObject,{...e.telemetryConstants,name:i.BP.Game}),icon:a,title:e.matchData.gameTitle,subTitle:this.getSubTitle(e),des:this.getDes(e),desLine2:this.getDesLine2(e),desClass:r===i.T0.Live?"live":"",linkTarget:"_blank",clickthroughUrl:(0,o.Ot)(e.matchData.gameCenterUrl)}}}},54653(e,t,r){r.r(t),r.d(t,{SportsSpotlightGolf(){return f}});var a=r(56911),i=r(92079);class o extends i.a{}var n=r(92011),s=r(74849),l=r(48751);const d=s.A` .spotlight-race-content{color:${l.l};
        display: grid;
        grid-template-rows: 1fr auto auto;
        row-gap: 6px;
        height: 100%;
        box-sizing: border-box;
    }
`;var c=r(96950),p=r(69259);const h=c.qy`
    <sports-simple-match
        :viewModel="${e=>{var t;return null===(t=e.viewModel.matchView)||void 0===t?void 0:t.viewModel}}"
    ></sports-simple-match>
`,g=c.qy`
    <sports-table
        :viewModel="${e=>e.viewModel.tableData}"
    ></sports-table>
`,u=c.qy`
    <div class="sports-spotlight-content ${e=>e.viewModel.cardSize}" data-t="${e=>e.viewModel.telemetryTag}">
        ${h}
        ${g}
    </div>
`,x=c.qy`
    ${(0,p.z)(e=>null!=e.viewModel,u)}
`;let f=class extends o{};f=(0,a.Cg)([(0,n.E)({name:"sports-spotlight-golf",template:x,styles:d,shadowOptions:{delegatesFocus:!0}})],f)},84553(e,t,r){r.r(t),r.d(t,{SportsSimpleMatchTransformer(){return h.U},SportsSpotlightGolfTransformer(){return p}});var a=r(49150),i=r(23587),o=r(79811),n=r(96950),s=r(58792),l=r(97266),d=r(22341),c=r(85312);class p extends i.Bc{constructor(){super(...arguments),this.iconUrl=e=>(0,o.iK)(e,!1,this.transformerProvider.config.teamImageInfoEnhanced),this.timeString=e=>{if(!e)return"-";const t=(0,o.yn)(e);return(0,o.ry)(t,s.T3.CurrentMarket||"en-us")}}async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,o.jJ)();const r=await this.getCurrentViewModel(e);return{viewTemplate:n.qy`
                <sports-spotlight-golf
                    :viewModel="${r}"
                ></sports-spotlight-golf>
            `}}async getCurrentViewModel(e){const{telemetryBuilder:t}=this.transformerProvider;return{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.SportsSpotlightGolfCard}),sportsSpotlightData:e.sportsSpotlightData,matchView:await this.getMatchView(e),tableData:await this.getTableData(e)}}async getMatchView(e){if(!e.sportsSpotlightData||!e.sportsSpotlightData.match)return void(0,d.vV)(c.Ax,"Spotlight Golf Match data missing",`market=${s.T3.CurrentMarket}`,JSON.stringify(e));const t={parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,matchData:e.sportsSpotlightData.match,cardSize:this.cardSize};return await this.transformerProvider.generateView(t,i.hi.SportsSimpleMatch)}getTableTitle(e){const{gameState:t}=e;return t.state===i.T0.Live||t.state===i.T0.InProgress?this.transformerProvider.strings.liveLeaderboard:t.state===i.T0.Final?this.transformerProvider.strings.finalResult:void 0}getTableKey(e){const{gameState:t}=e;return t.state===i.T0.PreGame?["player","teeTime"]:t.state===i.T0.Final?["pos","player","score"]:["pos","player","thru","r1","r2","r3","r4","total"]}getTableHeader(e){const{strings:t}=this.transformerProvider,{gameState:r,gameStartDateTime:a,roundInfo:n}=e;if(r.state===i.T0.PreGame){const e=(0,o.yn)(a),r=(0,o.AL)(e,s.T3.CurrentMarket||"en-us");return{player:{value:`${n} | ${(new l.e).localizedWeekday(e,s.T3.CurrentMarket||"en-us")} · ${r}`,class:"no-border"},teeTime:{value:t.teeTime,class:"right no-border"}}}return r.state===i.T0.Final?{pos:{value:t.positionShortName},player:{value:t.player||t.palyer},score:{value:t.score,class:"right"}}:{pos:{value:t.positionShortName},player:{value:t.player||t.palyer},thru:{value:"Thru"},r1:{value:"R1",class:"right"},r2:{value:"R2",class:"right"},r3:{value:"R3",class:"right"},r4:{value:"R4",class:"right"},total:{value:t.total,class:"right"}}}getTableBody(e){const{gameState:t,participants:r}=e,a={cellClass:"bottom",class:"right"};return t.state===i.T0.PreGame?r.map(e=>({player:{value:e.name,icon:this.iconUrl(e.imageId)},teeTime:{value:this.timeString(e.teetime),...a}})):t.state===i.T0.Final?r.map((e,t)=>({pos:{value:`${t+1}`},player:{value:e.name,icon:this.iconUrl(e.imageId)},score:{value:e.total,...a}})):r.map((e,t)=>{var r,i,o,n;return{pos:{value:`${t+1}`},player:{value:e.name,icon:this.iconUrl(e.imageId)},thru:{value:e.thru,cellClass:"middle",class:"center"},r1:{value:(null===(r=e.roundInfo)||void 0===r?void 0:r.r1)||"-",...a},r2:{value:(null===(i=e.roundInfo)||void 0===i?void 0:i.r2)||"-",...a},r3:{value:(null===(o=e.roundInfo)||void 0===o?void 0:o.r3)||"-",...a},r4:{value:(null===(n=e.roundInfo)||void 0===n?void 0:n.r4)||"-",...a},total:{value:e.total,...a}}})}getColumnStyle(e){const{gameState:t}=e;return t.state===i.T0.PreGame?"1fr minmax(auto, 62px)":t.state===i.T0.Final?"minmax(auto, 32px) 1fr minmax(auto, 62px)":"minmax(auto, 32px) minmax(0, 1fr) 26px 20px 20px 20px 20px minmax(auto, 32px)"}getRowCount(e){const{participantInfo:t}=e.sportsSpotlightData,{gameState:r}=t;let o=3;return r.state===i.T0.PreGame&&(o=4),this.cardSize===a.uE._1x_3y&&(o=9),o}async getTableData(e){const{telemetryBuilder:t}=this.transformerProvider,{participantInfo:r}=e.sportsSpotlightData;if(!r||!r.participants||0===r.participants.length)return void(0,d.vV)(c.Ax,"Spotlight Golf table data missing",`market=${s.T3.CurrentMarket}`,JSON.stringify(e));const a=this.getTableTitle(r),o=this.getTableKey(r),n=this.getTableHeader(r),l=this.getRowCount(e),p=this.getTableBody(r).slice(0,l),h={title:a,tagName:r.liveInfo,keys:o,header:n,body:p};return{telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:`${i.BP.SportsSpotlightGolfCard}Table`}),cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,data:h,columnStyle:this.getColumnStyle(r),rowStyle:`repeat(${p.length+1}, 27px)`}}}var h=r(42966);Promise.resolve().then(r.bind(r,54653)),Promise.resolve().then(r.bind(r,91035)),Promise.resolve().then(r.bind(r,17471))},91035(e,t,r){r.r(t),r.d(t,{SportsSimpleMatch(){return $}});var a=r(56911),i=r(92011),o=r(74849),n=r(22131),s=r(41123),l=r(61138),d=r(12640),c=r(4968);const p=o.A` .match-card{color:rgba(255,255,255,1)}.live{color:rgba(255,153,164,1)}`,h=o.A` .match-card{width:268px;height:64px;text-decoration:none;padding:8px 6px;border-radius:8px;display:flex;flex-direction:row;justify-content:space-between;align-items:center;background:none;box-sizing:border-box;color:rgba(0,0,0,0.83);${c.f}}.match-icon{display:flex;border:none;cursor:pointer;width:32px;height:32px;border-radius:8px;align-items:center;justify-content:center;background:transparent;padding:0 4px}.match-content{display:flex;flex-direction:column;min-width:0;flex-grow:1}.content-item{display:inline-block;height:20px;font-size:14px;font-weight:600;line-height:${s.Z};letter-spacing:0em;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.match-subtitle{display:flex;justify-content:space-between;font-weight:400;font-size:${l.k};
        line-height: ${l.F}}.match-subtitle > span:nth-of-type(1){overflow:hidden;text-overflow:ellipsis}.match-des{display:flex;flex-direction:column;font-weight:600;font-size:${l.k};
        line-height: ${l.F};letter-spacing:0em;text-align:center;white-space:nowrap}.des-line2{font-weight:400}.live{color:rgba(196,43,28,1);font-weight:600;font-size:${l.k};
        line-height: ${l.F};
    }
`.withBehaviors(new d.N(null,p),(0,n.mr)(o.A` :host{forced-color-adjust:auto}`));var g=r(96950),u=r(69259),x=r(50180);const f=g.qy`
    <a class="match-card" data-t="${e=>e.viewModel.telemetryTag}"
        href="${e=>e.viewModel.clickthroughUrl?e.viewModel.clickthroughUrl:void 0}"
        target="${e=>e.viewModel.linkTarget}"
    >
        ${(0,u.z)(e=>e.viewModel.icon&&!(0,x.oT)(e.viewModel.icon),g.qy`
            <img class="match-icon" role="presentation" src="${e=>e.viewModel.icon}"/>`)}
        <div class="match-content">
            <div class="content-item">${e=>e.viewModel.title}</div>
            <div class="content-item match-subtitle">
                <span>${e=>e.viewModel.subTitle}</span>
                ${(0,u.z)(e=>!e.viewModel.desLine2,g.qy`<span class="${e=>e.viewModel.desClass?e.viewModel.desClass:""}">${e=>e.viewModel.des}</span>`)}
            </div>
        </div>
        ${(0,u.z)(e=>e.viewModel.desLine2&&!(0,x.oT)(e.viewModel.desLine2),g.qy`
            <div class="match-des">
                <div class="${e=>e.viewModel.desClass?e.viewModel.desClass:""}">${e=>e.viewModel.des}</div>
                <div class="des-line2">${e=>e.viewModel.desLine2}</div>
            </div>
        `)}
    </a>
`,b=g.qy`
    ${(0,u.z)(e=>null!=e.viewModel,f)}
`;var m=r(92079);class v extends m.a{}let $=class extends v{};$=(0,a.Cg)([(0,i.E)({name:"sports-simple-match",template:b,styles:h,shadowOptions:{delegatesFocus:!0}})],$)},92079(e,t,r){r.d(t,{a(){return n}});var a=r(56911),i=r(92011),o=r(31525);let n=class extends i.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,a.Cg)([o.x],n)},99657(e,t,r){r.d(t,{D(){return n},I(){return o}});var a=r(45755);const{create:i}=a.G,o=i("sloppy-click-z-index",1),n=i("click-z-index",1)}}]);