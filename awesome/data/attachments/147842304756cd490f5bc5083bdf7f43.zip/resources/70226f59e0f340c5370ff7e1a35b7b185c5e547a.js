(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["cs-core-desktop_libs_dist_design-system_z-index_js-libs_channel-page-utils_dist_UrlUtilities_-9b558a"],{297(t,e,i){"use strict";i.d(e,{T(){return n}});var r=i(61138),o=i(48751);const n=i(74849).A` cs-attribution::part(content){display:flex;width:100%}cs-attribution .ad-provider{text-overflow:ellipsis;overflow:hidden;white-space:nowrap;color:${o.l} !important}cs-attribution .ad-provider-text{text-decoration:none;color:inherit;font-size:${r.k};text-overflow:ellipsis;position:relative;z-index:2}.ad-provider-text{text-decoration:none;color:inherit;font-size:${r.k};text-overflow:ellipsis;position:relative;z-index:2}.ad-provider-text:focus{outline:auto}.blendInStyle2,.blendInStyle3,.blendInStyle4{display:flex;align-items:center;width:100%}.blendInStyle1 .ad-slug{line-height:15px}.blendInStyle2 .ad-slug,.blendInStyle3 .ad-slug,.blendInStyle4 .ad-slug{flex-shrink:0;z-index:2}.blendInStyle2 .bi-ad-slug2{margin-right:8px}.blendInStyle3{justify-content:space-between}.blendInStyle4 .ad-choice{margin-inline-start:0}.blendInStyle4 .bi-ad-slug4{margin-left:4px;margin-right:8px}.blendInStyle4 .ad-footer{z-index:2}.blendInStyle4 .ad-choice-svg{display:flex}.native-ad-logo{width:16px;height:16px}`},903(t,e,i){"use strict";i.d(e,{D(){return d},G(){return s}});var r=i(93552),o=i(77367);let n,a;const s=()=>{a=new Map,n=new IntersectionObserver(t=>{for(const[t,e]of a.entries()){if(!(t&&e&&e.cardElement&&e.extTelemetry))return;const i=l(e.cardElement),r=i&&JSON.parse(i),o=r&&r.ext;if(!o||!o.row||!o.col)return;const n=`${o.row}-${o.col}`;t!==n&&(a.delete(t),a.set(n,{cardElement:e.cardElement,extTelemetry:o}))}t.forEach(t=>{const e=t.target,i=e&&l(e),r=i&&JSON.parse(i),o=r&&r.ext;if(!o||!o.row||!o.col)return;const n=`${o.row}-${o.col}`;t.isIntersecting?a.set(n,{cardElement:e,extTelemetry:o}):a.has(n)&&a.delete(n)})},{threshold:.99}),window.addEventListener("beforeunload",()=>{if("hidden"!==document.visibilityState)for(const[t,e]of a.entries()){if(!(t&&e&&e.cardElement&&e.extTelemetry))return;const i=t.split("-");if(isNaN(Number(i[0]))||isNaN(Number(i[1])))return;const r=parseFloat(i[0]),o=parseFloat(i[1]);c(e,a.get(`${r+1}-${o}`));c(e,a.get(`${r}-${o+1}`))}})},d=t=>{n&&t&&n.observe(t)};function l(t){if(t.classList&&t.classList.contains("infopane")){const e=t.querySelector("cs-article-card"),i=e&&e.shadowRoot&&e.shadowRoot.querySelector("cs-content-card");return i&&i.anchorTelemetryTag}return t.anchorTelemetryTag?t.anchorTelemetryTag:t.getAttribute("data-t")?t.getAttribute("data-t"):void 0}function c(t,e){if(!(t&&e&&e.cardElement&&e.extTelemetry&&t!==e))return;const i=t.cardElement.getBoundingClientRect(),n=e.cardElement.getBoundingClientRect();if(0===i.height||0===i.width||0===n.height||0===n.width)return;if(!(i.top>n.bottom||i.right<n.left||i.bottom<n.top||i.left>n.right)){const a=t.extTelemetry,s=e.extTelemetry;o.YT.sendAppErrorEvent({...r.ABd,message:"Feed cards are overlapping",pb:{...r.ABd.pb,customMessage:`{"${t.cardElement.id}": { "position": ${JSON.stringify(i)}, "slot": ${a.slot}, "template": "${a.template}", "row": ${a.row}, "col": ${a.col} },"${e.cardElement.id}": { "position": ${JSON.stringify(n)}, "slot": ${s.slot}, "template": "${s.template}", "row": ${s.row}, "col": ${s.col}}}`}})}}},1302(t,e,i){"use strict";i.d(e,{Be(){return r},WI(){return a},h(){return o},y3(){return n}});const r="TTSR.FirstSection",o=12,n=304,a=.08},1413(t,e,i){"use strict";i.d(e,{P(){return n},y(){return a}});var r=i(96950),o=i(82774);function n(t,e){return e?.some(e=>e.slot===t)}function a(t){const e=t.slotName??"";return r.qy`
        <div id="${e}" class="${e}" part="${e}">
            <slot
                name="${e}"
                ${t.slottedRef?(0,o.e)(t.slottedRef):""}
            >
                ${t.slottedDefault??""}
            </slot>
        </div>
    `}},3817(t,e,i){"use strict";i.d(e,{$n(){return u},IK(){return v},SF(){return g},U8(){return p}});var r=i(96950),o=i(69259),n=i(14475),a=i(33477),s=i(77793),d=i(24277);const l=r.qy`<div class="container"><div class="popup"><div class="popup-offset"><span class="popup-text">${t=>t.assets&&t.assets.disclaimer}</span></div><div class="popup-arrow"><span class="popup-arrow-svg"></span></div></div></div>`,c=r.qy`<a class="disclaimer" href="${t=>t.destinationUrl}" target="${n.z._blank}" title="${t=>t.localizedStrings&&t.localizedStrings.nativeAdDisclaimerText}" ${(0,s.Ib)(!0,!1)} data-t="${t=>{var e;return null===(e=t.adTelemetryContext)||void 0===e||null===(e=e.destination)||void 0===e?void 0:e.getMetadataTag()}}"><span class="disclaimer-svg"></span>${l}</a>`,h=r.qy`<a class="${t=>{var e;return!t.adChoiceIconUrl||t.hideAdLabelAndAdChoice||null!==(e=t.template)&&void 0!==e&&e.enableAdChoiceInCardActions?"ad-choice-hidden":(0,d.s4)(t.enableSafeAds,"ad-choice")}} ${t=>t.template&&t.template.useMobileAdChoice?"ad-choice-mobile":""} ${t=>t.cardSize==a.uE._1x_2y||t.cardSize==a.uE._2x_1y?"ad-choice-mono":""} ${t=>t.cardSize==a.uE._2x_2y?"ad-choice-mono-wide":""}" href="${t=>t.adChoiceIconUrl}" target="${t=>t.isThirdParty?n.z._self:n.z._blank}" @click="${(t,e)=>!t.adCardClickCallback||t.adCardClickCallback(e.event,t.adChoiceIconUrl)}" title="${t=>t.localizedStrings&&t.localizedStrings.nativeAdAdChoiceText}" data-t="${t=>{var e;return null===(e=t.adTelemetryContext)||void 0===e||null===(e=e.adChoice)||void 0===e?void 0:e.getMetadataTag()}}"><span class="ad-choice-svg"></span></a>`,u=r.qy`<div class="${t=>(0,d.s4)(t.enableSafeAds,"ad-footer")}" slot="${t=>(t=>4===t.enableBlendInAdSlugStyle?"":(0,d.s4)(t.enableSafeAds,"footer-end"))(t)}">${(0,o.z)(t=>t.assets&&t.assets.disclaimer,c)} ${(0,o.z)(t=>{var e;return!(null!==(e=t.template)&&void 0!==e&&e.enableNewAdChoice||t.disableAdChoice)},h)}</div>`,v=r.qy`<div class="ad-choice-container ad-choice-footer-start" slot="footer-start">${(0,o.z)(t=>t.assets&&t.assets.disclaimer,c)} ${(0,o.z)(t=>{var e;return!(null!==(e=t.template)&&void 0!==e&&e.enableNewAdChoice||t.disableAdChoice)},h)}</div>`,p=r.qy`<div class="ad-choice-container" slot="attribution">${(0,o.z)(t=>t.assets&&t.assets.disclaimer,c)} ${(0,o.z)(t=>{var e;return!(null!==(e=t.template)&&void 0!==e&&e.enableNewAdChoice||t.disableAdChoice)},h)}</div>`,g=r.qy`<div class="ad-choice-container">${(0,o.z)(t=>t.assets&&t.assets.disclaimer,c)} ${(0,o.z)(t=>{var e;return!(null!==(e=t.template)&&void 0!==e&&e.enableNewAdChoice||t.disableAdChoice)},h)}</div>`},6791(t,e,i){"use strict";i.d(e,{f(){return o}});var r=i(50645);class o{constructor(){this.config={},this.strings={},this.initialized=!1}async initConfig(t){var e,i;this.initialized||(this.config=await this.getConfigFromRef(t)||{},this.strings=(null===(e=this.config)||void 0===e?void 0:e.localizedStrings)||{},this.initialized=!!this.config&&!(null===(i=this.config)||void 0===i||!i.localizedStrings))}getConfig(){return this.config}getLocStrings(){return this.strings}async getConfigFromRef(t){try{const e=(null==t?void 0:t.configRef)||this.configRef,i=await r.L.getConfig(e);return null==i?void 0:i.properties}catch(t){return{}}}}},7895(t,e,i){"use strict";i.d(e,{T(){return d},s(){return s}});var r=i(58914),o=i(74849),n=i(89580),a=i(4283);const s=o.A` [size="_1x_1y"] .card-title{font-size:${n.Y};line-height:20px}[size="_1x_2y"] .card-title{font-size:18px;line-height:${n.v}}[size="_2x_2y"] .card-title{font-size:22px;line-height:26px}.breaking-news-tag{background-color:${a.IR};
        border-radius: 3px;
        color: white;
        padding: 0 5px;
    }
`,d=o.A`
    ${r.l}
    ${s}
`},8363(t,e,i){"use strict";i.d(e,{X(){return S}});var r=i(22977),o=i(62096),n=i(297),a=i(56930),s=i(33273),d=i(40073),l=i(62128),c=i(75988),h=i(2713),u=i(16077),v=i(56237),p=i(74849),g=i(4126),f=i(58914),m=i(12640),x=i(16548),b=i(52699),y=i(13187),w=i(69904);const $=p.A`
:host(:not(.infopane-slide):not([cf-visible])[feeds-3-design])::part(action-tray){padding:12px 0px 0px 0px}:host(:not(.infopane-slide):not([cf-visible])[feeds-3-design]) .card-image{border-radius:var(--borderRadiusLarge,${b.U9});height:auto}:host(:not(.infopane-slide):not([cf-visible])[feeds-3-design]) cs-content-card::part(content){padding:calc(${y.IU} * 2px)}:host(:not(.infopane-slide):not([cf-visible])[feeds-3-design])::part(text){--content-card-heading-line-height:${w.Oc};
    padding: ${y.fI} 0px 0px 0px}:host(:not(.infopane-slide):not([cf-visible])[size="_1x_2y"][feeds-3-design]),:host(:not(.infopane-slide):not([cf-visible])[size="_1x_2y"][feeds-3-design]) cs-card{height:324px}.native-video-media{display:block;z-index:300;clip-path:inset(0% round 8px)}`;var _=i(72499);const k=p.A` .native-video-media{display:block;z-index:300;clip-path:inset(0% round 8px)}`,z=p.A`
:host(:not(.infopane-slide):not([cf-visible])[adaptive-image])::part(heading){-webkit-line-clamp:1}:host(:not(.infopane-slide):not([cf-visible])[adaptive-image]) .card-image{width:auto;height:220px;margin-top:16px;justify-self:center;border-radius:var(--borderRadiusLarge,${b.U9})}:host(:not(.infopane-slide):not([cf-visible])[adaptive-image])::part(text){padding-top:8px}`;var C=i(57403);const S=p.A`
    ${x.ll}
    ${r.B}
    ${o.J}
    ${n.T}
    ${a.p}
    ${s.O}
    ${d.W}
    ${l.u}
    ${c.p}
    ${h.t}
    ${u.H}
    ${f.V}
    ${v.x}
    ${_.h}
    ${k}
    ${C.l} @media (forced-colors:active){[size="_2x_2y"] ::part(gradient){background-color:linear-gradient(180deg,var(--image-gradient-overlay-start-color) 0%,var(--image-gradient-overlay-end-color) 100%)}[size="_2x_2y"] ::part(text),[size="_2x_2y"] ::part(action-tray){background-color:var(--image-gradient-overlay-end-color)}}cs-card.withCustomTheme{--default-native-ad-card-bg:linear-gradient( var(--gradient-angle),var(--customized-native-ad-card-fill-color,var(--gradient-start-color)) 35.59%,var(--customized-native-ad-card-secondary-color,var(--gradient-end-color)) 100% );background:var(--customized-native-ad-card-bg,var(--default-native-ad-card-bg))}cs-card.withCustomTheme cs-content-card{--neutral-foreground-rest:var(--customized-native-ad-card-text-color)}cs-card[size="_1x_2y"].font-tracking-v1 ::part(heading){letter-spacing:1.6px}cs-card[size="_1x_2y"].font-tracking-v2 ::part(heading){letter-spacing:2.6px}cs-card[size="_1x_2y"].font-weight-normal ::part(heading){font-weight:normal}`.withBehaviors(new g.o("feeds3Design",!0,$),new g.o("adaptiveImage",!0,z),new m.N(null,x.Wk),new m.N(null,C.G))},10809(t,e,i){"use strict";i.d(e,{D(){return s}});var r=i(18272),o=i(2171),n=i(6791);class a extends n.f{constructor(){super(...arguments),this.configRef={experienceType:"SuperComponentData",instanceSrc:"default"}}static getInstance(){return o.vv.get("__SuperComponentDataHelper__",()=>new a)}}const s=(0,r.G)(a)},10894(t,e,i){"use strict";i.d(e,{i(){return d}});var r=i(4126),o=i(74849),n=i(58914),a=i(41123);const s=o.A` :host::part(media-info){display:none}cs-content-card[size="_1x_2y"] span.card-title{font-size:${a.K};
        line-height: ${a.Z};
    }
`,d=o.A`
    ${n.l} :host cs-content-card{--video-transition-delay:0.4s;--video-transition-start-duration:0.4s;--video-transition-end-duration:0.4s}:host cs-content-card.hover-preview-animation-disabled{--video-transition-delay:0;--video-transition-start-duration:0;--video-transition-end-duration:0}:host([size="_1x_2y"]) cs-card cs-content-card div[slot="media"]{overflow:hidden}:host([size="_1x_2y"]):not([immersive-card]) cs-card cs-content-card img.card-image{height:156px}:host([size="_1x_2y"]) cs-card cs-content-card[immersive-card]::part(heading){-webkit-line-clamp:var(--heading-max-lines,2)}:host([size="_1x_2y"]) cs-card cs-content-card[immersive-card]::part(action-tray){padding:4px var(--content-padding) var(--action-tray-padding) var(--content-padding)}.video-placeholder{width:100%;position:absolute;height:var(--video-placeholder-height);object-fit:var(--video-placeholder-object-fit)}[size="_1x_1y"] .video-placeholder{position:inherit}:host([size="_1x_2y"]) cs-card cs-content-card::part(media-info){margin-inline-start:16px;margin-bottom:8px}[slot="media-info"]{background-color:rgb(0,0,0,0.54);font-weight:600;border-radius:4px;line-height:var(--type-ramp-plus-1-font-size);z-index:1}:host cs-card cs-content-card:not([hover-preview-enabled]) [slot="media-info"],:host cs-card cs-content-card:not([hover-preview-enabled]) .media-info{display:none}:host cs-card cs-content-card[hover-preview-enabled]:hover::part(media-info){opacity:1}:host cs-card cs-content-card[hover-preview-enabled]:not(:hover)::part(media-info){opacity:0}video{border-top-left-radius:calc(var(--layer-corner-radius) * 1px);border-top-right-radius:calc(var(--layer-corner-radius) * 1px);background-color:black}video[is-portrait]{object-fit:contain}:host cs-content-card[hover-preview-enabled].horizontal-align-preview-badge::part(text){display:grid;grid-template-columns:auto auto 1fr}:host cs-content-card[hover-preview-enabled].horizontal-align-preview-badge::part(heading),:host cs-content-card[hover-preview-enabled].horizontal-align-preview-badge::part(abstract){grid-column:span 3}:host cs-content-card[hover-preview-enabled].horizontal-align-preview-badge::part(media-info){margin-inline-start:5px}`.withBehaviors(new r.o("enablePreviewOnScroll",!1,s))},12628(t,e,i){"use strict";i.d(e,{A(){return b}});var r=i(79454),o=i(31782),n=i(69329),a=i(28160),s=i(8481),d=i(5569),l=i(96950),c=i(58914),h=i(74849),u=i(75988);const v=h.A`
    ${u.p}
`,p=h.A`
    ${c.l}
    ${v}
`;var g=i(2665);const f=d.d.compose({name:"cs-article-card-no-hide-story",styles:p,template:(0,g._)({attribution:l.qy`${r.Au}`,footerStart:l.qy`${o.xZ}`,footerEnd:l.qy`${n.IL}`,hideStory:l.qy`${a.Z}`,title:l.qy`${s.B2}`})});var m=i(84056),x=i(65614);const b=()=>{(0,m.J)(),f.define(x.G.registry)}},13187(t,e,i){"use strict";i.d(e,{DA(){return l},EF(){return f},IU(){return v},Lv(){return m},MY(){return $},P1(){return p},Qk(){return k},Sl(){return o},TX(){return n},U9(){return a},UJ(){return x},cP(){return r},cT(){return y},dd(){return w},fI(){return h},gY(){return b},gu(){return g},gw(){return s},k9(){return c},rC(){return u},sF(){return d},tM(){return C},xD(){return _},zn(){return z}});const r="158px",o="324px",n="146px",a="462px",s="304px",d="620px",l="300px",c="612px",h="12px",u="8px",v="8",p="var(--max-width-card-adaptive-1u)",g="var(--min-width-card-adaptive-2c)",f="var(--max-width-card-adaptive-2c)",m="var(--min-width-card-adaptive)",x="var(--min-height-adaptive)",b="var(--max-height-adaptive)",y="var(--gutter-size-adaptive)",w="var(--width-card-1u)",$="var(--width-card-2c)",_="var(--width-card-3c)",k="var(--height-card-1u-px)",z="var(--height-card-15u)",C="var(--height-card-15u-px)"},16038(t,e,i){"use strict";i.d(e,{m(){return v}});var r=i(65614),o=i(13312),n=i(55153),a=i(7896),s=i(74849),d=i(64187);const l=s.A`
    ${(0,d.V)("grid")}

    :host {
        font-family: ${a.O};
        width: auto;
        grid-auto-columns: calc(${n.QG} * 1px);
        grid-auto-row: calc(${n.l8} * 1px);
        grid-gap: calc(${n.Sn} * 1px);
    }
`;var c=i(39957),h=i(96950);const u=h.qy`
    <template @keydown="${(t,e)=>t.handleKeyDown(e.event)}">
        ${(0,c.ux)(t=>t.childrenLayout,h.qy`
                ${(t,e)=>e.parent.selectTemplate(t)}
            `)}
    </template>
`,v=o.tA.compose({name:`${r.G.prefix}-feed-layout`,styles:l,template:u})},16077(t,e,i){"use strict";i.d(e,{H(){return r}});const r=i(74849).A` [class*="card-description"]{font-style:normal;font-weight:400;line-height:20px;display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden}[size="_1x_2y"] [class*="card-description"]{font-size:14px}[size="_2x_2y"] [class*="card-description"]{font-size:16px;padding-bottom:1px}.card-description-1{-webkit-line-clamp:1}.card-description-2{-webkit-line-clamp:2}.card-description-3{-webkit-line-clamp:3}`},18270(t,e,i){"use strict";i.d(e,{E(){return p}});var r=i(90905),o=i(18284),n=i(46417),a=i(36042),s=i(58792),d=i(80895),l=i(22760),c=i(58960),h=i(66345);const u="winWidgets"==s.T3.AppType?"dashboardscroll":"scroll",v="superApp"==s.T3.AppType;class p{get options(){return this._options}static getInstance(t){return p.instance||(p.instance=new p,t&&(p.instance._options={...t})),p.instance}getVideoRect(t){return t?t.getBoundingClientRect():{with:0,height:0,x:0,y:0,top:0,bottom:0,left:0}}constructor(){this.playerPreviewInfoMap=new Map,this.animationEffectCardList=[],this.inViewPortRatio=.1,this.checkActivePlayerInterval=null,this.isEnabled=!0,this.mouseEnterCallbackListeners=new Set,this._options={enableScrollPreview:!1,enableFasterPlayer:!1},this.handleBatteryChargingChange=()=>{this.battery.charging?this.determineActiveVideo():this.pauseAllVideos()},this.handleVisibilityChange=(()=>{const t="winWidgets"==s.T3.AppType;document.hidden||t&&!d.F_.get(2)?this.pauseAllVideos():this.playPreviewController(this.activePreviewController,"scroll")}).bind(this),this.pauseAllVideos=()=>{this.playerPreviewInfoMap.forEach(t=>{t.controller.pause()}),this.previewState=null},this.resetPreviewState=t=>{var e;t===(null===(e=this.previewState)||void 0===e?void 0:e.controller)&&(this.previewState=null)},this.calculateViewportBounds=(0,o.A)(t=>({upperBound:-1*t*this.inViewPortRatio,lowerBound:(window.innerHeight||document.documentElement.clientHeight)+t*this.inViewPortRatio})),this.getInViewportRatio=t=>{const{top:e=0,bottom:i=0,height:r}=t.getBoundingClientRect(),{upperBound:o,lowerBound:n}=this.calculateViewportBounds(r);let a=0;switch(!0){case e<o:a=i/r;break;case i>n:a=(e-window.innerHeight)/r;break;case i<n&&e>o:a=1;break;default:a=0}return a},this.determineActiveVideo=()=>this.options.enableFasterPlayer?(0,a.A)(async()=>{this.getActiveVideoAndPlay()},100)():(0,r.A)(async()=>{this.getActiveVideoAndPlay()},350)(),this.getActiveVideoAndPlay=async()=>{var t,e;const[i,r]=this.getCorrectPlayerPreviewInfos();if(i.forEach(t=>t.controller.pause()),this.options.enableScrollPreview&&!this.isHoverPlaying&&!location.search.includes("reqsrc=vp")&&(0,h.G)()){if(await this.batteryPromise,!(v||null!==(t=this.battery)&&void 0!==t&&t.charging))return!1;r.size&&(this.activePreviewController=null===(e=r.values().next().value)||void 0===e?void 0:e.controller,this.playerPreviewInfoMap.forEach(t=>{(null==t?void 0:t.controller)!==this.activePreviewController&&t.controller.pause()}),this.playPreviewController(this.activePreviewController,"scroll"))}},this.handleAutoPlayPreferenceChange=t=>{t?this.determineAnimationEffectCard():this.pauseAllAnimationEffectCards()},this.videoPlayOnMouseActionDebouncedCallback=(0,r.A)(t=>{var e;t&&t===(null===(e=this.previewState)||void 0===e?void 0:e.controller)&&this.isHoverPlaying&&(this.pauseAllVideos(),this.playPreviewController(t,"hover"))},500),this.handleVideoCardManagerEvents=t=>{switch(t.type){case c.O.PauseAllVideos:this.isEnabled=!1,this.pauseAllVideos();break;case c.O.PlayActiveVideo:this.isEnabled=!0}},this.registerOnMouseEnterListener=t=>{this.mouseEnterCallbackListeners.add(t)},this.unregisterOnMouseEnterListener=t=>{this.mouseEnterCallbackListeners.delete(t)},this.dispatchMouseEnterListeners=()=>{for(const t of this.mouseEnterCallbackListeners)try{t()}catch(t){console.error("dispatchMouseEnterListeners error",t)}},this.unsubscribeAutoPlayPreference=(0,h.Z)(this.handleAutoPlayPreferenceChange),this.addVideoCardManagerEventListeners(),this.batteryPromise||(this.batteryPromise=navigator.getBattery&&navigator.getBattery().then(t=>{var e;this.battery=t,null===(e=this.batteryPromise)||void 0===e||e.then(()=>{this.battery.addEventListener("chargingchange",this.handleBatteryChargingChange)})})),document.addEventListener("visibilitychange",this.handleVisibilityChange,!1),d.F_.subscribe(2,this.handleVisibilityChange),window.addEventListener("views-inline-refresh",()=>this.dispose(),{once:!0})}dispose(){var t;this.removeEventListeners(),null===(t=this.unsubscribeAutoPlayPreference)||void 0===t||t.call(this),p.instance=null}removeEventListeners(){this.battery&&this.battery.removeEventListener("chargingchange",this.handleBatteryChargingChange),document.removeEventListener("visibilitychange",this.handleVisibilityChange,!1),d.F_.unsubscribe(2,this.handleVisibilityChange),this.removeVideoCardManagerEventListeners()}startIntervalCheckActivePlayer(){this.checkActivePlayerInterval=window.setInterval(()=>{this.determineActiveVideo()},100)}stopIntervalCheckActivePlayer(){this.checkActivePlayerInterval&&clearInterval(this.checkActivePlayerInterval)}bindEvents(){this.options.enableScrollPreview&&window.addEventListener(u,this.determineActiveVideo,!1),this.options.enableFasterPlayer&&this.startIntervalCheckActivePlayer()}unbindEvents(){this.options.enableScrollPreview&&window.removeEventListener(u,this.determineActiveVideo,!1),this.options.enableFasterPlayer&&this.stopIntervalCheckActivePlayer()}getCorrectPlayerPreviewInfos(){const t=[],e=[],i=this.isInfopaneVisible();this.playerPreviewInfoMap.forEach(r=>{const o=()=>!(0,l.St)(r.previewElement,1/8);o()||e.push(r);const n=r.triggers.includes("scroll"),a=r.controller.displayVideoPreviewCta,s=this.options.disableIfInfopaneExists&&i,d=r.controller.isNearScrollPreviewCapped;if(n&&!s&&!d&&o()){if(a)return;t.push(r)}else a&&r.controller.disableVideoPreviewCta()});const r=(0,n.A)(t,[t=>{let{previewElement:e}=t;return this.getInViewportRatio(e)},t=>{let{previewElement:e}=t;return this.getVideoRect(e).top},t=>{let{previewElement:e}=t;return this.getVideoRect(e).left}],["desc","asc","asc"]);return[new Set(e),new Set(r??[])]}removePlayer(t){var e;t===(null===(e=this.previewState)||void 0===e?void 0:e.controller)&&(t.pause(),this.previewState=null),this.playerPreviewInfoMap.delete(t.id),this.playerPreviewInfoMap.size||this.unbindEvents()}addPlayer(t,e,i,r){this.playerPreviewInfoMap.size||this.bindEvents(),this.playerPreviewInfoMap.forEach((t,e)=>{t.previewElement!==i||r&&r===t.sharedPreviewElementId||this.playerPreviewInfoMap.delete(e)}),t&&this.playerPreviewInfoMap.set(t.id,{controller:t,triggers:e,previewElement:i,sharedPreviewElementId:r}),this.options.enableVideoPostScroll||this.determineActiveVideo()}addAnimationEffectCard(t){this.animationEffectCardList.includes(t)||(this.animationEffectCardList.push(t),this.determineAnimationEffectCard())}removeAnimationEffectCard(t){this.animationEffectCardList.includes(t)&&(this.animationEffectCardList=this.animationEffectCardList.filter(e=>e!==t),this.determineAnimationEffectCard())}pauseAllAnimationEffectCards(){this.animationEffectCardList.forEach(t=>t.pause())}determineAnimationEffectCard(){var t;if(!(0,h.G)())return void this.pauseAllAnimationEffectCards();let e,i=null;this.animationEffectCardList.forEach(t=>{var r,o;(void 0===e||t.priority>=e)&&null!==(r=t.isActiveCandidate)&&void 0!==r&&r.call(t)?(null===(o=i)||void 0===o||o.pause(),e=t.priority,i=t):t.pause()}),null===(t=i)||void 0===t||t.play()}videoMouseEnterCallback(t){this.previewState={controller:t,trigger:"hover"},this.dispatchMouseEnterListeners(),this.videoPlayOnMouseActionDebouncedCallback(t)}videoMouseClickCallback(t){this.pauseAllVideos(),this.playPreviewController(t,"hover")}videoMouseLeaveCallback(t){this.previewState=null,t.pause()}playPreviewController(t,e){t&&e&&this.isEnabled&&(t.play(),this.previewState={controller:t,trigger:e})}async addVideoCardManagerEventListeners(){window.addEventListener(c.O.PlayActiveVideo,this.handleVideoCardManagerEvents),window.addEventListener(c.O.PauseAllVideos,this.handleVideoCardManagerEvents);const{PreviewEventDispatcher:t}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679));t.dispatchStickyEvent()}removeVideoCardManagerEventListeners(){window.removeEventListener(c.O.PlayActiveVideo,this.handleVideoCardManagerEvents),window.removeEventListener(c.O.PauseAllVideos,this.handleVideoCardManagerEvents)}isInfopaneVisible(){const t=(0,l.Kt)('[data-t*="Infopane"]');return t&&!(0,l.St)(t,.75)}get isPlaying(){return!!this.previewState}get isHoverPlaying(){var t;return"hover"===(null===(t=this.previewState)||void 0===t?void 0:t.trigger)}get isScrollPlaying(){var t;return"scroll"===(null===(t=this.previewState)||void 0===t?void 0:t.trigger)}}},22760(t,e,i){"use strict";i.d(e,{CT(){return d},Kt(){return c},St(){return n},UV(){return l},h_(){return a},jc(){return s}});var r=i(42938),o=i(87582);const n=(t,e)=>{var i,n;if(!t)return!0;const{height:a,left:s,right:d,top:l}=t.getBoundingClientRect();if(!(a&&s&&d&&l))return!0;const c=function(t){for(;t.parentNode;)if((t=t.parentNode).shadowRoot)return t;return null}(t);if(!c)return l+a/2<0||l+a/2>window.innerHeight;const h=a*e,u=(0,r.u)(window.document.body)===o.OP.ltr?s+h:d-h,v=null==c||null===(i=c.shadowRoot)||void 0===i?void 0:i.elementFromPoint(u,l+h);return!(c.contains(v)||null!==(n=c.shadowRoot)&&void 0!==n&&n.contains(v))},a=()=>{const t=window&&window.navigator;if(!t)return!1;const{hardwareConcurrency:e=-1,deviceMemory:i=-1}=t;return i<=4},s=t=>{if(!t)return"";const e=Math.floor(t/60),i=t-60*e;return`${e>9?e:`0${e}`}:${i>9?i:`0${i}`}`};function d(t,e){return"number"==typeof t&&"number"==typeof e&&t>0&&e>0?t/e:1}async function l(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:100,i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:500,r=0;for(;!t()&&r<i;)await new Promise(t=>window.setTimeout(t,e)),r+=e}function c(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:document;const i=e.querySelector(t);if(i)return i;const r=e.querySelectorAll("*");for(const e of r)if(e instanceof HTMLElement&&e.shadowRoot){const i=c(t,e.shadowRoot);if(i)return i}return null}},22977(t,e,i){"use strict";i.d(e,{B(){return y},X(){return $}});var r=i(61138),o=i(95239),n=i(48751),a=i(74849),s=i(58792),d=i(12640),l=i(24277);const c=`${s.T3.StaticsUrl}latest/`,h=`${c}common/icons/PopupArrowDark.svg`,u=`${c}common/icons/PopupArrowLight.svg`,v=`${c}common/icons/DisclaimerDark.svg `,p=`${c}common/icons/DisclaimerLight.svg `,g=`${c}icons-wc/icons/AdChoice.svg`,f=`${c}icons-wc/icons/AdChoiceDark.svg`,m=`${c}icons-wc/icons/AdChoiceLight.svg`,x=a.A` .disclaimer .disclaimer-svg{background:url(${v}) no-repeat center}.popup-arrow-svg{background:url(${h}) no-repeat center}.ad-choice-mono > .ad-choice-svg{background:url(${f}) no-repeat center}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice-mono > .ad-choice-svg{background:url(${m}) no-repeat center;
        }
    }
`,b=a.A` .disclaimer .disclaimer-svg{background:url(${p}) no-repeat center}.popup-arrow .popup-arrow-svg{background:url(${u}) no-repeat center}.ad-choice-mono > .ad-choice-svg{background:url(${m}) no-repeat center}@media (forced-colors:active) and (prefers-color-scheme:dark){.ad-choice-mono > .ad-choice-svg{background:url(${f}) no-repeat center;
        }
    }
`,y=a.A` .ad-choice-hidden{max-width:0px;min-width:0px;visibility:hidden;width:0;padding:0;margin:0;border:0}.ad-choice,.${(0,l.nP)("ad-choice")}{margin-inline-start:10px}.ad-choice > .ad-choice-svg{background:url(${g}) no-repeat center}@media (forced-colors:active) and (prefers-color-scheme:dark){.ad-choice > .ad-choice-svg{background:url(${f}) no-repeat center}}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice > .ad-choice-svg{background:url(${m}) no-repeat center}}.ad-choice-mono > .ad-choice-svg{opacity:0.53}.ad-choice-mono-wide > .ad-choice-svg{opacity:0.67;background:url(${f}) no-repeat center}@media (forced-colors:active) and (prefers-color-scheme:dark){.ad-choice-mono-wide > .ad-choice-svg{background:url(${f}) no-repeat center}}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice-mono-wide > .ad-choice-svg{background:url(${m}) no-repeat center}}.ad-choice-svg{display:inline-block;width:12px;height:12px}.ad-choice-mobile{margin-inline-start:6px;padding-inline-start:4px;height:20px;margin-bottom:1px}.ad-footer,.${(0,l.nP)("ad-footer")}{align-items:center;display:flex;flex-direction:row}.disclaimer{cursor:pointer;margin-inline-end:2px}.disclaimer .container{display:none}.disclaimer .popup-arrow{bottom:36px;position:absolute}.disclaimer .popup-offset{background:${o.p};
        border-radius: 2px;
        bottom: 48px;
        color: ${n.l};
        font-size: ${r.k};margin-inline:-120px;max-width:152px;max-height:48px;padding:8px;position:absolute;width:152px;z-index:1}.disclaimer .popup-text{display:-webkit-box;overflow:hidden;white-space:normal;text-align:center;text-overflow:ellipsis;-webkit-line-clamp:2;-webkit-box-orient:vertical}.disclaimer .disclaimer-svg,.popup-arrow .popup-arrow-svg{display:inline-block;width:15px;height:15px}.disclaimer:hover .container{display:block}.popup{filter:drop-shadow(0px 0px 2px rgba(0,0,0,0.12)) drop-shadow(0px 4px 8px rgba(0,0,0,0.14))}`.withBehaviors(new d.N(b,x)),w=a.A` .disclaimer .disclaimer-svg{background:url(${p}) no-repeat center}.popup-arrow .popup-arrow-svg{background:url(${u}) no-repeat center}.ad-choice-mono > .ad-choice-svg{background:url(${m}) no-repeat center}.ad-choice-mono > .ad-choice-svg{opacity:0.8}`,$=a.A`
    ${y}
`.withBehaviors(new d.N(w,w))},26391(t,e,i){"use strict";i.d(e,{T(){return n}});var r=i(93552),o=i(22341);const n=(0,i(91454).sx)(r.WQp,"sendAdImageLoadError")(t=>{let{isBoost:e,...i}=t;(0,o.vV)(e?r.H77:r.MxD,"Ads image is not loaded properly",a(i),{shouldSampleErrorsForTreatement1:!e})}),a=t=>{let{id:e,rLink:i,imgLink:r,event:o,retryCount:n,isRetrySuccessful:a,status:s,statusText:d,type:l,redirected:c,errorMessage:h}=t;return JSON.stringify({id:e,rLink:i,imgLink:r||o&&o.target.src,retryCount:n,isRetrySuccessful:a,status:s,statusText:d,type:l,redirected:c,errorMessage:h})}},26831(t,e,i){"use strict";i.d(e,{Hg(){return a}});var r=i(58792),o=i(26220);const n=/[:/?#[\]@!$&'()*+,;=]/g;function a(t,e,i,a){let s=`${r.T3.NavTargetUrlWithLocale}/channel`;if(t&&i){const r="source"===i?"sr":"tp";s+="/"+[i,e?encodeURIComponent(e.replace(n,"")):"",`${r}-${t}`].filter(t=>t).join("/")}const d=new URL(s);return a||(d.search=(0,o.iA)()),(0,o.ou)().includes("localhost.msn.com")&&(d.host=(0,o.ou)()),d.toString()}},28160(t,e,i){"use strict";i.d(e,{Z(){return n}});var r=i(96950),o=i(58792);const n=r.qy`<button slot="hide-story" class="card-see-more" title=${t=>t.cardActionsTooltips&&t.cardActionsTooltips.seeMore} @click=${(t,e)=>t.toggleCardActionMenu&&t.toggleCardActionMenu(t,e.event)} data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.seeMore)||void 0===e?void 0:e.getMetadataTag()}}"><img src="${o.T3.StaticsUrl}latest/icons-wc/icons/MoreV2.svg" loading="lazy" alt="more" aria-hidden="true" /></button>`},29652(t,e,i){"use strict";i.d(e,{Y(){return c}});var r=i(85349),o=i(96950),n=i(69259),a=i(17857),s=i(41938),d=i.n(s),l=i(83222);const c=o.qy` ${(0,n.z)(t=>t.enableCardHideStoryIcon,o.qy`<button aria-label="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.hide}" class="card-hide" slot="hide-story" title="${t=>t.cardActionsTooltips&&t.cardActionsTooltips.hide}" @click=${(t,e)=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^a.J.hide^a.J.hidden,"Hide",!0,null,null,null,e.event,null,"hidestory-button")} @keypress=${t=>t.cardActionClickHandler&&t.cardActionClickHandler(t.id,t.cardActionStatus^a.J.hide^a.J.hidden,"Hide","Hide",!0,null,null,null,null,null,"hidestory-button")} data-t="${t=>{var e,i,o;return(null===(e=t.telemetryContext)||void 0===e?void 0:e.hide)&&(i=t.telemetryContext.hide,new l.$({...null==i?void 0:i.contract,name:"showFewer",action:r.EG.Click,behavior:r.MS.Dislike,type:r.MJ.ActionButton,content:{...null==i||null===(o=i.contract)||void 0===o?void 0:o.content}}).getMetadataTag())}}">${o.qy.partial(d())}</button>`)}
`},30664(t,e,i){"use strict";i.d(e,{I(){return r}});const r="1"},36355(t,e,i){"use strict";i.d(e,{v(){return p}});var r=i(50866),o=i(43922),n=i(25109),a=i(29937),s=i(52356);function d(t,e){const i=t;return function(t){t.imageData&&t.imageData.source&&(t.mediaType=["video","webcontent"].includes(t.contentType)?o.z.video:o.z.image)}(i),function(t,e){t.immersiveCard||(t.immersiveCard=t.cardSize===r.qJ._2x_2y&&t.cardLayout!==a.Sv.infoPane||t.cardSize===r.qJ._2x_2y&&t.cardLayout===a.Sv.infoPane&&e.config&&!e.config.enableImmersiveInfopane||t.cardLayout===a.Sv.infoPane&&e.config&&e.config.enableSuperInfopane&&!e.config.disable1UImmersiveInfopane)}(i,e),i}function l(t,e){if(t.immersiveCard&&t.mediaType)return t.cardFillColor="#333",t.darkCardFillColor=t.cardFillColor,void(t.lightCardFillColor=t.cardFillColor);let i=!1;if(i=t.useMobile&&!t.isMsnMobile?(0,n.r0)(t):t.useWinSystemMode||t.isMsnMobile?s.y.appInDarkMode():(0,n.ud)(),e&&e.config&&e.config.enableFeedSuperCardsSingleColor)e.config.cardColorsOverride?(t.lightCardFillColor=e.config.cardColorsOverride.lightCardFillColor,t.darkCardFillColor=e.config.cardColorsOverride.darkCardFillColor):(t.lightCardFillColor="#FFFFFF",t.lightCardSecondaryColor=void 0,t.lightGradientAngle=void 0,t.darkCardFillColor="#292929",t.darkCardSecondaryColor=void 0,t.darkGradientAngle=void 0);else{var r,o;const e=null===(r=t.colorSamples)||void 0===r?void 0:r.find(t=>!1===t.isDarkMode),i=!e||!e.hexColor&&!e.secHexColor&&!e.gradientAngle;t.lightCardFillColor=i?"#FFFFFF":e.hexColor,t.lightCardSecondaryColor=i?"#E1E1E1":e.secHexColor,t.lightGradientAngle=i?"112.05deg":e.gradientAngle;const n=null===(o=t.colorSamples)||void 0===o?void 0:o.find(t=>!0===t.isDarkMode),a=!n||!n.hexColor&&!n.secHexColor&&!n.gradientAngle;t.darkCardFillColor=a?"#565656":n.hexColor,t.darkCardSecondaryColor=a?"#272727":n.secHexColor,t.darkGradientAngle=a?"112.05deg":n.gradientAngle}t.cardFillColor=i?t.darkCardFillColor:t.lightCardFillColor,t.cardSecondaryColor=i?t.darkCardSecondaryColor:t.lightCardSecondaryColor,t.gradientAngle=i?t.darkGradientAngle:t.lightGradientAngle}function c(t,e){if(!e||!e.config)return;if(!e.config.enableFeedSuperCardsSolidColor&&!t.enableNativeAdCardsSolidColor)return;if(!t.immersiveCard&&"#000000"!==t.cardFillColor||t.cardSize===r.qJ._2x_2y&&!t.imageData){t.lightCardFillColor="#FFF",t.lightCardSecondaryColor=void 0,t.lightGradientAngle=void 0,t.darkCardFillColor="#333",t.darkCardSecondaryColor=void 0,t.darkGradientAngle=void 0;const e=s.y.appInDarkMode();t.cardFillColor=e?t.darkCardFillColor:t.lightCardFillColor,t.cardSecondaryColor=void 0,t.gradientAngle=void 0}}function h(t,e){const i=e._config,r=d(t,e);return l(r,e),r.openLinksInNewTab=r.openLinksInNewTab||r.openArticleInNewTab,r.seeMoreOverride=i.seeMoreOverride,c(r,e),r}function u(t,e,i){var r,n,a;const s=d(t,e);return s.isInfopaneComplexAd=i,l(s,e),c(s,e),function(t,e){if(e&&e.config&&e.config.nativeAdImageQuality&&t.imageData&&t.mediaType===o.z.image&&t.imageData.source){const i=new URL(t.imageData.source),r=null==i?void 0:i.searchParams;r&&(r.set("qlt",e.config.nativeAdImageQuality),i.search=r.toString(),t.imageData.source=i.toString())}}(s,e),s.enableAdShimmerEffect=null==e||null===(r=e.config)||void 0===r?void 0:r.enableAdShimmerEffect,s.useFeeds3Designs=null==e||null===(n=e.config)||void 0===n?void 0:n.enableDynamicWaterfall,s.enableResponsiveWidth=null==e||null===(a=e.config)||void 0===a?void 0:a.enableResponsiveWidth,s}var v=i(99476);class p{static createViewModel(t,e){switch(t&&t.childTemplateType){case"article-card":case"content-card":case"web-content-card":return h(t,e);case"video-card":return function(t,e){const i=d(t,e);l(i,e),i.openLinksInNewTab=i.openLinksInNewTab||i.openArticleInNewTab,c(i,e);const o=e.config;return i.immersiveCard=i.cardSize===r.qJ._2x_2y&&i.immersiveCard,i.enableSuperVideoIconLarge=o.enableSuperVideoIconLarge,i}(t,e);case"native-ad-card":case"native-top-ad-card":return u(t,e);case"super-sd-card":return d(t,e);case"content-group":return function(t,e){let i=d(t,e);const o=e._config;i.cardData=t,i.lightCardFillColor="#FFFFFF",i.darkCardFillColor="#333";const n=s.y.appInDarkMode();i.cardFillColor=n?i.darkCardFillColor:i.lightCardFillColor,t.contentGroupMetadata.subCards.forEach((t,i)=>{t.isNativeAd&&t.nativeAds.length>0?t.nativeAds.forEach(i=>{u(i,e,t.nativeAds.length>1)}):(h(t,e),o.enableFeed3Cards&&"1u"===t.cardSize&&(t.cardSize="_1x_2y"))});const a=(0,v.a)().get("vpFreeze");i={...i,...o};const l=o.autoRotateIntervalMs;i.enableFlippersOnRest=o.enableInfopaneFlippersOnRest,i.enableTransparentFlippersOnRest=o.enableTransIfpFlippersOnRest,i.enableSlideShow=!o.disableSlideShow&&!a,i.enablePlayPauseButton=!o.disableInfopanePlayPauseButton,i.disableNavAnimation=o.disableNavAnimation,i.rotationDuration=l?l/1e3:3,i.enableSuperCardMemoize=e.getEnableSuperCardMemoize(),i.disableInfopaneComplexAds=o.disableInfopaneComplexAds,i.enableIpTransform=o.enableIpTransform,i.restartRotationTimer=o.restartRotationTimer;const c=o.enableOneCInfopaneNav&&i.cardSize===r.qJ._1x_2y;return i.tabCount=o.enableMaxInfopaneSlider&&!c?99:5,i}(t,e);case"infopane-card":return function(t,e){const i=d(t,e),o=e._config;i.cardData=t,i.lightCardFillColor="#FFFFFF",i.darkCardFillColor="#333";const n=s.y.appInDarkMode();i.cardFillColor=n?i.darkCardFillColor:i.lightCardFillColor,t.slideContentData.forEach((t,i)=>{t&&(t.isNativeAd?o.enableResponsiveInfopaneMap?u(t,e):t.nativeAds.length>0&&t.nativeAds.forEach(i=>{u(i,e,t.nativeAds.length>1)}):(h(t,e),o.enableFeed3Cards&&"1u"===t.cardSize&&(t.cardSize="_1x_2y")))});const a=(0,v.a)().get("vpFreeze"),l=o.autoRotateIntervalMs??i.cardData.autoRotateIntervalMs;o.autoRotateIntervalMs||i.wpoRotationDuration||(i.wpoRotationDuration=i.cardData.autoRotateIntervalMs/1e3),i.enableSlideShow=!o.disableSlideShow&&!a,i.enablePlayPauseButton=!o.disableInfopanePlayPauseButton,i.enableResponsiveInfopaneMap=o.enableResponsiveInfopaneMap,i.enableAutoPlayInfopaneVideos=o.enableAutoPlayInfopaneVideos,i.enableResponsiveCards=o.enableResponsiveComponent,i.disableNavAnimation=o.disableNavAnimation,i.shiftIpNavToRight=o.shiftIpNavToRight,i.rotationDuration=l?l/1e3:3,i.enableSingleRotation=i.cardData.enableRotateOnlyOnce,i.enableSuperCardMemoize=e.getEnableSuperCardMemoize(),i.disableInfopaneComplexAds=o.disableInfopaneComplexAds,i.enableFlippersOnRest=o.enableInfopaneFlippersOnRest,i.enableTransparentFlippersOnRest=o.enableTransIfpFlippersOnRest,i.enableIpTransform=o.enableIpTransform,i.enableInfopaneDenseCardInteraction=o.enableInfopaneDenseCardInteraction,i.restartRotationTimer=o.infopaneRestartRotationBuffer>0?i.wpoRotationDuration+o.infopaneRestartRotationBuffer:o.restartRotationTimer,i.cardData.flipperSize=o.ipFlipperCustomSize??"large",i.cardData.flipperColorInverted=o.invertIpFlipperColor,i.seeMoreOverride=o.seeMoreOverride,i.enableLazyInfopane=!!o.enableLazyInfopane,i.lazyInfopanePreloadCount=o.lazyInfopanePreloadCount;const c=o.enableOneCInfopaneNav&&i.cardSize===r.qJ._1x_2y;return o.enableBottomNav&&!c&&(i.navPosition="bottom"),i.tabCount=o.enableMaxInfopaneSlider&&!c?99:5,i}(t,e);case"carousel":return function(t,e){return d(t,e)}(t,e);default:return null}}}},40331(t,e,i){"use strict";i.d(e,{q(){return _}});var r=i(56911),o=i(14475),n=i(60815),a=i(38493),s=i(3065),d=i(22162),l=i(10809),c=i(77367),h=i(85349),u=i(52356),v=i(89064),p=i(45102),g=i(69781),f=i(50866),m=i(92011),x=i(94043),b=i(903),y=i(10910),w=i(46528),$=i(90905);class _ extends m.L{constructor(){super(...arguments),this.deferRenderAfterHover=!1,this.showTitleTooltip=!0,this.tooltipIsSet=!1,this.enableAdImageRetry=!1,this.cardAddedForOcvTracking=!1,this.showCTA=!0,this.shouldRemoveFooterStartAndFooterEnd=()=>{var t,e;return(null===(t=this.config)||void 0===t?void 0:t.enableNTPTriverC2S)&&"nativead-triver-1"===(null===(e=this.data)||void 0===e?void 0:e.id)},this.handleResize=()=>{this.showCTA=(0,v.r7)(this,this.data)},this.handleTelemetryMouseEnter=t=>{(0,g.kM)("SuperNativeAdCard",()=>c.YT.sendActionEvent(t,h.EG.Hover,h.MS.Open))},this.handleTelemetryMouseLeave=t=>{(0,g.pS)("SuperNativeAdCard",()=>c.YT.sendActionEvent(t,h.EG.MouseLeave,h.MS.Open))},this.handleSetTitleOnMouseEnter=()=>{if(this.data&&this.data.cardElement){var t,e;const i=null===(t=this.data.cardElement.shadowRoot)||void 0===t||null===(e=t.querySelector)||void 0===e?void 0:e.call(t,".heading");this.showTitleTooltip=(0,v.lh)(i,this.data.enableTitleForTruncate),this.tooltipIsSet=!0}},this.onBreakpointCallback=t=>{t!==this.columnArrangement&&(this.columnArrangement=t)}}connectedCallback(){var t,e,i;if(this.config=l.D.getConfig(),this.deferRenderAfterHover=!!this.config.enableDeferRenderElement,this.enableAdImageRetry=!!this.config.enableAdImageRetry,null!==(t=this.data)&&void 0!==t&&t.useFeeds3Designs&&(this.feeds3Design=!0),super.connectedCallback(),(0,x.S)()&&this.data&&!this.data.useMobile&&(this.classList.contains("infopane-slide")||(0,b.D)(this.data.cardElement),this.handleXandrVisibilityTracking()),(0,x.S)()){if((0,y._Z)(this).then(async()=>{var t,e,i,r;null!==(t=this.data)&&void 0!==t&&null!==(t=t.attributionImage)&&void 0!==t&&t.complete&&(null===(i=(r=this.data).visualReadinessCallback)||void 0===i||i.call(r,3,d.j.image));u.y.subscribeThemeChange(this),this.targetTag=null!==(e=this.data)&&void 0!==e&&e.openAdInSameTab?o.z._self:o.z._blank,this.storeAdsForOcvFeedback()}),null!==(e=this.data)&&void 0!==e&&e.enableInarticleAdFullBleedImage){const t=(new w.bb).data.innerWidth();this.showDescription=(0,v.SA)(this.data,t),this.columnArrangement=(0,s.TU)().currentColumnArrangement,(0,s.TU)().subscribe(this.onBreakpointCallback),this.handleResize(),this.resizeHandler=(0,$.A)(this.handleResize,200),window.addEventListener("resize",this.resizeHandler)}}else this.targetTag=null!==(i=this.data)&&void 0!==i&&i.openAdInSameTab?o.z._self:o.z._blank}dataChanged(t,e){var i;null!==(i=this.data)&&void 0!==i&&i.useAdaptiveImageStyle&&(this.adaptiveImage=!0)}clickHandler(t,e){var i,r;return null===(i=this.data)||void 0===i||null===(r=i.onClickLink)||void 0===r||r.call(i),!0}isWindowIntraArticle(){return!!this.data.id&&(this.isIntraArticleId()&&this.data.cardSize===f.qJ._2x_1y)}disconnectedCallback(){var t;super.disconnectedCallback(),u.y.unsubscribeThemeChange(this),this.adUniqueId&&(0,p.r6)([this.adUniqueId]),null!==(t=this.data)&&void 0!==t&&t.enableInarticleAdFullBleedImage&&((0,s.TU)().unsubscribe(this.onBreakpointCallback),window.removeEventListener("resize",this.resizeHandler),this.resizeHandler=null)}get adUniqueId(){var t;return null===(t=this.data)||void 0===t||null===(t=t.items)||void 0===t||null===(t=t[0])||void 0===t?void 0:t.uniqueId}handleXandrVisibilityTracking(){this.adUniqueId&&(0,p.YW)(new Map([[this.adUniqueId,this.shadowRoot.host]]))}storeAdsForOcvFeedback(){var t;if(this.cardAddedForOcvTracking)return;const e="AllAds";window[e]||(window[e]=new Map),window[e].set(null===(t=this.data)||void 0===t?void 0:t.id,this.shadowRoot.host),this.cardAddedForOcvTracking=!0}handleThemeChange(t){var e;(0,v.CG)(t,this,[null===(e=this.data)||void 0===e?void 0:e.outerCSCard])}startRenderInvisibaleElementAfterHover(){this.deferRenderAfterHover=!1}isIntraArticleId(){return["inarticle","eoab","intranative","watchlistnative"].some(t=>this.data.id.startsWith(t))}}(0,r.Cg)([n.sH],_.prototype,"data",void 0),(0,r.Cg)([n.sH],_.prototype,"targetTag",void 0),(0,r.Cg)([n.sH],_.prototype,"deferRenderAfterHover",void 0),(0,r.Cg)([n.sH],_.prototype,"columnArrangement",void 0),(0,r.Cg)([n.sH],_.prototype,"showDescription",void 0),(0,r.Cg)([n.sH],_.prototype,"isSmallScreen",void 0),(0,r.Cg)([n.sH],_.prototype,"showTitleTooltip",void 0),(0,r.Cg)([n.sH],_.prototype,"tooltipIsSet",void 0),(0,r.Cg)([n.sH],_.prototype,"enableAdImageRetry",void 0),(0,r.Cg)([(0,a.CF)({attribute:"feeds-3-design"})],_.prototype,"feeds3Design",void 0),(0,r.Cg)([(0,a.CF)({attribute:"adaptive-image"})],_.prototype,"adaptiveImage",void 0),(0,r.Cg)([n.sH],_.prototype,"showCTA",void 0)},41938(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M2.4 2.55l.07-.08a.75.75 0 01.98-.07l.08.07L8 6.94l4.47-4.47a.75.75 0 111.06 1.06L9.06 8l4.47 4.47c.27.27.3.68.07.98l-.07.08a.75.75 0 01-.98.07l-.08-.07L8 9.06l-4.47 4.47a.75.75 0 01-1.06-1.06L6.94 8 2.47 3.53a.75.75 0 01-.07-.98l.07-.08-.07.08z"></path></svg>'},42792(t,e,i){"use strict";i.d(e,{R7(){return g},e(){return v},kc(){return p},nH(){return u}});var r=i(57416),o=i(55153),n=i(95239),a=i(26920),s=i(48751),d=i(64187),l=i(22131),c=i(74849),h=i(50882);const u=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,v=c.A`
    ${(0,d.V)("flex")} :host {
        background: ${n.p};
        outline: calc(${a.XA} * 1px) solid ${o.cu};
        border-radius: calc((${r.JU} - ${a.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${o.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${o.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${a.XA} * 1px) ${o.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${o.QG} * 1px);
        height: calc(${o.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${o.QG} * 1px);
        height: calc((${o.l8} * 2px) + (${o.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${o.QG} * 2px) + (${o.Sn} * 1px));
        height: calc((${o.l8} * 2px) + (${o.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${o.QG} * 2px) + (${o.Sn} * 1px));
        height: calc(${o.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,p=(0,l.mr)(c.A`
            :host {
                background: ${h.A.Canvas};
                color: ${h.A.CanvasText};
            }
        `),g=c.A`
    ${v}
    ${u}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(p)},43922(t,e,i){"use strict";i.d(e,{z(){return r}});const r={image:"image",video:"video"}},45214(t,e,i){"use strict";i.d(e,{O(){return V}});var r=i(65614),o=i(16038),n=i(56911),a=i(92011),s=i(60815),d=i(87119);class l extends a.L{}(0,n.Cg)([d.V],l.prototype,"configProvider",void 0),(0,n.Cg)([s.sH],l.prototype,"feedLayouts",void 0),(0,n.Cg)([s.sH],l.prototype,"layout",void 0),(0,n.Cg)([s.sH],l.prototype,"placeholderFeedLayout",void 0);var c=i(96950),h=i(36355),u=i(2171);class v{static getViewTemplate(t,e){const i=e&&e.getSuperCardsTemplatesMap(),r=i&&i[t.childTemplateType];if(!r)return null;const o=()=>{const t=c.qy.partial(r);return c.qy`
            <${t}
                class="card-container"
                config-instance-src="${t=>t.configInstanceSrc||"default"}"
                :displaySettings=${t=>t.displaySettings}
                :data=${t=>h.v.createViewModel(t,e)}
                style="grid-area:${t=>t.gridArea}"
                size="${t=>t.cardSize}"
                tabIndex="${t=>t.customTabIndex??0}"
            >
            </${t}>
        `};if(!e.getEnableSuperCardMemoize())return o();const n="_SuperContainer__TagCreatorFactory_",a=u.vv.get(n)||{};return a[r]||(a[r]=o(),u.vv.set(n,a)),a[r]}}var p=i(38493);class g extends l{constructor(){super(...arguments),this.lastFeedLayoutPosition=-1}feedLayoutsChanged(){var t;if(null===(t=this.feedLayouts)||void 0===t||!t.length)return;const e=this.configProvider.getCardTemplatesMap(),i=this.configProvider.getSuperCardsTemplatesMap();for(let t=this.lastFeedLayoutPosition+1;t<this.feedLayouts.length;t++){this.feedLayouts[t].feedData.defaultLayout.forEach(t=>{if(i[t.childTemplateType]){const i=v.getViewTemplate(t,this.configProvider);i&&(e[t.childTemplateType]=i)}})}this.lastFeedLayoutPosition=this.feedLayouts.length-1}}(0,n.Cg)([(0,p.CF)({attribute:"responsive-width"})],g.prototype,"responsiveWidth",void 0);var f=i(37635),m=i(74849);const x=m.A``,b=m.A`
    ${x} :host{display:grid;flex-flow:row wrap;gap:12px;justify-content:center;--layer-corner-radius:8}cs-feed-layout{grid-auto-rows:146px;--card-base-gap:12}:host([responsive-width="true"]) cs-feed-layout{grid-auto-columns:minmax(271px,348px);grid-auto-rows:auto}`.withBehaviors(new f.X(["configProvider"],t=>{var e;let i=m.A``;if(null!==(e=t.configProvider)&&void 0!==e&&null!==(e=e.config)&&void 0!==e&&e.feedLayoutGap){var r;const e=null===(r=t.configProvider)||void 0===r||null===(r=r.config)||void 0===r?void 0:r.feedLayoutGap;i=m.A` :host{gap:${e}px}cs-feed-layout{--card-base-gap:${e}; }
                `}return i}),new f.X(["configProvider"],t=>{var e,i,r;return t.configProvider&&t.configProvider.config&&(null!==(e=t.configProvider.config)&&void 0!==e&&e.useMobileNoHoverCards||null!==(i=t.configProvider.config)&&void 0!==i&&i.useMobileNoHoverLightCards||null!==(r=t.configProvider.config)&&void 0!==r&&r.enableChannelCard)?m.A` cs-feed-layout{grid-auto-rows:auto;grid-auto-columns:auto;`:m.A``}));var y=i(69259),w=i(39957);const $=c.qy` ${(0,y.z)(t=>!!(t.feedData&&t.feedData.defaultLayout&&t.feedData.defaultLayout.length),c.qy`<cs-feed-layout :disabledKeyListeners="${(t,e)=>e.parent.configProvider.getDisabledKeyListeners()}" layout="${(t,e)=>e.parent.layout}" :isPlaceholder="${t=>t.isPlaceholder}" :data="${t=>t.feedData}" :childTemplateMap="${(t,e)=>e.parent.configProvider.getCardTemplatesMap()}" :layoutStyles="${(t,e)=>e.parent.configProvider.getLayoutTemplatesMap()[t.templateId].styles}" style="${(t,e)=>e.parent.configProvider.getOverrideStyles()}" t-card-size="${t=>t.baseCardSize}"></cs-feed-layout>`)}`,_=c.qy` ${(0,y.z)(t=>t.feedLayouts&&t.feedLayouts.length,c.qy` ${(0,w.ux)(t=>t.feedLayouts,$)}<slot name="abovePlaceholder"></slot>${(0,y.z)(t=>t.placeholderFeedLayout,c.qy` ${(0,w.ux)(t=>[t.placeholderFeedLayout],$)} `)} `)}`,k=g.compose({name:"cs-personalized-feed",styles:b,template:_});var z=i(13312),C=i(29307),S=i(96787);class T extends a.L{constructor(){super(...arguments),this.enableWFMonitor=!1,this.sentinelHeight=1}feedLayoutsChanged(){this.mutateCurrentFeedLayouts()}placeholderFeedLayoutChanged(){this.placeholderFeedLayout&&this.mutateFeedLayout(this.placeholderFeedLayout)}layoutChanged(){this.mutateCurrentFeedLayouts(),this.placeholderFeedLayout&&this.mutateFeedLayout(this.placeholderFeedLayout)}responsiveFeedLayoutsChanged(){var t;this.cardTemplateMap=null===(t=this.responsiveFeedLayouts)||void 0===t||null===(t=t[0])||void 0===t?void 0:t.childTemplateMap}disconnectedCallback(){super.disconnectedCallback()}mutateCurrentFeedLayouts(){var t;null!==(t=this.feedLayouts)&&void 0!==t&&t.length&&this.layout&&this.feedLayouts.forEach(t=>this.mutateFeedLayout(t))}mutateFeedLayout(t){var e;const i=this.configProvider.getCardTemplatesMap();i["native-ad-card-video"]||(i["native-ad-card-video"]=(0,C.A)(i["native-ad-card"])),i["native-ad-card-boost"]||(i["native-ad-card-boost"]=(0,C.A)(i["native-ad-card"]));const r=null==t?void 0:t.feedData;null==r||null===(e=r.defaultLayout)||void 0===e||e.forEach((t,e)=>{const o=r[this.layout]&&r[this.layout].find(e=>(0,S.Yd)(e)&&e.id===t.id);o&&"video-card"===o.childTemplateType?t.childTemplateType="video-card":o&&"infopane-slide-card"===o.childTemplateType&&"infopane-slide-card"!==t.childTemplateType&&(r[this.layout].find(e=>(0,S.Yd)(e)&&e.id===t.id).childTemplateType=t.childTemplateType),this.updateTemplateForNotSupportedScenario(t,i)});for(const t in z._4)r[t]&&r[t].forEach(t=>t.childDOMOrder=t.card_dom_order)}personalizedFeedElementChanged(){this.onFeedLayoutElementsChanged&&!this.personalizedFeedElementMutationObserver&&this.personalizedFeedElement&&this.personalizedFeedElement.shadowRoot&&(this.personalizedFeedElementMutationObserver=new MutationObserver(()=>{if(this.personalizedFeedElement&&this.personalizedFeedElement.shadowRoot){const t=Array.from(this.personalizedFeedElement.shadowRoot.children).filter(t=>"CS-FEED-LAYOUT"===t.tagName&&!t.isPlaceholder);this.onFeedLayoutElementsChanged(t)}}),this.personalizedFeedElementMutationObserver.observe(this.personalizedFeedElement.shadowRoot,{childList:!0}))}updateTemplateForNotSupportedScenario(t,e){if(!(t&&"native-ad-card"===t.childTemplateType))return;if(t.videoProps||t.useProng2AmplifyCardTemplate)if(t.videoProps){const i=t.childTemplateType+"-v1";e[i]||(e[i]=e["native-ad-card-video"]),t.childTemplateType=i}else if(t.useProng2AmplifyCardTemplate){const i=t.childTemplateType+"-v2";e[i]||(e[i]=e["native-ad-card-boost"]),t.childTemplateType=i}}getResponsiveCardTemplates(t){if("widgetsWaterfall"===t)return this.cardTemplateMap;const e=this.configProvider.getCardTemplatesMap();e["infopane-card"]=v.getViewTemplate({id:"infopane",childTemplateType:"infopane-card"},this.configProvider),e["native-ad-card-video"]||(e["native-ad-card-video"]=(0,C.A)(e["native-ad-card"]));return e["native-ad-card"]=v.getViewTemplate({id:"nativead",childTemplateType:"native-ad-card"},this.configProvider),e}}(0,n.Cg)([d.V],T.prototype,"configProvider",void 0),(0,n.Cg)([s.sH],T.prototype,"feedLayouts",void 0),(0,n.Cg)([s.sH],T.prototype,"responsiveFeedLayouts",void 0),(0,n.Cg)([s.sH],T.prototype,"enableWFMonitor",void 0),(0,n.Cg)([s.sH],T.prototype,"enableFirstSectionFlush",void 0),(0,n.Cg)([s.sH],T.prototype,"cardTemplateMap",void 0),(0,n.Cg)([s.sH],T.prototype,"childTemplateSizeMap",void 0),(0,n.Cg)([s.sH],T.prototype,"layout",void 0),(0,n.Cg)([s.sH],T.prototype,"personalizedFeedElement",void 0),(0,n.Cg)([s.sH],T.prototype,"sentinelHeight",void 0),(0,n.Cg)([s.sH],T.prototype,"placeholderFeedLayout",void 0),(0,n.Cg)([s.sH],T.prototype,"responsiveWidth",void 0),(0,n.Cg)([s.sH],T.prototype,"seenContentHandler",void 0),(0,n.Cg)([(0,p.CF)({attribute:"content-seen-removal-mode",converter:p.R$})],T.prototype,"contentSeenRemovalMode",void 0);const E=m.A``;var P=i(60402),F=i(1302);(0,i(50193).C)(F.Be);const A=c.qy`<cs-personalized-feed ${(0,P.K)("personalizedFeedElement")} :layout="${t=>t.layout}" :feedLayouts=${t=>t.feedLayouts} :placeholderFeedLayout=${t=>t.placeholderFeedLayout} :responsiveWidth="${t=>t.responsiveWidth}"><slot name="sentinel" slot="abovePlaceholder"></slot></cs-personalized-feed>`,I=c.qy` ${(0,w.ux)(t=>t.responsiveFeedLayouts,c.qy`<cs-responsive-feed-layout :childTemplateMap="${(t,e)=>e.parent.getResponsiveCardTemplates(t.id)}" :childTemplateSizeMap="${(t,e)=>{var i;return null===(i=e.parent)||void 0===i?void 0:i.childTemplateSizeMap}}" :wideCard="${t=>t.wideCard}" :wideCardSize="${t=>t.wideCardSize}" :onFeedElementsChanged="${(t,e)=>e.parent.onFeedLayoutElementsChanged}" :enableMonitor="${(t,e)=>e.parent.enableWFMonitor}" :onBlankMonitorResult="${t=>t.onBlankMonitorResult}" :sentinelHeight="${(t,e)=>e.parent.sentinelHeight}" :sentinelRenderedElements="${(t,e)=>e.parent.sentinelRenderedElements}" :sectionTrackerTag="${t=>t.sectionTrackerTag}" :renderingMode="${t=>t.rowRendering?"row":"column"}" :responsiveWidth="${(t,e)=>e.parent.responsiveWidth}" :columns="${t=>t.columns}" :customRowSection="${t=>t.customRowSection}" :id="${t=>t.id}" :seenContentHandler="${(t,e)=>e.parent.seenContentHandler}" content-seen-removal-mode=${(t,e)=>e.parent.contentSeenRemovalMode}>${void 0}</cs-responsive-feed-layout>`,{positioning:!0})}
`,M=c.qy` ${(0,y.z)(t=>{var e;return!t.responsiveFeedLayouts&&(null===(e=t.feedLayouts)||void 0===e?void 0:e.length)},A)} ${(0,y.z)(t=>{var e;return null===(e=t.responsiveFeedLayouts)||void 0===e?void 0:e.length},I)}
`,L=T.compose({name:"cs-super-container",styles:E,template:M}),V=()=>{k.define(r.G.registry),L.define(r.G.registry),o.m.define(r.G.registry)}},45964(t,e,i){"use strict";i.d(e,{_q(){return s},hU(){return l}});var r,o=i(93552),n=i(22341);function a(t,e){if(t instanceof Error){const i=t.toString();return e&&t.stack?`${i}, Stack: ${t.stack}`:i}return"string"==typeof t?t:function(t){if(void 0===t)return"undefined";try{return JSON.stringify(t)}catch{return"[serialization-error]"}}(t)}!function(t){t.LO="101",t.SD="102",t.HQ="103",t.HD="104",t.FHD="105",t["4K"]="107",t.Source="1001",t.SmoothStreaming="1004",t.HLS="1006",t.DASH="1007"}(r||(r={}));const s=(t,e)=>{try{const i=(t=>t&&Array.isArray(t)?t.filter(t=>{if(!t||"object"!=typeof t)return!1;const e=t.url&&"string"==typeof t.url&&t.url.trim().length>0,i=void 0!==t.fileSize&&"number"==typeof t.fileSize&&!isNaN(t.fileSize)&&isFinite(t.fileSize)&&t.fileSize>0;return e&&i}):[])(t);if(null==i||!i.length)return;const r=(t,e)=>{const i=t.fileSize,r=e.fileSize;return i<r?-1:i>r?1:0},o=i.sort(r);return void 0!==e&&e>=0&&o.length>0?o[Math.min(e,o.length-1)]:o.length>0?o[0]:void 0}catch(t){return void(0,n.vV)(o.A0q,"Error processing video files",a(t))}},d=["hover","scroll"],l=function(t,e,i,r){let a=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"",l=arguments.length>5?arguments[5]:void 0,c=arguments.length>6&&void 0!==arguments[6]&&arguments[6],h=arguments.length>7?arguments[7]:void 0,u=arguments.length>8&&void 0!==arguments[8]?arguments[8]:"msn",v=arguments.length>9?arguments[9]:void 0,p=arguments.length>10&&void 0!==arguments[10]&&arguments[10],g=arguments.length>11&&void 0!==arguments[11]&&arguments[11],f=arguments.length>12?arguments[12]:void 0,m=arguments.length>13?arguments[13]:void 0,x=arguments.length>14?arguments[14]:void 0,b=arguments.length>15?arguments[15]:void 0,y=arguments.length>16?arguments[16]:void 0,w=arguments.length>17?arguments[17]:void 0;const $=Array.isArray(r)?r:[],_=s($,m);return{cardElement:t,config:{enableVideoCardHover:!0,enableVideoCardScroll:!0,capScrollPreview:c,enableVideoPreview:p,enableUserAutoPlaySettings:g,enablePauseOnComplete:w},logError(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"Generic Error Message";(0,n.vV)(o.fbJ,t,`Video Id: ${i}`)},previewTriggers:y||d,videoElement:e,videoData:{id:i,videoFile:_,title:a,videoDurationMs:l,motionThumbnailUrl:v,closedCaptions:x},overridePreviewElement:h,source:u,enablePreloadOnSetupTime:f,onHoverOtherVideoCallback:b}}},50866(t,e,i){"use strict";i.d(e,{L9(){return n},NZ(){return o},qJ(){return r}});const r={_1x_1y:"_1x_1y",_1x_2y:"_1x_2y",_2x_2y:"_2x_2y",_2x_1y:"_2x_1y"},o={DarkPlum:"dark-plum",DarkDesert:"dark-desert",DarkDawn:"dark-dawn",DarkSea:"dark-sea",DarkOrange:"dark-orange",DarkTropic:"dark-tropic",DarkMerlot:"dark-merlot",DarkPurple:"dark-purple",DarkGreen:"dark-green"},n={LightBlue:"light-blue",LightPurple:"light-purple",LightSky:"light-sky",LightPink:"light-pink",LightYellow:"light-yellow",LightBluebird:"light-bluebird",LightOrange:"light-orange",LightAqua:"light-aqua",LightGreen:"light-green"}},52380(t,e,i){"use strict";i.d(e,{i(){return f}});var r=i(56911),o=i(60815),n=i(77367),a=i(97015),s=i(65114),d=i(22760),l=i(18270),c=i(22341),h=i(93552);async function u(t,e){try{const i=await fetch(t);if(!i.ok)return(0,c.vV)(h.gl8,"Error FETCHING VTT caption file",`Video ID: ${e}, VTT URL: ${t}`),null;const r=await i.text(),o=new Blob([r],{type:"text/vtt"});return URL.createObjectURL(o)}catch(i){const r=i instanceof Error?i.message:String(i);return(0,c.vV)(h.gl8,"Error PARSING VTT caption file",`Video ID: ${e}, VTT URL: ${t}`,{errorMessage:r}),null}}function v(t){const e=t.textTracks||[];if(e.length>0&&e[0]){e[0].mode="showing"}}var p=i(66345),g=i(17918);class f{get isScrollPreviewCapped(){return this.scrollLoopCount>=this.maxScrollLoops}get isNearScrollPreviewCapped(){return this.scrollLoopCount>this.maxScrollLoops-1}get videoPlayer(){var t;return null!==(t=this.config)&&void 0!==t&&t.enableVideoTelemetry?this.nativeVideoPlayer:this.videoElement}constructor(t){var e,i,r;if(this.type="video",this.isHoverTriggered=!1,this.isOneTimeVideoPlayedOnScroll=!1,this.isForInlinePlayer=!1,this.eventHandlers={},this.isVideoPlaying=!1,this.hidePreviewBadges=!1,this.shouldRenderPreviewBadges=!1,this.isPreviewable=!1,this.isPortrait=!1,this.displayVideoPreviewCta=!1,this.isVideoLoaded=!1,this.isCompleted=!1,this.hasCompletedOnce=!1,this.scrollLoopCount=0,this.maxScrollLoops=1,this.handleAutoPlayPreferenceChange=t=>{var e;const i=this.filterPreviewTriggers(this.originalPreviewTriggers,t);if(this.arePreviewTriggerSetsEqual(this.activePreviewTriggers,i))return;if(this.activePreviewTriggers=i,!this.videoElement||!this.previewManagerInstance)return;const r=this.overridePreviewElement??this.videoElement;var o,n;(this.previewManagerInstance.removePlayer(this),this.previewManagerInstance.addPlayer(this,this.activePreviewTriggers,r,null===(e=this.config)||void 0===e?void 0:e.sharedPreviewElementId),this.activePreviewTriggers.includes("scroll"))?null===(o=(n=this.previewManagerInstance).determineActiveVideo)||void 0===o||o.call(n):this.pause()},this.onVideoLoaded=()=>{this.isVideoLoaded=!0},!t.useMobile&&(0,d.h_)())return;const{videoElement:o,overridePreviewElement:n,config:s,enablePreloadOnSetupTime:c,hidePreviewBadges:h,isForInlinePlayer:u,onHoverOtherVideoCallback:v}=t;this.cardElement=t.cardElement,this.config=s||{},this.videoData=t.videoData,this.motionThumbnailUrl=t.videoData.motionThumbnailUrl,this.isPreviewable=Boolean(null===(e=t.videoData.videoFile)||void 0===e?void 0:e.url)||this.isCNVideoPreviewable,this.logError=t.logError,this.videoElement=o,this.overridePreviewElement=n,this.videoFile=t.videoData.videoFile,this.id=t.videoData.id,this.isPortrait=this.videoFile&&(0,d.CT)(this.videoFile.width,this.videoFile.height)<1,this.type="video",this.hidePreviewBadges=h,this.originalPreviewTriggers=[...t.previewTriggers];const f=null===(i=this.config)||void 0===i||!i.enableUserAutoPlaySettings||(0,p.G)();this.activePreviewTriggers=this.filterPreviewTriggers(this.originalPreviewTriggers,f),this.isForInlinePlayer=u,this.onHoverOtherVideoCallback=v;const m={enableScrollPreview:null==s?void 0:s.enableVideoCardScroll,enableFasterPlayer:null==s?void 0:s.enableFasterPlayer,enableVideoPostScroll:null==s?void 0:s.enableVideoPostScroll,disableIfInfopaneExists:null==s?void 0:s.disableVideoPreviewATF};if(this.videoElement){var x,b;this.videoElement.addEventListener("loadeddata",this.onVideoLoaded,{once:!0}),c&&this.preload(),(0,g.dT)().then(()=>{this.injectClosedCaptions()}),this.previewManagerInstance=l.E.getInstance(m);const t=this.overridePreviewElement??this.videoElement;null===(x=this.previewManagerInstance)||void 0===x||x.addPlayer(this,this.activePreviewTriggers,t,null===(b=this.config)||void 0===b?void 0:b.sharedPreviewElementId),this.onHoverOtherVideoCallback&&this.previewManagerInstance.registerOnMouseEnterListener(this.onHoverOtherVideoCallback)}this.cardElement&&this.originalPreviewTriggers.includes("hover")&&this.registerHoverHandlers(this.cardElement),null!==(r=this.config)&&void 0!==r&&r.enableVideoTelemetry&&this.videoElement&&this.setupVideoTelemetry(t.videoData.videoDurationMs,t.videoData.title),this.isCNVideoPreviewable&&this.videoPlayer&&(this.videoPreviewUrl=(0,a.x3)(this.motionThumbnailUrl)),this.initializeAutoPlayPreferenceHandling(),this.checkAspectRatio()}initializeAutoPlayPreferenceHandling(){var t,e;this.videoElement&&null!==(t=this.config)&&void 0!==t&&t.enableVideoCardScroll&&null!==(e=this.config)&&void 0!==e&&e.enableUserAutoPlaySettings&&this.originalPreviewTriggers.includes("scroll")&&(this.autoPlayPreferenceUnsubscribe=(0,p.Z)(this.handleAutoPlayPreferenceChange))}async setupVideoTelemetry(t,e){var r;const{NativeVideoPlayer:o,VideoCardManager:n}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679));if(this.videoElement&&null!==(r=this.config)&&void 0!==r&&r.enableVideoTelemetry){const i={video:{id:this.id,durationSec:t,title:e||"",sourceId:"",categories:[],isWebContent:!1,isVideoPreview:!0},isAutoplay:!1,isFirstVideoFromPlaylist:!1,isInline:!0,isLocal:!1};this.nativeVideoPlayer=new o,this.nativeVideoPlayer.initialize({playerInfo:i,videoElement:this.videoElement});const r=n.getInstance();r.enableTelemetry(),r.registerPlayer(this.id,this.nativeVideoPlayer)}}async deregisterTelemetry(){var t;if(null!==(t=this.config)&&void 0!==t&&t.enableVideoTelemetry){const{VideoCardManager:t}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679));t.getInstance().deregisterPlayer(this.id)}}dispose(){var t;this.previewManagerInstance&&this.previewManagerInstance.removePlayer(this),this.onHoverOtherVideoCallback&&this.previewManagerInstance.unregisterOnMouseEnterListener(this.onHoverOtherVideoCallback),this.unregisterHoverHandlers(this.cardElement),this.deregisterTelemetry(),null===(t=this.autoPlayPreferenceUnsubscribe)||void 0===t||t.call(this),this.autoPlayPreferenceUnsubscribe=void 0}play(){var t,e;if(this.isScrollPreviewCapped&&!this.isHoverTriggered)return;const i=!this.isVideoLoaded&&"auto"===(null===(t=this.videoElement)||void 0===t?void 0:t.preload);null===(e=this.videoPlayer)||void 0===e||!e.src||i?(clearTimeout(this.playTimer),this.playTimer=window.setTimeout(()=>{this.play()},150)):this.videoPlayer&&this.videoPlayer.paused&&(this.videoElement.attributes["data-stay-pause"]||this.playVideo())}pause(){var t;clearTimeout(this.playTimer),null===(t=this.previewManagerInstance)||void 0===t||t.resetPreviewState(this),this.videoPlayer&&(this.videoPlayer.pause(),this.isVideoPlaying=!1)}resetCurrentTime(){this.videoPlayer&&(this.videoPlayer.currentTime=0,this.isCompleted=!1)}restartVideo(){this.videoPlayer&&(this.resetCurrentTime(),this.videoPlayer.play())}playVideo(){var t;this.isOneTimeVideoPlayedOnScroll&&(this.isOneTimeVideoPlayedOnScroll=!1,this.videoPlayer.currentTime=0),null===(t=this.videoPlayer)||void 0===t||t.play().then(()=>{this.isVideoPlaying=!0,this.displayVideoPreviewCta=!1}).catch(t=>{var e;"object"==typeof t&&null!==(e=t.message)&&void 0!==e&&e.includes("The play() request was interrupted by a call to pause()")||this.logError(`Error playing video - ${t}`),this.isVideoPlaying=!1})}registerHoverHandlers(t){this.isForInlinePlayer?this.registerHoverHandlerForInlinePlayer(t):(this.eventHandlers={hoverStart:t=>this.hoverStart(t),hoverEnd:t=>this.hoverEnd(t)},t.addEventListener("mouseenter",this.eventHandlers.hoverStart),t.addEventListener("mouseleave",this.eventHandlers.hoverEnd))}unregisterHoverHandlers(t){this.isForInlinePlayer?this.unregisterHoverHandlerForInlinePlayer(t):(null==t||t.removeEventListener("mouseenter",this.eventHandlers.hoverStart),null==t||t.removeEventListener("mouseleave",this.eventHandlers.hoverEnd))}registerHoverHandlerForInlinePlayer(t){this.eventHandlers={hoverStart:t=>this.hoverStartForInlinePlayer(t)},t.addEventListener("mouseenter",this.eventHandlers.hoverStart)}async hoverStartForInlinePlayer(t){const{VideoCardManager:e}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679)),r=null==e?void 0:e.getInstance();if(!r)return;const o=r.getPlayer(this.id);null!=o&&o.isPlaying||(r.pauseAll(),null==o||o.play())}async unregisterHoverHandlerForInlinePlayer(t){null==t||t.removeEventListener("mouseenter",this.eventHandlers.hoverStart);const{VideoCardManager:e}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679));(null==e?void 0:e.getInstance()).deregisterPlayer(this.id)}hoverStart(t){var e;this.shouldRenderPreviewBadges=!this.hidePreviewBadges,this.isHoverTriggered=!0,null===n.YT||void 0===n.YT||n.YT.addOrUpdateTmplProperty("VideoHoverView","1"),this.displayVideoPreviewCta||this.isPreviewable&&(null===(e=this.previewManagerInstance)||void 0===e||e.videoMouseEnterCallback(this))}clickStart(){var t,e;let i=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];this.displayVideoPreviewCta||!i&&null!==(t=this.previewManagerInstance)&&void 0!==t&&t.isPlaying||(this.videoPlayer&&(this.videoPlayer.currentTime=0),this.isHoverTriggered=!1,this.isPreviewable&&(null===(e=this.previewManagerInstance)||void 0===e||e.videoMouseClickCallback(this)))}hoverEnd(t){var e;this.isHoverTriggered&&(null===(e=this.previewManagerInstance)||void 0===e||e.videoMouseLeaveCallback(this));this.isHoverTriggered=!1}onTimeUpdate(){if(!this.config||!this.videoPlayer)return;let t=this.videoPlayer.duration?Math.min(this.videoPlayer.duration,10):10;if(this.config.enableOneTimeVideoPlay&&!this.isHoverTriggered&&(t=Math.min(t,this.config.oneTimeVideoPlayLimit)),this.videoPlayer.currentTime>=t){if(this.isCompleted=!0,this.hasCompletedOnce||(this.hasCompletedOnce=!0),this.config.enableVideoPreviewCta&&!this.displayVideoPreviewCta)return void this.enableVideoPreviewCta();if(this.config.enableOneTimeVideoPlay&&!this.isHoverTriggered)return this.isOneTimeVideoPlayedOnScroll=!0,void this.pause();this.config.capScrollPreview&&!this.isHoverTriggered&&this.scrollLoopCount++;this.isScrollPreviewCapped&&!this.isHoverTriggered||this.config.enablePauseOnComplete&&this.isHoverTriggered?this.pause():this.restartVideo(),this.config.enableVideoTelemetry&&this.videoPlayer.duration>=t&&(this.fireVideoEnded(),this.fireVideoPlay())}}enableVideoPreviewCta(){this.displayVideoPreviewCta=!0,this.videoPlayer.currentTime=0,this.previewCtaTimer=window.setTimeout(()=>{this.disableVideoPreviewCta()},1e4),this.pause()}disableVideoPreviewCta(){clearTimeout(this.previewCtaTimer),this.displayVideoPreviewCta=!1}fireVideoEnded(){var t;null===(t=this.videoElement)||void 0===t||t.dispatchEvent(new CustomEvent("ended",{cancelable:!1,bubbles:!1}))}fireVideoPlay(){var t;null===(t=this.videoElement)||void 0===t||t.dispatchEvent(new CustomEvent("play",{cancelable:!1,bubbles:!1}))}checkAspectRatio(){const t=this.videoElement;null==t||t.addEventListener("loadedmetadata",()=>{this.isPortrait=t.videoWidth<t.videoHeight},{once:!0})}get isCNVideoPreviewable(){var t;return!(null===(t=this.config)||void 0===t||!t.enableVideoPreview||!this.getCNVideoProvider())}getCNVideoProvider(){if(!this.motionThumbnailUrl)return"";for(const[t,e]of Object.entries(s.yB)){if(new URL(this.motionThumbnailUrl).origin===e)return t}return""}preload(){var t;this.videoElement&&!this.isVideoLoaded&&"auto"!==this.videoElement.preload&&(this.videoElement.src||null!==(t=this.videoFile)&&void 0!==t&&t.url)&&(this.videoElement.src||(this.videoElement.src=this.videoFile.url),this.videoElement.preload="auto")}filterPreviewTriggers(t,e){var i,r;let o=[...t];return null!==(i=this.config)&&void 0!==i&&i.enableVideoCardScroll?null!==(r=this.config)&&void 0!==r&&r.enableUserAutoPlaySettings&&!e&&(o=o.filter(t=>"scroll"!==t)):o=o.filter(t=>"scroll"!==t),o}arePreviewTriggerSetsEqual(t,e){if(t.length!==e.length)return!1;const i=new Set(e),r=new Set(t);if(r.size!==i.size)return!1;for(const t of r)if(!i.has(t))return!1;return!0}async injectClosedCaptions(){var t;if(!this.videoElement||null===(t=this.videoData.closedCaptions)||void 0===t||!t.length)return;const e=function(t){const e=[];if(null!=t&&t.length)for(const i of t)e.push({kind:"captions",label:"Auto generated",srclang:i.locale||"en",src:(i.href||"")+"&vtt=true"});return e}(this.videoData.closedCaptions);await async function(t,e,i){if(t&&e&&0!==e.length){!function(t){var e;if(!t)return;(null===(e=t.querySelectorAll)||void 0===e?void 0:e.call(t,"track")).forEach(t=>t.remove());const i=t.textTracks||[];for(let t=0;t<i.length;t++)i[t].mode="disabled"}(t);for(let r=0;r<e.length;r++){const o=e[r],n=await u(o.src,i);if(n){const e=document.createElement("track");e.default=0===r,e.kind=o.kind,e.label=o.label,e.srclang=o.srclang,e.src=n,t.appendChild(e)}}}}(this.videoElement,e,this.id),this.videoElement.readyState>=1?v(this.videoElement):this.videoElement.addEventListener("loadedmetadata",()=>{v(this.videoElement)},{once:!0})}resetPreviewable(){var t;this.isPreviewable=Boolean(null===(t=this.videoData.videoFile)||void 0===t?void 0:t.url)||this.isCNVideoPreviewable}}(0,r.Cg)([o.sH],f.prototype,"isVideoPlaying",void 0),(0,r.Cg)([o.sH],f.prototype,"shouldRenderPreviewBadges",void 0),(0,r.Cg)([o.sH],f.prototype,"isPreviewable",void 0),(0,r.Cg)([o.sH],f.prototype,"previewManagerInstance",void 0),(0,r.Cg)([o.sH],f.prototype,"isPortrait",void 0),(0,r.Cg)([o.sH],f.prototype,"displayVideoPreviewCta",void 0),(0,r.Cg)([o.sH],f.prototype,"videoPreviewUrl",void 0),(0,r.Cg)([o.sH],f.prototype,"isVideoLoaded",void 0),(0,r.Cg)([o.sH],f.prototype,"isCompleted",void 0),(0,r.Cg)([o.sH],f.prototype,"hasCompletedOnce",void 0)},55023(t,e,i){"use strict";i.d(e,{S(){return o},y(){return n}});var r=i(74849);const o=r.A`
:host{--color-card-background:#333333;--color-brand-background-2:#082338;--color-brand-background-2-hover:#0c3b5e;--color-neutral-background-2:#1f1f1f;--color-neutral-background-1-hover:#3d3d3d;--color-neutral-background-1:#292929;--color-neutral-background-2-hover:#292929;--color-neutral-background-2:#141414;--color-neutral-background-alpha-2:rgba(31,31,31,0.7);--color-neutral-foreground-1:#ffffff;--color-neutral-foreground-2:#d6d6d6;--color-neutral-foreground-3:#adadad;--color-neutral-stroke-1:#666666;--color-neutral-stroke-2:#525252;--color-neutral-stroke-3:#3d3d3d;--color-neutral-stroke-hover:#757575;--color-neutral-stroke-accessible-hover:#bdbdbd;--color-neutral-stroke-accessible:#adadad;--color-neutral-stroke-alpha:rgba(255,255,255,0.1);--color-neutral-stroke-1-pressed:#6b6b6b;--color-neutral-fill-secondary:#3b3b3b;--color-neutral-fill-secondary-hover:#383838}`,n=r.A`
:host{--color-card-background:#ffffff;--color-brand-background-2:#ebf3fc;--color-brand-background-2-hover:#cfe4fa;--color-neutral-background-2:#fafafa;--color-neutral-background-1-hover:#f5f5f5;--color-neutral-background-1:#ffffff;--color-neutral-background-2-hover:#ebebeb;--color-neutral-background-2:#f5f5f5;--color-neutral-background-alpha-2:rgba(255,255,255,0.8);--color-neutral-foreground-1:#242424;--color-neutral-foreground-2:#424242;--color-neutral-foreground-3:#616161;--color-neutral-stroke-1:#d1d1d1;--color-neutral-stroke-2:#e0e0e0;--color-neutral-stroke-3:#f0f0f0;--color-neutral-stroke-hover:#c7c7c7;--color-neutral-stroke-accessible-hover:#575757;--color-neutral-stroke-accessible:#616161;--color-neutral-stroke-alpha:rgba(0,0,0,0.05);--color-neutral-stroke-1-pressed:#b3b3b3;--color-neutral-fill-secondary:#f7f7f7;--color-neutral-fill-secondary-hover:#fcfcfc}`},56237(t,e,i){"use strict";i.d(e,{x(){return r}});const r=i(74849).A` [line-clamp*="1"]{-webkit-line-clamp:1}[line-clamp*="2"]{-webkit-line-clamp:2}.va-title{-webkit-box-orient:vertical;overflow:hidden;display:-webkit-box;line-height:inherit}[size="_1x_2y"] .va-title{font-size:18px !important}.va-container-ppa{display:flex}[size="_1x_2y"] .va-container-ppa{margin-top:4px}[size="_2x_2y"] .va-container-ppa{align-items:center}.va-container-ppa .column{display:flex;flex-direction:column}.va-container-ppa .asset{display:flex}[size="_1x_2y"] .num-assets-1 .asset{max-width:268px}[size="_1x_2y"] .va-container-ppa .asset,[size="_1x_2y"] .va-container-ppa .asset,[size="_1x_2y"] .va-container-ppa .asset{max-width:122px}[size="_2x_2y"] .num-assets-1 .asset{max-width:312px}[size="_2x_2y"] .num-assets-2 .asset{max-width:236px}[size="_2x_2y"] .num-assets-3 .asset{max-width:156px}[size="_2x_2y"] .num-assets-4 .asset{max-width:118px}[size="_1x_2y"] .va-container-ppa .asset{min-width:20px;margin-bottom:4px;margin-top:2px}[size="_2x_2y"] .va-container-ppa .asset{min-width:20px;margin-bottom:4px;margin-top:2px}[size="_1x_2y"] .va-container-ppa .asset-text{margin-top:2px;font-size:12px;font-style:normal;font-weight:600;line-height:16px}[size="_2x_2y"] .va-container-ppa .asset-text{margin-top:2px;font-size:14px;font-style:normal;font-weight:600;line-height:20px}.va-container-ppa .asset-text{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.va-container-ppa .asset img{margin-right:5px}[size="_1x_2y"] .column:first-child{margin-right:24px}[size="_2x_2y"] .separator{margin-left:12px;margin-right:12px;margin-top:2px}`},57403(t,e,i){"use strict";i.d(e,{G(){return n},l(){return o}});var r=i(74849);const o=r.A` .ad-choice-footer-start .ad-choice{margin-inline-start:0px;margin-inline-end:4px;display:flex;height:24px;align-items:center}.native-ad-logo{width:16px;height:16px}.call-to-action{display:flex;justify-content:center;align-items:center;background-color:rgba(255,255,255,0.15);border:1px solid;border-image-source:linear-gradient(180deg,rgba(0,0,0,0.0578) 90.58%,rgba(0,0,0,0.1622) 100%);border-radius:4px;font-size:12px;line-height:16px;font-family:"Segoe UI","Segoe UI Midlevel",sans-serif;font-weight:400;font-style:normal}.call-to-action-text,.call-to-action-text:visited{color:#ffffff;padding:4px 12px;text-decoration:none;display:-webkit-box;-webkit-box-orient:vertical;overflow:hidden;-webkit-line-clamp:1}.call-to-action-variant{background:none;background-color:unset;font-size:14px;line-height:20px}.call-to-action-variant .call-to-action-text,.call-to-action-variant .call-to-action-text:visited{padding:0px}cs-card[size="_1x_2y"] .call-to-action{background:none;background-color:#ffffff;border:1px solid #D1D1D1}cs-card[size="_1x_2y"] .call-to-action-text,cs-card[size="_1x_2y"] .call-to-action-text:visited{color:#242424;padding:3px 8px}cs-card[size="_2x_1y"] .call-to-action{background:none;background-color:#ffffff;border:1px solid #D1D1D1}cs-card[size="_2x_1y"] .call-to-action-text,cs-card[size="_2x_1y"] .call-to-action-text:visited{color:#242424;padding:3px 8px}`,n=r.A` cs-card{background:none;background-color:#333333}cs-card[size="_1x_2y"] .call-to-action,cs-card[size="_2x_1y"] .call-to-action{background-color:#242424;border:1px solid #666666}.call-to-action-text,.call-to-action-text:visited{color:#ffffff}cs-card[size="_1x_2y"] .call-to-action-text,cs-card[size="_1x_2y"] .call-to-action-text:visited{color:#ffffff}cs-card[size="_2x_1y"] .call-to-action-text,cs-card[size="_2x_1y"] .call-to-action-text:visited{color:#ffffff}.call-to-action-variant{border:none;background:none;background-color:unset}.call-to-action-variant .call-to-action-text,.call-to-action-variant .call-to-action-text:visited{color:#479EF5}`},57415(t,e,i){"use strict";i.d(e,{J(){return s}});var r=i(59836),o=i(73893),n=i(80090),a=i(65614);function s(){r.m.define(a.G.registry),o.m.define(a.G.registry),n.m.define(a.G.registry)}},58897(t,e,i){"use strict";i.d(e,{P(){return a}});var r=i(74849),o=i(7895),n=i(8363);const a=r.A`
    ${n.X}
    ${o.s}
`},58960(t,e,i){"use strict";var r;i.d(e,{O(){return r},v(){return o}}),function(t){t.PlayActiveVideo="previewPlayActiveVideo",t.PauseAllVideos="previewPauseAllVideos "}(r||(r={}));const o={[r.PlayActiveVideo]:new CustomEvent(r.PlayActiveVideo,{bubbles:!0}),[r.PauseAllVideos]:new CustomEvent(r.PauseAllVideos,{bubbles:!0})}},59836(t,e,i){"use strict";i.d(e,{m(){return f}});var r=i(65614),o=i(92011);class n extends o.L{}var a=i(7896),s=i(61138),d=i(48751),l=i(74838),c=i(74849),h=i(64187),u=i(22131),v=i(50882);const p=c.A`
    ${(0,h.V)("inline-flex")} :host {
        box-sizing: border-box;
        font-family: ${a.O};
        font-size: ${s.k};
        font-weight: 400;
        line-height: ${s.F};
        align-items: center;
        color: ${d.l};
        min-height: 16px;
    }

    .content {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        align-self: baseline;
    }

    ::slotted([slot="image"]) {
        display: flex;
        margin-inline-end: calc(${l.vR} * 2px);
    }
`.withBehaviors((0,u.mr)(c.A`
            :host,
            .content {
                color: ${v.A.ButtonText};
                fill: currentcolor;
            }
        `)),g=i(96950).qy`
    <slot name="image"></slot>
    <span part="content" class="content">
        <slot></slot>
    </span>
`,f=n.compose({name:`${r.G.prefix}-attribution`,styles:p,template:g})},61637(t,e,i){"use strict";var r=i(65614),o=i(79454),n=i(31782),a=i(69329),s=i(29652),d=i(28160),l=i(8481),c=i(5569),h=i(87582),u=i(50866);class v extends c.d{constructor(){super(...arguments),this.getResponsiveCardStyles=t=>t.fullSizeCardWidth?`width: ${t.fullSizeCardWidth};`:"",this.overrideIndicatorStyles=t=>{if(this.cardSize()===u.qJ._1x_1y){var e;const i="204px",r="98px",o=(null===(e=document)||void 0===e||null===(e=e.dir)||void 0===e?void 0:e.toLowerCase())===h.OP.ltr?"left":"right";let n=`${o}: ${i}`;return t.fullSizeCardWidth&&(n=`${o}: calc(${t.fullSizeCardWidth} - ${r})`),n}return""}}}var p=i(96950),g=i(7895),f=i(43612),m=i(69259),x=i(39957),b=i(60402),y=i(14475),w=i(89064);const $=v.compose({name:"cs-article-card-t1-full",styles:g.T,template:(_={attribution:p.qy`${o.Au}`,footerStart:p.qy`${n.xZ}`,footerEnd:p.qy`${a.IL}`,hideStory:p.qy`${s.Y}${d.Z}`,title:p.qy`${l.B2}`},p.qy` ${(0,m.z)(t=>t.data,p.qy`${(0,x.ux)(t=>[t.data],p.qy`<cs-card class="card-outer ${t=>t.enableHoverShowAbstract&&t.imageData?"card-outer-hsa":""}" card-fill-color="${t=>t.cardFillColor}" card-secondary-color="${t=>t.cardSecondaryColor}" gradient-angle="${t=>t.gradientAngle}" size="${t=>t.cardSize}" card-title-size="${t=>t.doubleWideArticleCardTitleSize}" style="${(t,e)=>e.parent.getResponsiveCardStyles&&e.parent.getResponsiveCardStyles(t)}" ref="${(t,e)=>t.metadata&&t.metadata.ref&&t.metadata.ref(e.parent)}" ${(0,b.K)("outerCSCard")}><cs-content-card class="card-content ${t=>{var e;return 1!=(null===(e=t.displaySettings)||void 0===e?void 0:e.columnCount)||!t.enableDynamicHeightCard||t.immersiveCard&&t.mediaType?"":"one-col"}}" id="contentcard_${t=>t.id}" href="${t=>t.destinationUrl}" media-type="${t=>t.mediaType}" size="${t=>t.cardSize}" title="${t=>t.disableCardTitleTooltip?"":t.title}" target="${t=>t.openLinksInNewTab?y.z._blank:t.defaultAnchorTarget||y.z._self}" ?immersive-card="${t=>t.immersiveCard&&t.mediaType}" :anchorTelemetryTag="${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}" data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.contentCard)||void 0===e?void 0:e.getMetadataTag()}}" t-image-ratio="${t=>t.imageRatio?t.imageRatio:""}" @click="${(t,e)=>!e.parent.clickHandler||e.parent.clickHandler(t,e)}" @mouseenter=${(t,e)=>{e.event&&e.parent.hoverTelemetryHelper&&e.parent.hoverTelemetryHelper.onMouseEnter(e.event.currentTarget,t.enableHover)}} @mouseleave=${(t,e)=>{e.event&&e.parent.hoverTelemetryHelper&&e.parent.hoverTelemetryHelper.onMouseLeave(e.event.currentTarget,t.enableHover)}} data-content-id=${t=>t.id}>${(0,m.z)(t=>t.isSlideshow&&t.contentIndicator,(t,e)=>(0,f.f)(t.contentIndicator,()=>e.parent.overrideIndicatorStyles(t)))} ${(0,m.z)(t=>t.mediaType,p.qy`<img alt="${t=>t.imageData&&t.imageData.altText}" class="card-image ${t=>t.useLightShadow?"lightShadow":""}" slot="media" style="${(t,e)=>e.parent.getResponsiveCardImageHeightStyle&&e.parent.getResponsiveCardImageHeightStyle(t)}" src="${t=>t.imageData&&t.imageData.source}" @load="${t=>(0,w.tg)(t)}" @error="${t=>(0,w.tg)(t)}" />`)} ${t=>{!t.imageData&&t.visualReadinessCallback&&t.visualReadinessCallback()}} ${(0,m.z)(t=>t.abstract,p.qy`<div slot="abstract">${t=>t.abstract}</div>`)} ${_.title??""} ${_.attribution??""} ${(0,m.z)(t=>!t.hideActionTray&&_.footerStart,p.qy`${_.footerStart}`)} ${(0,m.z)(t=>!t.hideActionTray&&_.footerEnd,p.qy`${_.footerEnd}`)} ${(0,m.z)(t=>t.cardActionsTooltips&&t.cardActionClickHandler&&!t.useMobile&&_.hideStory,p.qy`${_.hideStory}`)}</cs-content-card></cs-card>`)} `)}`)});var _,k=i(84056),z=i(65183),C=i(82095);class S extends C.O{constructor(){super(...arguments),this.getResponsiveCardStyles=t=>t.fullSizeCardWidth?`width: ${t.fullSizeCardWidth};`:""}}var T=i(10894),E=i(74849),P=i(89580);const F=E.A` [size="_1x_1y"] .card-title{font-size:${P.Y};line-height:20px}[size="_1x_2y"] .card-title{font-size:18px;line-height:${P.v}}[size="_2x_2y"] .card-title{font-size:22px;line-height:26px}[size="_1x_1y"] span[slot="media-overlay"]{width:34px;height:34px}`,A=E.A`
    ${T.i}
    ${F}
`,I=p.qy`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="20" height="20"><path d="M17.2221 8.68458C18.2586 9.25438 18.2586 10.7437 17.2221 11.3135L7.22259 16.8105C6.22292 17.36 5 16.6367 5 15.496L5 4.50214C5 3.36137 6.22292 2.63812 7.22259 3.18766L17.2221 8.68458Z"/></svg>`,M=S.compose({name:"cs-video-card-t1-full",styles:A,template:function(t){return p.qy`${(0,m.z)(t=>t.data,p.qy`${(0,x.ux)(t=>[t.data],p.qy`<cs-card class="card-outer" card-fill-color="${t=>t.cardFillColor}" card-secondary-color="${t=>t.cardSecondaryColor}" gradient-angle="${t=>t.gradientAngle}" size="${t=>t.cardSize}" style="${(t,e)=>e.parent.getResponsiveCardStyles&&e.parent.getResponsiveCardStyles(t)}" ${(0,b.K)("outerCSCard")}><cs-content-card class="card-content" id="contentcard_${t=>t.id}" href="${t=>t.destinationUrl}" media-type="${t=>t.mediaType}" ?animate-video="${(t,e)=>e.parent.isVideoPlaying}" size="${t=>t.cardSize}" title="${t=>t.disableCardTitleTooltip?"":t.title}" target="${t=>t.openLinksInNewTab?y.z._blank:t.defaultAnchorTarget||y.z._self}" ?immersive-card="${t=>t.immersiveCard}" :anchorTelemetryTag="${t=>t.telemetryContext&&t.telemetryContext.destination&&t.telemetryContext.destination.getMetadataTag()}" data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.contentCard)||void 0===e?void 0:e.getMetadataTag()}}" @click="${(t,e)=>!e.parent.clickHandler||e.parent.clickHandler(t,e)}" data-content-id=${t=>t.id}>${(0,m.z)(t=>t.mediaType,p.qy` ${(0,m.z)((t,e)=>!e.parent.config.enableVideoNativePlayer,p.qy`<div slot="media" style="${(t,e)=>e.parent.getResponsiveCardImageHeightStyle&&e.parent.getResponsiveCardImageHeightStyle(t)}"><img alt="${t=>t.imageData&&t.imageData.altText}" class="card-image video-placeholder ${t=>t.useLightShadow?"lightShadow":""}" src="${t=>t.imageData&&t.imageData.source}" style="${(t,e)=>e.parent.getResponsiveCardImageHeightStyle&&e.parent.getResponsiveCardImageHeightStyle(t)}" @load="${w.tg}" @error="${w.tg}" ${(0,b.K)("image")} />${(t,e)=>{var i;return t.useMobile&&0===(null===(i=t.externalVideoFiles)||void 0===i?void 0:i.length)?null:e.parent.renderVideoCard(t.videoCardConfigInfo,t.id,t.cardSize,t)}}</div>`)} ${(0,m.z)((t,e)=>!e.parent.config.enableVideoNativePlayer,p.qy` ${(0,m.z)(t=>t.videoData&&t.videoData.url,p.qy`<video muted slot="media" preload="none" poster="${t=>t.imageData&&t.imageData.source}" @load="${w.tg}" @error="${t=>t.logVideoError()}" ${(0,b.K)("video")}><source src="${t=>t.videoData&&t.videoData.url}" type="video/mp4"></source></video>`)} ${(0,m.z)(t=>!t.videoData,p.qy`<img slot="media" altText="${t=>t.imageData&&t.imageData.altText}" class="card-image ${t=>t.useLightShadow?"lightShadow":""}" src="${t=>t.imageData&&t.imageData.source}" @load="${w.tg}" @error="${w.tg}" ${(0,b.K)("image")} />`)} `)} `)}<span slot="media-overlay">${I}</span>${t=>{!t.imageData&&t.visualReadinessCallback&&t.visualReadinessCallback()}} ${(0,m.z)(t=>t.abstract,p.qy`<div slot="abstract">${t=>t.abstract}</div>`)} ${t.title??""} ${t.attribution??""} ${t.footerStart??""} ${t.footerEnd??""} ${(0,m.z)(e=>e.cardActionsTooltips&&e.cardActionClickHandler&&!e.useMobile&&t.hideStory,p.qy`${t.hideStory}`)}</cs-content-card></cs-card>`)} `)}`}({attribution:p.qy`${o.Au}`,footerStart:p.qy`${n.xZ}`,footerEnd:p.qy`${a.IL}`,hideStory:p.qy`${s.Y}${d.Z}`,title:p.qy`${l.B2}`})});var L=i(12628),V=i(45214);(0,k.J)(),$.define(r.G.registry),(0,z.s)(),(0,k.J)(),M.define(r.G.registry),(0,V.O)(),(0,L.A)()},62096(t,e,i){"use strict";i.d(e,{J(){return r}});const r=i(74849).A`
`},64183(t,e,i){"use strict";i.d(e,{o(){return a},t(){return n}});var r=i(68009),o=i(49399);function n(t,e,i,o,n,a,s){const d=t.closestIndexOf(e);return null==s&&(s=(0,r.F)(e)),{rest:t.get(d+s*i),hover:t.get(d+s*o),active:t.get(d+s*n),focus:t.get(d+s*a)}}function a(t,e,i,r,a,s,d=void 0,l,c,h,u,v=void 0){return(0,o.H)(e)?n(t,e,l,c,h,u,v):n(t,e,i,r,a,s,d)}},65114(t,e,i){"use strict";i.d(e,{yB(){return r}});const r=Object.freeze({Yidianzixun:"https://msn2.go2yd.com",Renmin:"https://jfmicsovideos.peopletech.cn"});Object.freeze({Yidianzixun:"https://doris.yidianzixun.com"})},65183(t,e,i){"use strict";i.d(e,{s(){return D}});var r,o=i(57415),n=i(3817),a=i(28160),s=i(8481),d=i(56911),l=i(40331);!function(t){t.none="none",t.default="default",t.imageShimmer="imageShimmer",t.imageShimmerOnce="imageShimmerOnce",t.imageZoomIn="imageZoomIn",t.extraScreen="extraScreen",t.extraScreenInitial="extraScreenInitial",t.extraScreenWhiteBg="extraScreenWhiteBg"}(r||(r={}));var c=i(77367),h=i(38493);class u extends l.q{constructor(){super(...arguments),this.enableAdAnimation=!1,this.adAnimationType=r.none,this.getResponsiveCardStyles=t=>t.fullSizeCardWidth&&t.fullSizeCardHeight?`width: ${t.fullSizeCardWidth}; height: ${t.fullSizeCardHeight};`:t.fullSizeCardWidth?`width: ${t.fullSizeCardWidth};`:""}get showDefaultImage(){return!this.enableAdAnimation||this.adAnimationType===r.none||this.adAnimationType===r.default||this.adAnimationType===r.extraScreenInitial||this.adAnimationType===r.extraScreenWhiteBg}get showImageShimmer(){return this.enableAdAnimation&&this.adAnimationType===r.imageShimmer}get showImageShimmerOnce(){return this.enableAdAnimation&&this.adAnimationType===r.imageShimmerOnce}get showImageZoomIn(){return this.enableAdAnimation&&this.adAnimationType===r.imageZoomIn}get showExtraScreen(){return this.enableAdAnimation&&this.adAnimationType===r.extraScreen}get showExtraScreenInitial(){return this.enableAdAnimation&&this.adAnimationType===r.extraScreenInitial}get showExtraScreenWhiteBg(){return this.enableAdAnimation&&this.adAnimationType===r.extraScreenWhiteBg}connectedCallback(){var t,e,i,r,o,n;(super.connectedCallback(),this.cardOverlayRef)||(this.cardOverlayRef=(null===(t=this.shadowRoot)||void 0===t||null===(e=t.querySelector)||void 0===e?void 0:e.call(t,".card-overlay"))||void 0);this.scaleImageRef||(this.scaleImageRef=(null===(i=this.shadowRoot)||void 0===i||null===(r=i.querySelector)||void 0===r?void 0:r.call(i,".card-image"))||void 0);this.imageShimmerRef||(this.imageShimmerRef=(null===(o=this.shadowRoot)||void 0===o||null===(n=o.querySelector)||void 0===n?void 0:n.call(o,".light-sweep-wrapper"))||void 0);this.logAdAnimationType()}dataChanged(t,e){var i,r;(super.dataChanged(t,e),this.enableAdAnimation)&&((null==t||null===(i=t.imageData)||void 0===i?void 0:i.source)!==(null==e||null===(r=e.imageData)||void 0===r?void 0:r.source)&&(this.restartAnimation(),this.logAdAnimationType()))}restartAnimation(){switch(this.adAnimationType){case r.imageZoomIn:this.scaleImageRef&&(this.scaleImageRef.style.animation="none",window.requestAnimationFrame(()=>{this.scaleImageRef.style.animation=""}));break;case r.extraScreen:this.cardOverlayRef&&(this.cardOverlayRef.style.animation="none",window.requestAnimationFrame(()=>{this.cardOverlayRef.style.animation=""}));break;case r.imageShimmerOnce:this.imageShimmerRef&&(this.imageShimmerRef.style.setProperty("--restart-animation","none"),window.requestAnimationFrame(()=>{this.imageShimmerRef.style.setProperty("--restart-animation","lightSweep 6s cubic-bezier(.1,.67,.58,.35)")}));case r.imageShimmer:case r.none:case r.default:}}logAdAnimationType(){this.adAnimationType!==r.none&&c.YT.addOrUpdateTmplProperty("ad_animation",this.adAnimationType)}}(0,d.Cg)([(0,h.CF)({attribute:"enable-ad-animation",mode:"boolean"})],u.prototype,"enableAdAnimation",void 0),(0,d.Cg)([(0,h.CF)({attribute:"ad-animation"})],u.prototype,"adAnimationType",void 0);var v=i(96950),p=i(74849),g=i(58897),f=i(12640),m=i(77078);const x=p.A` cs-card{background-color:var(--gradient-start-color) !important}`,b=p.A`
    ${(0,m.vM)()&&x} .mobile-image{width:84px;height:84px;grid-area:1 / 2 / auto / auto}cs-content-card::part(text){padding-top:var(--content-text-padding-top,12px)}cs-card.withCustomTheme{--default-native-ad-card-bg:linear-gradient( var(--gradient-angle),var(--customized-native-ad-card-fill-color,var(--gradient-start-color)) 35.59%,var(--customized-native-ad-card-secondary-color,var(--gradient-end-color)) 100% );background:var(--customized-native-ad-card-bg,var(--default-native-ad-card-bg))}cs-card.withCustomTheme cs-content-card{--neutral-foreground-rest:var(--customized-native-ad-card-text-color)}.card-ourter{position:relative}.card-overlay{position:absolute;top:0;bottom:0;left:0;right:0;z-index:10;opacity:1;background:#EBF2F6;display:flex;flex-direction:column;color:#242424;padding:var(--action-tray-padding,10px) var(--content-padding,16px);cursor:pointer;pointer-events:none}.card-overlay .overlay-content{flex:1;display:flex;flex-direction:column;justify-content:center;align-items:center}.card-overlay .overlay-content .provider-name{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;overflow:hidden;text-overflow:ellipsis;font-size:12px;font-weight:400;user-select:none}.card-overlay .overlay-content .ads-description{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;text-overflow:ellipsis;font-size:18px;font-weight:600;user-select:none;text-align:center;margin-top:10px}.card-overlay .overlay-content .circle-button{width:36px;height:36px;background:#2169EB;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0px 3px 6px 0px #00000040;border:none;margin-top:12px}.circle-button svg{display:block}.card-overlay .footer-container{display:flex;justify-content:flex-end;align-items:center;position:absolute;bottom:10px;left:0;right:16px}.card-fade-effect{animation:fadeEffect 15s ease-in-out infinite}@keyframes fadeEffect{0%{opacity:0}6.67%{opacity:0}21.33%{opacity:1}30%{opacity:1}40%{opacity:0}100%{opacity:0}}@media screen and (forced-colors:active){:host{display:block}}@keyframes lightSweep{0%{transform:translateX(-100%)}40%{transform:translateX(100%)}100%{transform:translateX(100%)}}.light-sweep-wrapper{position:relative;overflow:hidden;display:inline-block}.light-sweep-wrapper::after{content:'';position:absolute;top:0;left:0;width:200%;height:100%;background:linear-gradient(120deg,transparent 0%,transparent 43%,rgba(255,255,255,0.2) 46.5%,transparent 50%);transform:translateX(-100%);animation:var(--restart-animation,lightSweep 6s cubic-bezier(.1,.67,.58,.35) infinite);pointer-events:none}.light-sweep-wrapper.once::after{animation-iteration-count:1}@keyframes scaleDown{0%{transform:scale(1.18)}10%{transform:scale(1)}100%{transform:scale(1)}}.scale-image-wrapper{position:relative;overflow:hidden}.scale-image{animation:scaleDown 10s ease-out infinite;transform-origin:center center}`,y=p.A` .card-overlay{background:#EBF2F6;color:#242424}.card-overlay-white{background:linear-gradient(112.05deg,#FFFFFF,#E1E1E1)}`,w=p.A` .card-overlay{background:linear-gradient(112.05deg,#565656,#272727);color:#ffffff}`,$=p.A`
    ${g.P}
    ${b}
`.withBehaviors(new f.N(y,w));var _=i(22162),k=i(69259),z=i(39957),C=i(60402),S=i(14475),T=i(77793),E=i(86240),P=i(26391);function F(t,e){(0,E.mQ)(t,e,"SuperNativeAdCard"),t&&t.visualReadinessCallback&&t.visualReadinessCallback(3,_.j.image)}function A(t,e){F(t,e),(0,P.T)({id:t.id,rLink:t.destinationUrl,imgLink:t.imageData&&t.imageData.source})}var I=i(93808);const M=u.compose({name:"cs-native-ad-card-t1-full",styles:$,template:(L={footerEnd:v.qy`${n.$n}`,footerStart:v.qy`${I.bW}`,hideStory:v.qy`${a.Z}`,title:v.qy`${s.B2}`},v.qy`${(0,k.z)(t=>null==t?void 0:t.data,v.qy`${(0,z.ux)(t=>[t.data],v.qy`<cs-card ${(0,C.K)("outerCSCard")} class="card-outer ${t=>t.enableHoverShowAbstract?"card-outer-hsa":""} ${(t,e)=>e.parent.isWindowIntraArticle()?"card-full-size":""}${t=>t.enableCustomizeCardFillColor?" withCustomTheme ":""}" card-fill-color="${t=>t.cardFillColor}" card-secondary-color="${t=>t.cardSecondaryColor}" gradient-angle="${t=>t.gradientAngle}" id="native_ad_${t=>t.id}" size="${t=>t.cardSize}" style="${(t,e)=>e.parent.getResponsiveCardStyles&&e.parent.getResponsiveCardStyles(t)}"><cs-content-card class="card-content" id="${t=>t.id}" href="${t=>t.destinationUrl}" media-type="${t=>t.mediaType}" size="${t=>t.cardSize}" title="${t=>t.disableCardTitleTooltip?"":t.title}" target="${(t,e)=>e.parent.targetTag??S.z._blank}" ?immersive-card="${t=>t.immersiveCard}" :anchorTelemetryTag="${t=>t.adTelemetryContext&&t.adTelemetryContext.destination&&t.adTelemetryContext.destination.getMetadataTag()}" data-t="${t=>{var e;return t.id?null===(e=t.adTelemetryContext)||void 0===e||null===(e=e.nativeAdCard)||void 0===e?void 0:e.getMetadataTag():""}}" ${(0,T.Ib)()} @click="${(t,e)=>!e.parent.clickHandler||e.parent.clickHandler(t,e)}" @mouseenter=${(t,e)=>{e.event&&e.parent.handleTelemetryMouseEnter(e.event.currentTarget),e.parent.deferRenderAfterHover&&e.parent.startRenderInvisibaleElementAfterHover()}} @mouseleave=${(t,e)=>{e.event&&e.parent.handleTelemetryMouseLeave(e.event.currentTarget)}}>${(0,k.z)(t=>t.mediaType,v.qy` ${(0,k.z)((t,e)=>e.parent.showDefaultImage,v.qy`<img alt="${t=>t.imageData&&t.imageData.altText}" id="${t=>t.id+"-img"}" class="card-image ${t=>t.useLightShadow?"lightShadow":""} ${t=>t.isViewsSquareAd?"card-image-square":"mobile-image"}" slot="media" src="${t=>t.imageData&&t.imageData.source}" @load="${(t,e)=>F(t,e)}" @error="${(t,e)=>A(t,e)}" />`)} ${(0,k.z)((t,e)=>e.parent.showImageShimmer||e.parent.showImageShimmerOnce,v.qy`<div class="light-sweep-wrapper ${(t,e)=>e.parent.showImageShimmerOnce?"once":""}" slot="media"><img alt="${t=>t.imageData&&t.imageData.altText}" id="${t=>t.id+"-img"}" class="card-image ${t=>t.useLightShadow?"lightShadow":""} ${t=>t.isViewsSquareAd?"card-image-square":"mobile-image"}" src="${t=>t.imageData&&t.imageData.source}" @load="${(t,e)=>F(t,e)}" @error="${(t,e)=>A(t,e)}" /></div>`)} ${(0,k.z)((t,e)=>e.parent.showImageZoomIn,v.qy`<div class="scale-image-wrapper" slot="media"><img alt="${t=>t.imageData&&t.imageData.altText}" id="${t=>t.id+"-img"}" class="card-image ${t=>t.useLightShadow?"lightShadow":""} ${t=>t.isViewsSquareAd?"card-image-square":"mobile-image"} scale-image" src="${t=>t.imageData&&t.imageData.source}" @load="${(t,e)=>F(t,e)}" @error="${(t,e)=>A(t,e)}" /></div>`)} `)} ${t=>{!t.imageData&&t.visualReadinessCallback&&t.visualReadinessCallback()}} ${(0,k.z)(t=>t.enableHoverShowAbstract,v.qy`<div slot="abstract" class="ads-abstract">${t=>t.items[0].description}</div>`)} ${L.attribution??""} ${L.title??""} ${(0,k.z)(t=>t.title&&L.footerStart,v.qy`${L.footerStart}`)} ${(0,k.z)(t=>t.title&&L.footerEnd,v.qy`${L.footerEnd}`)} ${(0,k.z)(t=>{var e;return!t.disableHideStory&&t.feedbackUrl&&!t.useMobile&&!(null!==(e=t.template)&&void 0!==e&&e.enableAdChoiceInCardActions)},v.qy`${L.hideStory??""}`)} ${(0,k.z)(t=>{var e;return(null===(e=t.template)||void 0===e?void 0:e.enableAdChoiceInCardActions)&&!t.useMobile&&t.feedbackUrl&&t.privacyUrl&&t.adChoiceIconUrl},v.qy`${L.hideStory??""}`)}</cs-content-card>${(0,k.z)((t,e)=>e.parent.showExtraScreen||e.parent.showExtraScreenInitial||e.parent.showExtraScreenWhiteBg,v.qy`<div class="card-overlay ${(t,e)=>e.parent.showExtraScreen?"card-overlay-white":""} ${(t,e)=>e.parent.showExtraScreenInitial?"card-fade-effect":""} ${(t,e)=>e.parent.showExtraScreenWhiteBg?"card-overlay-white card-fade-effect":""}"><div class="overlay-content">${t=>v.qy`<div class="provider-name">${t.items[0].providerName}</span>`} ${t=>v.qy`<div class="ads-description">${t.title}</div>`}<button class="circle-button"><svg width="10" height="14" viewBox="0 0 10 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.5 1L8.5 7L1.5 13" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div>${(0,k.z)(t=>t.title&&L.footerEnd,v.qy`<div class="footer-container">${L.footerEnd}</div>`)}</div>`)}</cs-card>`)}
`)} `)});var L,V=i(65614);const D=()=>{(0,o.J)(),M.define(V.G.registry)}},66345(t,e,i){"use strict";i.d(e,{G(){return v},Z(){return p}});var r=i(95940),o=i(15525),n=i(94043);const a="auto-play-changed",s="enabled",d=new r.E("AutoPlayPreference"),l=new Set;let c=!1;const h=()=>{d.has(s)||d.set(s,(()=>{if(!(0,n.S)())return!0;const t=(0,o.Lg)().getItem("autoSettings");if(null==t)return!0;try{const e=JSON.parse(t);if("boolean"==typeof e)return e}catch(t){}return"false"!==t.toLocaleLowerCase()})())},u=t=>{const e=t.detail;var i;e&&"boolean"==typeof e.enabled&&(i=e.enabled,h(),d.get(s)!==i&&d.set(s,i))},v=()=>(h(),d.get(s)??!0),p=t=>(0,n.S)()?(h(),l.add(t),(0,n.S)()&&!c&&(window.addEventListener(a,u),c=!0),d.subscribe(s,t,{fireImmediately:!1}),()=>{d.unsubscribe(s,t),l.delete(t),l.size||(0,n.S)()&&c&&(window.removeEventListener(a,u),c=!1)}):()=>{}},69781(t,e,i){"use strict";i.d(e,{kM(){return h},pS(){return u}});var r=i(58792),o=i(70775);const n=[],a=1e3,s=1e3,d=new Map;function l(){return"vp"===o._3.getQueryParameterByName("reqsrc",location.href)||"1"===o._3.getQueryParameterByName("vptest",location.href)}function c(t){var e;return null===r.T3||void 0===r.T3||null===(e=r.T3.CurrentRequestTargetScope)||void 0===e?void 0:e.pageExperiments.some(e=>e.includes(t))}function h(t,e,i){t&&"function"==typeof e&&!n.includes(t)&&(l()||(c("prg-mousehovrev")?(n.push(t),setTimeout(()=>{!function(t,e){if(!n.includes(t))return;e();const i=n.indexOf(t);i>-1&&n.splice(i,1)}(t,e)},i??a)):function(t,e,i){const r=Date.now(),o=d.get(t)||{enterTimer:null,lastHoverTime:0,pendingLeave:!1};if(r-o.lastHoverTime<s)return;o.enterTimer&&clearTimeout(o.enterTimer);o.enterTimer=window.setTimeout(()=>{e(),o.lastHoverTime=Date.now(),o.enterTimer=null},i||a),d.set(t,o)}(t,e,i)))}function u(t,e){if(c("prg-mousehovrev")){if(!l())if(t&&n.includes(t)){const e=n.indexOf(t);e>-1&&n.splice(e,1)}else"function"==typeof e&&e()}else!function(t,e){if(!t||"function"!=typeof e||l())return;const i=d.get(t);if(!i)return void e();if(i.enterTimer)return clearTimeout(i.enterTimer),i.enterTimer=null,void d.delete(t);i.lastHoverTime>0&&e();d.delete(t)}(t,e)}},72499(t,e,i){"use strict";i.d(e,{h(){return a}});var r=i(55023),o=i(74849),n=i(12640);const a=o.A`
@keyframes shimmereffect{from{transform:translateX(-100%)}to{transform:translateX(100%)}}.shimmer{position:relative;overflow:hidden;background:var(--colorNeutralStroke2,var(--color-neutral-stroke-2));border-radius:var(--borderRadiusLarge,6px)}.shimmer::after{content:"";position:absolute;top:0;left:0;width:100%;height:100%;background:linear-gradient(to right,transparent 0%,var(--colorNeutralStroke3,var(--color-neutral-stroke-3)) 50%,transparent 100%);animation:shimmereffect 1s infinite linear;border-radius:var(--borderRadiusLarge,6px)}.loading-attribution{width:50%}.loading-text{margin-inline-start:16px;height:15px}.loading-container{align-items:flex-start;align-self:stretch;display:flex;flex-direction:column;gap:12px;height:100%;width:100%}.loading-heading1{width:85%}.loading-heading2{width:40%}.loading-media{align-self:stretch;aspect-ratio:1.91 / 1;display:block;width:100%;border-radius:0}`.withBehaviors(new n.N(r.y,r.S))},73893(t,e,i){"use strict";i.d(e,{m(){return s}});var r=i(65614),o=i(71008),n=i(42792);const a=i(96950).qy`
    <slot></slot>
`,s=o.h.compose({name:`${r.G.prefix}-card`,styles:n.R7,template:a})},80090(t,e,i){"use strict";i.d(e,{m(){return P}});var r=i(65614),o=i(11310),n=i(7896),a=i(48751),s=i(41123),d=i(57416),l=i(62047),c=i(14996),h=i(89580),u=i(99657),v=i(86856),p=i(74849),g=i(73477),f=i(4126),m=i(22131),x=i(50882);const b=p.A`
    .text,
    .media-info,
    .gradient {
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
    }

    .action-tray {
        transition-duration: var(--video-transition-end-duration);
        transition-property: background-color;
    }

    ::slotted([slot="media-overlay"]) {
        color: #ffffff;
        fill: #ffffff;
        height: 40px;
        min-width: 40px;
        display: grid;
        padding: 0px;
        grid-auto-flow: column;
        grid-gap: 8px;
        box-sizing: border-box;
        align-items: center;
        justify-content: center;
        border-radius: 20px;
        border: 1px solid transparent;
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
        background: linear-gradient(
                    135deg,
                    rgba(0, 0, 0, 0.5) 0%,
                    rgba(0, 0, 0, 0.7) 100%
                )
                padding-box,
            linear-gradient(
                    180deg,
                    rgba(255, 255, 255, 0.4) 0%,
                    rgba(255, 255, 255, 0.2) 100%
                )
                border-box;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 22px;
        min-width: 22px;
        padding: 0 6px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 38px;
        min-width: 38px;
        padding: 0 6px;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([animate-video]) .media-info,
    :host([immersive-card][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_1x_2y"][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_2x_2y"][animate-video]) ::slotted([slot="media-overlay"]) {
        transition-delay: var(--video-transition-delay);
        transition-duration: var(--video-transition-start-duration);
        opacity: 0;
    }
`,y=p.A`
    .preload {
        transition: none !important;
    }

    :host {
        --content-padding: 16px;
        --no-image-action-tray-padding: 20px;
        --action-tray-padding: 10px;
        width: 100%;
        height: 100%;
        font-family: ${n.O};
        --video-transition-delay: 1s;
        --video-transition-start-duration: 1s;
        --video-transition-end-duration: 1s;
    }

    :host([subscibed])::after {
        position: absolute;
        content: "";
        bottom: 0;
        left: 0;
        right: 0;
        height: 4px;
        width: 100%;
        background: linear-gradient(90deg, #ffa03d 0%, #ffdb00 100%);
    }

    :host([size="_1x_2y"]),
    :host([size="_2x_2y"]) {
        --content-card-heading-font-size: 18px;
        --content-card-heading-line-height: 24px;
    }

    :host .content {
        display: grid;
        grid-template-columns: 1fr minmax(auto, 84px);
        grid-template-rows: 1fr auto;
        row-gap: 14px var(--content-padding) var(--content-padding) var(--content-padding);
        column-gap: 12px;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        color: ${a.l};
        position: relative;
    }

    :host([size="_1x_1y"]) .content {
        row-gap: 0px;
        padding: 14px var(--content-padding) 10px var(--content-padding);
    }

    :host([size="_2x_1y"]) .content {
        row-gap: 0px;
        padding: var(--content-padding) var(--content-padding) 14px var(--content-padding);
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        grid-template-columns: 1fr;
        column-gap: 0;
    }

    :host([size="_1x_2y"]) .content {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]) .content.no-image {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .content:not(.no-image) .text {
        padding-top: 12px;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .content:not(.no-image) .text {
        padding-top: 0;
    }

    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        align-items: end;
        grid-template-rows: 1fr auto auto;
    }

    :host([size="_2x_2y"]) .no-image {
        align-items: unset;
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content {
        padding: 0;
        row-gap: 0;
    }

    :host([size="_1x_1y"]) .content.no-image,
    :host([size="_2x_1y"]) .content.no-image,
    :host([size="_1x_2y"]) .content.no-image,
    :host([size="_2x_2y"]) .content.no-image {
        grid-template-rows: 1fr auto;
    }

    ::slotted([slot="abstract"]) {
        display: none;
        overflow: hidden;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: var(--abstract-max-lines, 7);
        margin-top: var(--abstract-margin-top, 5px);
    }

    .no-image ::slotted([slot="abstract"]) {
        display: -webkit-box;
        -webkit-line-clamp: var(--abstract-max-lines, 3);
    }

    :host([size="_1x_1y"]) .no-image ::slotted([slot="abstract"]),
    :host([size="_2x_1y"]) .no-image ::slotted([slot="abstract"]) {
        --abstract-max-lines: 1;
    }

    .text {
        grid-area: 1 / 1;
        padding: var(--content-padding) var(--content-padding) 0 var(--content-padding);
        overflow: hidden;
        font-size: ${s.K};
        line-height: ${s.Z};
    }

    :host([size="_1x_1y"]) .text,
    :host([size="_2x_1y"]) .text {
        padding: 0;
    }

    :host([size="_1x_1y"]) .no-image .text,
    :host([size="_2x_1y"]) .no-image .text {
        grid-column: 1 / span 2;
    }

    :host([size="_1x_2y"]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        padding: 14px var(--content-padding) 0 var(--content-padding);
        grid-row: 1;
    }

    :host([size="_2x_2y"]) .text,
    :host([size="_1x_2y"]) .text {
        grid-row: 2;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .text {
        background-color: var(--image-gradient-overlay-end-color);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray,
    :host([size="_1x_2y"]:not([immersive-card])) .action-tray,
    :host .no-image .action-tray {
        background-color: transparent;
    }

    :host([immersive-card]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        background: unset;
    }

    :host([size="_1x_2y"]) .action-tray,
    :host([size="_2x_2y"]) .action-tray {
        grid-row: 3;
        padding: 4px var(--content-padding) var(--action-tray-padding)
            var(--content-padding);
    }

    :host([immersive-card]) .action-tray,
    :host([size="_2x_2y"]) .content:not(.no-image) .action-tray {
        padding: var(--action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
    }

    .action-tray {
        grid-row: 2;
        grid-column: span 2;
        display: flex;
        position: relative;
        background-color: var(--image-gradient-overlay-end-color);
        padding: var(--action-tray-padding) var(--content-padding) var(--content-padding)
            var(--content-padding);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray {
        padding: 0;
    }

    :host([size="_2x_1y"]) .content:not(.no-image) .action-tray {
        grid-area: 2 / 1 / auto / auto;
    }

    :host([size="_1x_1y"]) .no-image .action-tray {
        padding: 4px 0 0 0;
    }

    :host([size="_1x_2y"]) .no-image .action-tray,
    :host([size="_2x_2y"]) .no-image .action-tray {
        padding: var(--no-image-action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
        background: none;
        grid-row: 2;
        grid-column: 1;
    }

    .media-info {
        display: grid;
        grid-auto-flow: column;
        width: fit-content;
        grid-gap: 4px;
        fill: white;
        color: white;
        margin-bottom: 8px;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .media-info {
        grid-row: 1;
        grid-column: 1;
        align-self: flex-end;
        margin-bottom: 6px;
        margin-inline-start: 6px;
    }

    :host([size="_2x_1y"]:not([immersive-card])) .media-info {
        grid-area: 1 / 2 / span2 / auto;
        align-self: flex-end;
        margin-bottom: 8px;
        margin-inline-start: 6px;
    }

    ::slotted([slot="media-info"]) {
        display: grid;
        align-items: center;
        grid-auto-flow: column;
        grid-gap: 3px;
        background-color: var(--image-gradient-overlay-end-color);
        border-radius: calc(${d.Pb} * 1px);
        padding: 2px 6px;
        font-size: ${l.t};
        line-height: ${l.e};
    }

    ::slotted([slot="hide-story"]) {
        box-sizing: border-box;
        align-items: center;
        background-color: #ffffff;
        border-radius: 100%;
        border: 1px solid #e5e5e5;
        color: rgba(0, 0, 0 1);
        cursor: pointer;
        display: flex;
        fill: currentcolor;
        font-family: ${n.O};
        font-size: ${s.K};
        height: 28px;
        justify-content: center;
        line-height: ${s.Z};
        margin-inline-start: 4px;
        min-width: 28px;
        outline: none;
        padding: 0;
        position: relative;
    }

    ::slotted([slot="hide-story"]:hover) {
        background-color: #f2f2f2;
    }

    ::slotted([slot="hide-story"]:active) {
        background-color: #f7f7f7;
    }

    :host .hide-story-wrapper {
        position: absolute;
        display: flex;
        flex-direction: row;
        top: var(--content-padding);
    }

    :host .hide-story {
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.1s linear;
    }

    :host(:hover) .hide-story,
    :host(:focus-within) .hide-story {
        opacity: 1;
    }

    :host ::slotted([slot="hide-story"]:${g.N}) {
        border-color: ${c.WN};
    }

    ::slotted([slot="media"]) {
        grid-column: 1;
        object-fit: cover;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media"]) {
        height: 84px;
        width: 84px;
        grid-row: 1;
        grid-column: 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media"]) {
        height: 114px;
        width: 216px;
        grid-area: 1 / 2 / span2 / 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_1x_2y"]) ::slotted([slot="media"]) {
        grid-row: 1;
        grid-column: 1;
        height: 157px;
        width: 100%;
        display: flex;
    }

    :host([size="_2x_2y"]) ::slotted([slot="media"]),
    :host([immersive-card]) ::slotted([slot="media"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
    }

    ::slotted([slot="attribution"]) {
        display: flex;
        grid-column: 1;
        grid-row: 1;
        margin-bottom: 8px;
    }

    :host([size="_1x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]),
    :host([size="_2x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]) {
        grid-column-end: 1;
    }

    .heading {
        color: ${a.l};
        fill: currentcolor;
        display: -webkit-box;
        outline: 0;
        overflow: hidden;
        text-decoration: none;
        -webkit-line-clamp: var(--heading-max-lines, 3);
        -webkit-box-orient: vertical;
        font-weight: 600;
        font-size: var(--content-card-heading-font-size, ${h.Y});
        line-height: var(--content-card-heading-line-height, ${h.v});
    }

    .heading:focus-visible {
        text-decoration: underline;
    }

    .heading:after {
        bottom: 0;
        content: "";
        height: 100%;
        left: 0;
        position: absolute;
        right: 0;
        width: 100%;
        z-index: ${u.I};
    }

    :host([size="_2x_2y"][immersive-card]) .heading {
        --heading-max-lines: 2;
    }

    .media-overlay {
        position: absolute;
        display: flex;
        align-items: center;
        justify-content: center;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        pointer-events: none;
    }

    :host([size="_1x_1y"]) .media-overlay {
        grid-column: 2;
        grid-row: 1;
        height: 84px;
        width: 84px;
    }

    :host([size="_1x_2y"]) .media-overlay {
        grid-row-start: 1;
        grid-row-end: 1;
    }

    :host([size="_2x_2y"]) .media-overlay,
    :host([immersive-card]) .media-overlay {
        top: 100px;
        align-items: unset;
    }

    :host([size="_1x_2y"]) .no-image .heading,
    :host([size="_2x_2y"]) .no-image .heading {
        --heading-max-lines: 9;
    }

    :host([size="_2x_1y"]) .media-overlay {
        grid-area: 1 / 2 / span2 / 2;
        height: 114px;
        width: 216px;
    }

    ::slotted(p) {
        font-weight: 400;
        font-size: var(--abstract-font-size, 14px);
        line-height: var(--abstract-line-height, 20px);
        font-kerning: auto;
        margin: 8px 0px 0px;
    }

    ::slotted([slot="footer-start"]),
    ::slotted([slot="footer-end"]),
    ::slotted([slot="hide-story"]) {
        z-index: ${u.D};
    }

    .footer-end,
    .footer-start {
        display: flex;
        align-items: center;
    }

    .footer-end {
        margin-inline-start: auto;
    }

    .gradient {
        background: linear-gradient(
            180deg,
            var(--image-gradient-overlay-start-color) 0%,
            var(--image-gradient-overlay-end-color) 100%
        );
        grid-row: 1;
        height: 100%;
        display: none;
    }

    :host([size="_2x_2y"]) .gradient,
    :host([immersive-card]) .gradient {
        display: block;
        height: 80px;
    }

    :host([size="_2x_2y"]) .no-image .gradient,
    .no-image .gradient {
        display: none;
    }

    :host([size="_2x_1y"]) .content {
        column-gap: 24px;
    }
`.withBehaviors(new f.o("mediaType","video",b),new v.t(p.A`
            :host .hide-story-wrapper {
                right: var(--content-padding);
            }
        `,p.A`
            :host .hide-story-wrapper {
                left: var(--content-padding);
            }
        `),(0,m.mr)(p.A`
            :host {
                forced-color-adjust: auto;
            }
            .gradient {
                display: none;
            }
            :host([size="_1x_2y"]) .content,
            :host([size="_1x_1y"]) .content,
            :host([size="_2x_1y"]) .content {
                background: ${x.A.ButtonFace};
            }
            :host([size="_1x_2y"]) .text,
            :host([size="_1x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .text,
            :host([size="_2x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .content,
            :host([immersive-card]) .content {
                background: transparent;
            }
            ::slotted([slot="hide-story"]) {
                color: ${x.A.ButtonText};
                fill: currentcolor;
            }
        `));var w=i(96950),$=i(82774),_=i(416),k=i(10108),z=i(69259),C=i(1413);const S=w.qy`
    <slot name="media" ${(0,$.e)("mediaSlot")}></slot>
`,T=(E={mediaTemplate:S},w.qy`
        <template
            role="article"
            ${(0,_.Y)({property:"childElements",filter:(0,k.Y)()})}
        >
            <div class="content${t=>t.mediaType?"":" no-image"}" part="content">
                ${E.mediaTemplate}
                ${(0,z.z)(t=>t&&(0,C.P)("media-info",t.childElements)&&!(t.immersiveCard||"_2x_2y"===t.size),(0,C.y)({slotName:"media-info"}))}
                <div class="gradient" part="gradient"></div>
                ${(0,C.y)({slotName:"media-overlay",slottedDefault:E.mediaOverlay})}
                <div class="text" part="text">
                    ${(0,z.z)(t=>t&&(0,C.P)("media-info",t.childElements)&&(t.immersiveCard||"_2x_2y"===t.size),(0,C.y)({slotName:"media-info"}))}
                    <slot name="attribution"></slot>
                    <a
                        id="heading"
                        class="heading"
                        part="heading"
                        href="${t=>t.href?t.href:void 0}"
                        target="${t=>t.target?t.target:void 0}"
                        @click=${(t,e)=>t.handleContentCardLinkClick(e.event)}
                        data-t="${t=>t.anchorTelemetryTag}"
                    >
                        <span role="heading" aria-level="${t=>t.headingLevel}">
                            <slot></slot>
                        </span>
                    </a>
                    ${(0,C.y)({slotName:"abstract"})}
                </div>
                <div
                    class="action-tray ${t=>t.loaded?"":"preload"}"
                    part="action-tray"
                >
                    ${(0,C.y)({slotName:"footer-start",slottedDefault:E.footerStart})}
                    ${(0,C.y)({slotName:"footer-end",slottedDefault:E.footerEnd})}
                </div>
                <div class="hide-story-wrapper" part="hide-story-wrapper">
                    ${(0,C.y)({slotName:"hide-story",slottedDefault:E.hideStory})}
                </div>
            </div>
        </template>
    `);var E;const P=o.W.compose({name:`${r.G.prefix}-content-card`,styles:y,template:T})},82095(t,e,i){"use strict";i.d(e,{O(){return k}});var r=i(56911),o=i(14475),n=i(66591),a=i(60815),s=i(45964),d=i(22162),l=i(22760),c=i(52380),h=i(10809),u=i(52356),v=i(17918),p=i(22341),g=i(93552),f=i(89064),m=i(11310),x=i(77367),b=i(94043),y=i(903),w=i(10910);class $ extends m.W{constructor(){super(...arguments),this.shouldEnablePreview=!1,this.ttvr=!1,this.deferRenderAfterHover=!1,this.removePreviewBadgeAnimation=!1,this.horizontalAlignPreviewBadge=!1,this.hasImageFailed=!1,this.showTitleTooltip=!0,this.enableFlipTitleProvider=!1}get previewController(){return this._previewController}get videoData(){return(0,s._q)(this.data.externalVideoFiles)}get videoDuration(){var t;return this.data.videoDuration??(t=>{if(!t)return"";const e=Math.floor(t/60),i=t-60*e;return`${e>9?e:`0${e}`}:${i>9?i:`0${i}`}`})(null===(t=this.data.metadata)||void 0===t||null===(t=t.videoMetadata)||void 0===t?void 0:t.playTime)}get isCarouselCard(){return"cs-watch-carousel-card"==this.tagName.toLowerCase()}dataChanged(){this.isCarouselCard&&x.YT.addOrUpdateTmplProperty("VidCrslCardData",this.data?"1":"0")}connectedCallback(){this.config=h.D.getConfig(),this.strings=h.D.getLocStrings(),this.deferRenderAfterHover=!!this.config.enableDeferRenderElement,super.connectedCallback(),this.checkEnableSocialBar(),(0,b.S)()?(this.setIntersectionObserver(),(0,v.dT)().then(()=>{this.ttvr=!0}),(0,w._Z)(this).then(async()=>{var t,e,i,r,n,a;(this.data||x.YT.addOrUpdateTmplProperty("SuperVidCardInvalidData","1"),this.setupVideoAutoplay(),null!==(t=this.data)&&void 0!==t&&null!==(t=t.attributionImage)&&void 0!==t&&t.complete)&&(null===(n=(a=this.data).visualReadinessCallback)||void 0===n||n.call(a,1,d.j.provider));if(null!==(e=this.data)&&void 0!==e&&null!==(e=e.image)&&void 0!==e&&e.complete&&(0,f.tg)(this.data),this.data&&(0,y.D)(this.data.cardElement),this.targetTag=!this.data||this.data.openLinksInNewTab?o.z._blank:(null===(i=this.data)||void 0===i?void 0:i.defaultAnchorTarget)||o.z._self,u.y.subscribeThemeChange(this),this.isCarouselCard&&null!==(r=this.data)&&void 0!==r&&r.disableCardTitleTooltip&&this.data.cardElement){var s,l,c;const t=null===(s=this.shadowRoot)||void 0===s||null===(l=s.querySelector)||void 0===l||null===(l=l.call(s,"cs-content-card").shadowRoot)||void 0===l||null===(c=l.querySelector)||void 0===c?void 0:c.call(l,".heading");this.showTitleTooltip=(0,f.lh)(t,this.data.enableTitleForTruncate)}this.enableFlipTitleProvider=this.config.enableFlipTitleProvider})):this.targetTag=this.data.openLinksInNewTab?o.z._blank:this.data.defaultAnchorTarget||o.z._self}get enableThumbsVC(){var t;return!(null!==(t=this.data)&&void 0!==t&&t.isShorts)&&this.config.enableThumbsVC}get enableHoverSocialBarVC(){var t;return!(null!==(t=this.data)&&void 0!==t&&t.isShorts)&&this.config.enableHoverSocialBarVC}get enablePreviewOnScroll(){return!(this.data.disablePreviewOnScroll||this.config.disableVideoPreviewATF&&this.data.isFirstSectionCard)}checkEnableSocialBar(){this.enableHoverSocialBarVC?(this.classList.add("hover-social-bar-enabled"),this.classList.remove("thumbs-vc-enabled"),this.setSocialBarConfig()):this.enableThumbsVC?(this.classList.add("thumbs-vc-enabled"),this.classList.remove("hover-social-bar-enabled"),this.setSocialBarConfig()):(this.classList.remove("thumbs-vc-enabled"),this.classList.remove("hover-social-bar-enabled"))}disconnectedCallback(){var t;(super.disconnectedCallback(),(0,b.S)()&&this.shouldUseNativePlayer)&&(null===(t=this._previewController)||void 0===t||t.dispose());u.y.unsubscribeThemeChange(this)}get imageUrl(){var t,e,i;return null!==(t=this.data)&&void 0!==t&&t.isShorts&&null!==(e=this.data.imageData)&&void 0!==e&&e.source?((t,e)=>{const i=new URL(t,window.location.origin);return Object.entries(e).forEach(t=>{let[e,r]=t;i.searchParams.set(e,r)}),i.toString()})(this.data.imageData.source,{c:"3"}):null===(i=this.data)||void 0===i||null===(i=i.imageData)||void 0===i?void 0:i.source}get video(){return this.data.video}get shouldUseNativePlayer(){return!(this.isCarouselCard&&!this.config.enableVideoCrslPreview)&&this.config.enableVideoNativePlayer}setSocialBarConfig(){this.data&&!this.data.socialBarWCConfigInfo&&(this.data.socialBarWCConfigInfo={instanceId:"SocialBarWC",configRef:{experienceType:"SocialBarWC",instanceSrc:"tellUsMore"}})}setupVideoAutoplay(){(0,v.dT)().then(async()=>{this.shouldEnablePreview=this.shouldUseNativePlayer&&(this.config.enableVideoCardHover||this.config.enableVideoCardScroll),this.shouldEnablePreview&&this.setupPreviewController()})}async setupPreviewController(){var t;if(this.isCarouselCard&&x.YT.addOrUpdateTmplProperty("SuperVidPreviewSetup",this.data?"1":"0"),!this.data)return;const e=[];this.config.enableVideoCardHover&&e.push("hover"),this.enablePreviewOnScroll&&e.push("scroll"),await(0,l.UV)(()=>Boolean(this.video)),this._previewController=new c.i({cardElement:this.data.cardElement,config:this.config,logError:this.logVideoError.bind(this),previewTriggers:e,useMobile:this.data.useMobile,videoElement:this.video,videoData:{id:this.data.id,videoFile:this.videoData,title:this.data.title,videoDurationMs:null===(t=this.data.metadata)||void 0===t||null===(t=t.videoMetadata)||void 0===t?void 0:t.playTime}})}onMouseEnter(){x.YT.addOrUpdateTmplProperty("VideoHoverView","0"),this.config.enableDeferRenderElement&&(this.deferRenderAfterHover=!1)}logVideoError(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"Generic Error Message";(0,p.vV)(g.fbJ,t,`Video ID: ${this.data.id}`)}cardClickHandler(t,e){return e.parent.clickHandler?e.parent.clickHandler(t,e):!t.handleContentCardClickOverride||(t.handleContentCardClickOverride(e.event),!0)}setIntersectionObserver(){if(this.intersectionObserver)return;this.intersectionObserver=new IntersectionObserver(t=>{var e;t&&t.length&&t.length>0&&(null===(e=t[0])||void 0===e?void 0:e.intersectionRatio)>=.5&&(x.YT.addOrUpdateTmplProperty("VideoView","1"),this.unsetIntersectionObserver())},{root:null,rootMargin:"0px",threshold:[.5]}),this.intersectionObserver.observe(this)}unsetIntersectionObserver(){this.intersectionObserver&&(this.intersectionObserver.disconnect(),this.intersectionObserver=void 0)}handleThemeChange(t){var e;(0,f._R)(t,this.data,[null===(e=this.data)||void 0===e?void 0:e.outerCSCard])}getContentCardClassname(t){return(0,n.x)("card-content",["dualtone-card",t.enableLargeImgDualtoneCard],["dark",t.isDarkModeForMobile],["hover-preview-animation-disabled",this.removePreviewBadgeAnimation],["horizontal-align-preview-badge",this.horizontalAlignPreviewBadge])}onImageError(t){var e,i;!t||this.hasImageFailed&&t.src==f.FE||((0,p.vV)(g.zWZ,"Error fetching video carousel card img source","Src: "+(null===(e=this.data)||void 0===e||null===(e=e.imageData)||void 0===e?void 0:e.source)+", Video ID: "+(null===(i=this.data)||void 0===i?void 0:i.id)),(0,f.tg)(this.data),this.hasImageFailed=!0)}}(0,r.Cg)([a.sH],$.prototype,"data",void 0),(0,r.Cg)([a.sH],$.prototype,"targetTag",void 0),(0,r.Cg)([a.sH],$.prototype,"shouldEnablePreview",void 0),(0,r.Cg)([a.sH],$.prototype,"ttvr",void 0),(0,r.Cg)([a.sH],$.prototype,"deferRenderAfterHover",void 0),(0,r.Cg)([a.sH],$.prototype,"_previewController",void 0),(0,r.Cg)([a.sH],$.prototype,"removePreviewBadgeAnimation",void 0),(0,r.Cg)([a.sH],$.prototype,"horizontalAlignPreviewBadge",void 0),(0,r.Cg)([a.sH],$.prototype,"hasImageFailed",void 0),(0,r.Cg)([a.Jg],$.prototype,"previewController",null),(0,r.Cg)([a.Jg],$.prototype,"videoData",null),(0,r.Cg)([a.Jg],$.prototype,"videoDuration",null),(0,r.Cg)([a.sH],$.prototype,"showTitleTooltip",void 0),(0,r.Cg)([a.sH],$.prototype,"enableFlipTitleProvider",void 0);var _=i(65055);class k extends ${constructor(){super(...arguments),this.isVideoPlaying=!1,this.eventsCallback=(t,e)=>{this.player||(this.player=t),"play"===e?this.isVideoPlaying=!0:"pause"===e&&(this.isVideoPlaying=!1)}}renderVideoCard(t,e,i,r){if(!t)return;if(!(0,b.S)())return;if((0,l.h_)())return;const o=`${i} vertical_gradient super_feed_card ${r.immersiveCard?"immersive":""}`;return(0,_.yN)(t,{memoize:!1,properties:{id:e,context:{cardData:r,customStyleClass:o,eventsCallback:this.eventsCallback}}})}}(0,r.Cg)([a.sH],k.prototype,"isVideoPlaying",void 0),(0,r.Cg)([a.sH],k.prototype,"player",void 0)},84056(t,e,i){"use strict";i.d(e,{J(){return s}});var r=i(59836),o=i(73893),n=i(80090),a=i(65614);function s(){r.m.define(a.G.registry),o.m.define(a.G.registry),n.m.define(a.G.registry)}},86240(t,e,i){"use strict";i.d(e,{RG(){return l},mQ(){return c}});var r,o=i(74998),n=i(93552),a=i(22341),s=i(2171);!function(t){t.InterstitialNativeAdCard="InterstitialNativeAdCard",t.LinearFeedNativeAdCard="LinearFeedNativeAdCard",t.ViewsNativeAd="ViewsNativeAd",t.InfopaneCardTemplate="InfopaneCardTemplate",t.NativeAdCardTemplate="NativeAdCardTemplate",t.SuperNativeAdCard="SuperNativeAdCard",t.NativeAdCardT1Full="NativeAdCardT1Full",t.MobileAdCardTemplate="MobileAdCardTemplate",t.SuperMobileNativeAdCardNeutron="SuperMobileNativeAdCardNeutron",t.EdgeMobileInfopaneCard="EdgeMobileInfopaneCard",t.MobileEOABCard="MobileEOABCard"}(r||(r={}));const d=t=>{var e;let{id:i,destinationUrl:r,imgLink:o,renderAreaSize:d}=t;if(null==o||!o.startsWith("https://www.bing.com/th?")||!d)return;const l=function(t){const e=new URLSearchParams(t.split("?")[1]),i=Number(e.get("w")),r=Number(e.get("h"));return isNaN(i)||isNaN(r)||i<=0||r<=0?null:{width:i,height:r}}(o),c=null===(e=location)||void 0===e?void 0:e.href;if(!l){const t={id:i,currentPageUrl:c,destinationUrl:r,imgLink:o,renderAreaSize:d};return void(0,a.vV)(n.Ztd,"Ad Size Mismatch: Can not found proper image size from response image URL",void 0,t)}const h=s.vv.get("AdSizeMismatchRecord")||new Map,u=(t=>t?t.replace(/\d+$/,""):"")(i);if(!h.has(u)){if(h.set(u,1),s.vv.set("AdSizeMismatchRecord",h),0===d.height||0===l.height)return;const t=d.width!==l.width||d.height!==l.height,e=d.width/d.height,v=l.width/l.height,p=Math.round(100*Math.abs(e-v))/100;if(t&&p>.03){const t={id:i,currentPageUrl:c,destinationUrl:r,imgLink:o,renderAreaSize:d,renderAreaSizeRatio:e.toFixed(2),responseImageSize:l,responseImageSizeRatio:v.toFixed(2)};(0,a.vV)(n.Ztd,"Ad Size Mismatch: Detected size mismatch between response image VS render area",void 0,t)}}},l=(t,e,i,r)=>{if(!r||!i)return;const o=r.offsetWidth||Number(r.width),n=r.offsetHeight||Number(r.height);o&&n&&d({id:t,destinationUrl:e,imgLink:i,renderAreaSize:{width:o,height:n}})},c=(t,e,i)=>{var r,n,a,s,d,c,h,u,v,p,g;if(o.Rb.CurrentFlightSet.has("prg-ad-size-mis"))try{switch(i){case"LinearFeedNativeAdCard":case"NativeAdCardTemplate":case"SuperNativeAdCard":case"NativeAdCardT1Full":case"MobileAdCardTemplate":case"SuperMobileNativeAdCardNeutron":case"MobileEOABCard":l(t.id,t.destinationUrl,null===(r=t.imageData)||void 0===r?void 0:r.source,null===(n=e.parent)||void 0===n||null===(n=n.shadowRoot)||void 0===n||null===(a=n.querySelector)||void 0===a?void 0:a.call(n,`#${t.id}-img`));break;case"EdgeMobileInfopaneCard":l(t.id,t.destinationUrl,null===(s=t.imageData)||void 0===s?void 0:s.source,null===(d=e.parentContext)||void 0===d||null===(d=d.parent)||void 0===d||null===(d=d.shadowRoot)||void 0===d||null===(c=d.querySelector)||void 0===c?void 0:c.call(d,`#${t.id}-img`));break;case"ViewsNativeAd":l(t.id,t.destinationUrl,t.imageUrl,null===(h=e.parent)||void 0===h||null===(h=h.shadowRoot)||void 0===h||null===(u=h.querySelector)||void 0===u||null===(u=u.call(h,"msft-content-card"))||void 0===u?void 0:u.querySelector(`#${t.id}-img`));break;case"InfopaneCardTemplate":l(t.id,t.destinationUrl,null===(v=t.imageData)||void 0===v?void 0:v.source,null===(p=e.parentContext)||void 0===p||null===(p=p.parentContext)||void 0===p||null===(p=p.parent)||void 0===p||null===(p=p.shadowRoot)||void 0===p||null===(g=p.querySelector)||void 0===g?void 0:g.call(p,`#${t.id}-img`))}}catch(t){return null}}},87119(t,e,i){"use strict";i.d(e,{V(){return r}});const r=i(64332).DI.createContext()},87582(t,e,i){"use strict";var r;function o(t,e,i){return i===r.ltr?t:e}i.d(e,{OP(){return r},jt(){return o}}),function(t){t.ltr="ltr",t.rtl="rtl"}(r||(r={}))},93518(t,e,i){"use strict";i.d(e,{X(){return v}});var r=i(56911),o=i(97004),n=i(64183),a=i(95239),s=i(356),d=i(31023),l=i(37302),c=i(96193),h=i(38493),u=i(50866);class v extends c.z{constructor(){super(...arguments),this.size=u.qJ._1x_2y}cardFillColorChanged(t,e){this.isDarkCardGradient()?s.l.setValueFor(this,o.y.DarkMode):this.isLightCardGradient()?s.l.setValueFor(this,o.y.LightMode):s.l.deleteValueFor(this)}isDarkCardGradient(){return Object.values(u.NZ).includes(this.cardFillColor)}isLightCardGradient(){return Object.values(u.L9).includes(this.cardFillColor)}isNamedGradientFillColor(){return this.isLightCardGradient()||this.isDarkCardGradient()}connectedCallback(){super.connectedCallback(),l.jO.setValueFor(this,{evaluate(t,e){return(0,n.o)(t(d.r),e||t(a.p),-1,1,0,0,void 0,2,3,1,2,void 0)}})}}(0,r.Cg)([(0,h.CF)({attribute:"card-fill-color"}),(0,r.Sn)("design:type",Object)],v.prototype,"cardFillColor",void 0),(0,r.Cg)([h.CF,(0,r.Sn)("design:type",String)],v.prototype,"size",void 0)},96193(t,e,i){"use strict";i.d(e,{z(){return o}});var r=i(92011);class o extends r.L{}},96787(t,e,i){"use strict";function r(t){return!t.mapRawData}i.d(e,{Yd(){return r},wc(){return o}});const o=t=>({defaultLayout:t?[t]:[],C6:[],C5:[],C4:[],C3:[],C2:[],C1:[]})},97015(t,e,i){"use strict";i.d(e,{_Z(){return d},we(){return n},x3(){return s},z7(){return a}});var r=i(6205),o=i(65114);function n(t){const e="An unknown error";if("string"==typeof t)return{value:t};if(!t||"object"!=typeof t)return{value:e};if(!function(t){return Boolean(t&&"object"==typeof t&&"code"in t&&"message"in t)}(t))return{value:e,message:(0,r.M5)(t)};const{value:i,...o}=t;return"object"==typeof i?{value:(0,r.M5)(i),...o}:{value:"string"==typeof i?i:o.message,...o}}const a=(t,e,i)=>{let r=t+i;return r<0?r=0:r>e&&(r=e),r};function s(t){if(!t)return"";const e=new URL(t);return e.searchParams.set("_t",Date.now().toString()),e.searchParams.has("start")||e.searchParams.set("start","0"),e.searchParams.has("end")||e.searchParams.set("end","15"),e.href}function d(t){return t&&Object.values(o.yB).includes(new URL(t).origin)}},99657(t,e,i){"use strict";i.d(e,{D(){return a},I(){return n}});var r=i(45755);const{create:o}=r.G,n=o("sloppy-click-z-index",1),a=o("click-z-index",1)}}]);