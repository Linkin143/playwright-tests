"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["community-creation-ideas"],{4968(t,e,o){o.d(e,{f(){return s}});var i=o(64187),a=o(74849),l=o(42792),n=o(99657),r=o(36452);const s=a.A.partial`position: relative; z-index: ${n.D};`;a.A`
    ${l.e}
    ${l.nH}

    ${(0,i.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${s}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${r.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${r.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${r.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(l.kc)},44932(t,e,o){o.d(e,{D(){return n}});var i=o(56911),a=o(60815),l=o(92011);class n extends l.L{}(0,i.Cg)([a.sH],n.prototype,"viewModel",void 0)},58838(t,e,o){o.r(e),o.d(e,{CommunityCreationIdeas(){return M}});var i=o(56911),a=o(44932),l=o(58792),n=o(60815);class r extends a.D{constructor(){super(...arguments),this.dismissToast=()=>{this.enableToast&&(this.enableToast=!1,this.viewModel.isDismissed=!0)}}connectedCallback(){super.connectedCallback(),this.viewModel&&(this.isAnswered=this.viewModel.isAnswered||!1,this.answerId=this.viewModel.answerId||"",this.enableToast=this.isAnswered&&!this.viewModel.isDismissed)}async handlePollAnswer(t,e){this.isAnswered||this.answerId||(await this.viewModel.setPollAnswer(t,e),this.isAnswered=!0,this.enableToast=this.isAnswered&&!this.viewModel.isDismissed,this.answerId=t,this.viewModel.pollCounts[e]+=1)}getPollClass(t){return this.answerId?t===this.answerId?"answered":"answered not-answer":""}getOptionClass(t){return this.answerId?t===this.answerId?"selected-option":"not-selected-option":""}getPollCount(t){return this.viewModel.pollCounts[t]}getBackgroundWidth(t){const e=this.viewModel.pollCounts,o=e.reduce((t,e)=>t+e);return Math.floor(e[t]/o*100)}getReasonText(){var t;const e=null===(t=this.viewModel.pollOptions.find(t=>t.optionId===this.answerId))||void 0===t?void 0:t.optionText,{pollVoteReason:o}=this.viewModel.strings;return o.replace("{0}",e)}openNavLink(){var t;const e=(0,l.rA)().CurrentMarket||"en-us",o=null===(t=this.viewModel.pollOptions.find(t=>t.optionId===this.answerId))||void 0===t?void 0:t.optionId,i=`https://www.msn.com/${e}/community/profile/me?creationIdeaId=${this.viewModel.creationIdeaId}&optionId=${o}`;window.open(i,"_blank"),this.dismissToast()}}(0,i.Cg)([n.sH],r.prototype,"viewModel",void 0),(0,i.Cg)([n.sH],r.prototype,"isAnswered",void 0),(0,i.Cg)([n.sH],r.prototype,"answerId",void 0),(0,i.Cg)([n.sH],r.prototype,"enableToast",void 0);var s=o(92011),d=o(48751),p=o(46203),c=o(86856),h=o(4968),u=o(12640),g=o(74849);const v=g.A`
`,b=g.A` .option-vote{text-align:left}`,w=g.A` .poll{background:var(--backplate-default,rgba(255,255,255,0.06));border:1px solid rgba(255,255,255,0.1)}.selected-option{background:rgba(105,161,250,0.3) !important}.not-selected-option{background:rgba(255,255,255,0.1) !important}.poll:not(.answered):hover{background:var(--backplate-hover,rgba(255,255,255,0.14))}.toast-container{background:#FFFFFF}.toast-button{background:var(--pheonix-blue-background-rest,#235CCF)}`,x=g.A` a,a:hover,a:active,a:visited{color:${d.l};text-decoration:none;cursor:pointer}.creation-ideas-wrapper{${h.f}}.poll-wrapper{color:${d.l}}.news-detail{display:flex;gap:10px;align-items:center;height:60px}.news-text{font-size:14px;line-height:20px;font-weight:600;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;cursor:default;${h.f}}.poll-section{display:flex;margin-top:15px}.poll-button{width:100%;background:rgb(240,240,240);height:24px;border-radius:4px;color:#0000005e;font-size:14px;display:flex;align-items:center;justify-content:center}.poll-area{display:flex;flex-direction:column;justify-content:start;gap:10px;width:100%;height:120px}.poll{padding:8px 12px;width:100%;height:100%;line-height:16px;font-size:12px;font-weight:600;background:rgba(255,255,255,0.8);border:1px solid rgba(0,0,0,0.05);border-radius:32px;box-sizing:border-box;cursor:default;${h.f}}.poll:not(.answered):hover{cursor:pointer;background:var(--backplate-control-hover,rgba(240,240,240,1))}.selected-option{background:rgba(33,105,235,1)}.not-selected-option{background:rgba(41,41,41,0.4)}.not-answer{font-weight:400}.option-text{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.option-vote{width:55px;text-align:right;white-space:nowrap}.poll-row{display:flex;width:100%;justify-content:space-between;gap:5px}.single-poll-wrapper{position:relative;overflow:hidden;border-radius:32px}.poll-background{width:0%;height:-webkit-fill-available;position:absolute;max-width:100%}.article-info-div{display:flex;align-items:center;gap:8px;margin-top:12px;cursor:default}.article-info-link{display:flex;align-items:center;gap:8px;margin-top:12px;cursor:pointer;${h.f}}.article-logo{width:16px;height:16px;border-radius:2px}.article-title{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;overflow:hidden;text-overflow:ellipsis;font-size:12px;font-style:normal;font-weight:600;line-height:16px}.toast-container{background:rgb(41,41,41);border-radius:8px;display:flex;gap:8px;align-items:center;color:${p.le};padding:12px;position:absolute;bottom:0px;z-index:2;font-size:12px;font-style:normal;font-weight:600;line-height:16px}.toast-button{background:var(--pheonix-blue-background-rest,#2169EB);color:currentColor;border-radius:var(--Circular,9999px);display:flex;padding:3px 12px;justify-content:center;align-items:center;font-size:12px;font-style:normal;font-weight:400;line-height:16px;height:18px;min-width:61px}.toast-button::part(content){color:#FFFFFF;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;width:61px}.toast-close-button{background:transparent;color:currentColor;min-width:16px;width:16px;height:16px}.toast-message{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;cursor:default}`.withBehaviors(new u.N(null,w),new c.t(v,b));var f=o(96950),m=o(39957),$=o(69259),k=o(70394),y=o.n(k);const C=f.qy`<div class="toast-container"><span class="toast-message" title="${t=>t.getReasonText()}">${t=>t.getReasonText()}</span><fluent-anchor class="toast-button" title="${t=>t.viewModel.strings.createPost||null}" aria-label="${t=>t.viewModel.strings.createPost||null}" @click="${t=>t.openNavLink()}" data-t=${t=>t.viewModel.telemetryTag}>${t=>t.viewModel.strings.createPost||null}</fluent-anchor><fluent-button class="toast-close-button" @click="${t=>t.dismissToast()}" role="button" data-t=${t=>t.viewModel.telemetryTag}>${f.qy.partial(y())}</fluent-button></div>`,F=f.qy`<div class="news-detail"><div class="news-text" title=${t=>t.viewModel.title}>${t=>t.viewModel.title}</div></div>`,I=f.qy`<div class="poll-area">${(0,m.ux)(t=>t.viewModel.pollOptions,f.qy` ${(0,$.z)((t,e)=>e.parent.isAnswered,f.qy`<div class="single-poll-wrapper" title="${t=>t.optionText}" aria-label="${t=>t.optionText}"><div class="poll-background ${(t,e)=>e.parent.getOptionClass(t.optionId)}" style="width: ${(t,e)=>e.parent.getBackgroundWidth(e.index)}%;"></div><div class="poll ${(t,e)=>e.parent.getPollClass(t.optionId)}"><div class="poll-row"><span class="option-text">${t=>t.optionText}</span><span class="option-vote">${(t,e)=>e.parent.getPollCount(e.index)} (${(t,e)=>e.parent.getBackgroundWidth(e.index)}%)</span></div></div></div>`)} ${(0,$.z)((t,e)=>!e.parent.isAnswered,f.qy`<a class="single-poll-wrapper" title="${t=>t.optionText}" aria-label="${t=>t.optionText}" data-t=${(t,e)=>e.parent.viewModel.telemetryTag} role="button"><div class="poll ${(t,e)=>e.parent.getPollClass(t.optionId)}" @click=${(t,e)=>e.parent.handlePollAnswer(t.optionId,e.index)}><div class="poll-row"><span class="option-text">${t=>t.optionText}</span></div></div></a>`)} `,{positioning:!0})}</div>`,P=f.qy`<div class="poll-section">${I}</div>`,z=f.qy` ${(0,$.z)(t=>t.viewModel.articleLogoUrl,f.qy`<img class="article-logo" src=${t=>t.viewModel.articleLogoUrl}>`)}<div class="article-title">${t=>t.viewModel.articleTitle}</div>`,T=f.qy`<div class="article-info-div" title=${t=>t.viewModel.articleTitle}>${z}</div>`,V=f.qy`<a class="article-info-link" href=${t=>t.viewModel.articleUrl} target="_blank" rel="noopener noreferrer" title=${t=>t.viewModel.articleTitle} data-t=${t=>t.viewModel.telemetryTag}>${z}</a>`,A=f.qy`<div class="creation-ideas-wrapper"><div class="poll-wrapper">${F} ${P} ${(0,$.z)(t=>t.viewModel.articleTitle,f.qy`${t=>t.viewModel.articleUrl?V:T}`)}</div></div>`,D=f.qy` ${(0,$.z)(t=>null!=t.viewModel,A)} ${(0,$.z)(t=>t.enableToast,C)}
`;let M=class extends r{};M=(0,i.Cg)([(0,s.E)({name:"community-creation-ideas",template:D,styles:x,shadowOptions:{delegatesFocus:!0}})],M)},87250(t,e,o){o.r(e),o.d(e,{CreationIdeasTransformer(){return r}});var i=o(50130),a=o(74104),l=o(62795),n=o(96950);class r extends i.B{async transform(t){this.initPoll(t);const e=await this.getCurrentViewModel(t);return{viewTemplate:n.qy`
                <community-creation-ideas
                    :viewModel="${e}"
                ></community-creation-ideas>`}}initPoll(t){const{tabData:e}=t,{creationIdeaId:o,pollOptions:i}=e;this.pollId=o;const a=(0,l.wZ)(this.pollId);void 0!==a&&(this.isAnswered=!0,this.answerId=i[a].optionId)}async setPollAnswer(t,e){var o;null!==(o=this.transformerProvider)&&void 0!==o&&o.pollAnswerHandler&&(await this.transformerProvider.pollAnswerHandler(e,this.pollId),this.isAnswered=!0,this.answerId=t)}getPollCounts(t,e){const o=(0,l.GT)(t);return o.length===e.length?o:[...o,...Array(e.length-o.length).fill(0)]}async getCurrentViewModel(t){var e,o,i,l,n,r;const{tabData:s}=t,{pollOptions:d,title:p,creationIdeaId:c,contentTypeData:h}=s,{createPost:u,pollVoteHintDescription:g,pollVoteHintTitle:v,pollVoteReason:b,seeNextPoll:w,writeComment:x}=this.transformerProvider.strings,f=this.getPollCounts(c,d),m=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{name:null==t||null===(e=t.telemetryObject)||void 0===e||null===(e=e.contract)||void 0===e?void 0:e.name,signature:null==t||null===(o=t.telemetryObject)||void 0===o||null===(o=o.contract)||void 0===o||null===(o=o.ext)||void 0===o?void 0:o.signature,headline:null==t||null===(i=t.telemetryObject)||void 0===i||null===(i=i.contract)||void 0===i||null===(i=i.content)||void 0===i?void 0:i.headline});return null==d||d.splice(a.y7),{telemetryTag:m,pollOptions:d,title:p,strings:{createPost:u,pollVoteHintDescription:g,pollVoteHintTitle:v,pollVoteReason:b,seeNextPoll:w,writeComment:x},pollCounts:f,setPollAnswer:async(t,e)=>this.setPollAnswer(t,e),isAnswered:this.isAnswered,answerId:this.answerId,creationIdeaId:c,articleTitle:null==h||null===(l=h.article)||void 0===l?void 0:l.title,articleUrl:null==h||null===(n=h.article)||void 0===n?void 0:n.articleUrl,articleLogoUrl:null==h||null===(r=h.article)||void 0===r?void 0:r.logoUrl}}}Promise.resolve().then(o.bind(o,58838))}}]);