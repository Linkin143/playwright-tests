(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-info-spotlight-pre-earnings"],{4968(t,e,i){"use strict";i.d(e,{f(){return l}});var a=i(64187),r=i(74849),o=i(42792),n=i(99657),s=i(36452);const l=r.A.partial`position: relative; z-index: ${n.D};`;r.A`
    ${o.e}
    ${o.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},5760(t,e,i){"use strict";i.r(e),i.d(e,{SpotlightPreEarnings(){return U}});var a=i(56911),r=i(27208),o=i(92707);class n extends o.z{constructor(){super(...arguments),this.animationCompleted=!1}connectedCallback(){super.connectedCallback(),this.animateGaugeChart()}get gaugeChartIndicatorBackgroundColor(){var t;return(null===(t=this.viewModel.analystData)||void 0===t||null===(t=t.find(t=>t.isActive))||void 0===t?void 0:t.key)??""}get gaugeChartStyle(){const{recommendation:t}=this.viewModel.analystRecommendation||{};return`rotate(${{[r.O3.strongBuy]:"72deg",[r.O3.buy]:"36deg",[r.O3.hold]:"0deg",[r.O3.sell]:"-36deg",[r.O3.underperform]:"-72deg"}[t]??"-72deg"})`}animateGaugeChart(){if(this.chartIndicator&&this.chartIndicatorBackground){if(this.viewModel.animateAnalystAngle&&!this.animationCompleted)return this.chartIndicator.style.transition="transform 0.3s ease .2s",this.chartIndicatorBackground.style.transition="transform 0.3s ease .2s",void window.setTimeout(()=>{this.transformChartElements(),this.animationCompleted=!0},0);this.transformChartElements()}}transformChartElements(){this.chartIndicator&&this.chartIndicatorBackground&&(this.chartIndicator.style.transform=this.gaugeChartStyle,this.chartIndicatorBackground.style.transform=this.gaugeChartStyle)}stockNames(t){const{quote:{shortName:e,displayName:i,symbol:a}}=this.viewModel;return[e||i||"",a||""][t]}}var s=i(92011),l=i(64003),d=i(61138),h=i(48751),c=i(41123),p=i(4968),g=i(12640),u=i(74849);const f=u.A` :host{--standard-green:#02E176 !important;--standard-red:#FFAB8C !important;--standard-blue:#60CDFF !important;--standard-grey:rgba(255,255,255,0.54) !important}.bar-chart-bg{background-color:rgba(255,255,255,0.16)}.guage-chart path:nth-of-type(1){fill:#C7FF80}.guage-chart path:nth-of-type(2){fill:#92FDB6}.guage-chart path:nth-of-type(3){fill:#3AF277}.guage-chart path:nth-of-type(4){fill:#EE9F65}.guage-chart path:nth-of-type(5){fill:#FF6341}.chart-indicator path{fill:#FFFFFF}.chart-indicator-bg.strongBuy path{fill:#3AF277}.chart-indicator-bg.buy path{fill:#92FDB6}.chart-indicator-bg.hold path{fill:#C7FF80}.chart-indicator-bg.sell path{fill:#EE9F65}.chart-indicator-bg.underperform path{fill:#FF6341}`,x=u.A` :host{--standard-green:#0B7B24;--standard-red:#BF3401;--standard-blue:#005FB7;--standard-grey:rgba(0,0,0,0.54)}.emb{background:none;height:100%;border-radius:8px;${p.f}}.notf-ic{height:16px;padding-left:4px;padding-right:4px}.notf-ic svg{height:16px;width:16px}.sec-title-str{color:${l.c};
        margin: 0;
        font-size: ${d.k};
        line-height: ${d.F};white-space:nowrap}.price{align-items:center;justify-content:flex-end;display:flex}.price-str{color:${h.l};
        font-weight: 600;
        font-size: ${c.K};
        line-height: ${c.Z};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.change-button-area{display:flex;justify-content:flex-end;align-items:center}.change-values-percentage-gradient{display:flex;font-size:${c.K};
        line-height: ${d.F};font-weight:600;text-align:end;height:20px;justify-content:flex-end;align-items:center}.sl-quote{display:flex;flex-direction:column;justify-content:space-between;text-decoration:none;align-items:flex-start;height:100%;padding:12px 12px 0 12px;box-sizing:border-box;border-radius:6px}.sl-quote._1x_1y{display:grid;grid-column-gap:8px;grid-template-columns:1fr min-content;padding:9px 12px !important;align-items:center}.sl-sm-left{min-width:0px}.sl-title{display:flex;align-items:baseline;max-width:244px;font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);font-weight:600;margin:0;color:${h.l}}.ellipsis{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}._1x_3y .sl-title{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px)}.sl-quote .sec-title-str{font-weight:400;color:var(--standard-grey)}.emb:not(._1x_1y) .sec-title-str{margin-left:5px}.sl-quote._1x_1y .sec-title-str{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);color:${h.l}}.sl-quote .price-str{font-size:var(--type-ramp-plus-4-font-size,28px);line-height:var(--type-ramp-plus-4-line-height,36px)}.sl-quote._1x_2y .change-button-area,.sl-quote._1x_3y .change-button-area{margin:0 -2px;bottom:-6px;position:relative}.sl-quote._1x_1y .price-str{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.sl-quote._1x_3y .price-str{font-weight:600;font-size:var(--type-ramp-plus-5-font-size,32px);line-height:var(--type-ramp-plus-5-line-height,40px)}.sl-quote._1x_3y .change-values-percentage{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px)}.sl-price-row{display:grid;grid-template-columns:repeat(3,min-content);grid-gap:8px;align-items:center;margin-bottom:2px}.sl-quote .notf-tx{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);padding:0px 6px;display:inline-flex;overflow:hidden;-webkit-line-clamp:2;-webkit-box-orient:vertical;text-overflow:ellipsis}.sl-quote .notf-tx svg{align-self:center}.sl-quote._1x_1y .notf-tx{-webkit-line-clamp:1}.sl-quote._1x_3y .notf-tx{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px)}.sl-quote .glcn{display:flex;align-items:center}.sl-quote .glcn .notf-ic{line-height:16px;padding:0px}.sl-quote .glcn .notf-ic svg{width:16px;height:16px}.sl-quote._1x_3y .glcn .notf-ic{height:20px}.sl-quote._1x_3y .glcn .notf-ic svg{width:20px;height:20px}.icn{display:flex}.icn,.icn img{width:28px;height:28px}.icn img{object-fit:contain}.quote-red{color:var(--standard-red);fill:var(--standard-red)}.quote-green{color:var(--standard-green);fill:var(--standard-green)}.quote-blue{color:var(--standard-blue);fill:var(--standard-blue)}.guage-chart{position:absolute;left:0;right:0;text-align:center}.chart-indicator{position:absolute;z-index:1;width:8px;height:63px;margin-left:auto;margin-right:auto;left:0px;right:0px;bottom:20px;transform-origin:5px 64px;transform:rotate(-72deg)}.chart-indicator-bg{position:absolute;width:48px;height:70px;margin-left:auto;margin-right:auto;transform-origin:24px 71px;bottom:20px;left:0;right:0;transform:rotate(-72deg)}.analytics-chart{position:relative}._1x_3y .analytics-chart{margin-bottom:10px;margin-top:auto}.analytics-chart-elements{width:244px;height:94px}.chart-texts span{font-weight:400;font-size:var(--type-ramp-minus-2-font-size,10px);color:var(--standard-grey);width:38px;text-align:center;position:absolute}.chart-texts span.text-bold{color:${h.l};font-weight:600;font-size:var(--type-ramp-base-font-size,14px);margin-top:-5px}.text-underperform{left:6px;top:34px}.text-sell{left:45px;top:-6px}.text-hold{top:-24px;left:104px}.text-buy{right:45px;top:-6px}.text-strongBuy{right:6px;top:34px}.bar-chart-wrapper{display:flex;flex-direction:column;width:100%;margin-bottom:20px}.single-bar-chart-row{display:grid;grid-template-columns:70px auto 24px;margin-bottom:6px}.bar-chart-contents{display:flex}.bar-chart-contents span,.bar-chart-values span{color:${h.l};font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.bar-charts{display:flex;flex-direction:column;align-items:center;justify-content:space-around;flex:1}.bar-chart-bg{background-color:rgba(0,0,0,0.1);height:2px;border-radius:2px;width:100%}.bar-chart{height:100%;background-color:green;display:block;border-radius:2px}.bar-chart-values{display:flex;flex-direction:column;flex:none;margin-left:10px}.bar-chart-values{text-align:right}.chart-indicator-bg.strongBuy path{fill:#22DBD0}.chart-indicator-bg.buy path{fill:#2CDE68}.chart-indicator-bg.hold path{fill:#96DB3E}.chart-indicator-bg.sell path{fill:#EB8F4C}.chart-indicator-bg.underperform path{fill:#E86D52}`.withBehaviors(new g.N(null,f));var v,b=i(96950),m=i(60402),y=i(39957),$=i(69259),w=i(28922),z=i.n(w),k=i(9231),_=i.n(k);const C=b.qy`<img src="${t=>t.viewModel.notificationIconUrl}" class="notf-ic" alt="">`,q=b.qy`<span class="notf-tx ${(t,e)=>t.viewModel.quoteNotificationClass}">${t=>t.viewModel.notificationText}${b.qy.partial("rtl"===(null===(v=window)||void 0===v||null===(v=v.document)||void 0===v?void 0:v.dir)?z():_())}</span>`,F=b.qy`<p class="sl-title"><span class="ellipsis">${t=>t.stockNames(0)}</span><span class="sec-title-str">${t=>t.stockNames(1)}</span></p>`,B=b.qy`<span class="${(t,e)=>t.viewModel.quoteChangeClass}" aria-label="${(t,e)=>t.viewModel.quoteChangeAriaLabel}"><span class="change-button-area"><span class="change-values-percentage-gradient">&lrm;${t=>t.viewModel.quote.changePcnt}&lrm;</span></span></span>`,D=b.qy`<div class="price"><span class="price-str">${t=>t.viewModel.quote.price}</span></div>`,E=b.qy`<i class="guage-chart">${b.qy.partial('<svg width="150" height="75" viewBox="0 0 150 75" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M53.76 3.6a74.5 74.5 0 0 1 42.48 0c.72.21 1.12.98.88 1.7a1.41 1.41 0 0 1-1.75.91 71.75 71.75 0 0 0-40.74 0 1.41 1.41 0 0 1-1.75-.9c-.24-.73.16-1.5.88-1.7Z" fill="#96DB3E"/><path fill-rule="evenodd" clip-rule="evenodd" d="M98.07 5.62a1.34 1.34 0 0 1 1.72-.87 74.5 74.5 0 0 1 34.37 24.98c.45.59.32 1.44-.3 1.9-.6.44-1.47.3-1.94-.3A71.75 71.75 0 0 0 98.96 7.37a1.41 1.41 0 0 1-.89-1.76Z" fill="#2CDE68"/><path fill-rule="evenodd" clip-rule="evenodd" d="M134.45 32.43c.62-.45 1.47-.3 1.9.31a74.5 74.5 0 0 1 13.13 40.4c.02.75-.6 1.37-1.35 1.37-.76 0-1.38-.62-1.4-1.39a71.75 71.75 0 0 0-12.6-38.74c-.43-.64-.29-1.5.32-1.95Z" fill="#22DBD0"/><path fill-rule="evenodd" clip-rule="evenodd" d="M50.21 4.75c.7-.25 1.48.14 1.72.87.23.72-.16 1.5-.89 1.76a71.75 71.75 0 0 0-32.96 23.94c-.47.62-1.33.75-1.95.3a1.34 1.34 0 0 1-.29-1.9A74.5 74.5 0 0 1 50.21 4.76Z" fill="#EB8F4C"/><path fill-rule="evenodd" clip-rule="evenodd" d="M13.65 32.74a1.34 1.34 0 0 1 1.9-.3c.6.44.75 1.3.31 1.94A71.75 71.75 0 0 0 3.27 73.12a1.41 1.41 0 0 1-1.4 1.39c-.76 0-1.37-.62-1.35-1.36a74.5 74.5 0 0 1 13.13-40.41Z" fill="#E86D52"/></svg>')}</i>`,A=b.qy`<i class="chart-indicator" ${(0,m.K)("chartIndicator")}>${b.qy.partial('<svg width="8" height="63" viewBox="0 0 8 63" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.47 58.32 3.5 0 .51 58.27a3.45 3.45 0 0 0 3.5 3.74c1.94 0 3.5-1.5 3.48-3.34v-.02c0-.11 0-.22-.02-.33Z" fill="#545454"/></svg>')}</i>`,N=b.qy`<i class="chart-indicator-bg ${t=>t.gaugeChartIndicatorBackgroundColor}" ${(0,m.K)("chartIndicatorBackground")}>${b.qy.partial('<svg width="48" height="70" viewBox="0 0 44 70" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M22 69.4.69 3.8a70.5 70.5 0 0 1 42.62 0L22 69.4Z" fill-opacity=".2" fill="#2CDE68"/></svg>')}</i>`,M=b.qy`<div class="chart-texts">${(0,y.ux)(t=>t.viewModel.analystData,b.qy`<span class="text-${t=>t.key} ${t=>t.isActive?"text-bold":""}">${t=>t.text}</span>`)}</div>`,S=b.qy`<div class="analytics-chart-elements">${E} ${A} ${N}</div>`,L=b.qy`<div class="analytics-chart">${S} ${M}</div>`,T=b.qy`<div class="bar-chart-wrapper">${(0,y.ux)(t=>t.viewModel.analystData,b.qy`<div class="single-bar-chart-row"><div class="bar-chart-contents"><span>${t=>t.text}</span></div><div class="bar-charts"><span class="bar-chart-bg"><span class="bar-chart" style="width: ${t=>t.width}%; background-color: ${t=>t.color}"></span></span></div><div class="bar-chart-values"><span>${t=>t.value}</span></div></div>`)}</div>`,j=b.qy`<div class="sl-price-row">${D} ${B}</div>`,I=b.qy`<div class="glcn">${C} ${q}</div>`,Z=b.qy`<div>${F} ${()=>j} ${(0,$.z)(t=>t.viewModel.currentQuoteNotification,I)}</div>${L} ${(0,$.z)(t=>"_1x_3y"===t.viewModel.cardSize,T)}
`,R=b.qy`<div class="ellipsis">${(0,$.z)(t=>!t.viewModel.currentQuoteNotification,b.qy`${t=>t.viewModel.quote.symbol}`)}</div>`,O=b.qy`<div class="sl-sm-left"><div class="sec-title-str ellipsis">${t=>t.viewModel.quote.displayName}</div><div>${(0,$.z)(t=>t.viewModel.currentQuoteNotification,I)} ${(0,$.z)(t=>!t.viewModel.currentQuoteNotification,R)}</div></div><div class="sl-sm-right">${D} ${B}</div>`,P=b.qy`<a class="sl-quote emb ${t=>t.viewModel.cardSize}" role="link" href="${t=>t.viewModel.destinationUrl}" target="${t=>t.viewModel.openLinksInNewTab?"_blank":"_self"}" data-t="${t=>t.viewModel.telemetryTag}" tabindex="-1" aria-label="${t=>t.viewModel.quoteRowAriaLabel}" title="${t=>t.viewModel.quote.tooltipText}">${(0,$.z)(t=>"_1x_1y"===t.viewModel.cardSize,O)} ${(0,$.z)(t=>"_1x_1y"!==t.viewModel.cardSize,Z)}</a>`;let U=class extends n{};U=(0,a.Cg)([(0,s.E)({name:"spotlight-pre-earnings",template:P,styles:x,shadowOptions:{delegatesFocus:!0}})],U)},9231(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M7.65 4.15c.2-.2.5-.2.7 0l5.49 5.46c.21.22.21.57 0 .78l-5.49 5.46a.5.5 0 01-.7-.7L12.8 10 7.65 4.85a.5.5 0 010-.7z"></path></svg>'},28922(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M12.35 15.85a.5.5 0 01-.7 0L6.16 10.4a.55.55 0 010-.78l5.49-5.46a.5.5 0 11.7.7L7.2 10l5.16 5.15c.2.2.2.5 0 .7z"></path></svg>'},42792(t,e,i){"use strict";i.d(e,{R7(){return f},e(){return g},kc(){return u},nH(){return p}});var a=i(57416),r=i(55153),o=i(95239),n=i(26920),s=i(48751),l=i(64187),d=i(22131),h=i(74849),c=i(50882);const p=h.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,g=h.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${n.XA} * 1px) solid ${r.cu};
        border-radius: calc((${a.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${r.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${r.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${r.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${r.QG} * 1px);
        height: calc(${r.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${r.QG} * 1px);
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc(${r.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,d.mr)(h.A`
            :host {
                background: ${c.A.Canvas};
                color: ${c.A.CanvasText};
            }
        `),f=h.A`
    ${g}
    ${p}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},57729(t,e,i){"use strict";i.r(e),i.d(e,{SpotlightPreEarningsTransformer(){return s}});var a=i(27208),r=i(86449),o=i(30236),n=i(96950);class s extends a.IB{async transform(t){const e=await this.getCurrentViewModel(t);return{viewTemplate:n.qy`
                <spotlight-pre-earnings
                    :viewModel="${e}"
                ></spotlight-pre-earnings>`}}async getCurrentViewModel(t){const{quote:e,cardSize:i,previewType:o,quoteNotificationDetails:n,analystRecommendation:s}=t;this.quote=e,this.cardSize=i,this.previewType=o,this.notifications=null==n?void 0:n[this.quote.id],this.currentQuoteNotification=this.getNotificationData(),this.isDarkModeTheme=(0,r.jJ)();const l=s&&this.transformBarChartData(s);return{telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{name:a.CD.quoteItemClick,signature:t.signature,headline:t.destinationUrl}),experienceName:t.experienceName,openLinksInNewTab:this.transformerProvider.config.openLinksInNewTab,cardSize:this.cardSize,currentQuoteNotification:this.currentQuoteNotification,destinationUrl:t.destinationUrl,quote:this.quote,notificationText:this.notificationText,notificationIconUrl:this.getNotfIconUrl(),quoteNotificationClass:this.quoteChangeNotfClass,quoteChangeClass:this.quoteChangeClass,quoteChangeAriaLabel:this.quoteChangeAriaLabel,quoteRowAriaLabel:this.quoteRowAriaLabel,analystData:l,analystRecommendation:s,chartColors:this.barChartColors,animateAnalystAngle:this.transformerProvider.config.animateAnalystAngle}}transformBarChartData(t){const{preEarnings:e}=this.transformerProvider.strings,{analystRecommendationNumber:i,numberOfAnalysts:r,recommendation:o}=t,n=this.barChartColors,s=[],l=[a.O3.strongBuy,a.O3.buy,a.O3.hold,a.O3.sell,a.O3.underperform];for(const t of l)if(Object.prototype.hasOwnProperty.call(i,t)){const a=i[t];s.push({text:(null==e?void 0:e[t])??"",value:a,key:t,width:this.calculateBarChartWidth(a,r),color:n[t],isActive:t.toLowerCase()===o.toLowerCase()})}return s}get barChartColors(){return this.isDarkModeTheme?{strongBuy:"#3AF277",buy:"#92FDB6",hold:"#C7FF80",sell:"#EE9F65",underperform:"#FF6341"}:{strongBuy:"#22DBD0",buy:"#2CDE68",hold:"#96DB3E",sell:"#EB8F4C",underperform:"#E86D52"}}calculateBarChartWidth(t,e){return Math.round(100*t/e)}getNotfIconUrl(){var t,e,i;return(0,o.kX)(this.transformerProvider.config.urls,(null===(t=this.quote)||void 0===t?void 0:t.changePcntNumber)||0,null===(e=this.currentQuoteNotification)||void 0===e?void 0:e.notificationType,this.transformerProvider.config.swapGainLossColor,null===(i=this.currentQuoteNotification)||void 0===i||null===(i=i.notification)||void 0===i?void 0:i.signal)}getNotificationData(){const t=(0,r.U7)(this.previewType,this.notifications);if(null!=t&&t.length)return t[0]}get currentNotificationType(){var t;return null===(t=this.currentQuoteNotification)||void 0===t?void 0:t.notificationType}get currentNotificationSignal(){var t;return null===(t=this.currentQuoteNotification)||void 0===t||null===(t=t.notification)||void 0===t?void 0:t.signal}get notificationText(){var t;return(null===(t=this.currentQuoteNotification)||void 0===t?void 0:t.shortHeadline)||""}get quoteChangeNotfClass(){var t;let e="";return null!==(t=this.currentQuoteNotification)&&void 0!==t&&t.notificationType&&(e=this.currentNotificationType===a.Ex.PriceDrop||this.currentNotificationType===a.Ex.PriceSpike?(0,r.J6)(this.isDarkModeTheme,this.quote.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor,!1):this.getEventNotificationFillColor(this.currentNotificationType)),e}getEventNotificationFillColor(t){if((0,r.i1)(t)&&this.currentNotificationSignal){if(this.currentNotificationSignal===a.KH.Gainer)return this.transformerProvider.config.swapGainLossColor?"quote-red":"quote-green";if(this.currentNotificationSignal===a.KH.Loser)return this.transformerProvider.config.swapGainLossColor?"quote-green":"quote-red"}return"quote-blue"}get quoteChangeClass(){return(0,r.J6)(this.isDarkModeTheme,this.quote.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor,!1)}get quoteChangeAriaLabel(){return`${this.quote.changePcnt} ${this.quote.displayName} ${this.quote.changeValue}`}get quoteRowAriaLabel(){let t="";return t=this.quote.gain||this.quote.unchanged?this.transformerProvider.strings.increasedByText:this.transformerProvider.strings.decreasedByText,`${this.quote.symbol}, ${this.quote.displayName}. ${this.transformerProvider.strings.priceIsText} ${this.quote.price}. ${t} ${this.quote.changePcnt}`}}Promise.resolve().then(i.bind(i,5760))},92707(t,e,i){"use strict";i.d(e,{z(){return l}});var a=i(56911),r=i(27208),o=i(60815),n=i(92011),s=i(31525);let l=class extends n.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return r.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const t=this.getState();t&&(t.subscribe(r.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),t.subscribe(r.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(r.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(r.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(r.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(t){}onChartDictChange(t){}onShowNotificationTextChange(t){}onQuoteItemDictChange(t){}onCardWidthChanged(t){}};(0,a.Cg)([o.sH],l.prototype,"viewModel",void 0),l=(0,a.Cg)([s.x],l)},99657(t,e,i){"use strict";i.d(e,{D(){return n},I(){return o}});var a=i(45755);const{create:r}=a.G,o=r("sloppy-click-z-index",1),n=r("click-z-index",1)}}]);