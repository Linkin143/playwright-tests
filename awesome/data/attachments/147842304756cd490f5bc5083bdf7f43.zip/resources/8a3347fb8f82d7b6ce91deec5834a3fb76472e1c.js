"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_shopping-entry-base-experience_dist_utils_formatter_utils_js-libs_channel-page-ut-354b45"],{7014(e,t,o){o.d(t,{m(){return O}});var i=o(56911),r=o(38493),a=o(60815),n=o(55230),s=o(92011),d=o(56863);class c extends s.L{}class l extends((0,d.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends l{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(!this.readOnly)switch(e.key){case n.Mm:case n.gG:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,t){super.checkedChanged(e,t),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,i.Cg)([(0,r.CF)({attribute:"readonly",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",Array)],h.prototype,"defaultSlottedNodes",void 0);var u=o(37180),p=o(74849),g=o(64187),b=o(60993),v=o(73477),m=o(22131),f=o(50882),x=o(48196),$=o(86856),k=o(7896),y=o(74838),w=o(79288),C=o(46203),z=o(26920),T=o(43774),_=o(95239),S=o(14996),F=o(48751),B=o(41123),L=o(74089),I=o(4283);const H=p.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,g.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${k.O};
        margin: calc(${y.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${w.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${b.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${x.D} / 2) + ${y.vR}) * 2px);
        height: calc(((${x.D} / 2) + ${y.vR}) * 1px);
        background: ${C.le};
        border-radius: calc(${x.D} * 1px);
        border: calc(${z.XA} * 1px) solid ${T.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${C.jM};
        border-color: ${T.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${C.RS};
        border-color: ${T.p4};
    }

    :host(:${v.N}) .switch {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${S.WN};
        border-color: ${S.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${x.D} - (${y.vR} * 5.5)) * 1px);
        width: calc((${x.D} - (${y.vR} * 5.5)) * 1px);
        top: calc(${y.vR} * 1px);
        background: ${F.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${F.l};
        cursor: pointer;
        font-size: ${B.K};
        line-height: ${B.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${F.l};
        font-size: ${B.K};
        line-height: ${B.Z};
        margin-inline-end: calc(${y.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${y.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${L.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${I.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${I.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${L.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${I.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${L.J_};
    }

    :host([aria-checked="true"]:${v.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${S.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new $.t(p.A`
            .checked-indicator {
                left: calc(${y.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${x.D} / 2) + ${y.vR}) + ${y.vR}) * 1px
                );
            }
        `,p.A`
            .checked-indicator {
                right: calc(${y.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${x.D} / 2) + ${y.vR}) + ${y.vR}) * 1px
                );
            }
        `),(0,m.mr)(p.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${f.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${f.A.Field};
                border-color: ${f.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${f.A.HighlightText};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${f.A.Highlight};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${f.A.HighlightText};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${f.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${f.A.Highlight};
            }
            :host(:${v.N}) .switch {
                border-color: ${f.A.Highlight};
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([aria-checked="true"]:${v.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${f.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${f.A.Field};
                border-color: ${f.A.GrayText};
            }
            .status-message,
            .label {
                color: ${f.A.FieldText};
            }
        `));var M=o(96950),P=o(82774),A=o(18893);const D=function(e={}){return M.qy`
        <template
            role="switch"
            aria-checked="${e=>e.checked}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            tabindex="${e=>e.disabled?null:0}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <label
                part="label"
                class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,P.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,A.R)(e.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:M.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),O=class extends h{}.compose({name:`${u.c.prefix}-switch`,template:D,styles:H})},12717(e,t,o){o.d(t,{m(){return w}});var i=o(84506),r=o(37180),a=o(74849),n=o(64187),s=o(60993),d=o(73477),c=o(22131),l=o(50882),h=o(48196),u=o(48751),p=o(45476),g=o(26920),b=o(36452),v=o(79288),m=o(14996);const f=a.A`
    ${(0,n.V)("inline-flex")} :host {
        width: calc(${h.D} * 1px);
        height: calc(${h.D} * 1px);
        justify-content: center;
        align-items: center;
        margin: 0;
        position: relative;
        fill: currentcolor;
        color: ${u.l};
        background: transparent;
        border: none;
        outline: none;
        padding: 0;
    }

    :host::before {
        content: "";
        opacity: 0.8;
        background: ${p.Wl};
        border: calc(${g.XA} * 1px) solid ${b.I2};
        border-radius: 50%;
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        transition: all 0.1s ease-in-out;
    }

    .next,
    .previous {
        position: relative;
        ${""} width: 16px;
        height: 16px;
    }

    :host([disabled]) {
        opacity: ${v.q};
        cursor: ${s.Z};
    }

    :host(:hover) {
        cursor: pointer;
    }

    :host(:hover)::before {
        background: ${p.oO};
        border-color: ${b.mb};
    }

    :host(:${d.N}) {
        outline: none;
    }

    :host(:${d.N})::before {
        box-shadow: 0 0 0 1px ${m.WN} inset;
        border-color: ${m.WN};
    }

    :host(:active)::before {
        background: ${p.wO};
        border-color: ${b.MY};
    }

    :host::-moz-focus-inner {
        border: 0;
    }
`.withBehaviors((0,c.mr)(a.A`
            :host {
                background: ${l.A.Canvas};
            }
            :host .next,
            :host .previous {
                color: ${l.A.ButtonText};
                fill: currentcolor;
            }
            :host::before {
                background: ${l.A.Canvas};
                border-color: ${l.A.ButtonText};
            }
            :host(:hover)::before {
                forced-color-adjust: none;
                background: ${l.A.Highlight};
                border-color: ${l.A.ButtonText};
                opacity: 1;
            }
            :host(:hover) .next,
            :host(:hover) .previous {
                forced-color-adjust: none;
                color: ${l.A.HighlightText};
                fill: currentcolor;
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled])::before,
            :host([disabled]:hover)::before,
            :host([disabled]) .next,
            :host([disabled]) .previous,
            :host([disabled]:hover) .next,
            :host([disabled]:hover) .previous {
                forced-color-adjust: none;
                background: ${l.A.Canvas};
                border-color: ${l.A.GrayText};
                color: ${l.A.GrayText};
                fill: ${l.A.GrayText};
            }
            :host(:${d.N})::before {
                forced-color-adjust: none;
                border-color: ${l.A.Highlight};
                box-shadow: 0 0 0 2px ${l.A.Field},
                    0 0 0 4px ${l.A.FieldText};
            }
        `));var x=o(60143),$=o(96950);const k=(0,x.B)({next:$.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z"
            />
        </svg>
    `,previous:$.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z"
            />
        </svg>
    `});class y extends i.d{}const w=y.compose({name:`${r.c.prefix}-flipper`,template:k,styles:f})},17288(e,t,o){o.d(t,{F(){return m}});var i=o(56911),r=o(2958),a=o(37180),n=o(7014),s=o(92011),d=o(38493);class c extends s.L{constructor(){super(...arguments),this.preText="",this.postText="",this.enableTwoLine=!1}connectedCallback(){super.connectedCallback(),this.spinnerCompleteTimer=window.setTimeout(()=>{this.spinnerCompletedCallback&&this.spinnerCompletedCallback()},3e3)}disconnectedCallback(){super.disconnectedCallback(),clearTimeout(this.spinnerCompleteTimer),this.spinnerCompleteTimer=void 0}}(0,i.Cg)([(0,d.CF)({attribute:"pre-text"})],c.prototype,"preText",void 0),(0,i.Cg)([(0,d.CF)({attribute:"post-text"})],c.prototype,"postText",void 0),(0,i.Cg)([(0,d.CF)({attribute:"enable-two-line",mode:"boolean"})],c.prototype,"enableTwoLine",void 0);var l=o(12640),h=o(92393),u=o(74849);const p=u.A` .spinner-background{stroke:rgba(0,0,0,0.07)}.meter{stroke:${h.W_}}.checkmark-background{fill:${h.W_}}.checkmark{fill:white}`,g=u.A` .spinner-background{stroke:rgba(255,255,255,0.54)}.meter{stroke:white}.checkmark-background{fill:white}.checkmark{fill:black}`,b=u.A` :host{display:flex;flex-direction:column;align-items:center}:host([card-size="_1x_1y"]) .text,:host([card-size="_2x_1y"]) .text,:host([card-size="0.5u"]) .text{display:none}:host([card-size="_1x_1y"]) svg,:host([card-size="_2x_1y"]) svg,:host([card-size="0.5u"]) svg{height:30px;width:30px}:host(.check-icon[card-size="_1x_1y"]),:host(.check-icon[card-size="_2x_1y"]),:host(.check-icon[card-size="0.5u"]){padding-top:0;padding-bottom:11px}svg{aspect-ratio:1 / 1;height:auto;margin:auto;width:var(--animated-spinner-size,48px)}.spinner-background{fill:none;stroke-width:2.5px}.meter{animation:spinner 3s linear;fill:none;stroke-dasharray:150;stroke-dashoffset:0;stroke-linecap:round;stroke-width:2.5px;transform:rotate(-90deg);transform-origin:50% 50%}@keyframes spinner{from{stroke-dashoffset:150}to{stroke-dashoffset:0}}.checkmark-background{animation:checkmark-background 4s linear;transform-origin:50% 50%}@keyframes checkmark-background{0%,75%{fill-opacity:0}78%{fill-opacity:1}}.checkmark{animation:checkmark 4s linear;animation-fill-mode:both;transform:translate(8px,8px);transform-origin:50% 50%}@keyframes checkmark{0%,75%{transform:scale(0) translate(8px,8px)}85%{transform:scale(1.25) translate(8px,8px)}100%{transform:scale(1) translate(8px,8px)}}span{display:block;font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);overflow:hidden;position:absolute;text-overflow:ellipsis;white-space:nowrap;width:236px}.two-line span{white-space:unset;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.two-line.text{height:40px}.text{height:20px;padding-top:8px;width:236px}.pre-text{animation:fadeout 1s;animation-delay:3s;animation-fill-mode:both}.post-text{animation:fadein 1s;animation-delay:3s;animation-fill-mode:both}@keyframes fadein{from{opacity:0}to{opacity:1}}@keyframes fadeout{from{opacity:1}to{opacity:0}}@media (-ms-high-contrast:active),(prefers-contrast:more){${p}
    }
`.withBehaviors(new l.N(p,g)),v=o(96950).qy`<svg part="icon" viewBox="0 0 48 48"><circle class="spinner-background" cx="24" cy="24" r="21.5" /><circle class="meter" cx="24" cy="24" r="21.5" /><circle class="checkmark-background" cx="24" cy="24" r="24"/><path class="checkmark" d="M11.3333 22.1144L6.27614 17.0572C5.75544 16.5365 4.91122 16.5365 4.39052 17.0572C3.86983 17.5779 3.86983 18.4221 4.39052 18.9428L10.3905 24.9428C10.9112 25.4635 11.7554 25.4635 12.2761 24.9428L26.9428 10.2761C27.4635 9.75545 27.4635 8.91122 26.9428 8.39052C26.4221 7.86983 25.5779 7.86983 25.0572 8.39052L11.3333 22.1144Z"/></svg><div part="text" class="text ${e=>e.enableTwoLine?"two-line":""}"><span part="pre-text"class="pre-text" role="alert">${e=>e.preText}</span><span part="post-text" class="post-text">${e=>e.postText}</span></div>`;let m=class extends c{};m=(0,i.Cg)([(0,s.E)({name:"msn-animated-done-spinner",template:v,styles:b})],m),r.m.define(a.c.registry),n.m.define(a.c.registry)},25717(e,t,o){o.d(t,{T(){return r}});var i=o(96950);function r(){return i.qy`
        <slot></slot>
    `}},26831(e,t,o){o.d(t,{Hg(){return n}});var i=o(58792),r=o(26220);const a=/[:/?#[\]@!$&'()*+,;=]/g;function n(e,t,o,n){let s=`${i.T3.NavTargetUrlWithLocale}/channel`;if(e&&o){const i="source"===o?"sr":"tp";s+="/"+[o,t?encodeURIComponent(t.replace(a,"")):"",`${i}-${e}`].filter(e=>e).join("/")}const d=new URL(s);return n||(d.search=(0,r.iA)()),(0,r.ou)().includes("localhost.msn.com")&&(d.host=(0,r.ou)()),d.toString()}},27846(e,t,o){var i,r;o.d(t,{K(){return i},j(){return r}}),function(e){e.Default="default",e.Type1="t1",e.Type2="t2",e.Type3="t3",e.Type4="t4",e.Stripe="stripe",e.SDProductFullBleed="sdpfb",e.MasonryRegular="masonryRegular",e.MasonrySingleRow="masonrySingleRow",e.FullBleedImage="FullBleedImage",e.RelatedProduct="relatedProduct",e.FlyoutText="flyoutText",e.Stateful="stateful",e.ColoredInfoContainer="coloredInfoContainer",e.FavoriteStores="favoriteStores",e.UserSavings="userSavings",e.AbandonedCart="abandonedCart",e.PriceDrops="priceDrops",e.PersonalizedOffers="personalizedOffers",e.ProductsImage="productsImage",e.ProductsImageRectangular="productsImageRectangular",e.ForumBlendedMode="forumBlended",e.TwoColumns="twoColumns",e.Autos="autos",e.CarouselFullBleed="carouselFullBleed",e.MsnHP="msnHP",e.MsnHPT2="msnHPT2",e.MsnHPFullBleed="msnHPFullBleed",e.inmobiLargeCard="inmobiLargeCard",e.inmobiUpcoming="inmobiUpcoming",e.multiHorizontalProducts="multiHorizontalProducts",e.TidyCard="tidyCard",e.HalfTidyCard="halfTidyCard",e.ForumCardWithSeller="forumCardWithSeller",e.ForumSmallCard="forumSmallCard",e.WaterfallCard="waterfallCard",e.ForumCardWithFavorite="forumCardWithFavorite",e.ForumDealsCard="forumDealsCard",e.ForumDealsCardNoTitle="forumDealsCardNoTitle",e.ForumPdpAds="pdpAds"}(i||(i={})),function(e){e[e.Text=0]="Text",e[e.Annotation=1]="Annotation",e[e.Title=2]="Title",e[e.Price=3]="Price",e[e.Rating=4]="Rating",e[e.Store=5]="Store",e[e.StrikedOutPrice=6]="StrikedOutPrice",e[e.CallToAction=7]="CallToAction",e[e.DealExpiryTime=8]="DealExpiryTime",e[e.HotDecoration=9]="HotDecoration",e[e.BlurDecoration=10]="BlurDecoration",e[e.CouponAnnotation=11]="CouponAnnotation",e[e.HighlyRatedDecoration=12]="HighlyRatedDecoration",e[e.PriceWithInstallment=13]="PriceWithInstallment",e[e.IconDecoration=14]="IconDecoration",e[e.StoreNameOnly=15]="StoreNameOnly",e[e.HolidayDealDecoration=16]="HolidayDealDecoration",e[e.SaveBigDecoration=17]="SaveBigDecoration",e[e.CouponAndCashback=18]="CouponAndCashback",e[e.ShopNowButton=19]="ShopNowButton",e[e.MerchantInfo=20]="MerchantInfo",e[e.Bonsai=21]="Bonsai",e[e.FreeShipping=22]="FreeShipping",e[e.ForumIcon=23]="ForumIcon",e[e.GroupBuy=24]="GroupBuy",e[e.GroupBuyCount=25]="GroupBuyCount",e[e.masonrySinglePrice=26]="masonrySinglePrice",e[e.InsightDecoration=27]="InsightDecoration",e[e.ForumCashback=28]="ForumCashback",e[e.SalesVolume=29]="SalesVolume",e[e.SingleDay=30]="SingleDay",e[e.Percentage=31]="Percentage",e[e.blockPrice=32]="blockPrice",e[e.PriceWidthDealDecoration=33]="PriceWidthDealDecoration",e[e.newYear=34]="newYear",e[e.HoverTitle=35]="HoverTitle",e[e.PriceWithDealDaysDecoration=36]="PriceWithDealDaysDecoration",e[e.EstimatedCashback=37]="EstimatedCashback",e[e.blockPriceV2=38]="blockPriceV2",e[e.masonryBlockPriceV2=39]="masonryBlockPriceV2",e[e.BlockPriceWc=40]="BlockPriceWc",e[e.MasonrySinglePriceWc=41]="MasonrySinglePriceWc",e[e.StrikedOutPriceWc=42]="StrikedOutPriceWc"}(r||(r={}))},28971(e,t,o){o.d(t,{O(){return w},X(){return x}});var i=o(96950),r=o(416),a=o(10108),n=o(39957),s=o(69259),d=o(85218),c=o(81054),l=o(75688);l.k;const h=i.qy`<msn-hide-story-card class="hide-feedback instant-hide hide-shopping-card" align-actions="vertical" style="--content-region-width: auto;" hideStoryTitle="${e=>{var t;return(null===(t=e.personalizationEntity)||void 0===t?void 0:t.getTitle)&&e.personalizationEntity.getTitle(e)}}" data-t="${e=>{var t;return(null===(t=e.personalizationEntity)||void 0===t?void 0:t.getTitleTelemetryTag)&&e.personalizationEntity.getTitleTelemetryTag(e)}}">${(0,n.ux)(e=>{var t;return null===(t=e.personalizationEntity)||void 0===t?void 0:t.personalizationOptions},i.qy`<fluent-menu-item aria-label=${(e,t)=>e.getText&&e.getText(t.parent)} role="button" title=${(e,t)=>e.getText&&e.getText(t.parent)} @click=${(e,t)=>e.callback&&e.callback(t.parent)} slot="actions" appearance="stealth" class="hide-action-button" tabindex="0" data-t="${(e,t)=>e.getTelemetryTag&&e.getTelemetryTag(t.parent)}"><div class="menu-item-text">${(e,t)=>e.getText&&e.getText(t.parent)}</div></fluent-menu-item>`)}<fluent-menu-item aria-label=${e=>{var t;return(null===(t=e.personalizationEntity)||void 0===t?void 0:t.getUndoHideButtonText)&&e.personalizationEntity.getUndoHideButtonText(e)}} role="button" title=${e=>{var t;return(null===(t=e.personalizationEntity)||void 0===t?void 0:t.getUndoHideButtonText)&&e.personalizationEntity.getUndoHideButtonText(e)}} @click="${e=>{var t;return(null===(t=e.personalizationEntity)||void 0===t?void 0:t.onUndo)&&e.personalizationEntity.onUndo(e)}}" slot="actions" appearance="stealth" class="hide-action-button stealth-button" tabindex="0" id="Undo" data-t="${e=>{var t;return(null===(t=e.personalizationEntity)||void 0===t?void 0:t.getUndoButtonTelemetryTag)&&e.personalizationEntity.getUndoButtonTelemetryTag(e)}}"><div class="menu-item-text">${e=>{var t;return(null===(t=e.personalizationEntity)||void 0===t?void 0:t.getUndoHideButtonText)&&e.personalizationEntity.getUndoHideButtonText(e)}}</div></fluent-menu-item></msn-hide-story-card>`;var u=o(17288);l.k,u.F;const p=i.qy`<msn-hide-story-card class="hide-feedback instant-hide hide-confirm hide-shopping-card" align-actions="vertical" style="--content-region-width: auto;" hideStoryTitle="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.title}}" data-t="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.titleTelemetryTag}}">${(0,s.z)(e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.showSpinner},i.qy`<msn-animated-done-spinner slot="actions" class="check-icon" pre-text="Updating your feed" post-text="Done" card-size="_1x_2y" :spinnerCompletedCallback="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.spinnerCompletedCallback}}">></msn-animated-done-spinner>`)} ${(0,s.z)(e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.showRefresh},i.qy`<fluent-menu-item aria-label="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.refreshText}}" role="button" title="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.refreshText}}" @click="${e=>{var t;return(null===(t=e.hiddenEntity)||void 0===t?void 0:t.onRefresh)&&e.hiddenEntity.onRefresh(e)}}" slot="actions" appearance="stealth" class="hide-action-button" tabindex="0" data-t="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.refreshTelemetryTag}}"><div class="menu-item-text">${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.refreshText}}</div></fluent-menu-item>`)} ${(0,s.z)(e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.showManage},i.qy`<fluent-menu-item aria-label="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.manageText}}" role="button" title="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.manageText}}" @click="${e=>{var t;return(null===(t=e.hiddenEntity)||void 0===t?void 0:t.onManage)&&e.hiddenEntity.onManage(e)}}" slot="actions" appearance="stealth" class="hide-action-button" tabindex="0" data-t="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.manageTelemetryTag}}"><div class="menu-item-text">${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.manageText}}</div></fluent-menu-item>`)} ${(0,s.z)(e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.showUndo},i.qy`<fluent-menu-item aria-label="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.undoText}}" role="button" title="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.undoText}}" @click="${e=>{var t;return(null===(t=e.hiddenEntity)||void 0===t?void 0:t.onUndo)&&e.hiddenEntity.onUndo(e)}}" slot="actions" appearance="stealth" class="hide-action-button stealth-button" tabindex="0" data-t="${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.undoTelemetryTag}}"><div class="menu-item-text">${e=>{var t;return null===(t=e.hiddenEntity)||void 0===t?void 0:t.undoText}}</div></fluent-menu-item>`)}</msn-hide-story-card>`,g=(0,o(75307).Eo)("DismissSize20Regular",void 0,"icons-wc/icons"),b=i.qy`<button slot="personalization-button" @click="${(e,t)=>{var o;return null===(o=e.personalizationEntity)||void 0===o?void 0:o.onCross(e)}}" aria-label="${(e,t)=>{var o;return null===(o=e.personalizationEntity)||void 0===o?void 0:o.getCrossTooltip(e)}}" title="${(e,t)=>{var o;return null===(o=e.personalizationEntity)||void 0===o?void 0:o.getCrossTooltip(e)}}" class="hide-card" data-t="${(e,t)=>{var o,i;return null===(o=e.personalizationEntity)||void 0===o||null===(i=o.getCrossTelemetryTag)||void 0===i?void 0:i.call(o,e)}}"><img class="cross-icon" src=${g} alt="Cross" aria-hidden="true"/></button>`;var v=o(88988),m=o(58792);const f=i.qy`<button class="more-options-button" @click=${(e,t)=>e.onClickMoreOptionsButton&&e.onClickMoreOptionsButton(t.event,e)} data-t="${e=>{var t;return null===(t=e.shoppingEntity)||void 0===t?void 0:t.moreOptionsTelemetryTag}}" title=${e=>{var t;return null===(t=e.shoppingEntity)||void 0===t?void 0:t.moreOptionsText}}><img alt="" aria-hidden="true" src="${(0,m.rA)().StaticsUrl}/latest/fluent-icons/more_horizontal_20_regular.svg"></img></button>`,x=i.qy`<button class="expand-button"><div class="fly-in-and-fade-in-and-bounce"><div class="arrow-up"></div></div></button>`,$=i.qy`<div class="product-info ${e=>e.hasRating&&e.hasRatingAttribute?"has-rating":""}"><div class="decoration-groups middle" ${(0,r.Y)({property:"decorationGroupsMiddle",filter:(0,a.Y)("msn-shopping-decoration-group")})}>${(0,n.ux)(e=>{var t;return Array.from((null===(t=e.decorationsByPosition)||void 0===t?void 0:t.keys())||[]).filter(e=>"middle"==e)},d.AF)}</div>${c.u} ${(0,n.ux)(e=>e.variantAttibutes,i.qy`${(e,t)=>t.parent.attributeTemplateMap[e]}`)}</div>`,k=i.qy`<div class="${e=>e.shoppingCardInnerClasses}">${(0,s.z)((e,t)=>{var o;return(null===(o=e.personalizationEntity)||void 0===o?void 0:o.useExplicitPersonalization)&&e.isCarouselDataPersonalized&&!e.enableProductCardOptions},b)} ${(0,s.z)((e,t)=>e.enableProductCardOptions,f)} ${d.i_} ${$} ${(0,s.z)(e=>e.decorationsByPosition.size>0,d.RW)} ${(0,s.z)(e=>e.clickToReveal&&e.handleExpandClick,i.qy`<div class="expand-button-container" @click="${(e,t)=>e.handleExpandClick()}" data-t="${e=>{var t;return null===(t=e.shoppingEntity)||void 0===t?void 0:t.interactionTelemetryTag}}">${x}</div>`)}</div>`,y=i.qy`<a class="anchor-wrapper" tabindex="0" href="${e=>{var t;return null===(t=e.shoppingEntity)||void 0===t?void 0:t.clickUrl}}" rel="${e=>{var t;return null!==(t=e.shoppingEntity)&&void 0!==t&&t.clickUrl?(0,v.yE)(e.shoppingEntity.clickUrl):""}}" aria-hidden="true" target="_blank" title="${e=>{var t;return null===(t=e.shoppingEntity)||void 0===t?void 0:t.title}}" @mousedown=${(e,t)=>e.handleMousedown(t.event)} @click=${(e,t)=>e.handleClick(t.event)} @keydown=${(e,t)=>e.keydownHandler(t.event)} @mouseenter="${e=>e.handleHydratedContainerMouseEnter()}" @mouseleave="${e=>e.handleHydratedContainerMouseLeave()}" data-t="${e=>{var t;return null===(t=e.shoppingEntity)||void 0===t?void 0:t.telemetryTag}}">${(0,s.z)(e=>e.useCardParentElement,i.qy`<cs-card class="shopping-product-card">${k}</cs-card>`)} ${(0,s.z)(e=>!e.useCardParentElement,i.qy`<div class="shopping-product-card">${k}</div>`)}</a>`,w=i.qy`
${(0,s.z)(e=>e.showPersonalizationCard&&!e.showHiddenCard,h)}
${(0,s.z)(e=>!e.showPersonalizationCard&&e.showHiddenCard,p)}
${(0,s.z)(e=>!e.showPersonalizationCard&&!e.showHiddenCard&&e.shoppingEntity,y)}
${(0,s.z)(e=>!e.shoppingEntity,d.w1)}
`},33948(e,t,o){o.d(t,{Y(){return c},c(){return d}});var i=o(74998),r=o(93552),a=o(22341),n=o(69914),s=o(17918);function d(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:performance.now();const o=!0===i.Rb.IsPrerender?t-(0,s.W4)(n.xF):t;(0,s.tD)(e,o)}function c(e,t){try{var o,i;if(null!=e&&null!==(o=e.seeAllSlide)&&void 0!==o&&o.clickUrl&&null!=e&&null!==(i=e.seeAll)&&void 0!==i&&i.clickUrl){const o=new URL(e.seeAllSlide.clickUrl);o.searchParams.set("q",t),e.seeAllSlide.clickUrl=o.toString(),e.seeAll.clickUrl=o.toString()}}catch(e){(0,a.c_)(e,r.UMt,"Error in Replacing See All Url")}return e}},34768(e,t,o){o.d(t,{F7(){return d},Xt(){return c}});var i=o(6711),r=o(24642),a=o(67860);const n=(0,r.el)(i.DE,i.l2,i.L6,i.tN);function s(e){return t=>{const o=(0,a.xL)(t),r=o>=n(t)?-1:1;return(0,a.FD)(o+r*e(t),(0,i.ro)(t))}}const d=(0,r.kT)(s(i.DE)),c=(0,r.kT)(s(i.l2)),l=(0,r.kT)(s(i.L6)),h=(0,r.kT)(s(i.tN)),u=(0,r.kT)(s(i.SL));(0,r.kT)(e=>({rest:d(e),hover:c(e),active:l(e),focus:h(e),selected:u(e)}))},37256(e,t,o){o.d(t,{R(){return h}});var i=o(64187),r=o(22131),a=o(74849),n=o(50882),s=o(37998),d=o(57416),c=o(95239),l=o(48751);const h=a.A`
    ${(0,i.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${c.p};
        color: ${l.l};
        border-radius: calc(${d.JU} * 1px);
        ${s.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,r.mr)(a.A`
            :host {
                forced-color-adjust: none;
                background: ${n.A.Canvas};
                box-shadow: 0 0 0 1px ${n.A.CanvasText};
            }
        `))},38380(e,t,o){o.d(t,{v(){return i}});const i=(0,o(25717).T)()},39467(e,t,o){o.d(t,{G1(){return C},XR(){return T},Wr(){return z}});var i=o(74849),r=o(48751),a=o(24458),n=o(41123),s=o(64003),d=o(82492),c=o(27258),l=o(61138),h=o(55153),u=o(12640),p=o(58792);const g=i.A` .ad-slug .ad-label{border:0.5px solid rgba(255,255,255,.3);opacity:0.9}`,b=i.A`
.ad-slug{align-items:center;color:${r.l};
    display: flex;
    flex-direction: row;
    line-height: ${l.F};
    max-width: calc(${h.QG} * 1px - 100px);opacity:0.8;overflow:hidden}.ad-slug .ad-label{display:flex;align-items:center;border:0.5px solid rgba(26,26,26,.3);border-radius:4px;box-sizing:border-box;font-size:11px;height:16px;margin-inline-end:6px;min-width:22px;padding:1px 4px;overflow:hidden}.ad-slug .ad-label-text{color:inherit;pointer-events:auto;position:relative;text-decoration:none;z-index:1}[size="_2x_2y"] .ad-slug{max-width:calc(${h.QG} * 2px - 100px);
}
`.withBehaviors(new u.N(null,g)),v=`${p.T3.StaticsUrl}latest/`,m=`${v}icons-wc/icons/AdChoice.svg`,f=`${v}icons-wc/icons/AdChoiceDark.svg`,x=`${v}icons-wc/icons/AdChoiceLight.svg`,$=i.A` .ad-choice-mono > .ad-choice-svg{background:url(${f}) no-repeat center}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice-mono > .ad-choice-svg{background:url(${x}) no-repeat center;
        }
    }
`,k=i.A` .ad-choice-mono > .ad-choice-svg{background:url(${x}) no-repeat center}@media (forced-colors:active) and (prefers-color-scheme:dark){.ad-choice-mono > .ad-choice-svg{background:url(${f}) no-repeat center;
        }
    }
`,y=i.A` .ad-choice{margin-inline-start:10px}.ad-choice > .ad-choice-svg{background:url(${m}) no-repeat center}@media (forced-colors:active) and (prefers-color-scheme:dark){.ad-choice > .ad-choice-svg{background:url(${f}) no-repeat center}}@media (forced-colors:active) and (prefers-color-scheme:light){.ad-choice > .ad-choice-svg{background:url(${x}) no-repeat center}}.ad-choice-mono > .ad-choice-svg{opacity:0.53}.ad-choice-svg{display:inline-block;width:12px;height:12px}`.withBehaviors(new u.N(k,$));var w=o(96849);const C=i.A`
.expand-button-container{position:absolute;bottom:0;width:100%;height:44px}.expand-button{padding:0;display:flex;justify-content:center;position:absolute;height:100%;width:100%;bottom:0;background:transparent;border:none;cursor:pointer}.shopping-product-card:hover .fly-in-and-fade-in-and-bounce{top:5px;opacity:100%}.fly-in-and-fade-in-and-bounce{position:absolute;opacity:0%;transition:top .3s ease-in,opacity 0.3s ease-in 0s;animation:bounce 2000ms infinite cubic-bezier(0.445,0.05,0.55,0.95);top:15px}@keyframes bounce{50%{transform:translateY(-3px)}}.shopping-product-card:hover .arrow-up{visibility:visible}.arrow-up{visibility:hidden;position:relative;top:20%;left:50%;width:10px;height:3px;background:${r.l};transform:rotate(45deg);transform-origin:0% 0%;border-radius:5px}.arrow-up::after{content:"";float:left;position:relative;width:100%;height:100%;top:-100%;border-radius:5px;background:${r.l};
    transform: rotate(90deg);
    transform-origin: 0px 100%;
}
`,z=i.A`
${d.YI}
${w.h}
${C}
${d.xu}
${c.u}
${b}
${y}
${d.Yk} :host{width:var(--item-width,220px);height:var(--item-height,100%)}.shopping-product-card{height:var(--item-height,320px);width:var(--item-width,220px);background:var(--card-background-color,${a.m_});border-radius:var(--card-border-radius,calc((var(--layer-corner-radius) - var(--stroke-width))* 1px));box-shadow:var(--card-box-shadow,0 0 0 calc(var(--stroke-width)* 1px) var(--card-stroke-color),0px 2px 4px rgba(0,0,0,0.04))}.product-image-container{position:absolute}:host(.regular-card) .product-image-container{margin:var(--shopping-image-margin-regular,0px)}.product-info{position:absolute;inset:calc(100% - var(--initial-product-info-height,44px)) 0px 0px}.product-info{display:flex;flex-direction:column;justify-content:center;align-items:var(--product-info-align-items,center);background-color:var(--product-info-background-color,${a.m_});
    color: ${r.l};padding:var(--product-info-padding,6px)}@keyframes slide-up{0%{top:calc(100% - 44px);height:44px}100%{top:calc(100% - 66px);height:54px}}@keyframes hover-slide-up{0%{top:calc(100% - 46px);height:46px}100%{top:calc(100% - 98px);height:76px}}@keyframes hover-slide-up-rating{0%{top:calc(100% - 46px);height:46px}100%{top:calc(100% - 118px);height:96px}}@keyframes hover-slide-up-2{0%{top:calc(100% - 46px);height:46px}100%{top:calc(100% - 118px);height:96px}}@keyframes hover-slide-up-rating-2{0%{top:calc(100% - 46px);height:46px}100%{top:calc(100% - 138px);height:116px}}:host([expanded]) .product-info{animation:var(--product-info-animation,slide-up 0.3s ease-in);animation-fill-mode:forwards;padding:var(--product-info-expanded-padding,var(--product-info-padding,6px));opacity:var(--product-info-expanded-opacity,1);align-items:var(--product-info-expanded-align-items,var(--product-info-align-items,center))}:host([expanded]) .product-info.has-rating{animation:var(--product-info-rating-animation,slide-up 0.3s ease-in);animation-fill-mode:forwards}:host([expanded]) .shopping-product-card{background:#fff}.title{-webkit-line-clamp:var(--product-title-line-clamp,1);margin:var(--product-title-margin,0px);font-weight:var(--product-title-font-weight,600);word-break:var(--product-title-word-break,break-all)}.has-rating .title{margin:0 0 4px}.seller{-webkit-line-clamp:1;font-weight:600;font-size:var(--product-seller-font-size,${n.K});
    line-height: var(--product-seller-line-height, ${n.Z});overflow:hidden;word-break:break-all}.title,.price{font-size:${n.K};
    line-height: ${n.Z};overflow:hidden}.title,.seller{-webkit-box-orient:vertical;white-space:normal}.rating,.price,.seller,.title{display:none}.init-seller .seller,.init-title .title{display:-webkit-box}.init-price .price{display:flex}.price{flex-direction:row;gap:3px;font-weight:var(--shopping-price-font-weight,600);color:var(--shopping-price-color,inherit);align-items:var(--shopping-price-align-items,normal)}.current-price.sale{color:var(--shopping-current-price-color,inherit)}.previous-price{text-decoration-line:line-through;text-decoration-thickness:1px;color:${s.c};vertical-align:bottom;font-size:var(--previous-price-font-size,13px)}.rating{margin:0 0 12px}:host([expanded]) .title{display:-webkit-box}:host([expanded]) .rating,:host([expanded]) .price{display:flex}:host([expanded]) .seller{color:var(--seller-expanded-color,${s.c})}:host([expanded]) .expand-button-container{display:none}`.withBehaviors(new u.N(null,i.A` :host([expanded]) .shopping-product-card{background:var(--card-background-color-dark,#fff)}.shopping-product-card{background:var(--card-background-color-dark,${a.m_})}.product-info{background-color:var(--product-info-background-color-dark,${a.m_})}.price{color:var(--shopping-price-color-dark,inherit)}.current-price.sale{color:var(--shopping-current-price-color-dark,var(--shopping-current-price-color,inherit))}${w.M}
            `)),T=i.A`
    ${d.QZ} :host(.carousel-item){width:var(--item-width,220px);height:var(--item-height,320px)}.product-image-container{background:#fff}.title{height:var(--title-height,40px);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;white-space:normal;margin-top:var(--title-padding-top);color:var(--title-color,var(--neutral-foreground-rest));font-weight:var(--title-font-weight,600);font-size:var(--title-font-size,14px);line-height:var(--title-line-height,20px);transition:var(--title-transition)}.price{font-weight:600;padding-top:var(--colored-price-text-padding-top,12px);transition:var(--colored-price-transition);opacity:var(--colored-price-opacity)}.previous-price{padding:var(--original-price-padding,0 0 3px 0);font-size:var(--original-price-font-size,12px)}.anchor-wrapper:hover .price{padding-top:var(--colored-price-text-hover-padding-top)}.current-price-currency{font-size:var(--price-font-size)}.animate-in{animation-name:animateIn}.animate-scroll{opacity:var(--animate-scroll-opacity);padding-top:var(--animate-scroll-padding-top)}@keyframes animateIn{0%{transform:translateY(50%)}100%{transform:translateX(100%)}}.sale{color:var(--discount-price-color,var(--price-color,var(--neutral-foreground-rest)))}.shopping-product-card{width:var(--item-width);height:var(--item-height);background:var(--shopping-info-background-color,var(--neutral-fill-layer-rest))}.product-info{padding:var(--product-info-padding,0 16px)}`.withBehaviors(new u.N(null,i.A`
            .shopping-product-card{
                background: var(--shopping-info-background-color-dark, var(--neutral-fill-layer-rest));
            }
        `))},43774(e,t,o){o.d(t,{p4(){return b},ls(){return v},vA(){return g},nF(){return p}});var i=o(45755),r=o(68009),a=o(95239);const{create:n}=i.G,s=n("neutral-stroke-strong-hover-delta",40),d=n("neutral-stroke-strong-active-delta",16),c=n("neutral-stroke-strong-focus-delta",25);var l=o(31023);const{create:h}=i.G,u=h({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,t,o,i,a,n){const s=(0,r.F)(t),d=e.colorContrast(t,o),c=e.closestIndexOf(d);return{rest:d,hover:e.get(c+s*i),active:e.get(c+s*a),focus:e.get(c+s*n)}}(e(l.r),e(a.p),3,e(s),e(d),e(c))}}),p=h("neutral-stroke-strong-rest",e=>e(u).evaluate(e).rest),g=h("neutral-stroke-strong-hover",e=>e(u).evaluate(e).hover),b=h("neutral-stroke-strong-active",e=>e(u).evaluate(e).active),v=h("neutral-stroke-strong-focus",e=>e(u).evaluate(e).focus)},56286(e,t,o){o.d(t,{c(){return c}});var i=o(6711),r=o(24642),a=o(55609),n=o(67860);function s(e,t,o,r,s,d){return c=>{const l=(0,a.OB)(e,c),h=(0,n.ud)(c)?-1:1,u=(0,n.A2)(i.oR)(l)(n.HE)(()=>h)((0,n.EC)((0,a.OB)(t,c)))(c),p=(0,n.yB)(e,u)(c),g=(0,a.OB)(o,c),b=(0,a.OB)(r,c),v=(0,a.OB)(s,c),m=(0,a.OB)(d,c);return function(e,t,o,i,r,a,s){const d=e+o*Math.abs(i-r),c=1===o?i<r:o*i>o*r,l=c?e:d,h=c?d:e,u=l+o*a,p=l+o*s;return{rest:(0,n.FD)(l,t),hover:(0,n.FD)(h,t),active:(0,n.FD)(u,t),focus:(0,n.FD)(p,t)}}(p,l,h,g,b,v,m)}}function d(e){return s(i.ro,e,0,0,0,0)}const c=(0,r.sP)(r.TF.rest,(0,r.kT)(d(4.5)));(0,r.sP)(r.TF.rest,(0,r.kT)(d(3)))},59704(e,t,o){var i;o.d(t,{DR(){return a},mT(){return s},hO(){return r},Qi(){return d},Fw(){return n}}),function(e){e.NORMAL="normal",e.AUTO="auto",e.EXPAND_ON_HOVER="expandOnHover",e.EXPAND_ON_HOVER_INSTANT="expandOnHoverInstant"}(i||(i={}));const r=18,a=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:2;if(e)for(const[o,r]of e)if(r.length>1){r[0].style||(r[0].style=""),r[0].style+=`--decorations-number: ${r.length}; `,r[0].style+=`--decoration-auto-animation-duration: ${r.length*t}s; `,r[0].style+=`--decoration-auto-animation-delay: ${(r.length-1)*t}s; `,r[0].style+=`--decoration-auto-animation-keyframes: expand-collapse-${r.length}; `,r[0].animationMode=i.NORMAL;let e=1;for(;e<r.length;)r[e].style||(r[e].style=""),r[e].style+=`--decorations-number: ${r.length}; `,r[e].style+=`--decoration-auto-animation-duration: ${r.length*t}s; `,r[e].style+=`--decoration-auto-animation-delay: ${(e-1)*t}s; `,r[e].style+=`--decoration-auto-animation-keyframes: expand-collapse-${r.length}; `,r[e].animationMode=i.EXPAND_ON_HOVER,e++}},n=e=>{var t;if((null==e||null===(t=e.children)||void 0===t?void 0:t.length)>1)for(let t=0;t<e.children.length;t++)e.children[t].setAttribute("animationMode",`${i.EXPAND_ON_HOVER}`),0==t&&e.children[t].setAttribute("animationMode",`${i.NORMAL}`)},s=e=>{var t;if((null==e||null===(t=e.children)||void 0===t?void 0:t.length)>1)for(let t=0;t<e.children.length;t++)e.children[t].setAttribute("animationMode",`${i.AUTO}`)},d=e=>{const t=e.currentTarget,o=e.currentTarget.parentNode.children;if(o.length>1){let e=parseInt(getComputedStyle(t).getPropertyValue("--decoration-collapse-width"),10);e=isNaN(e)?r:e;const a=t.clientWidth,n=t.getAttribute("animationMode")==i.AUTO;for(let e=0;e<o.length;e++){o[e].setAttribute("animationMode",`${i.EXPAND_ON_HOVER}`)}n&&a>e&&t.setAttribute("animationMode",`${i.EXPAND_ON_HOVER_INSTANT}`)}}},60143(e,t,o){o.d(t,{B(){return a}});var i=o(96950),r=o(18893);function a(e={}){const t={};return i.qy`
        <template
            role="button"
            aria-disabled="${e=>!!e.disabled||void 0}"
            tabindex="${e=>e.hiddenFromAT?-1:0}"
            @keyup="${(e,t)=>e.keyupHandler(t.event)}"
        >
            ${o=>function(e,o){let a=t[e];return a||(t[e]=a=i.qy`
                <span part="${e}" class="${e}">
                    <slot name="${e}">
                        ${(0,r.R)(o[e])}
                    </slot>
                </span>
            `),a}(o.direction,e)}
        </template>
    `}},64186(e,t,o){o.d(t,{Wl(){return d}});var i=o(6711),r=o(24642),a=o(67860);const n=(0,r.el)(i.DE,i.l2,i.L6,i.tN,i.q,i.oj,i.Ws,i.Mc);function s(e){return t=>{const o=(0,a.xL)(t),r=o>=n(t)?-1:1;return(0,a.FD)(o+r*e(t),(0,i.ro)(t))}}const d=(0,r.kT)(s(i.q)),c=(0,r.kT)(s(i.oj)),l=(0,r.kT)(s(i.Ws)),h=(0,r.kT)(s(i.Mc)),u=(0,r.kT)(s(i.pW));(0,r.kT)(e=>({rest:d(e),hover:c(e),active:l(e),focus:h(e),selected:u(e)}))},71653(e,t,o){o.d(t,{Bl(){return l},bj(){return c}});var i=o(56911),r=o(74248),a=o(39467),n=o(92011),s=o(28971),d=o(85218);let c=class extends r.C{};c=(0,i.Cg)([(0,n.E)({name:"msn-shopping-carousel-expandable-product-card",template:s.O,styles:a.Wr,shadowOptions:{delegatesFocus:!0}})],c);let l=class extends r.C{};l=(0,i.Cg)([(0,n.E)({name:"msn-shopping-full-mit-product-card",template:d.kN,styles:a.XR,shadowOptions:{delegatesFocus:!0}})],l)},72526(e,t,o){o.d(t,{L(){return g}});var i=o(56911),r=o(96193),a=o(47429),n=o(60815),s=o(22870),d=o(38493),c=o(95239),l=o(31023),h=o(24458),u=o(5291),p=o(57606);class g extends r.z{cardFillColorChanged(e,t){if(t){const e=(0,s.Hs)(t);null!==e&&(this.neutralPaletteSource=t,c.p.setValueFor(this,u.q.create(e.r,e.g,e.b)))}}neutralPaletteSourceChanged(e,t){if(t){const e=(0,s.Hs)(t),o=u.q.create(e.r,e.g,e.b);l.r.setValueFor(this,p.p.create(o))}}handleChange(e,t){this.cardFillColor||c.p.setValueFor(this,e=>e(h.M3).evaluate(e,e(c.p)))}connectedCallback(){super.connectedCallback();const e=(0,a.Zo)(this);if(e){const t=n.cP.getNotifier(e);t.subscribe(this,"fillColor"),t.subscribe(this,"neutralPalette"),this.handleChange(e,"fillColor")}}}(0,i.Cg)([(0,d.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,i.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,i.Cg)([(0,d.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,i.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0)},74248(e,t,o){o.d(t,{C(){return s}});var i=o(56911),r=o(23528),a=o(60815),n=o(38493);class s extends r.E{constructor(){super(...arguments),this.clickToReveal=!0,this.expanded=!1,this.showPersonalizationCard=!1,this.showHiddenCard=!1,this.initialAttributeNames=["seller"],this.enableProductCardOptions=!1,this.handleScroll=()=>{var e;const t=null===(e=this.parentElement)||void 0===e||null===(e=e.parentElement)||void 0===e?void 0:e.parentElement;if("CS-STRIPE"===(null==t?void 0:t.tagName)){var o;const e=null===(o=this.anchorWrapperRef)||void 0===o?void 0:o.querySelector(".price"),i=t.getBoundingClientRect().top,r=t.offsetHeight,a=window.innerHeight;e&&(a-i<r||r+i<100?e.classList.add("animate-scroll"):e.classList.remove("animate-scroll"))}}}connectedCallback(){super.connectedCallback(),this.mapSuperCarouselCardData(),this.enableScrollPrice&&window.addEventListener("scroll",this.handleScroll)}disconnectedCallback(){super.disconnectedCallback(),this.enableScrollPrice&&window.removeEventListener("scroll",this.handleScroll)}mapSuperCarouselCardData(){if(!this.data)return;const{shoppingEntity:e,displayAttributes:t,shoppingProductCarouselVariant:o,decorationsByPosition:i,useCardParentElement:r,isCarouselDataPersonalized:a,personalizationEntity:n,onCardVisuallyReady:s,enableScrollPrice:d,enableCNPriceCurrencySymbol:c,shouldLazyLoadImages:l,enable1688ClickParams:h,setCardList:u,clickToReveal:p,enableProductCardOptions:g,onClickMoreOptionsButton:b,initialAttributeNames:v}=this.data;this.shoppingEntity=e,this.displayAttributes=t,this.shoppingProductCarouselVariant=o,this.useCardParentElement=!!r,this.isCarouselDataPersonalized=a,this.personalizationEntity=n,this.enableScrollPrice=d,this.enableCNPriceCurrencySymbol=c,this.shouldLazyLoadImages=!!l,this.enable1688ClickParams=h,this.clickToReveal=!!p,this.enableProductCardOptions=!!g,this.onClickMoreOptionsButton=b,v&&(this.initialAttributeNames=v),s&&(this.onCardVisuallyReady=s),i&&(this.decorationsByPosition=i),u&&u(this)}get shoppingCardInnerClasses(){var e;const t=["shopping-product-card-inner"];return null!==(e=this.initialAttributeNames)&&void 0!==e&&e.length&&this.initialAttributeNames.forEach(e=>{t.push(`init-${e}`)}),t.join(" ")}handleExpandClick(){this.expanded=!0}handleHydratedContainerMouseEnter(e,t){super.handleHydratedContainerMouseEnter(e,t),this.clickToReveal||(this.expanded=!0)}handleHydratedContainerMouseLeave(e,t){super.handleHydratedContainerMouseLeave(e,t),this.clickToReveal||(this.expanded=!1)}}(0,i.Cg)([(0,n.CF)({mode:"boolean"})],s.prototype,"clickToReveal",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean"})],s.prototype,"expanded",void 0),(0,i.Cg)([a.sH],s.prototype,"personalizationEntity",void 0),(0,i.Cg)([a.sH],s.prototype,"hiddenEntity",void 0),(0,i.Cg)([a.sH],s.prototype,"showPersonalizationCard",void 0),(0,i.Cg)([a.sH],s.prototype,"showHiddenCard",void 0),(0,i.Cg)([a.sH],s.prototype,"isCarouselDataPersonalized",void 0),(0,i.Cg)([a.sH],s.prototype,"initialAttributeNames",void 0),(0,i.Cg)([a.sH],s.prototype,"enableProductCardOptions",void 0),(0,i.Cg)([a.sH],s.prototype,"onClickMoreOptionsButton",void 0),(0,i.Cg)([a.sH],s.prototype,"data",void 0),(0,i.Cg)([a.Jg],s.prototype,"shoppingCardInnerClasses",null)},75003(e,t,o){o.d(t,{m(){return s}});var i=o(37180),r=o(72526),a=o(37256),n=o(38380);const s=r.L.compose({name:`${i.c.prefix}-card`,template:n.v,styles:a.R})},75688(e,t,o){o.d(t,{k(){return N}});var i=o(56911),r=o(4731),a=o(37180),n=o(88817),s=o(45899),d=o(73079),c=o(92011),l=o(38493),h=o(60815);class u extends c.L{constructor(){super(...arguments),this.actionAlignment="horizontal",this.isHeadingLoaded=!1}actionsSlottedNodesChanged(){var e,t;const o=null===(e=this.actionsSlottedNodes[0])||void 0===e?void 0:e.children[0];o&&window.setTimeout(()=>{o.focus()},0),null===(t=this.actionsSlottedNodes[0])||void 0===t||t.focus()}headingSlottedNodesChanged(){!this.isHeadingLoaded&&window.setTimeout(()=>{this.isHeadingLoaded=!0},0)}}(0,i.Cg)([(0,l.CF)({attribute:"align-actions"})],u.prototype,"actionAlignment",void 0),(0,i.Cg)([l.CF],u.prototype,"hideStoryTitle",void 0),(0,i.Cg)([h.sH],u.prototype,"actionsSlottedNodes",void 0),(0,i.Cg)([h.sH],u.prototype,"headingSlottedNodes",void 0),(0,i.Cg)([h.sH],u.prototype,"isHeadingLoaded",void 0);var p=o(7040),g=o(55609),b=o(34768),v=o(64186),m=o(56286),f=o(48751),x=o(89580),$=o(86856),k=o(30860),y=o(74849),w=o(64187),C=o(22131),z=o(12640),T=o(50882),_=o(58792),S=o(9307);const F=y.A` :host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item#Undo){right:0}`,B=y.A` :host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item#Undo){left:0}`,L=y.A` :host{--hide-story-background:${(0,p.dR)(()=>k.go)(g.Ay)};
        --button-color: ${(0,b.F7)((0,p.dR)(()=>k.go))(g.Ay)};
        --button-hover-color: ${(0,b.Xt)((0,p.dR)(()=>k.go))(g.Ay)};
        --stealth-button-color: ${(0,v.Wl)((0,p.dR)(()=>k.go))(g.Ay)};
        --stealth-button-text-color: ${(0,m.c)((0,p.k6)(()=>k.go))(g.Ay)};
        --neutral-fill-rest: ${(0,b.F7)((0,p.dR)(()=>k.go))(g.Ay)};
        --neutral-fill-hover: ${(0,b.Xt)((0,p.dR)(()=>k.go))(g.Ay)}}:host(.hide-feedback.instant-hide){${(0,S.zJ)(_.T3.CurrentMarket)?"--hide-story-background: linear-gradient(-90deg, #F6FAFF 2%, #F7FCFF 31.46%, #EAF6FF 97.33%);":"--hide-story-background: linear-gradient(90deg, #F6FAFF 2%, #F7FCFF 31.46%, #EAF6FF 97.33%);"}
    }
`,I=y.A` :host{--hide-story-background:${(0,p.pq)(()=>k.kJ)(g.Ay)};
        --button-color: ${(0,b.F7)((0,p.pq)(()=>k.kJ))(g.Ay)};
        --button-hover-color: ${(0,b.Xt)((0,p.pq)(()=>k.kJ))(g.Ay)};
        --stealth-button-color: ${(0,v.Wl)((0,p.pq)(()=>k.kJ))(g.Ay)};
        --stealth-button-text-color: ${(0,m.c)((0,p.k6)(()=>k.kJ))(g.Ay)};
        --neutral-fill-rest: ${(0,b.F7)((0,p.pq)(()=>k.kJ))(g.Ay)};
        --neutral-fill-hover: ${(0,b.Xt)((0,p.pq)(()=>k.kJ))(g.Ay)};
    }
`,H=y.A` :host{forced-color-adjust:auto}:host(.hide-feedback) ::slotted(fluent-menu-item){border-color:${T.A.ButtonText}}:host(.hide-feedback) ::slotted(fluent-menu-item:hover),:host(.hide-feedback) ::slotted(fluent-menu-item:focus){background-color:${T.A.Highlight};
        color: ${T.A.HighlightText}}:host(.hide-feedback) ::slotted(fluent-menu-item:focus),:host(.hide-feedback) ::slotted(fluent-button:focus){border-color:${T.A.ButtonText};
        box-shadow: 0 0 0 calc((var(--focus-stroke-width) - var(--stroke-width)) * 1px) ${T.A.ButtonText}}:host(.hide-feedback) ::slotted(.stealth-button:hover),:host(.hide-feedback) ::slotted(.stealth-button:focus){color:var(--stealth-button-text-color)}`,M=y.A`
        ${(0,w.V)("flex")} :host{--action-region-padding-top:0;--content-region-padding-top:16px;--content-region-width:236px;box-sizing:border-box;flex-direction:column;height:100%;position:relative;width:100%}:host(.hide-confirm[card-size="_1x_1y"]) .content-region,:host(.hide-confirm[card-size="_2x_1y"]) .content-region,:host(.hide-confirm[card-size="0.5u"]) .content-region{margin-inline:28px}:host(.hide-confirm[card-size="_1x_1y"]) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm[card-size="_1x_1y"]) ::slotted(fluent-button.stealth-button:hover),:host(.hide-confirm[card-size="_2x_1y"]) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm[card-size="_2x_1y"]) ::slotted(fluent-button.stealth-button:hover),:host(.hide-confirm[card-size="0.5u"]) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm[card-size="0.5u"]) ::slotted(fluent-button.stealth-button:hover){background:var(--button-hover-color)}:host(.hide-confirm[card-size="_1x_1y"]) ::slotted(fluent-button),:host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item),:host(.hide-feedback.instant-hide[card-size="_1x_1y"]) ::slotted(fluent-button.stealth-button),:host(.hide-confirm[card-size="_2x_1y"]) ::slotted(fluent-button),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item),:host(.hide-feedback.instant-hide[card-size="_2x_1y"]) ::slotted(fluent-button.stealth-button),:host(.hide-confirm[card-size="0.5u"]) ::slotted(fluent-button),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item),:host(.hide-feedback.instant-hide[card-size="0.5u"]) ::slotted(fluent-button.stealth-button){height:24px;font-size:var(--type-ramp-minus-1-font-size,12px);color:var(--neutral-foreground-rest);background:var(--button-color)}:host(.hide-feedback[card-size="_1x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="_2x_1y"]) ::slotted(fluent-menu-item#Undo),:host(.hide-feedback[card-size="0.5u"]) ::slotted(fluent-menu-item#Undo){position:absolute;height:18px;width:18px;top:0;margin-inline-end:8px;margin-top:8px;min-width:18px}:host([card-size="_1x_1y"]) .content-region,:host([card-size="_2x_1y"]) .content-region,:host([card-size="0.5u"]) .content-region{padding-top:20px;height:40px;width:232px}:host([card-size="_1x_1y"]) ::slotted(fluent-menu-item),:host([card-size="_2x_1y"]) ::slotted(fluent-menu-item),:host([card-size="0.5u"]) ::slotted(fluent-menu-item){height:24px}:host([card-size="_1x_1y"]) .action-region,:host([card-size="_2x_1y"]) .action-region,:host([card-size="0.5u"]) .action-region{padding-top:10px;padding-bottom:14px}.action-region{display:flex;position:absolute;padding:0 16px 16px;padding-top:var(--action-region-padding-top);justify-content:space-around;bottom:0;width:100%;box-sizing:border-box;align-items:center}:host([align-actions="vertical"]) .action-region{display:block;margin:auto;position:static}.content-region{display:inline-flex;flex-direction:column;align-items:center;padding:16px 16px 0 16px;padding-top:var(--content-region-padding-top);cursor:default}:host([align-actions="vertical"]) .content-region{display:block;margin:auto;text-align:center;width:var(--content-region-width)}.heading,::slotted(.heading){text-decoration:none;color:${f.l};
            font-size: var(--heading-font-size, ${x.Y});
            line-height: var(--heading-line-height, ${x.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,2)}::slotted(fluent-button){margin-bottom:8px;width:48%}:host(.hide-feedback){background:var(--hide-story-background)}:host(.hide-feedback) ::slotted(fluent-menu-item),:host(.hide-confirm) ::slotted(fluent-button){background:var(--button-color);border:calc(var(--stroke-width) * 1px) solid transparent}:host(.hide-feedback) ::slotted(.stealth-button){background:var(--stealth-button-color);color:var(--stealth-button-text-color)}:host(.hide-feedback.instant-hide) ::slotted(.stealth-button){background:transparent}:host(.hide-feedback) ::slotted(fluent-menu-item:hover),:host(.hide-confirm) ::slotted(fluent-button:hover),:host(.hide-feedback.hide-confirm) ::slotted(.stealth-button:hover){background:var(--button-hover-color)}:host(.hide-feedback) ::slotted(fluent-menu-item:focus),:host(.hide-feedback) ::slotted(fluent-button:focus){border:calc(var(--stroke-width) * 1px) solid var(--focus-stroke-outer);box-shadow:0 0 0 calc((var(--focus-stroke-width) - var(--stroke-width)) * 1px) var(--focus-stroke-outer)}:host(.hide-feedback) ::slotted(.stealth-button:hover),:host(.hide-feedback) ::slotted(.stealth-button:focus){background:var(--stealth-button-color)}`.withBehaviors(new $.t(F,B),(0,C.mr)(H),new z.N(L,I));var P=o(96950),A=o(82774),D=o(69259),O=o(10108);const j=P.qy`<div class="content-region" part="content-region" aria-live="assertive"><slot name="heading" ${(0,A.e)({property:"headingSlottedNodes"})}>${(0,D.z)(e=>e.isHeadingLoaded,P.qy`<span class="heading" part="heading" aria-level="2" role="heading">${e=>e.hideStoryTitle}</span>`)}</slot></div><div class="action-region" part="action-region"><slot name="actions" ${(0,A.e)({property:"actionsSlottedNodes",filter:(0,O.Y)("fluent-radio-group, fluent-radio, fluent-button, fluent-anchor, fluent-menu-item")})}></slot></div>`;let N=class extends u{};N=(0,i.Cg)([(0,c.E)({name:"msn-hide-story-card",template:j,styles:M,shadowOptions:{delegatesFocus:!0}})],N),r.m.define(a.c.registry),n.m.define(a.c.registry),s.m.define(a.c.registry),d.m.define(a.c.registry)},82203(e,t,o){o.d(t,{CG(){return w},CY(){return _},N9(){return I},_m(){return k},dY(){return T},es(){return L},ex(){return y},fv(){return H},iD(){return S},qG(){return z},rl(){return M},th(){return C},uU(){return B},vU(){return $}});var i=o(75307),r=o(32623),a=o(89989),n=o(96950);const s=(0,i.Eo)("TagLight",void 0,"icons-wc/icons/shopping"),d=(0,i.Eo)("TagGreen",void 0,"icons-wc/icons/shopping"),c=(0,i.Eo)("FreeShipping",void 0,"icons-wc/icons/shopping"),l=(0,i.Eo)("Truck",void 0,"icons-wc/icons/shopping"),h=(0,i.Eo)("TruckDarkMode",void 0,"icons-wc/icons/shopping"),u=(0,i.Eo)("Ticket",void 0,"icons-wc/icons/shopping"),p=(0,i.Eo)("TicketBlue",void 0,"icons-wc/icons/shopping"),g=(0,i.Eo)("cashback"),b=(0,i.Eo)("cashbackBlue"),v=(0,i.Eo)("fire"),m=(0,i.KN)("view"),f=(0,i.KN)("insight"),x=(0,i.KN)("cart"),$={deal:n.qy`<img src=${s} alt="TagIcon" aria-hidden="true"/>`,freeshipping:n.qy`<img src=${c} alt="FreeShippingIcon" aria-hidden="true"/>`,coupon:n.qy`<img src=${u} alt="TicketIcon" aria-hidden="true"/>`,cashback:n.qy`<img src=${g} alt="CashBackIcon" aria-hidden="true"/>`,hot:n.qy`<img src=${v} alt="FireIcon" aria-hidden="true"/>`,dealGreen:n.qy`<img src=${d} alt="TagGreenIcon" aria-hidden="true"/>`,cashbackBlue:n.qy`<img src=${b} alt="CashbackBlueIcon" aria-hidden="true"/>`,couponBlue:n.qy`<img src=${p} alt="TicketBlueIcon" aria-hidden="true"/>`,freeshippingAlt:n.qy`<img src=${l} alt="TruckIcon" aria-hidden="true"/>`,"freeshippingAlt-dark":n.qy`<img src=${h} alt="TruckIcon" aria-hidden="true"/>`,blackJackCommunityInsight:n.qy`<img src=${x} alt="CartIcon" aria-hidden="true"/>`,blackjackInsight:n.qy`<img src=${f} alt="InsightsIcon" aria-hidden="true"/>`,blackJackViewCount:n.qy`<img src=${m} alt="ViewIcon" aria-hidden="true"/>`},k={attributes:[{attributeType:r.x.Seller,attributeTemplate:a.wj}],imageHeight:160,imageWidth:268,iconTemplateMap:$},y={attributes:[],imageHeight:135,imageWidth:130,iconTemplateMap:$},w={attributes:[{attributeType:r.x.Seller,attributeTemplate:a.wj}],imageHeight:224,imageWidth:268,iconTemplateMap:$},C={attributes:[{attributeType:r.x.Title,attributeTemplate:a.BK},{attributeType:r.x.Seller,attributeTemplate:a.wj}],imageHeight:92,imageWidth:120,iconTemplateMap:$},z={...w,attributes:[{attributeType:r.x.Seller,attributeTemplate:a.wj}],secondaryAttributes:[{attributeType:r.x.Rating,attributeTemplate:a.c6}]},T={attributes:[{attributeType:r.x.Price,attributeTemplate:a.Mt},{attributeType:r.x.Title,attributeTemplate:a.BK},{attributeType:r.x.Seller,attributeTemplate:a.wj},{attributeType:r.x.SalesVolume,attributeTemplate:a.Rp}],iconTemplateMap:$,imageHeight:240,imageWidth:220},_={attributes:[{attributeType:r.x.Title,attributeTemplate:a.BK},{attributeType:r.x.Seller,attributeTemplate:a.wj},{attributeType:r.x.Price,attributeTemplate:a.Mt},{attributeType:r.x.SalesVolume,attributeTemplate:a.Rp}],iconTemplateMap:$,imageHeight:315,imageWidth:240},S={...T,attributes:[...T.attributes,{attributeType:r.x.Rating,attributeTemplate:a.c6}]},F=(r.x.Seller,a.wj,{attributes:[{attributeType:r.x.Title,attributeTemplate:a.BK},{attributeType:r.x.Seller,attributeTemplate:a.wj}],iconTemplateMap:$,cardVariant:r.m.Pivot,imageHeight:142,imageWidth:144,imageCroppingOption:"17",tag:"msn-shopping-prong-pivot-product-card",showSeeAllLink:!0}),B=(r.x.Seller,a.wj,r.x.Price,a.Wj,r.m.Pivot,r.x.Title,a.BK,r.m.Pivot,r.x.Title,a.BK,r.m.Pivot,{attributes:[{attributeType:r.x.Title,attributeTemplate:a.BK},{attributeType:r.x.Seller,attributeTemplate:a.wj}],imageHeight:54,imageWidth:54,imageCroppingOption:"17"}),L={attributes:[],imageHeight:34,imageWidth:34,imageCroppingOption:"17"};function I(e){return e.map(e=>{switch(e){case r.x.Price:return{attributeType:e,attributeTemplate:a.Mt};case r.x.Title:return{attributeType:e,attributeTemplate:a.BK};case r.x.Seller:default:return{attributeType:e,attributeTemplate:a.wj}}})}r.x.Title,a.BK,r.x.Title,a.BK,r.x.Seller,a.BK,r.x.Title,a.wj,r.x.Title,a.BK,r.x.Seller,a.wj;const H={attributes:[{attributeType:r.x.Title,attributeTemplate:a.BK}],imageHeight:240,imageWidth:240};function M(e,t){return e.sort((e,o)=>{const i=t.indexOf(e.attributeType),r=t.indexOf(o.attributeType);return-1===i?1:-1===r?-1:i-r}),e}},82567(e,t,o){o.d(t,{h8(){return f}});var i=o(99900),r=o(56911),a=o(92011),n=o(38493),s=o(60815);class d extends a.L{constructor(){super(...arguments),this.hidden=!1,this.disableActionButton=!1,this.disableCancelButton=!1,this.hideCloseButton=!1,this.localizedStrings={},this.dismissDialog=()=>{this.$emit("action-dialog-dismiss")}}}(0,r.Cg)([(0,n.CF)({mode:"boolean"})],d.prototype,"hidden",void 0),(0,r.Cg)([s.sH],d.prototype,"disableActionButton",void 0),(0,r.Cg)([s.sH],d.prototype,"disableCancelButton",void 0),(0,r.Cg)([s.sH],d.prototype,"hideCloseButton",void 0),(0,r.Cg)([s.sH],d.prototype,"actionButtonTelemetryTag",void 0),(0,r.Cg)([s.sH],d.prototype,"cancelButtonTelemetryTag",void 0),(0,r.Cg)([s.sH],d.prototype,"closeButtonTelemetryTag",void 0),(0,r.Cg)([s.sH],d.prototype,"localizedStrings",void 0);var c=o(62047),l=o(62198),h=o(74849),u=o(64187);const p=h.A`
    ${(0,u.V)("flex")} :host{--button-border-radius:20px;--button-min-width:160px;--control-corner-radius:2px;--dialog-padding:24px;--space-above-title:20px;--space-between-buttons:8px}.dialog{--dialog-height:var(--action-dialog-height,auto);--dialog-width:var(--action-dialog-width,auto);position:absolute;z-index:var(--action-dialog-z-index,0)}.body{margin:0 var(--dialog-padding) var(--dialog-padding) var(--dialog-padding)}.button{border-radius:var(--button-border-radius);min-width:var(--button-min-width)}.button-spacer{width:var(--space-between-buttons)}.content{display:flex;flex-direction:column}.controls{display:flex;flex-direction:row;justify-content:center}.heading{display:grid;grid-template-columns:1fr auto;grid-template-rows:1;position:relative;width:100%}.heading fluent-button svg{height:12px;width:12px}.heading span{font-size:${c.t};
        font-weight: 600;
        line-height: ${l.a};
        margin-inline-start: var(--dialog-padding);
        margin-top: var(--space-above-title);
    }
`;var g=o(96950),b=o(69259),v=o(85535);const m=g.qy`<fluent-dialog @dismiss=${e=>e.dismissDialog()} class="dialog" part="dialog" aria-label="${e=>e.localizedStrings.dialogAriaText}" modal><div class="heading" part="heading"><span>${e=>e.localizedStrings.dialogHeadline}</span><fluent-button tabindex="0" title=${e=>e.localizedStrings.closeButtonTitleLabel} aria-label=${e=>e.localizedStrings.closeButtonAriaLabel} @click=${e=>e.dismissDialog()} @keypress=${e=>e.dismissDialog()} appearance="stealth" :hidden=${e=>e.hideCloseButton} data-t="${e=>e.closeButtonTelemetryTag}">${g.qy.partial(v.IE)}</fluent-button></div><div class="body" part="body"><div class="content" part="content"><slot></slot></div><div class="controls" part="controls">${(0,b.z)(e=>e.localizedStrings.actionButtonText&&e.actionButtonCallback,g.qy`<fluent-button tabindex="0" title=${e=>e.localizedStrings.actionButtonTitleLabel} aria-label=${e=>e.localizedStrings.actionButtonAriaLabel} class="button" @click=${(e,t)=>e.actionButtonCallback&&e.actionButtonCallback(t.event)} @keypress=${(e,t)=>e.actionButtonCallback&&e.actionButtonCallback(t.event)} appearance="accent" :disabled=${e=>e.disableActionButton} data-t="${e=>e.actionButtonTelemetryTag}">${e=>e.localizedStrings.actionButtonText}</fluent-button>`)} ${(0,b.z)(e=>e.localizedStrings.actionButtonText&&e.actionButtonCallback&&e.localizedStrings.cancelButtonText&&e.cancelButtonCallback,g.qy`<div class="button-spacer"></div>`)} ${(0,b.z)(e=>e.localizedStrings.cancelButtonText&&e.cancelButtonCallback,g.qy`<fluent-button tabindex="0" title=${e=>e.localizedStrings.cancelButtonTitleLabel} aria-label=${e=>e.localizedStrings.cancelButtonAriaLabel} class="button" @click=${(e,t)=>e.cancelButtonCallback&&e.cancelButtonCallback(t.event)} @keypress=${(e,t)=>e.cancelButtonCallback&&e.cancelButtonCallback(t.event)} :disabled=${e=>e.disableCancelButton} data-t="${e=>e.cancelButtonTelemetryTag}">${e=>e.localizedStrings.cancelButtonText}</fluent-button>`)}</div></div></fluent-dialog>`,f=d.compose({name:`${i.i.prefix}-action-dialog`,template:m,styles:p,shadowOptions:{delegatesFocus:!0}})},84506(e,t,o){o.d(t,{d(){return s}});var i=o(56911),r=o(92011),a=o(38493);const n="next";class s extends r.L{constructor(){super(...arguments),this.hiddenFromAT=!0,this.direction=n}keyupHandler(e){if(!this.hiddenFromAT){const t=e.key;"Enter"!==t&&"Space"!==t||this.$emit("click",e)}}}(0,i.Cg)([(0,a.CF)({mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],s.prototype,"disabled",void 0),(0,i.Cg)([(0,a.CF)({attribute:"aria-hidden",converter:a.Bs}),(0,i.Sn)("design:type",Boolean)],s.prototype,"hiddenFromAT",void 0),(0,i.Cg)([a.CF,(0,i.Sn)("design:type",String)],s.prototype,"direction",void 0)},85535(e,t,o){o.d(t,{Gp(){return n},IE(){return r},WL(){return a},fU(){return i}});const i='<svg>\n    <path\n        d="M2 7C2.14063 7 2.27083 7.02607 2.39063 7.07813C2.51041 7.1302 2.61459 7.20313 2.70313 7.29687C2.79687 7.3854 2.86979 7.4896 2.92187 7.6094C2.97396 7.7292 3 7.8594 3 8C3 8.1406 2.97396 8.2708 2.92187 8.3906C2.86979 8.5104 2.79687 8.6172 2.70313 8.71093C2.61459 8.79947 2.51041 8.8698 2.39063 8.92187C2.27083 8.97393 2.14063 9 2 9C1.85937 9 1.72917 8.97393 1.60937 8.92187C1.48959 8.8698 1.38281 8.79947 1.28906 8.71093C1.20052 8.6172 1.13021 8.5104 1.07813 8.3906C1.02604 8.2708 1 8.1406 1 8C1 7.8594 1.02604 7.7292 1.07813 7.6094C1.13021 7.4896 1.20052 7.3854 1.28906 7.29687C1.38281 7.20313 1.48959 7.1302 1.60937 7.07813C1.72917 7.02607 1.85937 7 2 7ZM8 7C8.1406 7 8.2708 7.02607 8.3906 7.07813C8.5104 7.1302 8.6146 7.20313 8.70313 7.29687C8.79687 7.3854 8.8698 7.4896 8.92187 7.6094C8.97393 7.7292 9 7.8594 9 8C9 8.1406 8.97393 8.2708 8.92187 8.3906C8.8698 8.5104 8.79687 8.6172 8.70313 8.71093C8.6146 8.79947 8.5104 8.8698 8.3906 8.92187C8.2708 8.97393 8.1406 9 8 9C7.8594 9 7.7292 8.97393 7.6094 8.92187C7.4896 8.8698 7.3828 8.79947 7.28907 8.71093C7.20053 8.6172 7.1302 8.5104 7.07813 8.3906C7.02607 8.2708 7 8.1406 7 8C7 7.8594 7.02607 7.7292 7.07813 7.6094C7.1302 7.4896 7.20053 7.3854 7.28907 7.29687C7.3828 7.20313 7.4896 7.1302 7.6094 7.07813C7.7292 7.02607 7.8594 7 8 7ZM14 7C14.1406 7 14.2708 7.02607 14.3906 7.07813C14.5104 7.1302 14.6146 7.20313 14.7031 7.29687C14.7969 7.3854 14.8698 7.4896 14.9219 7.6094C14.9739 7.7292 15 7.8594 15 8C15 8.1406 14.9739 8.2708 14.9219 8.3906C14.8698 8.5104 14.7969 8.6172 14.7031 8.71093C14.6146 8.79947 14.5104 8.8698 14.3906 8.92187C14.2708 8.97393 14.1406 9 14 9C13.8594 9 13.7292 8.97393 13.6094 8.92187C13.4896 8.8698 13.3828 8.79947 13.2891 8.71093C13.2005 8.6172 13.1302 8.5104 13.0781 8.3906C13.0261 8.2708 13 8.1406 13 8C13 7.8594 13.0261 7.7292 13.0781 7.6094C13.1302 7.4896 13.2005 7.3854 13.2891 7.29687C13.3828 7.20313 13.4896 7.1302 13.6094 7.07813C13.7292 7.02607 13.8594 7 14 7Z"\n    ></path>\n</svg>',r='<svg width="10" height="10" viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg"><path d="M5.70801 5L10 9.29199L9.29199 10L5 5.70801L0.708008 10L0 9.29199L4.29199 5L0 0.708008L0.708008 0L5 4.29199L9.29199 0L10 0.708008L5.70801 5Z"/></svg>',a='<svg width="16" height="10" viewBox="0 0 16 10" xmlns="http://www.w3.org/2000/svg"><path d="M12 3V4C12.3958 4 12.7734 4.04688 13.1328 4.14062C13.4974 4.22917 13.8177 4.375 14.0938 4.57812C14.3698 4.77604 14.5885 5.03385 14.75 5.35156C14.9167 5.66406 15 6.04688 15 6.5C15 6.84375 14.9323 7.16667 14.7969 7.46875C14.6667 7.77083 14.487 8.03646 14.2578 8.26562C14.0339 8.48958 13.7708 8.66927 13.4688 8.80469C13.1667 8.9349 12.8438 9 12.5 9H8.5C8.15625 9 7.83333 8.9349 7.53125 8.80469C7.22917 8.66927 6.96354 8.48958 6.73438 8.26562C6.51042 8.03646 6.33073 7.77083 6.19531 7.46875C6.0651 7.16667 6 6.84375 6 6.5C6 6.04688 6.08073 5.66406 6.24219 5.35156C6.40885 5.03385 6.63021 4.77604 6.90625 4.57812C7.18229 4.375 7.5 4.22917 7.85938 4.14062C8.22396 4.04688 8.60417 4 9 4V3H8.5C8.01562 3 7.5599 3.09375 7.13281 3.28125C6.71094 3.46354 6.34115 3.71354 6.02344 4.03125C5.71094 4.34375 5.46094 4.71354 5.27344 5.14062C5.09115 5.5625 5 6.01562 5 6.5C5 6.98438 5.09115 7.4401 5.27344 7.86719C5.46094 8.28906 5.71094 8.65885 6.02344 8.97656C6.34115 9.28906 6.71094 9.53906 7.13281 9.72656C7.5599 9.90885 8.01562 10 8.5 10H12.5C12.9844 10 13.4375 9.90885 13.8594 9.72656C14.2865 9.53906 14.6562 9.28906 14.9688 8.97656C15.2865 8.65885 15.5365 8.28906 15.7188 7.86719C15.9062 7.4401 16 6.98438 16 6.5C16 6.01562 15.9062 5.5625 15.7188 5.14062C15.5365 4.71354 15.2865 4.34375 14.9688 4.03125C14.6562 3.71354 14.2865 3.46354 13.8594 3.28125C13.4375 3.09375 12.9844 3 12.5 3H12ZM7 7V6C7.39583 6 7.77344 5.95573 8.13281 5.86719C8.4974 5.77344 8.81771 5.6276 9.09375 5.42969C9.36979 5.22656 9.58854 4.96875 9.75 4.65625C9.91667 4.33854 10 3.95312 10 3.5C10 3.15625 9.93229 2.83333 9.79688 2.53125C9.66667 2.22917 9.48698 1.96615 9.25781 1.74219C9.03385 1.51302 8.77083 1.33333 8.46875 1.20312C8.16667 1.06771 7.84375 1 7.5 1H3.5C3.15625 1 2.83333 1.06771 2.53125 1.20312C2.22917 1.33333 1.96354 1.51302 1.73438 1.74219C1.51042 1.96615 1.33073 2.22917 1.19531 2.53125C1.0651 2.83333 1 3.15625 1 3.5C1 3.95312 1.08073 4.33854 1.24219 4.65625C1.40885 4.96875 1.63021 5.22656 1.90625 5.42969C2.18229 5.6276 2.5 5.77344 2.85938 5.86719C3.22396 5.95573 3.60417 6 4 6V7H3.5C3.01562 7 2.5599 6.90885 2.13281 6.72656C1.71094 6.53906 1.34115 6.28906 1.02344 5.97656C0.710938 5.65885 0.460938 5.28906 0.273438 4.86719C0.0911458 4.4401 0 3.98438 0 3.5C0 3.01562 0.0911458 2.5625 0.273438 2.14062C0.460938 1.71354 0.710938 1.34375 1.02344 1.03125C1.34115 0.713542 1.71094 0.463542 2.13281 0.28125C2.5599 0.09375 3.01562 0 3.5 0H7.5C7.98438 0 8.4375 0.09375 8.85938 0.28125C9.28646 0.463542 9.65625 0.713542 9.96875 1.03125C10.2865 1.34375 10.5365 1.71354 10.7188 2.14062C10.9062 2.5625 11 3.01562 11 3.5C11 3.98438 10.9062 4.4401 10.7188 4.86719C10.5365 5.28906 10.2865 5.65885 9.96875 5.97656C9.65625 6.28906 9.28646 6.53906 8.85938 6.72656C8.4375 6.90885 7.98438 7 7.5 7H7Z" fill-opacity="0.83"/></svg>',n='<svg height="20" width="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path fill="currentcolor" d="M5.0293 19.0918L14.1113 10L5.0293 0.908203L5.9082 0.0292969L15.8887 10L5.9082 19.9707L5.0293 19.0918Z"></path></svg>'},86278(e,t,o){o.d(t,{c(){return n}});var i=o(59704),r=o(27846);function a(e,t,o){const i={};if(t.decorations){var a;const e=function(e,t){var o;if(null!==(o=t.name)&&void 0!==o&&o.includes("decorations.")){const o=t.name.replace("decorations.","");if(null!=e&&e.decorations&&e.decorations[o]){const{text:i,strikeText:r,icon:a}=e.decorations[o];return{text:i,strikeText:r,iconName:t.iconName??a}}}}(t,o);if(!e)return;const{text:r,strikeText:n,iconName:s}=e;e.text=o.disableDecorationText?null==r||null===(a=r.match(/\d+%/g))||void 0===a?void 0:a.join(""):r,i.text=o.enableMinusSign?`-${r}`:r,i.text=o.enableBrackets?`(${i.text})`:i.text,i.strikeText=n,i.iconName=s}else{if(!o.type||!o.name)return;if(i.text=function(e,t,o){if(null!=o&&o.annotationText)switch(e){case r.j.HolidayDealDecoration:return o.annotationText.holiday;case r.j.Rating:return o.annotationText.highlyRated;case r.j.CouponAnnotation:return o.annotationText.coupon;case r.j.SaveBigDecoration:return o.annotationText.saveBig;case r.j.HotDecoration:return o.annotationText.hot;default:return t.startsWith("annotationText.")&&o.annotationText?o.annotationText[t.replace("annotationText.","")]:void 0}}(o.type,o.name,t),!i.text)return;i.iconName=s(o.type)}return i.isCoupon=o.type===r.j.CouponAnnotation,i.isInsight=o.type===r.j.InsightDecoration,i.class=`shopping-decoration ${e}`,i.part=`shopping-decoration-${e}`,i.style=o.styles,i.decorationStyle=o.decorationStyle,i.hideIcon=o.hideIcon,i.disableCollapsing=o.disableCollapsing,i}function n(e,t,o,r){let n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:99;const s=new Map;if(!e||0===e.length)return s;for(const t of e)s.set(t,[]);if(!t||!o||0===o.length)return s;const d=[],c=[];o.map(e=>{e.positionPriority?d.push(e):c.push(e)}),o=d.concat(c);let l=0;o.map(e=>{const o=e.decorationPosition&&a(e.decorationPosition,t,e);var i;o&&e.decorationPosition&&s.has(e.decorationPosition)&&l<n&&(null===(i=s.get(e.decorationPosition))||void 0===i||i.push(o),l++)});let h,u,p=!1;for(const[e,t]of s){for(const[o,i]of t.entries())if("holidaydeal"===i.iconName&&(p=!0),"hot"===i.iconName&&(h=e,u=o),p&&h&&void 0!==u){var g;null===(g=s.get(h))||void 0===g||g.splice(u,1);break}if(p&&void 0!==u)break}return r&&(0,i.DR)(s),s}const s=e=>{switch(e){case r.j.HolidayDealDecoration:return"holidaydeal";case r.j.HotDecoration:return"hot";case r.j.HighlyRatedDecoration:return"highlyrated";case r.j.SaveBigDecoration:return"saveBig";case r.j.Bonsai:return"bonsai";default:return}}},88817(e,t,o){o.d(t,{m(){return A}});var i=o(56911),r=o(38493),a=o(60815),n=o(55230),s=o(92011),d=o(56863);class c extends s.L{}class l extends((0,d.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends l{constructor(){super(),this.initialValue="on",this.proxy.setAttribute("type","radio")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}defaultCheckedChanged(){this.$fastController.isConnected&&!this.dirtyChecked&&(this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}connectedCallback(){super.connectedCallback(),this.validate(),"radiogroup"!==this.parentElement?.getAttribute("role")&&null===this.getAttribute("tabindex")&&(this.disabled||this.setAttribute("tabindex","0")),this.checkedAttribute&&(this.dirtyChecked||this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}isInsideRadioGroup(){return null!==this.closest("[role=radiogroup]")}keypressHandler(e){if(e.key!==n.gG)return!0;this.checked||this.readOnly||(this.checked=!0)}clickHandler(e){this.disabled||this.readOnly||this.checked||(this.checked=!0)}}(0,i.Cg)([(0,r.CF)({attribute:"readonly",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",String)],h.prototype,"name",void 0),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",Array)],h.prototype,"defaultSlottedNodes",void 0);var u=o(37180),p=o(74849),g=o(64187),b=o(73477),v=o(60993),m=o(22131),f=o(50882),x=o(48196),$=o(74838),k=o(26920),y=o(43774),w=o(46203),C=o(7896),z=o(48751),T=o(41123),_=o(95239),S=o(14996),F=o(79288);const B=p.A`
    ${(0,g.V)("inline-flex")} :host {
        --input-size: calc((${x.D} / 2) + ${$.vR});
        align-items: center;
        outline: none;
        margin: calc(${$.vR} * 1px) 0;
        ${""} user-select: none;
        position: relative;
        flex-direction: row;
        transition: all 0.2s ease-in-out;
    }

    .control {
        position: relative;
        width: calc(var(--input-size) * 1px);
        height: calc(var(--input-size) * 1px);
        box-sizing: border-box;
        border-radius: 50%;
        border: calc(${k.XA} * 1px) solid ${y.nF};
        background: ${w.le};
        outline: none;
        cursor: pointer;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        font-family: ${C.O};
        color: ${z.l};
        ${""} padding-inline-start: calc(${$.vR} * 2px + 2px);
        margin-inline-end: calc(${$.vR} * 2px + 2px);
        cursor: pointer;
        font-size: ${T.K};
        line-height: ${T.Z};
    }

    .control,
    .checked-indicator {
        flex-shrink: 0;
    }

    .checked-indicator {
        position: absolute;
        top: 5px;
        left: 5px;
        right: 5px;
        bottom: 5px;
        border-radius: 50%;
        display: inline-block;
        background: ${z.l};
        fill: ${z.l};
        opacity: 0;
        pointer-events: none;
    }

    :host(:enabled) .control:hover {
        background: ${w.jM};
        border-color: ${y.vA};
    }

    :host(:enabled) .control:active {
        background: ${w.RS};
        border-color: ${y.p4};
    }

    :host(:${b.N}) .control {
        box-shadow: 0 0 0 2px ${_.p}, 0 0 0 4px ${S.WN};
        border-color: ${S.WN};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${v.Z};
    }

    :host([aria-checked="true"]) .checked-indicator {
        opacity: 1;
    }

    :host([disabled]) {
        opacity: ${F.q};
    }
`.withBehaviors((0,m.mr)(p.A`
            .control {
                forced-color-adjust: none;
                border-color: ${f.A.FieldText};
                background: ${f.A.Field};
            }
            :host(:enabled) .control:hover,
            .control:active {
                border-color: ${f.A.Highlight};
                background: ${f.A.Field};
            }
            :host(:${b.N}) .control {
                border-color: ${f.A.Highlight};
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([aria-checked="true"]:${b.N}:enabled) .control {
                border-color: ${f.A.Highlight};
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([aria-checked="true"]:enabled) .control:hover,
            .control:active {
                border-color: ${f.A.Highlight};
                background: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${f.A.Highlight};
                fill: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .control:hover .checked-indicator {
                background: ${f.A.HighlightText};
                fill: ${f.A.HighlightText};
            }
            :host([disabled]) {
                forced-color-adjust: none;
                opacity: 1;
            }
            :host([disabled]) .label {
                color: ${f.A.GrayText};
            }
            :host([disabled]) .control,
            :host([aria-checked="true"][disabled]) .control:hover,
            .control:active {
                background: ${f.A.Field};
                border-color: ${f.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                fill: ${f.A.GrayText};
                background: ${f.A.GrayText};
            }
        `));var L=o(96950),I=o(82774),H=o(79109),M=o(18893);const P=function(e={}){return L.qy`
        <template
            role="radio"
            aria-checked="${e=>e.checked}"
            aria-required="${e=>e.required}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <div part="control" class="control">
                <slot name="checked-indicator">
                    ${(0,M.R)(e.checkedIndicator)}
                </slot>
            </div>
            <label
                part="label"
                class="${e=>["label",!e.defaultSlottedNodes?.length&&"label__hidden"].filter(Boolean).join(" ")}"
            >
                <slot
                    ${(0,I.e)({property:"defaultSlottedNodes",filter:H.g})}
                ></slot>
            </label>
        </template>
    `}({checkedIndicator:L.qy`
        <div part="checked-indicator" class="checked-indicator"></div>
    `}),A=h.compose({name:`${u.c.prefix}-radio`,template:P,styles:B})},96849(e,t,o){o.d(t,{M(){return s},h(){return n}});var i=o(74849),r=o(36452);const a=i.A` .hide-card{display:none;position:absolute;top:8px;right:8px;background-color:#ffff;border:1px solid ${r.Ez};
        cursor: pointer;
        border-radius: 100%;
        justify-content: center;
        align-items: center;
        width: 32px;
        height: 32px;
        padding: 0;
        font-size: var(--type-ramp-base-font-size);
        line-height: var(--type-ramp-base-line-height);
        z-index: 6;
    }

    .hide-card:hover{
        background-color: #f2f2f2;
        border: 1px solid ${r.U7}}.hide-card:active{background-color:#f7f7f7;border:1px solid ${r.IH}}.shopping-product-card:hover .hide-card,.shopping-special-event-wrapper:hover .hide-card{display:flex}.check-icon{display:flex;flex-direction:column;justify-content:center;align-items:center;fill:var(--neutral-foreground-rest);padding-top:20px;padding-bottom:32px;text-align:center}:host(.hiding:not(.shopping-grouped-item)){margin-inline-start:calc((var(--scroll-item-spacing,12px) + var(--item-width,220px)) * -1) !important;opacity:0;margin-left:calc((var(--scroll-item-spacing,12px) + var(--item-width,220px)) * -1);transform:scale(0);transition:transform var(--shopping-card-hide-transform-time,500ms) ease-in-out,opacity var(--shopping-card-hide-transform-time,500ms) ease-in-out,margin-left var(--shopping-card-hide-margin-time,800ms) ease-in-out,margin-inline-start var(--shopping-card-hide-margin-time,800ms) ease-in-out;-webkit-transition:transform var(--shopping-card-hide-transform-time,500ms) ease-in-out,opacity var(--shopping-card-hide-transform-time,500ms) ease-in-out,margin-left var(--shopping-card-hide-margin-time,800ms) ease-in-out,margin-inline-start var(--shopping-card-hide-margin-time,800ms) ease-in-out}:host(.hiding.first-item:not(.shopping-grouped-item)){margin-inline-start:calc((var(--scroll-item-spacing,12px) + var(--item-width,220px)) * -1 + var(--scroll-item-spacing,12px)) !important}:host(.hidden){display:none}.cross-icon{width:20px;height:20px}`,n=i.A`
    ${a} msn-hide-story-card.hide-shopping-card::part(heading){white-space:pre-line;font-size:var(--heading-font-size,var(--type-ramp-base-font-size));line-height:var(--heading-line-height,var(--type-ramp-base-line-height));-webkit-line-clamp:var(--heading-max-lines,3)}msn-hide-story-card fluent-menu-item::part(control){width:100%}msn-hide-story-card.hide-feedback::part(content-region){margin:0 auto;text-align:center;justify-content:center;--content-region-padding-top:38px}.menu-item-text{margin-top:5px;padding:0 8px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.hide-action-button{text-align:center;display:block;border-radius:20px;margin:0 auto 8px;font-size:var(--hide-card-button-size,var(--type-ramp-minus-1-font-size))}`,s=i.A`
.hide-action-button.stealth-button:hover{background:#2b2b2b}`}}]);