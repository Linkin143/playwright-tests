"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-event-brief"],{4968(e,t,r){r.d(t,{f(){return s}});var i=r(64187),a=r(74849),o=r(42792),n=r(99657),l=r(36452);const s=a.A.partial`position: relative; z-index: ${n.D};`;a.A`
    ${o.e}
    ${o.nH}

    ${(0,i.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${s}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},42792(e,t,r){r.d(t,{R7(){return b},e(){return h},kc(){return f},nH(){return p}});var i=r(57416),a=r(55153),o=r(95239),n=r(26920),l=r(48751),s=r(64187),d=r(22131),c=r(74849),g=r(50882);const p=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,s.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${n.XA} * 1px) solid ${a.cu};
        border-radius: calc((${i.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${l.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,f=(0,d.mr)(c.A`
            :host {
                background: ${g.A.Canvas};
                color: ${g.A.CanvasText};
            }
        `),b=c.A`
    ${h}
    ${p}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(f)},70697(e,t,r){r.r(t),r.d(t,{SportsEventBrief(){return w}});var i=r(56911),a=r(92079);class o extends a.a{}var n=r(92011),l=r(4968),s=r(74849),d=r(48751);const c=s.A` .event-brief-content{color:${d.l};
        display: grid;
        grid-template-rows: 1fr auto auto;
        row-gap: 6px;
        height: 100%;
        box-sizing: border-box;
        ${l.f} text-decoration:none}._1x_1y.event-brief-content{grid-template-columns:auto 56px;gap:12px;grid-template-rows:none;align-items:center}._1x_2y.event-brief-content{padding-bottom:4px}._1x_3y.event-brief-content{padding-bottom:16px}.event-brief-small-content{display:flex;flex-direction:column;gap:6px;max-width:200px}.event-name{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow:hidden;text-overflow:ellipsis;height:fit-content;text-decoration:none;color:${d.l};
        ${l.f}}._1x_1y .event-name{font-weight:600;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);-webkit-line-clamp:1}._1x_2y .event-name{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600}._1x_3y .event-name{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px);font-weight:600;-webkit-line-clamp:3}._1x_3y .event-publisher{margin-top:26px}._1x_2y .event-publisher{margin-top:6px}.event-related-stories{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.event-brief-image{max-height:100%;overflow:hidden}.event-brief-image img{width:100%;height:100%;max-width:100%;border-radius:8px;object-fit:cover}._1x_1y .event-brief-image{max-height:56px}._1x_1y .event-brief-image img{height:56px}.event-publisher.no-pimg{grid-template-columns:auto}.event-publisher{display:grid;grid-template-columns:16px auto;gap:8px;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.event-publisher img{width:16px;height:16px;max-width:16px;border-radius:2px}.event-publisher .publisher-info{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ai-generated{.event-publisher{gap:6px;margin-top:10px;grid-template-columns:min-content auto}.event-brief-image{max-height:124px}.event-name{-webkit-line-clamp:3}.publisher-icons{display:flex;flex-direction:row-reverse;img:not(:last-child){position:relative;margin-inline-start:-2px}}}.ai-generated.event-brief-content{grid-template-rows:unset;height:auto}`;var g=r(96950),p=r(69259),h=r(39957);const f=g.qy`
    <div class="event-brief-image">
        <img src="${e=>e.viewModel.eventImageUrl}" alt="">
    </div>
`,b=g.qy`
    <div class="event-publisher 
        ${e=>{var t;return null!==(t=e.viewModel.publisherIconUrls)&&void 0!==t&&t.length?"":"no-pimg"}}
    ">
        ${(0,p.z)(e=>{var t;return null===(t=e.viewModel.publisherIconUrls)||void 0===t?void 0:t.length},g.qy`
            <div class="publisher-icons">
                ${(0,h.ux)(e=>(e.viewModel.publisherIconUrls||[]).reverse(),g.qy`<img src="${e=>e}" alt=""/>`)}
            </div>
        `)}
        <span class="publisher-info">${e=>e.viewModel.publisherInfoText}</span>
    </div>
    <a class="event-name"
        href="${e=>e.viewModel.destinationUrl}"
        title="${e=>e.viewModel.eventName}"
        target="_blank"
        data-t="${e=>e.viewModel.articleTelemetryTag}"
    >
        ${e=>e.viewModel.eventName}
    </a>
`,u=g.qy`
    <div class="event-related-stories">
        ${e=>e.viewModel.relatedStoriesText}
    </div>
`,v=g.qy`
    <div class="event-brief-small-content">
        ${b}
        ${u}
    </div>
    ${f}
`,x=g.qy`
    ${f}
    ${b}
    ${(0,p.z)(e=>"_1x_1y"!==e.viewModel.cardSize&&e.viewModel.relatedStoriesText,u)}
`,m=g.qy`
    <a class="event-brief-content ${e=>e.viewModel.cardSize} ${e=>e.viewModel.isAiGenerated?"ai-generated":""}"
        href="${e=>e.viewModel.tabClickThroughUrl}"
        title="${e=>e.viewModel.eventName}"
        target="_blank"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        ${e=>"_1x_1y"===e.viewModel.cardSize?v:x}
    </a>
`,$=g.qy`
    ${(0,p.z)(e=>null!=e.viewModel,m)}
`;let w=class extends o{};w=(0,i.Cg)([(0,n.E)({name:"sports-event-brief",template:$,styles:c,shadowOptions:{delegatesFocus:!0}})],w)},71603(e,t,r){r.r(t),r.d(t,{SportsEventBriefTransformer(){return l}});var i=r(23587),a=r(79811),o=r(96950),n=r(50180);class l extends i.Bc{async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,a.jJ)();const r=this.getCurrentViewModel(e);return{viewTemplate:o.qy`
                <sports-event-brief
                    :viewModel="${r}"
                ></sports-event-brief>`}}getNewsDetails(e){var t;return null===(t=e.eventBriefData.newsDetails.newsList)||void 0===t?void 0:t[0]}getDestinationUrl(e,t){if(t&&e.tabClickThroughUrl)return(0,a.Ot)(e.tabClickThroughUrl);const r=this.getNewsDetails(e);return(0,a.Ot)((null==r?void 0:r.url)||"")}getPublisherIconUrls(e,t){const r=e.eventBriefData.newsDetails.newsList;var i;if(!t)return null!=r&&null!==(i=r[0])&&void 0!==i&&i.providerLogoUrl?[r[0].providerLogoUrl]:[];return((null==r?void 0:r.map(e=>e.providerLogoUrl).filter(e=>Boolean(e)))||[]).slice(0,3)}getCurrentViewModel(e){const{telemetryBuilder:t,strings:r}=this.transformerProvider,{eventBriefData:o,tabClickThroughUrl:l}=e,s=this.getNewsDetails(e),d=Boolean(o.sourceDisclaimer),c=this.getDestinationUrl(e,d),g=d?"":(0,n.GP)(r.relatedStories||"",o.numberOfNews||""),p=d?`+${o.numberOfNews} · ${o.sourceDisclaimer}`:null==s?void 0:s.providerName;return{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,relatedStoriesText:g,articleTelemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.EventBriefClick}),telemetryTag:t.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:i.BP.EventBriefContentClick}),eventImageUrl:(null==s?void 0:s.imageUrl)||"",eventName:(null==s?void 0:s.title)||"",destinationUrl:c,tabClickThroughUrl:l?(0,a.Ot)(l):c,eventLevel:o.eventLevel,publisherIconUrls:this.getPublisherIconUrls(e,d),publisherInfoText:p||"",isAiGenerated:d}}}Promise.resolve().then(r.bind(r,70697))},92079(e,t,r){r.d(t,{a(){return n}});var i=r(56911),a=r(92011),o=r(31525);let n=class extends a.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,i.Cg)([o.x],n)},99657(e,t,r){r.d(t,{D(){return n},I(){return o}});var i=r(45755);const{create:a}=i.G,o=a("sloppy-click-z-index",1),n=a("click-z-index",1)}}]);