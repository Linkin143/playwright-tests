(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["community-active-discussions"],{4968(e,t,i){"use strict";i.d(t,{f(){return s}});var r=i(64187),o=i(74849),a=i(42792),n=i(99657),l=i(36452);const s=o.A.partial`position: relative; z-index: ${n.D};`;o.A`
    ${a.e}
    ${a.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${s}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(a.kc)},7318(e){e.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M10.58 10l.05.45a11 11 0 01-.02 2.68c-.07.44-.2.88-.44 1.23-.25.38-.64.64-1.17.64-.52 0-.83-.37-1.02-.7-.2-.31-.36-.75-.54-1.2l-.01-.03c-.55-1.4-1.3-3.31-3.3-4.65-.31-.2-.6-.36-.86-.46-.7-.3-1.32-1.06-1.16-1.94l.23-1.2a2 2 0 011.43-1.55l4.95-1.38a3.5 3.5 0 014.37 2.73l.46 2.42A2.5 2.5 0 0111.09 10h-.51zm1.53-5.2a2.5 2.5 0 00-3.13-1.94L4.03 4.23a1 1 0 00-.71.78l-.22 1.2c-.06.28.16.66.55.82.31.13.66.31 1.03.55 2.28 1.53 3.13 3.7 3.67 5.11l.01.02c.2.5.33.85.47 1.08A.73.73 0 009 14c.14 0 .25-.05.35-.2.12-.18.22-.46.28-.83a10.06 10.06 0 00-.08-3.12l-.03-.2-.01-.05V9.6A.5.5 0 0110 9h1.09a1.5 1.5 0 001.47-1.78l-.45-2.42z"></path></svg>'},10814(e){e.exports='<svg width="48" height="48" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><path d="M4 24a20 20 0 1140 0 20 20 0 01-40 0zm19.87-8.63a1.25 1.25 0 000 1.76l5.61 5.62H15.25a1.25 1.25 0 100 2.5h14.23l-5.61 5.62a1.25 1.25 0 001.76 1.76l7.75-7.75c.5-.48.5-1.28 0-1.76l-7.75-7.75a1.25 1.25 0 00-1.76 0z"></path></svg>'},20966(e,t,i){"use strict";i.r(t),i.d(t,{CommentActivityTransformer(){return n}});var r=i(50130),o=i(51006),a=i(96950);class n extends r.B{async transform(e){const t=await this.getCurrentViewModel(e);return{viewTemplate:a.qy`
                <community-active-discussions
                    :viewModel="${t}"
                ></community-active-discussions>`}}async getCurrentViewModel(e){var t,i,r,a,n;const l=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{name:null==e||null===(t=e.telemetryObject)||void 0===t||null===(t=t.contract)||void 0===t?void 0:t.name,signature:null==e||null===(i=e.telemetryObject)||void 0===i||null===(i=i.contract)||void 0===i||null===(i=i.ext)||void 0===i?void 0:i.signature,headline:null==e||null===(r=e.telemetryObject)||void 0===r||null===(r=r.contract)||void 0===r||null===(r=r.content)||void 0===r?void 0:r.headline});return{...(0,o.aZ)(e,null===(a=this.transformerProvider)||void 0===a?void 0:a.strings,(null===(n=this.transformerProvider)||void 0===n||null===(n=n.config)||void 0===n?void 0:n.showUserComments)??!1),cardSize:e.cardSize,experienceName:e.experienceName,telemetryTag:l}}}Promise.resolve().then(i.bind(i,47915))},44932(e,t,i){"use strict";i.d(t,{D(){return n}});var r=i(56911),o=i(60815),a=i(92011);class n extends a.L{}(0,r.Cg)([o.sH],n.prototype,"viewModel",void 0)},47915(e,t,i){"use strict";i.r(t),i.d(t,{CommunityActiveDiscussions(){return D}});var r=i(56911),o=i(44932),a=i(60815);class n extends o.D{}(0,r.Cg)([a.sH],n.prototype,"viewModel",void 0);var l=i(92011),s=i(48751),d=i(86856),v=i(4968),p=i(12640),c=i(74849);const u=c.A` .post-container,.comments-container,.user-profile-container{background:var(--backplate-default,rgba(255,255,255,0.06))}`,g=c.A` .post-social-bar div{padding-right:8px}.post-social-bar span{padding-left:4px}`,h=c.A` .post-social-bar div{padding-left:8px}.post-social-bar span{padding-right:4px}`,x=c.A` a,a:hover,a:active,a:visited{color:${s.l};text-decoration:none;cursor:pointer}.active-comments-container{color:${s.l};width:268px;display:flex;position:absolute;flex-direction:column;justify-content:space-between;transition:left 700ms,right 700ms;gap:16px}.notif-text{color:${s.l};
        text-decoration: none;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        overflow: hidden;
        text-overflow: ellipsis;
        margin: 8px 0;
        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
        cursor: pointer;
        ${v.f}}.post-container{color:${s.l};text-decoration:none;display:flex;flex-direction:column;align-items:flex-start;border-radius:8px;background:var(--color-neutral-background-alpha-1-rest,rgba(255,255,255,0.50));padding:12px;gap:12px}.post-header{display:flex;gap:8px}.post-content{display:flex;flex-direction:column;gap:8px}.post-attr{display:flex;font-size:12px;font-weight:400;line-height:16px;gap:4px}.post-attr-name{text-overflow:ellipsis;overflow:hidden;max-width:100px;white-space:nowrap;cursor:pointer;${v.f}}.post-attr img{width:16px;height:16px;border-radius:2px}.post-title{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;text-overflow:ellipsis;font-size:14px;font-style:normal;font-weight:600;line-height:20px;cursor:pointer;height:65px;${v.f}}.post-image img{width:80px;height:80px;border-radius:9.697px;object-fit:cover}.post-social-bar{display:flex;align-items:center;font-weight:400;font-size:12px;line-height:16px;color:${s.l};
        fill: ${s.l}}.post-social-bar div{display:flex;align-items:center}.comments-container{color:${s.l};text-decoration:none;display:flex;flex-direction:column;align-items:flex-start;border-radius:8px;background:var(--color-neutral-background-alpha-1-rest,rgba(255,255,255,0.50));padding:12px;gap:8px}.comment-attr{display:flex;align-items:center;font-size:12px;font-weight:400;line-height:16px;gap:4px}.comment-attr-name{text-overflow:ellipsis;overflow:hidden;max-width:180px;font-weight:600;white-space:nowrap;cursor:pointer;${v.f}}.comment-attr img{width:16px;height:16px;border-radius:40px}.comment-attr svg{fill:currentColor}.comment-text{color:${s.l};
        text-decoration: none;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 3;
        overflow: hidden;
        text-overflow: ellipsis;
        align-items: center;
        font-size: 14px;
        font-weight: 400;
        line-height: 20px;
        cursor: pointer;
        height: 60px;
        ${v.f}}.comments-footer{display:flex;align-items:center;gap:4px;padding-top:8px}.comments-footer img{width:16px;height:16px;border-radius:2px}.article-title{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;overflow:hidden;text-overflow:ellipsis;font-size:14px;font-style:normal;font-weight:600;line-height:20px;cursor:pointer;${v.f}}.user-profile-container{width:268px;display:flex;align-items:center;justify-content:space-between;transition:left 700ms,right 700ms;height:-webkit-fill-available;border-radius:8px;background:var(--color-neutral-background-alpha-1-rest,rgba(255,255,255,0.50))}.user-profile-content{color:${s.l};text-decoration:none;display:flex;flex-direction:column;padding:0px 47px;align-items:center;gap:10px}.user-profile-content svg{fill:currentColor}.profile-nav-text{text-align:center;font-size:14px;font-style:normal;font-weight:400;line-height:20px;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:4;overflow:hidden;text-overflow:ellipsis}`.withBehaviors(new p.N(null,u),new d.t(g,h));var m=i(96950),f=i(69259),w=i(98967),b=i.n(w),$=i(7318),y=i.n($),k=i(88834),z=i.n(k),A=i(10814),M=i.n(A),_=i(83091),C=i.n(_),B=i(74104);const j=m.qy`<div class="comments-container"><div class="comment-attr">${(0,f.z)(e=>{var t;return e.viewModel.topComments&&(null===(t=e.viewModel.topComments[0])||void 0===t?void 0:t.userAvatarUrl)},m.qy`<img src=${e=>{var t;return e.viewModel.topComments&&(null===(t=e.viewModel.topComments[0])||void 0===t?void 0:t.userAvatarUrl)}}>`,m.qy`${m.qy.partial(C())}`)}<a class="comment-attr-name" href=${e=>e.viewModel.clickThroughUrl} target="_blank" rel="noopener noreferrer" title=${e=>{var t,i;return e.viewModel.topComments&&`${null===(t=e.viewModel.topComments[0])||void 0===t?void 0:t.userFirstName} ${null===(i=e.viewModel.topComments[0])||void 0===i?void 0:i.userLastName}`}} data-t=${e=>e.viewModel.telemetryTag}>${e=>{var t,i;return e.viewModel.topComments&&`${null===(t=e.viewModel.topComments[0])||void 0===t?void 0:t.userFirstName} ${null===(i=e.viewModel.topComments[0])||void 0===i?void 0:i.userLastName}`}}</a>${(0,f.z)(e=>{var t;return e.viewModel.topComments&&(null===(t=e.viewModel.topComments[0])||void 0===t?void 0:t.commentDateTime)},m.qy`<span>·</span>`)}<span>${e=>{var t;return e.viewModel.topComments&&(null===(t=e.viewModel.topComments[0])||void 0===t?void 0:t.commentDateTime)}}</span></div><a class="comment-text" href=${e=>e.viewModel.clickThroughUrl} target="_blank" rel="noopener noreferrer" title=${e=>{var t;return e.viewModel.topComments&&(null===(t=e.viewModel.topComments[0])||void 0===t?void 0:t.commentText)}} data-t=${e=>e.viewModel.telemetryTag}>${e=>{var t;return e.viewModel.topComments&&(null===(t=e.viewModel.topComments[0])||void 0===t?void 0:t.commentText)}}</a><div class="comments-footer">${(0,f.z)(e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.logoUrl},m.qy`<img src=${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.logoUrl}}>`)}<a class="article-title" href=${e=>e.viewModel.clickThroughUrl} target="_blank" rel="noopener noreferrer" title=${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.title}} data-t=${e=>e.viewModel.telemetryTag}>${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.title}}</a></div></div>`,H=m.qy`<div class="post-container"><div class="post-header"><div class="post-content"><div class="post-attr">${(0,f.z)(e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.logoUrl},m.qy`<img src=${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.logoUrl}}>`)}<a class="post-attr-name" href=${e=>e.viewModel.clickThroughUrl} target="_blank" rel="noopener noreferrer" title=${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.publisherName}} data-t=${e=>e.viewModel.telemetryTag}>${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.publisherName}}</a>${(0,f.z)(e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.publishedDateTime},m.qy`<span>·</span>`)}<span>${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.publishedDateTime}}</span></div><a class="post-title" href=${e=>e.viewModel.clickThroughUrl} target="_blank" rel="noopener noreferrer" title=${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.title}} data-t=${e=>e.viewModel.telemetryTag}>${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.title}}</a></div>${(0,f.z)(e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.imageUrl},m.qy`<div class="post-image"><img src=${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.imageUrl}}></div>`)}</div><div class="post-social-bar"><div>${m.qy.partial(z())}<span>${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.totalLikesCount}}</span></div><div>${m.qy.partial(y())}<span>${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.totalDislikesCount}}<span></div><div>${m.qy.partial(b())}<span>${e=>{var t;return null===(t=e.viewModel.article)||void 0===t?void 0:t.totalCommentsCount}}<span></div></div></div>`,L=m.qy`<div class="active-comments-container"><a class="notif-text" href=${e=>e.viewModel.clickThroughUrl} target="_blank" rel="noopener noreferrer" title=${e=>e.viewModel.activityNotificationText} data-t=${e=>e.viewModel.telemetryTag}>${e=>e.viewModel.activityNotificationText}</a>${(0,f.z)(e=>e.viewModel.reactionOnlyActivity,H,j)}</div>`,T=m.qy`<div class="user-profile-container"><a class="user-profile-content" href=${e=>e.viewModel.clickThroughUrl} target="_blank" rel="noopener noreferrer" data-t=${e=>e.viewModel.telemetryTag}>${m.qy.partial(M())}<div class="profile-nav-text">${e=>e.viewModel.userProfileNavText}</div></a></div>`,V=m.qy` ${(0,f.z)(e=>void 0!==e.viewModel&&null!==e.viewModel,m.qy` ${e=>e.viewModel.tabType===B.jR.UserProfile?T:L} `)}
`;let D=class extends n{};D=(0,r.Cg)([(0,l.E)({name:"community-active-discussions",template:V,styles:x,shadowOptions:{delegatesFocus:!0}})],D)},83091(e){e.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M8 7a2 2 0 114 0 2 2 0 01-4 0zm-.5 3h5c.83 0 1.5.67 1.5 1.5 0 1.12-.46 2.01-1.21 2.61-.74.6-1.74.89-2.79.89a4.43 4.43 0 01-2.79-.89A3.25 3.25 0 016 11.5c0-.83.67-1.5 1.5-1.5zM10 2a8 8 0 100 16 8 8 0 000-16zm-7 8a7 7 0 1114 0 7 7 0 01-14 0z"></path></svg>'},88834(e){e.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M8.03 1.92c.21-.52.8-1.08 1.55-.87.6.17.97.52 1.2 1 .2.44.25.96.26 1.46a7.5 7.5 0 01-.24 1.74c-.06.26-.12.51-.19.74h1.38a2 2 0 011.92 2.56l-1.36 4.65a2.5 2.5 0 01-3.15 1.68L4.05 13.2A2 2 0 012.77 12l-.52-1.4a2 2 0 01.86-2.42l1.87-1.1.02-.01.1-.09c.1-.07.23-.2.4-.4.35-.39.82-1.03 1.3-2.04.2-.44.37-.78.53-1.1.25-.5.46-.92.7-1.52zm-2.51 6l-.02.01-1.88 1.11a1 1 0 00-.43 1.22l.52 1.38a1 1 0 00.64.6l5.35 1.68c.8.26 1.65-.2 1.89-1l1.36-4.65A1 1 0 0012 6.99H9.93a.5.5 0 01-.48-.67c.1-.28.26-.77.38-1.3.13-.54.22-1.08.2-1.5 0-.46-.05-.8-.16-1.05a.78.78 0 00-.56-.45c-.04-.02-.1-.01-.16.03a.54.54 0 00-.19.25c-.25.63-.5 1.11-.76 1.65-.16.3-.32.63-.5 1.01a9.52 9.52 0 01-1.45 2.28 5.06 5.06 0 01-.7.66l-.02.01-.01.01zm-.54-.84z"></path></svg>'},98967(e){e.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M1 4.5A2.5 2.5 0 013.5 2h9A2.5 2.5 0 0115 4.5v5a2.5 2.5 0 01-2.5 2.5H8.69l-3.06 2.68A.98.98 0 014 13.94V12h-.5A2.5 2.5 0 011 9.5v-5zM3.5 3C2.67 3 2 3.67 2 4.5v5c0 .83.67 1.5 1.5 1.5H5v2.9L8.31 11h4.19c.83 0 1.5-.67 1.5-1.5v-5c0-.83-.67-1.5-1.5-1.5h-9z"></path></svg>'}}]);