"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-medal-v2"],{4968(e,t,r){r.d(t,{f(){return d}});var i=r(64187),a=r(74849),o=r(42792),n=r(99657),l=r(36452);const d=a.A.partial`position: relative; z-index: ${n.D};`;a.A`
    ${o.e}
    ${o.nH}

    ${(0,i.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${d}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},17471(e,t,r){r.r(t),r.d(t,{SportsTable(){return T}});var i=r(56911),a=r(92011),o=r(48751),n=r(62047),l=r(41123),d=r(61138),s=r(86856),c=r(74849),p=r(22131),g=r(4968),h=r(12640);const x=c.A` .table-card{color:rgba(255,255,255,1)}.card-header{color:rgba(255,255,255,1)}.card-header-tag{box-shadow:inset 0px 0px 0px 2px rgba(255,153,164,1)}.card-header-tag >span:nth-of-type(1){background:rgba(255,153,164,1);color:rgba(68,39,38,1)}.card-header-tag >span:nth-of-type(2){background:rgba(68,39,38,1);color:rgba(255,153,164,1)}.table-cell{border-top:1px solid rgba(255,255,255,0.07)}.no-border{border-top:none}.underlay{opacity:0.16}`,u=c.A` .line >img{margin-left:2px}.line >img.extra-margin{margin-left:4px}.line{padding-right:0px;padding-left:4px}.head-cell{padding-right:0px;padding-left:4px}.card-header-tag >span:nth-of-type(2){border-top-right-radius:0;border-bottom-right-radius:0;border-top-left-radius:3px;border-bottom-left-radius:3px}`,f=c.A` .table-container{text-decoration:none}.clickable{${g.f}}.table-card{margin-top:8px;width:268px;height:fit-content;background:none;color:${o.l};border-radius:8px;padding:8px 12px;box-sizing:border-box}.table-card.fill-card{margin-top:0px;padding:0px 12px;background:inherit}.card-header{display:flex;justify-content:space-between;align-items:baseline;padding:0 0 8px;color:${o.l}}.card-header >div{display:flex;font-size:12px;font-weight:600}.card-header-tag{height:18px;line-height:${n.e};box-shadow:inset 0px 0px 0px 4px rgba(196,43,28,1);border-radius:4px;padding:2px 2px;box-sizing:border-box}.card-header-tag >span{display:inline-block;font-size:${n.t};font-weight:600;box-sizing:border-box;padding:0px 2px}.card-header-tag >span:nth-of-type(1){background:rgba(196,43,28,1);color:rgba(255,255,255,1)}.card-header-tag >span:nth-of-type(2){background:rgba(255,255,255,1);color:rgba(196,43,28,1);border-top-right-radius:3px;border-bottom-right-radius:3px}.grid-table{display:grid;width:244px;grid-template-columns:minmax(20px,auto) 1fr minmax(auto,42px) minmax(auto,70px);grid-template-rows:repeat(9,28px)}.table-cell{position:relative;border-top:1px solid rgba(0,0,0,0.06);display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.line{font-size:${n.t};font-style:normal;font-weight:400;display:flex;align-items:center;padding:0 4px 0 0;width:100%;z-index:1}.line.large-font{font-size:${l.K}}.line > div{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.pre-text{font-size:${n.t};font-weight:600;width:14px;min-width:14px;padding-right:6px}.pre-text.large-font{font-size:${l.K};font-weight:400;width:16px}.head-cell{white-space:nowrap;text-overflow:ellipsis;overflow:hidden;border-top:1px solid rgba(0,0,0,0.06);font-size:${d.k};font-style:normal;font-weight:600;display:flex;align-items:center;padding:0 4px 0 0}.hidden{display:none}.no-border{border-top:none}.overflow{overflow:visible}.line > sup{margin:0 0 4px 1px}.right{justify-content:end}.center{justify-content:center}.left{justify-content:start}.top{align-items:flex-start}.middle{align-items:center}.bottom{align-items:flex-end}.bold{font-weight:600}.line > img{margin-right:2px;height:16px;width:16px}.line > img.extra-margin{margin-right:4px}.iconround > img{border-radius:50%}img.icon-20{height:20px;width:20px;min-width:20px}.line > img.icon-24{height:24px;width:24px;min-width:24px}.font-xs{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.font-s{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.font-m{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.font-l{font-size:var(--smtc-text-ramp-lg-item-body-font-size,16px);line-height:var(--smtc-text-ramp-lg-item-body-line-height,26px)}.align-right{justify-content:flex-end;padding-right:0}.secondary{color:var(--smtc-foreground-ctrl-neutral-secondary-rest,#4c4642)}.underlay{position:absolute;top:-2px;height:calc(100% + 4px);width:100%;background:#0178A7;opacity:0.08}.first-column .underlay{border-radius:12px 0px 0px 12px;width:calc(100% + 4px);left:-4px}.last-column .underlay{border-radius:0px 12px 12px 0px}.no-padding .line,.no-padding .head-cell{padding:0px}.full-width .table-card{width:100%}.cplt .table-card{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320)}`.withBehaviors(new s.t(null,u),new h.N(null,x),(0,p.mr)(c.A` :host{forced-color-adjust:auto}`));var b=r(96950),v=r(39957),m=r(69259);const $=b.qy`
    ${e=>void 0!==e.viewModel.data.title?b.qy`
        <div class="card-header" style="${e=>e.viewModel.headerStyles}">
            <div style="${e=>e.viewModel.data.titleStyles}">${e=>e.viewModel.data.title}</div>
            ${e=>void 0!==e.viewModel.data.subTitle?b.qy`
                <div class="card-header-tag">
                    <span>${e=>e.viewModel.data.tagName}</span>
                    <span>${e=>e.viewModel.data.subTitle}</span>
                </div>`:""}
            ${e=>void 0!==e.viewModel.data.subTitleText?b.qy`
                <div style="${e=>e.viewModel.data.subTitleStyles}">
                    <span>${e=>e.viewModel.data.subTitleText}</span>
                </div>`:""}
        </div>
    `:""}
`,y=b.qy`
    ${(0,v.ux)(e=>e.getHeaderValues(),b.qy`
        <div class="head-cell ${e=>void 0!==e.class?e.class:""}" style="${e=>e.textStyles}">
            ${e=>void 0!==e.icon?b.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null}"
            />`:""}
            ${e=>e.value}
        </div>
    `)}
`,w=b.qy`
    ${(0,v.ux)(e=>e.getAllBodyCells(),()=>b.qy`
    <div class="table-cell ${e=>void 0!==e.cellClass?e.cellClass:""}">
        ${e=>e.isHightlighted?b.qy`<div class="underlay"></div>`:""}
        <div class="line ${e=>void 0!==e.class?e.class:""}">
            ${e=>void 0!==e.preText?b.qy`<div class="pre-text ${e=>void 0!==e.preTextClass?e.preTextClass:""}" style="${e=>e.preTextStyles}">${e.preText}</div>`:""}
            ${e=>void 0!==e.icon?b.qy`<img
                role="presentation"
                src="${e=>e.icon}"
                class="${e=>void 0!==e.iconClass?e.iconClass:null} ${e=>e.icon?"":"hidden"}"
                onerror="this.style.display='none'"
            />`:""}
            ${e=>b.qy`<div style="${e=>e.textStyles}" title=${e=>e.value}>${e.value}</div>`}
            ${e=>void 0!==e.index?b.qy`<sup>${e.index}</sup>`:""}
        </div>
        <div class="line ${e=>void 0!==e.classL2?e.classL2:""}">
            ${e=>b.qy`<div>${e.valueL2}</div>`}
        </div>
    </div>
`)}
`,z=b.qy`
    <a
        class="${e=>e.viewModel.clickThroughUrl?"clickable":""} table-container ${e=>e.viewModel.tableClass}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="${e=>e.viewModel.clickThroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}" 
    >
        ${e=>e.viewModel.isHeaderAboveTheTable?$:""}
        <div
            class="table-card ${e=>e.viewModel.fillFullCard?"fill-card":""}"
            style="${e=>e.viewModel.tableStyles}"
        >
            ${e=>e.viewModel.isHeaderAboveTheTable?"":$}
            <div class="grid-table"
                style="${e=>`\n                    grid-template-columns: ${e.viewModel.columnStyle};\n                    grid-template-rows: ${e.viewModel.rowStyle};\n                    ${e.viewModel.gridStyles};\n                `}">
                ${e=>e.getHeaderValues().length>0?y:""}
                ${w}
            </div>
        </div>
    </a>
`,k=b.qy`
    ${(0,m.z)(e=>null!=e.viewModel,z)}
`;var S=r(92079);class M extends S.a{constructor(){super(...arguments),this.getKeys=()=>this.viewModel.data.keys,this.getHeaderValues=()=>{const{header:e}=this.viewModel.data;return e?this.getKeys().map(t=>e[t]):[]},this.isLarge=()=>"_1x_3y"===this.viewModel.cardSize,this.getAllBodyCells=()=>{const e=[],t=this.getKeys();return this.viewModel.data.body.forEach(r=>{t.forEach(t=>e.push(r[t]))}),e}}}let T=class extends M{};T=(0,i.Cg)([(0,a.E)({name:"sports-table",template:k,styles:f,shadowOptions:{delegatesFocus:!0}})],T)},24670(e,t,r){r.r(t),r.d(t,{SportsInfoMedalCountV2(){return f}});var i=r(56911),a=r(84564);class o extends a.z{}var n=r(92011),l=r(74849),d=r(12640),s=r(4968);const c=l.A` .logo{filter:invert(100%)}`,p=l.A` :host{height:100%;container-type:inline-size}.wrap{display:flex;flex-direction:column;height:100%;padding:11px;box-sizing:border-box;color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320)}.event-info{padding:20px 12px 4px 20px}.medal-table{width:100%;padding:20px;box-sizing:border-box;display:flex;flex-direction:column;flex-grow:1}.upd-text{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);padding:4px 2px}.header-text{font-size:var(--smtc-text-global-title2-font-size,20px);line-height:var(--smtc-text-global-title2-line-height,26px);font-weight:650}.event-info{display:flex;justify-content:space-between;align-items:center}.see-more{display:block;text-decoration:none;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);margin:16px 2px 8px;margin-inline-end:auto;color:var(--smtc-foreground-ctrl-neutral-primary-rest,#272320);${s.f};z-index:3}.see-more:hover{text-decoration:underline}.see-more:active{text-decoration:underline;color:var(--smtc-foreground-ctrl-neutral-primary-pressed,#5A544F)}.anchor-overlay{position:absolute;width:100%;height:100%;top:0px;left:0px;z-index:2}._2c.wrap{flex-direction:row}._2c .event-info{flex-direction:column;max-width:166px;padding:20px;align-items:flex-start}._2c .medal-table{padding:24px}._2c .see-more{margin-top:18px}@container (max-width:328px){.header-text{font-size:16px}}`.withBehaviors(new d.N(null,c));var g=r(96950),h=r(69259);const x=g.qy`
    <div class="wrap ${e=>{var t;return"1.5u"===(null===(t=e.viewModel)||void 0===t?void 0:t.cardSize)?"_15u":"_2c"}}">
        <a
            class="anchor-overlay"
            href="${e=>e.viewModel.destinationUrl}"
            data-t=${e=>e.viewModel.telemetryTag}
            target="_blank"
        ></a>
        <div class="event-info">
            <div>
                <div class="upd-text">
                    ${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.updatedAgoText}}
                </div>
                <div class="header-text">
                    ${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.headerText}}
                </div>
            </div>
            <img src="${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.logoUrl}}" alt="Olympics 2026 Logo" class="logo" />
        </div>
        <div class="medal-table">
            <sports-table
                :viewModel="${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.tableViewModel}}"
            ></sports-table>
            <a
                href="${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.seeMoreUrl}}"
                class="see-more"
                target="_blank"
                data-t=${e=>e.viewModel.seeMoreTelemetryTag}
            >${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.seeMoreText}}</a>
        </div>
    </div>
`,u=g.qy`
    ${(0,h.z)(e=>null!=e.viewModel,g.qy`${x}`)}
`;let f=class extends o{};f=(0,i.Cg)([(0,n.E)({name:"sports-medal-count-v2",template:u,styles:p,shadowOptions:{delegatesFocus:!0}})],f)},42792(e,t,r){r.d(t,{R7(){return u},e(){return h},kc(){return x},nH(){return g}});var i=r(57416),a=r(55153),o=r(95239),n=r(26920),l=r(48751),d=r(64187),s=r(22131),c=r(74849),p=r(50882);const g=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,d.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${n.XA} * 1px) solid ${a.cu};
        border-radius: calc((${i.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${l.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,x=(0,s.mr)(c.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),u=c.A`
    ${h}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(x)},67803(e,t,r){r.r(t),r.d(t,{SportsMedalV2Transformer(){return p}});var i=r(49150),a=r(23587),o=r(22341),n=r(85312),l=r(58792),d=r(79811),s=r(96950),c=r(50180);class p extends a.Bc{async transform(e){return this.isInDarkMode=(0,d.jJ)(),this.cardSize=e.cardSize,this.is2C=this.cardSize===i.uE._2c,{viewTemplate:s.qy`
                <sports-medal-count-v2
                    :viewModel=${this.getViewModel(e)}
                ></sports-medal-count-v2>
            `}}getViewModel(e){return{updatedAgoText:this.getUpdatedAgoText(e),headerText:this.transformerProvider.strings.medalCount2026OlympicsHeader,seeMoreText:this.transformerProvider.strings.seeMoreOlympics,backgroundImageUrl:this.getBackgroundImageUrl(),tableViewModel:this.getTableViewModel(e),logoUrl:`${(0,l.rA)().StaticsUrl}latest/sports/img/olympics/winter_2026_logo.svg`,seeMoreUrl:e.footerClickthroughUrl,cardSize:e.cardSize,destinationUrl:e.clickThroughUrl,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:a.BP.SportsMedalCard}),seeMoreTelemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:`${a.BP.SportsMedalCard}Footer`})}}getUpdatedAgoText(e){var t;const r=null===(t=e.medalData)||void 0===t?void 0:t.lastUpdateDateTime;if(!r)return"";const i=this.getRelativeTimeString(r,l.T3.CurrentMarket);return(0,c.GP)(this.transformerProvider.strings.updatedAgo||"",i)}getRelativeTimeString(e,t){const{strings:r}=this.transformerProvider,i=null==r?void 0:r.relativeTimeLocalization;if((0,c.oT)(e)||!i)return e;const a=(0,d.yn)(e),o=Date.now(),n=Math.floor((o-a.valueOf())/1e3),l=Math.max(1,Math.floor(n/60));if(l<60)return`${l}${i.numberMinutesAgoLabel}`;const s=Math.floor(l/60);if(s<24)return`${s}${i.numberHoursAgoLabel}`;const p=Math.floor(s/24);if(p<7)return`${p}${i.numberDaysAgoLabel}`;if(p<30){return`${Math.floor(p/7)}${i.numberWeeksAgoLabel}`}if(p<365){return`${Math.floor(p/30)}${i.numberMonthsAgoLabel}`}return`${Math.floor(p/365)}${i.numberYearsAgoLabel}`}getBackgroundImageUrl(){return`${(0,l.rA)().StaticsUrl}latest/sports/img/olympics/winter_2026_1c_light.png`}getTableHeader(){const{strings:e}=this.transformerProvider,t=`${(0,l.rA)().StaticsUrl}latest/sports/icons/`,r="icon-20";return{player:{value:e.team,class:"no-border font-m secondary",textStyles:"font-weight: 400"},gold:{value:"",icon:`${t}OlympicGold.svg`,class:"center no-border",iconClass:r},silver:{value:"",icon:`${t}OlympicSilver.svg`,class:"center no-border",iconClass:r},bronze:{value:"",icon:`${t}OlympicBronze.svg`,class:"center no-border",iconClass:r},total:{value:e.total,class:"no-border font-m secondary center",textStyles:"font-weight: 400"}}}iconUrl(e){return e?(0,d.iK)(e,!1,this.transformerProvider.config.teamImageInfoEnhanced):this.getTeamImageFallback()}getTeamImageFallback(){return`${(0,l.rA)().StaticsUrl}pr-6367804/sports/icons/TeamFlagFallbackV2.svg`}getMedalColumn(e,t,r,i,a){const o=i?"0":"-";return{value:`${t.medalsWon[e]?t.medalsWon[e]:o}`,cellClass:`no-border middle ${a}`,class:"center font-l",isHightlighted:r}}getTableBody(e){return e.map(e=>{const t=(0,d.Hn)(e.team.isUserLocalTeam),r=Boolean(e.medalsWon.Total);return{player:{preText:`${e.overallRank}`,preTextClass:"font-l text-center fw-400",preTextStyles:"width: 21px; font-weight: 400; text-align: center; padding-inline-end: 8px;",value:e.team.shortName||"-",icon:this.iconUrl(e.team.imageId),iconClass:"icon-24",textStyles:"margin-inline-start: 6px;",cellClass:"first-column no-border",class:"font-l",isHightlighted:t},gold:this.getMedalColumn("Gold",e,t,r),silver:this.getMedalColumn("Silver",e,t,r),bronze:this.getMedalColumn("Bronze",e,t,r,this.is2C?void 0:"last-column"),total:this.getMedalColumn("Total",e,t,r,this.is2C?"last-column":void 0)}})}getColumnStyle(){return this.is2C?"1fr repeat(4, 66px)":"minmax(100px, 1fr) repeat(3, minmax(min-content, 52px))"}getRowStyle(e){return this.is2C?`20px repeat(${e-1}, 32px)`:`repeat(${e}, 32px)`}getLocalTeam(e){return e.find(e=>(0,d.Hn)(e.team.isUserLocalTeam))}getEmptyMedalStanding(e){return{overallRank:`${e}`,team:{id:"",name:"",shortName:this.transformerProvider.strings.TBD,imageId:""},medalsWon:{Gold:0,Silver:0,Bronze:0,Total:0}}}prepareMedalStandigs(e){const t=this.cardSize===i.uE._15u?3:5,r=e.filter(e=>"-"!==e.overallRank).slice(0,t);for(;r.length<t;)r.push(this.getEmptyMedalStanding(r.length+1));const a=this.getLocalTeam(e),o=a&&Boolean(r.find(e=>e.team.id===a.team.id));return!a||o?r.slice(0,t):r.slice(0,t-1).concat(a)}tableStyles(){return"margin-top: 0px; padding: 0px"}gridStyles(){return`width: calc(100% + 8px); row-gap: ${this.is2C?"16":"10"}px;`}getTableViewModel(e){const{medalData:t}=e;if(!t||!t.topRankedTeamStandings||0===t.topRankedTeamStandings.length)return void(0,o.vV)(n.Ax,"Medal table data missing",`market=${l.T3.CurrentMarket}`,JSON.stringify(e));const r=["player","gold","silver","bronze"];this.is2C&&r.push("total");const i=this.getTableHeader(),a=this.prepareMedalStandigs(t.topRankedTeamStandings),d=this.getTableBody(a),s={keys:r,header:i,body:d};return{telemetryTag:"",cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,data:s,columnStyle:this.getColumnStyle(),rowStyle:this.getRowStyle(d.length+1),tableStyles:this.tableStyles(),gridStyles:this.gridStyles(),tableClass:"no-padding full-width cplt"}}}Promise.resolve().then(r.bind(r,24670)),Promise.resolve().then(r.bind(r,17471))},84564(e,t,r){r.d(t,{z(){return n}});var i=r(56911),a=r(60815),o=r(92011);class n extends o.L{}(0,i.Cg)([a.sH],n.prototype,"viewModel",void 0)},92079(e,t,r){r.d(t,{a(){return n}});var i=r(56911),a=r(92011),o=r(31525);let n=class extends a.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,i.Cg)([o.x],n)},99657(e,t,r){r.d(t,{D(){return n},I(){return o}});var i=r(45755);const{create:a}=i.G,o=a("sloppy-click-z-index",1),n=a("click-z-index",1)}}]);