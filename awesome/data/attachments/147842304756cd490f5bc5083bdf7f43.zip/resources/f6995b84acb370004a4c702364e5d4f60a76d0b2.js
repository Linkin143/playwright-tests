"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-cricket"],{4968(t,e,i){i.d(e,{f(){return o}});var a=i(64187),r=i(74849),n=i(42792),s=i(99657),l=i(36452);const o=r.A.partial`position: relative; z-index: ${s.D};`;r.A`
    ${n.e}
    ${n.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${o}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(n.kc)},10500(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},17620(t,e,i){i.r(e),i.d(e,{SportsCricketRecentMatches(){return F}});var a=i(56911),r=i(92011),n=i(74849),s=i(22131),l=i(4126),o=i(48751),d=i(61138),c=i(62047);const p=n.A` .ruby{container-type:inline-size}@container (min-width:180px) and (max-width:233px){.ruby{.content{.team-info{min-width:55px;max-width:60px}.team-performance{gap:2px}}}}@container (min-width:234px) and (max-width:269px){.ruby{.content{.team-performance{gap:7px}}}}`,v=n.A` :host{--ruby-win-color:#6CC57B;--ruby-loss-color:#F98981;--ruby-tie-color:#8791B0;--ruby-win-bg-color:#09662033;--ruby-loss-bg-color:#9D192033;--ruby-tie-bg-color:#323F60A6}.recent-matches{color:${o.l}}.ruby .result-element .team-name{color:#D7DEEF}`,h=(0,s.G2)(v),u=n.A` :host{--ruby-win-color:#01712B;--ruby-loss-color:#AC1922;--ruby-tie-color:#635C57;--ruby-win-bg-color:#94DC7F33;--ruby-loss-bg-color:#FFB5AE33;--ruby-tie-bg-color:#F8F4F2}p{margin:0;font-family:"Segoe UI"}.team-info{margin-right:8px}.title{font-size:${d.k};
        line-height: ${d.F};font-weight:600;margin:8px 0;text-align:center}.content{display:flex;flex-direction:column;background:var(--sports-item-background);padding:6px 12px;border-radius:8px}.team-performance{display:flex;flex-direction:row;gap:8px;&:first-child{padding-bottom:5px;margin-bottom:5px;border-bottom:1px solid rgba(0,0,0,0.05)}}.result-element{padding-top:4px;width:32px;display:flex;flex-direction:column;align-items:center;span{width:24px;text-align:center}.result{color:#fff;font-size:${d.k};
            line-height: ${d.F};text-align:center;border-radius:6px;font-weight:600;height:24px;display:flex;justify-content:center;align-items:center;margin-bottom:6px}.winner{background-color:rgba(15,112,59,1)}.loss{background-color:rgba(209,52,56,1)}.tied{background-color:rgba(220,159,6,1)}}.team-name{font-size:${c.t};
        line-height: ${c.e};font-weight:600;text-align:center}.team-image{height:32px}.underscore{width:12px;height:1px;position:absolute;bottom:6px;right:50%;transform:translateX(50%)}.ruby{.content{background:none;padding:0px 0px 18px}.title{display:none}.team-info{display:flex;align-items:center;width:70px;margin-right:0px}.team-image{width:20px;height:20px}.team-performance{gap:12px;&:first-child{margin-bottom:24px;border-bottom:0px}}.team-name{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);font-weight:550;margin:0px 0px 0px 4px;max-width:44px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:inherit}.result-element{position:relative;padding-top:0px;width:auto;.team-name{display:none}.winner{background-color:var(--ruby-win-bg-color);color:var(--ruby-win-color)}.loss{background-color:var(--ruby-loss-bg-color);color:var(--ruby-loss-color)}.tied{background-color:var(--ruby-tie-bg-color);color:var(--ruby-tie-color)}.underscore{&.winner{background-color:var(--ruby-win-color)}&.loss{background-color:var(--ruby-loss-color)}&.tied{background-color:var(--ruby-tie-color)}}}.result{margin-bottom:0px;border-radius:14px;height:28px;width:28px;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px)}}`.withBehaviors(h,new l.o("isAdaptiveThemeEnabled",!0,p));var g=i(96950),x=i(69259),m=i(39957);const f=g.qy`
    <div class="team-performance">
        <div class="team-info">
            <img class="team-image" src="${t=>t.teamImageUrl}" alt="${t=>t.teamName}" />
            <p class="team-name">${t=>t.teamName}</p>
        </div>
        ${(0,m.ux)(t=>t.matches,()=>g.qy`
    <div class="result-element">
        <span class="${(t,e)=>e.parentContext.parent.getResultClass(t.gameStatus)} result">
            ${t=>t.summary}
        </span>
        <span class="team-name">${t=>t.teamName}</span>
        ${(0,x.z)(t=>t.isLatest,g.qy`<div class="underscore ${(t,e)=>e.parentContext.parent.getResultClass(t.gameStatus)}"></div>`)}
    </div>
`)}
    </div>
`,b=g.qy`
    <div class="recent-matches ${t=>t.viewModel.isRubySpotlight?"ruby":""}" data-t="${t=>t.viewModel.telemetryTag}">
        <p class="title">${t=>{var e;return null===(e=t.viewModel.strings)||void 0===e?void 0:e.recentMatches}}</p>
        <div class="content">
            ${(0,m.ux)(t=>t.viewModel.recentMatches,f)}
        </div>
    </div>
`,y=g.qy`
    ${(0,x.z)(t=>null!=t.viewModel,b)}
`;var $=i(23587),w=i(92079),k=i(67689);class z extends w.a{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,k.h)()}getResultClass(t){return t===$.qz.Won?"winner":t===$.qz.Lost?"loss":"tied"}}let F=class extends z{};F=(0,a.Cg)([(0,r.E)({name:"sports-cricket-recent-matches",template:y,styles:u,shadowOptions:{delegatesFocus:!0}})],F)},32954(t,e,i){i.r(e),i.d(e,{SportsCricket(){return O}});var a=i(56911),r=i(23587),n=i(92079),s=i(50180),l=i(54229);class o extends n.a{handleClickFollowIcon(t,e,i,a){if(t&&t.currentTarget){t.preventDefault(),t.stopPropagation();const r="keydown"===t.type||"keypress"===t.type||"keyup"===t.type;(0,l.LE)(t.currentTarget,r,e),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,e,a)}}getScoreClassName(t,e){var i;return(null===(i=this.viewModel.scoreClassNameMap)||void 0===i?void 0:i.get(`${t}${e.satoriId}`))||""}getScoreLineByIndex(t,e,i){const a=this.viewModel.scoresMap.get(`${t}${e.satoriId}`),r=a&&a.length>i?a[i]:void 0;return null==r?void 0:r.trim()}getMiddleTemplate(t){return t==r.Xp.preGame?"pre":t==r.Xp.postGame?"post":"live"}getMiddleTemplateClass(t){return t===r.Xp.superover?"state-top":t===r.Xp.postponed?"state-bottom":""}getParticipant(t,e){return this.viewModel.isRTL?t?e.participantTwo:e.participantOne:t?e.participantOne:e.participantTwo}getLiveText(t){var e;return t==r.Xp.inprogressGame?null===(e=this.viewModel.strings)||void 0===e?void 0:e.sportsLive:t}getFollowIconTitle(t,e){var i,a;return(0,s.GP)((e?null===(i=this.viewModel.strings)||void 0===i?void 0:i.followSports:null===(a=this.viewModel.strings)||void 0===a?void 0:a.haveFollowed)||"",t.name||"")}getGameTime(t){return(t.tvChannel?`${t.gameStartTime}, ${t.tvChannel}`:t.gameStartTime)||""}isScoreMultiLine(t,e){const i=this.viewModel.scoresMap.get(`${t}${e.satoriId}`);return!!i&&i.length>1}shouldRenderResults(t){return t!=r.Xp.preGame&&t!=r.Xp.toss}shouldShowSuperOver(t){return t===r.Xp.superover}shouldShowPostPoned(t){return t===r.Xp.postponed}}var d=i(92011),c=i(86856),p=i(12640),v=i(74849),h=i(22131),u=i(4968);const g=v.A` :host{--bg-color:rgba(255,255,255,0.06);--bg-color-hover:#3D3D3D}.match-content{color:#FFFFFF}.ipl-super-over{background:rgba(255,255,255,0.09)}.expl .ipl-super-over,.expl .detailed-game-state{background-color:rgba(255,255,255,0.3)}.cricket-final{color:#FFFFFF}.expl .cricket-final{background:rgba(255,255,255,0.3)}.winner-tag path{fill:#FFFFFF}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#0078d4}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.cricket-live-tag{background:rgba(36,214,87,1);color:#000000}.expl .cricket-live-tag{background-color:rgba(233,143,109)}.match-footer{color:#FFFFFF}.pin-to-desk-block{background:rgba(91,51,143,1);background-image:linear-gradient(45deg,rgb(255,0,165) 0,rgb(255,0,165) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgba(255,0,165,0.8) 87%,rgb(255,0,165) 100%);color:white}.pin-to-desk-button{border:1px solid white}.win-light{display:none}.win-dark{display:block}`,x=v.A`

`,m=v.A` .flip-h .follow-icon{float:left}.match-footer{right:calc(50% - 90px)}.pin-to-desk-button > img{margin-left:4px}`,f=v.A` :host{--participant-height:55px;--match-content-height:54px;--bg-color:rgba(255,255,255,0.5);--bg-color-hover:#F7F7F7}.match-data{text-align:center;align-items:center;display:grid;row-gap:4px;position:relative;height:100%}.match-content{background:var(--sports-item-background);display:flex;flex-direction:row;justify-content:space-between;align-items:center;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:#000000;width:268px;backdrop-filter:blur(6px);height:54px;${u.f}}.match-content:hover,.match-content:focus-visible{background:var(--sports-item-hover-background)}.match-content:active{background:var(--sports-item-active-background)}._1x_1y .match-content{height:var(--match-content-height)}._1x_1y .participant-container{height:var(--match-content-height)}._1x_1y .participant-container .follow-icon{top:-5px;right:-8px}._1x_3y .match-content{height:72px}._1x_3y .participant-content{height:100%}._1x_3y .participant-score span{margin-top:3px}._1x_3y .participant-score{margin-top:10px}:host([isMobile=true]) .match-content{width:100%}:host([cardlayout="_1x_1y"]) .match-content{padding:0}:host([isMobile=true]) .match-content{margin:0 auto;margin-bottom:8px}:host([isMobile=true]) .participant-container{padding:20px;box-sizing:border-box}:host([cardlayout="_1x_1y"]) .participant-container{max-height:70px}:host([isMobile=true]),:host([isMobile=true]) *:active,:host([isMobile=true]) *:hover{border:none;outline:none;box-shadow:none;text-decoration:none;-webkit-tap-highlight-color:transparent;-webkit-highlight:none}.participant-container{width:108px;max-width:132px;margin:0 0 0 13px;height:100%}.participant-container.flip-h{margin:0 13px 0 0}.results{display:flex}.flip-h .results{flex-flow:row-reverse}.single{align-items:center}.single .participant-score span.score-line1{margin:0 0 5px 0}.participant-info{display:flex;flex-direction:column;justify-content:center;align-items:center;position:relative}.participant-content{display:flex;column-gap:7px;height:var(--participant-height);position:relative}.flip-h .participant-content{flex-flow:row-reverse}.match-detail{height:var(--participant-height);display:flex;align-items:center}.ipl .match-detail.state-top{height:80px}._1x_1y .match-detail{height:var(--match-content-height)}.participant-icon{width:32px;height:auto;border-radius:8px}.participant-name{font-weight:600;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:80px;margin:0 auto}.participant-score span{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);max-width:62px}.participant-score{max-height:36px;text-align:start;display:flex;flex-direction:column}.participant-score span.score-line1{margin-top:5px;font-size:14px;font-weight:600;line-height:18px}.flip-h .participant-score{text-align:end}.winner{font-weight:600}.winner-tag{position:absolute;height:100%;display:flex;align-items:center;left:-5px;margin-top:-8px;transform:scaleX(-1)}.flip-h .winner-tag{transform:scaleX(1);right:-5px;left:auto}.winner-tag > svg{fill:currentColor}.middle-detail{align-items:center;display:flex;flex-direction:column;direction:ltr}.game-detail{margin-top:-15px}.game-date{font-weight:600;font-size:14px;line-height:20px}.game-time{font-weight:400;font-size:12px;line-height:16px}.pre-game{width:120px}.cricket-live-tag{display:inline-block;background:rgb(7,148,48);color:rgb(255,255,255);font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-1-line-height,16px);height:16px;padding:1px 6px;margin:0;border-radius:3px;font-weight:600;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;text-transform:uppercase}.status-text{font-size:12px;line-height:14px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.ipl-super-over{background:rgba(255,255,255,0.4);display:flex;justify-content:center;align-items:center;border-radius:6px}.super-over-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0 4px 0 4px;font-size:10px;font-weight:400;line-height:14px}.state-top{flex-direction:column;justify-content:center}.state-top .middle-detail{flex:1;margin-top:15px}.state-bottom{flex-direction:column;justify-content:center;height:100%;margin-top:10px}.live-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;margin-top:1px}.detail-live-animation{height:1px;transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate;background:white}@keyframes liveAnimation{0%{width:20px}100%{width:4px}}.match-extended-details{width:180px;text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0px 10px;box-sizing:border-box}.match-footer{color:#1A1A1A;font-style:normal;font-weight:400;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);width:180px;display:inline-block;position:absolute;bottom:5px;left:calc(50% - 90px)}:host([cardlayout="_1x_1y"]) .match-footer{bottom:4px}.super-over-words{background:rgba(255,255,255,0.35);border-radius:3px;color:rgb(101,107,155);font-style:italic;font-weight:600;width:130px;height:30px;font-size:20px;transform:scale(0.5);line-height:14px;display:flex;align-items:center;justify-content:center;padding:0 3px 5px 0;box-sizing:border-box}.cricket-final{width:21px;height:21px;background:var(--sports-item-background);border-radius:21px;font-weight:400;font-size:10px;line-height:21px;color:#000000}.participant-hover{display:flex;align-items:center;justify-content:center;width:36px;height:28px}.ipl .participant-hover{border:0.5px solid rgba(186,186,186,0.22);border-radius:5px}.detail-live-animation .bottom-game-detail{line-height:14px}@keyframes liveAnimationCommon{0%{width:40px}100%{width:4px}}.participant-container .follow-icon{opacity:0;pointer-events:none;height:20px;position:absolute;bottom:35px;left:25px}.flip-h .follow-icon{float:right}.participant-container:hover .follow-icon,.match-content:focus-visible .follow-icon,.follow-icon:focus-visible{opacity:1;pointer-events:all}.match-content:focus-visible{outline-offset:-1px}._1x_1y.match-data:focus-visible{outline:none}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.pin-to-desk-block{background-color:rgb(255,241,250);background-image:linear-gradient(45deg,rgb(252,151,216) 0,rgb(252,151,216) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgb(252,151,216) 87%,rgb(252,151,216) 100%);display:flex;flex-direction:column;justify-content:center;align-items:center;gap:6px;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:black;width:268px;backdrop-filter:blur(6px);height:54px}.pin-to-desk-block:hover{cursor:pointer}.pin-to-desk-des,.pin-to-desk-button{font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;line-height:16px}.pin-to-desk-button{display:flex;height:28px;padding:2px 10px;justify-content:center;align-items:center;border-radius:100px;border:1px solid black}.pin-to-desk-button > img{margin-right:4px}.win-dark{display:none}._1x_1y .pin-to-desk-block{height:var(--match-content-height)}._1x_3y .pin-to-desk-block{height:72px}:host([isMobile=true]) .pin-to-desk-block{width:100%}:host([cardlayout="_1x_1y"]) .pin-to-desk-block{padding:0}:host([isMobile=true]) .pin-to-desk-block{margin:0 auto;margin-bottom:8px}.detailed-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);font-weight:600;padding:2px 6px;border-radius:3px;text-transform:uppercase;background:rgba(53,21,105,1)}.final-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);padding:2px 6px;border-radius:3px;background:rgba(53,21,105,0.5)}.expl._1x_2y .match-content,.expl._1x_3y .match-content{box-sizing:border-box;height:66px}.expl._1x_3y{row-gap:6px}.expl._1x_3y .participant-score{margin-top:0px}.expl .match-content{box-sizing:border-box;height:66px;background-color:var(--bg-color)}.expl .match-content:hover{background-color:var(--bg-color-hover)}.expl .cricket-final{background:rgba(26,26,26,0.1)}.expl .cricket-live-tag{background-color:rgb(196,43,28)}.expl .ipl-super-over,.expl .detailed-game-state{background-color:rgba(26,26,26,0.1)}`.withBehaviors(new c.t(x,m),new p.N(null,g),(0,h.mr)(v.A` :host{forced-color-adjust:auto}`));var b=i(96950),y=i(69259),$=i(39957),w=i(10500),k=i(36516),z=i(58792);const F=b.qy`
    <img
        src="${()=>(0,z.rA)().StaticsUrl}latest/sports/icons/PinBlack.svg"
        class="win-light"
    >
    <img
        src="${()=>(0,z.rA)().StaticsUrl}latest/sports/icons/PinWhite.svg"
        class="win-dark"
    />
`,_=(t,e,i,a)=>b.qy`
<div class="participant-container${t=>e?"":" flip-h"}" title="${(null==i?void 0:i.name)||""}">
<div class="participant-content" index="-1">
            <div class="winner-tag">    
                ${(0,y.z)(t=>null==i?void 0:i.isWinner,b.qy`${b.qy.partial('<svg width="5" height="10" viewBox="0 0 5 10" fill="none"><path d="M5 0 0 5.22 5 10V0Z"/></svg>')}`)}
            </div>
            <div class="participant-info" index="-1">
                <div class="participant-hover">
                    <img class="participant-icon" role="presentation" src="${t=>i.imageUrl}"/>
                </div>
                <div class="participant-name">${(null==i?void 0:i.name)||""}</div>
                ${(t,e)=>{var a;return((t,e)=>b.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${(i,a)=>a.parent.getFollowIconTitle(t,e)}"
        @click="${(i,a)=>a.parent.handleClickFollowIcon(a.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:r.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||"")}"
        @keyup="${(i,a)=>a&&a.event&&"Enter"===a.event.key?a.parent.handleClickFollowIcon(a.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:r.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||""):null}"
        data-t="${(t,e)=>e.parent.viewModel.followTelemetryTag}"
    >
    <div class="${t=>e?"icon-add":"icon-selected"}"> ${b.qy.partial(e?k.A:w.A)}</div>
    </div>
`)(i||{},1!=(null===(a=e.parent.viewModel.followedMap)||void 0===a?void 0:a.get(i.satoriId)))}}
            </div>
            ${(0,y.z)((t,e)=>e.parent.shouldRenderResults(a),((t,e,i)=>b.qy`
    <div class="results ${(e,a)=>a.parent.getScoreLineByIndex(t,i,1)?"":"single"}">
        <div class="${(e,a)=>a.parent.getScoreClassName(t,i)}">
            <span class="score-line1">${(e,a)=>a.parent.getScoreLineByIndex(t,i,0)}</span>
            ${(0,y.z)((e,a)=>a.parent.isScoreMultiLine(t,i),b.qy`
                        <span>${(e,a)=>a.parent.getScoreLineByIndex(t,i,1)}</span>`)}
        </div>
    </div>
`)(t,0,i))}
        </div>
    </div>
`,M=b.qy`
    <div class="cricket-live-detail">
        ${(0,y.z)(t=>t.detailedGameState!=r.Xp.nonlive,b.qy`
            <div class="cricket-live-tag">
                <span class="live-text">${(t,e)=>e.parent.getLiveText(t.detailedGameState)}</span>
            </div>
        `)}
    </div>
`,j=b.qy`
    <div class="game-detail pre-game">
        <div class="game-date">
            ${t=>t.gameDate}
        </div>
        <div class="game-time">
            ${(t,e)=>e.parent.getGameTime(t)}
        </div>
    </div>
`,S=b.qy`
    <div class="game-detail post-game">
        <div class="game-state cricket-final">
            ${(t,e)=>{var i;return(null===(i=e.parent.viewModel.strings)||void 0===i?void 0:i.sportsVS)||"VS"}}
        </div>
    </div>
`,C=b.qy`
 <div class="middle-detail">
     ${(t,e)=>{switch(e.parent.getMiddleTemplate(t.detailedGameState)){case"pre":return j;case"post":return S;case"live":return M;default:return""}}}
 </div>
`,I=(b.qy`
<div class="detailed-game-state">
    ${t=>t.detailedGameState}
</div>
`,b.qy`
<div class="detailed-game-state">
    ${t=>r.Xp.postponed}
</div>
`,b.qy`
    <div class="match-detail ${(t,e)=>e.parent.getMiddleTemplateClass(t.detailedGameState)}">
        ${C}
    </div>
`),T=b.qy`  
    <a class="match-content"
        tabindex="0"
        href="${t=>t.matchClickthroughUrl?t.matchClickthroughUrl:void 0}"
        target="${(t,e)=>e.parent.viewModel.linkTarget}"
        data-t="${(t,e)=>e.parent.viewModel.telemetryTag}"
    >
        ${(t,e)=>_(t.gameId||"",!0,e.parent.getParticipant(!0,t)||{},t.detailedGameState)}
        ${I}
        ${(t,e)=>_(t.gameId||"",!1,e.parent.getParticipant(!1,t)||{},t.detailedGameState)}
        <div class="match-footer">${(t,e)=>{return i=e.parent.viewModel.matchSummaryMap.get(t.gameId),b.qy`
    <div>
        <div class="match-extended-details" title="${i||""}">
            ${i||""}
        </div>
    </div>
`;var i}}</div>
    </a>
`,P=b.qy`
    <a class="pin-to-desk-block"
        tabindex="0"
        role="button"
        @click="${t=>t.viewModel.pinToDeskClick&&t.viewModel.pinToDeskClick()}"
        data-t="${t=>t.viewModel.pinToDeskButtonTelemetryTag}"
    >
        <div class="pin-to-desk-des">
            ${t=>t.viewModel.strings.pinToDeskDesc||"Follow the latest games on desktop"}
        </div>
        <div class="pin-to-desk-button">
            ${F}${t=>t.viewModel.strings.pinToDeskButton||"Pin live score"}
        </div>
    </a>
`,D=b.qy`
    ${(0,y.z)(t=>t.viewModel.matchData.length>0,b.qy`
        <div class="match-data ${t=>t.viewModel.cardSize} ${t=>t.viewModel.isIPL?"ipl":""} ${t=>t.viewModel.isExploration?"expl":""}">
            ${(0,$.ux)(t=>t.viewModel.matchData.slice(0,t.viewModel.shouldShowPinToDesk?t.viewModel.showMatchCount-1:t.viewModel.showMatchCount),T,{positioning:!0})}
            ${(0,y.z)(t=>t.viewModel.shouldShowPinToDesk,P)}
        </div>`)}
`,B=b.qy`
    ${(0,y.z)(t=>null!=t.viewModel,D)}
`;let O=class extends o{};O=(0,a.Cg)([(0,d.E)({name:"sports-cricket",template:B,styles:f,shadowOptions:{delegatesFocus:!0}})],O)},36516(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},39606(t,e,i){i.r(e),i.d(e,{SportsCricketPartnership(){return F}});var a=i(56911),r=i(92011),n=i(74849),s=i(48751),l=i(61138),o=i(62047),d=i(36452),c=i(41123),p=i(12640);const v=n.A` .cricket-partnership{color:${s.l};
    }

`,h=n.A` p{margin:0;font-family:"Segoe UI"}.cricket-partnership{width:268px}.ellipsis{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.current-partnership{font-size:${l.k};
        line-height: ${l.F};font-weight:600;margin:6px 0;text-align:center}.stats-item{height:28px;display:flex;justify-content:end;flex-direction:column;flex:1;padding:0 5px}.bar-title{height:14px;line-height:${o.e};
        font-size: ${o.t};font-weight:600;display:flex;justify-content:center}.bar-title >div{display:inline-block;line-height:${l.F};
        font-size: ${l.k}}.stats-bar{display:flex;height:8px;width:100%;border-radius:8px;justify-content:space-between;background:${d.I2};margin-top:6px}.left-bar{display:flex;height:8px;width:calc(50% - 0.5px);background:${d.I2};border-radius:8px 0 0 8px;justify-content:flex-end}.right-bar{display:flex;height:8px;width:calc(50% - 0.5px);background:${d.I2};border-radius:0 8px 8px 0;justify-content:flex-start}.left-bar-progress{height:8px;width:30%;border-radius:8px 0 0 8px;background:#EACF24}.right-bar-progress{height:8px;width:30%;border-radius:0 8px 8px 0;background:#9C8C26}.individual-partnership{flex-direction:row;flex-wrap:nowrap;justify-content:space-between;text-align:justify;position:relative;background:var(--sports-item-background);padding:12px;border-radius:8px;display:flex}.partnership-player{display:flex;flex-direction:column}.player-stats{height:20px;font-family:'Segoe UI';font-style:normal;font-weight:400;font-size:${l.k};;
        line-height: ${l.F};
    }

    .player-name{
        font-style: normal;
        font-weight: 600;
        font-size: ${l.k};
        line-height: ${l.F};max-width:70px}.left-player{text-align:left;flex:1 1 0}.right-player{text-align:right;flex:1 1 0}.horizontal-bar{box-sizing:border-box;width:100%;height:1px;background:var(--neutral-stroke-divider-rest);flex:0 0 auto;order:0}.stats-bar{text-align:center}._1x_3y{.current-partnership{margin:10px 0;font-size:${c.K};
            line-height: ${c.Z}}.individual-partnership{padding:13px}.player-name{-webkit-line-clamp:2}}.player-image{width:50px;height:50px}.middle-section{width:118px;display:flex;flex-direction:column}.team-image{width:16px;height:16px}.team-name{font-size:${o.t};
        line-height: ${o.e};font-weight:600;margin-left:6px}.team-image-container{display:flex;flex:1;justify-content:center;align-items:center}.individual-partnership.without-image{flex-direction:column;.partnership-player{flex-direction:row}.player-name-container{display:flex;flex:3 1 0;flex-direction:column;overflow:hidden}.player-stats{display:flex;flex:1 1 0;flex-direction:column;p{min-width:16px;max-width:35px;text-align:center}}.grid-stats{display:grid;grid-template-columns:1fr 1fr;column-gap:12px;width:100%}.header{font-weight:600}p{font-size:${l.k};
            line-height: ${l.F}}.stats-header-row,.stats-row{display:flex}.player-name{max-width:none}.player1{padding-bottom:8px;padding-top:4px;border-bottom:1px solid rgba(0,0,0,0.05)}.player2{padding-top:8px}}.partnership-info{margin-left:auto;font-size:${o.t};
        line-height: ${o.e};
        font-weight: 600;
    }
`.withBehaviors(new p.N(null,v));var u=i(96950),g=i(69259);const x=t=>u.qy`
    <div class="partnership-player">
        <div class="player-image-container">
            <img class="player-image" src="${t.imageUrl}" alt="${t.name}" />
        </div>
        <p class="player-name ellipsis"  title="${t.name}">
            ${t.name}
        </p>
        <p class="player-stats ellipsis">
            ${e=>{var i,a;return e.setPlayerStats((null===(i=t.battingStatistics)||void 0===i?void 0:i.runsScored)||"",(null===(a=t.battingStatistics)||void 0===a?void 0:a.ballsFaced)||"")}}
        </p>
    </div>
`,m=u.qy`
    <div class="stats-item">
        <div class="bar-title">
            <div>${t=>t.viewModel.partnershipInfo.runs} (${t=>t.viewModel.partnershipInfo.balls})</div>
        </div>
        <div class="stats-bar">
            <div class="left-bar"><div class="left-bar-progress" style="width: ${t=>t.partnershipPercentage("batter1")}"></div></div>
            <div class="right-bar"><div class="right-bar-progress" style="width: ${t=>t.partnershipPercentage("batter2")}"></div></div>
        </div>
    </div>
`,f=u.qy`
    <div class="cricket-partnership ${t=>t.viewModel.cardSize}" data-t="${t=>t.viewModel.telemetryTag}">
        <p class="current-partnership">${t=>t.viewModel.strings.currentPartnership}</p>
        ${t=>t.viewModel.partnershipInfo.batter1.imageUrl&&t.viewModel.partnershipInfo.batter2.imageUrl?y:b}
    </div>
`,b=u.qy`
    <div class="individual-partnership without-image">
        <div class="team-image-container">
            <img class="team-image" src="${t=>t.viewModel.partnershipInfo.batter1.teamImageUrl}" />
            <p class="team-name ellipsis" title="${t=>t.viewModel.partnershipInfo.batter1.teamName}">${t=>t.viewModel.partnershipInfo.batter1.teamShortName}</p>
            <p class="partnership-info">${t=>t.viewModel.partnershipInfo.runs}(${t=>t.viewModel.partnershipInfo.balls})</p>
        </div>
        <div class="player1">
            ${t=>$(t.viewModel.partnershipInfo.batter1)}
        </div>
        <div class="player2">
            ${t=>$(t.viewModel.partnershipInfo.batter2)}
        </div>
    </div>
`,y=u.qy`
    <div class="individual-partnership">
        <div class="left-player">
            ${t=>x(t.viewModel.partnershipInfo.batter1)}
        </div>
        <div class="middle-section">
            <div class="team-image-container">
                <img class="team-image" src="${t=>t.viewModel.partnershipInfo.batter1.teamImageUrl}" />
                <p class="team-name ellipsis" title="${t=>t.viewModel.partnershipInfo.batter1.teamName}">${t=>t.viewModel.partnershipInfo.batter1.teamShortName}</p>
            </div>
            ${m}
        </div>
        <div class="right-player">
            ${t=>x(t.viewModel.partnershipInfo.batter2)}
        </div>
    </div>
`,$=t=>{var e,i;return u.qy`
    <div class="partnership-player">
        <div class="player-name-container">
            <p class="player-name ellipsis header" title="${t.name}">
                ${t.name}
            </p>
            <p class="player-role ellipsis" title="${t.role.title}">
                ${t.role.title}
            </p>
        </div>
        <div class="player-stats">
            <div class="grid-stats">
                <p class="stats-header header">${t=>t.viewModel.strings.runs}</p>
                <p class="stats-header header">${t=>t.viewModel.strings.balls}</p>
                <p class="stats ellipsis">${(null===(e=t.battingStatistics)||void 0===e?void 0:e.runsScored)||""}</p>
                <p class="stats ellipsis">${(null===(i=t.battingStatistics)||void 0===i?void 0:i.ballsFaced)||""}</p>
            </div>
        </div>
    </div>
`},w=u.qy`
    ${(0,g.z)(t=>null!=t.viewModel,f)}
`;var k=i(92079);class z extends k.a{constructor(){super(...arguments),this.setPlayerStats=(t,e)=>{if(!t)return"";if(!e)return t;return t+" ("+e+")"},this.partnershipPercentage=t=>{var e;const i=(null===(e=("batter1"===t?this.viewModel.partnershipInfo.batter1:this.viewModel.partnershipInfo.batter2).battingStatistics)||void 0===e?void 0:e.runsScored)||"",a=this.viewModel.partnershipInfo.runs||"";if(this.isEmpty(i)||this.isEmpty(a))return"0%";return 100*parseInt(i)/parseInt(a)+"%"},this.isEmpty=t=>null===t||""===t}}let F=class extends z{};F=(0,a.Cg)([(0,r.E)({name:"sports-cricket-partnership",template:w,styles:h,shadowOptions:{delegatesFocus:!0}})],F)},42792(t,e,i){i.d(e,{R7(){return g},e(){return h},kc(){return u},nH(){return v}});var a=i(57416),r=i(55153),n=i(95239),s=i(26920),l=i(48751),o=i(64187),d=i(22131),c=i(74849),p=i(50882);const v=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,o.V)("flex")} :host {
        background: ${n.p};
        outline: calc(${s.XA} * 1px) solid ${r.cu};
        border-radius: calc((${a.JU} - ${s.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${l.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${r.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${r.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${s.XA} * 1px) ${r.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${r.QG} * 1px);
        height: calc(${r.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${r.QG} * 1px);
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc(${r.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,d.mr)(c.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),g=c.A`
    ${h}
    ${v}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},66102(t,e,i){i.r(e),i.d(e,{SportsSpotlightCricketTransformer(){return d}});var a=i(23587),r=i(22341),n=i(85312),s=i(58792),l=i(79811),o=i(96950);class d extends a.Bc{constructor(){super(...arguments),this.getCricketMetaData=t=>({cardSize:this.cardSize,telemetryObject:t.telemetryObject,telemetryConstants:t.telemetryConstants,leagueId:"",matchData:[{sportsMatchData:{...t.sportsSpotlightCricketData.match}}],followedSports:t.followedSports})}async transform(t){const{cardSize:e}=t;this.cardSize=e,this.isInDarkMode=(0,l.jJ)();const i=await this.getCurrentViewModel(t);return{viewTemplate:o.qy`
                <sports-spotlight-cricket
                    :viewModel="${i}"
                ></sports-spotlight-cricket>
            `}}async getCurrentViewModel(t){try{var e;if(!t.sportsSpotlightCricketData)return void(0,r.vV)(n.Ax,"Spotlight Cricket data missing",`market=${s.T3.CurrentMarket}`,t);const{match:i,partnershipInfo:o,playerOfTheMatchInfo:d,recentMatches:c}=t.sportsSpotlightCricketData;((0,l.nD)(i)||(0,l.nD)(o)&&(0,l.nD)(d)&&(0,l.nD)(c))&&(0,r.vV)(n.Ax,"Spotlight Cricket data missing",`market=${s.T3.CurrentMarket}`,t);const{telemetryBuilder:p}=this.transformerProvider,v=i.gameCenterUrl,h=v&&(0,l.Ot)(v);let u,g,x;const m=this.getCricketMetaData(t);let f;return g=await this.transformerProvider.generateView(m,a.hi.SportsCricket),(0,l.nD)(o)||(u=this.getPartnership(t)),(0,l.nD)(d)||(f=this.getPlayerOfMatch(t)),(0,l.nD)(c)||(x=this.getRecentMatches(t)),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,telemetryTag:p.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:a.BP.SportsSpotlightCricketCard}),sportsSpotlightCricketData:t.sportsSpotlightCricketData,partnership:u,matchView:null===(e=g)||void 0===e?void 0:e.viewTemplate,clickThroughUrl:h,playerOfMatch:f,recentMatches:x}}catch(e){return void(0,r.vV)(n.Ax,"Error in transforming Spotlight Cricket data",`market=${s.T3.CurrentMarket}`,t)}}getPlayerOfMatch(t){const{telemetryBuilder:e,strings:i}=this.transformerProvider,{playerOfTheMatchInfo:r}=t.sportsSpotlightCricketData,n=(0,l.iK)(r.teamImageId||t.sportsSpotlightCricketData.match.fallbackImageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),s=r.imageId?(0,l.iK)(r.imageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced):"";return{gameFormat:t.sportsSpotlightCricketData.match.gameFormat,cardSize:this.cardSize,playerOfTheMatchInfo:r,telemetryTag:e.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:a.BP.SportsSpotlightCricketCard}),imageUrl:s,teamImageUrl:n,strings:i}}getPartnership(t){const{telemetryBuilder:e,strings:i}=this.transformerProvider,{partnershipInfo:r}=t.sportsSpotlightCricketData;return r.batter1.imageUrl=(0,l.iK)(r.batter1.imageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),r.batter2.imageUrl=(0,l.iK)(r.batter2.imageId||"",!1,this.transformerProvider.config.teamImageInfoEnhanced),r.batter1.teamImageUrl=(0,l.iK)(r.batter1.teamImageId||t.sportsSpotlightCricketData.match.fallbackImageId||"",!1,this.transformerProvider.config.suggestionImageInfo),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,partnershipInfo:r,telemetryTag:e.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:a.BP.SportsSpotlightCricketCard}),strings:{currentPartnership:i.currentPartnership,runs:i.runsScoredText,balls:i.ballsFacedText,strikeRate:i.strikeRateText}}}getParticipantIconUrl(t){return null==t?void 0:t.replace(/w=([\d]*)?&h=([\d]*)?/,"w=70&h=70")}getRecentMatches(t){const{telemetryBuilder:e,strings:i}=this.transformerProvider,{recentMatches:r}=t.sportsSpotlightCricketData;return r.forEach(t=>{var e;t.teamImageUrl=t.teamImageId?(0,l.iK)(t.teamImageId,!1,this.transformerProvider.config.suggestionImageInfo):null,t.matches=null===(e=t.matches)||void 0===e?void 0:e.slice(0,5)}),{cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,recentMatches:r,telemetryTag:e.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:a.BP.SportsSpotlightCricketCard}),strings:{recentMatches:i.recentMatches}}}}Promise.resolve().then(i.bind(i,74341)),Promise.resolve().then(i.bind(i,39606)),Promise.resolve().then(i.bind(i,32954)),Promise.resolve().then(i.bind(i,71924)),Promise.resolve().then(i.bind(i,17620))},67689(t,e,i){i.d(e,{h(){return r}});var a=i(2827);function r(){return(0,a.oh)()}},71924(t,e,i){i.r(e),i.d(e,{PlayerOfMatchCard(){return L}});var a=i(56911),r=i(92011),n=i(41123),s=i(61138),l=i(62047),o=i(48751),d=i(74849);const c="600",p=`\n    display: flex;\n    flex-direction: column;\n    font-size: ${n.K};\n    justify-content: center;\n`,v=`\n    ${p}\n    height: 30px;\n`,h=d.A`
.pom-card{display:flex;flex-direction:column;gap:16px;padding:12px 12px 10px 12px;border-radius:8px;background:var(--sports-item-background);position:relative;max-height:125px}.pom-container{display:flex;flex-direction:column;align-items:center;padding:5px 0px 0px 0px;gap:5px;height:100%}.pom-info-container{display:flex;justify-content:space-between}.pom-title{font-size:${s.k};
    font-weight: ${c};
    line-height: ${s.F};position:relative}.player-stats-container{display:flex;justify-content:space-between}.stats-sub-container{${p} align-items:flex-start}.inning-container{${p}}.container-rt,.inning2-container{${p} align-items:center}.stats-container{${v} align-items:flex-start}.stats-container-inning2,.rt-stats-container{${v} align-items:center}.rt-stats-container-inning2{${v} align-items:flex-end}.empty-allrounder-summary-stats{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;font-size:${l.t};height:30px;font-weight:400}.stats-and-sub-container{font-size:${s.k};
    font-weight: 600;
    line-height: ${s.F};display:flex;flex-direction:row;justify-content:center;align-items:center}.divider{width:1px;background:${o.l};opacity:0.05}.player-stats{display:flex;justify-content:space-between;width:244px}.player-name{font-size:${l.e};
    font-weight: ${c};
    line-height: ${n.Z};max-height:20px;width:182px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.team-name{font-size:${l.t};
    font-weight: ${c};
    line-height: ${l.e}}.summary-stats-left{font-size:${s.k};
    font-weight: ${c};
    line-height: ${s.F};
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: space-between;
}

.summary-stats{
    font-size: ${s.k};
    font-weight: 600;
    line-height: ${s.F};
    display: flex;
    flex-direction: row;
    text-align: center;
    width: 244px;
    justify-content: space-between;
}

.detailed-summary-stats{
    font-size: ${s.k};
    font-weight: 600;
    line-height: ${s.F};
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    flex: 2;
}

.empty-summary-stats{
    font-size: ${l.t};
    font-weight: 400;
    line-height: ${s.F};display:flex;flex-direction:row;justify-content:center;align-items:center}.summary-stats-right{font-size:${s.k};font-weight:600;line-height:20px;display:flex;flex-direction:column;align-items:flex-end}.summary-stats-label{font-size:${l.t};
    font-weight: 400;
    line-height: ${l.e};text-align:center}.summary-stats-and-label{font-size:${s.k};
    font-weight: 600;
    line-height: ${l.e};text-align:center}.subtext-label{font-size:${l.t};
    font-weight: 400;
    line-height: ${l.e}}.player-role{font-size:${l.t};
    font-weight: 400;
    line-height: ${l.e}}.player-details-container{display:flex;flex-direction:column}.team-details-container{display:flex;gap:4px}.sport-with-subtext-title{text-wrap:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:justify;width:90px;font-weight:600;font-size:${s.k}}.team-image{width:16px;height:16px}.player-image{width:50px;height:50px}`;var u=i(96950),g=i(69259),x=i(23587);const m=u.qy`
    <div class="player-title-container">
        <div class="player-name">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e?void 0:e.name}}
        </div>
        <div class="player-role">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.role)||void 0===e?void 0:e.title}}
        </div>
    </div>
`,f=u.qy`
    <div class="summary-stats">
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.bowlingStatistics)||void 0===e?void 0:e.oversBowled}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.oversBowledText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.bowlingStatistics)||void 0===e?void 0:e.maidenOvers}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.maidenOversText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.bowlingStatistics)||void 0===e?void 0:e.runsConceded}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.runsConcededText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.bowlingStatistics)||void 0===e?void 0:e.wicketsTaken}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.wicketsTakenText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.bowlingStatistics)||void 0===e?void 0:e.economyRate}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.economyRateText}}</span>
        </div>
    </div>
`,b=u.qy`
    <div class="summary-stats">
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.battingStatistics)||void 0===e?void 0:e.runsScored}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.runsScoredText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.battingStatistics)||void 0===e?void 0:e.ballsFaced}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.ballsFacedText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.battingStatistics)||void 0===e?void 0:e.foursHit}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.foursHitText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.battingStatistics)||void 0===e?void 0:e.sixesHit}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.sixesHitText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.battingStatistics)||void 0===e?void 0:e.strikeRate}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.strikeRateText}}</span>
        </div>
    </div>
`,y=u.qy`
    <div class="summary-stats">
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.battingStatistics)||void 0===e?void 0:e.runsScored}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.runsScoredText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.battingStatistics)||void 0===e?void 0:e.ballsFaced}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.ballsFacedText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            <span class="summary-stats-and-label">&</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.bowlingStatistics)||void 0===e?void 0:e.wicketsTaken}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.wicketsTakenText}}</span>
        </div>
        <div class="divider"></div>
        <div class="stats-sub-container">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.bowlingStatistics)||void 0===e?void 0:e.runsConceded}}
            <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.runsConcededText}}</span>
        </div>
    </div>
`,$=u.qy`
    <div class="player-stats">
        ${t=>{var e;return null!==(e=t.viewModel)&&void 0!==e&&null!==(e=e.playerOfTheMatchInfo)&&void 0!==e&&null!==(e=e.battingStatistics)&&void 0!==e&&e.battingSummary?b:null}}
        ${t=>{var e;return null!==(e=t.viewModel)&&void 0!==e&&null!==(e=e.playerOfTheMatchInfo)&&void 0!==e&&null!==(e=e.bowlingStatistics)&&void 0!==e&&e.bowlingSummary?f:null}}
    </div>
`,w=u.qy`
    <div class="player-stats">
        ${y}
    </div>
`,k=u.qy`
    <div class="player-stats">
        ${t=>{var e,i;return null!==(e=t.viewModel)&&void 0!==e&&null!==(e=e.playerOfTheMatchInfo)&&void 0!==e&&e.battingStatistics&&null!==(i=t.viewModel)&&void 0!==i&&null!==(i=i.playerOfTheMatchInfo)&&void 0!==i&&i.bowlingStatistics?w:$}}
    </div>
`,z=(t,e)=>u.qy`
    <div class=${e?"container-rt":"inning-container"}>
        ${e=>e.getBattingStatsRunsScored(t)}
        <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.runsScoredText}}</span>
    </div>
    <div class="divider"></div>
    <div class=${e?"inning-container":"inning2-container"}>
        ${e=>e.getBattingStatsBallsFaced(t)}
        <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.ballsFacedText}}</span>
    </div>
`,F=(t,e)=>u.qy`
    <div class=${e?"container-rt":"inning-container"}>
        ${e=>e.getBowlingStatsWicketsTaken(t)}
        <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.wicketsTakenText}}</span>
    </div>
    <div class="divider"></div>
    <div class=${e?"inning-container":"inning2-container"}>
        ${e=>e.getBowlingStatsRunsConceded(t)}
        <span class="summary-stats-label">${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.runsScoredText}}</span>
    </div>
`,_=t=>u.qy`
    <div class="empty-summary-stats">
        <div class="placeholder-container">${t}</div>
    </div>
`,M=u.qy`
    <div class="player-stats">
        <div class="summary-stats">
            ${t=>{var e;return t.isBattingStatsAvailable("1")?z("1",!1):_(null===(e=t.viewModel)||void 0===e?void 0:e.strings.didNotBat)}}
            <div class="divider"></div>
            <div class="stats-and-sub-container">
                <span class="summary-stats-and-label">&</span>
            </div>
            <div class="divider"></div>
            ${t=>{var e;return t.isBattingStatsAvailable("2")?z("2",!0):_(null===(e=t.viewModel)||void 0===e?void 0:e.strings.didNotBat)}}
        </div>
    </div>
`,j=u.qy`
    <div class="player-stats">
        <div class="summary-stats">
            ${t=>{var e;return t.isBowlingStatsAvailable("1")?F("1",!1):_(null===(e=t.viewModel)||void 0===e?void 0:e.strings.didNotBowl)}}
            <div class="divider"></div>
            <div class="stats-and-sub-container">
                <span class="summary-stats-and-label">&</span>
            </div>
            <div class="divider"></div>
            ${t=>{var e;return t.isBowlingStatsAvailable("2")?F("2",!1):_(null===(e=t.viewModel)||void 0===e?void 0:e.strings.didNotBowl)}}
        </div>
    </div>
`,S=(t,e,i)=>u.qy`
    <div class="${i?"rt-":""}stats-container${e?"-inning2":""}">
        ${t}
    </div>
`,C=t=>u.qy`
    <div class="empty-allrounder-summary-stats">
        <div class="placeholder-container">${t}</div>
    </div>
`,I=u.qy`
    <div class="player-stats">
        <div class="summary-stats">
            ${t=>{var e;return t.isBattingStatsAvailable("1")?S(t.getBattingStatsSummary("1"),!1,!1):C(null===(e=t.viewModel)||void 0===e||null===(e=e.strings)||void 0===e?void 0:e.didNotBat)}}
            <div class="divider"></div>
            ${t=>{var e;return t.isBowlingStatsAvailable("1")?S(t.getBowlingStatsSummary("1"),!1,!0):C(null===(e=t.viewModel)||void 0===e?void 0:e.strings.didNotBowl)}}
            <div class="divider"></div>
            <div class="inning-container">
                <span class="summary-stats-and-label">&</span>
            </div>
            <div class="divider"></div>
            ${t=>{var e;return t.isBattingStatsAvailable("2")?S(t.getBattingStatsSummary("2"),!0,!1):C(null===(e=t.viewModel)||void 0===e?void 0:e.strings.didNotBat)}}
            <div class="divider"></div>
            ${t=>{var e;return t.isBowlingStatsAvailable("2")?S(t.getBowlingStatsSummary("2"),!0,!0):C(null===(e=t.viewModel)||void 0===e?void 0:e.strings.didNotBowl)}}
        </div>
    </div>
`,T=u.qy`
<div class="player-stats">
    ${t=>{var e;return(t=>{switch(t){case x.pA.allRounder:return I;case x.pA.batter:return M;case x.pA.bowler:return j;default:return I}})((null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.role)||void 0===e?void 0:e.primaryRole)||"")}}    
</div>
`,P=u.qy`
    <div class="player-stats-container">
        <div class="player-stats">
            ${t=>{var e,i;return((t,e)=>{if(e===x.S_.test)return T;switch(t){case x.pA.allRounder:return k;case x.pA.batter:return B;case x.pA.bowler:return D;default:return k}})((null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.role)||void 0===e?void 0:e.primaryRole)||"",(null===(i=t.viewModel)||void 0===i?void 0:i.gameFormat)||"")}}
        </div>
    </div>
`,D=u.qy`
    <div class="player-stats-container">
        <div class="player-detailed-stats">
            ${f}
        </div>
    </div>
`,B=u.qy`
    <div class="player-stats-container">
        <div class="player-detailed-stats">
            ${b}
        </div>
    </div>
`,O=u.qy`
    <div class="player-image-container">
        <img class="player-image" src=${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.imageUrl}} alt=${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e?void 0:e.name}}></img>
    </div>
`,A=u.qy`
    <div class="team-details-container">
        <img class="team-image" src=${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.teamImageUrl}} alt=${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e?void 0:e.teamShortName}}></img>
        <span class="team-name">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e?void 0:e.teamShortName}}
        </span>
    </div>
`,U=u.qy`
    <div class="player-details-container">
        ${A}
        ${m}
    </div>
`,E=u.qy`
    <div class="pom-info-container">
        ${U}
        ${t=>{var e;return null!==(e=t.viewModel)&&void 0!==e&&e.imageUrl?O:null}}
    </div>
`,R=u.qy`
    <div class="pom-container">
        <span class="pom-title">
            ${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.strings.playerOfTheMatchHeader}}
        </span>
        <div class="pom-card" data-t="${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.telemetryTag}}">
            ${E}
            ${P}
        </div>
    </div>
`,V=u.qy`
    ${(0,g.z)(t=>null!=t.viewModel,R)}
`;var Z=i(92079);class H extends Z.a{constructor(){super(...arguments),this.isBattingStatsAvailable=t=>{var e;return!(null===(e=this.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.statistics)||void 0===e||null===(e=e.batting)||void 0===e||!e.find(e=>e.inningNumber===t))},this.getBattingStatsRunsScored=t=>{var e;return(null===(e=this.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.statistics)||void 0===e||null===(e=e.batting)||void 0===e||null===(e=e.find(e=>e.inningNumber===t))||void 0===e?void 0:e.runsScored)||""},this.getBattingStatsBallsFaced=t=>{var e;return(null===(e=this.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.statistics)||void 0===e||null===(e=e.batting)||void 0===e||null===(e=e.find(e=>e.inningNumber===t))||void 0===e?void 0:e.ballsFaced)||""},this.getBattingStatsSummary=t=>{var e;return(null===(e=this.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.statistics)||void 0===e||null===(e=e.batting)||void 0===e||null===(e=e.find(e=>e.inningNumber===t))||void 0===e?void 0:e.battingSummary)||""},this.getBowlingStatsWicketsTaken=t=>{var e;return(null===(e=this.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.statistics)||void 0===e||null===(e=e.bowling)||void 0===e||null===(e=e.find(e=>e.inningNumber===t))||void 0===e?void 0:e.wicketsTaken)||""},this.getBowlingStatsRunsConceded=t=>{var e;return(null===(e=this.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.statistics)||void 0===e||null===(e=e.bowling)||void 0===e||null===(e=e.find(e=>e.inningNumber===t))||void 0===e?void 0:e.runsConceded)||""},this.getBowlingStatsSummary=t=>{var e;return(null===(e=this.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.statistics)||void 0===e||null===(e=e.bowling)||void 0===e||null===(e=e.find(e=>e.inningNumber===t))||void 0===e?void 0:e.bowlingSummary)||""},this.isBowlingStatsAvailable=t=>{var e;return!(null===(e=this.viewModel)||void 0===e||null===(e=e.playerOfTheMatchInfo)||void 0===e||null===(e=e.statistics)||void 0===e||null===(e=e.bowling)||void 0===e||!e.find(e=>e.inningNumber===t))}}}let L=class extends H{};L=(0,a.Cg)([(0,r.E)({name:"player-of-match-card",template:V,styles:h})],L)},74341(t,e,i){i.r(e),i.d(e,{SportsSpotlightCricket(){return $}});var a=i(56911),r=i(92079);class n extends r.a{}var s=i(92011),l=i(74849),o=i(22131),d=i(48751);const c=l.A` .sports-spotlight-content{color:${d.l};
    }
`,p=(0,o.G2)(c),v=l.A` .sports-spotlight-content{text-decoration:none;color:${d.l};display:grid;position:relative;z-index:1;height:100%;margin-top:2px;grid-auto-rows:min-content}._1x_1y.sports-spotlight-content{outline:none}`.withBehaviors(p);var h=i(96950),u=i(69259);const g=h.qy`
<sports-cricket-partnership
    :viewModel="${t=>t.viewModel.partnership}"
></sports-cricket-partnership>
`,x=h.qy`
 ${h.qy`${t=>t.viewModel.matchView}`}
`,m=h.qy`
<player-of-match-card
    :viewModel="${t=>t.viewModel.playerOfMatch}"
    ></player-of-match-card>
`,f=h.qy`
<sports-cricket-recent-matches
    :viewModel="${t=>t.viewModel.recentMatches}"
></sports-cricket-recent-matches>
`,b=h.qy`
    <a
        class="sports-spotlight-content ${t=>t.viewModel.cardSize}"
        href="${t=>t.viewModel.clickThroughUrl}"
        target="_blank"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        ${x}
        ${m}
        ${(0,u.z)(t=>"_1x_1y"!==t.viewModel.cardSize,g)}
        ${f}
    </a>
`,y=h.qy`
    ${(0,u.z)(t=>null!=t.viewModel,b)}
`;let $=class extends n{};$=(0,a.Cg)([(0,s.E)({name:"sports-spotlight-cricket",template:y,styles:v,shadowOptions:{delegatesFocus:!0}})],$)},92079(t,e,i){i.d(e,{a(){return s}});var a=i(56911),r=i(92011),n=i(31525);let s=class extends r.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};s=(0,a.Cg)([n.x],s)},99657(t,e,i){i.d(e,{D(){return s},I(){return n}});var a=i(45755);const{create:r}=a.G,n=r("sloppy-click-z-index",1),s=r("click-z-index",1)}}]);