"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-leaderboard"],{67398(t,e,i){i.r(e),i.d(e,{SportsLeaderboard(){return P}});var l=i(56911),a=i(84564);class s extends a.z{}var n=i(92011),o=i(48751),r=i(86856),d=i(12640),p=i(74849),h=i(22131);const c=p.A` .lb-content{background:var(--sports-item-background)}.lb-game-icon{filter:invert(1)}.formular1-data .lb-game-icon{-webkit-filter:invert(1);filter:invert(1)}.formular1-data .lb-game-icon{-webkit-filter:invert(1);filter:invert(1)}`,g=p.A` .more-actions{right:16px;left:auto}.sports-wc-st-suggest-icon{float:left}`,b=p.A` .more-actions{left:16px;right:auto}.sports-wc-st-suggest-icon{float:right}.lb-content{margin:0 0 0 16px}.lb-game-icon{margin:auto 0px auto 8px}.golf-data .lb-date{float:left}`,v=p.A` .lb-header,.lb-data,.lb-content,.lb-game-list,.lb-content-list{display:flex;align-items:center;width:100%;text-decoration:none;color:${o.l}}.lb-data{box-sizing:border-box;flex-direction:column;height:100%;z-index:1;position:relative}.lb-content{flex-direction:column;align-items:stretch}.golf-data .lb-content{width:100%}.golf-data .lb-header{display:block;padding-bottom:6px}.lb-header{color:${o.l};font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height)}.lb-sports-liveicon{padding:1px 6px;width:32px;height:16px;background:#FF0000;color:#FFFFFF;border-radius:3px;text-transform:uppercase;font-weight:600;font-size:10px;line-height:14px;text-align:center}.lb-header span{margin:0 2px}.lb-header img{padding-top:4px}.lb-header-title{font-weight:bold}.golf-data .lb-header-title{max-width:210px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500}.lb-date{width:50px}.golf-data .lb-date{float:right;text-align:end}.lb-line{display:flex;padding:6px 0 6px 6px;font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height);width:100%}.golf-data .lb-line{display:grid;grid-template-columns:24px 30px 144px 60px;padding:6px 0px}.golf-data .lb-pre .lb-line{grid-template-columns:30px 168px 60px}.lb-line span{padding:0 4px}.lb-line .winner-tag{padding:6px 0}.lb-winner{color:${o.l}}.lb-real{color:#C80000}.lb-participant{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600}.lb-participant-no{font-style:italic;font-size:14px;line-height:20px;font-weight:900;text-align:left;color:#FFFFFF;text-shadow:-1px -1px 1.25px rgba(0,0,0,0.83),1px -1px 1.25px rgba(0,0,0,0.83),-1px 1px 1.25px rgba(0,0,0,0.83),1px 1px 1.25px rgba(0,0,0,0.83)}.lb-score{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:60px;margin-left:auto;margin-right:4px;max-width:60px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:end}.lb-game-list{flex-direction:column;align-items:stretch;width:100%}.lb-game{display:flex;padding:8px;margin:4px 0;border-radius:6px;background:var(--sports-item-background);color:${o.l};text-decoration:none}.lb-game-icon{width:28px;height:28px;margin:auto 8px auto 0px}.lb-rank{width:15px}.lb-country-flag{width:22px;height:20px;margin:auto 8px auto 0px}.lb-game-info{width:158px}.lb-game-subheader,.lb-game-name{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-line-height)}.lb-game-name{font-weight:500}.lb-game-detail{text-align:center;color:${o.l};float:right;width:64px;margin:auto;font-size:var(--type-ramp-minus-1-font-size);line-height:var(--type-ramp-minus-1-line-height)}.lb-game-detail > div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.lb-game-time,.lb-winner{font-weight:bold}`.withBehaviors(new r.t(g,b),new d.N(null,c),(0,h.mr)(p.A`
            :host: 
                forced-color-adjust: auto;
            }
        `));var u=i(96950),x=i(69259),m=i(39957),f=i(58792);const $=u.qy`${t=>t.viewModel.matchContext.getLiveGameLogo()}`,w=u.qy`${t=>t.viewModel.matchContext.getNonLiveGameLogo()}`,y=u.qy`
    <img class="lb-country-flag" role="presentation" 
        src="${(t,e)=>null==t?void 0:t.countryFlagImageId}"
    />
`,k=u.qy`
    <span class="lb-participant-no ${(t,e)=>e.parent.viewModel.matchContext.isWinner(t)?"lb-winner":""}" 
        title=${(t,e)=>e.parent.viewModel.matchContext.getIdentifier(t)}>${(t,e)=>`#${e.parent.viewModel.matchContext.getIdentifier(t)}`}
    </span>
`,F=u.qy`
    <span>-</span>
    <span class="lb-date">
        ${t=>t.viewModel.matchContext.getGameDate(t.viewModel.matchData[0])}
    </span>
`,z=u.qy`
    <span>
        ${(0,x.z)(t=>t.viewModel.matchContext.isGameLive(t.viewModel.matchData[0]),$)}
        ${(0,x.z)(t=>!t.viewModel.matchContext.isGameLive(t.viewModel.matchData[0]),w)}
    </span>
`,D=u.qy`
    <span class="lb-sports-liveicon">
        ${t=>t.viewModel.strings.sportsLive}
    </span>
`,S=u.qy`
    ${(0,x.z)(t=>t.viewModel.matchContext.isLeaderBoard(),u.qy`
        <div class="lb-header">
            ${(0,x.z)(t=>!t.viewModel.matchContext.displayGenericLiveGameIcon(t.viewModel.matchData[0])&&t.viewModel.matchContext.displayGameDate(),z)}
            <span class="lb-header-title">
                ${t=>t.viewModel.matchContext.getGameProgress(t.viewModel.strings.sportsStateFinal,t.viewModel.strings.round)}
            </span>
            ${(0,x.z)(t=>t.viewModel.matchContext.displayGenericLiveGameIcon(t.viewModel.matchData[0]),D)}
            ${(0,x.z)(t=>t.viewModel.matchContext.displayGameDate(),F)}
            ${(0,x.z)(t=>!t.viewModel.matchContext.displayGameDate(),u.qy`<span class="lb-date">${t=>t.viewModel.matchContext.isPreGame(t.viewModel.matchData[0])?t.viewModel.strings.teeTime:t.viewModel.strings.total}</span>`)}
        </div>`)}
`,C=u.qy`
    <span 
        class="lb-rank">${(t,e)=>(null==t?void 0:t.rank)||""}
    </span>
`,M=u.qy`
    <div class="lb-line" key=${(t,e)=>e.parent.viewModel.matchContext.getIdentifier(t)}>
        ${(0,x.z)((t,e)=>!e.parent.viewModel.matchContext.isPreGame(e.parent.viewModel.matchData[0]),C)}
        ${(0,x.z)((t,e)=>e.parent.viewModel.matchContext.displayParticpantCountryFlag(),y)}
        <span class="lb-participant ${(t,e)=>e.parent.viewModel.matchContext.isWinner(t)?"lb-winner":""}" title=${(t,e)=>e.parent.viewModel.matchContext.getParticipantName(t)}>
            ${(t,e)=>e.parent.viewModel.matchContext.getParticipantName(t)}
        </span>
        ${(0,x.z)((t,e)=>e.parent.viewModel.matchContext.displayParticpantScoreTag(),k)}
        <span class="lb-score ${(t,e)=>e.parent.viewModel.matchContext.isWinner(t)?"lb-winner":""}" title=${(t,e)=>e.parent.viewModel.matchContext.getParticipantScore(e.parent.viewModel.matchData[0],t)}>
            ${(t,e)=>e.parent.viewModel.matchContext.getParticipantScore(e.parent.viewModel.matchData[0],t,e.parent.viewModel.strings.leader,e.parent.viewModel.strings.pointsAbbreviation,e.parent.viewModel.strings.secondsAbbreviation)}
        </span>
        ${(0,x.z)((t,e)=>e.parent.viewModel.matchContext.isWinner(t)&&0===e.index,u.qy`
            <img
                class="winner-tag"
                src="${f.T3.StaticsUrl}latest/sports/icons/SportsWinnerTag${(t,e)=>e.parent.viewModel.isDarkMode?"Light":"Dark"}.svg">
            `)}
    </div>
`,O=u.qy`
    <a class="lb-game"
        href=${(t,e)=>(null==t?void 0:t.matchClickthroughUrl)||void 0}
        target="${(t,e)=>e.parent.viewModel.linkTarget}"
        data-t="${(t,e)=>e.parent.viewModel.telemetryTag}"
    >
        <img class="lb-game-icon"
            role="presentation"
            src="${(t,e)=>e.parent.viewModel.matchContext.getGameImageUrl(t)}"
        />
        <div class="lb-game-info">
            <div class="lb-game-name" title="${(t,e)=>e.parent.viewModel.matchContext.getGameName(t)}">
                ${(t,e)=>e.parent.viewModel.matchContext.getGameName(t)}
            </div>
            <div class="lb-game-subheader ${(t,e)=>e.parent.viewModel.matchContext.isGameSubheaderBold(t)?"lb-winner":""}" title="${(t,e)=>e.parent.viewModel.matchContext.getGameSubheader(t)}">
                ${(t,e)=>e.parent.viewModel.matchContext.getGameSubheader(t)}
            </div>
        </div>
        <div class="lb-game-detail">
            <div class="lb-game-time ${(t,e)=>e.parent.viewModel.matchContext.isGameLive(t)?"lb-real":""}">
                ${(t,e)=>e.parent.viewModel.matchContext.getGameDetails(t,e.parent.viewModel.strings.sportsStateFinal).timeOrState}
            </div>
            <div class="lb-game-state">
                ${(t,e)=>e.parent.viewModel.matchContext.getGameDetails(t,e.parent.viewModel.strings.sportsStateFinal).channelOrDate}
            </div>
        </div>
    </a>
`,T=u.qy`
    <div class="lb-game-list">
        ${(0,m.ux)(t=>t.viewModel.matchData.slice(0,t.viewModel.showParticipantsCount),O)}
    </div>
`,_=u.qy`
    <a
        class="lb-content${t=>t.viewModel.matchContext.isPreGame(t.viewModel.matchData[0])?" lb-pre":""}"
        href=${t=>{var e;return(null===(e=t.viewModel.matchData[0])||void 0===e?void 0:e.matchClickthroughUrl)||void 0}}
        target="${t=>t.viewModel.linkTarget}"
        data-t="${(t,e)=>t.viewModel.telemetryTag}"
    >
        ${(0,m.ux)(t=>t.viewModel.matchContext.getParticipantsList(t.viewModel.showParticipantsCount,t.viewModel.matchData[0]),M)}
    </a>
`,L=u.qy`
    <div class="${t=>t.viewModel.dataClassName}">
        ${(0,x.z)(t=>t.viewModel.matchContext.isLeaderBoard(),S)}
        ${(0,x.z)(t=>t.viewModel.matchContext.isLeaderBoard(),_)}
        ${(0,x.z)(t=>!t.viewModel.matchContext.isLeaderBoard(),T)}
    </div>
`,B=u.qy`
    ${(0,x.z)(t=>null!=t.viewModel,L)}
`;let P=class extends s{};P=(0,l.Cg)([(0,n.E)({name:"sports-leaderboard",template:B,styles:v,shadowOptions:{delegatesFocus:!0}})],P)},84564(t,e,i){i.d(e,{z(){return n}});var l=i(56911),a=i(60815),s=i(92011);class n extends s.L{}(0,l.Cg)([a.sH],n.prototype,"viewModel",void 0)},99016(t,e,i){i.r(e),i.d(e,{SportsLeaderboardTransformer(){return g}});var l=i(23587),a=i(79811),s=i(97266),n=i(58792),o=i(96950);const r=`${n.T3.StaticsUrl}latest/icons-wc/icons/SportsMotorInprogress.svg`,d=`${n.T3.StaticsUrl}latest/icons-wc/icons/SportsMotorComplete.svg`;class p{constructor(t,e){this.getIdentifier=t=>(null==t?void 0:t.name)||"",this.getLiveGameLogo=()=>o.qy``,this.getNonLiveGameLogo=()=>o.qy``,this.getParticipantName=t=>(null==t?void 0:t.name)||"",this.isWinner=(t,e)=>!(null==t||!t.isWinner||!this.isPostGame(e)),this.isGameSubheaderBold=t=>!1,this.isGameLive=t=>(null==t?void 0:t.gameStateCatetory)===l.Xp.inprogressGame,this.isPostGame=t=>(null==t?void 0:t.gameStateCatetory)===l.Xp.postGame,this.isPreGame=t=>(null==t?void 0:t.gameStateCatetory)===l.Xp.preGame,this.getGameImageUrl=t=>(null==t?void 0:t.tournamentImageUrl)||"",this.getGameName=t=>(null==t?void 0:t.name)||"",this.getGameSubheader=t=>(null==t?void 0:t.locationName)||"",this.displayParticpantCountryFlag=()=>this.isLeaderBoard(),this.displayParticpantScoreTag=()=>!1,this.displayGenericLiveGameIcon=t=>this.isGameLive(t),this.displayGameDate=()=>!1,this.getGameProgress=(t,e)=>{const i=this.sportMatchData&&this.sportMatchData[0];return i?i.gameStateCatetory===l.Xp.postGame?`${i.endDateTime||""} | ${t}`:i.gameStateCatetory===l.Xp.inprogressGame?i.round?`${e} ${i.round} | `:"":i.round?`${e} ${i.round} | ${i.startWeekDay} · ${i.startDateTime}`:`${i.startWeekDay} · ${i.startDateTime}`:""},this.getGameDate=t=>t?t.gameStateCatetory===l.Xp.postGame?(null==t?void 0:t.endDateTime)||"":(t.currentDateTime||0)>(t.gameDate||0)&&(t.currentDateTime||0)<=(t.endDateTime||0)?t.currentDateTime||"":t.gameDate||"":"",this.isLeaderBoard=()=>!!this.sportCardData&&this.sportCardData.dataType===l.VO.leaderboard,this.getParticipantsList=(t,e)=>e&&e.participants&&e.participants.slice(0,t)||[],this.getParticipantScore=(t,e)=>(null==t?void 0:t.gameStateCatetory)===l.Xp.preGame?(null==e?void 0:e.teetime)||"":e?`${e.total||""}`:"",this.getGameDetails=(t,e)=>{const i=t&&t.gameDate&&(new Date).getDate()===new Date(t.gameDate).getDate();let a,s;switch(t.gameStateCatetory){case l.Xp.preGame:a=i?t.gameStartTime:t.gameDate,s=t.tvChannel;break;case l.Xp.inprogressGame:a=t.round,s=t.tvChannel;break;case l.Xp.postGame:a=e,s=t.endDateTime}return{timeOrState:a||"",channelOrDate:s||""}},this.sportCardData=t,this.sportMatchData=e}}class h{constructor(t,e){var i=this;this.getIdentifier=t=>(null==t?void 0:t.driverNumber)||"",this.getLiveGameLogo=()=>o.qy`<div><img src=${()=>r}></div>`,this.getNonLiveGameLogo=()=>o.qy`<div><img src=${()=>d}></div>`,this.getParticipantName=t=>(null==t?void 0:t.driverName)||"",this.isWinner=t=>(null==t?void 0:t.isWinner)||"0"===(null==t?void 0:t.timeDifferenceFromLeader),this.getGameProgress=function(){var t;return i.sportMatchData&&i.sportMatchData.length&&(null===(t=i.sportMatchData[0])||void 0===t?void 0:t.laps)||""},this.isGameLive=t=>(null==t?void 0:t.gameStateCatetory)===l.Xp.inprogressGame,this.isPreGame=t=>(null==t?void 0:t.gameStateCatetory)===l.Xp.preGame,this.isPostGame=t=>(null==t?void 0:t.gameStateCatetory)===l.Xp.postGame,this.getGameImageUrl=t=>(null==t?void 0:t.raceImageUrl)||"",this.isGameSubheaderBold=t=>this.isPostGame(t)&&!!this.getGameWinner(t),this.getGameName=t=>(null==t?void 0:t.raceName)||"",this.getGameSubheader=t=>{let e=t.locationName;if(this.isPostGame(t)){const i=this.getGameWinner(t);e=i&&i.driverName?`${i.rank||"1"}. ${i.driverName||""}`:e}return e||""},this.getGameWinner=t=>t.participants&&t.participants.filter(t=>t.isWinner)[0],this.getGameDate=t=>(null==t?void 0:t.gameDate)||"",this.isLeaderBoard=()=>!!this.sportCardData&&this.sportCardData.dataType===l.oL.singleRace,this.getParticipantsList=(t,e)=>(null==e?void 0:e.participants)&&e.participants.slice(0,t)||[],this.displayParticpantCountryFlag=()=>!1,this.displayParticpantScoreTag=()=>this.isLeaderBoard(),this.displayGenericLiveGameIcon=t=>!1,this.displayGameDate=()=>!0,this.getParticipantScore=(t,e,i,l,a)=>{let s="";return e?(s=this.isGameLive()?e.isWinner?i:`-${e.timeDifferenceFromLeader||""}${a}`:`${e.points||"-"} ${l}`,s||""):s},this.getGameDetails=(t,e)=>{const i=t&&t.gameDate&&(new Date).getDate()===new Date(t.gameDate).getDate();let a,s;switch(t.gameStateCatetory){case l.Xp.preGame:a=i?t.gameStartTime:t.gameDate,s=t.tvChannel;break;case l.Xp.inprogressGame:a=t.laps,s=t.tvChannel;break;case l.Xp.postGame:a=e,s=t.gameDate}return{timeOrState:a||"",channelOrDate:s||""}},this.sportCardData=t,this.sportMatchData=e}}class c{static getLeaderBoardSportContext(t,e){const i=t&&t.dataType;return i===l.VO.leaderboard||i===l.VO.scheduledTournaments?new p(t,e):new h(t,e)}}class g extends l.Bc{constructor(){super(...arguments),this.getParticipantsCount=(t,e)=>{const i=null==e?void 0:e.dataType;switch(t){case"_1x_2y":case"medium":return i===l.oL.raceList||i===l.v1.MotorSportsRaceList?3:6;case"_1x_3y":case"large":return i===l.oL.raceList||i===l.v1.MotorSportsRaceList?6:9;default:return 1}},this.getDataClassName=t=>{const e=null==t?void 0:t.dataType,i=e===l.VO.leaderboard||e===l.VO.scheduledTournaments||e===l.v1.GolfSchedule?" golf-data":"";return"b7a76276-375a-718b-52d9-49eae9b263a4"===(null==t?void 0:t.primaryEntityId)?"lb-data formular1-data":"lb-data"+i}}async transform(t){const e=this.getViewModel(t);return{viewTemplate:o.qy`
                <sports-leaderboard
                    :viewModel="${e}"
                ></sports-leaderboard>`}}getViewModel(t){var e;const i=(null===(e=t.matchData)||void 0===e?void 0:e.map(e=>{let i;if(null!=e&&e.sportsMatchData){const t=e.sportsMatchData;t.gameCenterUrl&&(t.matchClickthroughUrl=(0,a.Ot)(t.gameCenterUrl)),t.gameStateCatetory="string"!=typeof t.gameState?(0,a.m5)(t.gameState.state):t.gameStateCatetory,i=(0,a.yn)(t.gameStartDateTime),t.gameDate=(0,a.AL)(i,n.T3.CurrentMarket),t.gameStartTime=(t.gameStartDateTimeIsToBeAnnounced?null:(0,a.ry)(i,n.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,"string"!=typeof t.gameState&&(t.gamePeriodAndClock=(0,a.PH)(t.gameState))}if(t.cardData.dataType===l.v1.GolfSchedule||t.cardData.dataType===l.v1.GolfLeaderBoard){var o;const t=null==e?void 0:e.sportsMatchData;null===(o=t.participants)||void 0===o||o.forEach(t=>{t.total=t.total||t.points,t.countryFlagImageId=t.countryFlagImageId||(0,a.iK)(t.imageId,!1,this.transformerProvider.config.suggestionImageInfo),t.isWinner=Boolean(t.isWinner),t.teetime=t.teetime&&"-"!==t.teetime?(0,a.ry)(new Date(t.teetime),n.T3.CurrentMarket):"-"}),t.startWeekDay=(new s.e).localizedWeekday(i,n.T3.CurrentMarket),t.endDateTime=(0,a.AL)((0,a.yn)(t.gameEndDateTime),n.T3.CurrentMarket),t.startDateTime=(0,a.AL)(i,n.T3.CurrentMarket),t.currentDateTime=(0,a.AL)(new Date,n.T3.CurrentMarket),t&&(t.tournamentImageUrl=t.tournamentImageUrl||(0,a.iK)(t.imageId,!1,this.transformerProvider.config.suggestionImageInfo))}else if(t.cardData.dataType===l.v1.MotorSportsRaceList||t.cardData.dataType===l.v1.MotorSportsSingleRace){var r;const t=null==e?void 0:e.sportsMatchData;t&&(t.raceImageUrl=(0,a.iK)(t.imageId,!1,this.transformerProvider.config.suggestionImageInfo)),null===(r=t.participants)||void 0===r||r.forEach(t=>{t.isWinner=Boolean(t.isWinner)})}return e.sportsMatchData&&"string"!=typeof e.sportsMatchData.gameState?(0,a.m5)(e.sportsMatchData.gameState.state):e.sportsMatchData.gameStateCatetory,null==e?void 0:e.sportsMatchData}))||[],o=c.getLeaderBoardSportContext(t.cardData,i),r=t.cardSize;return{dataClassName:this.getDataClassName(t&&t.cardData),linkTarget:"_blank",matchContext:o,matchData:i,showParticipantsCount:this.getParticipantsCount(r,t&&t.cardData),strings:{...this.transformerProvider.strings},isDarkMode:(0,a.jJ)(),telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:l.BP.Game})}}}Promise.resolve().then(i.bind(i,67398))}}]);