(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["shopping-augment-card"],{11236(t,e,r){"use strict";r.d(e,{d(){return n}});var i=r(89167);class n extends i.X9{static buildAbsoluteUrl(t,e,r,n,a,o,s){let l=arguments.length>7&&void 0!==arguments[7]&&arguments[7],c=arguments.length>8?arguments[8]:void 0,d=arguments.length>9?arguments[9]:void 0,u=arguments.length>10?arguments[10]:void 0;const p=new URLSearchParams;r&&p.set("pid",r),e&&p.set(i.Ts.ClickSourceQueryParam,e),n&&n.length>0&&a&&a.length>0&&(p.set(i.Ts.ModalCarouselOfferIdsQueryParam,n.join(",")),p.set(i.Ts.ModalCarouselImageIdsQueryParam,a.join(","))),s&&s.length>0&&p.set(i.Ts.ModalCarouselECIdsQueryParam,s.join(",")),o&&p.set("title",o),c&&p.set(i.Ts.gameFirstPositionQueryParam,"1"),u&&p.set(i.Ts.itemQueryParam,"flights:"+u),d&&d.forEach(t=>{p.append(t,"1")});const h=(0,i.wW)(p,l);return`${this.getSchemeAndDomain()}/${t}/shopping${h?"?"+h:""}`}static buildAbsoluteUrlForProng1(t,e){return`${this.getSchemeAndDomain()}/${t}/shopping?pid=${e}`}}},26443(t,e,r){"use strict";r.r(e),r.d(e,{AugmentCarouselCardTemplate(){return M},ShoppingAugmentCard(){return k},ShoppingAugmentCardStyles(){return it},ShoppingAugmentCardTemplate(){return G},ToolingInfo(){return nt}});var i,n=r(65614),a=r(69966),o=r(30326),s=r(56911),l=r(60815),c=r(12680),d=r(39671),u=r(54229),p=r(93552),h=r(48847),g=r(89167),v=r(85349),m=r(19359);!function(t){t.PreviousFlipper="previousslidearrow",t.NextFlipper="nextslidearrow",t.CarouselItem="augment",t.Shopping="shopping"}(i||(i={}));var f=r(46835),b=r(41587);function $(t){return Array.isArray(t)?t.map(t=>$(t)):null!=t&&t.constructor===Object?Object.keys(t).reduce((e,r)=>({...e,[(0,b.A)(r)]:$(t[r])}),{}):t}async function y(t,e,r,n){return u.aC.safeExecute(async()=>{var a;const o=await f.b.fetchArticleAugmentProducts(e);null!=o&&o[0].data&&(t=o[0].data);const s=$(JSON.parse(t));s.articleProducts=(null===(a=s.articleProducts)||void 0===a||null===(a=a.filter(t=>t.id))||void 0===a?void 0:a.slice(0,30))||[],s.articleProducts.length<3&&(s.articleProducts=[]);const l=s.articleProducts;(0,h.kC)(l,!0,!0,!1,!1,!1,g.eA.NtpAugmentCard),function(t,e){if(!e)return;let r=t&&t.contract&&t.contract.ext;r&&(r={...r,augHt:70}),e.forEach(t=>{const e=(0,m.g)(i.CarouselItem,{id:t.id,headline:t.title,brand:t.seller,vertical:i.Shopping,category:i.Shopping},v.MS.Navigate,v.EG.Click,r,{type:v.MJ.Interaction});t.telemetryTag=e.getMetadataTag()})}(r,l),n&&l.forEach(t=>{t.clickUrl=(0,h.L6)(t.clickUrl,`FORM=${n}`,!0)});return{shoppingEntities:l}},{shoppingEntities:[]},p.d78,"ShoppingAugmentCard - error parsing data",`Article ID: ${e}`)}const x={shoppingAugmentShown:"ShoppingAugmentShown",shoppingAugmentArticleID:"ShoppingAugmentArticle-{0}"};var w=r(17918);class k extends d.U{constructor(){super(...arguments),this.cardId="",this.augmentType="",this.isFirstViewReady=!1,this.telemetryConstructor=null,this.ensureObservableBeforeConnect=!0,this.ttvrFired=!1,this.displayedEntities=[],this.itemCollapsedWidth=54,this.itemExpandedWidth=168,this.carouselContentGap=8,this.containerWidth=250,this.stop=0,this.stops=[]}async experienceConnected(){var t,e;this.shoppingEntitiesData=await y(this.data,this.cardId,this.telemetryObject,null===(t=this.config)||void 0===t?void 0:t.formCodeOverride),this.telemetryContext=(t=>{if(!t)return;let e=t&&t.contract&&t.contract.ext;return e&&(e={...e,augHt:70}),{componentRoot:t,previousFlipper:(0,m.g)(i.PreviousFlipper,{id:i.PreviousFlipper,vertical:i.Shopping,category:i.Shopping},v.MS.Show,v.EG.Click,e,{type:v.MJ.Interaction}),nextFlipper:(0,m.g)(i.NextFlipper,{id:i.NextFlipper,vertical:i.Shopping,category:i.Shopping},v.MS.Show,v.EG.Click,e,{type:v.MJ.Interaction})}})(this.telemetryObject),this.shoppingEntitiesData&&(this.shoppingEntitiesData.title={text:this.strings.carouselHeader}),(null===(e=this.shoppingEntitiesData)||void 0===e?void 0:e.shoppingEntities.length)>0?(this.isFirstViewReady=!0,this.setTmplTelemetry()):this.style.display="none"}getExperienceType(){return c.r87}onCardRendered(){if(!this.ttvrFired){this.ttvrFired=!0,this.markVisuallyReadyRaf();const t=`${this.getExperienceType()}.Ready`;(0,w.pE)(t,!1,this.getApproxTTVRValue(t))}}setTmplTelemetry(){(0,u.ao)(x.shoppingAugmentShown,1);const t=x.shoppingAugmentArticleID.replace("{0}",this.cardId);(0,u.ao)(t)}get showImageOnly(){var t,e,r;return(null===(t=this.config)||void 0===t||null===(t=t.shoppingCarouselUISettings)||void 0===t?void 0:t.productImageOnly)&&(null===(e=this.shoppingEntitiesData)||void 0===e?void 0:e.shoppingEntities.length)&&(null===(r=this.shoppingEntitiesData)||void 0===r?void 0:r.shoppingEntities.length)>5}shoppingEntitiesDataChanged(t,e){var r;e&&(null===(r=e.shoppingEntities)||void 0===r?void 0:r.length)>=0&&(this.displayedEntities=e.shoppingEntities,this.calculateStops())}expandingCardsChanged(t,e){e&&e.length>0&&(e.forEach((t,e)=>{t.onfocus=()=>{this.onExpandingCardFocus(e)}}),null!=e&&e[this.stop]&&!this.showImageOnly&&(e[this.stop].metadataExpanded=!0))}onExpandingCardFocus(t){return this.stop!==t&&(this.stop=t,this.updateExpandedCard(),this.updateCarouselContainer()),!0}calculateStops(){this.stops.push(0);const t=this.itemExpandedWidth+(this.displayedEntities.length-1)*(this.itemCollapsedWidth+this.carouselContentGap);let e=0;for(let r=1;r<this.displayedEntities.length;r++)1===r?e=(this.containerWidth-this.itemExpandedWidth-2*this.carouselContentGap)/2-this.itemCollapsedWidth:r===this.displayedEntities.length-1?e=-(t-this.containerWidth):e-=this.itemCollapsedWidth+this.carouselContentGap,this.stops.push(e)}get onFirstPage(){return 0===this.stop}get onLastPage(){return this.stop===this.stops.length-1}onFlipperPreviousClick(){this.onFirstPage||(this.stop--,this.updateExpandedCard(),this.updateCarouselContainer())}onFlipperNextClick(){this.onLastPage||(this.stop++,this.updateExpandedCard(),this.updateCarouselContainer())}updateExpandedCard(){var t;null===(t=this.expandingCards)||void 0===t||t.forEach((t,e)=>{t.metadataExpanded=this.stop===e})}updateCarouselContainer(){var t;const e=this.stops[this.stop];void 0!==e&&(null===(t=this.carouselContent)||void 0===t||t.style.setProperty("transform",`translateX(${e}px)`))}}(0,s.Cg)([l.sH],k.prototype,"data",void 0),(0,s.Cg)([l.sH],k.prototype,"cardId",void 0),(0,s.Cg)([l.sH],k.prototype,"augmentType",void 0),(0,s.Cg)([l.sH],k.prototype,"isFirstViewReady",void 0),(0,s.Cg)([l.sH],k.prototype,"shoppingEntitiesData",void 0),(0,s.Cg)([l.sH],k.prototype,"telemetryContext",void 0),(0,s.Cg)([l.Jg],k.prototype,"showImageOnly",null),(0,s.Cg)([l.sH],k.prototype,"carouselContent",void 0),(0,s.Cg)([l.sH],k.prototype,"expandingCards",void 0),(0,s.Cg)([l.sH],k.prototype,"stop",void 0),(0,s.Cg)([l.sH],k.prototype,"stops",void 0),(0,s.Cg)([l.Jg],k.prototype,"onFirstPage",null),(0,s.Cg)([l.Jg],k.prototype,"onLastPage",null);var T=r(96950),C=r(39957),S=r(60402),F=r(416),O=r(10108),P=r(69259),z=r(37912),I=r(82203),A=r(30576),D=r.n(A),L=r(58759),U=r.n(L);z.LC,z.e_;const R=T.qy`<msn-shopping-augment-carousel-card class="single-card" use-card-parent-element="${!1}" :shoppingEntity="${t=>{var e;return null===(e=t.displayedEntities)||void 0===e?void 0:e[0]}}" :shoppingProductCarouselVariant="${t=>I.uU}" :onCardVisuallyReady="${t=>t.onCardRendered.bind(t)}"></msn-shopping-augment-carousel-card>`,M=T.qy`<msn-shopping-augment-carousel-card class="augment-item ${(t,e)=>e.parent.showImageOnly?"image-only":"expanding-card"}" use-card-parent-element="${!1}" :shoppingEntity="${t=>t}" :shoppingProductCarouselVariant="${(t,e)=>q(e.parent)}" :onCardVisuallyReady="${(t,e)=>e.parent.onCardRendered.bind(e.parent)}"></msn-shopping-augment-carousel-card>`,_=T.qy`<div class="augment-header">${t=>{var e;return null===(e=t.shoppingEntitiesData)||void 0===e||null===(e=e.title)||void 0===e?void 0:e.text}}</div><cs-horizontal-scroll speed="3600" next-telemetry="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.nextFlipper)||void 0===e?void 0:e.getMetadataTag()}}" previous-telemetry="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.previousFlipper)||void 0===e?void 0:e.getMetadataTag()}}" flipper-size="small"><slot name="previous-flipper-icon" slot="previous"><span class="previous-flipper-icon" slot="previous-flipper-icon"></span></slot><slot name="next-flipper-icon" slot="next"><span class="next-flipper-icon" slot="next-flipper-icon"></span></slot>${(0,C.ux)(t=>{var e;return(null===(e=t.shoppingEntitiesData)||void 0===e?void 0:e.shoppingEntities)||[]},M,{positioning:!0})}</cs-horizontal-scroll>`,H=T.qy`<cs-flipper class="previous-flipper" @click="${t=>t.onFlipperPreviousClick()}" aria-hidden="false" size="medium" direction="previous" data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.previousFlipper)||void 0===e?void 0:e.getMetadataTag()}}"><span slot="previous" class="expanding-carousel-flipper-icon">${T.qy.partial(U())}</span></cs-flipper>`,B=T.qy`<cs-flipper class="next-flipper" @click="${t=>t.onFlipperNextClick()}" aria-hidden="false" size="medium" direction="next" data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.nextFlipper)||void 0===e?void 0:e.getMetadataTag()}}"><span slot="next" class="expanding-carousel-flipper-icon">${T.qy.partial(D())}</span></cs-flipper>`,E=T.qy`<div class="carousel-container"><div class="carousel-content" ${(0,S.K)("carouselContent")} ${(0,F.Y)({property:"expandingCards",filter:(0,O.Y)()})} style="gap:${t=>t.carouselContentGap}px;">${(0,C.ux)(t=>t.displayedEntities||[],M)}</div></div>${(0,P.z)(t=>!t.onFirstPage,H)} ${(0,P.z)(t=>!t.onLastPage,B)}
`,V=T.qy`<div class="augment-section" style="${t=>{var e;return null===(e=t.config)||void 0===e||null===(e=e.shoppingCarouselUISettings)||void 0===e?void 0:e.styles}}">${(0,P.z)(t=>{var e;return 1===(null===(e=t.displayedEntities)||void 0===e?void 0:e.length)},R)} ${(0,P.z)(t=>{var e;return(null===(e=t.displayedEntities)||void 0===e?void 0:e.length)>1},t=>t.showImageOnly?_:E)}</div>`,G=T.qy` ${(0,P.z)(t=>t.isFirstViewReady,V)}
`,q=t=>{var e,r;return null!=t&&t.showImageOnly?{...I.es,imageHeight:null==t||null===(e=t.config)||void 0===e||null===(e=e.shoppingCarouselUISettings)||void 0===e?void 0:e.imageHeight,imageWidth:null==t||null===(r=t.config)||void 0===r||null===(r=r.shoppingCarouselUISettings)||void 0===r?void 0:r.imageWidth}:I.uU};var N=r(74849),W=r(22131),j=r(61138),J=r(86856),Y=r(75307);const Q=(0,Y.Eo)("rightArrow"),X=(0,Y.Eo)("rightArrowDark"),K=(0,Y.Eo)("leftArrow"),Z=(0,Y.Eo)("leftArrowDark"),tt=N.A` :host{--augc-background-color:#141414;--augc-title-color:#D6D6D6;--augc-seller-color:#ADADAD}.previous-flipper-icon{background:url(${Z}) no-repeat center}.next-flipper-icon{background:url(${X}) no-repeat center}.augment-header{color:#fff}`,et=N.A`
`,rt=N.A`
`,it=N.A` :host{--augc-background-color:#F5F5F5;--augc-title-color:#424242;--augc-seller-color:#424242}.augment-section{border-radius:8px;background-color:var(--augc-background-color);padding:var(--augment-section-padding,8px);width:var(--augment-section-width,250px);height:54px;display:block;font-weight:600;text-decoration:none;position:relative}.carousel-container{overflow:hidden;width:100%;height:100%}.carousel-content{display:flex;height:100%;transition:transform 0.5s ease}.augment-item{width:var(--item-width,fit-content);height:var(--item-height,100%)}.expanding-card.augment-item{width:var(--expanding-item-width,fit-content);height:var(--expanding-item-height,100%)}.previous-flipper,.next-flipper{position:absolute;top:50%;transform:translateY(-50%);box-shadow:rgba(0,0,0,0.14) 0px 4px 8px;z-index:1;transition:opacity 0.3s linear 0s;opacity:0;user-select:none}.augment-section:hover .previous-flipper,.augment-section:hover .next-flipper{opacity:1}.previous-flipper{left:2px;right:auto}.next-flipper{right:2px;left:auto}.expanding-carousel-flipper-icon{display:flex;align-items:center}cs-horizontal-scroll{--scroll-item-spacing:var(--carousel-item-spacing,8px);height:34px}cs-horizontal-scroll::part(scroll-prev){transform:var(--scroll-prev-transform,0);left:15px}cs-horizontal-scroll::part(scroll-next){transform:var(--scroll-next-transform,0);right:15px}cs-horizontal-scroll::part(scroll-prev),cs-horizontal-scroll::part(scroll-next){opacity:0;transition:opacity 0.3s ease}.augment-section:hover cs-horizontal-scroll::part(scroll-prev),.augment-section:hover cs-horizontal-scroll::part(scroll-next){opacity:1;z-index:1}.next-flipper-icon,.previous-flipper-icon{width:7px;height:9px;display:block}.previous-flipper-icon{background:url(${K}) no-repeat center}.next-flipper-icon{background:url(${Q}) no-repeat center}.augment-header{font-size:${j.k};
        line-height: ${j.F};
        font-weight: 400;
        margin-bottom: 4px;
        color: #707070;
        padding: 0 0 0 8px;
        padding-inline-start: 8px;
    }
`.withBehaviors(new J.t(et,rt),(0,W.G2)(tt));o.m.define(n.G.registry),a.m.define(n.G.registry);const nt={experienceConfigSchema:undefined}},27550(t,e,r){"use strict";r.d(e,{w(){return i}});const i={medium:"medium",large:"large",extraLarge:"extra-large",twoExtraLarge:"extra-large-2"}},28986(t,e,r){"use strict";r.d(e,{DK(){return m},Rg(){return v},v8(){return g}});var i=r(45755),n=r(64183),a=r(95239);function o(t,e){return i.G.create({name:t},e)}const s=o("neutral-fill-secondary-rest-delta",3),l=o("neutral-fill-secondary-hover-delta",2),c=o("neutral-fill-secondary-active-delta",1),d=o("neutral-fill-secondary-focus-delta",3);var u=r(31023);const{create:p}=i.G,h=o("neutral-fill-secondary-recipe",{evaluate(t,e){return(0,n.t)(t(u.r),e||t(a.p),t(s),t(l),t(c),t(d))}}),g=p("neutral-fill-secondary-rest",t=>t(h).evaluate(t).rest),v=p("neutral-fill-secondary-hover",t=>t(h).evaluate(t).hover),m=p("neutral-fill-secondary-active",t=>t(h).evaluate(t).active);p("neutral-fill-secondary-focus",t=>t(h).evaluate(t).focus)},30326(t,e,r){"use strict";r.d(e,{m(){return $}});var i=r(65614),n=r(74849),a=r(64187),o=r(86856);const s=n.A`
    .scroll-prev {
        right: auto;
        left: 0;
    }

    .scroll.scroll-next::before,
    .scroll-next .scroll-action {
        left: auto;
        right: 0;
    }

    .scroll.scroll-next::before {
        background: linear-gradient(to right, transparent, var(--scroll-fade-next));
    }

    .scroll-next .scroll-action {
        transform: translate(60%, -50%);
    }
`,l=n.A`
    .scroll.scroll-next {
        right: auto;
        left: 0;
    }

    .scroll.scroll-next::before {
        background: linear-gradient(to right, var(--scroll-fade-next), transparent);
        left: auto;
        right: 0;
    }

    .scroll.scroll-prev::before {
        background: linear-gradient(to right, transparent, var(--scroll-fade-previous));
    }

    .scroll-prev .scroll-action {
        left: auto;
        right: 0;
        transform: translate(60%, -50%);
    }
`,c=n.A`
    div.scroll-view {
        overflow-x: hidden;
    }

    .scroll {
        bottom: 0;
        pointer-events: none;
        position: absolute;
        right: 0;
        top: 0;
        user-select: none;
        width: 100px;
    }

    .scroll.disabled {
        display: none;
    }

    .scroll::before,
    .scroll-action {
        left: 0;
        position: absolute;
    }

    .scroll::before {
        background: linear-gradient(to right, var(--scroll-fade-previous), transparent);
        content: "";
        display: block;
        height: 100%;
        width: 100%;
    }

    .scroll-action {
        pointer-events: auto;
        right: auto;
        top: 50%;
        transform: translate(-60%, -50%);
        transition: opacity 0.2s ease-in-out;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    :host([flippers-hidden-from-at="true"]) .scroll-action {
        opacity: 0;
    }

    :host([flippers-hidden-from-at="true"]) .scroll-area:hover .scroll-action {
        opacity: 1;
    }
`.withBehaviors(new o.t(s,l)),d=n.A`
    ${(0,a.V)("block")} :host {
        --scroll-align: center;
        --scroll-item-spacing: 4px;
        contain: layout;
        position: relative;
    }

    .scroll-area {
        position: relative;
        display: flex;
    }

    .scroll-view {
        overflow-x: auto;
        scrollbar-width: none;
        padding: var(--scroll-view-padding, 10px);
        overflow-y: clip;
    }

    ::-webkit-scrollbar {
        display: none;
    }

    .content-container {
        align-items: var(--scroll-align);
        display: inline-flex;
        flex-wrap: nowrap;
        position: relative;
        height: 100%;
    }

    .content-container ::slotted(*) {
        margin-inline-end: var(--scroll-item-spacing);
    }

    .content-container ::slotted(*:last-child) {
        margin-inline-end: 0;
    }
`;var u=r(56911),p=r(96751),h=r(38493),g=r(27550);class v extends p.I{constructor(){super(...arguments),this.flipperSize=g.w.large}connectedCallback(){super.connectedCallback(),"mobile"!==this.view&&this.$fastController.addStyles(c)}get isRTL(){return this.scrollItems.length>1&&this.scrollItems[0].offsetLeft>this.scrollItems[1].offsetLeft}getScrollStops(){return super.getScrollStops()}getCurrentScrollIndex(){const t=this.isRTL,e=this.getScrollStops(),r=this.scrollContainer.scrollLeft;return e.findIndex((i,n)=>i>=r&&(t||n===e.length-1||e[n+1]>r))}getNextScrollIndex(){const t=this.scrollContainer.scrollLeft,e=this.getScrollStops(),r=e.findIndex(e=>Math.abs(e)>=Math.abs(t)),i=e.findIndex(e=>Math.abs(t)+this.getWidth()<=Math.abs(e));let n=r;return i>r+2?n=i-2:r<e.length-2&&(n=r+1),n}getWidth(){return super.getWidth()}}(0,u.Cg)([(0,h.CF)({attribute:"next-telemetry"}),(0,u.Sn)("design:type",String)],v.prototype,"nextTelemetry",void 0),(0,u.Cg)([(0,h.CF)({attribute:"previous-telemetry"}),(0,u.Sn)("design:type",String)],v.prototype,"previousTelemetry",void 0),(0,u.Cg)([(0,h.CF)({attribute:"flipper-size"}),(0,u.Sn)("design:type",String)],v.prototype,"flipperSize",void 0),(0,u.Cg)([(0,h.CF)({attribute:"aria-label-previous"}),(0,u.Sn)("design:type",String)],v.prototype,"ariaLabelPrevious",void 0),(0,u.Cg)([(0,h.CF)({attribute:"aria-label-next"}),(0,u.Sn)("design:type",String)],v.prototype,"ariaLabelNext",void 0);var m=r(99015),f=r(96950);const b=(0,m.Y)({nextFlipper:f.qy`
            <cs-flipper
                size="${t=>t.flipperSize}"
                @click="${t=>t.scrollToNext()}"
                aria-hidden="${t=>t.flippersHiddenFromAT}"
                aria-label="${t=>t.ariaLabelNext||"next"}"
                data-t="${t=>t.nextTelemetry}"
                part="next-flipper"
            >
                <slot name="next" slot="next"></slot>
            </cs-flipper>
        `,previousFlipper:f.qy`
            <cs-flipper
                size="${t=>t.flipperSize}"
                @click="${t=>t.scrollToPrevious()}"
                direction="previous"
                aria-hidden="${t=>t.flippersHiddenFromAT}"
                aria-label="${t=>t.ariaLabelPrevious||"previous"}"
                data-t="${t=>t.previousTelemetry}"
                part="previous-flipper"
            >
                <slot name="previous" slot="previous"></slot>
            </cs-flipper>
        `}),$=v.compose({name:`${i.G.prefix}-horizontal-scroll`,styles:d,template:b})},30576(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M7.57 11.84A1 1 0 016 11.02V4.98a1 1 0 011.57-.82l3.79 2.62c.85.59.85 1.85 0 2.44l-3.79 2.62z"></path></svg>'},35643(t,e,r){"use strict";r.d(e,{M(){return n}});var i=r(89167);class n extends i.X9{static buildMITPageUrl(t){var e;const r=null==t||null===(e=t.split("/").pop())||void 0===e?void 0:e.substring(3);return`${this.bingShopBaseUrl}/${r}?FORM=SHOPHP`}static buildCategoryPageUrl(t,e,r){if(t&&e)return`${this.bingShopBaseUrl}/departments/${this.normalizeCategoryName(e)}?filters=catid:"${t}"&FORM=SHOPHP`;{const t=r&&r.split("?").length>0?r.split("?")[1]:"",e=new URLSearchParams(t),i=e.get("catid"),n=e.get("catname"),a=null==n?void 0:n.toLowerCase().replace(/ & /g,"-").replace(/ /g,"-");return`${this.bingShopBaseUrl}/departments/${a}?filters=catid:"${i}"&FORM=SHOPHP`}}static buildQuerySearchPageUrl(t,e){const r=e?`&clksrc=${e}`:"";return t?`${this.bingShopBaseUrl}?q=${encodeURIComponent(t)}${r}`:`${this.bingShopBaseUrl}?${r}`}static normalizeCategoryName(t){if(t)return null==t?void 0:t.toLowerCase().replace(/ & /g,"-").replace(/ /g,"-")}static buildBuyingGuideUrl(t,e){const r=new URLSearchParams(location.search),i=r.get("features"),n=r.get("mkt"),a=new URLSearchParams;return n&&a.append("mkt",n),i&&a.append("features",i),t?(a.append("catid",t),e&&a.append("catname",e),`${this.bingShopBaseUrl}/buying-guide?${a}&FORM=SHOPHP`):`${this.bingShopBaseUrl}/buying-guide?${a}&FORM=SHOPHP`}static buildQuerySearchPdp(t,e,r){const n=r?`&clksrc=${r}`:"";let a;if(t&&e){const r=new URLSearchParams(location.search);r.set("q",t),r.set("filters",`gGlobalOfferIds:"${e}" isexpscenario:"true"`),a=`${this.bingShopBaseUrl}?${r}${n}`}else a=`${this.bingShopBaseUrl}?${n}`;return(0,i.wQ)(a,"msn",void 0,!0)}}n.bingShopBaseUrl="https://www.bing.com/shop"},37912(t,e,r){"use strict";r.d(e,{e_(){return f},LC(){return m},i7(){return u}});var i=r(56911),n=r(82492),a=r(23528),o=r(92011),s=r(73893),l=r(65614),c=r(85218);let d=class extends a.E{};d=(0,i.Cg)([(0,o.E)({name:"msn-shopping-modal-product-card",template:c.kN,styles:n.Hl,shadowOptions:{delegatesFocus:!0}})],d);let u=class extends a.E{};u=(0,i.Cg)([(0,o.E)({name:"msn-shopping-sd-full-bleed-product-card",template:c.kN,styles:n.Ud,shadowOptions:{delegatesFocus:!0}})],u);let p=class extends a.E{};p=(0,i.Cg)([(0,o.E)({name:"msn-shopping-sd-halfu-product-card",template:c.kN,styles:n.b3,shadowOptions:{delegatesFocus:!0}})],p);let h=class extends a.E{};h=(0,i.Cg)([(0,o.E)({name:"msn-shopping-prong-pivot-product-card",template:c.kN,styles:n.OE,shadowOptions:{delegatesFocus:!0}})],h);let g=class extends a.E{};g=(0,i.Cg)([(0,o.E)({name:"msn-shopping-prong-pivot-category-card",template:c.kN,styles:n.nF,shadowOptions:{delegatesFocus:!0}})],g);let v=class extends a.E{};v=(0,i.Cg)([(0,o.E)({name:"msn-shopping-prong-pivot-flyer-card",template:c.kN,styles:n.bB,shadowOptions:{delegatesFocus:!0}})],v);let m=class extends a.E{};m=(0,i.Cg)([(0,o.E)({name:"msn-shopping-augment-main-card",template:c.kN,styles:n.fP,shadowOptions:{delegatesFocus:!0}})],m);let f=class extends a.E{};f=(0,i.Cg)([(0,o.E)({name:"msn-shopping-augment-carousel-card",template:c.kN,styles:n.w8,shadowOptions:{delegatesFocus:!0}})],f);let b=class extends a.E{};b=(0,i.Cg)([(0,o.E)({name:"msn-shopping-bg-premium-main-card",template:c.kN,styles:n.kG,shadowOptions:{delegatesFocus:!0}})],b);let $=class extends a.E{};$=(0,i.Cg)([(0,o.E)({name:"msn-shopping-bg-premium-article-card",template:c.kN,styles:n.Jj,shadowOptions:{delegatesFocus:!0}})],$);let y=class extends a.E{};y=(0,i.Cg)([(0,o.E)({name:"msn-shopping-pivot-banner-card",template:c.kN,styles:n.pm,shadowOptions:{delegatesFocus:!0}})],y);let x=class extends a.E{};x=(0,i.Cg)([(0,o.E)({name:"msn-shopping-prong-pivot-overlay-card",template:c.kN,styles:n.q1,shadowOptions:{delegatesFocus:!0}})],x),s.m.define(l.G.registry)},42792(t,e,r){"use strict";r.d(e,{R7(){return v},e(){return h},kc(){return g},nH(){return p}});var i=r(57416),n=r(55153),a=r(95239),o=r(26920),s=r(48751),l=r(64187),c=r(22131),d=r(74849),u=r(50882);const p=d.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=d.A`
    ${(0,l.V)("flex")} :host {
        background: ${a.p};
        outline: calc(${o.XA} * 1px) solid ${n.cu};
        border-radius: calc((${i.JU} - ${o.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${o.XA} * 1px) ${n.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${o.XA} * 1px) ${n.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${o.XA} * 1px) ${n.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${n.QG} * 1px);
        height: calc(${n.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${n.QG} * 1px);
        height: calc((${n.l8} * 2px) + (${n.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${n.QG} * 2px) + (${n.Sn} * 1px));
        height: calc((${n.l8} * 2px) + (${n.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${n.QG} * 2px) + (${n.Sn} * 1px));
        height: calc(${n.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,g=(0,c.mr)(d.A`
            :host {
                background: ${u.A.Canvas};
                color: ${u.A.CanvasText};
            }
        `),v=d.A`
    ${h}
    ${p}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(g)},46835(t,e,r){"use strict";r.d(e,{b(){return p}});var i=r(58792),n=r(68989),a=r(27233),o=r(93552),s=r(31756),l=r(96915),c=r(50952),d=r(95854);const u=(0,d.lJ)();class p{constructor(){}static getBaseUrl(){let t=arguments.length>0&&void 0!==arguments[0]&&arguments[0];const{usDcBaseUrl:e,segmentServiceRelativepath:r,baseUrl:i}=l.J;return t?e+r:i}static async fetchFrom1S(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0,r=arguments.length>2&&void 0!==arguments[2]&&arguments[2],i=arguments.length>3&&void 0!==arguments[3]&&arguments[3],a=arguments.length>4&&void 0!==arguments[4]&&arguments[4],o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:l.J.oneServiceTimeout;const c={credentials:"include",headers:await s.WR.getOneServiceHeaders(),method:"GET"},u=(0,d._H)(o);let p=await(0,n.hv)(t,u,c);const{usDcBaseUrl:h,usDcBaseUrl_segmentService_secondary:g}=l.J;if(i&&404==p.status&&(p=await(0,n.hv)(t.replace(h,g),u,c)),a)return p;if(!p.ok)throw"Did not get a 200 from 1S request";const v=await p.json();if(e>=0){let t=v[e];return r||(t=JSON.parse(t.data)),t}return v}static buildFeedbackUrl(t,e){let r=!(arguments.length>2&&void 0!==arguments[2])||arguments[2],n=`&$select=${t}`;return n+=`&$filter=${e.join("|")}~${l.J.xapMicroserviceTimeout}`,`${p.getBaseUrl(r)}?${u}${n}&activityid=${i.T3.ActivityId}`}static async updateUserFeedbacks(t){let{categoryFeedback:e,offerFeedback:r,sellerFeedback:i,brandFeedback:n}=t,a=!(arguments.length>1&&void 0!==arguments[1])||arguments[1],s=arguments.length>2&&void 0!==arguments[2]?arguments[2]:c.L.FeedbackWrite,l="";try{const t=[(0,d.sH)(e),(0,d.sH)(r),"false",(0,d.sH)(i),(0,d.sH)(n)];if(!t.join(""))return;return l=p.buildFeedbackUrl(s,t,a),await p.fetchFrom1S(l)}catch(t){return(0,d._G)(t,o.Qje,"ShoppingPageContentClientWriteLastSeenNTPFailedError",l),null}}static async getTrendingOffersOfCategory(t,e){let r;r=e===a.DX.ZHCN?`${l.J.segmentBaseUrl}?${u}&activityid=${i.T3.ActivityId}&filter=TrendingScenario::TrendingOffersOfCategory||CategoryId::${t}`:`${l.J.segmentBaseUrl}?${u}&activityid=${i.T3.ActivityId}&fdhead=prg-sh-ntpmtcd&$filter=TabbedCarouselSelection::${t}`;try{const t=await(0,n.hv)(r,l.J.xapMicroserviceTimeout);if(!t.ok)throw"Did not get a 200 from trending offers of category api request";return await t.json()}catch(t){return(0,d._G)(t,o.Yv0,"ShoppingPageContentClientTrendingOffersOfCategoryFailedError",r),null}}static buildTrendingProductsUrl(){const t=`&$top=${arguments.length>0&&void 0!==arguments[0]?arguments[0]:20}`;return`${p.getBaseUrl()}?${u}${t}&activityid=${i.T3.ActivityId}`}static async getCarouselTrendingOffers(){const t=p.buildTrendingProductsUrl();try{const r=await p.fetchFrom1S(t,-1);if(r&&r.length>0){let t=r[0];for(let i=1;i<r.length;i++){var e;"ShoppingCarousel"==(null===(e=r[i])||void 0===e?void 0:e.type)&&(t=r[i])}return t}return null}catch(e){return(0,d._G)(e,o.MnR,"ShoppingPageContentClientTrendingOffersFetchError",t),null}}static async getCashbackStatus(){let t="";try{t=`${`${l.J.forumBaseUrl}/cashbackStatus`}?${u}&activityid=${i.T3.ActivityId}`;const e=await this.fetchFrom1S(t,-1);return JSON.parse(e.data)}catch(e){return(0,d._G)(e,o.y$I,"ForumFetchCashbackStatusError",t),null}}static async getOffersFromTopic(t){const e=i.T3.CurrentMarket===a.DX.ZHCN?"prg-sh-cdnslots,prg-sh-ntpcdn7,prg-sh-ntpparachute,prg-sh-navhny,prg-sh-ntpmulcdn":"prg-sh-ntpmtc",r=`${l.J.segmentBaseUrl}?${u}&activityid=${i.T3.ActivityId}&fdhead=${e}&$filter=TabbedCarouselSelection::${t}`;try{const t=await(0,n.hv)(r,l.J.xapMicroserviceTimeout);if(!t.ok)throw"Did not get a 200 from tabbed carousel api request";return await t.json()}catch(t){return(0,d._G)(t,o.StB,"ShoppingAnaheimClientTopicOffersFailedError",r),null}}static async fetchTopics(t){const e=`${l.J.segmentBaseUrl}?${u}&activityid=${i.T3.ActivityId}&$filter=GroupedDataSections::${t.join(",")}`;try{const t=await(0,n.hv)(e,l.J.xapMicroserviceTimeout);if(!t.ok)throw"Did not get a 200 from topics api request";return await t.json()}catch(t){return(0,d._G)(t,o.StB,"ShoppingAnaheimClientFetchingTopicsFailedError",e),null}}static async fetchArticleAugmentProducts(t){const e=`${l.J.baseUrl}?${(0,d.lJ)("winp1")}&activityid=${i.T3.ActivityId}&pageFeedSkip=1&AppVersion=1&experience=ContentConsumptionViewPage&contentId=${t}`;try{const t=await(0,n.hv)(e,l.J.xapMicroserviceTimeout);if(!t.ok)throw"Did not get a 200 from topics api request";return await t.json()}catch(t){return(0,d._G)(t,o.WTc,"ShoppingAnaheimClientFetchAugmentProductsFailedError",e),null}}static async getCategoriesForSDCardDropdown(){const t=`${l.J.segmentBaseUrl}?${u}&activityid=${i.T3.ActivityId}&$filter=TabbedCarouselSelection::HotDeals,CategoryProducts`;try{const e=await(0,n.hv)(t,l.J.xapMicroserviceTimeout);if(!e.ok)throw"Did not get a 200 from tabbed carousel api request";return await e.json()}catch(e){return(0,d._G)(e,o.Yv0,"ShoppingPageContentClientTrendingOffersOfCategoryFailedError",t),null}}}},48847(t,e,r){"use strict";r.d(e,{L6(){return I},id(){return O},kC(){return S},lK(){return P},Vs(){return F},UB(){return T},mq(){return C},Qc(){return k},GH(){return w},Ym(){return z},IL(){return D},yT(){return A},UY(){return U},cA(){return f},m4(){return b},DC(){return L}});var i=r(11236),n=r(89167);class a extends n.X9{static buildAbsoluteUrl(t,e,r,i,a,o){const s=new URLSearchParams([["pid",t]]);return r&&s.set(n.Ts.ClickSourceQueryParam,r),i&&s.set("title",i),a&&s.set(this.loadArExperienceParam,"true"),o&&s.set("FORM",o),`${this.getSchemeAndDomain()}/${e}/shopping/product?${(0,n.wW)(s,!0)}`}}a.loadArExperienceParam="load-ar-experience";var o=r(26220),s=r(77367);class l extends n.X9{static buildAbsoluteUrl(t,e,r,i,a,o){const s=new URLSearchParams([["pid",t],["filters",`pdprecocache:"true" scenario:"17" gType:"12" gId:"${t}" gGlobalOfferIds:"${t}"`]]);return r&&s.set(n.Ts.ClickSourceQueryParam,r),i&&s.set("q",i),o&&s.set("FORM",o),a&&a.length>0&&s.set(n.Ts.ModalCarouselOfferIdsQueryParam,a.join(",")),`${this.getSchemeAndDomain()}/${e}/shopping/product-details?${(0,n.wW)(s,!0,!0)}`}static buildFullPagePDPUrl(t,e,r,i,a){const l=new URLSearchParams((0,o.iA)()),c=l.get("ocid"),d=l.get("cvid"),u=l.get("FORM")||l.get("form"),p=l.get("trafsrc"),h=new URLSearchParams([["pid",t],["filters",`scenario:"17" gType:"12" gId:"${t}" gGlobalOfferIds:"${t}"`],["productpage","true"]]);return e&&h.set("q",e),d&&(h.set("cvid",d),h.set("msnrid",d)),u&&h.set("FORM",u),p&&h.set("trafsrc",p),(c&&"startWidget"!==c||a)&&(c&&h.set("ocid",c),a&&h.set("msnrid",s.YT.getRequestId()),h.set("entryPoint","msn"),h.set("adunitId","378983"),h.set("propertyId","316966")),r&&h.set("dealid",r),i&&h.set(n.Ts.ClickSourceQueryParam,i),`${this.bingBaseUrl}?${h}`}}l.bingBaseUrl="https://www.bing.com/shop/productpage";var c=r(88083),d=r(35643),u=r(58792),p=r(99476),h=r(29853);function g(t,e){var r,i,n;if(!t)return!1;return(t=t.toString().toLowerCase()).indexOf("-")>-1?(null===(r=t)||void 0===r?void 0:r.startsWith("bn-"))||((null===(i=t)||void 0===i?void 0:i.startsWith("reco-"))||(null===(n=t)||void 0===n?void 0:n.startsWith("bonsai-")))&&!!e:!!e}function v(t){const e=null==t?void 0:t.id;return e?function(t,e){var r;const i=null==e||null===(r=e.expressCheckoutProvider)||void 0===r?void 0:r.productId;return g(t,i)&&(i||(t=t.toLowerCase()).startsWith("bn-")&&t.split("-").pop())||""}(e,t):""}var m=r(56302);function f(t){return"AbandonedCart"===(null==t?void 0:t.sourceType)}function b(t){return"TrackedProducts"===(null==t?void 0:t.sourceType)}function $(t){return t.isAds}function y(t){return function(t){return t.isHotDeal}(t)||$(t)}function x(t,e){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:[],i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:[],n=arguments.length>4&&void 0!==arguments[4]&&arguments[4],a=arguments.length>5&&void 0!==arguments[5]&&arguments[5],o=!(arguments.length>6&&void 0!==arguments[6])||arguments[6];t.forEach(t=>{var s,l;if(t&&t.id&&null!=t&&null!==(s=t.imageInfo)&&void 0!==s&&s.sourceImageUrl){t.imageInfo.sourceImageUrl.startsWith("/th")&&(t.imageInfo.sourceImageUrl="https://th.bing.com"+t.imageInfo.sourceImageUrl);const s=new URLSearchParams(new URL(t.imageInfo.sourceImageUrl).search);s.has("id")&&(o&&e.push((0,h.HU)(t.id)),n&&r.push(s.get("id")),a&&i.push(v(t)))}t.relatedEntities&&(null===(l=t.relatedEntities)||void 0===l?void 0:l.length)>0&&x(t.relatedEntities,e,r,i,n,a,o)})}function w(t,e,r){let n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"";const a=[],o=[],s=[];x(t,a,o,s,!0,arguments.length>3&&void 0!==arguments[3]&&arguments[3]),t.forEach(t=>{t&&t.id&&!y(t)&&(t.clickUrl=i.d.buildAbsoluteUrl(u.T3.CurrentMarket,e,(0,h.HU)(t.id),a,o,t.title,s,void 0,void 0,r,n))})}function k(t,e){t.forEach(t=>{t&&t.id&&!y(t)&&(t.clickUrl=a.buildAbsoluteUrl((0,h.HU)(t.id),u.T3.CurrentMarket,e,t.title))})}function T(t,e){const r=[];x(t,r),t.forEach(t=>{t&&t.id&&!y(t)&&(t.clickUrl=l.buildAbsoluteUrl((0,h.HU)(t.id),u.T3.CurrentMarket,e,t.title,r,n.eA.FullPage))})}function C(t,e){x(t,[]),t.forEach(t=>{t&&t.id&&!y(t)&&(t.clickUrl=l.buildFullPagePDPUrl((0,h.HU)(t.id),t.title,void 0,e,!0))})}function S(t){let e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],r=!(arguments.length>2&&void 0!==arguments[2])||arguments[2],i=arguments.length>3&&void 0!==arguments[3]&&arguments[3],n=arguments.length>4&&void 0!==arguments[4]&&arguments[4],a=arguments.length>6?arguments[6]:void 0,o=arguments.length>7&&void 0!==arguments[7]?arguments[7]:[],s=arguments.length>8&&void 0!==arguments[8]?arguments[8]:[];arguments.length>5&&void 0!==arguments[5]&&arguments[5]||x(t,o,s,[],!0,void 0,r),t.forEach(t=>{if(t.relatedEntities&&t.relatedEntities.length>0&&S(t.relatedEntities,e,r,i,n,!0,a,o,s),t&&t.id&&!y(t)){let r="";if(i)r=t.brq?t.brq:t.title;else if(n){var l;r=null!==(l=t.categoryInfo_2)&&void 0!==l&&l.categoryName?t.categoryInfo_2.categoryName:t.title}else e&&(r=t.title);t.clickUrl=m.f.buildAbsoluteUrl(r,(0,h.HU)(t.id),a,o)}})}function F(t){const e=[];x(t,e,[],[],!0,void 0,!(arguments.length>2&&void 0!==arguments[2])||arguments[2]),t.forEach(t=>{t&&t.id&&!y(t)&&(t.clickUrl=c.w.buildAbsoluteUrl((0,h.HU)(t.id),void 0,e))})}function O(t,e){t.forEach(t=>{const{categoryId:r,categoryName:i}=t.categoryInfo_2||{};r&&i&&(t.clickUrl=d.M.buildCategoryPageUrl(r,i,e||""))})}function P(t,e){t.forEach(t=>{const{title:r}=t;r&&(t.clickUrl=d.M.buildQuerySearchPageUrl(r,e||""))})}function z(t,e){t.forEach(t=>{const{title:r,globalOfferId:i}=t;r&&i&&(t.clickUrl=d.M.buildQuerySearchPdp(r,i,e||""))})}function I(t,e){let r=arguments.length>2&&void 0!==arguments[2]&&arguments[2];const[i,n]=t.split("?"),a=new URLSearchParams(n);return new URLSearchParams(e).forEach((t,e)=>{a.has(e)&&!r||a.set(e,t)}),a.toString()?`${i}?${a.toString()}`:i}function A(){const t=(0,p.a)().get("userid");return t?`&clientid=${t}`:""}function D(t,e,r,i){t.forEach(t=>{var a;$(t)||(t.relatedEntities&&t.relatedEntities.length>0&&D(t.relatedEntities,e,r,!0),(t.isFbt||i)&&(r&&1===r&&(t.clickUrl=(0,n.DH)(t.clickUrl,{fbt:"1"})),r&&2===r&&(t.clickUrl=(0,n.DH)(t.clickUrl,{fbt:"2"}))),t&&t.clickUrl&&(t.clickUrl=I(t.clickUrl,e)),null!==(a=t.similarItemsLink)&&void 0!==a&&a.clickUrl&&(t.similarItemsLink.clickUrl=I(t.similarItemsLink.clickUrl,e)))})}function L(t,e,r){const i=`${e}=${r}`;t.forEach(t=>{t.relatedEntities&&t.relatedEntities.length>0&&D(t.relatedEntities,e),t.clickUrl=I(t.clickUrl,i,!0)})}function U(t){var e,r;if(!t)return"";t=JSON.parse(t);const{miscData:i,...n}=t.metadata||{},a={...t,metadata:n};return null!==(e=a.shoppingEntities)&&void 0!==e&&e.length&&(a.shoppingEntities=a.shoppingEntities.map(t=>({id:t.id}))),null!==(r=a.topics)&&void 0!==r&&r.length&&(a.topics=a.topics.filter(t=>{var e;return null===(e=t.shoppingEntities)||void 0===e?void 0:e.length}).map(t=>{var e;const{miscData:r,...i}=t.metadata||{};return{...t,metadata:i,shoppingEntities:null===(e=t.shoppingEntities)||void 0===e?void 0:e.map(t=>({id:t.id||t.title}))}})),JSON.stringify(a)}},50866(t,e,r){"use strict";r.d(e,{L9(){return a},NZ(){return n},qJ(){return i}});const i={_1x_1y:"_1x_1y",_1x_2y:"_1x_2y",_2x_2y:"_2x_2y",_2x_1y:"_2x_1y"},n={DarkPlum:"dark-plum",DarkDesert:"dark-desert",DarkDawn:"dark-dawn",DarkSea:"dark-sea",DarkOrange:"dark-orange",DarkTropic:"dark-tropic",DarkMerlot:"dark-merlot",DarkPurple:"dark-purple",DarkGreen:"dark-green"},a={LightBlue:"light-blue",LightPurple:"light-purple",LightSky:"light-sky",LightPink:"light-pink",LightYellow:"light-yellow",LightBluebird:"light-bluebird",LightOrange:"light-orange",LightAqua:"light-aqua",LightGreen:"light-green"}},50952(t,e,r){"use strict";var i,n;r.d(e,{L(){return i}}),function(t){t.FeedbackWrite="userprofile|ntpfeedbackwrite",t.FeedbackWrite1688="userprofile|ntpfeedbackwrite1688"}(i||(i={})),function(t){t[t.SDCARD=0]="SDCARD",t[t.CAROUSEL=1]="CAROUSEL"}(n||(n={}))},54229(t,e,r){"use strict";r.d(e,{aC(){return f},YJ(){return a},x1(){return o},iJ(){return v},h9(){return m},LE(){return p},Eh(){return d},Ai(){return c},dI(){return u},j8(){return h},ao(){return g}});var i=r(85349),n=r(19359);const a={Customize:i.MS.Customize,Paginate:i.MS.Paginate,Hide:i.MS.Hide,Cancel:i.MS.Cancel,Close:i.MS.Close,Dislike:i.MS.Dislike,Show:i.MS.Show,Click:i.MS.Click};class o{createTelemetryObjectTag(t){return t?t.getMetadataTag():""}createTelemetryObject(t,e,r,a){if(!t||!e)return;const{name:o,content:s,...l}=e,c={...s,type:(null==s?void 0:s.type)||i.b5.StructuredData,vertical:this.verticalName,category:this.categoryName,subcategory:this.subCategoryName},d={...this.ext,signature:r};a&&(d.previewType=a);const u={...l,ext:d,zone:this.zone};return(0,n.g)(o,c,u)}createViewTelemetryObject(t,e){return this.createTelemetryObject(t,{name:e.name,action:i.EG.View,behavior:i.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType)}createViewTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,behavior:i.MS.View,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createNavClickTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,action:i.EG.Click,behavior:i.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createAddClickTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,action:i.EG.Click,behavior:i.MS.Add,type:i.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createHoverShowTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,action:i.EG.Hover,behavior:i.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createMouseLeaveCloseTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,action:i.EG.MouseLeave,behavior:i.MS.Close,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createDislikeActionTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,behavior:i.MS.Dislike,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createFollowTelemetryTag(t,e,r){const n=this.createTelemetryObject(t,{name:e.name,action:i.EG.Click,behavior:r?i.MS.Follow:i.MS.Unfollow,type:i.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createMenuDataProviderTelemetryTag(t,e,r){const n=this.createTelemetryObject(t,{name:e.name,action:i.EG.Click,behavior:i.MS.Undefined,type:i.MJ.ActionButton,content:{headline:e.headline},zone:r},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createNavClickWithTypeTelemetryTag(t,e,r){const n=this.createTelemetryObject(t,{name:e.name,action:i.EG.Click,behavior:i.MS.Navigate,type:r,content:{headline:e.headline,id:e.id,brandId:e.brandId,type:e.type||i.b5.StructuredData}},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createBehaviorTelemetryTag(t,e,r){const n=this.createTelemetryObject(t,{name:e.name,action:i.EG.Click,behavior:r,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createBaseContentCardTelemetryContext(t,e){const r=this.createTelemetryObject(t,{name:e.name,type:i.MJ.ContentCard,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType),n=this.createTelemetryObject(r,{name:e.name,type:i.MJ.Headline,behavior:i.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);if(r&&n)return{contentCard:r,destination:n}}initTelemetryBuilder(t,e,r,i,n){this.verticalName=t,this.categoryName=e,this.ext=r,this.zone=i,this.subCategoryName=n}updateExt(t){this.ext=t}}var s=r(77367),l=r(84742);function c(t){try{s.YT.sendActionEvent(t,i.EG.MouseLeave,i.MS.Close)}catch(t){return}}function d(t){try{s.YT.sendActionEvent(t,i.EG.Hover,i.MS.Show)}catch(t){return}}function u(t,e){try{s.YT.sendActionEvent(t,i.EG.Click,i.MS.Navigate,e)}catch(t){return}}function p(t,e,r){try{s.YT.sendActionEvent(t,e?i.EG.KeyPress:i.EG.Click,r?i.MS.Follow:i.MS.Unfollow)}catch(t){return}}function h(t){try{if(!t)throw new Error("Current target is undefined, cannot send content view telemetry.");s.YT.sendContentViewEvent(t,l.ym.View)}catch(t){return}}function g(t,e){const r=e?`${e}`:"";s.YT.addOrUpdateTmplProperty(t,r)}function v(t){s.YT.removeTmplProperty(t)}function m(t){for(const e of t)v(e)}var f,b=r(22341);!function(t){t.safeExecute=function(t,e,r,i,n){let a=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return t()}catch(t){return r&&(0,b.vV)(r,`${i}: ${null==t?void 0:t.message}`,n,a),e}},t.safeExecuteAsync=async function(t,e,r,i,n){let a=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return await t()}catch(t){return r&&(0,b.vV)(r,`${i}: ${null==t?void 0:t.message}`,n,a),Promise.resolve(e)}},t.logExceptionWithFormat=function(t,e,r,i,n){let a=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};(0,b.c_)(t,e,`${i}${i?": ":""}${r}`,n,a)},t.logErrorWithFormat=function(t,e,r,i){let n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:{};(0,b.vV)(t,`${r}${r?": ":""}${e}`,i,n)}}(f||(f={}))},56302(t,e,r){"use strict";r.d(e,{f(){return c}});var i=r(58792),n=r(27233),a=r(89167),o=r(29853),s=r(93552),l=r(22341);class c extends a.dN{static buildAbsoluteUrl(t,e,r,c){try{const s=new URL(this.bingBaseUrl);return this.updateBingShoppingQueryParameters(s,"msn",r,!0),t&&(r===a.eA.Prong1&&(t=t.replace(/[?&#]/g,"")),s.searchParams.set("q",t)),s.searchParams.set("overlayId",(0,o.yA)(e)),(null==c?void 0:c.length)>0&&s.searchParams.set("overlayOfferIds",c.join(",")),r!==a.eA.BuyingGuideInfoPane&&r!==a.eA.BuyingGuide1||i.T3.CurrentMarket!==n.DX.ZHCN||(s.href=e),s.href}catch(t){return(0,l.c_)(t,s.o8A,"Fail to build Bing Shopping url",`${this.bingBaseUrl};${e};${r}`),this.bingBaseUrl}}static buildMITAbsoluteUrl(t,e){const r=new URL(`${this.bingBaseUrl}/${t}`);return this.updateBingShoppingQueryParameters(r,"msn",e,!0),r.href}}c.bingBaseUrl="https://www.bing.com/shop"},58759(t){t.exports='<svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M9.43 11.84a1 1 0 001.57-.82V4.98a1 1 0 00-1.57-.82L5.64 6.78c-.85.59-.85 1.85 0 2.44l3.79 2.62z"></path></svg>'},60143(t,e,r){"use strict";r.d(e,{B(){return a}});var i=r(96950),n=r(18893);function a(t={}){const e={};return i.qy`
        <template
            role="button"
            aria-disabled="${t=>!!t.disabled||void 0}"
            tabindex="${t=>t.hiddenFromAT?-1:0}"
            @keyup="${(t,e)=>t.keyupHandler(e.event)}"
        >
            ${r=>function(t,r){let a=e[t];return a||(e[t]=a=i.qy`
                <span part="${t}" class="${t}">
                    <slot name="${t}">
                        ${(0,n.R)(r[t])}
                    </slot>
                </span>
            `),a}(r.direction,t)}
        </template>
    `}},64183(t,e,r){"use strict";r.d(e,{o(){return o},t(){return a}});var i=r(68009),n=r(49399);function a(t,e,r,n,a,o,s){const l=t.closestIndexOf(e);return null==s&&(s=(0,i.F)(e)),{rest:t.get(l+s*r),hover:t.get(l+s*n),active:t.get(l+s*a),focus:t.get(l+s*o)}}function o(t,e,r,i,o,s,l=void 0,c,d,u,p,h=void 0){return(0,n.H)(e)?a(t,e,c,d,u,p,h):a(t,e,r,i,o,s,l)}},69966(t,e,r){"use strict";r.d(e,{m(){return C}});var i=r(65614),n=r(56911),a=r(84506),o=r(38493),s=r(27550);class l extends a.d{constructor(){super(...arguments),this.size=s.w.medium}}(0,n.Cg)([o.CF,(0,n.Sn)("design:type",String)],l.prototype,"size",void 0);var c=r(28986),d=r(57416),u=r(48751),p=r(48196),h=r(74838),g=r(79288),v=r(14996),m=r(86856),f=r(60993),b=r(73477),$=r(22131),y=r(50882),x=r(74849),w=r(64187);const k=x.A`
    ${(0,w.V)("inline-flex")} :host {
        align-items: center;
        background: ${c.v8};
        border-radius: calc(${d.Pb} * 1px);
        color: ${u.l};
        fill: currentcolor;
        height: calc(${p.D} * 1px);
        justify-content: center;
        outline: none;
        width: calc(${h.vR} * 4px);
    }

    :host([size="large"]) {
        height: calc(${h.vR} * 12px);
        width: calc(${h.vR} * 6px);
    }

    :host([size="extra-large"]) {
        height: calc(${h.vR} * 12px);
        width: calc(${h.vR} * 6.5px);
    }

    :host([size="extra-large-2"]) {
        height: calc(${h.vR} * 12px);
        width: calc(${h.vR} * 7px);
    }

    :host([size="extra-large"]) ::slotted(svg) {
        height: 30px;
        width: 30px;
    }

    :host([size="extra-large-2"]) ::slotted(svg) {
        height: 34px;
        width: 34px;
    }

    ::slotted(svg) {
        height: 16px;
        width: 16px;
    }

    :host([size="large"]) ::slotted(svg) {
        height: 20px;
        width: 20px;
    }

    :host([disabled]) {
        cursor: ${f.Z};
        opacity: ${g.q};
        pointer-events: none;
    }

    .next,
    .previous {
        display: flex;
    }

    :host(:not([disabled]):hover) {
        cursor: pointer;
        background: ${c.Rg};
    }

    :host(:not([disabled]):active) {
        background: ${c.DK};
    }

    :host(:${b.N}) {
        border-color: ${v.WN};
    }

    :host::-moz-focus-inner {
        border: 0;
    }
`.withBehaviors((0,$.mr)(x.A`
            :host {
                background: ${y.A.ButtonFace};
                border-color: ${y.A.ButtonText};
            }
            :host .next,
            :host .previous {
                color: ${y.A.ButtonText};
                fill: currentcolor;
            }
            :host(:not([disabled]):hover) {
                background: ${y.A.Highlight};
            }
            :host(:not([disabled]):hover) .next,
            :host(:not([disabled]):hover) .previous {
                color: ${y.A.HighlightText};
                fill: currentcolor;
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]),
            :host([disabled]) .next,
            :host([disabled]) .previous {
                border-color: ${y.A.GrayText};
                color: ${y.A.GrayText};
                fill: currentcolor;
            }
            :host(:${b.N}) {
                forced-color-adjust: none;
                border-color: ${y.A.Highlight};
                box-shadow: 0 0 0 2px ${y.A.ButtonFace},
                    0 0 0 4px ${y.A.ButtonText};
            }
        `),new m.t(x.A``,x.A`
            :host {
                transform: scaleX(-1);
            }
        `)),T=(0,r(60143).B)(),C=l.compose({name:`${i.G.prefix}-flipper`,styles:k,template:T})},71008(t,e,r){"use strict";r.d(e,{h(){return h}});var i=r(56911),n=r(57606),a=r(5291),o=r(95239),s=r(31023),l=r(60815),c=r(74849),d=r(22870),u=r(38493),p=r(93518);class h extends p.X{constructor(){super(...arguments),this.gradientAngle="112.05deg",this.gradientColor=this.cardFillColor,this.gradientVariables=null}cardFillColorChanged(t,e){if(!e)return;if(super.cardFillColorChanged(t,e),!(0,d.Bi)(e))return this.gradientVariables&&this.$fastController.removeStyles(this.gradientVariables),o.p.deleteValueFor(this),void s.r.deleteValueFor(this);const r=(0,d.Hs)(e);r&&(this.neutralPaletteSource=e,o.p.setValueFor(this,a.q.create(r.r,r.g,r.b)))}neutralPaletteSourceChanged(t,e){if(e){const t=(0,d.Hs)(e);if(!t)return;const r=a.q.create(t.r,t.g,t.b);s.r.setValueFor(this,n.p.create(r))}}cardSecondaryColorChanged(){this.handleChange()}gradientAngleChanged(){this.handleChange()}generateGradientVariables(t,e,r){return c.A`
            :host {
                --gradient-angle: ${t};
                --gradient-start-color: ${e};
                --gradient-end-color: ${r};
            }
        `}connectedCallback(){super.connectedCallback(),l.cP.getNotifier(this).subscribe(this,"cardFillColor"),this.handleChange()}handleChange(){this.cardSecondaryColor&&(this.cardFillColor?this.gradientColor=this.cardFillColor:this.gradientColor=o.p.getValueFor(this).toColorString(),this.gradientVariables&&this.$fastController.removeStyles(this.gradientVariables),this.gradientVariables=this.generateGradientVariables(this.gradientAngle,this.gradientColor??"",this.cardSecondaryColor),this.$fastController.addStyles(this.gradientVariables))}}(0,i.Cg)([(0,u.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,i.Sn)("design:type",String)],h.prototype,"neutralPaletteSource",void 0),(0,i.Cg)([(0,u.CF)({attribute:"card-secondary-color",mode:"fromView"}),(0,i.Sn)("design:type",Object)],h.prototype,"cardSecondaryColor",void 0),(0,i.Cg)([(0,u.CF)({attribute:"gradient-angle",mode:"fromView"}),(0,i.Sn)("design:type",String)],h.prototype,"gradientAngle",void 0)},73893(t,e,r){"use strict";r.d(e,{m(){return s}});var i=r(65614),n=r(71008),a=r(42792);const o=r(96950).qy`
    <slot></slot>
`,s=n.h.compose({name:`${i.G.prefix}-card`,styles:a.R7,template:o})},82203(t,e,r){"use strict";r.d(e,{CG(){return k},CY(){return F},N9(){return A},_m(){return x},dY(){return S},es(){return I},ex(){return w},fv(){return D},iD(){return O},qG(){return C},rl(){return L},th(){return T},uU(){return z},vU(){return y}});var i=r(75307),n=r(32623),a=r(89989),o=r(96950);const s=(0,i.Eo)("TagLight",void 0,"icons-wc/icons/shopping"),l=(0,i.Eo)("TagGreen",void 0,"icons-wc/icons/shopping"),c=(0,i.Eo)("FreeShipping",void 0,"icons-wc/icons/shopping"),d=(0,i.Eo)("Truck",void 0,"icons-wc/icons/shopping"),u=(0,i.Eo)("TruckDarkMode",void 0,"icons-wc/icons/shopping"),p=(0,i.Eo)("Ticket",void 0,"icons-wc/icons/shopping"),h=(0,i.Eo)("TicketBlue",void 0,"icons-wc/icons/shopping"),g=(0,i.Eo)("cashback"),v=(0,i.Eo)("cashbackBlue"),m=(0,i.Eo)("fire"),f=(0,i.KN)("view"),b=(0,i.KN)("insight"),$=(0,i.KN)("cart"),y={deal:o.qy`<img src=${s} alt="TagIcon" aria-hidden="true"/>`,freeshipping:o.qy`<img src=${c} alt="FreeShippingIcon" aria-hidden="true"/>`,coupon:o.qy`<img src=${p} alt="TicketIcon" aria-hidden="true"/>`,cashback:o.qy`<img src=${g} alt="CashBackIcon" aria-hidden="true"/>`,hot:o.qy`<img src=${m} alt="FireIcon" aria-hidden="true"/>`,dealGreen:o.qy`<img src=${l} alt="TagGreenIcon" aria-hidden="true"/>`,cashbackBlue:o.qy`<img src=${v} alt="CashbackBlueIcon" aria-hidden="true"/>`,couponBlue:o.qy`<img src=${h} alt="TicketBlueIcon" aria-hidden="true"/>`,freeshippingAlt:o.qy`<img src=${d} alt="TruckIcon" aria-hidden="true"/>`,"freeshippingAlt-dark":o.qy`<img src=${u} alt="TruckIcon" aria-hidden="true"/>`,blackJackCommunityInsight:o.qy`<img src=${$} alt="CartIcon" aria-hidden="true"/>`,blackjackInsight:o.qy`<img src=${b} alt="InsightsIcon" aria-hidden="true"/>`,blackJackViewCount:o.qy`<img src=${f} alt="ViewIcon" aria-hidden="true"/>`},x={attributes:[{attributeType:n.x.Seller,attributeTemplate:a.wj}],imageHeight:160,imageWidth:268,iconTemplateMap:y},w={attributes:[],imageHeight:135,imageWidth:130,iconTemplateMap:y},k={attributes:[{attributeType:n.x.Seller,attributeTemplate:a.wj}],imageHeight:224,imageWidth:268,iconTemplateMap:y},T={attributes:[{attributeType:n.x.Title,attributeTemplate:a.BK},{attributeType:n.x.Seller,attributeTemplate:a.wj}],imageHeight:92,imageWidth:120,iconTemplateMap:y},C={...k,attributes:[{attributeType:n.x.Seller,attributeTemplate:a.wj}],secondaryAttributes:[{attributeType:n.x.Rating,attributeTemplate:a.c6}]},S={attributes:[{attributeType:n.x.Price,attributeTemplate:a.Mt},{attributeType:n.x.Title,attributeTemplate:a.BK},{attributeType:n.x.Seller,attributeTemplate:a.wj},{attributeType:n.x.SalesVolume,attributeTemplate:a.Rp}],iconTemplateMap:y,imageHeight:240,imageWidth:220},F={attributes:[{attributeType:n.x.Title,attributeTemplate:a.BK},{attributeType:n.x.Seller,attributeTemplate:a.wj},{attributeType:n.x.Price,attributeTemplate:a.Mt},{attributeType:n.x.SalesVolume,attributeTemplate:a.Rp}],iconTemplateMap:y,imageHeight:315,imageWidth:240},O={...S,attributes:[...S.attributes,{attributeType:n.x.Rating,attributeTemplate:a.c6}]},P=(n.x.Seller,a.wj,{attributes:[{attributeType:n.x.Title,attributeTemplate:a.BK},{attributeType:n.x.Seller,attributeTemplate:a.wj}],iconTemplateMap:y,cardVariant:n.m.Pivot,imageHeight:142,imageWidth:144,imageCroppingOption:"17",tag:"msn-shopping-prong-pivot-product-card",showSeeAllLink:!0}),z=(n.x.Seller,a.wj,n.x.Price,a.Wj,n.m.Pivot,n.x.Title,a.BK,n.m.Pivot,n.x.Title,a.BK,n.m.Pivot,{attributes:[{attributeType:n.x.Title,attributeTemplate:a.BK},{attributeType:n.x.Seller,attributeTemplate:a.wj}],imageHeight:54,imageWidth:54,imageCroppingOption:"17"}),I={attributes:[],imageHeight:34,imageWidth:34,imageCroppingOption:"17"};function A(t){return t.map(t=>{switch(t){case n.x.Price:return{attributeType:t,attributeTemplate:a.Mt};case n.x.Title:return{attributeType:t,attributeTemplate:a.BK};case n.x.Seller:default:return{attributeType:t,attributeTemplate:a.wj}}})}n.x.Title,a.BK,n.x.Title,a.BK,n.x.Seller,a.BK,n.x.Title,a.wj,n.x.Title,a.BK,n.x.Seller,a.wj;const D={attributes:[{attributeType:n.x.Title,attributeTemplate:a.BK}],imageHeight:240,imageWidth:240};function L(t,e){return t.sort((t,r)=>{const i=e.indexOf(t.attributeType),n=e.indexOf(r.attributeType);return-1===i?1:-1===n?-1:i-n}),t}},84506(t,e,r){"use strict";r.d(e,{d(){return s}});var i=r(56911),n=r(92011),a=r(38493);const o="next";class s extends n.L{constructor(){super(...arguments),this.hiddenFromAT=!0,this.direction=o}keyupHandler(t){if(!this.hiddenFromAT){const e=t.key;"Enter"!==e&&"Space"!==e||this.$emit("click",t)}}}(0,i.Cg)([(0,a.CF)({mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],s.prototype,"disabled",void 0),(0,i.Cg)([(0,a.CF)({attribute:"aria-hidden",converter:a.Bs}),(0,i.Sn)("design:type",Boolean)],s.prototype,"hiddenFromAT",void 0),(0,i.Cg)([a.CF,(0,i.Sn)("design:type",String)],s.prototype,"direction",void 0)},88083(t,e,r){"use strict";r.d(e,{w(){return a}});var i=r(89167),n=r(29853);class a extends i.dN{static buildAbsoluteUrl(t,e,r){const i=new URL(this.bingBaseUrl);return this.updateBingShoppingQueryParameters(i,"msn",e,!0),i.searchParams.set("overlayId",(0,n.yA)(t)),(null==r?void 0:r.length)>0&&i.searchParams.set("overlayOfferIds",r.join(",")),i.href}}a.bingBaseUrl="https://www.bing.com/shop/deals"},93518(t,e,r){"use strict";r.d(e,{X(){return h}});var i=r(56911),n=r(97004),a=r(64183),o=r(95239),s=r(356),l=r(31023),c=r(37302),d=r(96193),u=r(38493),p=r(50866);class h extends d.z{constructor(){super(...arguments),this.size=p.qJ._1x_2y}cardFillColorChanged(t,e){this.isDarkCardGradient()?s.l.setValueFor(this,n.y.DarkMode):this.isLightCardGradient()?s.l.setValueFor(this,n.y.LightMode):s.l.deleteValueFor(this)}isDarkCardGradient(){return Object.values(p.NZ).includes(this.cardFillColor)}isLightCardGradient(){return Object.values(p.L9).includes(this.cardFillColor)}isNamedGradientFillColor(){return this.isLightCardGradient()||this.isDarkCardGradient()}connectedCallback(){super.connectedCallback(),c.jO.setValueFor(this,{evaluate(t,e){return(0,a.o)(t(l.r),e||t(o.p),-1,1,0,0,void 0,2,3,1,2,void 0)}})}}(0,i.Cg)([(0,u.CF)({attribute:"card-fill-color"}),(0,i.Sn)("design:type",Object)],h.prototype,"cardFillColor",void 0),(0,i.Cg)([u.CF,(0,i.Sn)("design:type",String)],h.prototype,"size",void 0)},95854(t,e,r){"use strict";r.d(e,{_G(){return p},_H(){return d},lJ(){return u},sH(){return h}});var i=r(22341),n=r(58792),a=r(96915),o=r(26220);const s=new URLSearchParams((0,o.iA)()),l=s.has("vptest")&&"1"===s.get("vptest"),c=s.get("1Stimeout");function d(t){return c?+c:t}function u(t){var e;const r=new URLSearchParams;if(a.J&&(r.set("ocid",t||a.J.ocid),r.set("apikey",a.J.apiKey),r.set("timeOut",c||a.J.oneServiceTimeout.toString()),r.set(n.T3.OneServiceContentMarketQspKey,null===n.T3||void 0===n.T3?void 0:n.T3.CurrentMarket),r.set("scn",null===n.T3||void 0===n.T3?void 0:n.T3.AuthCookieName),r.set("caller","api")),null!==n.T3&&void 0!==n.T3&&n.T3.UserId&&r.set("user",n.T3.UserId),n.T3.ShouldUseFdheadQsp&&null!==n.T3&&void 0!==n.T3&&null!==(e=n.T3.CurrentRequestTargetScope)&&void 0!==e&&e.pageExperiments){const t=n.T3.CurrentRequestTargetScope.pageExperiments.filter(t=>(t.includes("1s")||t.startsWith("prg-sh")||t.startsWith("prg-spr"))&&"prg-sh-gobgcrsl1"!==t&&"prg-sh-gobgcrsl2"!==t).join();t&&r.set("fdhead",t)}return r}function p(t,e,r,a){l?console.error(`This error is not be logged to AppError. Logging only to the console. error- ${t}. message - ${r}. requestUrl - ${a}`):(0,i.c_)(t,e,`${r}|${n.T3.ActivityId}|${a}`)}function h(t){if(!t)return"";let e="";return t.forEach((t,r)=>{e+=`${r},${t},`}),e.substring(0,e.length-1)}},96193(t,e,r){"use strict";r.d(e,{z(){return n}});var i=r(92011);class n extends i.L{}},96915(t,e,r){"use strict";r.d(e,{J(){return a}});var i=r(58792),n=r(27233);const a={ocid:"anaheim-ntp-feeds",apiKey:"0QfOX3Vn51YCzitbLaRkTTBadtWpgTN8NZLW0C1SEM",oneServiceTimeout:1e4,xapMicroserviceTimeout:7500,baseUrl:`https://assets.msn.${i.T3.CurrentMarket===n.DX.ZHCN?"cn":"com"}/service/news/feed/segments/shopping`,shoppingServiceRelativepath:"/shopping",segmentServiceRelativepath:"/segments/recoitems/shopping",usDcBaseUrl:"https://sf-prod-eastus2.oneservice.msn.com",usDcBaseUrl_segmentService_secondary:"https://sf-prod-westus2.oneservice.msn.com",forumBaseUrl:"https://api.msn.com/shopping",segmentBaseUrl:`https://assets.msn.${i.T3.CurrentMarket===n.DX.ZHCN?"cn":"com"}/service/segments/recoitems/shopping`}},99015(t,e,r){"use strict";r.d(e,{Y(){return d}});var i=r(96950),n=r(60402),a=r(69259),o=r(82774),s=r(10108),l=r(35106),c=r(18893);function d(t={}){return i.qy`
        <template @keyup="${(t,e)=>t.keyupHandler(e.event)}">
            ${(0,l.LT)(t)}
            <div class="scroll-area" part="scroll-area">
                <div
                    class="scroll-view"
                    part="scroll-view"
                    @scroll="${t=>t.scrolled()}"
                    ${(0,n.K)("scrollContainer")}
                >
                    <div
                        class="content-container"
                        part="content-container"
                        ${(0,n.K)("content")}
                    >
                        <slot
                            ${(0,o.e)({property:"scrollItems",filter:(0,s.Y)()})}
                        ></slot>
                    </div>
                </div>
                ${(0,a.z)(t=>"mobile"!==t.view,i.qy`
                        <div
                            class="scroll scroll-prev"
                            part="scroll-prev"
                            ${(0,n.K)("previousFlipperContainer")}
                        >
                            <div class="scroll-action" part="scroll-action-previous">
                                <slot name="previous-flipper">
                                    ${(0,c.R)(t.previousFlipper)}
                                </slot>
                            </div>
                        </div>
                        <div
                            class="scroll scroll-next"
                            part="scroll-next"
                            ${(0,n.K)("nextFlipperContainer")}
                        >
                            <div class="scroll-action" part="scroll-action-next">
                                <slot name="next-flipper">
                                    ${(0,c.R)(t.nextFlipper)}
                                </slot>
                            </div>
                        </div>
                    `)}
            </div>
            ${(0,l.aO)(t)}
        </template>
    `}}}]);