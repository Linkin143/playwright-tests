"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["moment-in-time-hero"],{797(t,e,i){i.r(e),i.d(e,{MomentInTimeHero(){return k},MomentInTimeHeroStyles(){return B},MomentInTimeHeroTemplate(){return N},ToolingInfo(){return O}});var o=i(55615),a=i(7574),n=i(65614),r=i(59836),s=i(84056),d=i(31970),l=i(66690),c=i(56911),h=i(60815),g=i(12680),p=i(39671),v=i(25109),u=i(27160),m=i(85349),x=i(33477),y=i(54229),b=i(3083),f=i(41065),_=i(19359),$=i(15148),w=i(17918),z=i(15938);class k extends p.U{constructor(){super(...arguments),this.ensureObservableBeforeConnect=!0,this.isDark=!1,this.eventListenerRemovers=[],this.themeHandler=()=>{this.setCurrentTheme()},this.processCardData=()=>{var t,e;this.initTelemetry();let i,o="";switch(this.cardType){case u.pL.DailyMomentsCard2:case u.pL.DailyMomentsCard3:case u.pL.MiTHeroContent:var a;this.getContentCardData(this.cardMetadata),o=null===(a=this.cardMetadata.header)||void 0===a?void 0:a.title;break;case u.pL.MiTHeroSpotlight:var n,r;this.flatCardData=this.mapArticleData(this.cardMetadata.content),o=(null===(n=this.cardMetadata.header)||void 0===n?void 0:n.title)||"",i=null===(r=this.cardMetadata.content)||void 0===r?void 0:r.url;break;case u.pL.MiTHeroAction:case u.pL.DailyMomentsCard1:default:this.getFlatCardData(this.cardMetadata),o=null===(t=this.cardMetadata.header)||void 0===t?void 0:t.title,i=null===(e=this.cardMetadata.flatCard)||void 0===e?void 0:e.clickThroughUrl,this.footerData={footerLink:{text:this.strings.CTAtext,navigationUrl:i},isWidgetRegion:!0}}this.cardContainerData={id:"",gridArea:"",childTemplateType:"sd-card",parentTelemetryObject:this.parentTelemetry,cardSize:this.cardSize,headerData:{isActionMenuAvailable:!0,isMoreSettingAvailable:!0,isHideCardAvailable:!1,telemetryHeadlines:{title:o,logo:o},telemetryDestinationUrl:{title:i,logo:i},headerLogo:"",title:o,titleNavigationLink:i,actionMenuData:{moreSettingsPersonalizeCallback:this.goToPersonalizeSettingsCallback}},footerData:this.footerData}}}experienceConnected(){var t;if(this.cardMetadata=(null===(t=this.config)||void 0===t?void 0:t.cardMetaDataOverride)||this.cardMetadata,!this.cardMetadata)return;this.telemetryBuilder=new y.x1,this.setCurrentTheme();const e=window.matchMedia("(prefers-color-scheme: dark)");e.addEventListener("change",this.themeHandler),this.eventListenerRemovers.push(()=>e.removeEventListener("change",this.themeHandler)),this.processCardData()}disconnectedCallback(){super.disconnectedCallback(),this.eventListenerRemovers.forEach(t=>t()),this.eventListenerRemovers=[]}shadowDomPopulated(){this.cardMetadata&&((0,$.D)(()=>{const t=this.getApproxTTVRValue();(0,w.oO)(this.getExperienceType(),!1,t,!t)}),this.markVisuallyReadyRaf())}markVisuallyReadyRaf(){const t=(0,z.ZF)()[w.wL+this.getExperienceType()];super.markVisuallyReadyRaf(t)}getExperienceType(){return g.shR}setCurrentTheme(){this.isDark=(0,v.ud)()}async cardSizeChanged(t,e){t&&t!=e&&await this.processCardData()}initTelemetry(){var t,e;this.telemetryObject=(0,f.N)(this.getExperienceType()),this.mitTelemetryTag=null===(t=this.telemetryObject)||void 0===t?void 0:t.getMetadataTag(),this.cardTelemetryObject=this.cardType&&(0,f.N)(this.cardType),this.cardTelemetryTag=null===(e=this.cardTelemetryObject)||void 0===e?void 0:e.getMetadataTag()}mapArticleData(t){let e=!(arguments.length>1&&void 0!==arguments[1])||arguments[1];const{title:i,url:o,image:a,provider:n,id:r,type:s,videoInformation:d}=t,l="video"===s,c=this.getCropProperties(null==a?void 0:a.focalRegion,a.url?98:void 0);return{id:r,childTemplateType:"sd-card",cardSize:this.cardSize,defaultAnchorTarget:"_blank",destinationUrl:o,gridArea:"",imageData:a&&{source:c&&!this.isListCard?(0,b.oQ)(a.url,c):a.url,altText:a.title||i,options:this.isListCard?c:void 0},immersiveCard:e,mediaType:l?"video":"image",contentType:l?"video":"image",providerData:n&&{name:n.name,logoImage:`${n.logoUrl}?w=16&h=16`},title:i,metadata:{abstract:i,category:"news"},telemetryContext:{componentRoot:this.cardTelemetryObject,destination:(0,_.l)(`${this.cardType}_destination`,{id:r,headline:i,brand:null==n?void 0:n.name,type:l?m.b5.Video:m.b5.Article},m.MS.Navigate),contentCard:(0,_.l)(`${this.cardType}_content`,{id:r,headline:i,brand:null==n?void 0:n.name,type:l?m.b5.Video:m.b5.Article})},hideActionTray:!0,useDarkShadow:!0,videoDuration:l?null==d?void 0:d.videoDuration:void 0,externalVideoFiles:l?null==d?void 0:d.externalVideoFiles:void 0}}getContentCardData(t){var e;const i=[];var o;1===(null===(e=t.contents)||void 0===e?void 0:e.length)?i.push(this.mapArticleData(t.contents[0],!1)):(this.isListCard=!0,this.cgCardSize=t.contents.length,null===(o=t.contents)||void 0===o||o.forEach(t=>{i.push(this.mapArticleData(t))}));this.contentCardData=i}getFlatCardData(t){var e,i;const{title:o,imageUrl:a,clickThroughUrl:n,type:r}=t.flatCard,s=(null===(e=t.header)||void 0===e?void 0:e.title)||"",d=(this.cardType===u.pL.MiTHeroAction||this.cardType===u.pL.DailyMomentsCard1)&&null!=t&&null!==(i=t.flatCard)&&void 0!==i&&i.imageFocalRegion?this.getCropProperties(t.flatCard.imageFocalRegion,a?98:void 0):void 0;this.flatCardData={id:s,childTemplateType:"sd-card",cardSize:this.cardSize,defaultAnchorTarget:"_blank",destinationUrl:n,gridArea:"",imageData:a&&{source:d?(0,b.oQ)(a,d):a,altText:o},immersiveCard:!0,mediaType:"video"===r?"video":"image",title:o,metadata:{abstract:o,category:"news"},telemetryContext:{componentRoot:this.cardTelemetryObject,destination:(0,_.l)(`${this.cardType}_destination`,{id:s,headline:o,type:"video"===r?m.b5.Video:m.b5.Article},m.MS.Navigate),contentCard:(0,_.l)(`${this.cardType}_content`,{id:s,headline:o,type:"video"===r?m.b5.Video:m.b5.Article})},hideActionTray:!0,useDarkShadow:!0}}getCropProperties(t,e){const i={enableDpiScaling:!1,...void 0!==e&&{quality:e},...t&&{mode:b.Pz.FocalCrop,focalRegion:t}};if(this.cardSize===x.uE._2x_2y&&this.cardType===u.pL.MiTHeroSpotlight)return{...i,width:580,height:240};if((this.cardType===u.pL.MiTHeroContent||this.cardType===u.pL.DailyMomentsCard2||this.cardType===u.pL.DailyMomentsCard3)&&!this.isListCard)return{...i,width:268,height:140};if((this.cardType===u.pL.MiTHeroContent||this.cardType===u.pL.DailyMomentsCard2||this.cardType===u.pL.DailyMomentsCard3)&&this.isListCard){if(3===this.cgCardSize)return{...i,width:56,height:56};if(2===this.cgCardSize)return{...i,width:96,height:96}}return this.cardType===u.pL.MiTHeroAction||this.cardType===u.pL.DailyMomentsCard1?{...i,width:268,height:224}:void 0}}(0,c.Cg)([h.sH],k.prototype,"cardMetadata",void 0),(0,c.Cg)([h.sH],k.prototype,"cardSize",void 0),(0,c.Cg)([h.sH],k.prototype,"flatCardData",void 0),(0,c.Cg)([h.sH],k.prototype,"contentCardData",void 0),(0,c.Cg)([h.sH],k.prototype,"isListCard",void 0),(0,c.Cg)([h.sH],k.prototype,"cardContainerData",void 0),(0,c.Cg)([h.sH],k.prototype,"footerData",void 0),(0,c.Cg)([h.sH],k.prototype,"isDark",void 0);var C=i(96950),T=i(69259);const I=C.qy`<div slot="card-content" class="content"><cs-article-card-carousel class="card carousel-no-dark-bg" :data=${t=>t.flatCardData} :size=${t=>t.cardSize}></cs-article-card-carousel></div>`,D=C.qy`<div slot="card-content" class="content"><cs-watch-carousel-card class="carouselCard articleContent carousel-item" :data=${t=>t.flatCardData} :size=${t=>t.cardSize}></cs-watch-carousel-card></div>`,S=C.qy`<div class="wrap"><responsive-sd-card :data="${t=>t.cardContainerData}" size="${t=>t.cardSize}" data-t="${t=>t.cardTelemetryTag}" responsive-sizing-enabled="true">${(0,T.z)(t=>t.flatCardData,t=>{var e;return"video"===(null===(e=t.flatCardData)||void 0===e?void 0:e.mediaType)?D:I})}</responsive-sd-card></div>`,L=C.qy`<div slot="card-content" class="content"><cs-article-card-carousel class="card carousel-no-dark-bg" :data=${t=>t.flatCardData} :size=${t=>t.cardSize}></cs-article-card-carousel></div>`,j=C.qy`<div class="wrap "solid-bg"><responsive-sd-card :data="${t=>t.cardContainerData}" size="${t=>t.cardSize}" data-t="${t=>t.cardTelemetryTag}" responsive-sizing-enabled="true">${(0,T.z)(t=>t.flatCardData,L)}</responsive-sd-card></div>`;var A=i(58792);const E=C.qy`<div slot="card-content" class="content"><responsive-list class="list" :contentList=${t=>t.contentCardData} :size=${t=>t.cardSize}></responsive-list></div>`,H=C.qy`<span class="playIndicator"><img aria-hidden="true" role="presentation" src="${(0,A.rA)().StaticsUrl}/latest/fluent-icons/play_24_filled.svg"></img></span>`,F=C.qy`<div slot="card-content" class="container"><div class="single-content"><div class="image-single"><div class="articleImageContainer"><img src=${t=>{var e;return null===(e=t.contentCardData)||void 0===e||null===(e=e[0])||void 0===e||null===(e=e.imageData)||void 0===e?void 0:e.source}} alt="" />${(0,T.z)(t=>{var e;return"video"==(null===(e=t.contentCardData)||void 0===e||null===(e=e[0])||void 0===e?void 0:e.mediaType)},H)}</div></div><div class="attribution"><img slot="image" class="provider-logo" src=${t=>{var e;return null===(e=t.contentCardData)||void 0===e||null===(e=e[0])||void 0===e||null===(e=e.providerData)||void 0===e?void 0:e.logoImage}}/><p class="provider-name">${t=>{var e;return null===(e=t.contentCardData)||void 0===e||null===(e=e[0])||void 0===e||null===(e=e.providerData)||void 0===e?void 0:e.name}}</p></div><div class="title"><a class="single-heading" data-t="${t=>{var e;return null===(e=t.contentCardData)||void 0===e||null===(e=e[0])||void 0===e||null===(e=e.telemetryContext)||void 0===e||null===(e=e.destination)||void 0===e?void 0:e.getMetadataTag()}}" href=${t=>{var e;return null===(e=t.contentCardData)||void 0===e||null===(e=e[0])||void 0===e?void 0:e.destinationUrl}} target="_blank">${t=>{var e;return null===(e=t.contentCardData)||void 0===e||null===(e=e[0])||void 0===e?void 0:e.title}}</a></div></div></div>`,M=C.qy`<div class="wrap"><responsive-sd-card class="${t=>{var e;return t.isListCard?`content-list-card-${null===(e=t.contentCardData)||void 0===e?void 0:e.length}`:"content-single-card"}}" :data="${t=>t.cardContainerData}" size="${t=>t.cardSize}" data-t="${t=>t.cardTelemetryTag}" responsive-sizing-enabled="true">${(0,T.z)(t=>{var e;return t.isListCard&&(null===(e=t.contentCardData)||void 0===e?void 0:e.length)},E)} ${(0,T.z)(t=>{var e;return!t.isListCard&&(null===(e=t.contentCardData)||void 0===e?void 0:e.length)},F)}</responsive-sd-card></div>`,R=(0,i(50193).C)(`TTSR.${g.shR}`),N=C.qy`<div data-t="${t=>t.mitTelemetryTag}" class="hovershadow">${(0,T.z)(t=>t.cardMetadata,t=>function(t){switch(t){case u.pL.MiTHeroSpotlight:return S;case u.pL.DailyMomentsCard2:case u.pL.DailyMomentsCard3:case u.pL.MiTHeroContent:return M;case u.pL.MiTHeroAction:case u.pL.DailyMomentsCard1:return j;default:return S}}(t.cardType))} ${R}</div>`;var P=i(74849),U=i(48751);const B=P.A` cs-article-card-carousel{z-index:1}cs-watch-carousel-card{z-index:1}responsive-list::part(listContent){padding:0px 5px}.image-single{grid-area:image;border-radius:8px;overflow:hidden;position:relative;cursor:pointer;user-select:none;z-index:1;align-items:center;justify-content:center;margin-bottom:16px}:host(:hover) .image-single{filter:brightness(0.9)}.single-content{width:100%;height:100%;color:${U.l};
    display: flex;
    flex-direction: column;
    text-decoration: unset;
    position: relative;
}

.attribution {
    grid-area: attribution;
    align-items: center;
    box-sizing: border-box;
    display: inline-flex;
    font-size: 12px;
    height: 16px;
    line-height: 16px;
    margin-bottom: 4px;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 100%;
}

.provider-logo {
    margin-inline-end: calc(var(--design-unit)* 2px);
}

.title {
    grid-area: title;
}

.single-heading {
    color: inherit;
    display: -webkit-box;
    font-size: 14px;
    font-weight: 600;
    line-height: 20px;
    overflow: hidden;
    text-decoration: none;
    -webkit-line-clamp: var(--heading-lines, 3);
    -webkit-box-orient: vertical;
}

.single-heading::after {
    bottom: 0px;
    content: "";
    height: 100%;
    left: 0px;
    position: absolute;
    right: 0px;
    width: 100%;
    z-index: 1;
}

.articleImageContainer {
    aspect-ratio: 268/140;
    display: flex;
    position: relative;
    align-items: center;
    justify-content: center;
}

.articleImageContainer img {
    height: 100%;
    width: 100%;
}

.playIndicator {
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, .2);
    border-radius: 50%;
    display: flex;
    padding: 3.36%;
    position: absolute;

}

.playIndicator img {
    filter: invert(1);
    width: 24px;
}

@container (width < 300px) {
    .single-heading {
        -webkit-line-clamp: 2;
    }
}
`;(0,s.J)(),d.G.define(n.G.registry),(0,a.o)(),(0,o.c)(),l.csResponsiveList.define(n.G.registry),r.m.define(n.G.registry);const O={experienceConfigSchema:undefined}},1413(t,e,i){i.d(e,{P(){return n},y(){return r}});var o=i(96950),a=i(82774);function n(t,e){return e?.some(e=>e.slot===t)}function r(t){const e=t.slotName??"";return o.qy`
        <div id="${e}" class="${e}" part="${e}">
            <slot
                name="${e}"
                ${t.slottedRef?(0,a.e)(t.slottedRef):""}
            >
                ${t.slottedDefault??""}
            </slot>
        </div>
    `}},4968(t,e,i){i.d(e,{f(){return d}});var o=i(64187),a=i(74849),n=i(42792),r=i(99657),s=i(36452);const d=a.A.partial`position: relative; z-index: ${r.D};`;a.A`
    ${n.e}
    ${n.nH}

    ${(0,o.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${d}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(n.kc)},26831(t,e,i){i.d(e,{Hg(){return r}});var o=i(58792),a=i(26220);const n=/[:/?#[\]@!$&'()*+,;=]/g;function r(t,e,i,r){let s=`${o.T3.NavTargetUrlWithLocale}/channel`;if(t&&i){const o="source"===i?"sr":"tp";s+="/"+[i,e?encodeURIComponent(e.replace(n,"")):"",`${o}-${t}`].filter(t=>t).join("/")}const d=new URL(s);return r||(d.search=(0,a.iA)()),(0,a.ou)().includes("localhost.msn.com")&&(d.host=(0,a.ou)()),d.toString()}},54229(t,e,i){i.d(e,{aC(){return x},YJ(){return n},x1(){return r},iJ(){return u},h9(){return m},LE(){return g},Eh(){return c},Ai(){return l},dI(){return h},j8(){return p},ao(){return v}});var o=i(85349),a=i(19359);const n={Customize:o.MS.Customize,Paginate:o.MS.Paginate,Hide:o.MS.Hide,Cancel:o.MS.Cancel,Close:o.MS.Close,Dislike:o.MS.Dislike,Show:o.MS.Show,Click:o.MS.Click};class r{createTelemetryObjectTag(t){return t?t.getMetadataTag():""}createTelemetryObject(t,e,i,n){if(!t||!e)return;const{name:r,content:s,...d}=e,l={...s,type:(null==s?void 0:s.type)||o.b5.StructuredData,vertical:this.verticalName,category:this.categoryName,subcategory:this.subCategoryName},c={...this.ext,signature:i};n&&(c.previewType=n);const h={...d,ext:c,zone:this.zone};return(0,a.g)(r,l,h)}createViewTelemetryObject(t,e){return this.createTelemetryObject(t,{name:e.name,action:o.EG.View,behavior:o.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType)}createViewTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:o.MS.View,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createNavClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:o.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createAddClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:o.MS.Add,type:o.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createHoverShowTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:o.EG.Hover,behavior:o.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createMouseLeaveCloseTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:o.EG.MouseLeave,behavior:o.MS.Close,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createDislikeActionTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:o.MS.Dislike,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createFollowTelemetryTag(t,e,i){const a=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:i?o.MS.Follow:o.MS.Unfollow,type:o.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(a)}createMenuDataProviderTelemetryTag(t,e,i){const a=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:o.MS.Undefined,type:o.MJ.ActionButton,content:{headline:e.headline},zone:i},e.signature,e.previewType);return this.createTelemetryObjectTag(a)}createNavClickWithTypeTelemetryTag(t,e,i){const a=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:o.MS.Navigate,type:i,content:{headline:e.headline,id:e.id,brandId:e.brandId,type:e.type||o.b5.StructuredData}},e.signature,e.previewType);return this.createTelemetryObjectTag(a)}createBehaviorTelemetryTag(t,e,i){const a=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:i,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(a)}createBaseContentCardTelemetryContext(t,e){const i=this.createTelemetryObject(t,{name:e.name,type:o.MJ.ContentCard,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType),a=this.createTelemetryObject(i,{name:e.name,type:o.MJ.Headline,behavior:o.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);if(i&&a)return{contentCard:i,destination:a}}initTelemetryBuilder(t,e,i,o,a){this.verticalName=t,this.categoryName=e,this.ext=i,this.zone=o,this.subCategoryName=a}updateExt(t){this.ext=t}}var s=i(77367),d=i(84742);function l(t){try{s.YT.sendActionEvent(t,o.EG.MouseLeave,o.MS.Close)}catch(t){return}}function c(t){try{s.YT.sendActionEvent(t,o.EG.Hover,o.MS.Show)}catch(t){return}}function h(t,e){try{s.YT.sendActionEvent(t,o.EG.Click,o.MS.Navigate,e)}catch(t){return}}function g(t,e,i){try{s.YT.sendActionEvent(t,e?o.EG.KeyPress:o.EG.Click,i?o.MS.Follow:o.MS.Unfollow)}catch(t){return}}function p(t){try{if(!t)throw new Error("Current target is undefined, cannot send content view telemetry.");s.YT.sendContentViewEvent(t,d.ym.View)}catch(t){return}}function v(t,e){const i=e?`${e}`:"";s.YT.addOrUpdateTmplProperty(t,i)}function u(t){s.YT.removeTmplProperty(t)}function m(t){for(const e of t)u(e)}var x,y=i(22341);!function(t){t.safeExecute=function(t,e,i,o,a){let n=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return t()}catch(t){return i&&(0,y.vV)(i,`${o}: ${null==t?void 0:t.message}`,a,n),e}},t.safeExecuteAsync=async function(t,e,i,o,a){let n=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return await t()}catch(t){return i&&(0,y.vV)(i,`${o}: ${null==t?void 0:t.message}`,a,n),Promise.resolve(e)}},t.logExceptionWithFormat=function(t,e,i,o,a){let n=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};(0,y.c_)(t,e,`${o}${o?": ":""}${i}`,a,n)},t.logErrorWithFormat=function(t,e,i,o){let a=arguments.length>4&&void 0!==arguments[4]?arguments[4]:{};(0,y.vV)(t,`${i}${i?": ":""}${e}`,o,a)}}(x||(x={}))},55615(t,e,i){i.d(e,{c(){return r}});var o=i(84056),a=i(65614),n=i(97823);const r=()=>{(0,o.J)(),n.r.define(a.G.registry)}},59836(t,e,i){i.d(e,{m(){return m}});var o=i(65614),a=i(92011);class n extends a.L{}var r=i(7896),s=i(61138),d=i(48751),l=i(74838),c=i(74849),h=i(64187),g=i(22131),p=i(50882);const v=c.A`
    ${(0,h.V)("inline-flex")} :host {
        box-sizing: border-box;
        font-family: ${r.O};
        font-size: ${s.k};
        font-weight: 400;
        line-height: ${s.F};
        align-items: center;
        color: ${d.l};
        min-height: 16px;
    }

    .content {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        align-self: baseline;
    }

    ::slotted([slot="image"]) {
        display: flex;
        margin-inline-end: calc(${l.vR} * 2px);
    }
`.withBehaviors((0,g.mr)(c.A`
            :host,
            .content {
                color: ${p.A.ButtonText};
                fill: currentcolor;
            }
        `)),u=i(96950).qy`
    <slot name="image"></slot>
    <span part="content" class="content">
        <slot></slot>
    </span>
`,m=n.compose({name:`${o.G.prefix}-attribution`,styles:v,template:u})},66690(t,e,i){i.d(e,{csResponsiveList(){return U}});var o=i(89580),a=i(48751),n=i(4283),r=i(74089),s=i(4968),d=i(74849),l=i(22131),c=i(4126),h=i(69904);const g=d.A` .container{display:grid;grid-template-columns:1fr 1fr}.articleContent{height:max-content}`,p=d.A`
.articleHeadingInfo:hover .articleTitle{text-decoration:underline}`,v=d.A` .articleTitle{font-size:${o.Y};
        line-height: ${o.v};-webkit-line-clamp:3}cs-attribution{margin-bottom:6px}`,u=d.A` .articleContent.selected{background:#EBEBEB}.articleContent:hover{background:#F5F5F5}.articleContent:active{background:#E0E0E0}@media (prefers-color-scheme:dark){.articleContent.selected{background:#383838}.articleContent:hover{background:#3D3D3D}.articleContent:active{background:#1F1F1F}}`,m=d.A`
.articleContent:hover{background:rgba(255,255,255,0.06)}.articleContent.selected{background:#26292E}`,x=d.A`
.container{height:100%}.articleContent{border-radius:8px;color:${a.l};display:grid;gap:12px;grid-template-columns:auto var(--responsive-list-image-size,20.9%);height:33.33%;overflow:hidden;text-decoration:none;padding:0px 16px}a.articleContent:focus-visible{outline-offset:-1px}.articleContent.noImage{grid-template-columns:auto}.articleContent.selected{background:#F6F9FC}a{${s.f}}.articleContent:hover{background:rgba(0,0,0,0.04)}.articleHeadingInfo{height:fit-content;margin:auto 0px;min-height:60px;overflow:hidden}cs-attribution{display:flex;margin-bottom:4px;max-width:100%}cs-attribution::part(content){color:var(--content-color,${a.l})}cs-attribution .attribution-image{height:16px;width:16px}cs-attribution .divider{padding-inline-end:1px}cs-attribution .time{margin-inline-start:2px;unicode-bidi:embed}cs-attribution .webContentIcon{filter:invert(var(--iconInvert,0));margin:0px 2px;opacity:0.5;vertical-align:bottom}.articleTag{padding:1px 4px 3px;white-space:nowrap;border-radius:6px;background:${n.IR};
    color: ${r.l_}}.articleTag.breaking{background:#E10303}.articleTitle{display:-webkit-box;font-size:${h.Kg};
    font-weight: 600;
    line-height: ${h.Z6};
    overflow: hidden;
    -webkit-line-clamp: var(--responsive-list-title-lineheight, 2);
    -webkit-box-orient: vertical;
}

.articleImageContainer {
    display: flex;
    position: relative;
    align-items: center;
    justify-content: center;
}

.articleImage {
    aspect-ratio: 1/1;
    border-radius: 8px;
    margin: auto;
    max-width: 72px;
    width: 100%;
    object-fit: var(--responsive-list-image-object-fit, unset);
}

.articleContent.oneItemList {
    height: 100%;
}

.articleContent.twoItemList {
    --responsive-list-image-size: 35.8%;
    height: 50%;
}

.twoItemList .articleHeadingInfo {
    min-height: 92px;
}

.twoItemList .articleTitle {
    --responsive-list-title-lineheight: 3;
}

.twoItemList .articleImage {
    max-width: 116px;
}

.playIndicator {
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, .2);
    border-radius: 50%;
    display: flex;
    padding: 5px;
    position: absolute;
}

.playIndicator img {
    filter: invert(1);
    width: 14px;
}

@container (width < 300px) {
    .articleHeadingInfo {
        min-height: min-content;
    }

    .articleTitle {
        --responsive-list-title-lineheight: 1;
    }
}
`.withBehaviors((0,l.G2)(m),new c.o("horizontalMode",!0,g),new c.o("useSubtleControlColors",!0,u),new c.o("useSubtleItemSize",!0,v),new c.o("underlineTitle",!0,p));var y=i(96950),b=i(69259),f=i(39957),_=i(14475),$=i(60402),w=i(22162),z=i(58792);const k=`${(0,z.rA)().StaticsUrl}/latest/fluent-icons/globe_16_regular.svg`,C=y.qy`<cs-attribution>${(0,b.z)(t=>t.attrBadge,y.qy`<span class="articleTag ${t=>{var e;return null===(e=t.attrBadge)||void 0===e?void 0:e.type}}" slot="image">${t=>{var e,i;return(null===(e=t.attrBadge)||void 0===e?void 0:e.localizedLabel)||(null===(i=t.attrBadge)||void 0===i?void 0:i.value)}}</span>`)} ${(0,b.z)(t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.logoImage},y.qy`<img alt="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}" aria-hidden="true" class="attribution-image" decoding="${t=>t.enableLazyImage?"async":""}" loading="${t=>t.enableLazyImage?"lazy":""}" part="image" slot="image" src="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.logoImage}}" title="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}" @load=${t=>t.visualReadinessCallback&&t.visualReadinessCallback(1,w.j.provider)} />`)} ${(0,b.z)(t=>t.providerData&&t.providerData.name,y.qy`<span style="unicode-bidi: embed;" class="attribution-text" title="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}">${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}</span>`)} ${(0,b.z)(t=>t.isWebContent&&!t.metadata.videoMetadata,y.qy`<img class="webContentIcon" src="${k}">`)} ${(0,b.z)(t=>t.publishedDateTime,y.qy`<span aria-hidden="true" class="divider" focusable="false">·</span><span class="time">${t=>t.publishedDateTime}</span>`)}</cs-attribution>`,T=y.qy`<span class="playIndicator"><img aria-hidden="true" role="presentation" src="${(0,z.rA)().StaticsUrl}/latest/fluent-icons/play_16_filled.svg"></img></span>`,I=y.qy`<div class="articleImageContainer"><img class="articleImage" part="articleImage" src=${(t,e)=>{var i;return t.imageData?e.parent.getScaledListItemImage(t.imageData.source,null===(i=t.imageData)||void 0===i?void 0:i.options):""}} alt=${t=>{var e;return(null===(e=t.imageData)||void 0===e?void 0:e.altText)??""}}>${(0,b.z)((t,e)=>{var i;return(null===(i=e.parent.contentList)||void 0===i?void 0:i.length)>1&&"video"==t.contentType},T)}</div>`,D=y.qy` ${()=>C}<span class="articleTitle" ${(0,$.K)("articleContentRef")}>${t=>t.title}</span>`,S=y.qy`<span class="articleTitle" ${(0,$.K)("articleContentRef")}>${t=>t.title}</span>${()=>C}
`,L=y.qy`<a role="listitem" part="listContent" class=${(t,e)=>{var i;return((t,e,i)=>{let o="articleContent";return 1===t&&(o+=" oneItemList"),2===t&&(o+=" twoItemList"),e||(o+=" noImage"),i&&(o+=" selected"),o})(null===(i=e.parent.contentList)||void 0===i?void 0:i.length,!!t.imageData,t.selected||!1)}} href=${t=>t.destinationUrl} target="${(t,e)=>((t,e)=>e?_.z._self:t.openLinksInNewTab?_.z._blank:t.defaultAnchorTarget||_.z._self)(t,e.parent.config.enableOpenContentInSelf)}" title=${t=>t.title} data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.destination)||void 0===e?void 0:e.getMetadataTag()}}" @click="${(t,e)=>e.parent.clickHandler(t,e)}"><div class="articleHeadingInfo" part="listContentInfo">${(0,b.z)((t,e)=>e.parent.enableFlipTitleProvider,S,D)}</div>${(0,b.z)(t=>t.imageData,I)}</a>`,j=y.qy`<div class="container" role="list" data-t="${t=>{var e;return null===(e=t.listContainerTelemetry)||void 0===e?void 0:e.getMetadataTag()}}">${(0,b.z)(t=>null==t?void 0:t.contentList,y.qy` ${(0,f.ux)(t=>t.contentList,L,{positioning:!0})} `)}</div>`;var A=i(56911),E=i(92011),H=i(60815),F=i(38493),M=i(3083),R=i(10809),N=i(27160);class P extends E.L{connectedCallback(){this.config=R.D.getConfig(),this.enableFlipTitleProvider=this.config.enableFlipTitleProvider,this.underlineTitle=this.contentList&&this.contentList[0]&&this.contentList[0].underlineTitle,super.connectedCallback()}getScaledListItemImage(t,e){const i={width:100,height:100,enableDpiScaling:!1,...e};return(0,M.oQ)(t,i)}clickHandler(t,e){return t.useMobile&&!t.isMsnMobile?(t.mobileCardClickCallback(e.event,N.pL.Article,t,"article card"),!1):(t.contentClickCallback&&t.contentClickCallback(t,e),!0)}}(0,A.Cg)([H.sH],P.prototype,"contentList",void 0),(0,A.Cg)([H.sH],P.prototype,"listContainerTelemetry",void 0),(0,A.Cg)([(0,F.CF)({attribute:"horizontal-mode",mode:"boolean"})],P.prototype,"horizontalMode",void 0),(0,A.Cg)([(0,F.CF)({attribute:"use-subtle-control-colors",mode:"boolean"})],P.prototype,"useSubtleControlColors",void 0),(0,A.Cg)([(0,F.CF)({attribute:"use-subtle-item-size",mode:"boolean"})],P.prototype,"useSubtleItemSize",void 0),(0,A.Cg)([(0,F.CF)({attribute:"underline-title",mode:"boolean"})],P.prototype,"underlineTitle",void 0),(0,A.Cg)([(0,F.CF)({attribute:"enable-flip-title-provider",mode:"boolean"})],P.prototype,"enableFlipTitleProvider",void 0);const U=P.compose({name:"responsive-list",styles:x,template:j})},73893(t,e,i){i.d(e,{m(){return s}});var o=i(65614),a=i(71008),n=i(42792);const r=i(96950).qy`
    <slot></slot>
`,s=a.h.compose({name:`${o.G.prefix}-card`,styles:n.R7,template:r})},80090(t,e,i){i.d(e,{m(){return S}});var o=i(65614),a=i(11310),n=i(7896),r=i(48751),s=i(41123),d=i(57416),l=i(62047),c=i(14996),h=i(89580),g=i(99657),p=i(86856),v=i(74849),u=i(73477),m=i(4126),x=i(22131),y=i(50882);const b=v.A`
    .text,
    .media-info,
    .gradient {
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
    }

    .action-tray {
        transition-duration: var(--video-transition-end-duration);
        transition-property: background-color;
    }

    ::slotted([slot="media-overlay"]) {
        color: #ffffff;
        fill: #ffffff;
        height: 40px;
        min-width: 40px;
        display: grid;
        padding: 0px;
        grid-auto-flow: column;
        grid-gap: 8px;
        box-sizing: border-box;
        align-items: center;
        justify-content: center;
        border-radius: 20px;
        border: 1px solid transparent;
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
        background: linear-gradient(
                    135deg,
                    rgba(0, 0, 0, 0.5) 0%,
                    rgba(0, 0, 0, 0.7) 100%
                )
                padding-box,
            linear-gradient(
                    180deg,
                    rgba(255, 255, 255, 0.4) 0%,
                    rgba(255, 255, 255, 0.2) 100%
                )
                border-box;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 22px;
        min-width: 22px;
        padding: 0 6px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 38px;
        min-width: 38px;
        padding: 0 6px;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([animate-video]) .media-info,
    :host([immersive-card][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_1x_2y"][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_2x_2y"][animate-video]) ::slotted([slot="media-overlay"]) {
        transition-delay: var(--video-transition-delay);
        transition-duration: var(--video-transition-start-duration);
        opacity: 0;
    }
`,f=v.A`
    .preload {
        transition: none !important;
    }

    :host {
        --content-padding: 16px;
        --no-image-action-tray-padding: 20px;
        --action-tray-padding: 10px;
        width: 100%;
        height: 100%;
        font-family: ${n.O};
        --video-transition-delay: 1s;
        --video-transition-start-duration: 1s;
        --video-transition-end-duration: 1s;
    }

    :host([subscibed])::after {
        position: absolute;
        content: "";
        bottom: 0;
        left: 0;
        right: 0;
        height: 4px;
        width: 100%;
        background: linear-gradient(90deg, #ffa03d 0%, #ffdb00 100%);
    }

    :host([size="_1x_2y"]),
    :host([size="_2x_2y"]) {
        --content-card-heading-font-size: 18px;
        --content-card-heading-line-height: 24px;
    }

    :host .content {
        display: grid;
        grid-template-columns: 1fr minmax(auto, 84px);
        grid-template-rows: 1fr auto;
        row-gap: 14px var(--content-padding) var(--content-padding) var(--content-padding);
        column-gap: 12px;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        color: ${r.l};
        position: relative;
    }

    :host([size="_1x_1y"]) .content {
        row-gap: 0px;
        padding: 14px var(--content-padding) 10px var(--content-padding);
    }

    :host([size="_2x_1y"]) .content {
        row-gap: 0px;
        padding: var(--content-padding) var(--content-padding) 14px var(--content-padding);
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        grid-template-columns: 1fr;
        column-gap: 0;
    }

    :host([size="_1x_2y"]) .content {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]) .content.no-image {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .content:not(.no-image) .text {
        padding-top: 12px;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .content:not(.no-image) .text {
        padding-top: 0;
    }

    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        align-items: end;
        grid-template-rows: 1fr auto auto;
    }

    :host([size="_2x_2y"]) .no-image {
        align-items: unset;
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content {
        padding: 0;
        row-gap: 0;
    }

    :host([size="_1x_1y"]) .content.no-image,
    :host([size="_2x_1y"]) .content.no-image,
    :host([size="_1x_2y"]) .content.no-image,
    :host([size="_2x_2y"]) .content.no-image {
        grid-template-rows: 1fr auto;
    }

    ::slotted([slot="abstract"]) {
        display: none;
        overflow: hidden;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: var(--abstract-max-lines, 7);
        margin-top: var(--abstract-margin-top, 5px);
    }

    .no-image ::slotted([slot="abstract"]) {
        display: -webkit-box;
        -webkit-line-clamp: var(--abstract-max-lines, 3);
    }

    :host([size="_1x_1y"]) .no-image ::slotted([slot="abstract"]),
    :host([size="_2x_1y"]) .no-image ::slotted([slot="abstract"]) {
        --abstract-max-lines: 1;
    }

    .text {
        grid-area: 1 / 1;
        padding: var(--content-padding) var(--content-padding) 0 var(--content-padding);
        overflow: hidden;
        font-size: ${s.K};
        line-height: ${s.Z};
    }

    :host([size="_1x_1y"]) .text,
    :host([size="_2x_1y"]) .text {
        padding: 0;
    }

    :host([size="_1x_1y"]) .no-image .text,
    :host([size="_2x_1y"]) .no-image .text {
        grid-column: 1 / span 2;
    }

    :host([size="_1x_2y"]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        padding: 14px var(--content-padding) 0 var(--content-padding);
        grid-row: 1;
    }

    :host([size="_2x_2y"]) .text,
    :host([size="_1x_2y"]) .text {
        grid-row: 2;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .text {
        background-color: var(--image-gradient-overlay-end-color);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray,
    :host([size="_1x_2y"]:not([immersive-card])) .action-tray,
    :host .no-image .action-tray {
        background-color: transparent;
    }

    :host([immersive-card]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        background: unset;
    }

    :host([size="_1x_2y"]) .action-tray,
    :host([size="_2x_2y"]) .action-tray {
        grid-row: 3;
        padding: 4px var(--content-padding) var(--action-tray-padding)
            var(--content-padding);
    }

    :host([immersive-card]) .action-tray,
    :host([size="_2x_2y"]) .content:not(.no-image) .action-tray {
        padding: var(--action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
    }

    .action-tray {
        grid-row: 2;
        grid-column: span 2;
        display: flex;
        position: relative;
        background-color: var(--image-gradient-overlay-end-color);
        padding: var(--action-tray-padding) var(--content-padding) var(--content-padding)
            var(--content-padding);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray {
        padding: 0;
    }

    :host([size="_2x_1y"]) .content:not(.no-image) .action-tray {
        grid-area: 2 / 1 / auto / auto;
    }

    :host([size="_1x_1y"]) .no-image .action-tray {
        padding: 4px 0 0 0;
    }

    :host([size="_1x_2y"]) .no-image .action-tray,
    :host([size="_2x_2y"]) .no-image .action-tray {
        padding: var(--no-image-action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
        background: none;
        grid-row: 2;
        grid-column: 1;
    }

    .media-info {
        display: grid;
        grid-auto-flow: column;
        width: fit-content;
        grid-gap: 4px;
        fill: white;
        color: white;
        margin-bottom: 8px;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .media-info {
        grid-row: 1;
        grid-column: 1;
        align-self: flex-end;
        margin-bottom: 6px;
        margin-inline-start: 6px;
    }

    :host([size="_2x_1y"]:not([immersive-card])) .media-info {
        grid-area: 1 / 2 / span2 / auto;
        align-self: flex-end;
        margin-bottom: 8px;
        margin-inline-start: 6px;
    }

    ::slotted([slot="media-info"]) {
        display: grid;
        align-items: center;
        grid-auto-flow: column;
        grid-gap: 3px;
        background-color: var(--image-gradient-overlay-end-color);
        border-radius: calc(${d.Pb} * 1px);
        padding: 2px 6px;
        font-size: ${l.t};
        line-height: ${l.e};
    }

    ::slotted([slot="hide-story"]) {
        box-sizing: border-box;
        align-items: center;
        background-color: #ffffff;
        border-radius: 100%;
        border: 1px solid #e5e5e5;
        color: rgba(0, 0, 0 1);
        cursor: pointer;
        display: flex;
        fill: currentcolor;
        font-family: ${n.O};
        font-size: ${s.K};
        height: 28px;
        justify-content: center;
        line-height: ${s.Z};
        margin-inline-start: 4px;
        min-width: 28px;
        outline: none;
        padding: 0;
        position: relative;
    }

    ::slotted([slot="hide-story"]:hover) {
        background-color: #f2f2f2;
    }

    ::slotted([slot="hide-story"]:active) {
        background-color: #f7f7f7;
    }

    :host .hide-story-wrapper {
        position: absolute;
        display: flex;
        flex-direction: row;
        top: var(--content-padding);
    }

    :host .hide-story {
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.1s linear;
    }

    :host(:hover) .hide-story,
    :host(:focus-within) .hide-story {
        opacity: 1;
    }

    :host ::slotted([slot="hide-story"]:${u.N}) {
        border-color: ${c.WN};
    }

    ::slotted([slot="media"]) {
        grid-column: 1;
        object-fit: cover;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media"]) {
        height: 84px;
        width: 84px;
        grid-row: 1;
        grid-column: 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media"]) {
        height: 114px;
        width: 216px;
        grid-area: 1 / 2 / span2 / 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_1x_2y"]) ::slotted([slot="media"]) {
        grid-row: 1;
        grid-column: 1;
        height: 157px;
        width: 100%;
        display: flex;
    }

    :host([size="_2x_2y"]) ::slotted([slot="media"]),
    :host([immersive-card]) ::slotted([slot="media"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
    }

    ::slotted([slot="attribution"]) {
        display: flex;
        grid-column: 1;
        grid-row: 1;
        margin-bottom: 8px;
    }

    :host([size="_1x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]),
    :host([size="_2x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]) {
        grid-column-end: 1;
    }

    .heading {
        color: ${r.l};
        fill: currentcolor;
        display: -webkit-box;
        outline: 0;
        overflow: hidden;
        text-decoration: none;
        -webkit-line-clamp: var(--heading-max-lines, 3);
        -webkit-box-orient: vertical;
        font-weight: 600;
        font-size: var(--content-card-heading-font-size, ${h.Y});
        line-height: var(--content-card-heading-line-height, ${h.v});
    }

    .heading:focus-visible {
        text-decoration: underline;
    }

    .heading:after {
        bottom: 0;
        content: "";
        height: 100%;
        left: 0;
        position: absolute;
        right: 0;
        width: 100%;
        z-index: ${g.I};
    }

    :host([size="_2x_2y"][immersive-card]) .heading {
        --heading-max-lines: 2;
    }

    .media-overlay {
        position: absolute;
        display: flex;
        align-items: center;
        justify-content: center;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        pointer-events: none;
    }

    :host([size="_1x_1y"]) .media-overlay {
        grid-column: 2;
        grid-row: 1;
        height: 84px;
        width: 84px;
    }

    :host([size="_1x_2y"]) .media-overlay {
        grid-row-start: 1;
        grid-row-end: 1;
    }

    :host([size="_2x_2y"]) .media-overlay,
    :host([immersive-card]) .media-overlay {
        top: 100px;
        align-items: unset;
    }

    :host([size="_1x_2y"]) .no-image .heading,
    :host([size="_2x_2y"]) .no-image .heading {
        --heading-max-lines: 9;
    }

    :host([size="_2x_1y"]) .media-overlay {
        grid-area: 1 / 2 / span2 / 2;
        height: 114px;
        width: 216px;
    }

    ::slotted(p) {
        font-weight: 400;
        font-size: var(--abstract-font-size, 14px);
        line-height: var(--abstract-line-height, 20px);
        font-kerning: auto;
        margin: 8px 0px 0px;
    }

    ::slotted([slot="footer-start"]),
    ::slotted([slot="footer-end"]),
    ::slotted([slot="hide-story"]) {
        z-index: ${g.D};
    }

    .footer-end,
    .footer-start {
        display: flex;
        align-items: center;
    }

    .footer-end {
        margin-inline-start: auto;
    }

    .gradient {
        background: linear-gradient(
            180deg,
            var(--image-gradient-overlay-start-color) 0%,
            var(--image-gradient-overlay-end-color) 100%
        );
        grid-row: 1;
        height: 100%;
        display: none;
    }

    :host([size="_2x_2y"]) .gradient,
    :host([immersive-card]) .gradient {
        display: block;
        height: 80px;
    }

    :host([size="_2x_2y"]) .no-image .gradient,
    .no-image .gradient {
        display: none;
    }

    :host([size="_2x_1y"]) .content {
        column-gap: 24px;
    }
`.withBehaviors(new m.o("mediaType","video",b),new p.t(v.A`
            :host .hide-story-wrapper {
                right: var(--content-padding);
            }
        `,v.A`
            :host .hide-story-wrapper {
                left: var(--content-padding);
            }
        `),(0,x.mr)(v.A`
            :host {
                forced-color-adjust: auto;
            }
            .gradient {
                display: none;
            }
            :host([size="_1x_2y"]) .content,
            :host([size="_1x_1y"]) .content,
            :host([size="_2x_1y"]) .content {
                background: ${y.A.ButtonFace};
            }
            :host([size="_1x_2y"]) .text,
            :host([size="_1x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .text,
            :host([size="_2x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .content,
            :host([immersive-card]) .content {
                background: transparent;
            }
            ::slotted([slot="hide-story"]) {
                color: ${y.A.ButtonText};
                fill: currentcolor;
            }
        `));var _=i(96950),$=i(82774),w=i(416),z=i(10108),k=i(69259),C=i(1413);const T=_.qy`
    <slot name="media" ${(0,$.e)("mediaSlot")}></slot>
`,I=(D={mediaTemplate:T},_.qy`
        <template
            role="article"
            ${(0,w.Y)({property:"childElements",filter:(0,z.Y)()})}
        >
            <div class="content${t=>t.mediaType?"":" no-image"}" part="content">
                ${D.mediaTemplate}
                ${(0,k.z)(t=>t&&(0,C.P)("media-info",t.childElements)&&!(t.immersiveCard||"_2x_2y"===t.size),(0,C.y)({slotName:"media-info"}))}
                <div class="gradient" part="gradient"></div>
                ${(0,C.y)({slotName:"media-overlay",slottedDefault:D.mediaOverlay})}
                <div class="text" part="text">
                    ${(0,k.z)(t=>t&&(0,C.P)("media-info",t.childElements)&&(t.immersiveCard||"_2x_2y"===t.size),(0,C.y)({slotName:"media-info"}))}
                    <slot name="attribution"></slot>
                    <a
                        id="heading"
                        class="heading"
                        part="heading"
                        href="${t=>t.href?t.href:void 0}"
                        target="${t=>t.target?t.target:void 0}"
                        @click=${(t,e)=>t.handleContentCardLinkClick(e.event)}
                        data-t="${t=>t.anchorTelemetryTag}"
                    >
                        <span role="heading" aria-level="${t=>t.headingLevel}">
                            <slot></slot>
                        </span>
                    </a>
                    ${(0,C.y)({slotName:"abstract"})}
                </div>
                <div
                    class="action-tray ${t=>t.loaded?"":"preload"}"
                    part="action-tray"
                >
                    ${(0,C.y)({slotName:"footer-start",slottedDefault:D.footerStart})}
                    ${(0,C.y)({slotName:"footer-end",slottedDefault:D.footerEnd})}
                </div>
                <div class="hide-story-wrapper" part="hide-story-wrapper">
                    ${(0,C.y)({slotName:"hide-story",slottedDefault:D.hideStory})}
                </div>
            </div>
        </template>
    `);var D;const S=a.W.compose({name:`${o.G.prefix}-content-card`,styles:f,template:I})},84056(t,e,i){i.d(e,{J(){return s}});var o=i(59836),a=i(73893),n=i(80090),r=i(65614);function s(){o.m.define(r.G.registry),a.m.define(r.G.registry),n.m.define(r.G.registry)}}}]);