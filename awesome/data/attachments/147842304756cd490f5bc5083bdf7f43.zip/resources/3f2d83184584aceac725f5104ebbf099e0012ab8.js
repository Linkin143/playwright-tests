// © Microsoft Corporation. All rights reserved.
import { CardDefinition, FluentDesignSystem, definition, CSDesignSystem } from "@cs-core/design-system";
import { MSFTDesignSystem, msftArticle, msftArticleCard, msftAttribution, msftContentCard, msftContentIndicator } from "@msnews/fast-msft-web-components";
import { registerCsCarousel, registerCsStripe, registerCsArticleCard, registerCsArticleCardCarousel, registerCsArticleCardCarouselNoHover } from "@msnews/super-cards";
import { AttributionDefinition } from "@cs-core/attribution";
import { ContentCardDefinition } from "@cs-core/content-card";
export function defineElements() {
    definition.define(FluentDesignSystem.registry);
    AttributionDefinition.define(CSDesignSystem.registry);
    CardDefinition.define(FluentDesignSystem.registry);
    ContentCardDefinition.define(CSDesignSystem.registry);
    msftArticleCard.define(MSFTDesignSystem.registry);
    msftArticle.define(MSFTDesignSystem.registry);
    msftAttribution.define(MSFTDesignSystem.registry);
    msftContentCard.define(MSFTDesignSystem.registry);
    msftContentIndicator.define(MSFTDesignSystem.registry);
    registerCsCarousel();
    registerCsStripe();
    registerCsArticleCard();
    registerCsArticleCardCarousel();
    registerCsArticleCardCarouselNoHover();
}
//# sourceMappingURL=define-elements.js.map