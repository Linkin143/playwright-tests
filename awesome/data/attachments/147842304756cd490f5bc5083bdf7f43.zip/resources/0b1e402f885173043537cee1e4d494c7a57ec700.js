"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["grid-view-feed"],{1540(t,e,o){o.d(e,{rX(){return w}});var i=o(94407),a=o(96950),n=o(82774);const r=a.qy`<span class="icon-container" part="icon-container" aria-hidden="true"><slot name="icon"></slot></span><span class="label-container" part="label-container"><span class="label" part="label"><slot ${(0,n.e)({property:"defaultItems",filter(t){var e;return t instanceof HTMLElement&&null!==t.offsetParent||t instanceof Text&&!(null===(e=t.textContent)||void 0===e||!e.trim().length)}})}></slot></span></span>`;var s=o(7896),l=o(61138),d=o(86856),c=o(57416),p=o(64187),u=o(22131),h=o(74849),g=o(12640),v=o(50882);const f=h.A` :host::after{transform:translateX(-100%) translateX(20px)}:host([animate]) .label{transform:translateX(-100%)}`,m=h.A` :host::after{transform:translateX(100%) translateX(-20px)}:host([animate]) .label{transform:translateX(100%)}`,$=h.A` :host{color:#000}:host::after{background:rgba(255,255,255,0.46)}`,x=h.A` :host{color:#fff}:host::after{background:rgba(0,0,0,0.54)}`,b=h.A`
        ${(0,p.V)("inline-flex")} :host{align-items:center;box-sizing:border-box;contain:content;overflow:hidden}.label-container{overflow:hidden}:host,:host::after{${""} border-radius:4px}:host::after{content:"";height:100%;position:absolute;width:100%;z-index:-1}.icon-container,.label{min-height:20px;min-width:20px;display:flex;align-items:center;justify-content:center;fill:currentcolor}:host([animate])::after,.label{transition:transform 250ms cubic-bezier(0.17,0.17,0,1)}.label{font-family:${s.O};
            font-size: ${l.k};
            font-weight: 600;
            line-height: ${l.F};text-overflow:ellipsis;padding:0 4px}:host([expanded][animate])::after,:host([expanded][animate]) .label{transform:translateX(0%)}.label{transform:translateX(-100%)}::slotted([slot="icon"]){display:block;fill:currentcolor}`.withBehaviors(new d.t(f,m),new g.N($,x),(0,u.mr)(h.A` :host{forced-color-adjust:auto}::slotted([slot="icon"]){color:${v.A.ButtonText};fill:currentcolor}.icon-container,:host([expanded][animate]) .label,:host::after{background:${v.A.ButtonFace};
                    color: ${v.A.ButtonText};
                    fill: currentcolor;
                    border-radius: calc(${c.Pb} * 10px)}.label{background:transparent}`));var y=o(99900);const w=i.L.compose({name:`${y.i.prefix}-content-indicator`,template:r,styles:b})},9587(t,e,o){o.d(e,{m(){return d}});var i=o(37180),a=o(58976),n=o(97482),r=o(99015),s=o(96950);const l=(0,r.Y)({nextFlipper:s.qy`
            <fluent-flipper
                @click="${t=>t.scrollToNext()}"
                aria-hidden="${t=>t.flippersHiddenFromAT}"
            ></fluent-flipper>
        `,previousFlipper:s.qy`
            <fluent-flipper
                @click="${t=>t.scrollToPrevious()}"
                direction="previous"
                aria-hidden="${t=>t.flippersHiddenFromAT}"
            ></fluent-flipper>
        `}),d=a.C.compose({name:`${i.c.prefix}-horizontal-scroll`,template:l,styles:n.R})},10168(t,e,o){o.d(e,{G(){return a}});var i=o(19657);class a{}a.updateLayout=new i.P("updateLayout"),a.initialize=new i.P("initialize")},12717(t,e,o){o.d(e,{m(){return k}});var i=o(84506),a=o(37180),n=o(74849),r=o(64187),s=o(60993),l=o(73477),d=o(22131),c=o(50882),p=o(48196),u=o(48751),h=o(45476),g=o(26920),v=o(36452),f=o(79288),m=o(14996);const $=n.A`
    ${(0,r.V)("inline-flex")} :host {
        width: calc(${p.D} * 1px);
        height: calc(${p.D} * 1px);
        justify-content: center;
        align-items: center;
        margin: 0;
        position: relative;
        fill: currentcolor;
        color: ${u.l};
        background: transparent;
        border: none;
        outline: none;
        padding: 0;
    }

    :host::before {
        content: "";
        opacity: 0.8;
        background: ${h.Wl};
        border: calc(${g.XA} * 1px) solid ${v.I2};
        border-radius: 50%;
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        transition: all 0.1s ease-in-out;
    }

    .next,
    .previous {
        position: relative;
        ${""} width: 16px;
        height: 16px;
    }

    :host([disabled]) {
        opacity: ${f.q};
        cursor: ${s.Z};
    }

    :host(:hover) {
        cursor: pointer;
    }

    :host(:hover)::before {
        background: ${h.oO};
        border-color: ${v.mb};
    }

    :host(:${l.N}) {
        outline: none;
    }

    :host(:${l.N})::before {
        box-shadow: 0 0 0 1px ${m.WN} inset;
        border-color: ${m.WN};
    }

    :host(:active)::before {
        background: ${h.wO};
        border-color: ${v.MY};
    }

    :host::-moz-focus-inner {
        border: 0;
    }
`.withBehaviors((0,d.mr)(n.A`
            :host {
                background: ${c.A.Canvas};
            }
            :host .next,
            :host .previous {
                color: ${c.A.ButtonText};
                fill: currentcolor;
            }
            :host::before {
                background: ${c.A.Canvas};
                border-color: ${c.A.ButtonText};
            }
            :host(:hover)::before {
                forced-color-adjust: none;
                background: ${c.A.Highlight};
                border-color: ${c.A.ButtonText};
                opacity: 1;
            }
            :host(:hover) .next,
            :host(:hover) .previous {
                forced-color-adjust: none;
                color: ${c.A.HighlightText};
                fill: currentcolor;
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled])::before,
            :host([disabled]:hover)::before,
            :host([disabled]) .next,
            :host([disabled]) .previous,
            :host([disabled]:hover) .next,
            :host([disabled]:hover) .previous {
                forced-color-adjust: none;
                background: ${c.A.Canvas};
                border-color: ${c.A.GrayText};
                color: ${c.A.GrayText};
                fill: ${c.A.GrayText};
            }
            :host(:${l.N})::before {
                forced-color-adjust: none;
                border-color: ${c.A.Highlight};
                box-shadow: 0 0 0 2px ${c.A.Field},
                    0 0 0 4px ${c.A.FieldText};
            }
        `));var x=o(60143),b=o(96950);const y=(0,x.B)({next:b.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z"
            />
        </svg>
    `,previous:b.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z"
            />
        </svg>
    `});class w extends i.d{}const k=w.compose({name:`${a.c.prefix}-flipper`,template:y,styles:$})},16038(t,e,o){o.d(e,{m(){return h}});var i=o(65614),a=o(13312),n=o(55153),r=o(7896),s=o(74849),l=o(64187);const d=s.A`
    ${(0,l.V)("grid")}

    :host {
        font-family: ${r.O};
        width: auto;
        grid-auto-columns: calc(${n.QG} * 1px);
        grid-auto-row: calc(${n.l8} * 1px);
        grid-gap: calc(${n.Sn} * 1px);
    }
`;var c=o(39957),p=o(96950);const u=p.qy`
    <template @keydown="${(t,e)=>t.handleKeyDown(e.event)}">
        ${(0,c.ux)(t=>t.childrenLayout,p.qy`
                ${(t,e)=>e.parent.selectTemplate(t)}
            `)}
    </template>
`,h=a.tA.compose({name:`${i.G.prefix}-feed-layout`,styles:d,template:u})},25717(t,e,o){o.d(e,{T(){return a}});var i=o(96950);function a(){return i.qy`
        <slot></slot>
    `}},29995(t,e,o){o.d(e,{M(){return s}});var i=o(96950),a=o(60402),n=o(82774),r=o(35106);function s(t={}){return i.qy`
        <a
            class="control"
            part="control"
            download="${t=>t.download}"
            href="${t=>t.href}"
            hreflang="${t=>t.hreflang}"
            ping="${t=>t.ping}"
            referrerpolicy="${t=>t.referrerpolicy}"
            rel="${t=>t.rel}"
            target="${t=>t.target}"
            type="${t=>t.type}"
            aria-atomic="${t=>t.ariaAtomic}"
            aria-busy="${t=>t.ariaBusy}"
            aria-controls="${t=>t.ariaControls}"
            aria-current="${t=>t.ariaCurrent}"
            aria-describedby="${t=>t.ariaDescribedby}"
            aria-details="${t=>t.ariaDetails}"
            aria-disabled="${t=>t.ariaDisabled}"
            aria-errormessage="${t=>t.ariaErrormessage}"
            aria-expanded="${t=>t.ariaExpanded}"
            aria-flowto="${t=>t.ariaFlowto}"
            aria-haspopup="${t=>t.ariaHaspopup}"
            aria-hidden="${t=>t.ariaHidden}"
            aria-invalid="${t=>t.ariaInvalid}"
            aria-keyshortcuts="${t=>t.ariaKeyshortcuts}"
            aria-label="${t=>t.ariaLabel}"
            aria-labelledby="${t=>t.ariaLabelledby}"
            aria-live="${t=>t.ariaLive}"
            aria-owns="${t=>t.ariaOwns}"
            aria-relevant="${t=>t.ariaRelevant}"
            aria-roledescription="${t=>t.ariaRoledescription}"
            ${(0,a.K)("control")}
        >
            ${(0,r.LT)(t)}
            <span class="content" part="content">
                <slot ${(0,n.e)("defaultSlottedContent")}></slot>
            </span>
            ${(0,r.aO)(t)}
        </a>
    `}},30273(t,e,o){o.d(e,{$(){return i}});const i=function(t){let e=!(arguments.length>1&&void 0!==arguments[1])||arguments[1],o=arguments.length>2&&void 0!==arguments[2]&&arguments[2];if(document.head.querySelector(`[href="${t}"]`))return;const i=document.createElement("link");i.rel="preconnect",i.href=t,e&&i.setAttribute("crossorigin",o?"use-credentials":""),document.head.appendChild(i)}},30581(t,e,o){o.d(e,{yr(){return L}});var i=o(87993),a=o(96950),n=o(60402),r=o(69259),s=o(416),l=o(10108),d=o(82774),c=o(58792);const p=(0,o(75307).Eo)("MicrosoftLogoWithText","4806176","icons-wc/icons/shopping"),u=a.qy`<div class="footer ${t=>t.hasAbstract?"has-abstract-footer":""}" part="footer"><span part="start-actions" ${(0,n.K)("startActionsContainer")}><slot name="start-actions" ${(0,n.K)("startActions")} @slotchange=${t=>t.handleStartActionsContentChange()}></slot></span><span part="end-actions" ${(0,n.K)("endActionsContainer")}><slot name="end-actions" ${(0,n.K)("endActions")} @slotchange=${t=>t.handleEndActionsContentChange()}></slot></span></div>`,h=a.qy`<div style=" background: linear-gradient(265deg, rgb(18, 113, 3) 0%, rgb(69, 153, 3) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><img class="delivery-icon" loading="lazy" src="${(0,c.rA)().StaticsUrl}pr-3980746/shopping/deliveryTruckIcon.svg"><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">Free shipping</span></div>`,g=/\d+% cash ?back/i,v=a.qy`<div style=" background: linear-gradient(270deg, rgb(21, 61, 219) 0%, rgb(0, 113, 246) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">${t=>{var e;return(t.title&&(null===(e=t.title.match(g))||void 0===e?void 0:e[0]))??"Earn cash back"}}</span></div>`,f=(t,e)=>a.qy`<div style=" background: #424242; display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding: 0px 2px; padding-top: 0px; align-items:center; "><img src="${e}" aria-hidden="true" onerror="this.style.display='none'"/><span style=" ${t.includes("Holiday Deals")?"font-weight: 600;":"text-transform: uppercase; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size));"} color: white; padding:2px; align-items: center; ">${t}</span></div>`,m=a.qy`<div style="display: flex;">${t=>t.id.includes("__")?a.qy` ${(0,r.z)(t=>t.id.includes("_Christmas"),f("Holiday Deals","https://www.bing.com/th?id=OSS.BT4443E8F9A2BBD34313F790F7FC3FD09DD960AF1BCACA6A40544E8EBF98066A80"))} ${(0,r.z)(t=>t.id.includes("_BlackFriday"),f("Black Friday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))} ${(0,r.z)(t=>t.id.includes("_CyberMonday"),f("Cyber Monday Offer",(0,c.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))}`:a.qy` ${(0,r.z)(t=>t&&!t.id.includes("_NoCashback"),v)} ${(0,r.z)(t=>t,h)} `}</div>`,$=a.qy`<div style="background: no-repeat center url('${t=>t.querySelector("img").src}');background-size: cover;filter: blur(40px); height: 100%; width:100%;position: absolute;"></div>`,x=a.qy`<div class="logo-container"><img src=${p} alt="Microsoft Logo" aria-hidden="true" /></div>`,b=a.qy`<template ${(0,s.Y)({property:"mediaNodes",filter:(0,l.Y)("[slot='media'], [slot='icon']")})}><span part="background-image" class='${t=>t.id.includes("contentcard_InfoBuyDirectCard")?"bd-background-image":"background-image"}'>${(0,r.z)(t=>t.id.includes("contentcard_tripleCashback"),x)} ${(0,r.z)(t=>t.id.includes("contentcard_edgeReclaim"),x)} ${(0,r.z)(t=>t.id.includes("contentcard_InfoBuyDirectCard"),$)}<slot name="background-image" ${(0,n.K)("backgroundImage")}></slot></span>${(0,r.z)(t=>t.id.includes("BuyDirectCard"),m)}<div class="mask" part="mask"></div><div class="body ${t=>t.hasAbstract?"has-abstract":""} ${t=>t.isGrid?"grid":""}" part="body">${(0,r.z)(t=>{var e;return(null==t||null===(e=t.mediaNodes)||void 0===e?void 0:e.length)>0},a.qy`<div class="media-wrapper" part="media-wrapper"><div part="media" ${(0,n.K)("mediaContainer")}><slot name="media" ${(0,n.K)("media")} @slotchange=${t=>t.handleMediaContentChange()}></slot><slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot><span part="icon" ${(0,n.K)("iconContainer")} class="${t=>t.iconSlottedNodes&&t.iconSlottedNodes.length?"icon":"icon__hidden"}"><slot name="icon" ${(0,n.K)("icon")} ${(0,d.e)("iconSlottedNodes")}></slot></span></div></div>`)}<div class="heading-container" part="heading-container">${(0,r.z)(t=>{var e;return 0===(null==t||null===(e=t.mediaNodes)||void 0===e?void 0:e.length)},a.qy`<slot name="content-indicator" ${(0,d.e)("contentIndicatorNodes")}></slot>`)}<slot name="attribution"></slot><span class="heading-wrapper" part="heading-wrapper" role="heading" aria-level=${t=>t.headinglevel} name="heading"><a class="heading" part="heading" href=${t=>t.href?t.href:void 0} target=${t=>t.target?t.target:void 0} @click=${(t,e)=>t.handleContentCardLinkClick(e.event)} data-t="${t=>t.anchorTelemetryTag}"><slot></slot></a></span></div><div class="abstract" part="abstract"><slot name="abstract" ${(0,d.e)("abstract")}></slot></div>${(0,r.z)(t=>t.layout!==i.S.default,u)}</div>${(0,r.z)(t=>t.layout===i.S.default,u)}<span part="hover-actions" class="${t=>t.hoverActionsSlottedNodes&&t.hoverActionsSlottedNodes.length?"hover-actions":"hover-actions__hidden"}"><slot name="hover-actions" ${(0,d.e)("hoverActionsSlottedNodes")}></slot></span><slot name="call-to-action"></slot></template>`;var y=o(64187),w=o(73477),k=o(22131),C=o(74849),z=o(50882),F=o(7896),M=o(61138),S=o(64003),T=o(41123),P=o(48751),q=o(89580),D=o(95239),B=o(86856);const A=C.A` :host([layout="default"]) .media-wrapper{float:right}`,V=C.A` :host([layout="default"]) .media-wrapper{float:left}`,H=C.A`
    ${(0,y.V)("flex")} :host{--icon-size:24px;position:relative;width:auto;box-sizing:border-box;font-family:${F.O};flex-direction:column;outline:none;height:100%;overflow:hidden}:host(:hover) .hover-actions{opacity:1;transition:opacity 0.2s ease-in-out}.body{display:grid;justify-content:center;row-gap:8px;column-gap:10px;grid-template-columns:1fr auto;grid-template-rows:auto}:host([layout="default"]) .body .abstract{display:none}:host([layout="default"]) .body{display:block}:host([layout="default"]) .body.grid{display:grid}:host([layout="default"]) .body.grid .media-wrapper{float:none}:host([layout="default"]) .has-abstract .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([layout="default"]) .has-abstract .media-wrapper{margin-inline-start:16px}:host([image-priority]) .has-abstract .media-wrapper{margin-inline-start:0}.footer{padding-inline-start:var(--footer-start-padding,16px);padding-inline-end:var(--footer-start-padding,16px);padding-top:var(--footer-padding-top,0);padding-bottom:var(--footer-padding-bottom,4px);margin-top:auto;font-size:var(--footer-font-size,${M.k});
        line-height: var(--footer-line-height, ${M.F})}.logo-container{display:flex;align-items:center;position:fixed;bottom:16px;z-index:1000;left:17px}.footer,.start-actions,.end-actions{display:flex;flex-direction:row;align-items:center;justify-content:space-between;color:${S.c};
        fill: ${S.c}}.footer__hidden{display:none}.hover-actions{display:flex;flex-direction:column;position:absolute;top:8px;z-index:2;opacity:0}.hover-actions__hidden{display:none}.hover-actions:focus-within{opacity:1}.heading-container{grid-row:1;display:flex;flex-direction:column;padding-inline-start:var(--heading-start-padding,16px);padding-inline-end:var(--heading-end-padding,16px);padding-bottom:0;padding-top:16px}.heading-wrapper a:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;top:0;width:100%;z-index:1}:host([layout="condensed"]) .body{gap:0}:host([layout="condensed"]) .footer{grid-row:2;grid-column-start:1;grid-column-end:var(--footer-grid-column-end,auto);padding-inline-start:16px}:host([layout="condensed"]) .media-wrapper{position:relative;grid-row:1 / span 2;margin-top:5px}:host([layout="condensed"]) .heading-container{padding-top:0px;--heading-end-padding:12px}:host([layout="condensed"]) ::slotted([slot="attribution"]){margin-bottom:0px}.icon{position:absolute;display:inline-flex;top:auto;bottom:0;justify-content:center;align-items:center;margin:0 0 4px 0;margin-inline-start:4px}.hover-actions{inset-inline-end:8px}.icon{inset-inline-start:0}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){inset-inline-start:8px}.icon__hidden{display:none}::slotted([slot="icon"]){width:var(--icon-size);height:var(--icon-size);fill:#FFF}::slotted([slot="attribution"]){margin-bottom:6px}::slotted([slot="abstract"]){margin:2px 0}.media-wrapper{grid-row:1;grid-column:2;margin-inline-end:var(--media-inline-padding,16px);margin-top:16px}.media{display:flex;position:relative}:host([image-priority]) .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([image-priority]) .body{grid-template-columns:1}:host([image-priority]) .media-wrapper{grid-row:1;grid-column:span 2;margin:0}:host([image-priority]) .heading-container{grid-row:2;grid-column:span 2;padding-top:10px;padding-inline-start:var(--heading-start-padding,16px)}:host([image-priority]) ::slotted([slot="media"]),:host([layout="infoPaneSplitHorizontal"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPane"]) .media-wrapper,:host([layout="infoPane1x3y"]) .media-wrapper{grid-row:1;grid-column:1;margin-top:0;width:fit-content;height:fit-content}:host([layout="infoPane"]) .icon,:host([layout="infoPaneSplitVertical"]) .icon,:host([layout="infoPane1x3y"]) .icon{display:inline;left:0;top:0;margin:4px 0 0;margin-inline-start:4px}:host([layout="infoPaneSplitVertical"]) .icon{display:block}:host([layout="infoPaneSplitHorizontal"]) .icon{bottom:0px}:host([layout="infoPaneSplitHorizontal"]) .heading-container,:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{align-self:end}:host([layout="infoPaneSplitHorizontal"]) .body,:host([layout="infoPane"]) .body,:host([layout="infoPane1x3y"]) .body{height:100%;grid-template-rows:1fr auto}::slotted([slot="call-to-action"]){width:calc(100% - 32px);grid-row:3;z-index:1;grid-column:1 / span 2;margin:0 16px}::slotted([slot="media"]){border-radius:calc(var(--content-card-corner-radius,2) * 2px)}:host([layout="default"]) .grid .heading-container{grid-area:initial !important}:host([layout="default"]) .has-abstract .abstract{display:block;padding:0 16px 16px 16px}.abstract{position:relative;margin:0;font-size:var(--abstract-font-size,${T.K});
        line-height: var(--abstract-line-height, ${T.Z});
        font-weight: 400;
        grid-column: span 2;
        box-sizing: content-box;
        color: ${S.c};padding:0 16px}::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){z-index:2;display:grid;gap:5px;align-items:center;grid-auto-flow:column}::slotted([slot="call-to-action"]){z-index:2}::slotted(fluent-button[slot="start-actions"]),::slotted(fluent-button[slot="end-actions"]){color:${S.c};
        fill: ${S.c}}::slotted(fluent-button[appearance="stealth"]:not(:hover)),:slotted([slot="hover-actions"]:not(:hover)){background:transparent}.heading{text-decoration:none;outline:none;color:${P.l};
        font-size: var(--heading-font-size, ${q.Y});
        line-height: var(--heading-line-height, ${q.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,3);white-space:initial}.mask{display:none}.heading:hover,.heading:${w.N}{text-decoration:underline}.heading::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}:host([layout="infoPane"]),:host([layout="infoPane1x3y"]){justify-content:flex-end;border:none}:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{position:absolute;bottom:0;right:0;left:0;background:${D.p};
        box-shadow: 0px -25px 15px ${D.p}}:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{grid-column:1 / 3;z-index:1}:host([layout="infoPane"]) .has-abstract .heading-container,:host([layout="infoPane1x3y"]) .has-abstract .heading-container{grid-area:2/ 1 / span 2 / auto;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:8px;align-self:flex-start}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{grid-row:2;grid-column:2;color:${P.l};padding:8px 16px 0 16px;align-self:end;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:4}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract{display:none}:host([layout="infoPane"]) .has-abstract,:host([layout="infoPane1x3y"]) .has-abstract{grid-template-columns:1fr 1fr;gap:0 10px}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer{min-height:calc(40px - 4px)}:host([layout="infoPane"]) .has-abstract .abstract,:host([layout="infoPane1x3y"]) .has-abstract .abstract{display:-webkit-box;align-self:flex-end}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{display:flex;position:absolute;top:0;left:0;right:0;bottom:0;background-image:var(--mask-gradient,linear-gradient(to top,rgba(0,0,0,1),rgba(0,0,0,0) 176px))}:host([layout="infoPane1x3y"]) .mask{background-image:var(--mask-gradient,linear-gradient(rgba(0,0,0,0),rgba(0,0,0,1) 69px,rgba(0,0,0,1)));top:257px}:host([layout="infoPane"]) .has-abstract .has-abstract-footer,:host([layout="infoPane1x3y"]) .has-abstract .has-abstract-footer{grid-row:3;grid-column:2;position:inherit;align-self:flex-end;max-height:40px}:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer{margin-top:unset;grid-row:2;grid-column:1 / span 2;padding-inline-start:16px;padding-inline-end:16px}:host([layout="infoPane"]) ::slotted(msft-attribution[slot="attribution"]),:host([layout="infoPane1x3y"]) ::slotted(msft-attribution[slot="attribution"]){color:${P.l};text-shadow:0px 0.4px 0.9px rgba(0,0,0,0.13),0px 0px 2.22px rgba(0,0,0,0.11)}:host([layout="infoPaneSplitVertical"]){grid-template-columns:304px 1fr;grid-template-rows:auto;background:${D.p}}:host([layout="infoPaneSplitVertical"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPaneSplitVertical"]) .media-wrapper{grid-row:1 / span 2;grid-column:1;margin:0}:host([layout="infoPaneSplitVertical"]) .heading-container{grid-row:1;grid-column:2;--heading-start-padding:4px;--heading-end-padding:16px;padding-bottom:0;padding-top:16px}:host([layout="infoPaneSplitVertical"]) .footer{grid-row:2;grid-column:2;padding-inline-start:0;padding-inline-end:16px;padding-top:0}:host([layout="infoPaneSplitHorizontal"]) .body{grid-template-columns:1fr 1fr;grid-template-rows:326px auto auto;row-gap:4px;background:${D.p}}:host([layout="infoPaneSplitHorizontal"]) .media-wrapper{grid-column:1 / span 2;margin:0}:host([layout="infoPaneSplitHorizontal"]) .heading-container{grid-column:1;grid-row:2 / span 2;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:12px}:host([layout="infoPaneSplitHorizontal"]) .footer{grid-column:2;grid-row:3;box-shadow:none}:host([layout="infoPaneSplitHorizontal"]) .abstract{color:inherit;align-self:inherit;padding:12px 16px 0 16px}.background-image{position:absolute;top:0;left:0;right:0;bottom:0}:host([layout="infoPane1x3y"]) .background-image{position:absolute;top:0;left:0;right:0;bottom:136px}.background-image ::slotted(img){width:100%;height:100%;object-fit:cover}.bd-background-image ::slotted(img){width:100%;height:100%;object-fit:contain;position:absolute;top:0px}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){position:absolute;top:8px;z-index:1}::slotted([slot="content-indicator"]){margin-bottom:26px;align-self:flex-start}`.withBehaviors(new B.t(A,V),(0,k.mr)(C.A` .heading{color:${z.A.LinkText};
                    background: ${z.A.ButtonFace}}.abstract{color:${z.A.ButtonText}}.icon{background-color:#000;height:fit-content}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{color:${z.A.ButtonText};
                    background: ${z.A.ButtonFace}}.footer,.start-actions,.end-actions,::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){background:${z.A.ButtonFace};
                    color: ${z.A.ButtonText};fill:currentcolor}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{background-image:none}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer,:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer,:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{background:${z.A.ButtonFace};box-shadow:none}::slotted(fluent-button[appearance="stealth"]:not(:hover)){background:${z.A.ButtonFace};
                }
            `));var _=o(99900);const L=i.m.compose({name:`${_.i.prefix}-content-card`,template:b,styles:H,shadowOptions:{delegatesFocus:!0}})},33801(t,e,o){o.r(e),o.d(e,{GridViewFeed(){return ne},GridViewFeedStyles(){return se},GridViewFeedTemplate(){return Oe},ToolingInfo(){return Ze}});var i=o(2958),a=o(37180),n=o(75003),r=o(4731),s=o(88817),l=o(45899),d=o(12717),c=o(99564),p=o(9587),u=o(65614),h=o(71608),g=o(99900),v=o(30581),f=o(1540),m=o(56911),$=o(92011),x=o(38493),b=o(60815),y=o(96950),w=o(69259);const k=y.qy`<svg width="12" height="20" viewBox="0 -1 16 16" xmlns="http://www.w3.org/2000/svg"><path d="M2 7C2.14063 7 2.27083 7.02607 2.39063 7.07813C2.51041 7.1302 2.61459 7.20313 2.70313 7.29687C2.79687 7.3854 2.86979 7.4896 2.92187 7.6094C2.97396 7.7292 3 7.8594 3 8C3 8.1406 2.97396 8.2708 2.92187 8.3906C2.86979 8.5104 2.79687 8.6172 2.70313 8.71093C2.61459 8.79947 2.51041 8.8698 2.39063 8.92187C2.27083 8.97393 2.14063 9 2 9C1.85937 9 1.72917 8.97393 1.60937 8.92187C1.48959 8.8698 1.38281 8.79947 1.28906 8.71093C1.20052 8.6172 1.13021 8.5104 1.07813 8.3906C1.02604 8.2708 1 8.1406 1 8C1 7.8594 1.02604 7.7292 1.07813 7.6094C1.13021 7.4896 1.20052 7.3854 1.28906 7.29687C1.38281 7.20313 1.48959 7.1302 1.60937 7.07813C1.72917 7.02607 1.85937 7 2 7ZM8 7C8.1406 7 8.2708 7.02607 8.3906 7.07813C8.5104 7.1302 8.6146 7.20313 8.70313 7.29687C8.79687 7.3854 8.8698 7.4896 8.92187 7.6094C8.97393 7.7292 9 7.8594 9 8C9 8.1406 8.97393 8.2708 8.92187 8.3906C8.8698 8.5104 8.79687 8.6172 8.70313 8.71093C8.6146 8.79947 8.5104 8.8698 8.3906 8.92187C8.2708 8.97393 8.1406 9 8 9C7.8594 9 7.7292 8.97393 7.6094 8.92187C7.4896 8.8698 7.3828 8.79947 7.28907 8.71093C7.20053 8.6172 7.1302 8.5104 7.07813 8.3906C7.02607 8.2708 7 8.1406 7 8C7 7.8594 7.02607 7.7292 7.07813 7.6094C7.1302 7.4896 7.20053 7.3854 7.28907 7.29687C7.3828 7.20313 7.4896 7.1302 7.6094 7.07813C7.7292 7.02607 7.8594 7 8 7ZM14 7C14.1406 7 14.2708 7.02607 14.3906 7.07813C14.5104 7.1302 14.6146 7.20313 14.7031 7.29687C14.7969 7.3854 14.8698 7.4896 14.9219 7.6094C14.9739 7.7292 15 7.8594 15 8C15 8.1406 14.9739 8.2708 14.9219 8.3906C14.8698 8.5104 14.7969 8.6172 14.7031 8.71093C14.6146 8.79947 14.5104 8.8698 14.3906 8.92187C14.2708 8.97393 14.1406 9 14 9C13.8594 9 13.7292 8.97393 13.6094 8.92187C13.4896 8.8698 13.3828 8.79947 13.2891 8.71093C13.2005 8.6172 13.1302 8.5104 13.0781 8.3906C13.0261 8.2708 13 8.1406 13 8C13 7.8594 13.0261 7.7292 13.0781 7.6094C13.1302 7.4896 13.2005 7.3854 13.2891 7.29687C13.3828 7.20313 13.4896 7.1302 13.6094 7.07813C13.7292 7.02607 13.8594 7 14 7Z" /></svg>`;var C=y.qy`<msft-content-card href="${t=>t.href}" target="${(t,e)=>e.parent.target}" title="${t=>t.title}" data-t="${t=>t.telemetry_context&&t.telemetry_context.card}" :anchorTelemetryTag=${t=>t.telemetry_context&&t.telemetry_context.url}>${t=>t.title}<img slot="media" src="${t=>t.media_src}" alt="${t=>t.media_alt}" />${(0,w.z)(t=>t.content_indicator_icon,y.qy`<msft-content-indicator slot="content-indicator">${t=>t.content_indicator_icon}</msft-content-indicator>`)} ${(0,w.z)(t=>t.attribution_src||t.attribution_title,y.qy`<msft-attribution slot="attribution">${(0,w.z)(t=>t.attribution_src,y.qy`<img slot="image" src="${t=>t.attribution_src}" alt="${t=>t.attribution_alt}" />`)}<span class="attribution-container"><span class="attribution-title">${t=>t.attribution_title}</span>${(0,w.z)(t=>t.attribution_publishedDate,y.qy`<span class="attribution-separator">&middot;</span><span class="attribution-date">${t=>t.attribution_publishedDate}</span>`)}</span></msft-attribution>`)} ${(0,w.z)(t=>t.more_actions,y.qy` ${(0,w.z)(t=>t.comment_count,y.qy`<div slot="start-actions" class="like-button"><svg width="14" height="13" viewBox="0 0 14 13" xmlns="http://www.w3.org/2000/svg"><path d="M0 2.5C0 1.11929 1.11929 0 2.5 0H11.5C12.8807 0 14 1.11929 14 2.5V7.5C14 8.88071 12.8807 10 11.5 10H7.68787L4.62533 12.6797C3.99168 13.2342 3 12.7842 3 11.9422V10H2.5C1.11929 10 0 8.88071 0 7.5V2.5ZM2.5 1C1.67157 1 1 1.67157 1 2.5V7.5C1 8.32843 1.67157 9 2.5 9H4V11.8981L7.31213 9H11.5C12.3284 9 13 8.32843 13 7.5V2.5C13 1.67157 12.3284 1 11.5 1H2.5Z" /></svg><span>${t=>t.comment_count}</span></div>`)}<fluent-button appearance="stealth" class="actions-button" slot="end-actions" @click=${(t,e)=>e.parent.actionTriggered(t)} @keypress=${(t,e)=>e.parent.actionTriggered(t)} data-t="${t=>t.telemetry_context&&t.telemetry_context.button}">${k}</fluent-button>`)}</msft-content-card>`;const z='\n    <path d="M2 7a.942.942 0 0 1 .703.297A.941.941 0 0 1 3 8c0 .14-.026.27-.078.39a1.03 1.03 0 0 1-.531.532A.97.97 0 0 1 2 9a.97.97 0 0 1-.39-.078 1.103 1.103 0 0 1-.32-.211 1.103 1.103 0 0 1-.212-.32A.969.969 0 0 1 1 8a.969.969 0 0 1 .29-.703A.97.97 0 0 1 2 7Zm6 0a.941.941 0 0 1 .703.297A.941.941 0 0 1 9 8a.97.97 0 0 1-.078.39 1.03 1.03 0 0 1-.531.532A.97.97 0 0 1 8 9a.97.97 0 0 1-.39-.078 1.103 1.103 0 0 1-.32-.211 1.103 1.103 0 0 1-.212-.32A.97.97 0 0 1 7 8a.97.97 0 0 1 .29-.703A.97.97 0 0 1 8 7Zm6 0a.94.94 0 0 1 .703.297A.941.941 0 0 1 15 8a.97.97 0 0 1-.297.71A.97.97 0 0 1 14 9a.97.97 0 0 1-.39-.078 1.102 1.102 0 0 1-.32-.211 1.103 1.103 0 0 1-.212-.32A.97.97 0 0 1 13 8a.97.97 0 0 1 .29-.703A.97.97 0 0 1 14 7Z"/>\n',F=y.qy`<svg width="12" height="20" viewBox="0 -2 16 16" xmlns="http://www.w3.org/2000/svg">${z}</svg>`;var M=y.qy`<msft-content-card href="${t=>t.href}" layout="condensed" target="${(t,e)=>e.parent.target}" title="${t=>t.title}" data-t="${t=>t.telemetry_context&&t.telemetry_context.card}" :anchorTelemetryTag=${t=>t.telemetry_context&&t.telemetry_context.url}>${t=>t.title} ${(0,w.z)(t=>t.media_src,y.qy`<img slot="media" src="${t=>t.media_src}" alt="${t=>t.media_alt}" width="${t=>t.media_width}" height="${t=>t.media_height}" />`)} ${(0,w.z)(t=>t.content_indicator_icon,y.qy`<msft-content-indicator slot="content-indicator">${t=>t.content_indicator_icon}</msft-content-indicator>`)} ${(0,w.z)(t=>t.attribution_src||t.attribution_title,y.qy`<div slot="attribution" class="attribution-condensed-container"><msft-attribution>${(0,w.z)(t=>t.attribution_src,y.qy`<img slot="image" src="${t=>t.attribution_src}" alt="${t=>t.attribution_alt}" width="${t=>t.attribution_width}" height="${t=>t.attribution_height}" />`)}<span class="attribution-container"><span class="attribution-title">${t=>t.attribution_title}</span>${(0,w.z)(t=>t.attribution_publishedDate,y.qy`<span class="attribution-separator">&middot;</span><span class="attribution-date">${t=>t.attribution_publishedDate}</span>`)}</span></msft-attribution>${(0,w.z)(t=>t.more_actions,y.qy`<fluent-button class="actions-button" appearance="stealth" @click="${(t,e)=>e.parent.actionTriggered(t,e.event)}" @keypress="${(t,e)=>e.parent.actionTriggered(t,e.event)}" data-t="${t=>t.telemetry_context&&t.telemetry_context.button}">${F}</fluent-button>`)}</div>`)}</msft-content-card>`;const S=y.qy`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" version="1.1" width=36 height=36>
    <g id="🔍-System-Icons" stroke="none" stroke-width="1" fill="#FFFFFF" fill-rule="evenodd">
        <g id="ic_fluent_play_circle_24_regular" fill="#FFFFFF" fill-rule="nonzero">
            <path d="M12 2c5.523 0 10 4.477 10 10s-4.477 10-10 10S2 17.523 2 12 6.477 2 12 2Zm0 1.5a8.5 8.5 0 1 0 0 17 8.5 8.5 0 0 0 0-17ZM9.053 8.585a.5.5 0 0 1 .587-.256l.084.033 6.382 3.19a.5.5 0 0 1 .076.848l-.076.047-6.382 3.191a.5.5 0 0 1-.716-.357L9 15.19V8.809a.5.5 0 0 1 .053-.224Z" fill-rule="nonzero" fill="#FFF" id="🎨-Color"/>
        </g>
    </g>
</svg>
`,T=y.qy`
    <svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#a)"><path d="M16 8c.04-2.12-.82-4.18-2.36-5.64A7.598 7.598 0 0 0 8 0C5.86-.04 3.82.82 2.34 2.36A7.655 7.655 0 0 0 0 8c-.04 2.12.82 4.18 2.34 5.66A7.732 7.732 0 0 0 8 16c2.12.04 4.18-.82 5.64-2.34A7.642 7.642 0 0 0 16 8z" fill="url(#b)"/><path d="M6.04 5.04c-1.3 0-2.36 1.04-2.38 2.34v.02C3.66 8.7 4.7 9.76 6 9.78h.02c1.3 0 2.36-1.04 2.38-2.34v-.02c0-1.3-1.04-2.36-2.34-2.38h-.02z" fill="url(#c)"/><path d="M4.46 7.42c0 .88.7 1.58 1.58 1.58.42 0 .82-.16 1.12-.46.3-.3.48-.7.46-1.12 0-.88-.7-1.58-1.58-1.58a1.573 1.573 0 0 0-1.58 1.58z" fill="#fff"/><path d="M5.48 6.86a.71.71 0 0 0-.22.56c-.02.42.32.78.76.8h.04c.22 0 .42-.08.56-.22.16-.14.24-.36.22-.56 0-.2-.08-.4-.22-.56a.757.757 0 0 0-.56-.24.712.712 0 0 0-.58.22z" fill="#000"/><path d="M7.6 7.06c-.08-.3-.22-.58-.44-.8a1.78 1.78 0 0 0-1.22-.42c-.4-.02-.78.16-1.04.48l2.7.74z" fill="#D32B00"/><path d="M10 5.04c-1.3 0-2.36 1.06-2.38 2.36v.02c0 .64.24 1.24.7 1.68.94.92 2.44.92 3.36 0 .46-.44.7-1.06.7-1.68 0-1.3-1.06-2.36-2.36-2.38H10z" fill="url(#d)"/><path d="M8.42 7.42C8.42 8.3 9.12 9 10 9c.42 0 .82-.16 1.12-.46.3-.3.48-.7.46-1.12 0-.88-.7-1.58-1.58-1.58-.42 0-.82.16-1.12.46-.3.28-.46.7-.46 1.12z" fill="#fff"/><path d="M9.44 6.86a.71.71 0 0 0-.22.56c-.02.42.32.78.76.8h.04c.22 0 .42-.08.56-.22.16-.16.24-.36.22-.58 0-.2-.08-.4-.22-.56a.77.77 0 0 0-.58-.24c-.22 0-.42.08-.56.24z" fill="#000"/><path d="M8.38 7.12c.1-.32.26-.6.5-.82.3-.3.7-.46 1.12-.46.4 0 .8.14 1.1.42l-2.72.86z" fill="#D32B00"/><path fill-rule="evenodd" clip-rule="evenodd" d="M4.51 6.454a.258.258 0 0 1 .316-.183l2.72.72a.258.258 0 0 1-.132.498l-2.72-.72a.258.258 0 0 1-.183-.315zm6.997-.047a.258.258 0 0 1-.174.32l-2.7.8a.258.258 0 1 1-.146-.494l2.7-.8c.136-.04.28.037.32.174z" fill="#000"/><path fill-rule="evenodd" clip-rule="evenodd" d="M11.47 4.824a.258.258 0 0 1-.114.346l-2.74 1.38a.258.258 0 0 1-.232-.46l2.74-1.38a.258.258 0 0 1 .346.114zm-6.9 0a.258.258 0 0 1 .346-.114l2.74 1.38a.258.258 0 0 1-.232.46l-2.74-1.38a.258.258 0 0 1-.114-.346z" fill="#5B3C22"/><path opacity=".5" fill-rule="evenodd" clip-rule="evenodd" d="m10.49 12.27-.14.252.14-.252a.31.31 0 0 1-.3.54l.15-.27-.15.27-.004-.002a1.31 1.31 0 0 0-.133-.062 3.954 3.954 0 0 0-.44-.157 5.713 5.713 0 0 0-1.689-.22c-.728.01-1.262.13-1.608.243a3.018 3.018 0 0 0-.469.196.692.692 0 0 0-.018.011l-.002.002v-.001a.31.31 0 0 1-.335-.52l.168.26-.168-.26.002-.001.004-.002.01-.007.034-.02a3.642 3.642 0 0 1 .582-.247c.403-.131 1-.262 1.792-.272a6.33 6.33 0 0 1 1.872.245 4.554 4.554 0 0 1 .647.245l.038.02.011.005.004.002.002.002z" fill="#FF783F"/><path fill-rule="evenodd" clip-rule="evenodd" d="M7.955 11.37a5.15 5.15 0 0 1 2.849.788.31.31 0 0 1-.328.524 4.53 4.53 0 0 0-2.51-.693h-.002a4.58 4.58 0 0 0-1.757.353 3.226 3.226 0 0 0-.545.298.828.828 0 0 0-.023.017l-.004.003a.31.31 0 0 1-.39-.48l.195.24-.196-.24h.001l.001-.001.004-.003.011-.01.039-.028a3.845 3.845 0 0 1 .663-.365 5.198 5.198 0 0 1 1.992-.402zm-2.32 1.29z" fill="#401E13"/></g><defs><linearGradient id="b" x1="8" y1=".69" x2="8" y2="16.692" gradientUnits="userSpaceOnUse"><stop stop-color="#FF7B44"/><stop offset="1" stop-color="#E62E00"/></linearGradient><linearGradient id="c" x1="6.045" y1="4.86" x2="6.045" y2="9.61" gradientUnits="userSpaceOnUse"><stop stop-color="#E73304"/><stop offset="1" stop-color="#F4692D"/></linearGradient><linearGradient id="d" x1="10.004" y1="4.86" x2="10.004" y2="9.606" gradientUnits="userSpaceOnUse"><stop stop-color="#E73304"/><stop offset="1" stop-color="#F4692D"/></linearGradient></defs></svg>
`,P=y.qy`
<svg width="15" height="16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="m1.078 9.32.2-.68h3c.32-.5.7-1.04 1.1-1.6.8-1.12 1.36-1.82 1.7-2.1.9-.7 1.46-1.16 1.7-1.36.9-.8 1.4-1.4 1.5-1.82.04-.34.18-.68.4-.96.1-.12.24-.2.4-.2.26 0 .52.18.76.52.36.48.36 1.16.04 2-.18.46-.4.9-.66 1.32-.2.28-.38.56-.54.86-.18.36-.26.78-.2 1.18.68.04 1.34.14 2 .32 1.34.36 2 .88 2 1.58 0 .2-.04.4-.12.6-.08.2-.18.28-.28.28l.3.22c.22.28.32.62.3.96 0 .22-.12.44-.3.58-.1.08-.2.14-.3.2l.16.3c.1.28.1.58.02.86-.06.22-.18.42-.36.56-.12.12-.28.2-.44.24v.74c-.06.54-.26.88-.6 1.04-.72.36-1.12.54-1.2.58-.56.16-1.36.2-2.4.12-1.12-.1-2.22-.26-3.3-.52-.6-.14-1.1-.26-1.5-.38h-3c-.12-.3-.22-.6-.28-.92-.2-.68-.3-1.4-.32-2.1.02-.8.08-1.62.22-2.42Z" fill="#FDCE4C"/></svg>
`,q=y.qy`
<svg width="16" height="14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M14.578 2.3c-.84-.96-1.98-1.58-3.26-1.52-1.28.08-2.44.74-3.16 1.8-.2-.2-.36-.46-.58-.66-.24-.22-.5-.42-.78-.6-.6-.36-1.28-.56-1.96-.56-1.32.04-2.54.68-3.32 1.74a4.82 4.82 0 0 0-.84 3.64c.24 1.34 1.04 2.48 2 3.4 1.66 1.58 3.56 2.78 5.22 4.34.14.14.26.16.4.02.26-.24.48-.52.76-.74.28-.22.56-.48.86-.7 1.08-.84 2.2-1.64 3.24-2.56 1.14-1.02 2.12-2.26 2.4-3.8.26-1.34-.1-2.72-.98-3.8Z" fill="#F4322A"/></svg>
`,D=y.qy`
    <svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#a)"><path d="M16 8c.04-2.12-.82-4.18-2.36-5.64A7.598 7.598 0 0 0 8 0C5.86-.04 3.82.82 2.34 2.36A7.655 7.655 0 0 0 0 8c-.04 2.12.82 4.18 2.34 5.66A7.732 7.732 0 0 0 8 16c2.12.04 4.18-.82 5.64-2.34A7.642 7.642 0 0 0 16 8z" fill="#FDCD4D"/><path fill-rule="evenodd" clip-rule="evenodd" d="M11.862 12.086c-2.486-1.03-4.94-1.028-7.34-.002a.31.31 0 0 1-.244-.569c2.56-1.093 5.186-1.092 7.82 0a.31.31 0 0 1-.236.57z" fill="#FEE154"/><path fill-rule="evenodd" clip-rule="evenodd" d="M10.886 11.374a6.04 6.04 0 0 0-2.678-.562h-.016a6.066 6.066 0 0 0-2.698.562l-.008.004-.009.003c-.28.116-.542.303-.809.532a.412.412 0 1 1-.536-.626c.29-.25.626-.5 1.022-.665A6.89 6.89 0 0 1 8.2 9.987a6.864 6.864 0 0 1 3.026.635c.395.165.732.415 1.022.665a.412.412 0 1 1-.537.626c-.266-.229-.527-.416-.808-.532l-.009-.003-.008-.004z" fill="#32150C"/><path d="M11.3 4.7c-.44-.46-1.06-.72-1.7-.7-1.32 0-2.4 1.08-2.4 2.4 0 1.32 1.08 2.4 2.4 2.4.64.02 1.26-.24 1.7-.7.46-.44.72-1.06.7-1.7.02-.64-.24-1.26-.7-1.7z" fill="url(#b)"/><path d="M8.1 4.7c-.44-.46-1.06-.72-1.7-.7C5.08 4 4 5.08 4 6.4c-.02.64.24 1.24.7 1.7.44.46 1.06.72 1.7.7.64.02 1.26-.24 1.7-.7.46-.44.72-1.06.7-1.7.02-.64-.24-1.26-.7-1.7z" fill="url(#c)"/><path d="M5.28 5.28c-.32.28-.48.7-.48 1.12 0 .88.72 1.6 1.6 1.6.42 0 .84-.16 1.14-.46.3-.3.48-.7.46-1.14 0-.88-.72-1.6-1.6-1.6-.42 0-.84.16-1.12.48z" fill="url(#d)"/><path d="M8.46 5.28c-.3.28-.46.7-.46 1.12C8 7.28 8.72 8 9.6 8c.42 0 .84-.16 1.14-.46.3-.3.48-.7.46-1.14 0-.88-.72-1.6-1.6-1.6-.42 0-.84.16-1.14.48z" fill="url(#e)"/><path fill-rule="evenodd" clip-rule="evenodd" d="M8.898 1.508a.31.31 0 0 1 .394.19 4.024 4.024 0 0 0 1.486 1.969l.005.003c.268.197.573.341.9.432a.31.31 0 0 1-.166.596 3.392 3.392 0 0 1-1.097-.527 4.643 4.643 0 0 1-1.712-2.27.31.31 0 0 1 .19-.393zm-1.796 0a.31.31 0 0 1 .19.394 4.643 4.643 0 0 1-1.712 2.27 3.392 3.392 0 0 1-1.097.526.31.31 0 0 1-.166-.596c.327-.09.632-.235.9-.431l.005-.004a4.024 4.024 0 0 0 1.486-1.969.31.31 0 0 1 .394-.19z" fill="#976537"/><path d="M5.82 5.84c-.14.14-.22.34-.22.56 0 .44.34.8.78.8h.02c.22 0 .42-.08.56-.24a.79.79 0 0 0 .24-.56c0-.22-.08-.42-.24-.56a.726.726 0 0 0-.56-.24c-.22 0-.42.08-.58.24zm3.22 0c-.16.14-.24.34-.24.56 0 .44.34.8.78.8h.02c.22 0 .42-.08.56-.24a.79.79 0 0 0 .24-.56c0-.22-.08-.42-.24-.56a.726.726 0 0 0-.56-.24c-.22 0-.42.08-.56.24z" fill="#000"/></g><defs><linearGradient id="b" x1="9.6" y1="3.992" x2="9.6" y2="8.793" gradientUnits="userSpaceOnUse"><stop stop-color="#FFB400"/><stop offset="1" stop-color="#FDCD4D"/></linearGradient><linearGradient id="c" x1="6.4" y1="3.992" x2="6.4" y2="8.793" gradientUnits="userSpaceOnUse"><stop stop-color="#FFB400"/><stop offset="1" stop-color="#FDCD4D"/></linearGradient><linearGradient id="d" x1="6.4" y1="6.52" x2="6.4" y2="7.8" gradientUnits="userSpaceOnUse"><stop stop-color="#fff"/><stop offset="1" stop-color="#E7F9FF"/></linearGradient><linearGradient id="e" x1="9.6" y1="6.52" x2="9.6" y2="7.8" gradientUnits="userSpaceOnUse"><stop stop-color="#fff"/><stop offset="1" stop-color="#E7F9FF"/></linearGradient></defs></svg>
`,B=y.qy`
    <svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#a)"><path d="M16 8c.04-2.12-.82-4.18-2.36-5.64A7.598 7.598 0 0 0 8 0C5.86-.04 3.82.82 2.34 2.36A7.655 7.655 0 0 0 0 8c-.04 2.12.82 4.18 2.34 5.66A7.732 7.732 0 0 0 8 16c2.12.04 4.18-.82 5.64-2.34A7.642 7.642 0 0 0 16 8Z" fill="#FDCD4D"/><path d="m6.34 10.34-.16.4c-.12.42-.2.84-.24 1.26-.22 2.3.44 3.44 2 3.44s2.28-1.02 2.16-3.08c-.04-.46-.12-.9-.24-1.34-.12-.36-.18-.6-.2-.68" stroke="#FEE154" stroke-width=".722" stroke-linecap="round"/><path d="M8 9.3c-.4 0-.8.12-1.1.36-.3.24-.56.54-.72.9-.06.12-.12.26-.18.4-.28.76-.28 1.58 0 2.32.4 1.06 1.06 1.58 2 1.6.94-.02 1.6-.56 1.98-1.6.3-.88.26-1.84-.12-2.7a2.61 2.61 0 0 0-.76-.92c-.3-.24-.7-.36-1.1-.36Z" fill="#fff"/><path d="M8 9.3c.4 0 .78.12 1.1.36.32.24.58.56.76.92.38.86.42 1.82.12 2.7-.38 1.06-1.04 1.58-1.98 1.6-.94-.02-1.6-.56-2-1.6-.28-.76-.28-1.58 0-2.34.04-.14.1-.26.18-.4.16-.36.42-.66.72-.9.32-.22.7-.34 1.1-.34Z" stroke="url(#b)" stroke-width=".722" stroke-linecap="round"/><path d="M11.86 2.54c-.6-.62-1.42-.96-2.26-.94a2.99 2.99 0 0 0-2.26.94c-.62.6-.94 1.42-.94 2.26-.02.84.32 1.66.94 2.26.6.62 1.42.96 2.26.94.86.02 1.66-.32 2.26-.94.62-.58.96-1.4.94-2.26a2.99 2.99 0 0 0-.94-2.26Z" fill="url(#c)"/><path d="M8.66 2.54c-.6-.62-1.42-.96-2.26-.94a2.99 2.99 0 0 0-2.26.94c-.62.6-.94 1.42-.94 2.26-.02.84.32 1.66.94 2.26.6.62 1.42.96 2.26.94.86.02 1.66-.32 2.26-.94.62-.58.96-1.4.94-2.26a2.99 2.99 0 0 0-.94-2.26Z" fill="url(#d)"/><path d="M4.7 3.1c-.46.44-.7 1.06-.7 1.7-.02.64.24 1.26.7 1.7.44.46 1.06.72 1.7.7.64 0 1.26-.24 1.7-.7.46-.44.72-1.06.7-1.7 0-.64-.24-1.26-.7-1.7-.44-.46-1.06-.7-1.7-.7-.64-.02-1.26.24-1.7.7Z" fill="#fff"/><path d="M7.9 3.1c-.46.44-.7 1.06-.7 1.7-.02.64.24 1.26.7 1.7.44.46 1.06.72 1.7.7.64 0 1.26-.24 1.7-.7.46-.44.72-1.06.7-1.7 0-.64-.24-1.26-.7-1.7-.44-.46-1.06-.7-1.7-.7-.64-.02-1.26.24-1.7.7Z" fill="#fff"/><path d="M5.68 4.1a1 1 0 0 0-.28.7c0 .54.42 1 .96 1h.04c.26 0 .52-.1.72-.28.2-.18.3-.44.28-.72a1 1 0 0 0-.28-.7.95.95 0 0 0-.72-.3c-.26 0-.52.1-.72.3ZM8.88 4.1a1 1 0 0 0-.28.7c0 .54.42 1 .96 1h.04c.26 0 .52-.1.72-.28.2-.18.3-.44.28-.72a1 1 0 0 0-.28-.7.95.95 0 0 0-.72-.3c-.26 0-.52.1-.72.3Z" fill="#000"/><path d="M7.12.6C6.72.54 6.3.54 5.9.6c-.86.12-1.64.54-2.2 1.2M8.86.6c.4-.06.82-.06 1.22 0 .86.12 1.64.54 2.2 1.2" stroke="#976537" stroke-width=".619" stroke-linecap="round"/></g><defs><linearGradient id="b" x1="7.997" y1="16.086" x2="7.997" y2="9.198" gradientUnits="userSpaceOnUse"><stop stop-color="#8D503D"/><stop offset="1" stop-color="#32150C"/></linearGradient><linearGradient id="c" x1="9.6" y1="1.53" x2="9.6" y2="7.931" gradientUnits="userSpaceOnUse"><stop stop-color="#FFB400"/><stop offset="1" stop-color="#FDCD4D"/></linearGradient><linearGradient id="d" x1="6.4" y1="1.53" x2="6.4" y2="7.931" gradientUnits="userSpaceOnUse"><stop stop-color="#FFB400"/><stop offset="1" stop-color="#FDCD4D"/></linearGradient></defs></svg>
`,A=y.qy`
    <svg width="16" height="16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 8c0-2.2-.78-4.1-2.36-5.64C12.1.78 10.2 0 8 0 5.8 0 3.9.78 2.34 2.36.78 3.9 0 5.8 0 8c0 2.22.78 4.1 2.34 5.66C3.9 15.22 5.8 16 8 16s4.1-.78 5.64-2.34C15.22 12.1 16 10.2 16 8z" fill="#FDCE4C"/><path d="M11.86 3.34c-.62-.62-1.38-.94-2.26-.94-.88 0-1.64.32-2.26.94-.62.62-.94 1.38-.94 2.26 0 .88.32 1.64.94 2.26.62.62 1.38.94 2.26.94.88 0 1.64-.32 2.26-.94.62-.62.94-1.38.94-2.26 0-.88-.32-1.64-.94-2.26z" fill="url(#a)"/><path d="M8.66 3.34c-.62-.62-1.38-.94-2.26-.94-.88 0-1.64.32-2.26.94-.62.62-.94 1.38-.94 2.26 0 .88.32 1.64.94 2.26.62.62 1.38.94 2.26.94.88 0 1.64-.32 2.26-.94.62-.62.94-1.38.94-2.26 0-.88-.32-1.64-.94-2.26z" fill="url(#b)"/><path d="M4.7 3.9c-.46.48-.7 1.04-.7 1.7 0 .66.24 1.24.7 1.7.46.46 1.04.7 1.7.7.66 0 1.22-.24 1.7-.7.46-.46.7-1.04.7-1.7 0-.66-.24-1.22-.7-1.7-.48-.46-1.04-.7-1.7-.7-.66 0-1.24.24-1.7.7z" fill="#fff"/><path d="M7.9 3.9c-.46.48-.7 1.04-.7 1.7 0 .66.24 1.24.7 1.7.46.46 1.04.7 1.7.7.66 0 1.22-.24 1.7-.7.46-.46.7-1.04.7-1.7 0-.66-.24-1.22-.7-1.7-.48-.46-1.04-.7-1.7-.7-.66 0-1.24.24-1.7.7z" fill="#fff"/><path d="M6.64 3.62c-.16.16-.24.34-.24.56 0 .22.08.42.24.58.16.16.34.22.56.22.22 0 .4-.08.58-.22.16-.16.22-.36.22-.58 0-.22-.08-.4-.22-.56a.801.801 0 0 0-.58-.24c-.22 0-.4.08-.56.24zm3.2 0c-.16.16-.24.34-.24.56 0 .22.08.42.24.58.16.16.34.22.56.22.22 0 .4-.08.58-.22.16-.16.22-.36.22-.58 0-.22-.08-.4-.22-.56a.801.801 0 0 0-.58-.24c-.22 0-.4.08-.56.24z" fill="#000"/><path fill-rule="evenodd" clip-rule="evenodd" d="M7.364 9.446a.425.425 0 0 1 .59.118c.275.413.556.588.839.63.297.045.69-.043 1.206-.357a.425.425 0 0 1 .442.726c-.603.366-1.201.558-1.774.472-.587-.087-1.056-.452-1.42-1a.425.425 0 0 1 .117-.589z" fill="#FEE154"/><path fill-rule="evenodd" clip-rule="evenodd" d="M7.21 9.43a.425.425 0 0 1 .56-.22c.754.331 1.54.46 2.384.367a.425.425 0 0 1 .092.845 5.422 5.422 0 0 1-2.817-.433.425.425 0 0 1-.218-.56z" fill="#000"/><path fill-rule="evenodd" clip-rule="evenodd" d="M6.72 1.361c.334-.083.655-.127.92-.127a.266.266 0 1 1 0 .532 3.43 3.43 0 0 0-.796.112l-.009.002c-.621.132-1.094.372-1.452.713a.266.266 0 1 1-.366-.386c.44-.418 1.007-.697 1.703-.846zm2.627.408.125-.513.833.102.014.003c.657.148 1.223.428 1.664.846l-.276.442-2.36-.88z" fill="#976537"/><mask id="c" mask-type="alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="16" height="16"><path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0z" fill="#C4C4C4"/></mask><g mask="url(#c)"><path fill-rule="evenodd" clip-rule="evenodd" d="M12.281 11.185c-.276.613-1.21 1.595-2.733.617A55.468 55.468 0 0 0 5.524 9.49c-.462-.364-1.376-.83-1.345.221-.016.307.083.99.603 1.269.425.229 1.596.903 2.417 1.379a.601.601 0 0 0-.57.89l-.09.109a.6.6 0 0 0-.513.886 1.74 1.74 0 0 0-.06.144.601.601 0 0 0-.092 1.101l.146.078c.068.154.161.314.283.479 1.208 1.644 3.315 2.162 4.4 2 .896-.148 2.825-.963 2.8-3.8-.026-2.837.341-3.661.428-3.764.19-.51.465-1.559.05-1.663-.417-.105-.869.278-1.043.483l-.657 1.884z" fill="#000"/><path d="M8.86 11.057c1.523.978 2.457-.004 2.734-.617l.656-1.884c.175-.204.627-.588 1.043-.483.415.104.14 1.152-.05 1.663-.087.103-.453.927-.428 3.764.025 2.837-1.903 3.652-2.8 3.8-1.084.162-3.192-.356-4.4-2-1.208-1.644.408-2.72 1.378-3.408-.75-.436-2.38-1.379-2.899-1.658-.52-.28-.618-.962-.603-1.268-.03-1.051.884-.586 1.345-.222a55.465 55.465 0 0 1 4.024 2.313z" fill="#D4EFF6"/><path d="M8.234 13.149a.601.601 0 0 0-.25-.813l-1.235-.655a.6.6 0 1 0-.563 1.062l1.235.655a.6.6 0 0 0 .813-.25z" fill="#D4EFF6"/><path d="M7.634 14.149a.601.601 0 0 0-.25-.813l-1.235-.655a.6.6 0 1 0-.563 1.062l1.235.655a.6.6 0 0 0 .813-.25z" fill="#D4EFF6"/><path d="M7.234 15.149a.601.601 0 0 0-.25-.813l-1.235-.655a.6.6 0 1 0-.563 1.062l1.235.655a.6.6 0 0 0 .813-.25z" fill="#D4EFF6"/><path d="m5.41 13.425-.1.218c.642.16 1.224.452 1.74.853a6.114 6.114 0 0 0-1.64-1.07zm.422-.79c.326.037.86.302 1.614.8-.644-.51-1.133-.84-1.447-.999l-.167.199z" fill="#9EC9D6"/></g><defs><linearGradient id="a" x1="9.6" y1="2.398" x2="9.6" y2="8.801" gradientUnits="userSpaceOnUse"><stop stop-color="#FFB400"/><stop offset="1" stop-color="#FFB400"/></linearGradient><linearGradient id="b" x1="6.4" y1="2.398" x2="6.4" y2="8.801" gradientUnits="userSpaceOnUse"><stop stop-color="#FFB400"/><stop offset="1" stop-color="#FFB400"/></linearGradient></defs></svg>
`,V=y.qy`<svg width="16" height="16" viewBox="0 -1 16 16" xmlns="http://www.w3.org/2000/svg">${z}</svg>`;var H,_=y.qy`<msft-content-card layout="condensed" href="${t=>t.href}" target="${(t,e)=>e.parent.target}" title="${t=>t.title}" class="social-reaction-card">${t=>t.title} ${(0,w.z)(t=>t.content_indicator_icon,y.qy`<msft-content-indicator slot="content-indicator">${t=>t.content_indicator_icon}</msft-content-indicator>`)}<img slot="media" src="${t=>t.media_src}" alt="${t=>t.media_alt}" width="${t=>t.media_width}" height="${t=>t.media_height}" />${(0,w.z)(t=>t.media_icon,y.qy` <div class="media-icon" slot="icon">${S}</div>`)} ${(0,w.z)(t=>t.attribution_src||t.attribution_title,y.qy`<msft-attribution slot="attribution">${(0,w.z)(t=>t.attribution_src,y.qy`<img slot="image" src="${t=>t.attribution_src}" alt="${t=>t.attribution_alt}" width="${t=>t.attribution_width}" height="${t=>t.attribution_height}" />`)}<span class="attribution-container"><span class="attribution-title">${t=>t.attribution_title}</span>${(0,w.z)(t=>t.attribution_publishedDate,y.qy`<span class="attribution-separator">&middot;</span><span class="attribution-date">${t=>t.attribution_publishedDate}</span>`)}</span></msft-attribution>`)} ${(0,w.z)(t=>t.more_actions,y.qy`<div slot="start-actions" class="like-button">${(0,w.z)(t=>t.social_reaction_count,y.qy` ${(0,w.z)(t=>t.social_reaction_angry,y.qy`${T}`)} ${(0,w.z)(t=>t.social_reaction_like,y.qy`${P}`)} ${(0,w.z)(t=>t.social_reaction_love,y.qy`${q}`)} ${(0,w.z)(t=>t.social_reaction_sad,y.qy`${D}`)} ${(0,w.z)(t=>t.social_reaction_surprised,y.qy`${B}`)} ${(0,w.z)(t=>t.social_reaction_thinking,y.qy`${A}`)}<span style="margin-inline-end: 30px">${t=>t.social_reaction_count}</span>`)} ${(0,w.z)(t=>t.comment_count,y.qy`<svg width="14" height="13" viewBox="0 0 14 13" xmlns="http://www.w3.org/2000/svg"><path d="M0 2.5C0 1.11929 1.11929 0 2.5 0H11.5C12.8807 0 14 1.11929 14 2.5V7.5C14 8.88071 12.8807 10 11.5 10H7.68787L4.62533 12.6797C3.99168 13.2342 3 12.7842 3 11.9422V10H2.5C1.11929 10 0 8.88071 0 7.5V2.5ZM2.5 1C1.67157 1 1 1.67157 1 2.5V7.5C1 8.32843 1.67157 9 2.5 9H4V11.8981L7.31213 9H11.5C12.3284 9 13 8.32843 13 7.5V2.5C13 1.67157 12.3284 1 11.5 1H2.5Z" /></svg><span>${t=>t.comment_count}</span>`)}</div><fluent-button appearance="stealth" class="actions-button" slot="end-actions" @click=${(t,e)=>e.parent.actionTriggered(t)} @keypress=${(t,e)=>e.parent.actionTriggered(t)}>${V}</fluent-button>`)}</msft-content-card>`;!function(t){t.ordered="ordered",t.unordered="unordered"}(H||(H={}));class L extends $.L{constructor(){super(...arguments),this.listType=H.unordered,this.ready=!1,this.dividerEnabled=!1,this.touchHoverUnderlineDisabled=!1,this.templateByType={"content-card":C,"condensed-card":M,"social-reactions-card":_}}selectTemplate(){return this.templateByType[this.itemTemplate]}actionTriggered(t,e){this.$emit("action-triggered",{data:t,event:e})}}(0,m.Cg)([(0,x.CF)({attribute:"list-type"})],L.prototype,"listType",void 0),(0,m.Cg)([b.sH],L.prototype,"data",void 0),(0,m.Cg)([(0,x.CF)({attribute:"item-template"})],L.prototype,"itemTemplate",void 0),(0,m.Cg)([b.sH],L.prototype,"ready",void 0),(0,m.Cg)([x.CF],L.prototype,"target",void 0),(0,m.Cg)([(0,x.CF)({attribute:"divider-enabled",mode:"boolean"})],L.prototype,"dividerEnabled",void 0),(0,m.Cg)([(0,x.CF)({attribute:"touch-hover-underline-disabled",mode:"boolean"})],L.prototype,"touchHoverUnderlineDisabled",void 0);var G=o(74849),j=o(64187),E=o(22131),I=o(7896),O=o(41123),Z=o(48751),U=o(89580),N=o(61138);const R=G.A`
        ${(0,j.V)("flex")} :host{box-sizing:border-box;font-family:${I.O};
            font-size: ${O.K};
            line-height: ${O.Z};
            color: ${Z.l};height:100%;width:100%;flex-direction:column}.ordered-list,.unordered-list{display:flex;flex-direction:column;height:100%;justify-content:space-between;margin:8px 0}.ordered-list{list-style:decimal;padding-inline-start:30px}msft-content-card{--heading-font-size:${O.K};
            --heading-line-height: ${O.Z}}.touch-underline-disabled msft-content-card::part(heading):hover,.touch-underline-disabled msft-content-card::part(heading):focus{text-decoration:none;-webkit-tap-highlight-color:transparent}msft-content-card[layout="condensed"]{margin-bottom:11px}.ordered-list msft-content-card{display:block;--heading-start-padding:4px}::slotted(*){display:grid;grid-template-columns:auto 1fr auto;grid-gap:12px;margin:8px 12px 0 12px;font-size:${U.Y};
            line-height: ${U.v};align-items:center;font-weight:bold}::slotted([slot="footer"]){display:grid;grid-template-columns:1fr auto;grid-gap:12px;font-weight:unset;margin:0px 12px 8px 12px;font-size:${N.k};
            line-height: ${N.F};align-items:center}.unordered-list{list-style:none;padding:0}.attribution-container{display:flex;max-width:154px}.attribution-condensed-container{display:grid;grid-template-columns:minmax(0px,1fr) auto;column-gap:6px}.attribution-condensed-container .attribution-container{display:flex;max-width:100%}.attribution-condensed-container .actions-button{z-index:2;margin-top:2px}.actions-button{width:24px;height:24px;min-width:24px;justify-content:center}.actions-button::part(control){padding:0}.like-button{font-size:${N.k}}.attribution-title{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.attribution-separator{margin:0 3px}.attribution-date{white-space:nowrap}.divider li::after{background:rgba(0,0,0,0.1);content:"";height:1px;display:block;margin-left:12px;margin-right:12px;margin-bottom:5px}.divider li:nth-last-child(1)::after{display:none}.media-icon{width:36px;height:36px}.social-reaction-card::part(icon){background:none;filter:drop-shadow(0px 4px 8px rgba(0,0,0,0.2));left:50%;top:50%;margin:0;transform:translate(-50%,-50%)}`.withBehaviors((0,E.mr)(G.A` :host{forced-color-adjust:auto}`));var X=o(39957);const W=y.qy`<li>${(t,e)=>e.parent.selectTemplate()}</li>`,K=y.qy`<slot></slot>${(0,w.z)(t=>"unordered"===t.listType,y.qy`<ul class="unordered-list ${t=>t.dividerEnabled?"divider":""} ${t=>t.touchHoverUnderlineDisabled?"touch-underline-disabled":""}" part="unordered-list">${(0,X.ux)(t=>t.data,W)}</ul>`)} ${(0,w.z)(t=>"ordered"===t.listType,y.qy`<ol class="ordered-list ${t=>t.dividerEnabled?"divider":""} ${t=>t.touchHoverUnderlineDisabled?"touch-underline-disabled":""}" part="ordered-list">${(0,X.ux)(t=>t.data,W)}</ol>`)}<slot name="footer" part="footer"></slot>`,Q=L.compose({name:`${g.i.prefix}-list-card`,template:K,styles:R});var Y=o(93866),J=o(42767),tt=o(98093),et=o(60402);const ot=y.qy`<div class="popover-arrow" part="popover-arrow"><svg width="16" height="6" viewBox="0 0 16 6" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.473.708 3.689 3.996C2.562 5.326 1.333 5.99 0 5.99c.987.02 14.998 0 16 0-1.332 0-2.563-.667-3.692-1.999L9.528.708a2.002 2.002 0 0 0-3.055 0Z" fill="#F2F2F2" /></svg></div><div class="options-list" part="options-list">${(0,w.z)(t=>!0===t.userSignedIn,y.qy`<a class="option-item" part="option-item" @mousedown="${(t,e)=>t.addSymbolAction(e.event)}"><div class="option-svg" part="option-svg"><svg width="11" height="12" viewBox="0 0 11 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6396 5.9V6.6H5.73965V11.5H5.03965V6.6H0.139648V5.9H5.03965V1H5.73965V5.9H10.6396Z" fill="black" fill-opacity="0.83" stroke="black" stroke-opacity="0.83" stroke-width="0.2" /></svg></div><div class="option-str" part="option-str"><span>${t=>t.addSymbolOptStr}</span></div></a>`)}<a class="option-item" part="option-item" @mousedown="${(t,e)=>t.hideCardAction(e.event)}"><div class="option-svg" part="option-svg"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M.409.146A.5.5 0 0 0 .36.797L.41.853l2.689 2.69A6.656 6.656 0 0 0 .46 7.373a.5.5 0 0 0 .97.243 5.658 5.658 0 0 1 2.386-3.355l1.207 1.206a2.666 2.666 0 0 0 3.77 3.77l3.945 3.946a.5.5 0 0 0 .755-.651l-.048-.056L9.37 8.402V8.4l-.799-.799L6.66 5.69h.002L4.74 3.77l-.755-.754-2.87-2.87a.5.5 0 0 0-.707 0Zm5.321 6.03 2.356 2.356A1.666 1.666 0 0 1 5.73 6.176Zm1.197-3.843a6.66 6.66 0 0 0-1.925.283l.824.824a5.667 5.667 0 0 1 6.598 4.18.5.5 0 0 0 .97-.242 6.667 6.667 0 0 0-6.467-5.045Zm.13 2.339 2.534 2.533a2.668 2.668 0 0 0-2.534-2.533Z" fill="#000" fill-opacity=".83" /></svg></div><div class="option-str" part="option-str"><span>${t=>t.hideCardOptStr}</span></div></a><a class="option-item" part="option-item" @mousedown="${(t,e)=>t.dataProviderAction(e.event)}"><div class="option-svg" part="option-svg"><svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M7.5 9c0 .693-.235 1.332-.63 1.84l2.769 2.768a.375.375 0 1 1-.53.53l-2.77-2.768A3 3 0 1 1 7.5 9Zm-3 2.25a2.25 2.25 0 1 0 0-4.5 2.25 2.25 0 0 0 0 4.5Z" fill="#000" fill-opacity=".83" /><path fill-rule="evenodd" clip-rule="evenodd" d="M4.125 2.25a.375.375 0 0 0-.375.375v2.7c-.26.053-.512.133-.75.237V2.625C3 2.004 3.504 1.5 4.125 1.5h3.814c.299 0 .585.119.796.33l2.936 2.935c.21.211.329.497.329.796v6.814c0 .621-.504 1.125-1.125 1.125h-.44a1.121 1.121 0 0 0-.266-.422l-.328-.328h1.034a.375.375 0 0 0 .375-.375V6H8.625A1.125 1.125 0 0 1 7.5 4.875V2.25H4.125Zm4.125.155v2.47c0 .207.168.375.375.375h2.47L8.25 2.405Z" fill="#000" fill-opacity=".83" /></svg></div><div class="option-str" part="option-str"><span>${t=>t.dataProviderOptStr}</span></div></a><a class="option-item" part="option-item" @mousedown="${(t,e)=>t.moreSettingAction(e.event)}"><div class="option-svg" part="option-svg"><svg width="11" height="3" viewBox="0 0 11 3" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.5 1.25a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0ZM6.5 1.25a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0ZM9.25 2.5a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5Z" fill="#000" fill-opacity=".83" /></svg></div><div class="option-str" part="option-str"><span>${t=>t.moreSettingOptStr}</span></div></a></div>`,it=y.qy`<div class="quote-row"><div class="quote-view" part="quote-view" id="quoteItemView"><a class="quote-titles-cntr" part="quote-titles-cntr" href="${t=>t.quoteHref}" target=${t=>t.target}><span class="quote-title" part="quote-title">${(0,w.z)(t=>t.displayName.length<=8,y.qy`<p class="quote-title-str" part="quote-title-str">${t=>t.displayName}</p>`)} ${(0,w.z)(t=>t.displayName.length>8,y.qy`<p class="quote-title-str" part="quote-title-str">${t=>t.symbol}</p>`)}</span><span class="sec-title" part="sec-title"><p class="sec-title-str" part="sec-title-str">${t=>t.displayName}</p></span></a><div class="price" part="price"><span class="price-str" part="price-str">${t=>t.price}</span></div><a class="change-values ${(t,e)=>e.parent.getQuoteColor(t.gain,t.unchanged,"quote-red","quote-green","quote-grey")}" part="change-values ${(t,e)=>e.parent.getQuoteColor(t.gain,t.unchanged,"quote-red","quote-green","quote-grey")}" @click="${(t,e)=>e.parent.changeShowingValue()}">${(0,w.z)((t,e)=>e.parent.showChangeValue,y.qy`<span class="change-values-str" part="change-values-str">&lrm;${t=>t.changeValue}</span>`)} ${(0,w.z)((t,e)=>!e.parent.showChangeValue,y.qy`<span class="change-values-percentage" part="change-values-percentage">&lrm;${t=>t.changePcnt}</span>`)}</a></div></div>`,at=y.qy`<div class="quote-list" part="quote-list">${(0,X.ux)(t=>t.quoteItems&&t.quoteItems.map(e=>({...e,target:t.target})),it)}</div><div class="footer" part="footer"><fluent-anchor class="sd-action" part="sd-action" target=${t=>t.target} href="${t=>t.footerLink}">${t=>t.footer}</fluent-anchor></div>`,nt=y.qy`<div class="empty-item" part="empty-item"><div class="empty-str" part="empty-str"><span>${t=>t.emptyWatchlistStr}&lrm;</span></div><fluent-button class="add-symbol-button sd-action" appearance="outline" part="add-symbol-button" @click="${(t,e)=>t.addSymbolAction(e.event)}">&lrm;${t=>t.addSymbolBtnStr}</fluent-button></div>${(0,w.z)(t=>t.layout===tt.PO.full,y.qy`<div class="quote-list-empty-watchlist" part="quote-list">${(0,X.ux)(t=>t.quoteItems&&t.quoteItems.map(e=>({...e,target:t.target})),it)}</div>`)}
`,rt=y.qy`<a class="suggestion-entry" part="suggestion-entry" @click="${(t,e)=>e.parent.addToWatchlist(t.quoteId)}"><div class="suggestion-item" part="suggestion-item"><div class="suggestion-company" part="suggestion-company"><span class="suggestion-symbol" part="suggestion-symbol">${t=>t.equitySymbol}</span><span class="suggestion-name" part="suggestion-name">${t=>t.longName}</span></div><div class="suggestion-market" part="suggestion-market"><span class="suggestion-market-str">${t=>t.exchangeName}</span></div><div class="suggestion-add-icon"><svg width="11" height="11" viewBox="0 0 11 11" xmlns="http://www.w3.org/2000/svg"><path d="M10.5 4.9V5.6H5.6V10.5H4.9V5.6H0V4.9H4.9V0H5.6V4.9H10.5Z" fill="black" fill-opacity="0.83" /></svg></div></div></a>`,st=y.qy`<div class="search-area" part="search-area"><div class="search-button" part="search-button"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 3a5.5 5.5 0 0 1 4.227 9.02l4.127 4.126a.5.5 0 0 1-.638.765l-.07-.057-4.126-4.127A5.5 5.5 0 1 1 8.5 3Zm0 1a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9Z" fill="#212121" /></svg></div><input class="search-input" part="search-input" type="search" autofocus="autofocus" @input=${t=>t.handleTextInput()} placeholder="${t=>t.searchPlaceholder}" :value="${t=>t.value}" ${(0,et.K)("inputControl")} />${(0,w.z)(t=>!0===t.showSuggestions,y.qy`<div class="suggestions-list" part="suggestions-list">${(0,X.ux)(t=>t.searchSuggestions,rt)}</div>`)} ${(0,w.z)(t=>!0===t.noSuggestion,y.qy`<div class="suggestions-list" part="suggestions-list"><div class="no-suggestion-str">${t=>t.noSuggestionHint}</div></div>`)}</div>`,lt=y.qy`<div class="title" part="title" ${(0,et.K)("titleArea")}>${(0,w.z)(t=>t.cardType===tt.po.AddWatchlist,y.qy`<a class="title-link" part="title-link" @click="${t=>t.onTitleClicked()}"><div class="title-content">&lrm;${t=>t.titleStr}</div></a>`)} ${(0,w.z)(t=>t.cardType!=tt.po.AddWatchlist,y.qy`<a class="title-link" part="title-link" href="${t=>t.titleLink}" target=${t=>t.target}><div class="title-content">&lrm;${t=>t.titleStr}</div></a><fluent-button id="option-button" class="option-button" part="option-button" slot="option-actions" @click="${t=>t.optionClicked()}" @blur="${t=>t.onBlurOption()}" ref="optButton"><slot name="option-button-svg"></slot></fluent-button>`)}</div>${(0,w.z)(t=>t.optionSwitch,ot)} ${(0,w.z)(t=>t.cardType===tt.po.ShowData,at)} ${(0,w.z)(t=>t.cardType===tt.po.EmptyWatchlist,nt)} ${(0,w.z)(t=>t.cardType===tt.po.AddWatchlist,st)}
`;var dt=o(57416),ct=o(48196),pt=o(64003),ut=o(22683),ht=o(37302),gt=o(86856),vt=o(26920),ft=o(73477),mt=o(50882),$t=o(87481);const xt=G.A` .options-list{right:16px}.option-str{padding:0px 10px 3px 0px}.popover-arrow{left:264px}`,bt=G.A` .options-list{left:16px}.option-str{padding:0px 0px 3px 10px}.popover-arrow{left:25px}`,yt=G.A`
    ${(0,j.V)("grid")} :host{box-sizing:border-box;position:relative;width:100%;outline:none;padding:8px;height:100%;grid-template-rows:auto 1fr}:host([layout="full"]) .footer{align-items:center;display:flex;justify-content:center;margin-top:8px}:host([layout="full"]) .price-str{font-size:${U.Y};
        font-weight: 500;
        height: 23px;
        line-height: ${O.Z}}:host([layout="full"]) .quote-list{grid-row-gap:24px;height:200px}:host([layout="full"]) .quote-title-str{color:${Z.l};
        font-size: ${O.K};
        font-weight: 600;
        height: 18px;
        line-height: ${N.F};overflow:hidden;text-overflow:ellipsis;margin:0px}:host([layout="full"]) .sec-title-str{font-size:${N.k};
        height: 14px;
        line-height: ${N.F}}:host([layout="full"]) .title{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:1fr auto;height:24px;margin-bottom:11px}:host([layout="half"]) .footer{align-items:center;display:flex;justify-content:center;margin-top:8px}:host([layout="half"]) .price-str{font-size:${O.K};font-weight:500;height:18px;line-height:18px}:host([layout="half"]) .quote-list{grid-row-gap:6px;height:54px}:host([layout="half"]) .quote-title-str{color:${Z.l};
        font-size: ${U.Y};font-weight:600;height:18px;line-height:18px;overflow:hidden;text-overflow:ellipsis;margin:0px}:host([layout="half"]) .sec-title-str{display:none}:host([layout="half"]) .title{align-items:center;display:grid;grid-template-columns:1fr auto;grid-column-gap:8px;margin-bottom:8px}.change-values{border-radius:calc(${dt.Pb} * 1px);cursor:pointer;display:flex;flex-direction:column;text-decoration:none;display:flex;justify-content:center;height:24px;padding:0 6px}.change-values-str,.change-values-percentage{font-size:${N.k};
        line-height: ${N.F};display:flex;justify-content:flex-end}.operation-btn::part(actions){border:none;padding-right:0px;padding-left:0px;height:32px;width:99px}.option-button{display:none;--control-corner-radius:20;height:24px;width:24px;min-width:24px}.option-button::part(control){padding:0}.index-logo{justify-content:flex-start;fill:${Z.l}}.operation-btn{height:calc(${ct.D} * 1px);width:99px}.price{align-items:center;display:flex;justify-content:flex-end}.price-str{}.quote-green{color:#ffffff;background:#107c10}.quote-list{display:grid}.quote-list-empty-watchlist{display:grid;grid-row-gap:24px;height:88px;margin-bottom:44px}.quote-red{color:#ffffff;background:#d33e3e}.quote-grey{color:#ffffff;background:#808080}.quote-titles-cntr{text-decoration:none}.quote-view{align-items:center;display:grid;grid-column-gap:10px;grid-template-columns:var(--quote-grid-columns-ltr)}.sec-title-str{color:${pt.c};margin:0px;overflow:hidden;text-overflow:ellipsis}.title-link{font-weight:500;color:${Z.l};
        display: flex;
        font-size: ${N.k};
        justify-content: flex-start;
        line-height: ${N.F};
        outline: none;
        cursor: pointer;
        text-decoration: none;
    }

    .title-link:${ft.N}{text-decoration:underline}.title-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:6px;padding-inline-end:12px}.empty-item{width:146px;height:54px;align-items:center;display:grid;border-radius:calc(${dt.Pb} * 1px);
        border: 1px solid ${ut.hb};grid-template-rows:auto 1fr;grid-row-gap:8px;justify-content:center;padding:18px 60px 19px 60px}.empty-str{font-family:Segoe UI;font-size:${O.K};
        line-height: ${O.Z};text-align:center}.add-symbol-button{border-color:#00B294;color:#00B294}.search-area{display:grid;grid-template-columns:auto 1fr;height:calc(${ct.D} * 1px);
        width: 266px;
        position: relative;
        border: 1px solid ${ut.hb}}.search-button{border:none;background:transparent;width:20px;padding:6px 10px}.search-input{background:transparent;font-size:${O.K};
        line-height: ${O.Z};
        height: calc(${ct.D} * 1px);border:none;outline:none}.quote-row{padding:0 8px}.sd-action{height:24px}input[type="search"]::-webkit-search-decoration,input[type="search"]::-webkit-search-cancel-button,input[type="search"]::-webkit-search-results-button,input[type="search"]::-webkit-search-results-decoration{display:none}.popover-arrow{position:absolute;z-index:9998;top:31px}.options-list{display:block;position:absolute;background:#F2F2F2;top:44px;padding:5px 0px;border-radius:3px;z-index:9999}.option-item{cursor:pointer;display:grid;grid-template-columns:28px auto;height:20px;width:100%;margin:0px;padding:3px 0px 3px 0px}.option-item:hover{background:${ht.Xt}}.option-svg{display:flex;align-items:center;width:28px;height:20px}.option-svg svg{margin:0 auto;display:block}.option-str{height:16px;font-size:${N.k};
        line-height: ${O.Z}}.suggestions-list{display:block;position:absolute;box-sizing:border-box;top:40px;width:100%;padding:4px;-webkit-box-shadow:0 0 10px ${ut.hb};
        -moz-box-shadow: 0 0 10px ${ut.hb};
        box-shadow: 0 0 10px ${ut.hb};z-index:9999}.no-suggestion-str{font-size:${O.K};
        line-height: ${N.F};height:16px;margin:5px 0px 5px 9px}.suggestion-entry{text-decoration:none;cursor:pointer}.suggestion-entry:hover .suggestion-item{background:${ht.Xt}}.suggestion-item{display:grid;grid-template-columns:148px 70px 32px;grid-column-gap:2px;height:40px;padding:5px 8px 2px 8px}.suggestion-company{display:grid;grid-template-rows:20px 20px}.suggestion-add-icon{padding-top:9px;padding-left:10px}.suggestion-add-icon svg path{fill:${Z.l}}.suggestion-symbol{font-weight:800;font-size:${O.K};
        line-height: ${O.Z};
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: ${Z.l}}.suggestion-name{font-weight:600;font-size:${N.k};
        line-height: ${O.Z};
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: ${Z.l}}.suggestion-market{position:relative;text-align:right;padding-top:8px}.suggestion-market-str{position:absolute;height:100%;right:0px;font-weight:600;font-size:${N.k};
        line-height: ${O.Z};
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: ${Z.l};
    }

    ${$t.O}
`.withBehaviors(new gt.t(xt,bt),(0,E.mr)(G.A` :host{forced-color-adjust:auto}.option-item,.suggestion-add-icon svg path,.option-svg svg path,.search-button svg path{color:${mt.A.ButtonText};fill:currentcolor;fill-opacity:1}.options-list{forced-color-adjust:none;background:${mt.A.ButtonFace};
                box-shadow: 0 0 0 calc((v${vt.XA} * 1px)) ${mt.A.CanvasText}}.option-item:hover,.option-item:hover .option-svg svg path{background:${mt.A.Highlight};
                color: ${mt.A.HighlightText};fill:currentcolor}.add-symbol-button:hover{border-color:${mt.A.HighlightText};
                color: ${mt.A.HighlightText}}.suggestions-list{forced-color-adjust:none;background:${mt.A.Canvas};
                box-shadow: 0 0 0 calc((v${vt.XA} * 1px)) ${mt.A.CanvasText}}.suggestion-entry .suggestion-item *{color:${mt.A.ButtonText};
                fill: currentcolor;
            }
            .suggestion-entry:hover .suggestion-item,
            .suggestion-entry:${ft.N} .suggestion-item{background:${mt.A.Highlight};
            }
            .suggestion-entry:hover .suggestion-item *,
            .suggestion-entry:hover .suggestion-item svg path,
            .suggestion-entry:${ft.N} .suggestion-item *,
            .suggestion-entry:${ft.N} .suggestion-item svg path{color:${mt.A.HighlightText};
                fill: currentcolor;
            }
        `)),wt=tt.l4.compose({name:`${g.i.prefix}-money-card`,template:lt,styles:yt});var kt=o(16038),Ct=o(61861),zt=o(88635),Ft=o(3065),Mt=o(12680),St=o(11297);const Tt=(t,e)=>{const o=t.cardWidth;return e&&1==t.columnCount?`grid-auto-columns:${o}px;grid-auto-rows:auto`:`grid-auto-columns:${o}px;grid-auto-rows:${(Math.floor(o/.99)-12)/2}px`};var Pt,qt=o(56064),Dt=o(94043),Bt=o(26220),At=o(2171),Vt=o(94976),Ht=o(58792),_t=o(74998),Lt=o(30273),Gt=o(72860),jt=o(27160),Et=o(45110);!function(t){t[t.largeGap=10]="largeGap",t[t.midGap=8]="midGap",t[t.tinyGap=6]="tinyGap",t[t.miniGap=4]="miniGap"}(Pt||(Pt={}));const It=()=>!!(0,Et.zP)(St.h$).getCurrentState().verticalTabsOpened,Ot=t=>Boolean(t&&t in Pt),Zt=t=>!t,Ut=t=>{const{layoutGap:e,horizontalTabLayoutGap:o,consumeVerticalTab:i}=t,a=i&&!It()?o:e;return Ot(a)?a:void 0},Nt=t=>{const{reverseLayoutGap:e}=t;if(Zt(e)){const e=Ut(t);return Ot(e)?{gap:`${e}px`}:void 0}},Rt=t=>e=>{if(t===jt.pL.ShoppingCarousel)return;const{fixedCardHeight:o,reverseLayoutGap:i}=e;if(!Zt(i))return;const a=Ut(e);if(!o||!Ot(a))return;return{"grid-auto-rows":`${((304-a)/2).toFixed(1)}px`}},Xt=(t,e)=>{const o=t.reduce((t,o)=>({...t,...o(e)||{}}),{});return Object.entries(o).map(t=>{let[e,o]=t;return`${e}:${o};`}).join("")};var Wt=o(9206),Kt=o(92966),Qt=o(30010),Yt=o(66198),Jt=o(13312),te=o(10168),ee=o(77367),oe=o(82316),ie=o(15938),ae=o(90905);class ne extends Gt.F{constructor(){super(...arguments),this.navIsSticky=!1,this.hideRefreshPill=!1,this.isFeedDisabled=!1,this.elementKey=Qt.u.gridViewFeed,this.enableInlinePivotViaCss=!1,this.enableInlinePivotViaCssScope=[],this.activeTab="Home",this.visitedFeeds=[],this.layout3InDiscover=!1,this.feedPadding=20,this.useLayout3=!1,this.initFeedManager=async()=>{var t;const{feedSource:e,layoutTemplateMap:o,importLayoutTemplateMap:i,getDefaultConfigWithOverrides:a,isFeedDisabled:n}=this,r=a(),{feedId:s,feedName:l}=(null===(t=r.riverSectionCardProviderConfig)||void 0===t?void 0:t.initialRequest)||{};l&&(this.feedName=l),r.enableFollowingFeed&&(this.isFollowingFeed="following"===this.feedName),(s||this.isFollowingFeed)&&(this.feedId=s),n&&(this.isFeedDisabled=n);const d={config:r,elementKey:this.elementKey,emptyFeedCallback:this.emptyFeedCallback,experienceId:this.getExperienceType(),feedId:this.feedId,feedName:this.feedName,feedSource:e,layoutTemplateMap:o,importLayoutTemplateMap:i,needsHydration:()=>(0,Dt.S)()&&this.hasAttribute("needs-hydration"),regionKeys:["hero","river","overlay"],riverChangedCallback:this.riverChangedCallback,useProviderKey:this.useProviderKey,superFeedWce:this,shouldDisableFeedRedHandles:!!this.shouldDisableFeedRedHandles};(0,Vt.jU)("navBar",t=>{this.isTranslucent="translucentBackground"===t}),await this.feedManager.init(d)},this.getLayout=t=>{if(this.customGetLayout)return this.customGetLayout(t);if(this.customGetLayoutCallback){const e=this.customGetLayoutCallback(t);if(e)return e}return t===zt.j1.c1?this.config.enableOneColumn?Jt._4.C1:Jt._4.C2:Jt._4[t.toUpperCase()]},this.shouldShowPlaceholderSection=()=>!(!this.config.enableGreyBlock||!this.feedManager.hasCardsInLastResponse),this.refreshFeedForChannelFilter=(0,ae.A)(()=>{this.feedManager.callRefreshRegionsData({invalidateCache:!1,scrollToTop:!1,isFromChannelFilter:!0},!0).catch(()=>{})},500,{leading:!0,trailing:!1}),this.refresh=()=>{this.feedManager.callRefreshRegionsData({invalidateCache:!0,scrollToTop:!0},!0).catch(()=>{}),(0,Wt.i6)(Mt.jCw)}}async feedConnected(){var t,e,o;const i=(0,Bt.iA)();if(this.hideRefreshPill=!!i&&Ht.T3.IsHeroNTP&&i.includes("segment=Weather"),(0,Dt.S)()){let t=Ht.T3.IsChinaCompliance?"https://srtb.msn.cn/":null;!Ht.T3.IsChinaCompliance&&_t.Rb.CurrentFlightSet.has("prg-ads-ipv6dmn")&&(t="https://srtb-ax.msn.com/"),(0,Lt.$)(t||"https://srtb.msn.com",!0,null!=t)}const{config:a}=this;if(a.addXandrScript&&(0,Dt.S)()){const t=document.createElement("script");t.setAttribute("src",`${(0,Ht.rA)().StaticsUrl}/latest/js/thirdparty/xandr/trk.js`),document.head.appendChild(t)}var n,r,s;this.overrideGapStyles=Xt([Nt],a),te.G.updateLayout.registerObserver(()=>{this.overrideGapStyles=Xt([Nt],a)}),this.config.useMobile&&(this.overrideLayoutStyles=Tt(this.feedManager.displaySettings,a.enableDynamicHeightCard),this.feedManager.addDisplaySettingsChangedCallback(()=>{this.superContainerLoader.init({...this.initOptions,overrideStyles:Tt(this.feedManager.displaySettings,a.enableDynamicHeightCard)})}),this.feedManager.logTrace("GridViewFeedConnected")),this.feedManager.appendFeedStyleArgs({layoutGap:(n=a.layoutGap,r=a.consumeVerticalTab,s=a.reverseLayoutGap,!s&&n&&Ot(n)&&(!r||r&&It())?a.layoutGap:void 0)});let l=2;const d=null===(t=(0,Et.zP)(St.h$))||void 0===t?void 0:t.getCurrentState();d&&ee.YT.addOrUpdateTmplProperty("FEED_DISPLAY_SETTING",d.selectedFeedDisplaySetting),"peek"===(null==d?void 0:d.selectedFeedDisplaySetting)&&(l=1),void 0!==this.config.overrideRowCountForTtvr&&(l=this.config.overrideRowCountForTtvr),void 0!==this.feedManager.overrideRowCountForTtvr&&(l=this.feedManager.overrideRowCountForTtvr),this.feedManager.updateTtvrSpaceTotal((0,qt.r8)(l,this.getLayout((0,Ft.TU)().currentColumnArrangement))),this.config.enableGlobalMonitor&&this.feedManager.setTtvrRows(l),null!==(e=this.config)&&void 0!==e&&e.enableFeedRefreshWhenOnline&&window.addEventListener("online",this.feedManager.handleOnlineTransition),window.addEventListener("refreshOnChannelStore",this.refresh),this.config.enableRefreshFeedFromChFltr&&this.isFollowingFeed&&window.addEventListener("refreshOnChannelFilter",this.refreshFeedForChannelFilter),null!==(o=this.config.childExperienceReferencesWC)&&void 0!==o&&o.watchWC&&this.enableInlinePivotViaCssScope.push("Video");const c=At.vv.get("__DelayNtpSSRFeedDuration__");c&&((0,oe.E)(),await new Promise(t=>globalThis.setTimeout(t,c)))}shadowDomPopulated(){if(super.shadowDomPopulated(),(0,Yt.KO)(this.elementKey,this),this.config.riverSectionCardProviderConfig&&this.config.riverSectionCardProviderConfig.initialRequest){const t=this.config.riverSectionCardProviderConfig.initialRequest;t&&"gaming"===t.feedName&&t.useXboxAccessToken&&window.setTimeout(async()=>{const{setXboxTitleHubData:t}=await o.e("EsportsDataService").then(o.bind(o,9677));await t()},1e3)}}disconnectedCallback(){var t;(0,Dt.S)()&&!this.isConnected||(super.disconnectedCallback(),null!==(t=this.config)&&void 0!==t&&t.enableFeedRefreshWhenOnline&&window.removeEventListener("online",this.feedManager.handleOnlineTransition),window.removeEventListener("refreshOnChannelStore",this.refresh),this.config.enableRefreshFeedFromChFltr&&this.isFollowingFeed&&window.removeEventListener("refreshOnChannelFilter",this.refreshFeedForChannelFilter))}getExperienceType(){return Mt.jCw}async prerenderRefreshCritical(){const t=this.feedManager,e=(0,ie.ZF)(),o=performance.now();if(t.isFeedStaleWithPartialResponse())return e.prerenderRefreshCritical=Math.round(performance.now()-o),t.updateStaledPartialFeed();if(t.isPrerenderFeedCallDisabled())return e.prerenderRefreshCritical=Math.round(performance.now()-o),t.updateDisabledPrerenderFeed();this.config.unblockAdsEarly&&t.unblockAdsOnPrerenderedFeed();const i=t.isFeedStaleWithThresholdReached(),a=t.isSDCardsStaleWithThresholdReached(),n=!(!this.config.invalidatePrerenderRiverOnActions||!(0,Wt.PP)(Mt.jCw));n&&ee.YT.addOrUpdateTmplProperty("gvfinv","1"),i&&ee.YT.addOrUpdateTmplProperty("staleriver","1");const r=()=>{t.refreshSDCard().catch(()=>{})};if(!this.config.forceRefreshForStalePrerender&&!n&&(i||a))return i&&!this.config.unblockAdsEarly&&t.unblockAdsOnPrerenderedFeed(),this.config.refreshPrerenderSdCardsOnly&&a&&(0,Kt.GP)().then(()=>{r()},()=>{}),(0,Kt.GP)().then(()=>this.setRefreshPillRender(this.config.refreshPillRenderDelayInMs)).catch(()=>{}),void(e.prerenderRefreshCritical=Math.round(performance.now()-o));if(i||n||!this.config.unlockAdsPrerender||(this.config.delayRiverPrerenderAds&&(this.containerClass="hidden",window.setTimeout(async()=>{this.containerClass=""},this.config.delayRiverPrerenderAds)),t.unblockAdsOnPrerenderedFeed()),i||n){const i=t.callRefreshRegionsData();return this.containerClass="hidden",i.finally(()=>{this.containerClass="",this.config.unblockAdsEarly||t.unblockAdsOnPrerenderedFeed()}),e.prerenderRefreshCritical=Math.round(performance.now()-o),t.getPageRevalidateResultAsync()}a&&(this.config.unblockAdsEarly||t.unblockAdsOnPrerenderedFeed(),(0,Kt.GP)().then(()=>{r()},()=>{})),e.prerenderRefreshCritical=Math.round(performance.now()-o)}}(0,m.Cg)([b.sH],ne.prototype,"navigateToURLCallback",void 0),(0,m.Cg)([b.sH],ne.prototype,"emptyFeedCallback",void 0),(0,m.Cg)([b.sH],ne.prototype,"riverChangedCallback",void 0),(0,m.Cg)([b.sH],ne.prototype,"customGetLayout",void 0),(0,m.Cg)([b.sH],ne.prototype,"customGetLayoutCallback",void 0),(0,m.Cg)([b.sH],ne.prototype,"isDarkModeForMobile",void 0),(0,m.Cg)([b.sH],ne.prototype,"containerClass",void 0),(0,m.Cg)([b.sH],ne.prototype,"displayFeedLevelFeedback",void 0),(0,m.Cg)([b.sH],ne.prototype,"isDarkMode",void 0),(0,m.Cg)([b.sH],ne.prototype,"isTranslucent",void 0),(0,m.Cg)([b.sH],ne.prototype,"feedManager",void 0),(0,m.Cg)([b.sH],ne.prototype,"hideRefreshPill",void 0),(0,m.Cg)([b.sH],ne.prototype,"isFeedDisabled",void 0),(0,m.Cg)([b.sH],ne.prototype,"enableInlinePivotViaCss",void 0),(0,m.Cg)([b.sH],ne.prototype,"enableInlinePivotViaCssScope",void 0),(0,m.Cg)([b.sH],ne.prototype,"activeTab",void 0),(0,m.Cg)([b.sH],ne.prototype,"visitedFeeds",void 0),(0,m.Cg)([b.sH],ne.prototype,"scrollToTop",void 0),(0,m.Cg)([b.sH],ne.prototype,"layout3InDiscover",void 0),(0,m.Cg)([b.sH],ne.prototype,"feedPadding",void 0),(0,m.Cg)([b.sH],ne.prototype,"isHeroShownOnHeader",void 0),(0,m.Cg)([b.sH],ne.prototype,"useLayout3",void 0);const re=G.A`
.fallback-vertical-card{background-color:#4a4a4a}`,se=G.A`
.grid-view-feed-root{color:${Z.l};margin:0 auto;position:relative}.layout3{--card-height:304px}.enhanced-fallback-title{font-size:20px;font-weight:600;margin-bottom:32px}.fallback-vertical-card-container{display:flex;gap:12px;margin-bottom:36px}.fallback-vertical-image{border-radius:6px}.fallback-vertical-image-container{display:flex;height:84px;margin-top:-10px;width:84px}.fallback-vertical-text{display:block;font-size:12px;font-weight:600;max-width:84px;overflow:hidden;padding-top:12px;text-overflow:ellipsis}.fallback-vertical-card{background-color:#ffffff;box-shadow:0px 2px 4px rgba(0,0,0,0.1);height:142px;width:106px}.feed{display:grid;flex-flow:row wrap;gap:12px;justify-items:center;justify-content:center;--layer-corner-radius:6;margin-bottom:33px}.feed-aside{justify-content:flex-end}.feed-disable{display:none}.river-sentinel{position:absolute;bottom:0;left:0;right:0;z-index:-1}.zoom-container{display:grid;flex-flow:row wrap;gap:12px;justify-content:center;--layer-corner-radius:6}.heading-group-error{align-items:center;display:flex;flex-direction:column;margin-top:10vh;text-align:center}.heading-group-error.vertical{margin-top:80px}.heading-group-error.translucent-white{color:#f5f5f5}.isMobile .heading-group-error-icon{font-family:'SF Pro Display';font-style:normal;font-weight:600;font-size:60px;line-height:24px;margin-top:1vh;margin-bottom:2vh}.subheading-error{margin-bottom:10px}.subheading-error.vertical{font-size:14px}.subheading-error.vertical{margin-bottom:32px}.isMobile h2{font-size:18px}.isMobile .subheading-error{font-size:15px;max-width:80vw}.isMobile .refresh-button{border-radius:100px;margin-top:15px;padding:2px;line-height:100%}.loading-placeholder{padding:8px 0 12px;font-size:16px;font-weight:600;color:var(--neutral-foreground-rest);text-align:center}.hidden{display:none}.hero-section{padding-bottom:15px}.refresh-button-icon{width:14px;height:14px;display:inline-block}${(0,zt.H5)(zt.j1.c1)}{.fallback-vertical-card-container{flex-wrap:wrap;justify-content:center}}`.withBehaviors((0,E.G2)(re));var le=o(64240),de=o(54205),ce=o(81678),pe=o(73182),ue=o(60222),he=o(65055);pe.MsnActionsMenu,ue.U;const ge=y.qy` ${t=>{var e;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.cardAction)&&(0,he.yN)(t.config.childExperienceReferencesWC.cardAction,{properties:{useEnhancedToastMessages:t.config.useEnhancedToastMessages}})}}
`,ve=t=>{var e;const o=t.config.useMobile&&t.feedManager.disableCardActionAndToast,i=t.feedManager.disableToast;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.toastWC)&&!(o||i)},fe=y.qy` ${t=>{var e,o;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.toastWC)&&(0,he.yN)(null===(o=t.config.childExperienceReferencesWC)||void 0===o?void 0:o.toastWC,{properties:{useEnhancedToastMessages:t.config.useEnhancedToastMessages}})}}
`,me=y.qy` ${t=>{var e,o,i;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.superBreakingNews)&&(0,he.yN)(null===(o=t.config.childExperienceReferencesWC)||void 0===o?void 0:o.superBreakingNews,{attributes:{style:`display: grid; justify-items: center; --feed-width: ${null===(i=t.feedManager)||void 0===i||null===(i=i.displaySettings)||void 0===i?void 0:i.feedWidth}; margin-top: calc(var(--card-base-gap) * 1px); margin-bottom: 0px;`},properties:{noWrapForHeadline:!(t.config.useMobile&&!t.config.isMsnMobile),isMobile:t.config.useMobile&&!t.config.isMsnMobile,navigateToURLCallback:t.navigateToURLCallback,isDarkModeForMobile:t.isDarkModeForMobile}})}}
`,$e=y.qy`<div class="interest-fre-overlay-container">${t=>{var e,o;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.interestFREOverlay)&&(0,he.yN)(null===(o=t.config.childExperienceReferencesWC)||void 0===o?void 0:o.interestFREOverlay,{properties:{isFollowingFeed:t.isFollowingFeed,refreshCallback(){return t.feedManager.callRefreshRegionsData({invalidateCache:!0,scrollToTop:!0})},metadata:t.feedManager.extractFollowingFREData(t.feedManager.overlay)}})}}</div>`,xe=y.qy`<div class="signal-overlay-container">${t=>{var e,o;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.signalOverlay)&&(0,he.yN)(null===(o=t.config.childExperienceReferencesWC)||void 0===o?void 0:o.signalOverlay,{properties:{refreshCallback(){return t.feedManager.callRefreshRegionsData({invalidateCache:!0,scrollToTop:!0})},metadata:t.feedManager.extractFollowingFREData(t.feedManager.overlay)}})}}</div>`,be=y.qy`<div class="following-fre-confirmation">${t=>{var e,o;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.followingFreConfirmation)&&(0,he.yN)(null===(o=t.config.childExperienceReferencesWC)||void 0===o?void 0:o.followingFreConfirmation)}}</div>`,ye=y.qy`<msn-actions-menu :menuItems=${t=>{var e;return null===(e=t.feedManager.sdCardMenuProps)||void 0===e?void 0:e.menuItems}} :referrerButton=${t=>{var e;return null===(e=t.feedManager.sdCardMenuProps)||void 0===e?void 0:e.referrerButton}} :useFastAnchoredRegion=${t=>!1} @dismiss-menu=${t=>t.feedManager.sdCardMenuOpen=!1} ${(0,et.K)("sdCardMenuRef")}></msn-actions-menu>`,we=y.qy`<cs-feed-layout layout="${(t,e)=>e.parent.feedManager.layout}" :data="${t=>t.feedData}" :childTemplateMap="${(t,e)=>e.parent.feedManager.cardTemplateMap}" :layoutStyles="${(t,e)=>{var o;return null===(o=e.parent.feedManager.getLayoutTemplate(t.templateId))||void 0===o?void 0:o.styles}}" style="${(t,e)=>{var o,i,a;return e.parent.overrideGapStyles+(i=null===(o=t.cardMetadataList)||void 0===o||null===(o=o[0])||void 0===o?void 0:o.type,a=e.parent.config,Xt([Rt(i)],a))}}"></cs-feed-layout>`,ke=y.qy` ${(0,X.ux)(t=>t.feedManager.river,we)}
`,Ce=y.qy`<msn-dot-loading></msn-dot-loading>`,ze=y.qy`<div class="loading-placeholder" data-t="${t=>{var e,o;return null===(e=t.feedManager)||void 0===e||null===(e=e.loadingPlaceholderTelemetry)||void 0===e||null===(o=e.getMetadataTag)||void 0===o?void 0:o.call(e)}}">${(0,w.z)(t=>"dot"===t.config.loadingPlaceholderType,Ce)}</div>`,Fe=y.qy`<div slot="${t=>t.config.enableGreyBlock&&t.config.enableFeedSuperCards?"sentinel":null}" ${(0,et.K)("riverSentinel")} id="river-sentinel" class="river-sentinel" style="height: ${t=>t.riverSentinelHeight}px;"></div>`,Me=y.qy`<cs-super-container :layout="${t=>t.feedManager.layout}" :feedLayouts="${t=>t.feedManager.hero}" :onFeedLayoutElementsChanged="${t=>t.feedManager.onHeroFeedLayoutElementsChanged}" class="hero-section ${t=>t.containerClass}" data-t="${t=>{var e;return null===(e=t.feedManager.heroTelemetry)||void 0===e?void 0:e.getMetadataTag()}}"></cs-super-container>`,Se=y.qy` ${t=>{var e,o;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.heroContainerWC)&&(0,he.yN)(null===(o=t.config.childExperienceReferencesWC)||void 0===o?void 0:o.heroContainerWC,{properties:{layout:t.feedManager.layout,feedLayouts:t.feedManager.river.slice(0,1),onFeedLayoutElementsChanged:t.feedManager.onHeroFeedLayoutElementsChanged}})}}
`,Te=y.qy`<cs-super-container class="${t=>t.containerClass}" :feedLayouts="${t=>t.feedManager.foundTopSectionInRiver?t.feedManager.river.slice(1):t.feedManager.river}" :layout="${t=>t.feedManager.layout}" :onFeedLayoutElementsChanged="${t=>t.feedManager.onFeedLayoutElementsChanged}" :placeholderFeedLayout="${t=>t.shouldShowPlaceholderSection()?t.feedManager.riverPlaceholderData:void 0}" :responsiveFeedLayouts="${t=>t.feedManager.waterfall}">${(0,w.z)(t=>t.config.enableGreyBlock,Fe)}</cs-super-container>`,Pe=y.qy`<cs-super-container class="${t=>t.containerClass}" :feedLayouts="${t=>t.feedManager.foundTopSectionInRiver?t.feedManager.river.slice(1):t.feedManager.river}" :layout="${t=>t.feedManager.layout}" :onFeedLayoutElementsChanged="${t=>t.feedManager.onFeedLayoutElementsChanged}" :placeholderFeedLayout="${t=>t.shouldShowPlaceholderSection()?t.feedManager.riverPlaceholderData:void 0}">${(0,w.z)(t=>t.config.enableGreyBlock,Fe)}</cs-super-container>`,qe=y.qy`<div role="main" class="grid-view-feed-root ${t=>t.feedManager.layout3InDiscover||t.useLayout3?"layout3":""}" data-t="${t=>{var e;return null===(e=t.telemetryObject)||void 0===e?void 0:e.getMetadataTag()}}">${(0,w.z)(t=>!t.hideRefreshPill,ce.Bt)}<div class="feed" data-t="${t=>{var e;return null===(e=t.feedManager.riverTelemetry)||void 0===e?void 0:e.getMetadataTag()}}" style="${t=>t.overrideGapStyles}" ${(0,et.K)("riverFeedElement")}>${(0,w.z)(t=>{var e;return!t.isHeroShownOnHeader&&(null===(e=t.feedManager.hero)||void 0===e||null===(e=e[0])||void 0===e?void 0:e.feedData)},Me)} ${(0,w.z)(t=>{var e;return!t.isHeroShownOnHeader&&t.feedManager.foundTopSectionInRiver&&(null===(e=t.feedManager.river)||void 0===e||null===(e=e[0])||void 0===e?void 0:e.feedData)&&t.config.enableHeroContainer},Se)} ${(0,w.z)(t=>{var e;return t.config.enableBreakingNews&&(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.superBreakingNews)&&t.config.useMobile&&!t.config.isMsnMobile},me)} ${(0,w.z)(t=>t.feedManager.showFREConfirmation,be)} ${(0,w.z)(t=>!t.config.enableFeedSuperCards,ke)} ${(0,w.z)(t=>t.config.enableFeedSuperCards&&(!0===t.feedManager.layout3InDiscover||t.useLayout3),Te)} ${(0,w.z)(t=>t.config.enableFeedSuperCards&&!0!==t.feedManager.layout3InDiscover&&!t.useLayout3,Pe)} ${(0,w.z)(t=>t.shouldShowPlaceholderSection()||t.config.showLoadingPlaceholder&&t.feedManager.isUpdateRegionsDataLoading,ze)}</div>${(0,w.z)(t=>!t.config.enableGreyBlock||!t.config.enableFeedSuperCards,Fe)} ${(0,w.z)(ve,fe)}</div>`,De=y.qy`
${t=>(0,he.yN)({instanceId:"CasualGamesFeed"+t.feedManager.layout,configRef:{experienceType:"CasualGamesFeed",instanceSrc:"default"}},{properties:{layout:t.feedManager.layout,scrollToTop:t.scrollToTop,activeTab:t.activeTab}})}
`,Be=y.qy`
${t=>{var e;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.watchWC)&&(0,he.yN)(t.config.childExperienceReferencesWC.watchWC,{properties:{cardActionRef:t.cardActionRef,scrollToTop:t.scrollToTop}})}}
`,Ae=y.qy`
${t=>(0,he.yN)({instanceId:"ShoppingPivotFeed"+t.feedManager.layout,configRef:{experienceType:"ShoppingPivotFeed",instanceSrc:"default"}},{properties:{layout:t.feedManager.layout,scrollToTop:t.scrollToTop,activeTab:t.activeTab}})}
`,Ve=y.qy`<div class="${t=>"Play"!==t.activeTab?"hidden":""}">${De}</div>`,He=y.qy`<div class="${t=>"Video"!==t.activeTab?"hidden":""}">${Be}</div>`,_e=y.qy`<div class="${t=>"Shopping"!==t.activeTab?"hidden":""}">${Ae}</div>`,Le=y.qy`<div class="${t=>t.enableInlinePivotViaCssScope.includes(t.activeTab)?"hidden":""}">${qe}</div>${(0,w.z)(t=>"Play"==t.activeTab||t.visitedFeeds.includes("Play"),Ve)}
${(0,w.z)(t=>"Video"==t.activeTab||t.visitedFeeds.includes("Video"),He)}
${(0,w.z)(t=>"Shopping"==t.activeTab,_e)}
`,Ge=y.qy`
${(0,w.z)(t=>t.feedManager.sdCardMenuOpen,ye)}
`,je=y.qy`
${t=>t.enableInlinePivotViaCss?Le:qe}
${(0,w.z)(t=>{var e,o;return(null===(e=t.feedManager.overlay)||void 0===e?void 0:e[0])&&(null===(o=t.config.childExperienceReferencesWC)||void 0===o?void 0:o.interestFREOverlay)},$e)}
${(0,w.z)(t=>{var e,o;return(null===(e=t.feedManager.overlay)||void 0===e?void 0:e[0])&&(null===(o=t.config.childExperienceReferencesWC)||void 0===o?void 0:o.signalOverlay)},xe)}
${(0,w.z)(t=>{var e;return(null===(e=t.config.childExperienceReferencesWC)||void 0===e?void 0:e.cardAction)&&!(t.config.useMobile&&t.feedManager.disableCardActionAndToast)},ge)}
${Ge}
`,Ee=y.qy`
${(0,w.z)(t=>t.feedManager.fallbackFeed&&!t.isFollowingFeed,t=>(t=>(t.config.useMobile?de.vK:de.N0)({fallbackFeed:t.feedManager.fallbackFeed},t.isTranslucent))(t))}
${le.aR}
${le.Dd}
${(0,w.z)(t=>!t.feedManager.fallbackFeed,je)}
`,Ie=y.qy`<div>${(0,w.z)(ve,fe)} ${Ge}</div>`,Oe=y.qy`
${t=>t.isFeedDisabled?Ie:Ee}
`,Ze={experienceConfigSchema:undefined};i.m.define(a.c.registry),n.m.define(a.c.registry),r.m.define(a.c.registry),s.m.define(a.c.registry),l.m.define(a.c.registry),d.m.define(a.c.registry),c.m.define(a.c.registry),p.m.define(a.c.registry),kt.m.define(u.G.registry),h.Af.define(g.i.registry),v.yr.define(g.i.registry),f.rX.define(g.i.registry),Q.define(g.i.registry),Y.Bb.define(g.i.registry),J.K7.define(g.i.registry),wt.define(g.i.registry),Ct.BD.define(u.G.registry)},37256(t,e,o){o.d(e,{R(){return p}});var i=o(64187),a=o(22131),n=o(74849),r=o(50882),s=o(37998),l=o(57416),d=o(95239),c=o(48751);const p=n.A`
    ${(0,i.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${d.p};
        color: ${c.l};
        border-radius: calc(${l.JU} * 1px);
        ${s.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,a.mr)(n.A`
            :host {
                forced-color-adjust: none;
                background: ${r.A.Canvas};
                box-shadow: 0 0 0 1px ${r.A.CanvasText};
            }
        `))},38380(t,e,o){o.d(e,{v(){return i}});const i=(0,o(25717).T)()},42767(t,e,o){o.d(e,{K7(){return w}});var i=o(99900),a=o(56911),n=o(92011),r=o(38493),s=o(60815);class l extends n.L{constructor(){super(...arguments),this.pinned=!1}}(0,a.Cg)([r.CF],l.prototype,"target",void 0),(0,a.Cg)([(0,r.CF)({mode:"boolean"})],l.prototype,"pinned",void 0),(0,a.Cg)([s.sH],l.prototype,"data",void 0),(0,a.Cg)([s.sH],l.prototype,"headerTelemetryTag",void 0),(0,a.Cg)([s.sH],l.prototype,"seeMoreTelemetryTag",void 0);var d=o(64187),c=o(73477),p=o(22131),u=o(74849),h=o(50882),g=o(7896),v=o(48751),f=o(61138),m=o(45476);const $=u.A`
    ${(0,d.V)("grid")}:host{position:relative;width:auto;height:100%;box-sizing:border-box;font-family:${g.O};grid-template-rows:auto 1fr auto;padding:var(--content-padding,16px 0);outline:none}:host([pinned]){padding:var(--content-padding,0 16px 16px 16px)}:host([pinned]) .title-link{cursor:pointer}:host([pinned]) .title{cursor:var(--cursor-styles);padding:var(--title-padding,16px 0 0)}.footer{display:grid;grid-template-columns:1fr auto 1fr;padding:var(--footer-padding,0 16px)}.title{overflow:hidden;display:grid;grid-template-columns:1fr auto auto;grid-gap:8px;padding:var(--title-padding,0 16px);overflow:visible;align-items:center}.title-link{display:grid;grid-template-columns:auto 1fr;grid-gap:8px;color:${v.l};
        font-size: ${f.k};
        justify-content: flex-start;
        line-height: ${f.F};
        outline: none;
        cursor: pointer;
        text-decoration: none;
        margin-inline-end: auto;
    }

    .title-link:hover,
    .title-link:active,
    .title-link:${c.N}{text-decoration:underline}.title-link:${c.N} > .title-content{text-decoration:underline}.title-content{font-size:${f.k};
        line-height: ${f.F};margin-top:4px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;-webkit-line-clamp:var(--title-max-lines,1)}::slotted([slot="title-icon"]){margin-top:4px}.sd-action{--control-corner-radius:16;grid-column:2;z-index:1}.sd-action:not([appearance="lightweight"]){font-size:${f.k};
        line-height: ${f.F}}.sd-action::part(control){width:100%;padding:var(--sd-action-padding,0px 24px)}.sd-action::part(content){-webkit-box-orient:vertical;-webkit-line-clamp:1;text-overflow:ellipsis;overflow:hidden}::slotted([slot="more-actions"]){min-width:var(--more-actions-size,24px);width:var(--more-actions-size,24px);height:var(--more-actions-size,24px);--control-corner-radius:var(--more-actions-corner-radius,16);z-index:1;grid-column:3;background-color:transparent}::slotted([slot="more-actions"]:hover){background-color:${m.oO}}::slotted([slot="more-actions"]:active){background-color:${m.wO}}::slotted([slot="pin"]){fill:${v.l};
        margin-inline-end: 6px;
    }
`.withBehaviors((0,p.mr)(u.A` .title-link{color:${h.A.CanvasText}}a[href]{color:${h.A.LinkText};
                }
            `));var x=o(96950),b=o(69259);const y=x.qy`<div class="title" part="title" role="heading" aria-level="2">${(0,b.z)(t=>{var e;return null==t||null===(e=t.data)||void 0===e?void 0:e.titleContent},x.qy`<a class="title-link" part="title-link" href="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.link}}" target=${t=>t.target} title="${t=>{var e,o;return(null===(e=t.data)||void 0===e?void 0:e.titleContentHint)??(null===(o=t.data)||void 0===o?void 0:o.titleContent)}}" data-t="${t=>t.headerTelemetryTag}"><slot name="title-icon"></slot><div class="title-content" part="title-content">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.titleContent}}</div><slot name="weather-pen-btn"></slot><slot name="weather-map-btn"></slot></a>`)}<slot name="pin"></slot><slot name="more-actions"></slot></div><slot></slot><div class="footer" part="footer"><slot name="footer-start"></slot>${(0,b.z)(t=>{var e;return null==t||null===(e=t.data)||void 0===e?void 0:e.footerContent},x.qy`<fluent-anchor class="sd-action" part="sd-action" appearance="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.actionAppearance}}" href="${t=>{var e,o,i;return null!==(e=t.data)&&void 0!==e&&e.footerLink?null===(o=t.data)||void 0===o?void 0:o.footerLink:null===(i=t.data)||void 0===i?void 0:i.link}}" target=${t=>t.target} data-t="${t=>t.seeMoreTelemetryTag}">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.footerContent}}</fluent-anchor>`)}<slot name="footer-end"></slot></div>`,w=l.compose({name:`${i.i.prefix}-structured-data-card`,template:y,styles:$})},43774(t,e,o){o.d(e,{p4(){return v},ls(){return f},vA(){return g},nF(){return h}});var i=o(45755),a=o(68009),n=o(95239);const{create:r}=i.G,s=r("neutral-stroke-strong-hover-delta",40),l=r("neutral-stroke-strong-active-delta",16),d=r("neutral-stroke-strong-focus-delta",25);var c=o(31023);const{create:p}=i.G,u=p({name:"neutral-stroke-strong-recipe"},{evaluate(t){return function(t,e,o,i,n,r){const s=(0,a.F)(e),l=t.colorContrast(e,o),d=t.closestIndexOf(l);return{rest:l,hover:t.get(d+s*i),active:t.get(d+s*n),focus:t.get(d+s*r)}}(t(c.r),t(n.p),3,t(s),t(l),t(d))}}),h=p("neutral-stroke-strong-rest",t=>t(u).evaluate(t).rest),g=p("neutral-stroke-strong-hover",t=>t(u).evaluate(t).hover),v=p("neutral-stroke-strong-active",t=>t(u).evaluate(t).active),f=p("neutral-stroke-strong-focus",t=>t(u).evaluate(t).focus)},45899(t,e,o){o.d(e,{m(){return h}});var i=o(37180),a=o(56911),n=o(7511),r=o(38493);class s extends n._{appearanceChanged(t,e){t!==e&&(this.classList.add(e),this.classList.remove(t))}connectedCallback(){super.connectedCallback(),this.appearance||(this.appearance="neutral")}defaultSlottedContentChanged(){const t=this.defaultSlottedContent.filter(t=>t.nodeType===Node.ELEMENT_NODE);1===t.length&&t[0]instanceof SVGElement?this.control.classList.add("icon-only"):this.control.classList.remove("icon-only")}}(0,a.Cg)([r.CF,(0,a.Sn)("design:type",String)],s.prototype,"appearance",void 0);var l=o(74849),d=o(25984),c=o(17767);const p=l.A`
    ${d._9}
`.withBehaviors((0,c.f)("accent",d.Vw),(0,c.f)("hypertext",d.aY),(0,c.f)("lightweight",d.ZI),(0,c.f)("outline",d.LA),(0,c.f)("stealth",d.ss)),u=(0,o(29995).M)(),h=s.compose({name:`${i.c.prefix}-anchor`,template:u,styles:p,shadowOptions:{delegatesFocus:!0}})},54205(t,e,o){o.d(e,{N0(){return p},NQ(){return l},vK(){return c}});var i=o(66591),a=o(96950),n=o(69259),r=o(39957),s=o(58792);const l=t=>{if(null==t||!t.fallbackFeed)return null;const{fallbackFeed:e,isTranslucent:o,isCopilotTheme:s}=t,l="refreshButton"in e&&e.refreshButton||"managePublisherButton"in e&&e.managePublisherButton;return a.qy`
        <div class=${()=>(0,i.x)("heading-group-error",["translucent-white",o],["vertical",null==e?void 0:e.isEnhancedVerticalsFallbackFeed],["copilot-theme",s])}>
            ${(0,n.z)(()=>!e.isEnhancedVerticalsFallbackFeed,a.qy`
                <h2>${e.title||""}</h2>
            `)}
            ${(0,n.z)(()=>e.isEnhancedVerticalsFallbackFeed,a.qy`
                <span class=${()=>(0,i.x)("enhanced-fallback-title",["vertical",null==e?void 0:e.isEnhancedVerticalsFallbackFeed],["copilot-theme",s])}>
                    ${e.title||""}
                </span>
            `)}
            ${(0,n.z)(()=>e.subTitle,a.qy`
                <div class=${()=>(0,i.x)("subheading-error",["vertical",null==e?void 0:e.isEnhancedVerticalsFallbackFeed],["copilot-theme",s])}>
                    <span>${e.subTitle}</span>
                </div>
            `)}
            ${(0,n.z)(()=>{var t;return e.isEnhancedVerticalsFallbackFeed&&(null===(t=e.emptyFallbackFeedCardsMetadata)||void 0===t?void 0:t.length)},a.qy`
                <div class="fallback-vertical-card-container">
                ${(0,r.ux)(()=>e.emptyFallbackFeedCardsMetadata||[],a.qy`
                    <fluent-anchor
                        class="fallback-vertical-card"
                        data-t="${t=>{var e,o;return(null==t||null===(e=t.telemetryObject)||void 0===e||null===(o=e.getMetadataTag)||void 0===o?void 0:o.call(e))||""}}"
                        href=${t=>(null==t?void 0:t.pageUrl)||"#"}
                        target=_blank
                    >
                    <span class="fallback-vertical-image-container">
                        <img class="fallback-vertical-image" src="${t=>(null==t?void 0:t.imageUrl)||""}" alt="">
                    </span>
                    <span class="fallback-vertical-text">
                        ${t=>(null==t?void 0:t.title)||""}
                    </span>
                    </fluent-anchor>
                `)}
                </div>
            `)}
            ${(0,n.z)(()=>l,a.qy`
                <fluent-button 
                    appearance=${()=>s?"stealth":"accent"}
                    class=${()=>(0,i.x)("refresh-button",["copilot-theme",s])}
                    data-t="${()=>{var t,e;return(null==l||null===(t=l.telemetryObject)||void 0===t||null===(e=t.getMetadataTag)||void 0===e?void 0:e.call(t))||""}}"
                    @click=${()=>{var t;return null==l||null===(t=l.onClick)||void 0===t?void 0:t.call(l)}}
                    @keypress=${()=>{var t;return null==l||null===(t=l.onClick)||void 0===t?void 0:t.call(l)}}
                >
                    ${()=>(null==l?void 0:l.title)||""}
                </fluent-button>
            `)}
        </div>`},d=a.qy`<h2 class="heading-group-error-icon">!</h2>`,c=(t,e)=>{var o;let{fallbackFeed:i}=t;return a.qy`
${(0,n.z)(()=>i,a.qy`
    <header class="heading-group-error isMobile">
        ${(0,n.z)(()=>e,function(t){let e;switch(t){case u.Offline:e=`${(0,s.rA)().StaticsUrl}latest/icons-wc/icons/Offline.svg`;break;case u.UnsupportedMarket:e=`${(0,s.rA)().StaticsUrl}latest/icons-wc/icons/RestrictedRegion.svg`;break;case u.FetchFailed:default:e=`${(0,s.rA)().StaticsUrl}latest/icons-wc/icons/Error.svg`}return a.qy`<img class="heading-group-error-icon" src="${e}" />`}(i.reason))}
        ${(0,n.z)(()=>!e,d)}
        <h2>${()=>i.title}</h2>
        ${(0,n.z)(()=>i.subTitle,a.qy`
            <p class="subheading-error">${i.subTitle}</p>
        `)}
        ${(0,n.z)(()=>i.refreshButton,a.qy`
            <fluent-button 
                appearance="accent"
                class="refresh-button"
                data-t="${()=>{var t,e;return(null===(t=i.refreshButton)||void 0===t?void 0:t.telemetryObject)&&(null===(e=i.refreshButton)||void 0===e?void 0:e.telemetryObject.getMetadataTag())}}"
                @click=${()=>{var t;return null===(t=i.refreshButton)||void 0===t?void 0:t.onClick()}}
                @keypress=${()=>{var t;return null===(t=i.refreshButton)||void 0===t?void 0:t.onClick()}}>
                    ${(0,n.z)(()=>i.reason!==u.BlockedPublishers,a.qy`
                        <img slot="start" class="refresh-button-icon" src="${(0,s.rA)().StaticsUrl}latest/icons-wc/RefreshIcon.svg"/>
                    `)}
                    ${null===(o=i.refreshButton)||void 0===o?void 0:o.title}
            </fluent-button>
        `)}
    </header>`)}`},p=(t,e,o)=>{let{fallbackFeed:i}=t;return l({fallbackFeed:i,isTranslucent:e,isCopilotTheme:o})};var u;!function(t){t[t.FetchFailed=0]="FetchFailed",t[t.UnsupportedMarket=1]="UnsupportedMarket",t[t.Offline=2]="Offline",t[t.BlockedPublishers=3]="BlockedPublishers"}(u||(u={}))},60143(t,e,o){o.d(e,{B(){return n}});var i=o(96950),a=o(18893);function n(t={}){const e={};return i.qy`
        <template
            role="button"
            aria-disabled="${t=>!!t.disabled||void 0}"
            tabindex="${t=>t.hiddenFromAT?-1:0}"
            @keyup="${(t,e)=>t.keyupHandler(e.event)}"
        >
            ${o=>function(t,o){let n=e[t];return n||(e[t]=n=i.qy`
                <span part="${t}" class="${t}">
                    <slot name="${t}">
                        ${(0,a.R)(o[t])}
                    </slot>
                </span>
            `),n}(o.direction,t)}
        </template>
    `}},60222(t,e,o){o.d(e,{U(){return d}});var i=o(56911),a=o(92011);class n extends a.L{}const r=o(96950).qy`<div class="snippet"><div class="stage"><div class="dot-elastic"></div></div></div>`,s="#036ac4",l=o(74849).A`
.snippet{display:inline-block}@keyframes dot-elastic-before{0%{transform:scale(1,1)}25%{transform:scale(1,1.5)}50%{transform:scale(1,0.67)}75%{transform:scale(1,1)}100%{transform:scale(1,1)}}@keyframes dot-elastic{0%{transform:scale(1,1)}25%{transform:scale(1,1)}50%{transform:scale(1,1.5)}75%{transform:scale(1,1)}100%{transform:scale(1,1)}}@keyframes dot-elastic-after{0%{transform:scale(1,1)}25%{transform:scale(1,1)}50%{transform:scale(1,0.67)}75%{transform:scale(1,1.5)}100%{transform:scale(1,1)}}.dot-elastic{position:relative;width:10px;height:10px;border-radius:5px;background-color:${s};
    color: ${s};animation:dot-elastic 1s infinite linear}.dot-elastic:before,.dot-elastic:after{content:"";display:inline-block;position:absolute;top:0}.dot-elastic:before{left:-15px;width:10px;height:10px;border-radius:5px;background-color:${s};
    color: ${s};animation:dot-elastic-before 1s infinite linear}.dot-elastic:after{left:15px;width:10px;height:10px;border-radius:5px;background-color:${s};
    color: ${s};
    animation: dot-elastic-after 1s infinite linear;
}
`;let d=class extends n{};d=(0,i.Cg)([(0,a.E)({name:"msn-dot-loading",template:r,styles:l,shadowOptions:{delegatesFocus:!0}})],d)},64240(t,e,o){o.d(e,{$p(){return c},Dd(){return l},aR(){return s},sr(){return d}});var i=o(96950),a=o(69259),n=o(65055),r=o(72030);const s=i.qy`
    ${(0,a.z)(t=>t.config.childExperienceReferencesWC&&t.config.childExperienceReferencesWC.contextualFeedbackWC&&r.V.shouldDisplayFeedLevelCF,i.qy`${t=>(0,n.yN)(t.config.childExperienceReferencesWC.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{cFId:"00000",surveyTemplate:"feed-level",cardType:"feed-level"}})}`)}
`,l=i.qy`
    ${(0,a.z)(t=>t.config.childExperienceReferencesWC&&t.config.childExperienceReferencesWC.contextualFeedbackWC&&r.V.thumbnailCardData&&r.V.thumbnailCardTemplate&&r.V.isThumbnailCardInWhiteList(),i.qy`${t=>{var e,o,i;return(0,n.yN)(t.config.childExperienceReferencesWC.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{cFId:null===(e=r.V.thumbnailCardData)||void 0===e||null===(e=e.wpoMetadata)||void 0===e?void 0:e.cfId,cFMetadataType:null===(o=r.V.thumbnailCardData)||void 0===o?void 0:o.cFMetadataType,thumbnailCardData:r.V.thumbnailCardData,thumbnailCardTemplate:r.V.thumbnailCardTemplate,surveyTemplate:"thumbnail-popup",cardType:"thumbnail-popup",telemetryContent:null===(i=r.V.thumbnailCardData)||void 0===i||null===(i=i.telemetryContext)||void 0===i||null===(i=i.contentCard)||void 0===i||null===(i=i.contract)||void 0===i?void 0:i.content}})}}`)}
`,d=i.qy`
    ${(0,a.z)(t=>{var e;return t.contextualFeedbackData&&(null===(e=t.config)||void 0===e||null===(e=e.childRefs)||void 0===e?void 0:e.contextualFeedbackWC)},i.qy`${t=>{var e,o,i,a,r;return(0,n.yN)(null===(e=t.config)||void 0===e||null===(e=e.childRefs)||void 0===e?void 0:e.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{surveyTemplate:"opt-out",cFId:null===(o=t.contextualFeedbackData)||void 0===o?void 0:o.cFId,cFMetadataType:null===(i=t.contextualFeedbackData)||void 0===i?void 0:i.cFMetadataType,scenarioName:null===(a=t.contextualFeedbackData)||void 0===a?void 0:a.scenarioName,optOutActionCallback:null===(r=t.contextualFeedbackData)||void 0===r?void 0:r.optOutActionCallback,wideCardStyle:t.size&&!t.size.startsWith("_1x")&&!t.size.startsWith("_2x")&&!t.size.startsWith("1u"),cardType:t.cFId},attributes:{size:t.size}})}}`)}
`,c=i.qy`
    ${(0,a.z)(t=>{var e,o,i;return(null===(e=t.data)||void 0===e?void 0:e.contextualFeedbackData)&&(null===(o=t.config)||void 0===o||null===(o=o.childRefs)||void 0===o?void 0:o.contextualFeedbackWC)&&r.V.shouldDisplayCSAT(null===(i=t.data)||void 0===i||null===(i=i.contextualFeedbackData)||void 0===i?void 0:i.cFId)},i.qy`${t=>{var e,o,i;return(0,n.yN)(null===(e=t.config)||void 0===e||null===(e=e.childRefs)||void 0===e?void 0:e.contextualFeedbackWC,{includeTelemetryTag:!1,properties:{surveyTemplate:"default",cFId:null===(o=t.data)||void 0===o||null===(o=o.contextualFeedbackData)||void 0===o?void 0:o.cFId,cFMetadataType:null===(i=t.data)||void 0===i||null===(i=i.contextualFeedbackData)||void 0===i?void 0:i.cFMetadataType,wideCardStyle:t.size&&!t.size.startsWith("_1x")&&!t.size.startsWith("_2x")&&!t.size.startsWith("1u"),cardType:t.cFId},attributes:{size:t.size}})}}`)}
`},71608(t,e,o){o.d(e,{Af(){return m}});var i=o(92687),a=o(96950),n=o(60402);const r=a.qy`<span part="image" ${(0,n.K)("imageContainer")}><slot name="image" ${(0,n.K)("image")} @slotchange=${t=>t.handleImageContentChange()}></slot></span><span part="content" class="content"><slot></slot></span>`;var s=o(74849),l=o(64187),d=o(22131),c=o(7896),p=o(61138),u=o(64003),h=o(74838),g=o(50882);const v=s.A`
        ${(0,l.V)("inline-flex")} :host{box-sizing:border-box;font-family:${c.O};
            font-size: ${p.k};
            font-weight: 400;
            line-height: ${p.F};
            align-items: center;
            color: ${u.c};min-height:16px}.content{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.image{display:flex;margin-inline-end:calc(${h.vR} * 2px);
        }
    `.withBehaviors((0,d.mr)(s.A` :host,.content{color:${g.A.CanvasText};
                    fill: currentcolor;
                }
            `));var f=o(99900);const m=i.m.compose({name:`${f.i.prefix}-attribution`,template:r,styles:v})},72526(t,e,o){o.d(e,{L(){return g}});var i=o(56911),a=o(96193),n=o(47429),r=o(60815),s=o(22870),l=o(38493),d=o(95239),c=o(31023),p=o(24458),u=o(5291),h=o(57606);class g extends a.z{cardFillColorChanged(t,e){if(e){const t=(0,s.Hs)(e);null!==t&&(this.neutralPaletteSource=e,d.p.setValueFor(this,u.q.create(t.r,t.g,t.b)))}}neutralPaletteSourceChanged(t,e){if(e){const t=(0,s.Hs)(e),o=u.q.create(t.r,t.g,t.b);c.r.setValueFor(this,h.p.create(o))}}handleChange(t,e){this.cardFillColor||d.p.setValueFor(this,t=>t(p.M3).evaluate(t,t(d.p)))}connectedCallback(){super.connectedCallback();const t=(0,n.Zo)(this);if(t){const e=r.cP.getNotifier(t);e.subscribe(this,"fillColor"),e.subscribe(this,"neutralPalette"),this.handleChange(t,"fillColor")}}}(0,i.Cg)([(0,l.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,i.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,i.Cg)([(0,l.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,i.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0)},75003(t,e,o){o.d(e,{m(){return s}});var i=o(37180),a=o(72526),n=o(37256),r=o(38380);const s=a.L.compose({name:`${i.c.prefix}-card`,template:r.v,styles:n.R})},75261(t,e,o){o.d(e,{t(){return s}});var i=o(56911),a=o(60815),n=o(92011),r=o(38493);class s extends n.L{constructor(){super(...arguments),this.percentComplete=0}valueChanged(){this.updatePercentComplete()}minChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}maxChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}connectedCallback(){super.connectedCallback(),this.updatePercentComplete()}updatePercentComplete(){const t="number"==typeof this.min?this.min:0,e="number"==typeof this.max?this.max:100,o="number"==typeof this.value?this.value:0,i=e-t;this.percentComplete=0===i?0:Math.fround((o-t)/i*100)}}(0,i.Cg)([(0,r.CF)({converter:r.R$}),(0,i.Sn)("design:type",Object)],s.prototype,"value",void 0),(0,i.Cg)([(0,r.CF)({converter:r.R$}),(0,i.Sn)("design:type",Number)],s.prototype,"min",void 0),(0,i.Cg)([(0,r.CF)({converter:r.R$}),(0,i.Sn)("design:type",Number)],s.prototype,"max",void 0),(0,i.Cg)([(0,r.CF)({mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],s.prototype,"paused",void 0),(0,i.Cg)([a.sH,(0,i.Sn)("design:type",Number)],s.prototype,"percentComplete",void 0)},75307(t,e,o){o.d(e,{Bl(){return u},Eo(){return d},KN(){return l},LG(){return c},Mj(){return h},kg(){return s},x8(){return p}});var i=o(58792),a=o(99476),n=o(26363),r=o(77367);function s(){const t=(0,a.a)();return!!t&&("1"===t.get("vptest")||"true"===t.get("vptest")||"vp"===t.get("reqsrc"))}function l(t,e){return d(t,e,"shopping/product-tracking")}function d(t,e,o){if("local"===e&&window.location.origin.indexOf("localhost")>-1)return`http://127.0.0.1:3000/shopping/${t}.svg`;if(t){const a=e?`pr-${e}`:"latest",n=o?`${o}`:"shopping";return`${(0,i.rA)().StaticsUrl}${a}/${n}/${t}.svg`}return""}function c(t){return t&&t.href&&(t.href=p(t.href)),!0}function p(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;const o=(new Date).getTime()+e,i=(0,n.G)(),a=new URL(t);return a.searchParams.set("ts",o.toString()),a.searchParams.set("m_clk",`sid-${i}`),a.toString()}function u(t){return!!t&&/p4psearch\.1688\.com/.test(t)}function h(t,e){if(t&&t.href){const o=new URL(t.href);o.searchParams.set("m_ac","176674350"),o.searchParams.set("PageId",r.YT.getRequestId()),o.searchParams.set("ct",e),t.href=p(o.toString())}return!0}},81678(t,e,o){o.d(e,{Bt(){return s}});var i=o(96950),a=o(65055);const n=t=>{var e;return Boolean(null==t||null===(e=t.config)||void 0===e||null===(e=e.childExperienceReferencesWC)||void 0===e?void 0:e.pillWC)};function r(t){return null!=t&&t.pillClickCallback&&"function"==typeof t.pillClickCallback?t.pillClickCallback:()=>{var e;return null==t||null===(e=t.feedManager)||void 0===e?void 0:e.callRefreshRegionsData({invalidateCache:!0,scrollToTop:!1})}}const s=i.qy`
${(t,e)=>{const o=((t,e)=>n(t)?t:n(null==e?void 0:e.parent)?e.parent:void 0)(t,e);return o?(0,a.yN)({...o.config.childExperienceReferencesWC.pillWC,instanceId:o.instanceId},{properties:{refreshCallback:r(o),getDesktopFeedRect(){var t;return null===(t=o.getBoundingClientRect)||void 0===t?void 0:t.call(o)},hasRailSectionProng2:o.hasRailSection}}):null}}`},82316(t,e,o){function i(t){}o.d(e,{E(){return i}})},84506(t,e,o){o.d(e,{d(){return s}});var i=o(56911),a=o(92011),n=o(38493);const r="next";class s extends a.L{constructor(){super(...arguments),this.hiddenFromAT=!0,this.direction=r}keyupHandler(t){if(!this.hiddenFromAT){const e=t.key;"Enter"!==e&&"Space"!==e||this.$emit("click",t)}}}(0,i.Cg)([(0,n.CF)({mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],s.prototype,"disabled",void 0),(0,i.Cg)([(0,n.CF)({attribute:"aria-hidden",converter:n.Bs}),(0,i.Sn)("design:type",Boolean)],s.prototype,"hiddenFromAT",void 0),(0,i.Cg)([n.CF,(0,i.Sn)("design:type",String)],s.prototype,"direction",void 0)},87481(t,e,o){o.d(e,{O(){return n},S(){return a}});var i=o(74849);const a=i.A`
    .line-clamp {
        overflow: hidden;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: var(--heading-max-lines, 3);
    }
`,n=i.A`
    .sd-action:not([appearance="lightweight"]) {
        --control-corner-radius: 999;
        font-size: var(--type-ramp-minus-1-font-size);
        line-height: var(--type-ramp-minus-1-line-height);
    }

    .sd-action::part(control) {
        width: 100%;
    }

    .sd-action::part(content) {
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
        text-overflow: ellipsis;
        overflow: hidden;
    }
`},87993(t,e,o){o.d(e,{S(){return i},m(){return d}});var i,a=o(56911),n=o(60815),r=o(92011),s=o(38493),l=o(94407);!function(t){t.default="default",t.condensed="condensed",t.infoPane="infoPane",t.infoPane1x3y="infoPane1x3y",t.infoPaneSplitVertical="infoPaneSplitVertical",t.infoPaneSplitHorizontal="infoPaneSplitHorizontal"}(i||(i={}));class d extends r.L{constructor(){super(...arguments),this.layout=i.default,this.headinglevel=3}handleStartActionsContentChange(){this.startActionsContainer.classList.toggle("start-actions",this.startActions.assignedNodes().length>0)}handleEndActionsContentChange(){this.endActionsContainer.classList.toggle("end-actions",this.endActions.assignedNodes().length>0)}abstractChanged(){this.$fastController.isConnected&&(this.hasAbstract=this.abstract.length>0)}handleMediaContentChange(){this.mediaContainer.classList.toggle("media",this.media.assignedNodes().length>0)}handleContentCardLinkClick(t){return this.handleContentCardClickOverride?this.handleContentCardClickOverride(t):(this.$emit("link-invoked",t),!0)}connectedCallback(){super.connectedCallback(),this.addEventListener("mouseover",this.mouseOver),this.addEventListener("mouseout",this.mouseOut),this.addEventListener("focusin",this.focusIn),this.addEventListener("focusout",this.focusOut)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mouseover",this.mouseOver),this.removeEventListener("mouseout",this.mouseOut),this.removeEventListener("focusin",this.focusIn),this.removeEventListener("focusout",this.focusOut)}mouseOver(){this.setExpanded(!0),this.hasHover=!0}mouseOut(){this.hasFocus||this.setExpanded(!1),this.hasHover=!1}focusIn(){this.setExpanded(!0),this.hasFocus=!0}focusOut(){this.hasHover||this.setExpanded(!1),this.hasFocus=!1}filteredContentIndicator(){return this.contentIndicatorNodes.filter(t=>t instanceof l.L)}setExpanded(t){this.filteredContentIndicator().forEach(e=>e.expanded=t)}}(0,a.Cg)([s.CF],d.prototype,"layout",void 0),(0,a.Cg)([(0,s.CF)({attribute:"heading-level",mode:"fromView",converter:s.R$})],d.prototype,"headinglevel",void 0),(0,a.Cg)([(0,s.CF)({mode:"fromView"})],d.prototype,"href",void 0),(0,a.Cg)([n.sH],d.prototype,"isGrid",void 0),(0,a.Cg)([n.sH],d.prototype,"anchorTelemetryTag",void 0),(0,a.Cg)([n.sH],d.prototype,"mediaNodes",void 0),(0,a.Cg)([n.sH],d.prototype,"hasAbstract",void 0),(0,a.Cg)([n.sH],d.prototype,"abstract",void 0),(0,a.Cg)([n.sH],d.prototype,"iconSlottedNodes",void 0),(0,a.Cg)([(0,s.CF)({attribute:"image-priority",mode:"boolean"})],d.prototype,"imagePriority",void 0),(0,a.Cg)([s.CF],d.prototype,"target",void 0),(0,a.Cg)([n.sH],d.prototype,"hoverActionsSlottedNodes",void 0),(0,a.Cg)([n.sH],d.prototype,"handleContentCardClickOverride",void 0),(0,a.Cg)([n.sH],d.prototype,"contentIndicatorNodes",void 0)},88817(t,e,o){o.d(e,{m(){return H}});var i=o(56911),a=o(38493),n=o(60815),r=o(55230),s=o(92011),l=o(56863);class d extends s.L{}class c extends((0,l.dx)(d)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class p extends c{constructor(){super(),this.initialValue="on",this.proxy.setAttribute("type","radio")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly)}defaultCheckedChanged(){this.$fastController.isConnected&&!this.dirtyChecked&&(this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}connectedCallback(){super.connectedCallback(),this.validate(),"radiogroup"!==this.parentElement?.getAttribute("role")&&null===this.getAttribute("tabindex")&&(this.disabled||this.setAttribute("tabindex","0")),this.checkedAttribute&&(this.dirtyChecked||this.isInsideRadioGroup()||(this.checked=this.defaultChecked??!1,this.dirtyChecked=!1))}isInsideRadioGroup(){return null!==this.closest("[role=radiogroup]")}keypressHandler(t){if(t.key!==r.gG)return!0;this.checked||this.readOnly||(this.checked=!0)}clickHandler(t){this.disabled||this.readOnly||this.checked||(this.checked=!0)}}(0,i.Cg)([(0,a.CF)({attribute:"readonly",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],p.prototype,"readOnly",void 0),(0,i.Cg)([n.sH,(0,i.Sn)("design:type",String)],p.prototype,"name",void 0),(0,i.Cg)([n.sH,(0,i.Sn)("design:type",Array)],p.prototype,"defaultSlottedNodes",void 0);var u=o(37180),h=o(74849),g=o(64187),v=o(73477),f=o(60993),m=o(22131),$=o(50882),x=o(48196),b=o(74838),y=o(26920),w=o(43774),k=o(46203),C=o(7896),z=o(48751),F=o(41123),M=o(95239),S=o(14996),T=o(79288);const P=h.A`
    ${(0,g.V)("inline-flex")} :host {
        --input-size: calc((${x.D} / 2) + ${b.vR});
        align-items: center;
        outline: none;
        margin: calc(${b.vR} * 1px) 0;
        ${""} user-select: none;
        position: relative;
        flex-direction: row;
        transition: all 0.2s ease-in-out;
    }

    .control {
        position: relative;
        width: calc(var(--input-size) * 1px);
        height: calc(var(--input-size) * 1px);
        box-sizing: border-box;
        border-radius: 50%;
        border: calc(${y.XA} * 1px) solid ${w.nF};
        background: ${k.le};
        outline: none;
        cursor: pointer;
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        font-family: ${C.O};
        color: ${z.l};
        ${""} padding-inline-start: calc(${b.vR} * 2px + 2px);
        margin-inline-end: calc(${b.vR} * 2px + 2px);
        cursor: pointer;
        font-size: ${F.K};
        line-height: ${F.Z};
    }

    .control,
    .checked-indicator {
        flex-shrink: 0;
    }

    .checked-indicator {
        position: absolute;
        top: 5px;
        left: 5px;
        right: 5px;
        bottom: 5px;
        border-radius: 50%;
        display: inline-block;
        background: ${z.l};
        fill: ${z.l};
        opacity: 0;
        pointer-events: none;
    }

    :host(:enabled) .control:hover {
        background: ${k.jM};
        border-color: ${w.vA};
    }

    :host(:enabled) .control:active {
        background: ${k.RS};
        border-color: ${w.p4};
    }

    :host(:${v.N}) .control {
        box-shadow: 0 0 0 2px ${M.p}, 0 0 0 4px ${S.WN};
        border-color: ${S.WN};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .control,
    :host([disabled]) .control {
        cursor: ${f.Z};
    }

    :host([aria-checked="true"]) .checked-indicator {
        opacity: 1;
    }

    :host([disabled]) {
        opacity: ${T.q};
    }
`.withBehaviors((0,m.mr)(h.A`
            .control {
                forced-color-adjust: none;
                border-color: ${$.A.FieldText};
                background: ${$.A.Field};
            }
            :host(:enabled) .control:hover,
            .control:active {
                border-color: ${$.A.Highlight};
                background: ${$.A.Field};
            }
            :host(:${v.N}) .control {
                border-color: ${$.A.Highlight};
                box-shadow: 0 0 0 2px ${$.A.Field},
                    0 0 0 4px ${$.A.FieldText};
            }
            :host([aria-checked="true"]:${v.N}:enabled) .control {
                border-color: ${$.A.Highlight};
                box-shadow: 0 0 0 2px ${$.A.Field},
                    0 0 0 4px ${$.A.FieldText};
            }
            :host([aria-checked="true"]:enabled) .control:hover,
            .control:active {
                border-color: ${$.A.Highlight};
                background: ${$.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${$.A.Highlight};
                fill: ${$.A.Highlight};
            }
            :host([aria-checked="true"]) .control:hover .checked-indicator {
                background: ${$.A.HighlightText};
                fill: ${$.A.HighlightText};
            }
            :host([disabled]) {
                forced-color-adjust: none;
                opacity: 1;
            }
            :host([disabled]) .label {
                color: ${$.A.GrayText};
            }
            :host([disabled]) .control,
            :host([aria-checked="true"][disabled]) .control:hover,
            .control:active {
                background: ${$.A.Field};
                border-color: ${$.A.GrayText};
            }
            :host([disabled]) .checked-indicator,
            :host([aria-checked="true"][disabled]) .control:hover .checked-indicator {
                fill: ${$.A.GrayText};
                background: ${$.A.GrayText};
            }
        `));var q=o(96950),D=o(82774),B=o(79109),A=o(18893);const V=function(t={}){return q.qy`
        <template
            role="radio"
            aria-checked="${t=>t.checked}"
            aria-required="${t=>t.required}"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            @keypress="${(t,e)=>t.keypressHandler(e.event)}"
            @click="${(t,e)=>t.clickHandler(e.event)}"
        >
            <div part="control" class="control">
                <slot name="checked-indicator">
                    ${(0,A.R)(t.checkedIndicator)}
                </slot>
            </div>
            <label
                part="label"
                class="${t=>["label",!t.defaultSlottedNodes?.length&&"label__hidden"].filter(Boolean).join(" ")}"
            >
                <slot
                    ${(0,D.e)({property:"defaultSlottedNodes",filter:B.g})}
                ></slot>
            </label>
        </template>
    `}({checkedIndicator:q.qy`
        <div part="checked-indicator" class="checked-indicator"></div>
    `}),H=p.compose({name:`${u.c.prefix}-radio`,template:V,styles:P})},92687(t,e,o){o.d(e,{m(){return a}});var i=o(92011);class a extends i.L{handleImageContentChange(){this.imageContainer.classList.toggle("image",this.image.assignedNodes().length>0)}}},93866(t,e,o){o.d(e,{Bb(){return M}});var i=o(56911),a=o(92011),n=o(38493),r=o(60815);class s extends a.L{moneyCardContentDataChanged(){"Default"!==this.cardStyle&&void 0===this.moneyCardContentData.actionAppearance&&(this.moneyCardContentData.actionAppearance="outline")}getQuoteColor(t,e,o,i,a){return e?a:this.moneyCardContentData.swapGainLossColor?t?o:i:t?i:o}changeShowingValue(){this.showChangeValue=!this.showChangeValue}connectedCallback(){super.connectedCallback(),this.showChangeValue=!1}}(0,i.Cg)([(0,n.CF)({attribute:"layout"})],s.prototype,"layout",void 0),(0,i.Cg)([n.CF],s.prototype,"cardStyle",void 0),(0,i.Cg)([n.CF],s.prototype,"target",void 0),(0,i.Cg)([r.sH],s.prototype,"moneyCardContentData",void 0),(0,i.Cg)([r.sH],s.prototype,"quoteItems",void 0),(0,i.Cg)([r.sH],s.prototype,"showChangeValue",void 0),(0,i.Cg)([r.sH],s.prototype,"headerTelemetryTag",void 0),(0,i.Cg)([r.sH],s.prototype,"switchValueTelemetryTag",void 0),(0,i.Cg)([r.sH],s.prototype,"seeMoreTelemetryTag",void 0);var l=o(96950),d=o(69259),c=o(39957);const p=l.qy`<a class="quote-row" part="quote-row" href="${t=>t.quoteHref}" target=${(t,e)=>e.parent.target} aria-label="${t=>t.displayName} ${t=>t.symbol} ${t=>t.price} ${t=>t.changePcnt}" data-t="${t=>t.telemetryTag}"><div class="quote-view" part="quote-view"><div class="quote-title-container" part="quote-title-container"><span class="quote-title" part="quote-title"><p class="quote-title-content" part="quote-title-content" title="${t=>t.displayName} (${t=>t.symbol})">${t=>t.symbol}</p></span><span class="sec-title" part="sec-title"><p class="sec-title-str" part="sec-title-str" title="${t=>t.displayName} (${t=>t.symbol})">${t=>t.displayName}</p></span></div><div class="quote-title-container" part="quote-title-container"><div class="price" part="price"><span class="price-str" part="price-str">${t=>t.price}</span></div></div><button class="change-values ${(t,e)=>e.parent.getQuoteColor(t.gain,t.unchanged,"quote-red","quote-green","quote-grey")}" part="change-values ${(t,e)=>e.parent.getQuoteColor(t.gain,t.unchanged,"quote-red","quote-green","quote-grey")}" @click="${(t,e)=>e.parent.changeShowingValue()}" aria-label="${(t,e)=>e.parent.showChangeValue?`${t.changeValue} ${t.displayName} ${t.changePcnt}`:`${t.changePcnt} ${t.displayName} ${t.changeValue}`}" data-t="${(t,e)=>e.parent.switchValueTelemetryTag}">${(0,d.z)((t,e)=>e.parent.showChangeValue,l.qy`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${t=>t.changeValue}</span></span>`)} ${(0,d.z)((t,e)=>!e.parent.showChangeValue,l.qy`<span class="change-button-area" part="change-button-area"><span class="change-values-percentage" part="change-values-percentage">&lrm;${t=>t.changePcnt}&lrm;</span></span>`)}</button></div></a>`,u=l.qy`<msft-structured-data-card target=${t=>t.target} :headerTelemetryTag=${t=>t.headerTelemetryTag} :seeMoreTelemetryTag=${t=>t.seeMoreTelemetryTag} :data=${t=>t.moneyCardContentData}><slot name="more-actions" slot="more-actions"></slot><slot name="pin" slot="pin"></slot><slot name="title-icon" slot="title-icon"></slot><div class="quote-list" part="quote-list">${(0,c.ux)(t=>t.quoteItems,p)}</div><slot name="footer-start" slot="footer-start"></slot><slot name="footer-end" slot="footer-end"></slot></msft-structured-data-card>`;var h=o(48751),g=o(89580),v=o(41123),f=o(64003),m=o(61138),$=o(45476),x=o(14996),b=o(26920),y=o(74849),w=o(64187),k=o(22131),C=o(50882);const z=y.A`
        ${(0,w.V)("flex")} :host{height:100%;--quote-grid-columns:111px 81px 56px}:host(:focus){outline:none}msft-structured-data-card::part(title-link)::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}.price-str{color:${h.l};
            font-weight: 600;
            text-align: end;
            width: 100%;
            font-size: var(--price-content-font-size, ${g.Y});
            line-height: var(--price-content-line-height, ${g.v})}.quote-list{margin-top:var(--quote-list-margin-top,12px);display:grid;grid-template-rows:var(--quote-list-grid-rows,repeat(auto-fill,52px));row-gap:var(--quote-list-grid-gap,2px);z-index:1}.quote-title-content{color:${h.l};
            font-weight: 600;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            margin: 0;
            font-size: var(--quote-title-font-size, ${v.K});
            line-height: var(--quote-title-line-height, ${v.Z})}.sec-title-str{color:${f.c};
            margin: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            font-size: ${m.k};
            line-height: ${m.F}}.quote-row{cursor:pointer;text-decoration:none;padding:var(--quote-row-padding,8px 8px);margin:var(--quote-row-margin,0px 8px)}.quote-row:hover{background:${$.oO}}.change-values{height:24px;font-family:var(--body-font);border-radius:4px;border:0;padding:0;cursor:pointer;outline:none}.change-values:focus-visible{outline-color:${x.WN};outline-width:2px;outline-style:auto}.change-button-area{display:flex;flex-direction:column;justify-content:flex-end}.change-values-percentage{margin-top:4px;margin-bottom:4px;margin-inline-end:8px;display:block;font-size:${m.k};
            font-weight: 600;
            line-height: ${m.F};text-align:end}.price{align-items:center;display:flex}.quote-title-container{text-decoration:none}.quote-view{align-items:center;display:grid;grid-column-gap:8px;grid-template-columns:var(--quote-grid-columns)}.quote-green{color:#ffffff;background:#107c10}.quote-red{color:#ffffff;background:#d33e3e}.quote-grey{color:#ffffff;background:#808080}`.withBehaviors((0,k.mr)(y.A` :host{forced-color-adjust:auto}.title-link:hover{text-decoration:underline}.change-values,.quote-row:hover{forced-color-adjust:none;background:${C.A.ButtonFace};
                    box-shadow: 0 0 0 calc((${b.vd} - ${b.XA}) * 1px)
                        ${C.A.LinkText};
                    color: ${C.A.ButtonText}}::slotted(*[slot="option-button"]){fill:${C.A.ButtonText}}::slotted([slot="option-button"]:hover){background:${C.A.Highlight};
                    fill: ${C.A.HighlightText}}.change-values:focus-visible{outline-color:${C.A.Highlight};
                }
            `));var F=o(99900);const M=s.compose({name:`${F.i.prefix}-show-quotes-money-card`,template:u,styles:z})},94407(t,e,o){o.d(e,{L(){return s}});var i=o(56911),a=o(60815),n=o(92011),r=o(38493);class s extends n.L{constructor(){super(...arguments),this.expanded=!1}defaultItemsChanged(){this.$fastController.isConnected&&(this.shouldanimate=this.defaultItems.length>0)}}(0,i.Cg)([(0,r.CF)({mode:"boolean"})],s.prototype,"expanded",void 0),(0,i.Cg)([a.sH],s.prototype,"defaultItems",void 0),(0,i.Cg)([(0,r.CF)({mode:"boolean",attribute:"animate"})],s.prototype,"shouldanimate",void 0)},94976(t,e,o){o.d(e,{jU(){return r}});var i=o(2171);const a=()=>i.vv.get("__core_DisplayModeCoordination_displayModeMap__",()=>({})),n=()=>i.vv.get("__core_DisplayModeCoordination_callbackMap__",()=>({}));function r(t,e){const o=n(),i=a();let r=o[t];r||(r=[],o[t]=r),r.push(e);const s=i[t];s&&e(s)}},96193(t,e,o){o.d(e,{z(){return a}});var i=o(92011);class a extends i.L{}},98093(t,e,o){o.d(e,{l4(){return g},PO(){return i},po(){return n},bN(){return r},tr(){return a}});var i,a,n,r,s=o(56911),l=o(38493),d=o(60815),c=o(56863),p=o(92011);class u extends p.L{}class h extends((0,c.rf)(u)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}!function(t){t.full="full",t.half="half"}(i||(i={})),function(t){t.Currency="currencyPair",t.Commodity="future",t.ETF="etf",t.Funds="fund",t.Indices="index",t.Stocks="stock"}(a||(a={})),function(t){t.ShowData="showData",t.EmptyWatchlist="emptyWatchlist",t.AddWatchlist="addWatchlist"}(n||(n={})),function(t){t.Watchlist="watchlist",t.Market="market"}(r||(r={}));class g extends h{constructor(){super(...arguments),this.layout=i.half,this.optionSwitch=!1,this.target="_blank",this.showChangeValue=!1,this.swapGainLossColor=!1}getQuoteColor(t,e,o,i,a){return e?a:this.swapGainLossColor?t?o:i:t?i:o}optionClicked(){this.$emit("action-click-option");const t=this.titleArea.querySelector("#option-button");t&&t.focus()}blurOption(){const t=this.titleArea.querySelector("#option-button");t&&t.blur()}onBlurOption(){this.$emit("action-blur-option")}onTitleClicked(){this.$emit("action-title-clicked")}changeShowingValue(){this.showChangeValue=!this.showChangeValue}handleTextInput(){this.inputControl&&(this.value=this.inputControl.value,this.$emit("action-text-input",this.inputControl.value))}addToWatchlist(t){this.inputControl&&(this.inputControl.value="",this.value=""),this.$emit("action-add-to-watchlist",t)}addSymbolAction(t){0===t.button&&(this.$emit("action-add-symbol"),this.blurOption())}hideCardAction(t){0===t.button&&(this.$emit("action-hide-card"),this.blurOption())}dataProviderAction(t){0===t.button&&(this.$emit("action-data-provider"),this.blurOption(),window.open(this.dataProviderLink))}moreSettingAction(t){0===t.button&&(this.$emit("action-more-setting"),this.blurOption())}}(0,s.Cg)([l.CF],g.prototype,"layout",void 0),(0,s.Cg)([l.CF],g.prototype,"titleStr",void 0),(0,s.Cg)([l.CF],g.prototype,"titleLink",void 0),(0,s.Cg)([(0,l.CF)({mode:"boolean"})],g.prototype,"userSignedIn",void 0),(0,s.Cg)([l.CF],g.prototype,"dataFrom",void 0),(0,s.Cg)([l.CF],g.prototype,"quoteItems",void 0),(0,s.Cg)([(0,l.CF)({mode:"boolean"})],g.prototype,"optionSwitch",void 0),(0,s.Cg)([l.CF],g.prototype,"cardType",void 0),(0,s.Cg)([(0,l.CF)()],g.prototype,"footer",void 0),(0,s.Cg)([(0,l.CF)()],g.prototype,"footerLink",void 0),(0,s.Cg)([(0,l.CF)()],g.prototype,"dataProviderLink",void 0),(0,s.Cg)([l.CF],g.prototype,"target",void 0),(0,s.Cg)([d.sH],g.prototype,"showChangeValue",void 0),(0,s.Cg)([(0,l.CF)({mode:"boolean"})],g.prototype,"swapGainLossColor",void 0),(0,s.Cg)([l.CF],g.prototype,"addSymbolBtnStr",void 0),(0,s.Cg)([l.CF],g.prototype,"emptyWatchlistStr",void 0),(0,s.Cg)([l.CF],g.prototype,"searchSuggestions",void 0),(0,s.Cg)([(0,l.CF)({mode:"boolean"})],g.prototype,"showSuggestions",void 0),(0,s.Cg)([l.CF],g.prototype,"searchPlaceholder",void 0),(0,s.Cg)([(0,l.CF)({mode:"boolean"})],g.prototype,"noSuggestion",void 0),(0,s.Cg)([l.CF],g.prototype,"noSuggestionHint",void 0),(0,s.Cg)([l.CF],g.prototype,"addSymbolOptStr",void 0),(0,s.Cg)([l.CF],g.prototype,"hideCardOptStr",void 0),(0,s.Cg)([l.CF],g.prototype,"dataProviderOptStr",void 0),(0,s.Cg)([l.CF],g.prototype,"moreSettingOptStr",void 0)},99015(t,e,o){o.d(e,{Y(){return c}});var i=o(96950),a=o(60402),n=o(69259),r=o(82774),s=o(10108),l=o(35106),d=o(18893);function c(t={}){return i.qy`
        <template @keyup="${(t,e)=>t.keyupHandler(e.event)}">
            ${(0,l.LT)(t)}
            <div class="scroll-area" part="scroll-area">
                <div
                    class="scroll-view"
                    part="scroll-view"
                    @scroll="${t=>t.scrolled()}"
                    ${(0,a.K)("scrollContainer")}
                >
                    <div
                        class="content-container"
                        part="content-container"
                        ${(0,a.K)("content")}
                    >
                        <slot
                            ${(0,r.e)({property:"scrollItems",filter:(0,s.Y)()})}
                        ></slot>
                    </div>
                </div>
                ${(0,n.z)(t=>"mobile"!==t.view,i.qy`
                        <div
                            class="scroll scroll-prev"
                            part="scroll-prev"
                            ${(0,a.K)("previousFlipperContainer")}
                        >
                            <div class="scroll-action" part="scroll-action-previous">
                                <slot name="previous-flipper">
                                    ${(0,d.R)(t.previousFlipper)}
                                </slot>
                            </div>
                        </div>
                        <div
                            class="scroll scroll-next"
                            part="scroll-next"
                            ${(0,a.K)("nextFlipperContainer")}
                        >
                            <div class="scroll-action" part="scroll-action-next">
                                <slot name="next-flipper">
                                    ${(0,d.R)(t.nextFlipper)}
                                </slot>
                            </div>
                        </div>
                    `)}
            </div>
            ${(0,l.aO)(t)}
        </template>
    `}},99564(t,e,o){o.d(e,{m(){return x}});var i=o(75261);class a extends i.t{}var n=o(37180),r=o(74849),s=o(64187),l=o(22131),d=o(50882),c=o(48196),p=o(37302),u=o(4283),h=o(64003);const g=r.A`
    ${(0,s.V)("flex")} :host {
        align-items: center;
        outline: none;
        height: calc(${c.D} * 1px);
        width: calc(${c.D} * 1px);
        margin: calc(${c.D} * 1px) 0;
    }

    .progress {
        height: 100%;
        width: 100%;
    }

    .background {
        stroke: ${p.F7};
        fill: none;
        stroke-width: 2px;
    }

    .determinate {
        stroke: ${u.IR};
        fill: none;
        stroke-width: 2px;
        stroke-linecap: round;
        transform-origin: 50% 50%;
        transform: rotate(-90deg);
        transition: all 0.2s ease-in-out;
    }

    .indeterminate-indicator-1 {
        stroke: ${u.IR};
        fill: none;
        stroke-width: 2px;
        stroke-linecap: round;
        transform-origin: 50% 50%;
        transform: rotate(-90deg);
        transition: all 0.2s ease-in-out;
        animation: spin-infinite 2s linear infinite;
    }

    :host([paused]) .indeterminate-indicator-1 {
        animation-play-state: paused;
        stroke: ${p.F7};
    }

    :host([paused]) .determinate {
        stroke: ${h.c};
    }

    @keyframes spin-infinite {
        0% {
            stroke-dasharray: 0.01px 43.97px;
            transform: rotate(0deg);
        }
        50% {
            stroke-dasharray: 21.99px 21.99px;
            transform: rotate(450deg);
        }
        100% {
            stroke-dasharray: 0.01px 43.97px;
            transform: rotate(1080deg);
        }
    }
`.withBehaviors((0,l.mr)(r.A`
            .indeterminate-indicator-1,
            .determinate {
                stroke: ${d.A.FieldText};
            }
            .background {
                stroke: ${d.A.Field};
            }
            :host([paused]) .indeterminate-indicator-1 {
                stroke: ${d.A.Field};
            }
            :host([paused]) .determinate {
                stroke: ${d.A.GrayText};
            }
        `));var v=o(96950),f=o(69259),m=o(18893);const $=function(t={}){return v.qy`
        <template
            role="progressbar"
            aria-valuenow="${t=>t.value}"
            aria-valuemin="${t=>t.min}"
            aria-valuemax="${t=>t.max}"
        >
            ${(0,f.z)(t=>"number"==typeof t.value,v.qy`
                    <svg
                        class="progress"
                        part="progress"
                        viewBox="0 0 16 16"
                        slot="determinate"
                    >
                        <circle
                            class="background"
                            part="background"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                        <circle
                            class="determinate"
                            part="determinate"
                            style="stroke-dasharray: ${t=>44*t.percentComplete/100+"px 44px"}"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                    </svg>
                `,v.qy`
                    <slot name="indeterminate">
                        ${(0,m.R)(t.indeterminateIndicator)}
                    </slot>
                `)}
        </template>
    `}({indeterminateIndicator:v.qy`
        <svg class="progress" part="progress" viewBox="0 0 16 16">
            <circle
                class="background"
                part="background"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
            <circle
                class="indeterminate-indicator-1"
                part="indeterminate-indicator-1"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
        </svg>
    `}),x=a.compose({name:`${n.c.prefix}-progress-ring`,template:$,styles:g})}}]);