// © Microsoft Corporation. All rights reserved.
export const IE11NTPLocalisation = {
    "ar-ae": {
        bannerTextHeadline: "ينتهي دعم Internet Explorer لـ MSN",
        bannerText: "للوصول إلى MSN وتجارب مخصصة أخرى جذابة، ابدأ استخدام Microsoft Edge.",
        bannerButtonText: "بدء استخدام Microsoft Edge",
        footerItems: [
            {
                Displaytext: " الخصوصية وملفات تعريف الارتباط |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " شروط الاستخدام</value> |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " الإعلان هنا |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " >حول الإعلانات الخاصة بنا",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "ar-eg": {
        bannerTextHeadline: "ينتهي دعم Internet Explorer لـ MSN",
        bannerText: "للوصول إلى MSN وتجارب مخصصة أخرى جذابة، ابدأ استخدام Microsoft Edge.",
        bannerButtonText: "بدء استخدام Microsoft Edge",
        footerItems: [
            {
                Displaytext: " الخصوصية وملفات تعريف الارتباط |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " شروط الاستخدام</value> |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " الإعلان هنا |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " >حول الإعلانات الخاصة بنا",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "ar-sa": {
        bannerTextHeadline: "ينتهي دعم Internet Explorer لـ MSN",
        bannerText: "للوصول إلى MSN وتجارب مخصصة أخرى جذابة، ابدأ استخدام Microsoft Edge.",
        bannerButtonText: "بدء استخدام Microsoft Edge",
        footerItems: [
            {
                Displaytext: " الخصوصية وملفات تعريف الارتباط |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " شروط الاستخدام</value> |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " الإعلان هنا |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " >حول الإعلانات الخاصة بنا",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "bn-in": {
        bannerTextHeadline: "Internet Explorer-এর জন্য MSN সহায়তা দেওয়া শেষ করছে",
        bannerText: "MSN এবং অন্যান্য ব্যক্তিগতকৃত অ্যাক্সেস করতে, নিযুক্ত অভিজ্ঞতাগুলি, Microsoft Edge দিয়ে শুরু করা যাক।",
        bannerButtonText: "Microsoft Edge দিয়ে শুরু করা যাক",
        footerItems: [
            {
                Displaytext: " গোপনীয়তা এবং কুকি |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " ব্যবহারের নিয়মাবলি |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " বিজ্ঞাপন |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Aআমাদের বিজ্ঞাপন সম্পর্কে",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "cs-cz": {
        bannerTextHeadline: "Ukončení podpory MSN pro Internet Explorer",
        bannerText: "Pokud chcete získat přístup k aplikaci MSN a dalším přizpůsobeným a poutavým prostředím, začněte s Microsoft Edgem.",
        bannerButtonText: "Začínáme s Microsoft Edgem",
        footerItems: [
            {
                Displaytext: " Ochrana osobních údajů a soubory cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Podmínky použití |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Inzerujte |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " O našich reklamách",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "da-dk": {
        bannerTextHeadline: "MSN afslutter support af Internet Explorer.",
        bannerText: "Kom i gang med Microsoft Edge for at få adgang til MSN og andre tilpassede, engagerende oplevelser.",
        bannerButtonText: "Kom i gang med Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Beskyttelse af personlige oplysninger og Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Vilkår for anvendelse |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Reklame |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Om vores reklamer",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "de-at": {
        bannerTextHeadline: "MSN beendet den Support für Internet Explorer.",
        bannerText: "Um auf MSN und andere personalisierte, ansprechende Erfahrungen zuzugreifen, beginnen Sie mit Microsoft Edge.",
        bannerButtonText: "Erste Schritte mit Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Datenschutz und Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Nutzungsbedingungen |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Werben auf MSN |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Impressum & Transparenz |",
                href: "https://www.msn.com/de-at/nachrichten/topgeschichten/impressum/ar-BB5wUud"
            },
            {
                Displaytext: " Über unsere Anzeigen",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "de-ch": {
        bannerTextHeadline: "MSN beendet den Support für Internet Explorer.",
        bannerText: "Um auf MSN und andere personalisierte, ansprechende Erfahrungen zuzugreifen, beginnen Sie mit Microsoft Edge.",
        bannerButtonText: "Erste Schritte mit Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Datenschutz und Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Nutzungsbedingungen |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Werben auf MSN |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Impressum & Transparenz |",
                href: "https://www.msn.com/de-ch/nachrichten/topgeschichten/impressum/ar-BB5wWbz"
            },
            {
                Displaytext: " Über unsere Anzeigen",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "de-de": {
        bannerTextHeadline: "MSN beendet den Support für Internet Explorer.",
        bannerText: "Um auf MSN und andere personalisierte, ansprechende Erfahrungen zuzugreifen, beginnen Sie mit Microsoft Edge.",
        bannerButtonText: "Erste Schritte mit Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Datenschutz und Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Nutzungsbedingungen |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Werben auf MSN |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Impressum & Transparenz |",
                href: "https://www.msn.com/de-de/nachrichten/schlagzeilen/Impressum/ar-BB56cmH"
            },
            {
                Displaytext: " Über unsere Anzeigen",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "el-gr": {
        bannerTextHeadline: "Λήξη υποστήριξης MSN για Internet Explorer",
        bannerText: "Για να αποκτήσετε πρόσβαση στο MSN και σε άλλες εξατομικευμένες, ελκυστικές εμπειρίες, ξεκινήστε με το Microsoft Edge.",
        bannerButtonText: "Ξεκινήστε με το Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Προστασία προσωπικών δεδομένων και cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Όροι χρήσης |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Διαφήμιση |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Σχετικά με τις διαφημίσεις μας",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-ae": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-au": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-ca": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-gb": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-ie": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-in": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-my": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-nz": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-ph": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-sg": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-us": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Us |",
                href: "https://msn.com/en-us/news/us/about-us/ar-BBN0NAK"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-xl": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "en-za": {
        bannerTextHeadline: "MSN ending support for Internet Explorer",
        bannerText: "To access MSN and other personalized, engaging experiences, get started with Microsoft Edge.",
        bannerButtonText: "Get Started with Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "es-ar": {
        bannerTextHeadline: "El soporte técnico de MSN para Internet Explorer finalizará pronto.",
        bannerText: "Para acceder a MSN y a otras experiencias personalizadas y atractivas, empieza con Microsoft Edge.",
        bannerButtonText: "Introducción a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacidad y cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Términos de uso |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Anunciar |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Acerca de nuestra publicidad",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "es-cl": {
        bannerTextHeadline: "El soporte técnico de MSN para Internet Explorer finalizará pronto.",
        bannerText: "Para acceder a MSN y a otras experiencias personalizadas y atractivas, empieza con Microsoft Edge.",
        bannerButtonText: "Introducción a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacidad y cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Términos de uso |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Anunciar |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Acerca de nuestra publicidad",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "es-co": {
        bannerTextHeadline: "El soporte técnico de MSN para Internet Explorer finalizará pronto.",
        bannerText: "Para acceder a MSN y a otras experiencias personalizadas y atractivas, empieza con Microsoft Edge.",
        bannerButtonText: "Introducción a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacidad y cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Términos de uso |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Anunciar |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Acerca de nuestra publicidad",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "es-es": {
        bannerTextHeadline: "El soporte técnico de MSN para Internet Explorer finalizará pronto.",
        bannerText: "Para acceder a MSN y a otras experiencias personalizadas y atractivas, empieza con Microsoft Edge.",
        bannerButtonText: "Introducción a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacidad y cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Condiciones de uso |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Anunciar |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Acerca de nuestros anuncios",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "es-mx": {
        bannerTextHeadline: "El soporte técnico de MSN para Internet Explorer finalizará pronto.",
        bannerText: "Para acceder a MSN y a otras experiencias personalizadas y atractivas, empieza con Microsoft Edge.",
        bannerButtonText: "Introducción a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacidad y cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Términos de uso |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Anunciar |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Acerca de nuestra publicidad",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "es-pe": {
        bannerTextHeadline: "El soporte técnico de MSN para Internet Explorer finalizará pronto.",
        bannerText: "Para acceder a MSN y a otras experiencias personalizadas y atractivas, empieza con Microsoft Edge.",
        bannerButtonText: "Introducción a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacidad y cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Términos de uso |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Anunciar |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Acerca de nuestra publicidad",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "es-us": {
        bannerTextHeadline: "El soporte técnico de MSN para Internet Explorer finalizará pronto.",
        bannerText: "Para acceder a MSN y a otras experiencias personalizadas y atractivas, empieza con Microsoft Edge.",
        bannerButtonText: "Introducción a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacidad y cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Términos de uso |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Anunciar |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Acerca de nuestra publicidad",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "es-ve": {
        bannerTextHeadline: "El soporte técnico de MSN para Internet Explorer finalizará pronto.",
        bannerText: "Para acceder a MSN y a otras experiencias personalizadas y atractivas, empieza con Microsoft Edge.",
        bannerButtonText: "Introducción a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacidad y cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Términos de uso |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Anunciar |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Acerca de nuestra publicidad",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "es-xl": {
        bannerTextHeadline: "El soporte técnico de MSN para Internet Explorer finalizará pronto.",
        bannerText: "Para acceder a MSN y a otras experiencias personalizadas y atractivas, empieza con Microsoft Edge.",
        bannerButtonText: "Introducción a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacidad y cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Términos de uso |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Anunciar |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Acerca de nuestra publicidad",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "fi-fi": {
        bannerTextHeadline: "MSN lopettaa Internet Explorerin tuen",
        bannerText: "Jos haluat käyttää MSNia ja muita mukautettuja ja mukaansatempaavia kokemuksia, aloita Microsoft Edgen käyttö.",
        bannerButtonText: "Microsoft Edgen käytön aloittaminen",
        footerItems: [
            {
                Displaytext: " Tietosuoja ja evästeet |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Käyttöehdot |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Mainosta |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Tietoja mainoksistamme",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "fr-be": {
        bannerTextHeadline: "Prise en charge de fin MSN pour les Explorer Internet",
        bannerText: "Pour accéder à MSN et à d’autres expériences personnalisées et attrayantes, commencez à utiliser Microsoft Edge.",
        bannerButtonText: "Démarrer avec Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Confidentialité et cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Conditions d’utilisation |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Annonceurs |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " À propos de nos annonces",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "fr-ca": {
        bannerTextHeadline: "Prise en charge de fin MSN pour les Explorer Internet",
        bannerText: "Pour accéder à MSN et à d’autres expériences personnalisées et attrayantes, commencez à utiliser Microsoft Edge.",
        bannerButtonText: "Démarrer avec Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Confidentialité et cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Conditions d’utilisation |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Annonceurs |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " À propos de nos annonces",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "fr-ch": {
        bannerTextHeadline: "Prise en charge de fin MSN pour les Explorer Internet",
        bannerText: "Pour accéder à MSN et à d’autres expériences personnalisées et attrayantes, commencez à utiliser Microsoft Edge.",
        bannerButtonText: "Démarrer avec Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Confidentialité et cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Conditions d’utilisation |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Annonceurs |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Charte éditoriale |",
                href: "https://www.msn.com/fr-ch/actualite/other/Mentions-légales/ar-BB5xedv"
            },
            {
                Displaytext: " À propos de nos annonces",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "fr-fr": {
        bannerTextHeadline: "Prise en charge de fin MSN pour les Explorer Internet",
        bannerText: "Pour accéder à MSN et à d’autres expériences personnalisées et attrayantes, commencez à utiliser Microsoft Edge.",
        bannerButtonText: "Démarrer avec Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Confidentialité et cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Conditions d’utilisation |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Annonceurs |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Qui sommes-nous? |",
                href: "https://www.msn.com/fr-fr/actualite/microsoftnews/qui-sommes-nous/ar-AA135Z7y"
            },
            {
                Displaytext: " À propos de nos annonces",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "fr-xl": {
        bannerTextHeadline: "Prise en charge de fin MSN pour les Explorer Internet",
        bannerText: "Pour accéder à MSN et à d’autres expériences personnalisées et attrayantes, commencez à utiliser Microsoft Edge.",
        bannerButtonText: "Démarrer avec Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Confidentialité et cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Conditions d’utilisation |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Annonceurs |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " À propos de nos annonces",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "he-il": {
        bannerTextHeadline: "MSN מסיימת את התמיכה ב- Internet Explorer",
        bannerText: "כדי לגשת ל- MSN ולחוויות מרתקות מותאמות אישית אחרות, התחל עם Microsoft Edge.",
        bannerButtonText: "התחל בעבודה עם Microsoft Edge ",
        footerItems: [
            {
                Displaytext: " פרטיות וקובצי Cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " תנאי שימוש |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " פרסם |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " אודות הפרסומות שלנו",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "hi-in": {
        bannerTextHeadline: "MSN Internet Explorer के लिए समर्थन समाप्त कर रहा है",
        bannerText: "MSN और अन्य वैयक्तिकृत, आकर्षक अनुभवों तक पहुँचने के लिए, Microsoft Edge के साथ शुरू करें.",
        bannerButtonText: "Microsoft Edge के साथ शुरू करें",
        footerItems: [
            {
                Displaytext: " गोपनीयता और कुकीज़ |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " उपयोग की शर्तें |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " विज्ञापन करें |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " हमारे ब्रांड के बारे में",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "hu-hu": {
        bannerTextHeadline: "Az MSN hamarosan megszünteti az Internet Explorer támogatását.",
        bannerText: "A MSN és más személyre szabott, érdekes felületek eléréséhez kezdje el használni a Microsoft Edge böngészőt.",
        bannerButtonText: "A Microsoft Edge használatának első lépései",
        footerItems: [
            {
                Displaytext: " Adatvédelem és cookie-k |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Használati feltételek |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Hirdetés közzététele |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " A hirdetéseinkről",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "id-id": {
        bannerTextHeadline: "MSN mengakhiri dukungan untuk Internet Explorer",
        bannerText: "Untuk mengakses MSN dan pengalaman menarik yang dipersonalisasi lainnya, mulai dengan Microsoft Edge.",
        bannerButtonText: "Mulai dengan Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privasi dan Cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Ketentuan Penggunaan |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Beriklan |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Tentang Kami |",
                href: "https://www.msn.com/id-id/berita/nasional/tentang-kami/ar-BBca8ZE"
            },
            {
                Displaytext: " Tentang Iklan Kami",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "it-it": {
        bannerTextHeadline: "MSN termina il supporto per Internet Explorer",
        bannerText: "Per accedere a MSN e ad altre esperienze personalizzate e coinvolgenti, inizia con Microsoft Edge.",
        bannerButtonText: "Introduzione a Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy e cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Condizioni per l'utilizzo |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Messaggio pubblicitario |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Chi siamo |",
                href: "https://www.msn.com/it-it/notizie/microsoftnews/chi-siamo/ar-AA135VD5"
            },
            {
                Displaytext: " Informazioni sulle nostre inserzioni",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "ja-jp": {
        bannerTextHeadline: "MSN は Internet Explorer のサポートを終了します",
        bannerText: "MSN やその他のパーソナライズされた魅力的なエクスペリエンスにアクセスするには、Microsoft Edge を使い始めます。",
        bannerButtonText: "Microsoft Edge を使い始める",
        footerItems: [
            {
                Displaytext: " プライバシーと Cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " 利用規約 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " 広告 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " 広告について",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "ko-kr": {
        bannerTextHeadline: "MSN, Internet Explorer 11에 대한 지원 종료",
        bannerText: "MSN 및 기타 개인 설정된 매력적인 환경에 액세스하려면 Microsoft Edge를 시작하세요.",
        bannerButtonText: "Microsoft Edge 시작",
        footerItems: [
            {
                Displaytext: " 개인정보처리방침 |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " 서비스 계약 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " 광고 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " 광고 정보",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "mr-in": {
        bannerTextHeadline: "MSN हे Internet Explorer साठीचे समर्थन समाप्त करत आहे",
        bannerText: "MSN आणि इतर वैयक्तिकृत, आकर्षक अनुभव ऍक्सेस करण्यासाठी, Microsoft Edge सह प्रारंभ करा.",
        bannerButtonText: "Microsoft Edge सह प्रारंभ करा",
        footerItems: [
            {
                Displaytext: " गोपनीयता आणि कुकीज |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " वापरण्याच्या अटी |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " जाहिरात द्या |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " आमच्या जाहिरातींबद्दल",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "nb-no": {
        bannerTextHeadline: "MSN avslutter støtte for Internet Explorer",
        bannerText: "Kom i gang med Microsoft Edge for å få tilgang til MSN og andre tilpassede, engasjerende opplevelser.",
        bannerButtonText: "Kom i gang med Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Personvern og informasjonskapsler |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Vilkår for bruk |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Annonsere |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Om annonsene våre",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "nl-be": {
        bannerTextHeadline: "MSN beëindigt ondersteuning voor Internet Explorer",
        bannerText: "Ga aan de slag met Microsoft Edge om toegang te krijgen tot MSN en andere persoonlijke, aantrekkelijke ervaringen.",
        bannerButtonText: "Aan de slag met Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy en cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Gebruiksvoorwaarden |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Adverteren |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Over onze advertenties",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "nl-nl": {
        bannerTextHeadline: "MSN beëindigt ondersteuning voor Internet Explorer",
        bannerText: "Ga aan de slag met Microsoft Edge om toegang te krijgen tot MSN en andere persoonlijke, aantrekkelijke ervaringen.",
        bannerButtonText: "Aan de slag met Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy en cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Gebruiksvoorwaarden |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Adverteren |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Over onze advertenties",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "pl-pl": {
        bannerTextHeadline: "Wkrótce usługa MSN zakończy obsługę przeglądarki Internet Explorer",
        bannerText: "Aby uzyskać dostęp do aplikacji MSN i innych spersonalizowanych, atrakcyjnych środowisk, zacznij korzystać z przeglądarki Microsoft Edge.",
        bannerButtonText: "Rozpocznij za pomocą przeglądarki Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Prywatność i pliki cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Warunki użytkowania |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Reklamuj się |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Nasze reklamy — informacje",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "pt-br": {
        bannerTextHeadline: "Suporte final do MSN para o Internet Explorer",
        bannerText: "Para acessar o MSN e outras experiências personalizadas e envolventes, comece a usar o Microsoft Edge.",
        bannerButtonText: "Introdução ao Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "pt-pt": {
        bannerTextHeadline: "O MSN deixou de suportar o Internet Explorer",
        bannerText: "Para aceder ao MSN e a outras experiências personalizadas e envolventes, comece a usar o Microsoft Edge.",
        bannerButtonText: "Comece a usar o Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Privacy and Cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Terms of Use |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Advertise |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " About Our Ads",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "ru-ru": {
        bannerTextHeadline: "MSN завершает поддержку Internet Explorer",
        bannerText: "Чтобы получить доступ к MSN и другим персонализированным интерфейсам, начните работу с Microsoft Edge.",
        bannerButtonText: "Начните работу с Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Конфиденциальность и файлы cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Условия использования |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Реклама |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " 18+ |",
                href: "http://pravo.gov.ru/proxy/ips/?docbody=&link_id=2&nd=102144583&intelsearch=&lastDoc=1"
            },
            {
                Displaytext: " О рекламе",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "sv-se": {
        bannerTextHeadline: "MSN avslutar stöd för Internet Explorer",
        bannerText: "Kom igång med Microsoft Edge för att komma åt MSN och andra personliga, engagerande upplevelser.",
        bannerButtonText: "Kom igång med Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Sekretess och cookies |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Användningsvillkor |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Annonsera |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Om våra annonser",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "te-in": {
        bannerTextHeadline: "Internet Explorerకు MSN ఇస్తున్న మద్దతు త్వరలో ముగిస్తోంది.",
        bannerText: "MSN మరియు ఇతర వ్యక్తిగతీకరించిన, ఆకర్షణీయమైన అనుభవాలను యాక్సెస్ చేయడానికి, Microsoft Edgeతో ప్రారంభించండి.",
        bannerButtonText: "Microsoft Edgeతో ప్రారంభించండి",
        footerItems: [
            {
                Displaytext: " గోప్యత మరియు కుకీలు |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " వాడుక నియమాలు |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " ప్రకటన ఇవ్వండి |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " మా ప్రకటనల గురించి",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "th-th": {
        bannerTextHeadline: "MSN สิ้นสุดการสนับสนุนสําหรับ Internet Explorer",
        bannerText: "เมื่อต้องการเข้าถึง MSN และประสบการณ์ที่ปรับให้เป็นแบบส่วนบุคคลและน่าสนใจอื่นๆ ให้เริ่มต้นใช้งาน Microsoft Edge",
        bannerButtonText: "เริ่มต้นใช้งาน Microsoft Edge",
        footerItems: [
            {
                Displaytext: " ความเป็นส่วนตัวและคุกกี้ |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " ข้อกำหนดการใช้งาน |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " โฆษณา |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " เกี่ยวกับโฆษณาของเรา",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "tr-tr": {
        bannerTextHeadline: "MSN, Internet Explorer desteğini sonlandırıyor",
        bannerText: "MSN’a ve diğer kişiselleştirilmiş ve ilgi çekici deneyimlere erişmek için Microsoft Edge’i kullanmaya başlayın.",
        bannerButtonText: "Microsoft Edge’i Kullanmaya Başlayın",
        footerItems: [
            {
                Displaytext: " Gizlilik ve Tanımlama Bilgileri |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Kullanım Koşulları |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Reklam Ver |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Reklamlarımız Hakkında",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "vi-vn": {
        bannerTextHeadline: "MSN kết thúc hỗ trợ cho Internet Explorer",
        bannerText: "Để truy cập MSN và các trải nghiệm hấp dẫn, được cá nhân hóa khác, hãy bắt đầu với Microsoft Edge.",
        bannerButtonText: "Bắt đầu với Microsoft Edge",
        footerItems: [
            {
                Displaytext: " Quyền riêng tư và Cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " Điều khoản sử dụng |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " Quảng cáo |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " Về quảng cáo của chúng tôi",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "zh-cn": {
        bannerTextHeadline: "MSN 终止对 Internet Explorer 的支持",
        bannerText: "若要访问 MSN 和其他个性化、极具吸引力的体验，请开始使用 Microsoft Edge。",
        bannerButtonText: "开始使用 Microsoft Edge",
        footerItems: [
            {
                Displaytext: " 隐私与 Cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " 使用条款 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " 广告 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " 关于我们的广告",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "zh-hk": {
        bannerTextHeadline: "Internet Explorer 將終止對 MSN 的支援",
        bannerText: "若要存取 MSN 和其他個人化且吸引人的體驗，請開始使用 Microsoft Edge。",
        bannerButtonText: "開始使用 Microsoft Edge",
        footerItems: [
            {
                Displaytext: " 隱私權與 Cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " 使用條款 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " 廣告 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " 關於我們的廣告",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    },
    "zh-tw": {
        bannerTextHeadline: "Internet Explorer 將終止對 MSN 的支援",
        bannerText: "若要存取 MSN 和其他個人化且吸引人的體驗，請開始使用 Microsoft Edge。",
        bannerButtonText: "開始使用 Microsoft Edge",
        footerItems: [
            {
                Displaytext: " 隱私權與 Cookie |",
                href: "http://go.microsoft.com/fwlink/?LinkId=521839"
            },
            {
                Displaytext: " 使用條款 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=246338"
            },
            {
                Displaytext: " 廣告 |",
                href: "http://go.microsoft.com/fwlink/?LinkID=2003950"
            },
            {
                Displaytext: " 關於我們的廣告",
                href: "https://go.microsoft.com/fwlink/?LinkID=286759"
            }
        ]
    }
};
//# sourceMappingURL=Localisation.js.map