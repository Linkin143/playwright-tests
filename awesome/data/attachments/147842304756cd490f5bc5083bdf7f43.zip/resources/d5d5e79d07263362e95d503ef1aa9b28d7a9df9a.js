"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["rich-calendar-component-spotlight"],{34301(e,i,o){o.r(i),o.d(i,{RichCalendarSpotlightBook(){return C}});var t=o(56911),a=o(92011),n=o(60815),r=o(85657),l=o(11363),s=o(58792),d=o(12197),v=o(70828);class c extends a.L{richCalendarCardChanged(e,i){i&&(this.todayDateInfo=i.todayDateInfo,this.generateBookData())}get currentMarket(){return s.T3.CurrentMarket}get weekday(){var e;return d.VJ(null===(e=this.todayDateInfo)||void 0===e?void 0:e.Date)}get day(){var e;return null===(e=this.todayDateInfo)||void 0===e||null===(e=e.Date)||void 0===e?void 0:e.Day}get dateOrScore(){var e,i,o,t;return null!==(e=this.todayDateInfo)&&void 0!==e&&null!==(e=e.Book)&&void 0!==e&&e.Score&&(null===(i=this.todayDateInfo)||void 0===i||null===(i=i.Book)||void 0===i?void 0:i.Score)>0?{firstLine:null===(o=this.bookData)||void 0===o?void 0:o.score,secondLine:null===(t=this.strings)||void 0===t?void 0:t.scoreTitle}:this.day&&this.weekday?{firstLine:this.day,secondLine:this.weekday}:null}get strings(){var e;const i=(null===(e=this.richCalendarCard)||void 0===e||null===(e=e.config)||void 0===e?void 0:e.BookSpotlightStrings)??"",[o,t,a]=i.split(/[_]/);return{scoreTitle:o,releaseDate:t,authorTitle:a}}generateBookData(){var e,i,o;const{Image:t="",Title:a="",ReleaseDate:n,ScoreStr:s,Text:d="",URL:c,Author:p=""}=(null===(e=this.todayDateInfo)||void 0===e?void 0:e.Book)??{};this.bookData={imageUrl:v.n(t,{width:86,height:0}),bookTitle:a,bookReleaseDate:`${null===(i=this.strings)||void 0===i?void 0:i.releaseDate}：${n}`,bookQuote:d,score:s??"0",telemetry:(0,l.IW)(r.kj.BookSpotlight,a),targetUrl:c??"",bookAuthor:`${null===(o=this.strings)||void 0===o?void 0:o.authorTitle}：${p}`}}}(0,t.Cg)([n.sH],c.prototype,"richCalendarCard",void 0),(0,t.Cg)([n.Jg],c.prototype,"dateOrScore",null);var p=o(74849),h=o(22131),u=o(12640);const x=`${r.r$}latest/richcalendar/img/quotation.svg`,g=p.A`
.calendar-datetime,
.book-title,
.book-release-detail {
    color: #FFFFFF;
}
`,m=p.A`
.calendar-datetime,
.book-title {
    color: #333333;
}
.book-release-detail {
    color: #666666;
}
`;var f=p.A`
    a {
        text-decoration: none;
        color: inherit;
    }
    .book-container {
        position: absolute;
        z-index: 2;
        width: 300px;
        height: 256px;
        top: 48px;
        left: 0;
        box-sizing: border-box;
        padding: 0 12px;
    }
    .book-cover-container {
        background: linear-gradient(180deg, #1E7671 -47.7%, #00A99F 100%);
        width: 100%;
        height: 152px;
        position: relative;
        z-index: 1;
        overflow: hidden;
        border-radius: 10px;
        display: flex;
        box-sizing: border-box;
        padding: 0 20px 0 12px;
    }
    .book-image-container {
        width: 86px;
        height: 100%;
        display: flex;
        margin-right: 8px;
    }
    .book-image {
        background: red;
        margin: auto;
        border-radius: 6px;
        width: 86px;
        max-height: 128px;
        z-index: -1;
    }
    .book-description-container {
        display: flex;
    }
    .book-description {
        margin: auto;
        padding-left: 10px;
        position: relative;
    }
    .quote-icon {
        -webkit-mask-image:url(${x});
        mask-image: url(${x});
        mask-repeat: no-repeat;
        -webkit-mask-position: center;
        mask-position: center;
        -webkit-mask-size: 100% 100%;
        mask-size: 100% 100%;
        width: 36px;
        height: 22px;
        position: absolute;
        left: -3px;
        top: -9px;
        z-index: 0;
        background: #ffffff;
        opacity: 0.1;
    }
    .book-quote {
        width: 140px;
        font-size: 14px;
        line-height: 20px;
        font-weight: 500;
        font-style: normal;
        overflow: hidden;
        text-overflow: ellipsis;
        z-index: 1;
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        color: #ffffff;
    }
    .book-details-container {
        width: 100%;
        padding-right: 4px;
        display: flex;
        justify-content: space-between;
        box-sizing: border-box;
    }
    .book-details {
        flex: 1;
        display: flex;
        flex-direction: column;
        margin-top: 11px;
        min-height: 60px;
        justify-content: center;
        overflow: hidden;

        span {
            font-style: normal;
            line-height: 16px;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
        }
        .book-title {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 4px;
        }
        .book-release-detail {
            font-size: 12px;
            font-weight: 400;
            margin: 4px 0 0 4px;
        }
    }
    .calendar-datetime {
        min-width: 50px;
        text-align: center;

        span {
            display: block;
        }
        .date-label {
            font-size: 44px;
            font-style: normal;
            font-weight: 600;
            letter-spacing: -0.4px;
            line-height: 52px;
        }
        .weekday-label {
            font-size: 14px;
            font-style: normal;
            font-weight: 400;
            line-height: 20px;
            letter-spacing: 0.28px;
        }
    }
    `.withBehaviors(new u.N(m,g),(0,h.G2)(g)),b=o(96950),w=o(69259);const k=b.qy`<div class="book-cover-container"><div class="book-image-container"><img src="${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.imageUrl}}" alt="${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.bookTitle}}" class="book-image" /></div><div class="book-description-container"><div class="book-description"><i class="quote-icon"></i><span class="book-quote" title="${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.bookQuote}}">${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.bookQuote}}</span></div></div></div>`,$=b.qy`<div class="calendar-datetime"><span class="date-label">${e=>{var i;return null===(i=e.dateOrScore)||void 0===i?void 0:i.firstLine}}</span><span class="weekday-label">${e=>{var i;return null===(i=e.dateOrScore)||void 0===i?void 0:i.secondLine}}</span></div>`,y=b.qy`<div class="book-details-container"><div class="book-details"><span class="book-title" title="${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.bookTitle}}">${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.bookTitle}}</span><span class="book-release-detail" title="${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.bookAuthor}}">${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.bookAuthor}}</span><span class="book-release-detail" title="${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.bookReleaseDate}}">${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.bookReleaseDate}}</span></div>${(0,w.z)(e=>e.dateOrScore&&e.dateOrScore.firstLine&&e.dateOrScore.secondLine,$)}</div>`;var z=b.qy`<a class="book-container"} href="${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.targetUrl}}" data-t="${e=>{var i;return null===(i=e.bookData)||void 0===i?void 0:i.telemetry}}" target="_blank" rel="noopener noreferrer">${k} ${y}</a>`;let C=class extends c{};C=(0,t.Cg)([(0,a.E)({name:"rich-calendar-spotlight-book",template:z,styles:f,shadowOptions:{delegatesFocus:!0}})],C)},82557(e,i,o){o.r(i),o.d(i,{RichCalendarSpotlightMovie(){return T}});var t=o(56911),a=o(92011),n=o(60815),r=o(12197),l=o(70828),s=o(47018),d=o(11363),v=o(85657),c=o(58792),p=o(27233);s.f;class h extends a.L{richCalendarCardChanged(e,i){i&&(this.todayDateInfo=i.todayDateInfo,this.generateMovieData())}get weekday(){var e;return r.VJ(null===(e=this.todayDateInfo)||void 0===e?void 0:e.Date)}get day(){var e;return null===(e=this.todayDateInfo)||void 0===e||null===(e=e.Date)||void 0===e?void 0:e.Day}get textColorMode(){var e;return null===(e=this.movieData)||void 0===e?void 0:e.movieQuoteMode}get strings(){var e;const i=(null===(e=this.richCalendarCard)||void 0===e||null===(e=e.config)||void 0===e?void 0:e.MovieSpotlightStrings)??"",[o,t,a]=i.split(/[_]/);return{scoreTitle:o,releaseDate:t,scoreStandards:a}}get config(){var e;return null===(e=this.richCalendarCard)||void 0===e?void 0:e.config}get showStarIndentation(){return c.T3.CurrentMarket===p.gU}get dateOrScore(){var e,i,o,t;return null!==(e=this.movieData)&&void 0!==e&&e.score&&Number(null===(i=this.movieData)||void 0===i?void 0:i.score)>0?{firstLine:null===(o=this.movieData)||void 0===o?void 0:o.score,secondLine:null===(t=this.strings)||void 0===t?void 0:t.scoreTitle}:null}get movieReleaseAndDuration(){var e,i;let o="";return null!==(e=this.movieData)&&void 0!==e&&e.movieReleaseDate&&(o+=this.movieData.movieReleaseDate),null!==(i=this.movieData)&&void 0!==i&&i.movieDuration&&(o+=` · ${this.movieData.movieDuration}`),o}generateMovieData(){var e;const{Image:i="",Text:o,TextColor:t,TextBackgroundColor:a="",Title:n="",ReleaseDate:r,ScoreStr:s,Duration:c="",URL:p}=(null===(e=this.todayDateInfo)||void 0===e?void 0:e.Movie)??{};this.movieData={imageUrl:l.n(i,{width:276,height:152}),movieQuote:(null==o?void 0:o[0])??"",movieTitle:n,movieQuoteMode:t,movieReleaseDate:`${this.strings.releaseDate}：${r}`,movieDuration:c,imageOverlayColor:a,score:s??"0",telemetry:(0,d.IW)(v.kj.MovieSpotlight,n),targetUrl:p??""}}}(0,t.Cg)([n.sH],h.prototype,"richCalendarCard",void 0),(0,t.Cg)([n.Jg],h.prototype,"dateOrScore",null),(0,t.Cg)([n.Jg],h.prototype,"movieReleaseAndDuration",null);var u=o(74849),x=o(4126),g=o(22131),m=o(12640),f=o(76346);const b=`${v.r$}latest/richcalendar/img/quotation.svg`,w=u.A`
.calendar-datetime,
.movie-title,
.movie-release-date {
    color: #FFFFFF;
}
`,k=u.A`
.calendar-datetime,
.movie-title {
    color: #333333;
}
.movie-release-date,
.score-text {
    color: #666666;
}
`;var $=u.A`
    a {
        text-decoration: none;
        color: inherit;
    }
    .movie-container {
        position: absolute;
        z-index: 2;
        width: 300px;
        height: 256px;
        top: 48px;
        left: 0;
        box-sizing: border-box;
        padding: 0 12px;

        .movie-quote {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
    }
    .movie-image-container {
        width: 100%;
        height: 152px;
        position: relative;
        z-index: 1;
        overflow: hidden;
        border-radius: 10px;
        padding: 8px 12px;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        box-sizing: border-box;
    }
    .movie-image-background {
        position: absolute;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        z-index: -1;
    }
    .movie-image-overlay {
        position: absolute;
        z-index: -1;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 80px;
        background-blend-mode: overlay;
    }
    .movie-image-overlay-text {
        padding: 0 12px 10px 12px;
        position: absolute;
        z-index: -1;
        left: 0;
        bottom: 0;
        display: flex;
        align-items: center;
    }
    .quote-icon {
        -webkit-mask-image:url(${b});
        mask-image: url(${b});
        mask-repeat: no-repeat;
        -webkit-mask-position: center;
        mask-position: center;
        -webkit-mask-size: 100% 100%;
        mask-size: 100% 100%;
        width: 41px;
        height: 26px;
        position: absolute;
        top: -11px;
        left: 3px;
        z-index: 0;
        background: #ffffff;
        opacity: 0.3;
    }
    .movie-quote {
        width: 252px;
        font-size: 14px;
        line-height: 20px;
        font-weight: 500;
        font-style: normal;
        letter-spacing: -0.14px;
        overflow: hidden;
        text-overflow: ellipsis;
        z-index: 1;
    }
    .movie-details-container {
        width: 100%;
        padding-right: 4px;
        display: flex;
        justify-content: space-between;
        box-sizing: border-box;
    }
    .movie-star-indentation {
      --star-box-padding: 3px;
    }
    .movie-details {
        flex: 1;
        display: flex;
        flex-direction: column;
        margin-top: 11px;
        min-height: 60px;
        justify-content: center;
        overflow: hidden;

        span {
            font-style: normal;
            line-height: 16px;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
        }
        .movie-title {
            font-size: 14px;
            font-weight: var(--movie-title-weight, 600);
            margin-bottom: 4px;
            padding-left: var(--movie-title-padding, 3px);
        }
        .movie-release-date {
            font-size: 12px;
            font-weight: 400;
            margin: 4px 0 0 4px;
        }
    }
    .calendar-datetime {
        min-width: 50px;
        text-align: center;

        span {
            display: block;
        }
        .date-label {
            font-size: 44px;
            font-style: normal;
            font-weight: 600;
            letter-spacing: -0.4px;
            line-height: 52px;
        }
        .weekday-label {
            font-size: 14px;
            font-style: normal;
            font-weight: 400;
            line-height: 20px;
            letter-spacing: 0.28px;
        }
    }
    .stars-container {
        display: flex;
        align-items: center;
        gap: 8px;

        rich-calendar-star {
            --star-size: 20px;
        }
        .score-text {
            font-size: 12px;
            font-weight: 400;
        }
    }
    `.withBehaviors(new x.o("textColorMode",f.$h.Dark,u.A`
            .movie-quote {
                color: #333333
            }
        `),new x.o("textColorMode",f.$h.Light,u.A`
            .movie-quote {
                color: #F5F5F5;
            }
        `),new m.N(k,w),(0,g.G2)(w)),y=o(96950),z=o(69259),C=o(94043);const F=y.qy`<div class="stars-container"><rich-calendar-star :scoreStandards="${e=>e.strings.scoreStandards}" :score="${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.score}}"></rich-calendar-star></div>`,q=y.qy`<div class="movie-image-container"><img class="movie-image-background" src="${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.imageUrl}}" alt="${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.movieTitle}}" />${(0,z.z)(e=>{var i;return(0,C.S)()&&(null===(i=e.movieData)||void 0===i?void 0:i.movieQuote)},y.qy`<div class="movie-image-overlay" style="background-image: linear-gradient(180deg, rgba(${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.imageOverlayColor}}, 0.00) 0%, rgba(${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.imageOverlayColor}}, 0.70) 47.03%);"></div><div class="movie-image-overlay-text"><i class="quote-icon"></i><span class="movie-quote" title="${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.movieQuote}}">${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.movieQuote}}</span></div `)}</div>`,D=y.qy`<div class="calendar-datetime"><span class="date-label">${e=>{var i;return null===(i=e.dateOrScore)||void 0===i?void 0:i.firstLine}}</span><span class="weekday-label">${e=>{var i;return null===(i=e.dateOrScore)||void 0===i?void 0:i.secondLine}}</span></div>`,S=y.qy`<div class=${e=>e.showStarIndentation?"movie-details-container movie-star-indentation":"movie-details-container"}><div class="movie-details"><span class="movie-title" title="${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.movieTitle}}">${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.movieTitle}}</span>${(0,z.z)(e=>{var i,o;return e.movieData&&(null===(i=e.movieData)||void 0===i?void 0:i.score)&&Number(null===(o=e.movieData)||void 0===o?void 0:o.score)>0},F)}<span class="movie-release-date" title="${e=>e.movieReleaseAndDuration}">${e=>e.movieReleaseAndDuration}</span></div>${(0,z.z)(e=>e.dateOrScore&&e.dateOrScore.firstLine&&e.dateOrScore.secondLine,D)}</div>`;var R=y.qy`<a class="movie-container"} href="${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.targetUrl}}" data-t="${e=>{var i;return null===(i=e.movieData)||void 0===i?void 0:i.telemetry}}" target="_blank" rel="noopener noreferrer">${q} ${S}</a>`;let T=class extends h{};T=(0,t.Cg)([(0,a.E)({name:"rich-calendar-spotlight-movie",template:R,styles:$,shadowOptions:{delegatesFocus:!0}})],T)},91855(e,i,o){o.r(i),o.d(i,{RichCalendarSpotlightHoroscope(){return A}});var t=o(56911),a=o(92011),n=o(60815),r=o(19700),l=o(47018),s=o(21038),d=o(51467),v=o(85657),c=o(11363),p=o(58792),h=o(27233);l.f,s.l;class u extends a.L{constructor(){super(...arguments),this.horoscopeContent=[],this.horoscopeList=[]}get currentMarket(){return p.T3.CurrentMarket}get illustrationUrl(){var e,i;return null!==(e=this.nowHoroscope)&&void 0!==e&&e.Id?`${v.r$}latest/richcalendar/img/horoscope/${null===(i=this.nowHoroscope)||void 0===i?void 0:i.Id}_tbr${this.currentMarket===h.oQ?"_nooverlay":""}.png`:""}get strings(){var e;return null===(e=this.richCalendarCard)||void 0===e?void 0:e.strings}get telemetryDataContainer(){var e;return(0,c.IW)(v.kj.HoroscopeSpotlight,null===(e=this.nowHoroscope)||void 0===e?void 0:e.Id)}get overwriteIndex(){var e;const i=Number(null===(e=this.richCalendarCard)||void 0===e||null===(e=e.previewType)||void 0===e?void 0:e.subEventIndex);return isNaN(i)?void 0:i}get horoscopeDropdownListPosition(){return d.Nd.Top}richCalendarCardChanged(e,i){i&&this.generateHoroscopeData()}handleHoroscopeChange(e){this.nowHoroscope&&(this.nowHoroscope.isSelected=!1,this.nowHoroscope=this.horoscopeList[e.index],this.nowHoroscope.isSelected=!0,this.horoscopeHandler&&(this.horoscopeContent=this.horoscopeHandler.generateFortuneDetail(this.nowHoroscope)))}generateHoroscopeData(){var e;const i=null===(e=this.richCalendarCard)||void 0===e||null===(e=e.contentData)||void 0===e?void 0:e.TodayInfo;this.horoscopeHandler=new r.A(this.strings);const{list:o,index:t}=this.horoscopeHandler.generateHoroscopeDataByV2(i,this.overwriteIndex);this.horoscopeList=o,this.nowHoroscope=this.horoscopeList[t],this.horoscopeContent=this.horoscopeHandler.generateFortuneDetail(this.nowHoroscope)}}(0,t.Cg)([n.sH],u.prototype,"richCalendarCard",void 0),(0,t.Cg)([n.sH],u.prototype,"nowHoroscope",void 0),(0,t.Cg)([n.sH],u.prototype,"horoscopeContent",void 0),(0,t.Cg)([n.Jg],u.prototype,"illustrationUrl",null);var x=o(74849),g=o(4126),m=o(12640),f=o(22131);const b=`${v.r$}latest/richcalendar/img/quotation.svg`,w=x.A`
    .horoscope-today-fortune span,
    .horoscope-item-name,
    .horoscope-item-value,
    .horoscope-item-text {
        color: #FFFFFF;
    }
`,k=x.A`
    .horoscope-today-fortune span {
        color: #333333;
    }
    .horoscope-item-name {
        color: #1A1A1A;
    }
    .horoscope-item-value,
    .horoscope-item-text {
        color: #000000;
    }
`;var $=x.A`
    a {
        text-decoration: none;
        color: inherit;
    }
    .horoscope-container {
        position: absolute;
        z-index: 10;
        width: 300px;
        height: 256px;
        top: 48px;
        left: 0;
        box-sizing: border-box;
        padding: 0 12px;
    }
    .horoscope-image-container {
        width: 100%;
        height: 152px;
        position: relative;
        z-index: 1;
        overflow: hidden;
        border-radius: 10px;
        padding: 8px 12px;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        box-sizing: border-box;
    }
    .horoscope-image-background {
        position: absolute;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        z-index: -1;
    }
    .quote-icon {
        -webkit-mask-image:url(${b});
        mask-image: url(${b});
        mask-repeat: no-repeat;
        -webkit-mask-position: center;
        mask-position: center;
        -webkit-mask-size: 100% 100%;
        mask-size: 100% 100%;
        width: 41px;
        height: 26px;
        position: absolute;
        bottom: 16px;
        left: 5px;
        z-index: -1;
        background: #ffffff;
        opacity: 0.1;
    }
    .horoscope-quote {
        color: #F5F5F5;
        font-size: 16px;
        font-style: normal;
        font-weight: 700;
        line-height: 24px;
        letter-spacing: -0.16px;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .horoscope-details-container {
        width: 100%;
        padding: 0 4px;
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        box-sizing: border-box;
    }
    .horoscope-today-fortune {
        width: 60px;
        display: inline-flex;
        flex-direction: column;
        align-items: center;
        gap: -10px;

        span {
            font-style: normal;
            line-height: normal;
        }
        .today-fortune {
            font-size: 40px;
            font-weight: 600;
            letter-spacing: -0.4px;
        }
        .today-fortune-label {
            font-size: 14px;
            font-weight: 700;
        }
    }
    .horoscope-today-sort {
        display: flex;
        align-items: flex-end;
        align-self: flex-end;

        .today-sort {
            font-size: 40px;
            font-weight: 600;
            line-height: 40px;
            font-style: normal;
        }
        .today-sort-label {
            font-size: 14px;
            font-weight: 700;
            line-height: 20px;
            font-style: normal;
        }
    }
    .horoscope-details {
        margin-top: 10px;
        height: 60px;
        width: 196px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items: flex-start;
        flex-shrink: 0;
    }
    rich-calendar-horoscope-selection {
        font-size: 16px;
        font-style: normal;
        font-weight: 600;
        line-height: 22px;
    }
    .horoscope-detail {
        width: 100%;
        display: flex;
        justify-content: space-between;
    }
    .horoscope-item-text {
        font-size: 12px;
        line-height: 16px;
        font-weight: 400;
        font-style: normal;
        overflow: hidden;
        -webkit-line-clamp: 2;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        text-overflow: ellipsis;
    }
    .horoscope-item {
        .horoscope-item-name {
            display: block;
            font-size: 12px;
            line-height: 16px;
            font-weight: 400;
            font-style: normal;
        }
        .horoscope-item-value {
            display: block;
            font-size: 10px;
            line-height: 14px;
            font-weight: 400;
            font-style: normal;
            max-width: 60px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        rich-calendar-star {
            margin-top: 2px;
            display: block;
            --star-size: 12px;
        }
    }
`.withBehaviors(new g.o("currentMarket",h.CR,x.A`
        rich-calendar-horoscope-selection {
            --horoscope-ddl-width: 215px;
        }
    `),new m.N(k,w),(0,f.G2)(w)),y=o(96950),z=o(69259),C=o(39957);const F=y.qy`<div class="horoscope-item" aria-label="${e=>`${e.name}：${e.value}`}" tabindex="0"><span class="horoscope-item-name">${e=>e.name}</span><rich-calendar-star :score="${e=>e.rate}"></rich-calendar-star></div>`,q=y.qy`<div class="horoscope-image-container"><img class="horoscope-image-background" src="${e=>e.illustrationUrl}" alt="${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.Name}}" />${(0,z.z)(e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.SpotlightTitle},y.qy`<i class="quote-icon"></i><span class="horoscope-quote" title="${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.SpotlightTitle}}">${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.SpotlightTitle}}</span>`)}</div>`,D=y.qy`<div class="horoscope-item-text" aria-label="${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.TodayFortuneText}}" tabindex="0">${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.TodayFortuneText}}</div>`,S=y.qy`<div class="horoscope-detail">${(0,C.ux)(e=>e.horoscopeContent,F)}<div class="horoscope-item" title="${v.FH.HoroscopeLuckyItemLabelKoKr}：${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.LuckyItem}}" aria-label="${v.FH.HoroscopeLuckyItemLabelKoKr}：${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.LuckyItem}}" tabindex="0"><span class="horoscope-item-name">${v.FH.HoroscopeLuckyItemLabelKoKr}</span><span class="horoscope-item-value">${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.LuckyItem}}</span></div></div>`,R=y.qy`<div class="horoscope-detail">${(0,C.ux)(e=>e.horoscopeContent,F)}</div>`,T=y.qy`<div class="horoscope-today-sort" aria-label="${e=>{var i,o;return`${null===(i=e.strings)||void 0===i?void 0:i.todayFortune} ${null===(o=e.nowHoroscope)||void 0===o?void 0:o.TodayFortune}`}}" tabindex="0"><span class="today-sort">${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.TodayFortune}}</span><span class="today-sort-label">位</span></div>`,L=y.qy`<div class="horoscope-today-fortune" aria-label="${e=>{var i,o;return`${null===(i=e.strings)||void 0===i?void 0:i.todayFortune} ${null===(o=e.nowHoroscope)||void 0===o?void 0:o.TodayFortune}`}}" tabindex="0"><span class="today-fortune">${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.TodayFortune}}</span><span class="today-fortune-label">${e=>{var i;return null===(i=e.strings)||void 0===i?void 0:i.todayFortune}}</span></div>`,j=y.qy`<div class="horoscope-details-container"><div class="horoscope-details"><rich-calendar-horoscope-selection :richCalendarCard="${e=>e.richCalendarCard}" :selectedHoroscope="${e=>e.nowHoroscope}" :horoscopeList="${e=>e.horoscopeList}" :selectedIndex="${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.index}}" :position="${e=>e.horoscopeDropdownListPosition}" @change="${(e,i)=>e.handleHoroscopeChange(i.event.detail)}"></rich-calendar-horoscope-selection>${e=>(e=>{switch(e.currentMarket){case h.oQ:return D;case h.CR:return S;default:return R}})(e)}</div>${e=>(e=>e.currentMarket===h.oQ?T:L)(e)}</div>`;var M=y.qy`<a class="horoscope-container" href="${e=>{var i;return null===(i=e.nowHoroscope)||void 0===i?void 0:i.Url}}" data-t="${e=>e.telemetryDataContainer}" target="_blank" rel="noopener noreferrer">${q} ${j}</a>`;let A=class extends u{};A=(0,t.Cg)([(0,a.E)({name:"rich-calendar-spotlight-horoscope",template:M,styles:$,shadowOptions:{delegatesFocus:!0}})],A)}}]);