// © Microsoft Corporation. All rights reserved.
export const desktopConfig = {
    defaultAdPlacementConfig: {
        adName: "banner1",
        height: 90,
        width: 728
    },
    "ar-ae": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNAEAR15"
            }
        ]
    },
    "ar-eg": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNEGAR15"
            }
        ]
    },
    "ar-sa": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNSAAR15"
            }
        ]
    },
    "bn-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNINBN12"
            }
        ]
    },
    "da-dk": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNDKDA15"
            }
        ]
    },
    "de-at": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNATDE15"
            }
        ]
    },
    "de-ch": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNCHDE15"
            }
        ]
    },
    "de-de": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNDEDE12"
            }
        ]
    },
    "el-gr": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNGREL15"
            }
        ]
    },
    "en-ae": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNAEEN12"
            }
        ]
    },
    "en-au": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNAUEN15"
            }
        ]
    },
    "en-ca": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNCAEN12"
            }
        ]
    },
    "en-gb": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNUKEN12"
            }
        ]
    },
    "en-ie": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNIEEN15"
            }
        ]
    },
    "en-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNINEN15"
            }
        ]
    },
    "en-my": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNMYEN15"
            }
        ]
    },
    "en-nz": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNNZEN12"
            }
        ]
    },
    "en-ph": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNPHEN15"
            }
        ]
    },
    "en-sg": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNSGEN15"
            }
        ]
    },
    "en-us": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNUSEN15"
            }
        ]
    },
    "en-xl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNXLEN12"
            }
        ]
    },
    "en-za": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNZAEN12"
            }
        ]
    },
    "es-ar": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNARES15"
            }
        ]
    },
    "es-cl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNCLES15"
            }
        ]
    },
    "es-co": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNCOES15"
            }
        ]
    },
    "es-es": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNESES15"
            }
        ]
    },
    "es-mx": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNMXES15"
            }
        ]
    },
    "es-pe": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNPEES15"
            }
        ]
    },
    "es-us": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNUSES12"
            }
        ]
    },
    "es-ve": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNVEES15"
            }
        ]
    },
    "es-xl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSN99ES15"
            }
        ]
    },
    "fi-fi": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNFIFI15"
            }
        ]
    },
    "fr-be": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNBEFR15"
            }
        ]
    },
    "fr-ca": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNCAFR12"
            }
        ]
    },
    "fr-ch": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNCHFR15"
            }
        ]
    },
    "fr-fr": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNFRFR15"
            }
        ]
    },
    "fr-xl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNXLFR12"
            }
        ]
    },
    "he-il": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNILIW15"
            }
        ]
    },
    "hi-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNHIIN12"
            }
        ]
    },
    "hu-hu": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNHUHU12"
            }
        ]
    },
    "id-id": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNIDID15"
            }
        ]
    },
    "it-it": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNITIT15"
            }
        ]
    },
    "ja-jp": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNJPJA12"
            }
        ]
    },
    "ko-kr": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNKRKO15"
            }
        ]
    },
    "mr-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNINMR12"
            }
        ]
    },
    "nb-no": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNNONO15"
            }
        ]
    },
    "nl-be": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNBENL15"
            }
        ]
    },
    "nl-nl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNNLNL15"
            }
        ]
    },
    "pl-pl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNPLPL15"
            }
        ]
    },
    "pt-br": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNBRPT12"
            }
        ]
    },
    "pt-pt": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNPTPT15"
            }
        ]
    },
    "ru-ru": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNRURU15"
            }
        ]
    },
    "ru-xl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNXLRU12"
            }
        ]
    },
    "sv-se": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNSESV15"
            }
        ]
    },
    "te-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNINTE12"
            }
        ]
    },
    "th-th": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNTHTH15"
            }
        ]
    },
    "tr-tr": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNTRTR15"
            }
        ]
    },
    "vi-vn": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNVNVI12"
            }
        ]
    },
    "zh-hk": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNHKZH15"
            }
        ]
    },
    "zh-tw": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MSNTWZH15"
            }
        ]
    }
};
export const mobileConfig = {
    defaultAdPlacementConfig: {
        adName: "banner1",
        height: 50,
        width: 320
    },
    "ar-ae": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNAEAR12"
            }
        ]
    },
    "ar-eg": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNEGAR12"
            }
        ]
    },
    "ar-sa": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNSAAR12"
            }
        ]
    },
    "bn-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNINBN12"
            }
        ]
    },
    "cz-cs": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNCSCZ12"
            }
        ]
    },
    "da-dk": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNDKDA12"
            }
        ]
    },
    "de-at": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNATDE12"
            }
        ]
    },
    "de-ch": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNCHDE12"
            }
        ]
    },
    "de-de": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNDEDE12"
            }
        ]
    },
    "el-gr": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNGREL12"
            }
        ]
    },
    "en-ae": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNAEEN12"
            }
        ]
    },
    "en-au": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNAUEN12"
            }
        ]
    },
    "en-ca": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNCAEN12"
            }
        ]
    },
    "en-gb": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNUKEN12"
            }
        ]
    },
    "en-ie": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNIEEN12"
            }
        ]
    },
    "en-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNINEN12"
            }
        ]
    },
    "en-my": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNMYEN12"
            }
        ]
    },
    "en-nz": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNNZEN12"
            }
        ]
    },
    "en-ph": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNPHEN12"
            }
        ]
    },
    "en-sg": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNSGEN12"
            }
        ]
    },
    "en-us": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNUSEN12"
            }
        ]
    },
    "en-xl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNXLEN12"
            }
        ]
    },
    "en-za": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNZAEN12"
            }
        ]
    },
    "es-ar": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNARES12"
            }
        ]
    },
    "es-cl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNCLES12"
            }
        ]
    },
    "es-co": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNCOES12"
            }
        ]
    },
    "es-es": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNESES12"
            }
        ]
    },
    "es-mx": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNMXES12"
            }
        ]
    },
    "es-pe": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNPEES12"
            }
        ]
    },
    "es-us": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNUSES12"
            }
        ]
    },
    "es-ve": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNVEES12"
            }
        ]
    },
    "es-xl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSN99ES12"
            }
        ]
    },
    "fi-fi": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNFIFI12"
            }
        ]
    },
    "fr-be": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNBEFR12"
            }
        ]
    },
    "fr-ca": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNCAFR12"
            }
        ]
    },
    "fr-ch": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNCHFR12"
            }
        ]
    },
    "fr-fr": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNFRFR12"
            }
        ]
    },
    "fr-xl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNXLFR12"
            }
        ]
    },
    "he-il": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNILIW12"
            }
        ]
    },
    "hi-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNHIIN12"
            }
        ]
    },
    "hu-hu": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNHUHU12"
            }
        ]
    },
    "id-id": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNIDID12"
            }
        ]
    },
    "it-it": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNITIT12"
            }
        ]
    },
    "ja-jp": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNJPJA12"
            }
        ]
    },
    "ko-kr": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNKRKO12"
            }
        ]
    },
    "mr-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNINMR12"
            }
        ]
    },
    "nl-be": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNBENL12"
            }
        ]
    },
    "nl-nl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNNLNL12"
            }
        ]
    },
    "no-no": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNNONO12"
            }
        ]
    },
    "pl-pl": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNPLPL12"
            }
        ]
    },
    "pt-br": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNBRPT12"
            }
        ]
    },
    "pt-pt": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNPTPT12"
            }
        ]
    },
    "ru-ru": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNRURU12"
            }
        ]
    },
    "sv-se": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNSESV12"
            }
        ]
    },
    "te-in": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNINTE12"
            }
        ]
    },
    "th-th": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNTHTH12"
            }
        ]
    },
    "tr-tr": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNTRTR12"
            }
        ]
    },
    "vi-vn": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNVNVI12"
            }
        ]
    },
    "zh-hk": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNHKZH12"
            }
        ]
    },
    "zh-tw": {
        adPlacements: [
            {
                adName: "banner1",
                pageGroup: "MMSNTWZH12"
            }
        ]
    }
};
//# sourceMappingURL=displayAdConfig.js.map