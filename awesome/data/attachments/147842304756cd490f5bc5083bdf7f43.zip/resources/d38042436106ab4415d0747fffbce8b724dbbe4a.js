"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-augment-card"],{15943(t,e,i){i.r(e),i.d(e,{SportsAugmentCard(){return h},SportsAugmentCardStyles(){return M},SportsAugmentCardTemplate(){return C},ToolingInfo(){return N}});var n=i(56911),r=(i(43365),i(60815)),o=i(12680),a=i(23587),s=i(39671),l=i(507),d=i(54229),c=i(93552),g=i(47441),m=i(2171);class u extends g.N${static getInstance(t,e){const i=`SportsAugmentDataTransformer_${t}`,n=m.vv.get(i,()=>({}));return n[i]||(n[i]=new u("SportsAugmentCard",t,e)),n[i]}tagNameToComponentName(t){var e;if(null===(e=this.config)||void 0===e||!e.tagToComponentNameMap)throw new Error("tagToComponentNameMap is not defined in config");return this.config.tagToComponentNameMap[t]||null}}const p={sportsAugmentShown:"SportsAugmentShown",sportsAugmentType:"SportsAugmentType-{0}_{1}",sportsAugmentArticleID:"SportsAugmentArticle-{0}"};class h extends s.U{constructor(){super(...arguments),this.cardId="",this.augmentType="",this.isFirstViewReady=!1,this.ensureObservableBeforeConnect=!0,this.parseFeedData=t=>d.aC.safeExecute(()=>JSON.parse(t),void 0,c.FKe,"SportsAugmentCard - error parsing feed data",`Article ID: ${this.cardId}`),this.generateAugmentView=async t=>{const e=this.getSportsMatchAugmentItem(t);if(e)return await d.aC.safeExecuteAsync(async()=>{const i=u.getInstance(`${a.tX.SportsAugment}_${this.cardId}`,this.transformationContext);if(!i)throw new Error("Could not get SportsAugmentDataTransformer instance");return await i.generateView({cardData:t.sportsMatchupCardData,augmentItem:e,cardSize:this.cardSize,parentTelemetryObject:this.cardTelemetryObject},"sports-augment-card")},void 0,c.NT7,"SportsAugmentCard - generate span view failed",`Article ID: ${this.cardId}`)}}get viewModel(){return this.view.viewModel}experienceConnected(){const t=this.parseFeedData(this.data);if(t){const e=l.F.transformSportsMatchDataWithTrans(t);this.setView(e)}}getExperienceType(){return o.IUs}async setView(t){const e=await this.generateAugmentView(t);null!=e&&e.viewModel&&(this.view=e,this.isFirstViewReady=!0,this.markVisuallyReadyRaf(),this.setTmplTelemetry())}getSportsMatchAugmentItem(t){return d.aC.safeExecute(()=>{const e=null==t?void 0:t.sportsMatchOverallData;if(!e||e.length<1)throw new Error(`SportsAugmentCard - no match items in response: ${e}`);return e[0]},void 0,c._i,"SportsAugmentCard - error getting match item from augment response",`Article ID: ${this.cardId}`)}get transformationContext(){return{config:this.config,strings:this.strings,interestMenuItemClickHandler(){},paginationFlipperClickHandler(){},followClickHandler(){},searchInterestsHandler(){},openSearchViewHandler(){}}}setTmplTelemetry(){if(!this.view)return;(0,d.ao)(p.sportsAugmentShown,1);let t=p.sportsAugmentType.replace("{0}",this.augmentType);t=t.replace("{1}",this.viewModel.id||""),(0,d.ao)(t);const e=p.sportsAugmentArticleID.replace("{0}",this.cardId);(0,d.ao)(e)}}(0,n.Cg)([r.sH],h.prototype,"data",void 0),(0,n.Cg)([r.sH],h.prototype,"view",void 0),(0,n.Cg)([r.sH],h.prototype,"cardId",void 0),(0,n.Cg)([r.sH],h.prototype,"cardSize",void 0),(0,n.Cg)([r.sH],h.prototype,"augmentType",void 0),(0,n.Cg)([r.sH],h.prototype,"isFirstViewReady",void 0);var v=i(96950),f=i(69259);const w=v.qy`
    <img src="${t=>t.viewModel.winnerTagIconUrl}" />
`,x=v.qy`
    <div class="middle-game-detail ${t=>t.viewModel.isWinnerOne?"scale-x":"og-scale"}">
        ${(0,f.z)(t=>t.viewModel.isWinnerOne,w)}
        ${t=>t.viewModel.middleGameDetailsString}
        ${(0,f.z)(t=>t.viewModel.isWinnerTwo,w)}
    </div>
`,$=v.qy`
    <div class="middle-game-detail">
        ${t=>t.viewModel.middleGameDetailsString}
    </div>
`,A=v.qy`
    <div class="bottom-game-detail">
        ${t=>t.viewModel.gameDateString}
    </div>
`,S=v.qy`
    <div class="game-details">
        ${t=>t.viewModel.isPostGame?x:$}
        ${A}
    </div>
`,y=(t,e)=>v.qy`
    <div class="match-participant">
        ${(0,f.z)(!!t,v.qy`
            <img
                role="presentation"
                src="${t||""}"
            />`)}
        <div class="mp-name">
            ${e||""}
        </div>
    </div>
`,T=v.qy`
    <a
        class="augment-item"
        href="${t=>t.viewModel.clickThroughUrl}"
        title="${t=>t.viewModel.tooltipText}"
        target="_blank"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        ${t=>y(t.viewModel.participantOneImgIcon,t.viewModel.participantOneName)}
        ${S}
        ${t=>y(t.viewModel.participantTwoImgIcon,t.viewModel.participantTwoName)}
    </a>
`,C=v.qy`
    ${(0,f.z)(t=>t.view&&t.isFirstViewReady,T)}
`;var b=i(74849),I=i(22131),D=i(86856);const k=b.A` :host{--augc-background-color:#141414;--augc-background-hov-color:#292929;--augc-sub-color:#ADADAD;--augc-main-color:#D6D6D6}`,E=b.A` .middle-game-detail.scale-x img{transform:scaleX(-1)}`,H=b.A` .middle-game-detail.og-scale img{transform:scaleX(-1)}`,M=b.A`
:host{--augc-background-color:#F5F5F5;--augc-background-hov-color:#EBEBEB;--augc-sub-color:#616161;--augc-main-color:#424242}.augment-item{border-radius:8px;background-color:var(--augc-background-color);padding:8px 12px;width:242px;height:54px;display:grid;grid-template-columns:72px 98px 72px;font-weight:600;text-decoration:none;color:var(--augc-sub-color)}.augment-item:hover{background-color:var(--augc-background-hov-color)}.match-participant{display:flex;flex-direction:column;align-items:center;justify-content:center}.match-participant img{width:36px;height:36px}.mp-name{font-size:12px;font-style:normal;font-weight:400;line-height:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.game-details{display:flex;flex-direction:column;justify-content:center;align-items:center}.middle-game-detail{font-size:20px;font-style:normal;font-weight:600;line-height:28px;color:var(--augc-main-color);display:flex;align-items:center;gap:4px}.middle-game-detail img{vertical-align:middle}.wt-helper{display:inline-block;height:100%;vertical-align:middle}.bottom-game-detail{font-size:12px;font-style:normal;font-weight:400;line-height:16px}`.withBehaviors(new D.t(E,H),(0,I.G2)(k)),N={experienceConfigSchema:undefined}},16317(t,e,i){i.r(e),i.d(e,{SportsAugmentCardTransformer(){return d}});var n=i(23587),r=i(79811),o=i(54229),a=i(93552),s=i(50180),l=i(58792);class d extends n.ci{constructor(){super(...arguments),this.getTeamImageUrl=t=>{if(null!=t&&t.imageUrl)return(0,r.Hv)(null==t?void 0:t.imageUrl);const e=(0,r.iK)(null==t?void 0:t.imageId,!(null!=t&&t.imageId),this.transformerProvider.config.teamImageInfoEnhanced);return(0,r.Hv)(e)},this.getScoreString=t=>{var e,i;const n=null===(e=t.participantOne)||void 0===e?void 0:e.score,r=null===(i=t.participantTwo)||void 0===i?void 0:i.score;return n&&r||o.aC.logErrorWithFormat(a._i,`transformer - Participant scores are missing. p1: ${n}; p2: ${r}`,"SportsAugmentCard"),`${n} - ${r}`},this.getMiddleGameDetailsString=t=>t.gameStateCatetory===n.Xp.postGame?this.getScoreString(t):t.gameStartTime,this.getDateString=t=>t.gameStateCatetory===n.Xp.postGame?`${this.transformerProvider.strings.sportsStateFinal} · ${t.gameDate}`:t.gameDate,this.getTooltipText=t=>{var e,i,r,o;return t.gameStateCatetory===n.Xp.postGame?(0,s.GP)(this.transformerProvider.strings.sportsMatchAriaPostGame,t.gameDate,null===(e=t.participantOne)||void 0===e?void 0:e.name,null===(i=t.participantTwo)||void 0===i?void 0:i.name):(0,s.GP)(this.transformerProvider.strings.sportsMatchAriaGeneric,t.gameDate,null===(r=t.participantOne)||void 0===r?void 0:r.name,null===(o=t.participantTwo)||void 0===o?void 0:o.name)},this.getWinnerTagIconUrl=()=>(0,r.jJ)()?`${(0,l.rA)().StaticsUrl}latest/sports/icons/SportsWinnerTag2AugDark.svg`:`${(0,l.rA)().StaticsUrl}latest/sports/icons/SportsWinnerTag2AugLight.svg`}async transform(t){return{viewModel:this.getViewModel(t)}}getViewModel(t){var e,i,r,s,l;const d=t.cardData,c=t.augmentItem.sportsMatchData,g=c.gameStateCatetory===n.Xp.postGame,m={brandId:(null==d?void 0:d.primaryEntityId)??(null==d?void 0:d.leagueId)??"",headline:(null==d?void 0:d.sportType)??n.D7.unknown,id:(null==d?void 0:d.leagueId)||"",type:55},u=this.transformerProvider.telemetryBuilder,p=t.parentTelemetryObject,h={...null==p||null===(e=p.contract)||void 0===e?void 0:e.ext,augHt:70};return u.initTelemetryBuilder(n.BP.Vertical,null==d?void 0:d.leagueName,h),p||o.aC.logErrorWithFormat(a.CF0,"transformer - parentTelemetryObject was passed as undefined","SportsAugmentCard"),{clickThroughUrl:c.matchClickthroughUrl,participantOneImgIcon:this.getTeamImageUrl(c.participantOne),participantTwoImgIcon:this.getTeamImageUrl(c.participantTwo),participantOneName:(null===(i=c.participantOne)||void 0===i?void 0:i.name)||"",participantTwoName:(null===(r=c.participantTwo)||void 0===r?void 0:r.name)||"",middleGameDetailsString:this.getMiddleGameDetailsString(c),gameDateString:this.getDateString(c),isPostGame:g,isWinnerOne:g&&(null===(s=c.participantOne)||void 0===s?void 0:s.isWinner),isWinnerTwo:g&&(null===(l=c.participantTwo)||void 0===l?void 0:l.isWinner),winnerTagIconUrl:this.getWinnerTagIconUrl(),tooltipText:this.getTooltipText(c),id:c.gameId,telemetryTag:u.createNavClickWithTypeTelemetryTag(p,{...m,name:n.BP.Augment},81)}}}}}]);