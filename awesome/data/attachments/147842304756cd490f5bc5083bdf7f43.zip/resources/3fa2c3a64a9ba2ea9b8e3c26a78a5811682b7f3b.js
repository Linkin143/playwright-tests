"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-fre"],{4968(e,t,i){i.d(t,{f(){return d}});var r=i(64187),o=i(74849),l=i(42792),a=i(99657),n=i(36452);const d=o.A.partial`position: relative; z-index: ${a.D};`;o.A`
    ${l.e}
    ${l.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${d}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${n.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${n.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${n.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(l.kc)},17132(e,t,i){i.r(t),i.d(t,{SportsFre(){return I}});var r=i(56911),o=i(92011),l=i(4968),a=i(86856),n=i(12640),d=i(74849),s=i(22131);const c=d.A` .item-name-vertical{text-align:right;margin-right:4px}`,g=d.A` .feeds2-fre .fre-overview-vertical .overview-logo{background:rgba(41,41,41,1)}`,p=d.A` :host{width:100%}.fre-overview{display:flex;flex-direction:row;margin:0 16px;padding:16px 0;gap:6px;height:58px;text-decoration:none;color:currentColor;border-bottom:1px solid var(--neutral-stroke-active)}.fre-overview-vertical{height:64px}._1x_1y.fre-overview-vertical{border:none !important;padding:0px}._1x_2y.fre-overview-vertical{padding:0 0 4px 0}._1x_3y.fre-overview-vertical{padding:6px 0}.feeds2-fre .fre-overview{${l.f};margin:0}.overview-logo{border-radius:8px;align-items:center;justify-content:center;display:flex;border:none}.feeds2-fre .fre-overview-vertical .overview-logo{width:60px;height:60px;margin-left:4px;background:rgba(255,255,255,1)}.overview-logo > img{width:58px;height:58px}.feeds2-fre .overview-logo > img{width:58px;height:58px}.feeds2-fre .fre-overview-vertical .overview-logo > img{width:46px;height:46px}.overview-title{font-weight:700;font-size:18px;line-height:26px;max-width:200px;overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;color:currentColor;margin:4px}.fre-overview-vertical .overview-title{font-weight:600;font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px);max-width:190px;margin:2px 4px}.one-line.overview-title{-webkit-line-clamp:1}.overview-content{display:flex;flex-direction:column;justify-content:space-between}.fre-title{position:relative;padding:12px 16px 0 16px;font-weight:400;font-size:14px;line-height:20px;text-align:center;width:268px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.feeds2-fre .fre-title{padding:12px 0 8px}.feeds2-fre.fre-vertical .fre-title{padding:0;text-align:initial;margin:8px 4px 3px;font-weight:600}.feeds2-fre.fre-vertical ._1x_3y.fre-title{margin:16px 2px 8px !important}.item-list{display:grid;gap:8px;grid-template-columns:repeat(auto-fit,61px);padding:8px 16px 0px}.fre-vertical .item-list{display:flex;gap:0;flex-direction:column}.fre-item{${l.f};width:61px;height:76px;background:var(--sports-item-background);display:flex;align-items:center;flex-direction:column;border-radius:6px;gap:2px;color:currentColor;text-decoration:none}.fre-item-vertical{${l.f};background:rgba(255,255,255,0.55);display:flex;align-items:center;border-radius:6px;color:currentColor;text-decoration:none;margin:3px;height:36px;padding:0 6px}.fre-item-dark{background:rgba(26,26,26,0.5)}.fre-item:hover{background:var(--sports-item-hover-background)}.fre-item:active{background:var(--sports-item-active-background)}.fre-item > img{width:32px;height:32px}.item-name{width:60px;font-weight:600;font-size:14px;line-height:20px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center}.item-name-vertical{width:100%;text-align:left;margin-left:4px}._1x_1y.fre-title{padding:0 16px}._1x_1y.item-list{grid-template-columns:repeat(auto-fit,36px)}._1x_1y .fre-item{width:36px;height:48px}._1x_1y .fre-item > img{width:20px;height:20px}._1x_1y .item-name{display:none}._1x_2y .fre-item{height:92px;gap:4px}._1x_2y .fre-item > img{width:32px;height:32px;padding-top:6px}._1x_2y .fre-item-vertical > img{width:18px;height:18px;margin:2px}._1x_3y .fre-item{height:92px;gap:4px}._1x_3y.fre-item-vertical{height:38px;margin:4px 0}._1x_3y .fre-item > img{width:32px;height:32px;padding-top:6px}._1x_3y .fre-item-vertical > img{width:18px;height:18px;margin:2px}.feeds2-fre .item-list,.feeds2-fre ._1x_1y.fre-title{padding:0}.feeds2-fre ._1x_1y.item-list{grid-template-columns:repeat(auto-fit,38px)}.follow-icon{height:20px;padding:0;background:none;align-items:center;display:flex;color:currentcolor;fill:currentcolor;border:none}.follow-icon:hover{cursor:pointer}.follow-button{height:24px;width:fit-content;background:none;border-radius:20px;border:1px solid #1A1A1A;color:#1A1A1A;font-weight:400;font-size:12px;line-height:16px;align-items:center;display:flex}.follow-button:hover{cursor:pointer}.follow-button svg > path:nth-child(2),.follow-button svg rect{fill:none}.follow-button svg path,.follow-button.following > svg > path:nth-child(2){fill:#1A1A1A}.icon-add,.icon-selected{height:24px;display:inline-flex;align-items:center}.discover-more-icon{filter:brightness(0)}.discover-more-icon-dark{filter:brightness(1)}.icon-selected svg{fill:#036AC4}.discover-more-item{z-index:var(--click-z-index);background:rgba(255,255,255,0.55);cursor:pointer;display:flex;align-items:center;border-radius:6px;color:currentColor;text-decoration:none;margin:3px;height:36px;padding:0 4px 0 6px}.discover-more-item-dark{background:rgba(26,26,26,0.5) !important}._1x_3y.discover-more-item{margin:4px !important}.discover-more-text{width:100%;font-weight:600;font-size:14px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;margin:3px}`.withBehaviors(new a.t(null,c),new n.N(null,g),(0,s.mr)(d.A` :host{forced-color-adjust:auto}`));var h=i(96950),f=i(69259),v=i(39957),u=i(58792);const x={dark:h.qy`
    <img
      src="${(0,u.rA)().StaticsUrl}latest/sports/icons/CircleAddLargeDark.svg"
    >`,light:h.qy`
    <img
      src="${(0,u.rA)().StaticsUrl}latest/sports/icons/CircleAddLarge.svg"
    >`},m={dark:h.qy`
    <img
        src="${(0,u.rA)().StaticsUrl}latest/sports/icons/CircleCompletedLarge.svg"
    >`,light:h.qy`
    <img
        src="${(0,u.rA)().StaticsUrl}latest/sports/icons/CircleCompletedLarge.svg"
    >`},b=h.qy`
    <img
        src="${(0,u.rA)().StaticsUrl}latest/sports/icons/SportsRightArrowWhite.svg"
    >
`,w=h.qy`
    <a class="fre-overview ${e=>e.viewModel.isVerticalFre&&"fre-overview-vertical"} ${e=>e.viewModel.cardSize}"
        href="${e=>e.viewModel.leagueUrl}" target="${e=>e.viewModel.linkTarget}" title="${e=>e.viewModel.leagueDescription}" data-t="${e=>{var t;return e.viewModel.leagueEntity.telemetryContext.searchTelemetryTag||(null===(t=e.viewModel.leagueEntity.telemetryContext.webSearchUrl)||void 0===t?void 0:t.getMetadataTag())}}">
        <div class="overview-logo"">
            <img role="presentation" src="${e=>e.viewModel.leagueLogoUrl}"/>
        </div>
        <div class="overview-content">
            <div class="overview-title ${e=>e.viewModel.enableFollowButton?"one-line":""} title="${e=>e.viewModel.leagueDescription??""}">
                ${e=>e.viewModel.leagueDescription}
            </div>
            ${(0,f.z)(e=>e.viewModel.enableFollowButton,h.qy`
                <fluent-button
                    class="follow-button"
                    tabindex="0"
                    aria-label="${e=>e.followButtonTitle}"
                    title="${e=>e.followButtonTitle}"
                    @click="${(e,t)=>e.handleClickFollowIcon(t.event,e.viewModel.leagueEntity)}"
                    @keyup="${(e,t)=>t&&e.onKeyUp(t.event,e.viewModel.leagueEntity)}"
                    data-t="${e=>e.followButtonTelemetry}"
                >
                    <div class="${e=>e.viewModel.isFollowCurrent?"icon-selected":"icon-add"}">
                        ${e=>e.viewModel.isFollowCurrent?m[e.getColorMode()]:x[e.getColorMode()]}
                        ${e=>e.followButtonContent}
                    </div>
                </fluent-button>
            `)}
        </div>
    </a>
`,$=h.qy`
    ${(0,f.z)((e,t)=>null!=t.parent.updateFre,h.qy`
        <a class="${(e,t)=>t.parent.viewModel.isVerticalFre?"fre-item-vertical":"fre-item"} ${(e,t)=>t.parent.viewModel.isDarkModeTheme&&"fre-item-dark"}"
            href="${e=>e.webSearchUrl}" target="${(e,t)=>t.parent.viewModel.linkTarget}"
            data-t="${e=>e.telemetryContext.searchTelemetryTag}">
            <img role="presentation" src="${e=>e.imageUrl}"/>
            <div class="item-name ${(e,t)=>t.parent.viewModel.isVerticalFre&&"item-name-vertical"}" title="${e=>e.name||e.alias}">${e=>e.alias||e.name}</div>
            <fluent-button
                class="follow-icon"
                tabindex="0"
                aria-label="${(e,t)=>t&&t.parent.getFollowItemButtonTitle(e)}"
                title="${(e,t)=>t&&t.parent.getFollowItemButtonTitle(e)}"
                @click="${(e,t)=>t&&t.parent.handleClickFollowIcon(t.event,e)}"
                @keyup="${(e,t)=>t&&t.parent.onKeyUp(t.event,e)}"
                data-t="${e=>e.telemetryContext.followTelemetryTag}" 
            >
                <div class="${(e,t)=>t.parent.viewModel.isSportsFollowed(e.id,e.yId)?"icon-selected":"icon-add"}">
                    ${(e,t)=>t.parent.viewModel.isSportsFollowed(e.id,e.yId)?m[t.parent.getColorMode()]:x[t.parent.getColorMode()]}
                </div>
            </fluent-button>
        </a>
    `)}
`,y=h.qy`
    <a class="discover-more-item ${e=>e.viewModel.cardSize} ${e=>e.viewModel.isDarkModeTheme&&"discover-more-item-dark"}"
        @click="${e=>e.viewModel.openInterestManager&&e.viewModel.openInterestManager()}" data-t="${e=>e.viewModel.discoverMoreTelemetryTag}">
        <div class="discover-more-text" title="${e=>e.getDiscoverMoreTitle()}"> ${e=>e.getDiscoverMoreTitle()} </div>
        <fluent-button
            class="follow-icon"
            tabindex="0"
            title="${e=>e.getDiscoverMoreTitle()}"
        >
            <div class="icon-add discover-more-icon ${e=>e.viewModel.isDarkModeTheme&&"discover-more-icon-dark"}"}>
                ${b}
            </div>
        </fluent-button>
    </a>
`,k=h.qy`
    <div class="fre-title ${e=>e.viewModel.cardSize}" title="${e=>e.viewModel.freTitle}">
        ${e=>e.viewModel.freTitle}
    </div>
    <div class="item-list ${e=>e.viewModel.cardSize}">
        ${(0,v.ux)(e=>e.viewModel.entityData,$,{positioning:!0})}
        ${(0,f.z)(e=>e.viewModel.isVerticalFre,y)}
    </div>
`,_=h.qy`
    <div class="${e=>"feeds2"===e.viewModel.feedsType?"feeds2-fre":""} ${e=>e.viewModel.isVerticalFre?"fre-vertical":""}">
        ${(0,f.z)(e=>e.viewModel.showOverview,w)}
        ${(0,f.z)(e=>e.viewModel.showItemList,k)}
    </div>
`,z=h.qy`
    ${(0,f.z)(e=>null!=e.viewModel,_)}
`;var C=i(84564),T=i(54229),F=i(60815),S=i(50180);class A extends C.z{onSizeChange(e){}onPaginate(e){}get followButtonTitle(){return(0,S.GP)(this.viewModel.isFollowCurrent?this.viewModel.strings.haveFollowed:this.viewModel.strings.followSports,this.viewModel.leagueEntity.name||"")}get followButtonContent(){return this.viewModel.isFollowCurrent?this.viewModel.strings.haveFollowed.replace("{0}",""):this.viewModel.strings.follow}get followButtonTelemetry(){return this.viewModel.leagueEntity.telemetryContext.followTelemetryTag}getColorMode(){return this.viewModel.isDarkModeTheme?"dark":"light"}getFollowItemButtonTitle(e){return(0,S.GP)(this.viewModel.isSportsFollowed(e.id,e.yId)?this.viewModel.strings.haveFollowed:this.viewModel.strings.followSports,e.name||"")}getDiscoverMoreTitle(){return(0,S.GP)(this.viewModel.strings.discoverMoreButton)}handleClickFollowIcon(e,t){if(e&&e.currentTarget){e.preventDefault(),e.stopPropagation();const i="keydown"===e.type||"keypress"===e.type||"keyup"===e.type,r=!this.viewModel.isSportsFollowed(t.id,t.yId);(0,T.LE)(e.currentTarget,i,r),this.updateFre=!1,r?this.viewModel.followClickHandler&&this.viewModel.followClickHandler(t):this.viewModel.unfollowClickHandler&&this.viewModel.unfollowClickHandler(t),window.setTimeout(()=>{this.updateFre=!0},100)}}onKeyUp(e,t){e&&"Enter"===e.key&&t&&this.handleClickFollowIcon(e,t)}}(0,r.Cg)([F.sH],A.prototype,"updateFre",void 0);let I=class extends A{};I=(0,r.Cg)([(0,o.E)({name:"sports-fre",template:z,styles:p})],I)},42792(e,t,i){i.d(t,{R7(){return v},e(){return h},kc(){return f},nH(){return p}});var r=i(57416),o=i(55153),l=i(95239),a=i(26920),n=i(48751),d=i(64187),s=i(22131),c=i(74849),g=i(50882);const p=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,d.V)("flex")} :host {
        background: ${l.p};
        outline: calc(${a.XA} * 1px) solid ${o.cu};
        border-radius: calc((${r.JU} - ${a.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${n.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${o.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${o.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${a.XA} * 1px) ${o.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${o.QG} * 1px);
        height: calc(${o.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${o.QG} * 1px);
        height: calc((${o.l8} * 2px) + (${o.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${o.QG} * 2px) + (${o.Sn} * 1px));
        height: calc((${o.l8} * 2px) + (${o.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${o.QG} * 2px) + (${o.Sn} * 1px));
        height: calc(${o.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,f=(0,s.mr)(c.A`
            :host {
                background: ${g.A.Canvas};
                color: ${g.A.CanvasText};
            }
        `),v=c.A`
    ${h}
    ${p}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(f)},46239(e,t,i){i.r(t),i.d(t,{SportsFreTransformer(){return m}});var r=i(23587),o=i(54229),l=i(96950),a=i(3083),n=i(80895),d=i(58792),s=i(42161),c=i(90366),g=i(2827),p=i(25109),h=i(26220),f=i(52356);const v=function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"",t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:40,i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:40,r=arguments.length>3&&void 0!==arguments[3]&&arguments[3];return e?e.replace(/w=([\d]*)?&h=([\d]*)?/,`w=${r?i+20:i}&h=${r?t+20:t}`):null};function u(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1],i=arguments.length>2?arguments[2]:void 0;const r={format:a.f5.PNG,enableDpiScaling:!1,crop:0,...i};return(o=e)&&o.trim()?e.indexOf(".")>0?(0,a.oQ)(`${a.Ro}?id=${e}&pid=MSports`,r):(0,a.XP)(e,r):t?(0,a.XP)("BB1dV8FG",r):null;var o}function x(e){if(null!=e&&e.startsWith("http"))return e;if(!e)return"";const t=(0,s.g2)((0,c.t7)(e));return(0,g.oh)()?function(e){if(!e)return e;try{const t=new URL((0,h.$N)()),i=new URL(e),r=t.searchParams.getAll("item").find(e=>e.startsWith("flights:"));return r&&i.searchParams.append("item",r),i.href}catch{return e}}(t):t}class m extends r.Bc{constructor(){super(...arguments),this.followIconClickHandler=async e=>{await this.transformerProvider.followClickEntityHandler(e,!0,e.webSearchUrl)},this.unfollowIconClickHandler=async e=>{await this.transformerProvider.followClickEntityHandler(e,!1,e.webSearchUrl)}}async transform(e){var t,i;this.isInDarkMode="bingHomepage"===d.T3.AppType?f.y.appInDarkMode():(null===n.F_||void 0===n.F_?void 0:n.F_.get(1))??(0,p.ud)(),this.isVerticalFre="boolean"==typeof(i=null===(t=e.tabData)||void 0===t||null===(t=t.tabContent)||void 0===t?void 0:t.isVertical)?i:!!i&&("1"===i||"true"===i.toLowerCase());const r=this.getCurrentViewModel(e);return{viewTemplate:l.qy` 
                <sports-fre
                    :viewModel=${r}
                    :updateFre=${()=>!0}
                ></sports-fre>`}}initEntityData(e){this.entityData=e.freData,this.entityData.forEach(t=>{if(t){t.webSearchUrl=t.webSearchUrl||`${x(t.gameCenterUrl)}&src=fre`,t.imageUrl=t.imageUrl||u(t.imageId,!t.imageId,this.transformerProvider.config.teamImageInfoEnhanced),t.type=t.type||r.XR.Team;const i=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{name:r.BP.SportsSuggestUrl,brandId:"FRECard",headline:t.sportType||r.D7.unknown,id:t.leagueId,signature:e.telemetryConstants.signature}),o=this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(e.telemetryObject,{name:r.BP.FollowTeam,brandId:"FRECard",headline:t.name,id:t.id,signature:e.telemetryConstants.signature},!0);t.telemetryContext={searchTelemetryTag:i,followTelemetryTag:o}}})}getEntityData(e){let t;return this.isVerticalFre?t="_1x_3y"===e.cardSize?5:2:(t="_1x_3y"===e.cardSize?12:4,"_1x_1y"===e.cardSize&&(t=6)),this.entityData.slice(0,t)}getLeagueEntity(e){var t,i,o,l,a,n,d,s,c,g;const p={id:(null==e||null===(t=e.tabData)||void 0===t?void 0:t.primaryEntityId)||"",yId:(null==e||null===(i=e.tabData)||void 0===i?void 0:i.yId)||"",name:(null==e||null===(o=e.tabData)||void 0===o?void 0:o.primaryEntityName)||"",type:(null==e||null===(l=e.tabData)||void 0===l?void 0:l.primaryEntityType)||"League",sportType:(null==e||null===(a=e.tabData)||void 0===a||null===(a=a.tabContent)||void 0===a?void 0:a.sport)||"",leagueId:(null==e||null===(n=e.tabData)||void 0===n||null===(n=n.tabContent)||void 0===n||null===(n=n.league)||void 0===n?void 0:n.id)||"",displayText:(null==e||null===(d=e.tabData)||void 0===d?void 0:d.primaryEntityName)||"",imageUrl:u(null==e||null===(s=e.tabData)||void 0===s?void 0:s.primaryEntityImage,!(null!==(c=e.tabData)&&void 0!==c&&c.primaryEntityImage),this.transformerProvider.config.teamImageInfoEnhanced),webSearchUrl:`${x(null==e||null===(g=e.tabData)||void 0===g||null===(g=g.tabContent)||void 0===g||null===(g=g.league)||void 0===g?void 0:g.clickThroughUrl)}&src=fre`},h=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{name:r.BP.SportsSuggestUrl,brandId:"FRECard",headline:p.sportType||r.D7.unknown,id:p.leagueId,signature:e.telemetryConstants.signature}),f=this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(e.telemetryObject,{name:r.BP.FollowTeam,brandId:"FRECard",headline:p.name,id:p.id,signature:e.telemetryConstants.signature},!0);return p.telemetryContext={searchTelemetryTag:h,followTelemetryTag:f},p}isSportsFollowed(e,t){return!!this.followedSports&&(this.followedSports.get(e||"")||this.followedSports.get(t||""))}isEnableFollowButton(e){var t;return Boolean(null===(t=e.tabData)||void 0===t||null===(t=t.tabContent)||void 0===t?void 0:t.enableFollowButton)}isShowOverview(e){return!!this.isVerticalFre||"_1x_1y"!==e.cardSize}isShowItemList(e){return!this.isVerticalFre||"_1x_1y"!==e.cardSize}getCurrentViewModel(e){var t,i,l,a,n,d,s,c;return this.initEntityData(e),this.followedSports=e.followedSports,{cardSize:e.cardSize,isDarkModeTheme:this.isInDarkMode,enableFollowButton:this.isEnableFollowButton(e),entityData:this.getEntityData(e),feedsType:"feeds2",followClickHandler:this.followIconClickHandler,followedSports:this.followedSports,freTitle:(null==e||null===(t=e.tabData)||void 0===t||null===(t=t.tabContent)||void 0===t?void 0:t.headerTextLine2)||"",isFollowCurrent:this.isSportsFollowed((null===(i=e.tabData)||void 0===i?void 0:i.primaryEntityId)||"",(null===(l=e.tabData)||void 0===l?void 0:l.yId)||""),isSportsFollowed:this.isSportsFollowed,leagueDescription:(null==e||null===(a=e.tabData)||void 0===a||null===(a=a.tabContent)||void 0===a?void 0:a.headerTextLine1)||"",leagueEntity:this.getLeagueEntity(e),leagueLogoUrl:v(u(null===(n=e.tabData)||void 0===n||null===(n=n.tabContent)||void 0===n?void 0:n.headerLogo,!(null!==(d=e.tabData)&&void 0!==d&&d.primaryEntityImage),this.transformerProvider.config.teamImageInfoEnhanced),58,58,!0),leagueUrl:`${x((null===(s=e.tabData)||void 0===s||null===(s=s.tabContent)||void 0===s?void 0:s.clickThroughUrl)||(null===(c=e.tabData)||void 0===c?void 0:c.clickThroughUrl))}&src=fre`,linkTarget:"_blank",isVerticalFre:this.isVerticalFre,showOverview:this.isShowOverview(e),showItemList:this.isShowItemList(e),strings:{...this.transformerProvider.strings},telemetryObject:e.telemetryObject,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsFRE}),unfollowClickHandler:this.unfollowIconClickHandler,discoverMoreTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsFRE},o.YJ.Customize),openInterestManager:()=>{var e,t;return null===(e=(t=this.transformerProvider).openSearchViewHandler)||void 0===e?void 0:e.call(t,!0)}}}}Promise.resolve().then(i.bind(i,17132))},84564(e,t,i){i.d(t,{z(){return a}});var r=i(56911),o=i(60815),l=i(92011);class a extends l.L{}(0,r.Cg)([o.sH],a.prototype,"viewModel",void 0)},99657(e,t,i){i.d(t,{D(){return a},I(){return l}});var r=i(45755);const{create:o}=r.G,l=o("sloppy-click-z-index",1),a=o("click-z-index",1)}}]);