"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_entry-point-hp-wc_dist_lazy-loadings_widgetLayoutTemplateMaps_js"],{3641(t,o,l){l.d(o,{v(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_halfy,C4:s.uE._2x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:C}},12814(t,o,l){l.d(o,{m(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:C}},36271(t,o,l){l.d(o,{b(){return e}});var s=l(33477);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3"
        "slot1 slot1 slot2 slot2 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3]}}],styles:C}},40094(t,o,l){l.d(o,{w(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot4 slot5"
        "slot1 slot1 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot5 slot4"
        "slot1 slot3 slot5 slot4";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot5 slot2 slot4"
        "slot1 slot5 slot3 slot4";
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._2x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,2],C1:[1,3]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[2,3],C4:[2,3],C3:[2,3],C2:[2,2],C1:[2,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,5],C3:[1,5],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,3],C1:[1,2]}}],styles:C}},41523(t,o,l){l.d(o,{X(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1";
}
`.withBehaviors(),e={cardCount:1,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:C}},42411(t,o,l){l.d(o,{L(){return e}});var s=l(33477);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot2"
        "slot1 slot2 slot2";
}
:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3";
}
:host([layout="C2"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._2x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C2:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C2:[1,2]}}],styles:C}},54267(t,o,l){l.d(o,{r(){return e}});var s=l(33477);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:C}},56512(t,o,l){l.d(o,{c(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,4],C4:[1,4]}}],styles:C}},56614(t,o,l){l.d(o,{k(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot4 slot1 slot1 slot2"
        "slot5 slot1 slot1 slot2";
}
:host([layout="C4"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot5";
}
:host([layout="C3"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot4 slot2"
        "slot5 slot2";
}

:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(4),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._2x_2y,C2:s.uE._2x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C2:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,4],C2:[3,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y},telemetryRowCol:{C5:[1,4]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y},telemetryRowCol:{C5:[1,5],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y},telemetryRowCol:{C5:[2,5],C4:[2,1],C3:[2,3],C2:[4,1]}}],styles:C}},64865(t,o,l){l.d(o,{x(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot1 slot4"
        "slot3 slot1 slot1 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot3";
}

:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(4),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._2x_2y,C2:s.uE._2x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y},telemetryRowCol:{C5:[1,4],C4:[2,1],C3:[2,3],C2:[4,1]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C2:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C2:[3,2]}}],styles:C}},68151(t,o,l){l.d(o,{AnaheimWidgetsLayoutTemplateMap(){return P}});var s=l(74050),C=l(69721),e=l(72547),a=l(54267),r=l(42411),y=l(64865),i=l(68683),d=l(56614),g=l(40094),u=l(36271),n=l(12814),h=l(3641),m=l(93833),p=l(90773),w=l(69827),c=l(41523),_=l(71350),R=l(99541),x=l(56512);const P={"hero-section-one-row-11111":e.D,"hero-section-one-row-122":r.L,"hero-section-one-row-1211":a.r,"hero-section-one-row-2111":y.x,"hero-section-one-row-2111-b":i.$,"hero-section-one-row-21155":d.k,"hero-section-one-row-25511":g.w,"hero-section-one-row-221":u.b,"hero-section-one-row-3-cards":n.m,"hero-section-one-row-3-mini-widgets":h.v,"hero-section-one-row-5-mini-widgets-drp":p.v,"hero-section-one-row-5-mini-widgets":w.X,"hero-section-one-row-4-cards":m.R,"hero-section-first-river-4-cards":s.O,"hero-section-first-river-5-cards":C.Z,"widgets-cards-1":c.X,"widgets-cards-2":_.Q,"widgets-cards-3":R.X,"widgets-cards-4":x.c}},68683(t,o,l){l.d(o,{$(){return e}});var s=l(33477);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}
 
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._2x_2y,C4:s.uE._2x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:C}},69721(t,o,l){l.d(o,{Z(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot4"
        "slot3 slot4 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot3"
        "slot3 slot3"
        "slot2 slot4"
        "slot2 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5";
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(4),C2:(0,s.P)(6),C1:(0,s.P)(10)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[5,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_1y,C3:s.uE._1x_2y,C2:s.uE._2x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_1y,C3:s.uE._2x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[2,3],C3:[3,2],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}}],styles:C}},69827(t,o,l){l.d(o,{X(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,5],C3:[1,5],C2:[1,5],C1:[1,5]}}],styles:C}},71350(t,o,l){l.d(o,{Q(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),e={cardCount:2,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}}],styles:C}},72547(t,o,l){l.d(o,{D(){return e}});var s=l(33477);const C=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:C}},74050(t,o,l){l.d(o,{O(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot4 slot3"
        "slot1 slot2 slot4 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot4 slot2"
        "slot1 slot4 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot2 slot3"
        "slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot4"
        "slot4"
        "slot2"
        "slot2"
        "slot3"
        "slot3";
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(4),C1:(0,s.P)(8)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_1y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_1y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[2,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,3],C3:[1,2],C2:[1,2],C1:[3,1]}}],styles:C}},90773(t,o,l){l.d(o,{v(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy,C1:s.uE._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy,C2:s.uE._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy,C3:s.uE._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_halfy,C4:s.uE._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:s.uE._1x_halfy},telemetryRowCol:{C5:[1,5]}}],styles:C}},93833(t,o,l){l.d(o,{R(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,s.P)(2),C4:(0,s.P)(2),C3:(0,s.P)(2),C2:(0,s.P)(2),C1:(0,s.P)(2)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._2x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:s.uE._1x_2y,C4:s.uE._1x_2y,C3:s.uE._1x_2y,C2:s.uE._1x_2y,C1:s.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}}],styles:C}},99541(t,o,l){l.d(o,{X(){return e}});var s=l(33477);const C=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,s.P)(1),C4:(0,s.P)(1),C3:(0,s.P)(1),C2:(0,s.P)(1),C1:(0,s.P)(1)},colWidthPx:s.f1,gutterPx:s.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:s.uE._1x_1y,C4:s.uE._1x_1y,C3:s.uE._1x_1y,C2:s.uE._1x_1y,C1:s.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}}],styles:C}}}]);