"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-event-schedule"],{4968(e,t,i){i.d(t,{f(){return s}});var r=i(64187),o=i(74849),a=i(42792),n=i(99657),l=i(36452);const s=o.A.partial`position: relative; z-index: ${n.D};`;o.A`
    ${a.e}
    ${a.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${s}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(a.kc)},42792(e,t,i){i.d(t,{R7(){return u},e(){return p},kc(){return f},nH(){return g}});var r=i(57416),o=i(55153),a=i(95239),n=i(26920),l=i(48751),s=i(64187),d=i(22131),c=i(74849),h=i(50882);const g=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,p=c.A`
    ${(0,s.V)("flex")} :host {
        background: ${a.p};
        outline: calc(${n.XA} * 1px) solid ${o.cu};
        border-radius: calc((${r.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${l.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${o.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${o.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${o.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${o.QG} * 1px);
        height: calc(${o.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${o.QG} * 1px);
        height: calc((${o.l8} * 2px) + (${o.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${o.QG} * 2px) + (${o.Sn} * 1px));
        height: calc((${o.l8} * 2px) + (${o.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${o.QG} * 2px) + (${o.Sn} * 1px));
        height: calc(${o.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,f=(0,d.mr)(c.A`
            :host {
                background: ${h.A.Canvas};
                color: ${h.A.CanvasText};
            }
        `),u=c.A`
    ${p}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(f)},51303(e,t,i){i.r(t),i.d(t,{SportsEventScheduleTransformer(){return c}});var r=i(23587),o=i(49150),a=i(79811),n=i(54229),l=i(85312),s=i(58792),d=i(96950);class c extends r.Bc{async transform(e){const{cardSize:t}=e;this.cardSize=t,this.isInDarkMode=(0,a.jJ)(),this.isHeroCard=!!e.isHeroCard;const i=this.getCurrentViewModel(e);return{viewTemplate:d.qy`
                <sports-info-list
                    :viewModel="${i}"
                ></sports-info-list>
            `}}getDes(e,t){const{strings:i}=this.transformerProvider,{state:o}=e.gameState,{PreGame:n,InProgress:l,PostGame:s,Live:d,Final:c}=r.T0;return o===n?{des:this.getGameDate(e.gameStartDateTime,t)}:o===l||o===d?{des:i.sportsLive,desStyle:`color: ${this.isInDarkMode?a.HX:a.d$}; text-transform: uppercase;`}:o===s||o===c?{des:i.matchCompleted}:{des:""}}getGameDate(e,t){return e?n.aC.safeExecute(()=>{const t=(0,a.yn)(e),i=s.T3.CurrentMarket||"en-us";return this.isToday(t)?(0,a.ry)(t,i):(0,a.AL)(t,i)},"",l.Gu,`SportsEventScheduleTransformer: error while parsing game date: ${e}`,JSON.stringify(t)):""}isToday(e){const t=new Date;return t.getFullYear()===e.getFullYear()&&t.getMonth()===e.getMonth()&&t.getDate()===e.getDate()}getImageUrl(e){const t=this.isInDarkMode?e.sport.darkImageId:e.sport.imageId;return(0,a.iK)(t||"BB1nYzrJ",!1,this.transformerProvider.config.teamImageInfoEnhanced)}getListData(e){var t;if(null===(t=e.data)||void 0===t||!t.games)return[];const i=this.getMaxCount(e),r=e.data.games.slice(0,i),o=this.getItemStyle(e,r.length);return r.map(t=>({icon:this.getImageUrl(t),title:t.sport.name,subTitle:t.eventName,...this.getDes(t,e),itemStyle:o,clickThroughUrl:t.sport.clickThroughUrl}))}getItemStyle(e,t){return e.isFullCard&&this.isHeroCard?"margin-bottom: 8px; padding-left: 12px; padding-right: 12px":e.isFullCard?void 0:this.cardSize===o.uE._1x_3y?"height: 58px;":1===t?"height: 56px; justify-content: center;":"height: 50px"}getMaxCount(e){switch(this.cardSize){case o.uE._1x_1y:return 1;case o.uE._1x_2y:return e.isFullCard?4:2;case o.uE._1x_3y:return e.isFullCard?7:4;default:return 4}}getItemSizeFullCard(e){return this.cardSize===o.uE._1x_1y?"small":this.cardSize!==o.uE._1x_2y?e.length<=4?"large":5===e.length?"medium":"small":e.length<=2?"large":3===e.length?"medium":e.length>=4?"small":void 0}getTitle(e,t){var i;if(this.isHeroCard&&e.isFullCard)return;if(null!==(i=e.data)&&void 0!==i&&i.gamesTitle)return e.data.gamesTitle;const{todayEvent:r,todayEvents:o}=this.transformerProvider.strings;return t>1?o:r}getSubtitle(e,t){var i;if(this.isHeroCard)return"";return t===this.getMaxCount(e)?null===(i=e.data)||void 0===i?void 0:i.gamesCountText:""}getCurrentViewModel(e){const{clickThroughUrl:t}=e.data||{},{telemetryBuilder:i}=this.transformerProvider,o=this.getListData(e),n=Boolean(this.isHeroCard&&e.isFullCard);return{telemetryTag:null==i?void 0:i.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:r.BP.SportsEventScheduleCard}),cardSize:this.cardSize,isDarkModeTheme:this.isInDarkMode,title:this.getTitle(e,o.length),subTitle:this.getSubtitle(e,o.length),hasItemBg:n,showDivider:!n,listStyle:n?"max-height: initial; padding-left: 0px; padding-right: 0px;":"",items:o,itemSize:e.isFullCard?this.getItemSizeFullCard(o):"small",clickThroughUrl:t?(0,a.Ot)(t):void 0}}}Promise.resolve().then(i.bind(i,96041))},84564(e,t,i){i.d(t,{z(){return n}});var r=i(56911),o=i(60815),a=i(92011);class n extends a.L{}(0,r.Cg)([o.sH],n.prototype,"viewModel",void 0)},96041(e,t,i){i.r(t),i.d(t,{SportsInfoList(){return z}});var r=i(56911),o=i(92011),a=i(74849),n=i(22131),l=i(61138),s=i(41123),d=i(62047),c=i(4968),h=i(12640);const g=a.A` .info-list{color:rgba(255,255,255,1)}.divider>div:not(:first-child){border-top:1px solid rgba(255,255,255,0.1)}.list-content{background:rgba(26,26,26,0.5)}`,p=a.A` .list-container{text-decoration:none;${c.f}}.info-list{width:268px;height:fit-content;display:flex;flex-direction:column;color:rgba(36,36,36,1)}.list-header{display:flex;flex-direction:row;justify-content:space-between;margin-bottom:6px;align-items:baseline}.list-title{font-weight:600;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px)}.list-sub-title{font-weight:600;font-size:${l.k}}.list-content{display:flex;flex-direction:column;width:100%;border-radius:8px;background:rgba(255,255,255,0.5);padding:0 12px;box-sizing:border-box;overflow:hidden}.hero-bg{background:var(--sports-item-background)}.hero-bg:hover,.hero-bg:focus-visible{background:var(--sports-item-hover-background)}.list-content._1x_1y{max-height:42px}.list-content._1x_2y{max-height:200px}.list-content._1x_3y{max-height:358px}._1x_1y.list-header{margin-bottom:4px}._1x_1y .list-title{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}._1x_1y .list-sub-title{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.divider>div:not(:first-child){border-top:1px solid rgba(0,0,0,0.05)}.content-item{display:flex;flex-direction:row;align-items:center;gap:8px;height:50px;box-sizing:border-box}.content-item .hero-bg{border-radius:8px}.content-item.small{height:50px;padding:9px 0px;&>img{width:32px;height:32px};&>.content-middle{height:32px}}._1x_1y>.content-item.small{height:42px;&>.content-middle{height:32px}}.content-item.medium{height:66px;padding:6px 0px;&>img{width:40px;height:40px}}.content-item.large{height:96px;padding:12px 0px;&>img{width:54px;height:54px}}.content-middle{display:flex;flex-direction:column;justify-content:space-between;height:38px;width:100%;flex-grow:2;min-width:0}.content-title{font-weight:600;font-size:${s.K};
        line-height: ${s.Z};text-overflow:ellipsis;overflow:hidden;white-space:nowrap}.small>.content-middle>.content-title{font-size:${l.k};
        line-height: ${l.F}}.content-sub-title{font-weight:400;font-size:${l.k};
        line-height: ${l.F};white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.small>.content-middle>.content-sub-title{font-size:${d.t};
        line-height: ${d.e}}.content-des{font-weight:600;line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);white-space:nowrap}.small>.content-des{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}`.withBehaviors(new h.N(null,g),(0,n.mr)(a.A` :host{forced-color-adjust:auto}`));var f=i(96950),u=i(69259),x=i(50180),b=i(39957);const m=f.qy`
    <div class="content-item ${(e,t)=>t.parent.viewModel.itemSize} ${(e,t)=>t.parent.viewModel.hasItemBg?"hero-bg":""}" style="${e=>e.itemStyle?e.itemStyle:""}">
        ${(0,u.z)(e=>e.icon&&!(0,x.oT)(e.icon),f.qy`
            <img
                class="content-icon"
                style="${e=>e.iconStyle?e.iconStyle:""}"
                role="presentation"
                onerror="this.style.visibility='hidden'"
                src="${e=>e.icon}"/>`)}
        <div class="content-middle" style="${e=>e.contentMiddleStyle||""}">
            <div class="content-title" title="${e=>e.title}">${e=>e.title}</div>
            <div class="content-sub-title" title="${e=>e.subTitle}">${e=>e.subTitle}</div>
        </div>
        ${(0,u.z)(e=>e.des&&!(0,x.oT)(e.des),f.qy`
            <div class="content-des" style="${e=>e.desStyle?e.desStyle:""}">${e=>e.des}</div>
        `)}
    </div>
`,v=f.qy`
    <div class="list-header ${e=>e.viewModel.cardSize}">
        <div class="list-title" title="${e=>e.viewModel.title}">${e=>e.viewModel.title}</div>
        ${(0,u.z)(e=>e.viewModel.subTitle,f.qy`<div class="list-sub-title" title="${e=>e.viewModel.subTitle}">${e=>e.viewModel.subTitle}</div>`)}
    </div>
`,$=f.qy`
    <a 
        class="${e=>e.viewModel.clickThroughUrl?"list-container":""}"
        href="${e=>e.viewModel.clickThroughUrl?e.viewModel.clickThroughUrl:void 0}"
        target="_blank"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        <div class="info-list">
            ${(0,u.z)(e=>e.viewModel.title||e.viewModel.subTitle,v)}
            <div class="
                list-content
                ${e=>e.viewModel.cardSize}
                ${e=>e.viewModel.showDivider?"divider":""}
                ${e=>e.viewModel.hasItemBg?"":"hero-bg"}
            "
                style="${e=>e.viewModel.listStyle?e.viewModel.listStyle:""}"
            >
                ${(0,b.ux)(e=>e.viewModel.items,m)}
            </div>
        </div>
    </a>
`,y=f.qy`
    ${(0,u.z)(e=>null!=e.viewModel,$)}
`;var w=i(84564);class k extends w.z{}let z=class extends k{};z=(0,r.Cg)([(0,o.E)({name:"sports-info-list",template:y,styles:p,shadowOptions:{delegatesFocus:!0}})],z)},99657(e,t,i){i.d(t,{D(){return n},I(){return a}});var r=i(45755);const{create:o}=r.G,a=o("sloppy-click-z-index",1),n=o("click-z-index",1)}}]);