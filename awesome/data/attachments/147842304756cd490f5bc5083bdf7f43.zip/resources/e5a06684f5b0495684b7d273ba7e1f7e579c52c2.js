// © Microsoft Corporation. All rights reserved.
import { appEnvironment } from "@msnews/core";
import { ColumnArrangement, fastBreakpointManager, overrideMinViewportWidths, updateColumnWidths } from "@msnews/experiences-base";
const feedViewGutter = 12;
export function setupBreakpoint(config) {
    // Override the breakpoints for Homepage
    let breakpoints = [0, 0, 995, 1325];
    // Override Media Query bounds so that it will not add the 32 pixel buffer to media queries.
    let newViewportWidths = new Map([
        [ColumnArrangement.c1, 0],
        [ColumnArrangement.c2, 0],
        [ColumnArrangement.c3, 995],
        [ColumnArrangement.c4, 1325]
    ]);
    if (config.enableWaterfallViewFeed) {
        appEnvironment.EnableFiveColLayout = true;
        updateColumnWidths(feedViewGutter);
        breakpoints = [332, 644, 956, 1268, 1580];
        newViewportWidths = new Map([
            [ColumnArrangement.c1, breakpoints[0]],
            [ColumnArrangement.c2, breakpoints[1]],
            [ColumnArrangement.c3, breakpoints[2]],
            [ColumnArrangement.c4, breakpoints[3]],
            [ColumnArrangement.c5, breakpoints[4]]
        ]);
    }
    else {
        // Check for five column support
        // if the rail is enabled, the Rail will occupy the fifth column, and the feed will remain in 4 columns
        if (config.enableFifthColumn || config.showRailInLayouts?.length) {
            const c5Value = 1800;
            appEnvironment.EnableFiveColLayout = true;
            breakpoints.push(c5Value);
            newViewportWidths.set(ColumnArrangement.c5, c5Value);
        }
    }
    fastBreakpointManager().useRequestIsolatedTracker = true;
    fastBreakpointManager().breakpoints = breakpoints;
    overrideMinViewportWidths(newViewportWidths);
}
//# sourceMappingURL=breakpoints.js.map