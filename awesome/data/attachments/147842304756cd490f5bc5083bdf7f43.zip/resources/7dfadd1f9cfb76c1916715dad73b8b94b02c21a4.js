export function insertContentIntoTemplate(templateData, title, headData, bodyData) {
    // Replace title attribute
    const titleStartIndex = findTitleStartIndex(templateData.html);
    let titleFixed = false;
    let htmlTemplate = templateData.html;
    const titleString = `<title>${title || "MSN"}</title>`;
    if (titleStartIndex >= 0) {
        const templateHeadDataPreTitle = templateData.html.slice(0, titleStartIndex);
        const templateHeadDataPostTitle = templateData.html.slice(findTitleEndIndex(templateData.html, titleStartIndex) + 8); // 8 chars for </title>
        htmlTemplate = `
            ${templateHeadDataPreTitle}
            ${titleString}
            ${templateHeadDataPostTitle}
        `;
        titleFixed = true;
    }
    // Insert metatags into head
    const templateHeadDataHtmlInsertionIndex = findIndexOfEndTag(htmlTemplate, "<head ", "</head>");
    let templateHeadDataHtmlTop = htmlTemplate.slice(0, templateHeadDataHtmlInsertionIndex);
    const templateHeadDataHtmlBottom = htmlTemplate.slice(templateHeadDataHtmlInsertionIndex);
    // Check if there is any <div> tag before templateHeadDataHtmlInsertionIndex, if there is, delete the entire tag
    const divTagIndex = templateHeadDataHtmlTop.indexOf("<div");
    const divTagEndIndex = templateHeadDataHtmlTop.indexOf("</div>");
    if (divTagIndex >= 0 && divTagEndIndex >= 0) {
        const templateHeadDataHtmlTopPreDiv = templateHeadDataHtmlTop.slice(0, divTagIndex);
        const templateHeadDataHtmlTopPostDiv = templateHeadDataHtmlTop.slice(divTagEndIndex + 6); // 6 chars for </div>
        templateHeadDataHtmlTop = templateHeadDataHtmlTopPreDiv + templateHeadDataHtmlTopPostDiv;
    }
    // Insert body HTML into body
    const templateBodyDataHtmlInsertionIndex = findIndexOfEndTag(templateHeadDataHtmlBottom, "<div id=\"root\"", "</div>");
    const templateBodyDataHtmlTop = templateHeadDataHtmlBottom.slice(0, templateBodyDataHtmlInsertionIndex);
    const templateBodyDataHtmlBottom = templateHeadDataHtmlBottom.slice(templateBodyDataHtmlInsertionIndex);
    const assembledHTML = `
        ${templateHeadDataHtmlTop}
        ${headData || ""}
        ${titleFixed ? "" : titleString}
        ${templateBodyDataHtmlTop}
        ${bodyData || ""}
        ${templateBodyDataHtmlBottom}
    `;
    return assembledHTML;
}
function findTitleStartIndex(templateDataHtml) {
    return templateDataHtml.indexOf("<title>");
}
function findTitleEndIndex(templateDataHtml, startIndex) {
    return templateDataHtml.indexOf("</title>", startIndex);
}
function findIndexOfEndTag(templateDataHtml, startTag, endTag) {
    const startTagIndex = templateDataHtml.indexOf(startTag);
    return templateDataHtml.indexOf(endTag, startTagIndex);
}
//# sourceMappingURL=static-renderer.js.map