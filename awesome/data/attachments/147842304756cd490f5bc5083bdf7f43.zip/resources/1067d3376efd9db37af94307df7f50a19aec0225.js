"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["marketplace-card-wc"],{4968(t,e,a){a.d(e,{f(){return l}});var i=a(64187),s=a(74849),o=a(42792),n=a(99657),r=a(36452);const l=s.A.partial`position: relative; z-index: ${n.D};`;s.A`
    ${o.e}
    ${o.nH}

    ${(0,i.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${r.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${r.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${r.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},5993(t,e,a){a.d(e,{V(){return n},m(){return r}});var i=a(47264),s=a(73182),o=a(96950);s.MsnActionsMenu;const n=function(t,e,a,s){let n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"more-actions",r=arguments.length>5&&void 0!==arguments[5]&&arguments[5];return o.qy`
        <fluent-button
            slot="${n}"
            appearance="neutral"
            class=${s??""}
            @click=${t}
            data-t=${t=>e}
            title="${a}"
            aria-label="${a}"
            aria-expanded="${r}"
            role="button"
        >
            ${o.qy.partial(i.A)}
        </fluent-button>
    `},r=function(t,e,a){let i=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"end";return o.qy`
        <msn-actions-menu 
            :referrerButton=${e=>t}
            :menuItems=${t=>e}
            :useFastAnchoredRegion=${t=>!0!==a}
            defaultHorizontalPosition=${i}
        />
    `}},7014(t,e,a){a.d(e,{m(){return j}});var i=a(56911),s=a(38493),o=a(60815),n=a(55230),r=a(92011),l=a(56863);class c extends r.L{}class d extends((0,l.dx)(c)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class p extends d{constructor(){super(),this.initialValue="on",this.keypressHandler=t=>{if(!this.readOnly)switch(t.key){case n.Mm:case n.gG:this.checked=!this.checked}},this.clickHandler=t=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(t,e){super.checkedChanged(t,e),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,i.Cg)([(0,s.CF)({attribute:"readonly",mode:"boolean"}),(0,i.Sn)("design:type",Boolean)],p.prototype,"readOnly",void 0),(0,i.Cg)([o.sH,(0,i.Sn)("design:type",Array)],p.prototype,"defaultSlottedNodes",void 0);var m=a(37180),h=a(74849),g=a(64187),u=a(60993),v=a(73477),k=a(22131),f=a(50882),b=a(48196),x=a(86856),$=a(7896),T=a(74838),y=a(79288),w=a(46203),_=a(26920),C=a(43774),A=a(95239),D=a(14996),L=a(48751),F=a(41123),S=a(74089),z=a(4283);const I=h.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,g.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${$.O};
        margin: calc(${T.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${y.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${u.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${b.D} / 2) + ${T.vR}) * 2px);
        height: calc(((${b.D} / 2) + ${T.vR}) * 1px);
        background: ${w.le};
        border-radius: calc(${b.D} * 1px);
        border: calc(${_.XA} * 1px) solid ${C.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${w.jM};
        border-color: ${C.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${w.RS};
        border-color: ${C.p4};
    }

    :host(:${v.N}) .switch {
        box-shadow: 0 0 0 2px ${A.p}, 0 0 0 4px ${D.WN};
        border-color: ${D.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${b.D} - (${T.vR} * 5.5)) * 1px);
        width: calc((${b.D} - (${T.vR} * 5.5)) * 1px);
        top: calc(${T.vR} * 1px);
        background: ${L.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${L.l};
        cursor: pointer;
        font-size: ${F.K};
        line-height: ${F.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${L.l};
        font-size: ${F.K};
        line-height: ${F.Z};
        margin-inline-end: calc(${T.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${T.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${S.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${z.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${z.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${S.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${z.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${S.J_};
    }

    :host([aria-checked="true"]:${v.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${A.p}, 0 0 0 4px ${D.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new x.t(h.A`
            .checked-indicator {
                left: calc(${T.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${b.D} / 2) + ${T.vR}) + ${T.vR}) * 1px
                );
            }
        `,h.A`
            .checked-indicator {
                right: calc(${T.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${b.D} / 2) + ${T.vR}) + ${T.vR}) * 1px
                );
            }
        `),(0,k.mr)(h.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${f.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${f.A.Field};
                border-color: ${f.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${f.A.HighlightText};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${f.A.Highlight};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${f.A.HighlightText};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${f.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${f.A.Highlight};
            }
            :host(:${v.N}) .switch {
                border-color: ${f.A.Highlight};
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([aria-checked="true"]:${v.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${f.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${f.A.Field};
                border-color: ${f.A.GrayText};
            }
            .status-message,
            .label {
                color: ${f.A.FieldText};
            }
        `));var U=a(96950),B=a(82774),M=a(18893);const P=function(t={}){return U.qy`
        <template
            role="switch"
            aria-checked="${t=>t.checked}"
            aria-disabled="${t=>t.disabled}"
            aria-readonly="${t=>t.readOnly}"
            tabindex="${t=>t.disabled?null:0}"
            @keypress="${(t,e)=>t.keypressHandler(e.event)}"
            @click="${(t,e)=>t.clickHandler(e.event)}"
        >
            <label
                part="label"
                class="${t=>t.defaultSlottedNodes&&t.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,B.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,M.R)(t.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:U.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),j=class extends p{}.compose({name:`${m.c.prefix}-switch`,template:P,styles:I})},13509(t,e){e.A='<svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path clip-rule="evenodd" d="M7.5 9c0 .7-.24 1.33-.63 1.84l2.77 2.77a.37.37 0 1 1-.53.53l-2.77-2.77A3 3 0 1 1 7.5 9Zm-3 2.25a2.25 2.25 0 1 0 0-4.5 2.25 2.25 0 0 0 0 4.5Z"/><path clip-rule="evenodd" d="M4.13 2.25c-.21 0-.38.17-.38.38v2.7c-.26.05-.51.13-.75.23V2.63C3 2 3.5 1.5 4.13 1.5h3.8c.3 0 .6.12.8.33l2.94 2.94c.21.2.33.5.33.8v6.8c0 .63-.5 1.13-1.13 1.13h-.44c-.05-.15-.14-.3-.26-.42l-.33-.33h1.04c.2 0 .37-.17.37-.38V6H8.62C8 6 7.5 5.5 7.5 4.87V2.25H4.12Zm4.12.16v2.46c0 .21.17.38.38.38h2.46L8.25 2.41Z"/></svg>'},25717(t,e,a){a.d(e,{T(){return s}});var i=a(96950);function s(){return i.qy`
        <slot></slot>
    `}},31422(t,e){e.A='<svg width="14" height="14" viewBox="0 0 14 14"><path d="M.4.15A.5.5 0 0 0 .37.8l.05.05 2.69 2.7A6.66 6.66 0 0 0 .46 7.36a.5.5 0 0 0 .97.25 5.66 5.66 0 0 1 2.39-3.36l1.2 1.2A2.67 2.67 0 0 0 8.8 9.25l3.95 3.94a.5.5 0 0 0 .75-.65l-.04-.05L9.37 8.4l-.8-.8L6.66 5.7 4.74 3.77l-.76-.75L1.13.15a.5.5 0 0 0-.71 0Zm5.33 6.03 2.36 2.35a1.67 1.67 0 0 1-2.36-2.35Zm1.2-3.85A6.66 6.66 0 0 0 5 2.62l.83.82a5.67 5.67 0 0 1 6.6 4.18.5.5 0 0 0 .96-.24 6.67 6.67 0 0 0-6.46-5.05Zm.13 2.34 2.53 2.54a2.67 2.67 0 0 0-2.53-2.54Z" fill-opacity=".83"/></svg>'},37256(t,e,a){a.d(e,{R(){return p}});var i=a(64187),s=a(22131),o=a(74849),n=a(50882),r=a(37998),l=a(57416),c=a(95239),d=a(48751);const p=o.A`
    ${(0,i.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${c.p};
        color: ${d.l};
        border-radius: calc(${l.JU} * 1px);
        ${r.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,s.mr)(o.A`
            :host {
                forced-color-adjust: none;
                background: ${n.A.Canvas};
                box-shadow: 0 0 0 1px ${n.A.CanvasText};
            }
        `))},38319(t,e,a){a.d(e,{t(){return m}});var i=a(56911),s=a(13509),o=a(31422),n=a(80541),r=a(93552),l=a(77367),c=a(60815),d=a(71398),p=a(40865);class m{constructor(t,e,a,i,s){this.menuItems=[],this.isActionMenuOpen=!1,this.actionsMenuButtonElement=null,this.onOutsideClick=t=>{const e=t.composedPath()&&t.composedPath()[0];t.target instanceof this.currentSDClass||(0,p.W)(this.actionsMenuButtonElement,e)||this.toggleActionMenu(!1,null)},this.onKeydown=t=>{"Escape"===t.code&&this.toggleActionMenu(!1,null)},this.moreSettingAction=async()=>{this.toggleActionMenu(!1,null),this.goToPersonalizeSettingsCallback&&this.goToPersonalizeSettingsCallback()},this.hideSettingAction=async()=>{if(!this.segmentSdCardType)return!1;try{const t=await d.d.updateSegmentCardsEnableStatus([{cardType:this.segmentSdCardType,enabled:!1}]);return t&&this.refreshSDCardSection&&this.refreshSDCardSection(),this.toggleActionMenu(!1,null),t}catch(t){return l.YT.sendAppErrorEvent({...r.N2u,message:`Fail to hide ${this.segmentSdCardType} Card .`,pb:{...r.N2u.pb,customMessage:`Failed with exception : ${t}`}}),!1}},this.currentSDClass=t,this.settingMenuConfig=a,this.goToPersonalizeSettingsCallback=i,this.refreshSDCardSection=s,this.menuItems=this.getBaseActionMenuItems(),this.segmentSdCardType=e}updateMenuItems(t,e){this.menuItems=e?this.menuItems.concat(t):t.concat(this.menuItems)}toggleActionMenu(t,e){this.isActionMenuOpen=t,t?(this.actionsMenuButtonElement=e&&e.currentTarget,this.setAriaExpanded(t),document.addEventListener("click",this.onOutsideClick),document.addEventListener("keydown",this.onKeydown)):(this.setAriaExpanded(t),this.actionsMenuButtonElement=null,document.removeEventListener("click",this.onOutsideClick),document.removeEventListener("keydown",this.onKeydown))}setAriaExpanded(t){this.actionsMenuButtonElement&&(this.actionsMenuButtonElement.ariaExpanded=String(t))}getBaseActionMenuItems(){var t,e;if(!this.settingMenuConfig)return[];const a=[];if(null!==(t=this.settingMenuConfig.interestSetting)&&void 0!==t&&t.onClick){const t=this.settingMenuConfig.interestSetting;a.push({glyph:o.A,title:t.title,id:"dislike",onClick:t.onClick,telemetryTag:t.telemetryTag})}if(null!==(e=this.settingMenuConfig.dataProviderSetting)&&void 0!==e&&e.onClick){const t=this.settingMenuConfig.dataProviderSetting;a.push({glyph:s.A,title:t.title,id:"dataProvider",onClick:t.onClick,telemetryTag:t.telemetryTag})}if(this.settingMenuConfig.hideSetting){const t=this.settingMenuConfig.hideSetting;a.push({glyph:o.A,title:t.title,id:"hide",onClick:t.onClick?t.onClick:()=>this.hideSettingAction(),telemetryTag:t.telemetryTag})}if(this.settingMenuConfig.moreSetting){const t=this.settingMenuConfig.moreSetting;a.push({glyph:n.A,ariaLabel:t.ariaLabel,title:t.title,id:"more",onClick:t.onClick?t.onClick:()=>this.moreSettingAction(),telemetryTag:t.telemetryTag})}return a}}(0,i.Cg)([c.sH],m.prototype,"menuItems",void 0),(0,i.Cg)([c.sH],m.prototype,"isActionMenuOpen",void 0)},38380(t,e,a){a.d(e,{v(){return i}});const i=(0,a(25717).T)()},43774(t,e,a){a.d(e,{p4(){return u},ls(){return v},vA(){return g},nF(){return h}});var i=a(45755),s=a(68009),o=a(95239);const{create:n}=i.G,r=n("neutral-stroke-strong-hover-delta",40),l=n("neutral-stroke-strong-active-delta",16),c=n("neutral-stroke-strong-focus-delta",25);var d=a(31023);const{create:p}=i.G,m=p({name:"neutral-stroke-strong-recipe"},{evaluate(t){return function(t,e,a,i,o,n){const r=(0,s.F)(e),l=t.colorContrast(e,a),c=t.closestIndexOf(l);return{rest:l,hover:t.get(c+r*i),active:t.get(c+r*o),focus:t.get(c+r*n)}}(t(d.r),t(o.p),3,t(r),t(l),t(c))}}),h=p("neutral-stroke-strong-rest",t=>t(m).evaluate(t).rest),g=p("neutral-stroke-strong-hover",t=>t(m).evaluate(t).hover),u=p("neutral-stroke-strong-active",t=>t(m).evaluate(t).active),v=p("neutral-stroke-strong-focus",t=>t(m).evaluate(t).focus)},47264(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20"><path d="M6 10a1.25 1.25 0 1 1-2.5 0A1.25 1.25 0 0 1 6 10zM11.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0zM15.25 11.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5z"/></svg>'},72526(t,e,a){a.d(e,{L(){return g}});var i=a(56911),s=a(96193),o=a(47429),n=a(60815),r=a(22870),l=a(38493),c=a(95239),d=a(31023),p=a(24458),m=a(5291),h=a(57606);class g extends s.z{cardFillColorChanged(t,e){if(e){const t=(0,r.Hs)(e);null!==t&&(this.neutralPaletteSource=e,c.p.setValueFor(this,m.q.create(t.r,t.g,t.b)))}}neutralPaletteSourceChanged(t,e){if(e){const t=(0,r.Hs)(e),a=m.q.create(t.r,t.g,t.b);d.r.setValueFor(this,h.p.create(a))}}handleChange(t,e){this.cardFillColor||c.p.setValueFor(this,t=>t(p.M3).evaluate(t,t(c.p)))}connectedCallback(){super.connectedCallback();const t=(0,o.Zo)(this);if(t){const e=n.cP.getNotifier(t);e.subscribe(this,"fillColor"),e.subscribe(this,"neutralPalette"),this.handleChange(t,"fillColor")}}}(0,i.Cg)([(0,l.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,i.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,i.Cg)([(0,l.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,i.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0)},75003(t,e,a){a.d(e,{m(){return r}});var i=a(37180),s=a(72526),o=a(37256),n=a(38380);const r=s.L.compose({name:`${i.c.prefix}-card`,template:n.v,styles:o.R})},77216(t,e,a){a.r(e),a.d(e,{MarketplaceCardWC(){return O},MarketplaceCardWCStyles(){return X},MarketplaceCardWCTemplate(){return Yt},ToolingInfo(){return Kt}});var i=a(91956),s=a(75003),o=a(37180),n=a(7574),r=a(56911);const l="cardactionellipsis",c="footer",d="subheader",p="tagline",m="hidecard",h="header",g="MarketplaceCardWC",u="image",v="moresettings",k="previousslidearrow",f="PreviousSlideArrow",b="nextslidearrow",x="NextSlideArrow",$="body-Image",T="customization",y="header",w="description",_="image",C="classlength",A="classdifficulty";var D=a(22341),L=a(93552),F=a(17918),S=a(38319),z=a(77367),I=a(85349),U=a(60815),B=a(12680),M=a(29658),P=a(39671),j=a(71398),H=a(19359);const R="https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1fZxZz.img",E="MULTIPLE_SD_CARD",N="BTS_MULTI_SD_CARD";class O extends P.U{constructor(){super(),this.cardNumber=0,this.superSDCardNumber=0,this.isActionMenuOpen=!1,this.actionMenuItems=[],this.logoLink=[],this.refreshFeedCard=()=>{this.refreshFeed?this.refreshFeed():this.$emit("refreshSDCardSection")},this.initializeDataSuperSD=t=>{try{this.cardsData=t}catch(t){(0,D.c_)(t,L.XcU,"Error when parse Marketplace Super SD Json Data.")}},this.initializeDataBTSSuperSD=t=>{try{this.btsCardsData=t}catch(t){(0,D.c_)(t,L.XcU,"Error when parse Marketplace Super SD Json Data.")}},this.mapBTSSuperSDCardData=()=>{var t,e,a,i,s,o,n,r,l,c,d;this.btsCardData=this.getBTSMarketplaceEventCardData(this.btsCardsData,this.superSDCardNumber),this.data={id:"marketplace_"+this.superSDCardNumber,gridArea:"",childTemplateType:"sd-card",cardSize:"_1x_2y",metadata:{cardType:M.s.MarketPlaceCard},immersiveCard:!0,darkImmersiveImage:{source:"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1fVVX7.img",altText:"back to school"},lightImmersiveImage:{source:"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AA1fW32U.img",altText:"back to school"},headerData:{headerLogo:this.getIcon(R),logoNavigationLink:null===(t=this.btsCardData)||void 0===t?void 0:t.LogoClickUrl,title:null===(e=this.btsCardData)||void 0===e?void 0:e.LogoCaption,titleNavigationLink:null===(a=this.btsCardData)||void 0===a?void 0:a.LogoCaptionClickUrl,actionMenuData:{hideCardCallback:this.hideCard,moreSettingsPersonalizeCallback:this.moreSettingsAction},telemetryDestinationUrl:{logo:null===(i=this.btsCardData)||void 0===i?void 0:i.LogoClickUrl,title:null===(s=this.btsCardData)||void 0===s?void 0:s.LogoCaption},telemetryHeadlines:{logo:null===(o=this.btsCardData)||void 0===o?void 0:o.LogoCaption,title:null===(n=this.btsCardData)||void 0===n?void 0:n.LogoCaption}},footerData:{footerLink:{text:null===(r=this.btsCardData)||void 0===r?void 0:r.CardButtonCaption,navigationUrl:null===(l=this.btsCardData)||void 0===l?void 0:l.CardButtonClickUrl},paginationData:{currentPageIndex:this.superSDCardNumber+1,onFlipperClick:this.onBTSFlipperClick,pageCount:null!=this.btsCardsData?null===(c=this.btsCardsData)||void 0===c?void 0:c.BackToSchoolEventCards.length:0},telemetryHeadlines:{paginationNext:x,paginationPrevious:f,footerLink:null===(d=this.btsCardData)||void 0===d?void 0:d.CardButtonCaption}},parentTelemetryObject:this.marketplaceCardTelemetryObject}},this.onBTSFlipperClick=(t,e)=>{t?this.refreshBTSMarketplaceContentCardData(1):this.refreshBTSMarketplaceContentCardData(-1)},this.mapSuperSDCardData=()=>{var t,e,a,i,s,o,n,r,l,c;this.cardData=this.getMarketplaceEventCardData(this.cardsData,this.superSDCardNumber),this.data={id:"marketplace_"+this.superSDCardNumber,gridArea:"",childTemplateType:"sd-card",cardSize:"_1x_2y",metadata:{cardType:M.s.MarketPlaceCard},headerData:{headerLogo:this.getIcon(R),logoNavigationLink:null===(t=this.cardData)||void 0===t?void 0:t.LogoActionLink,title:null===(e=this.cardData)||void 0===e?void 0:e.LogoText,titleNavigationLink:null===(a=this.cardData)||void 0===a?void 0:a.ClickthroughUrl,actionMenuData:{hideCardCallback:this.hideCard,moreSettingsPersonalizeCallback:this.moreSettingsAction},telemetryDestinationUrl:{logo:null===(i=this.cardData)||void 0===i?void 0:i.LogoActionLink,title:null===(s=this.cardData)||void 0===s?void 0:s.LogoTextLink},telemetryHeadlines:{logo:null===(o=this.cardData)||void 0===o?void 0:o.Tagline,title:null===(n=this.cardData)||void 0===n?void 0:n.Tagline}},footerData:{footerLink:{text:null===(r=this.cardData)||void 0===r?void 0:r.CallToActionText,navigationUrl:null===(l=this.cardData)||void 0===l?void 0:l.CallToActionLink},paginationData:{currentPageIndex:this.superSDCardNumber+1,onFlipperClick:this.onFlipperClick,pageCount:null!=this.cardsData?this.cardsData.SingleSDCards.length:0},telemetryHeadlines:{paginationNext:x,paginationPrevious:f,footerLink:null===(c=this.cardData)||void 0===c?void 0:c.Tagline}},parentTelemetryObject:this.marketplaceCardTelemetryObject}},this.onFlipperClick=(t,e)=>{t?this.refreshMarketplaceContentCardData(1):this.refreshMarketplaceContentCardData(-1)},this.getBTSMarketplaceEventCardData=(t,e)=>{const a=t.BackToSchoolEventCards[e];return 2==e?{CardType:t.CardType,ImageOneUrl:a.ImageOneUrl+"?w=300&h=300",ImageOneClickUrl:a.ImageOneClickUrl,ImageTwoUrl:a.ImageTwoUrl+"?w=300&h=300",ImageTwoClickUrl:a.ImageTwoClickUrl,ImageThreeUrl:a.ImageThreeUrl+"?w=300&h=300",ImageThreeClickUrl:a.ImageThreeClickUrl,ImageFourUrl:a.ImageFourUrl+"?w=300&h=300",ImageFourClickUrl:a.ImageFourClickUrl,CaptionOne:a.CaptionOne,CaptionOneClickUrl:a.CaptionOneClickUrl,CaptionTwo:a.CaptionTwo,CaptionTwoClickUrl:a.CaptionTwoClickUrl,CaptionThree:a.CaptionThree,CaptionThreeClickUrl:a.CaptionThreeClickUrl,CaptionFour:a.CaptionFour,CaptionFourClickUrl:a.CaptionFourClickUrl,CardButtonCaption:a.CardButtonCaption,CardButtonClickUrl:a.CardButtonClickUrl,LogoCaption:a.LogoCaption,LogoClickUrl:a.LogoClickUrl,LogoCaptionClickUrl:a.LogoCaptionClickUrl}:{CardType:t.CardType,ImageOneUrl:a.ImageOneUrl+"?w=900&h=900",ImageOneClickUrl:a.ImageOneClickUrl,ImageTwoUrl:a.ImageTwoUrl+"?w=900&h=900",ImageTwoClickUrl:a.ImageTwoClickUrl,ImageThreeUrl:a.ImageThreeUrl+"?w=1000&h=1000",ImageThreeClickUrl:a.ImageThreeClickUrl,ImageFourUrl:a.ImageFourUrl+"?w=900&h=900",ImageFourClickUrl:a.ImageFourClickUrl,CaptionOne:a.CaptionOne,CaptionOneClickUrl:a.CaptionOneClickUrl,CaptionTwo:a.CaptionTwo,CaptionTwoClickUrl:a.CaptionTwoClickUrl,CaptionThree:a.CaptionThree,CaptionThreeClickUrl:a.CaptionThreeClickUrl,CaptionFour:a.CaptionFour,CaptionFourClickUrl:a.CaptionFourClickUrl,CardButtonCaption:a.CardButtonCaption,CardButtonClickUrl:a.CardButtonClickUrl,LogoCaption:a.LogoCaption,LogoClickUrl:a.LogoClickUrl,LogoCaptionClickUrl:a.LogoCaptionClickUrl}},this.getMarketplaceEventCardData=(t,e)=>{const a=t.SingleSDCards[e];return{CardType:t.CardType,ImageDataUrl:a.ImageDataUrl,ImageActionLink:a.ImageActionLink,CallToActionText:a.CallToActionText,CallToActionLink:a.CallToActionLink,LogoText:a.LogoText,LogoTextLink:a.LogoTextLink,LogoActionLink:a.LogoActionLink,Tagline:a.Tagline,TaglineLink:a.TaglineLink,Description:a.Description,DescriptionLink:a.DescriptionLink,Duration:a.Duration,DurationLink:a.DurationLink,Level:a.Level,LevelLink:a.LevelLink,ClickthroughUrl:a.ClickthroughUrl}},this.refreshBTSMarketplaceContentCardData=t=>{var e;const a=null!=this.btsCardsData?this.btsCardsData.BackToSchoolEventCards.length:1;this.superSDCardNumber=(this.superSDCardNumber+t)%a,this.superSDCardNumber<0&&(this.superSDCardNumber=(a+this.superSDCardNumber)%a),this.mapBTSSuperSDCardData(),null!==(e=this.btsCardData)&&void 0!==e&&e.ImageOneClickUrl&&z.YT.addOrUpdateTmplProperty("marketplace_destinationUrl",this.btsCardData.ImageOneClickUrl)},this.refreshMarketplaceContentCardData=t=>{var e;const a=null!=this.cardsData?this.cardsData.SingleSDCards.length:1;this.superSDCardNumber=(this.superSDCardNumber+t)%a,this.superSDCardNumber<0&&(this.superSDCardNumber=(a+this.superSDCardNumber)%a),this.mapSuperSDCardData(),null!==(e=this.cardData)&&void 0!==e&&e.ImageActionLink&&z.YT.addOrUpdateTmplProperty("marketplace_destinationUrl",this.cardData.ImageActionLink)},this.hideCard=async()=>{try{let t=!1;return t=await j.d.updateSegmentCardsEnableStatus([{cardType:M.s.MarketPlaceCard,enabled:!1}]),t&&(this.refreshFeedCard?this.refreshFeedCard():this.$emit("refreshSDCardSection")),t}catch(t){return(0,D.c_)(t,L.XcU,"customized error message"),!1}},this.moreSettingsAction=()=>{this.goToPersonalizeSettingsCallback?this.goToPersonalizeSettingsCallback():this.$emit("goToPersonalizeSettingsCallback")},this.data={id:"",gridArea:"",childTemplateType:"sd-card",headerData:{headerLogo:"",title:""}}}generateTelemetryTags(){var t;if(!this.telemetryObject)return;const e=null===(t=this.parentTelemetry)||void 0===t?void 0:t.contract,a=null==e?void 0:e.ext;this.marketplaceCardTelemetryObject=(0,H.g)(g,{type:I.b5.StructuredData},{ext:a}),this.marketplaceCardTelemetryTag=this.marketplaceCardTelemetryObject.getMetadataTag(),this.customizeTelemetryTag=(0,H.g)(T,{type:I.b5.StructuredData,headline:"More options"},I.MS.More,{ext:a}).getMetadataTag(),this.actionButtonTelemetryTag=(0,H.g)(l,{type:I.b5.StructuredData},I.MS.More,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.callToActionTelemetryTag=(0,H.g)(c,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.headlineTelemetryTag=(0,H.g)(d,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.taglineTelemtryTag=(0,H.g)(p,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.hideTakelessonsCardTelemetryTag=(0,H.g)(m,{type:I.b5.StructuredData},I.MS.Hide,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.logoHeaderTelemetryTag=(0,H.g)(h,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{destinationUrl:"https://takelessons.com",isCI:!0}).getMetadataTag();const i=this.marketplaceData;this.mainCardLogoLink=i.LogoLink,this.miniCardTelemetryTag=i&&i.SubjectCards&&i.SubjectCards.map((t,e)=>(this.logoLink[e]=t.LogoLink,(0,H.g)(u,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{destinationUrl:t.SecondaryClickthroughUrl,isCI:!0}).getMetadataTag())),this.moreMenuTelemetryTag=(0,H.g)(v,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.navigationArrowBackTelemetryTag=(0,H.g)(k,{type:I.b5.StructuredData,headline:f},I.MS.Paginate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.navigationArrowForwardTelemetryTag=(0,H.g)(b,{type:I.b5.StructuredData,headline:x},I.MS.Paginate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.imageTelemetryTag=(0,H.g)($,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.contentHeaderTelemetryTag=(0,H.g)(y,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.contentDescTelemetryTag=(0,H.g)(w,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.contentImageTelemetryTag=(0,H.g)(_,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.classLengthTelemetryTag=(0,H.g)(C,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag(),this.classDifficultyTelemetryTag=(0,H.g)(A,{type:I.b5.StructuredData},I.MS.Navigate,I.EG.Click,a,{isCI:!0}).getMetadataTag()}experienceConnected(){try{this.jsonMarketplaceData?this.marketplaceData=JSON.parse(this.jsonMarketplaceData):this.marketplaceData=JSON.parse('{"SubjectCards":[{"SecondaryClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardimage2&utm_term=TestPrep&utm_campaign=grouplessons","Title":"Master ACT in a live class today","ShortTitle":"ACT","Description":"Score higher in the ACT with our expert tutors in group lessons.","CallToAction":"Join for free","CallToActionLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cta2&utm_term=TestPrep&utm_campaign=grouplessons","ImageURL":"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAVcHwy.img","LogoLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardlogo2&utm_term=TestPrep&utm_campaign=grouplessons","CardType":"SUBJECT_CARD","ClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=tile-act&utm_term=TestPrep&utm_campaign=grouplessons"},{"SecondaryClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardimage3&utm_term=TestPrep&utm_campaign=grouplessons","Title":"Achieve the best score in SAT","ShortTitle":"SAT","Description":"Get effective SAT test prep with the most qualified online tutors","CallToAction":"Join for free","CallToActionLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cta3&utm_term=TestPrep&utm_campaign=grouplessons","ImageURL":"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAVcHwx.img","LogoLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardlogo3&utm_term=TestPrep&utm_campaign=grouplessons","CardType":"SUBJECT_CARD","ClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=tile-sat&utm_term=TestPrep&utm_campaign=grouplessons"},{"SecondaryClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardimage4&utm_term=TestPrep&utm_campaign=grouplessons","Title":"Intro to ACT/SAT Math","ShortTitle":"Math","Description":"This 5 class series is tailored for students studying to reach 20+ on the ACT","CallToAction":"Join for free","CallToActionLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cta4&utm_term=TestPrep&utm_campaign=grouplessons","ImageURL":"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAVcMwE.img","LogoLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardlogo4&utm_term=TestPrep&utm_campaign=grouplessons","CardType":"SUBJECT_CARD","ClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=tile-math&utm_term=TestPrep&utm_campaign=grouplessons"},{"SecondaryClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardimage5&utm_term=TestPrep&utm_campaign=grouplessons","Title":"Ace your exams with Science tutors","ShortTitle":"Science","Description":"Master ACT and SAT sections and practice common test strategies with expert teachers in online classes","CallToAction":"Join for free","CallToActionLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cta5&utm_term=TestPrep&utm_campaign=grouplessons","ImageURL":"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAVcMwF.img","LogoLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardlogo5&utm_term=TestPrep&utm_campaign=grouplessons","CardType":"SUBJECT_CARD","ClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=tile-science&utm_term=TestPrep&utm_campaign=grouplessons"},{"SecondaryClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardimage6&utm_term=TestPrep&utm_campaign=grouplessons","Title":"ACT Reading Strategies","ShortTitle":"Reading","Description":"Master ACT practicing common test strategies with expert teachers.","CallToAction":"Join for free","CallToActionLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cta6&utm_term=TestPrep&utm_campaign=grouplessons","ImageURL":"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAVcMwD.img","LogoLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardlogo6&utm_term=TestPrep&utm_campaign=grouplessons","CardType":"SUBJECT_CARD","ClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=tile-reading&utm_term=TestPrep&utm_campaign=grouplessons"},{"SecondaryClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardimage7&utm_term=TestPrep&utm_campaign=grouplessons","Title":"ACT Essay Strategies","ShortTitle":"Writing","Description":"You will learn key tips and methods to increase ACT Essay Test scores","CallToAction":"Join for free","CallToActionLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cta7&utm_term=TestPrep&utm_campaign=grouplessons","ImageURL":"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAVcYdU.img","LogoLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardlogo7&utm_term=TestPrep&utm_campaign=grouplessons","CardType":"SUBJECT_CARD","ClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=tile-writing&utm_term=TestPrep&utm_campaign=grouplessons"},{"SecondaryClickthroughUrl":"https://takelessons.com/browse-lessons?utm_source=edge&utm_medium=ntp&utm_content=CTA-Browse-Lessons&coupon=$1PROMO&utm_flight=base&utm_campaign=testprep&utm_term=TestPrep","Title":"Reach your goals with the help of the best tutors in any subject.","ShortTitle":null,"Description":null,"CallToAction":"Explore now","CallToActionLink":"https://takelessons.com/browse-lessons?utm_source=edge&utm_medium=ntp&utm_content=CTA-Browse-Lessons&coupon=$1PROMO&utm_flight=base&utm_campaign=testprep&utm_term=TestPrep","ImageURL":"https://img-s-msn-com.akamaized.net/tenant/amp/entityid/AAS1RMh.img","LogoLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardlogo8&utm_term=TestPrep&utm_campaign=grouplessons","CardType":"SUBJECT_CARD","ClickthroughUrl":"https://takelessons.com/browse-lessons?utm_source=edge&utm_medium=ntp&utm_content=CTA-Browse-Lessons&coupon=$1PROMO&utm_flight=base&utm_campaign=testprep&utm_term=TestPrep"}],"Description":"Boost your scores with SAT and ACT courses. 8 live classes each month for FREE!","CallToAction":"Join for free","CallToActionLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cta-maincard&utm_term=TestPrep&utm_campaign=grouplessons","LogoLink":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=cardlogo&utm_term=TestPrep&utm_campaign=grouplessons","CardType":"MULTI_SUBJECT_CARD","ClickthroughUrl":"https://takelessons.com/live/test-prep?&utm_source=edge&utm_medium=ntp&utm_content=Headline-Main-card&utm_term=TestPrep&utm_campaign=grouplessons"}'),window.setInterval(()=>this.nextCard(),8e3)}catch(t){(0,D.c_)(t,L.XcU,"Error when parsing Marketplace Json Data.")}this.initSuperSDSetting(),this.generateTelemetryTags(),null!=this.marketplaceData&&this.marketplaceData.CardType==N&&(this.initializeDataBTSSuperSD(this.marketplaceData),this.mapBTSSuperSDCardData()),null!=this.marketplaceData&&this.marketplaceData.CardType==E&&(this.initializeDataSuperSD(this.marketplaceData),this.mapSuperSDCardData())}getIcon(t){return`<img style="margin: 0 0 0 -10px" src="${t}" alt="Header Logo" aria-hidden="true"/>`}getExperienceType(){return B.JY9}shadowDomPopulated(){(0,F.tt)(this.getExperienceType());let t="",e="";if(null!=this.marketplaceData)if(this.marketplaceData.CardType==N){const a=this.marketplaceData;null!=a.BackToSchoolEventCards&&a.BackToSchoolEventCards.length>0&&a.BackToSchoolEventCards[0].ImageOneClickUrl&&a.CardType&&(e=a.BackToSchoolEventCards[0].ImageOneClickUrl,t=a.CardType)}else if(this.marketplaceData.CardType==E){const a=this.marketplaceData;null!=a.SingleSDCards&&a.SingleSDCards.length>0&&a.SingleSDCards[0].CallToActionLink&&a.CardType&&(e=a.SingleSDCards[0].ImageActionLink,t=a.CardType)}else{const a=this.marketplaceData;a.CallToActionLink&&a.CardType&&(e=a.CallToActionLink,t=a.CardType)}""!=e&&z.YT.addOrUpdateTmplProperty("marketplace_destinationUrl",e),""!=t&&z.YT.addOrUpdateTmplProperty("marketplace_cardType",t)}initSuperSDSetting(){const t={moreSetting:{title:this.strings.takelessonsMoreSettings,telemetryTag:this.moreMenuTelemetryTag??""},hideSetting:{title:this.strings.takelessonsHideCard,telemetryTag:this.hideTakelessonsCardTelemetryTag??""}};this.superSDSetting=new S.t(O,M.s.MarketPlaceCard,t,this.goToPersonalizeSettingsCallback,this.refreshFeedCard)}nextCard(){this.cardNumber<7?this.cardNumber+=1:this.cardNumber=0}previousCard(){this.cardNumber>0?this.cardNumber-=1:this.cardNumber=7}get callTtvr(){return()=>{(0,F.oO)(this.getExperienceType())}}}(0,r.Cg)([U.sH],O.prototype,"marketplaceData",void 0),(0,r.Cg)([U.sH],O.prototype,"customizeTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"actionButtonTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"callToActionTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"headlineTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"taglineTelemtryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"hideTakelessonsCardTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"logoHeaderTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"marketplaceCardTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"miniCardTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"moreMenuTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"navigationArrowBackTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"navigationArrowForwardTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"imageTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"contentHeaderTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"contentDescTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"contentImageTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"classLengthTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"classDifficultyTelemetryTag",void 0),(0,r.Cg)([U.sH],O.prototype,"cardNumber",void 0),(0,r.Cg)([U.sH],O.prototype,"superSDCardNumber",void 0),(0,r.Cg)([U.sH],O.prototype,"isActionMenuOpen",void 0),(0,r.Cg)([U.sH],O.prototype,"actionMenuItems",void 0),(0,r.Cg)([U.sH],O.prototype,"superSDSetting",void 0),(0,r.Cg)([U.sH],O.prototype,"logoLink",void 0),(0,r.Cg)([U.sH],O.prototype,"mainCardLogoLink",void 0),(0,r.Cg)([U.sH],O.prototype,"data",void 0),(0,r.Cg)([U.sH],O.prototype,"cardsData",void 0),(0,r.Cg)([U.sH],O.prototype,"cardData",void 0),(0,r.Cg)([U.sH],O.prototype,"btsCardsData",void 0),(0,r.Cg)([U.sH],O.prototype,"btsCardData",void 0),(0,r.Cg)([U.Jg],O.prototype,"callTtvr",null);var J=a(73182),V=a(5993),Z=a(96950),W=a(69259),G=a(92011),q=a(4968),Y=a(74849),K=a(22131);const X=Y.A`a,button{${q.f}}fluent-card{--grid-gap:12;--example-card-height:146;--example-card-width:300}._1x_1y{--card-width:calc(var(--example-card-width) * 1px);--card-height:calc(var(--example-card-height) * 1px)}._1x_2y{--card-width:calc(var(--example-card-width) * 1px);--card-height:calc( (var(--example-card-height) * 2px) + (var(--grid-gap) * 1px) )}.heading-wrapper{display:flex;z-index:2;position:absolute;flex-direction:row;justify-content:space-between;align-items:center;padding-top:12px;padding-left:16px;padding-right:16px;width:268px}.heading-spacing{height:34px}.toggle-button{position:relative;background:rgba(0,0,0,0.07);border-radius:16px;height:24px;min-width:24px;width:24px}.toggle-button svg{width:24px;height:24px}.toggle-button:hover{opacity:0.7}.more-actions{display:flex;width:24px;height:24px;position:relative;justify-content:center;align-items:center;z-index:3}.linkText{margin-left:6px}.take-lessons-logo{display:flex;justify-content:center;align-items:end;color:inherit;text-decoration:inherit;font-size:12px}.light{color:white}.take-lessons-logo h5{margin:4px 0 0 0}.take-lessons-logo svg{margin-top:3px;fill:#3d88c9}.pointer{cursor:pointer}.inherit{color:inherit;text-decoration:inherit}.title{left:16px;align-items:center;display:flex;text-transform:uppercase;position:relative}.title a{color:rgb(0,0,0);font-family:${"Segoe UI"};
    font-size: 12px;
    font-weight: ${"600"};line-height:16px;text-decoration:none}.title:hover a{text-decoration:underline}.bottom-controls{display:grid;grid-template-columns:20px 40px 20px auto;bottom:12px;padding:0px 16px;width:calc(100% - 24px);position:absolute}.bottom-controls p{margin:1px auto;font-size:12px;line-height:16px}.bottom-controls a{text-align:right}.bottom-controls a button{padding:2px}.bottom-controls .arrow-button{padding:0px;border:none;background:none}.container{padding:0px 16px;position:relative}.marketplace_card_container{background:linear-gradient(315.76deg,rgba(28,126,213,0.18) 0%,rgba(226,241,255,0.6) 100%);contain:none;overflow:visible;content-visibility:visible}.marketplace_card_container_light{background:linear-gradient(135.76deg,#F2F7FD 0%,#BFD4F4 100%);contain:none;overflow:visible;content-visibility:visible;box-shadow:0px 2px 4px rgba(0,0,0,0.1);border-radius:6px}`.withBehaviors((0,K.G2)(Y.A` .marketplace_card_container{background:linear-gradient(315.76deg,#124068 0%,rgba(18,64,104,0.6) 100%)}.toggle-button{background:rgba(255,255,255,0.09)}.title a{color:#FFFFFF}.toggle-button svg path{fill:white}.bottom-controls .arrow-button{padding:0px;border:none;background:none;color:#FFFFFF}.slideCounter{color:#FFFFFF}.take-lessons-logo{color:white}`)),Q=Y.A`
.marketplace-bts-content-card{height:224px;margin-left:3px;margin-right:3px;display:flex}.left-container{width:50%;display:flex;flex-direction:column;justify-content:space-between}.right-container{width:50%;height:224px;position:relative}.right-container-card-one{display:flex;border-radius:8px;overflow:hidden;position:relative;margin-bottom:3px;margin-left:3px}.right-container-card-two{display:flex;border-radius:8px;overflow:hidden;position:relative;margin-top:3px;margin-left:3px}.left-container-card-one{display:flex;border-radius:8px;overflow:hidden;position:relative;margin-bottom:3px;margin-right:3px}.left-container-card-two{display:flex;border-radius:8px;overflow:hidden;position:relative;margin-top:3px;margin-right:3px}.right-container-card-two img{object-fit:cover;-moz-transform:scale(1);-webkit-transform:scale(1);transform:scale(1);transition:0.7s ease all;-webkit-transition:0.7s ease all;-moz-transition:0.7s ease all}.right-container-card-one img{object-fit:cover;-moz-transform:scale(1);-webkit-transform:scale(1);transform:scale(1);transition:0.7s ease all;-webkit-transition:0.7s ease all;-moz-transition:0.7s ease all}.left-container-card-two img{object-fit:cover;-moz-transform:scale(1);-webkit-transform:scale(1);transform:scale(1);transition:0.7s ease all;-webkit-transition:0.7s ease all;-moz-transition:0.7s ease all}.left-container-card-one img{object-fit:cover;-moz-transform:scale(1);-webkit-transform:scale(1);transform:scale(1);transition:0.7s ease all;-webkit-transition:0.7s ease all;-moz-transition:0.7s ease all}.right-container-card-one:hover img{-moz-transform:scale(1.07);-webkit-transform:scale(1.07);transform:scale(1.07)}.right-container-card-two:hover img{-moz-transform:scale(1.07);-webkit-transform:scale(1.07);transform:scale(1.07)}.left-container-card-one:hover img{-moz-transform:scale(1.07);-webkit-transform:scale(1.07);transform:scale(1.07)}.left-container-card-two:hover img{-moz-transform:scale(1.07);-webkit-transform:scale(1.07);transform:scale(1.07)}.right-container-card:hover img{-moz-transform:scale(1.07);-webkit-transform:scale(1.07);transform:scale(1.07)}.right-container-card:hover .caption{text-decoration:underline}.right-container-card-two:hover .caption{text-decoration:underline}.right-container-card-one:hover .caption{text-decoration:underline}.left-container-card-two:hover .caption{text-decoration:underline}.left-container-card-one:hover .caption{text-decoration:underline}.right-container-card{display:flex;border-radius:8px;overflow:hidden;height:100%;margin-left:3px}.right-container-card img{width:100%;height:100%;border-radius:8px;object-fit:cover;-moz-transform:scale(1);-webkit-transform:scale(1);transform:scale(1);transition:0.7s ease all;-webkit-transition:0.7s ease all;-moz-transition:0.7s ease all}.caption{position:absolute;bottom:0;left:1;padding:5px;width:100%;box-sizing:border-box;color:#FFFFFF;font-family:Segoe UI;font-size:12px;font-style:normal;font-weight:600;line-height:16px}.mp_gradient{position:absolute;height:100%;width:100%;background:linear-gradient(rgba(0,0,0,0) 0%,rgba(0,0,0,0) 33%,rgba(0,0,0,0.54) 67%);border-radius:0 0px 8px 8px}.card-container{width:268px;height:224px;display:flex;flex-direction:column}.card-row{display:flex;align-items:center;justify-content:space-between;width:100%;height:33.33%}.card-caption{width:80%;max-width:calc(100% - 56px);overflow:hidden;color:var(--neutral-foreground-neutral-foreground-rest,#1A1A1A);text-overflow:ellipsis;whitespace:nowrap;font-family:Segoe UI;font-size:14px;font-style:normal;font-weight:600;margin-right:40px;line-height:20px}.card-row:hover .card-caption{text-decoration:underline}.card-image-container{border-radius:8px;width:54px;height:54px;position:relative}.card-image-container img{border-radius:8px;width:54px;height:54px;object-fit:cover;right:0;-moz-transform:scale(1);-webkit-transform:scale(1);transform:scale(1);transition:0.7s ease all;-webkit-transition:0.7s ease all;-moz-transition:0.7s ease all}.card-row:hover .card-image-container img{-moz-transform:scale(1.07);-webkit-transform:scale(1.07);transform:scale(1.07)}.marketplace-bts-content-card a{text-decoration:none}${X};
`.withBehaviors((0,K.G2)(Y.A` .card-caption{color:var(--dark-fill-color-text-primary,#FFF)}`)),tt=Z.qy`<div class="marketplace-bts-content-card">${(0,W.z)(t=>t.data&&1==t.cardNumber,Z.qy`<div class="left-container"><a class="left-container-card-one" href="${t=>t.data&&t.data.ImageOneClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageOneUrl}} title=${t=>t.data&&t.data.CaptionOne} alt="" /><div class="mp_gradient"></div><span class="caption" title=${t=>t.data&&t.data.CaptionOne}>${t=>t.data&&t.data.CaptionOne}</span></a><a class="left-container-card-two" href="${t=>t.data&&t.data.ImageTwoClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageTwoUrl}} title=${t=>t.data&&t.data.CaptionTwo} alt="" /><div class="mp_gradient"></div><span class="caption" title=${t=>t.data&&t.data.CaptionTwo}>${t=>t.data&&t.data.CaptionTwo}</span></a></div><div class="left-container"><a class="right-container-card-one" href="${t=>t.data&&t.data.ImageThreeClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageThreeUrl}} title=${t=>t.data&&t.data.CaptionThree} alt="" /><div class="mp_gradient"></div><span class="caption" title=${t=>t.data&&t.data.CaptionThree}>${t=>t.data&&t.data.CaptionThree}</span></a><a class="right-container-card-two" href="${t=>t.data&&t.data.ImageFourClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageFourUrl}} title=${t=>t.data&&t.data.CaptionFour} alt="" /><div class="mp_gradient"></div><span class="caption" title=${t=>t.data&&t.data.CaptionFour}>${t=>t.data&&t.data.CaptionFour}</span></a></div>`)}
${(0,W.z)(t=>t.data&&0==t.cardNumber,Z.qy`<div class="left-container"><a class="left-container-card-one" href="${t=>t.data&&t.data.ImageOneClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageOneUrl}} title=${t=>t.data&&t.data.CaptionOne} alt="" /><div class="mp_gradient"></div><span class="caption" title=${t=>t.data&&t.data.CaptionOne}>${t=>t.data&&t.data.CaptionOne}</span></a><a class="left-container-card-two" href="${t=>t.data&&t.data.ImageTwoClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageTwoUrl}} title=${t=>t.data&&t.data.CaptionTwo} alt="" /><div class="mp_gradient"></div><span class="caption" title=${t=>t.data&&t.data.CaptionTwo}>${t=>t.data&&t.data.CaptionTwo}</span></a></div><div class="right-container"><a class="right-container-card" href="${t=>t.data&&t.data.ImageThreeClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageThreeUrl}} title=${t=>t.data&&t.data.CaptionThree} alt="" /><div class="mp_gradient"></div><span class="caption" title=${t=>t.data&&t.data.CaptionThree}>${t=>t.data&&t.data.CaptionThree}</span></a></div>`)}
${(0,W.z)(t=>t.data&&2==t.cardNumber,Z.qy`<div class="card-container"><div class="card-row"><a href="${t=>t.data&&t.data.CaptionOneClickUrl}" target="_blank" data-t="${t=>t.contentDescTelemetryTag}"><span class="card-caption" title=${t=>t.data&&t.data.CaptionOne}>${t=>t.data&&t.data.CaptionOne}</span></a><a class="card-image-container" href="${t=>t.data&&t.data.ImageOneClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><div class="mp_gradient"></div><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageOneUrl}} title=${t=>t.data&&t.data.CaptionOne} alt="" /></a></div><div class="card-row"><a href="${t=>t.data&&t.data.CaptionTwoClickUrl}" target="_blank" data-t="${t=>t.contentDescTelemetryTag}"><span class="card-caption" title=${t=>t.data&&t.data.CaptionTwo}>${t=>t.data&&t.data.CaptionTwo}</span></a><a class="card-image-container" href="${t=>t.data&&t.data.ImageTwoClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><div class="mp_gradient"></div><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageTwoUrl}} title=${t=>t.data&&t.data.CaptionTwo} alt="" /></a></div><div class="card-row"><a href="${t=>t.data&&t.data.CaptionThreeClickUrl}" target="_blank" data-t="${t=>t.contentDescTelemetryTag}"><span class="card-caption" title=${t=>t.data&&t.data.CaptionThree}>${t=>t.data&&t.data.CaptionThree}</span></a><a class="card-image-container" href="${t=>t.data&&t.data.ImageThreeClickUrl}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><div class="mp_gradient"></div><img src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageThreeUrl}} title=${t=>t.data&&t.data.CaptionThree} alt="" /></a></div></div>`)}</div>`;let et=class extends G.L{};(0,r.Cg)([U.sH],et.prototype,"data",void 0),(0,r.Cg)([U.sH],et.prototype,"cardNumber",void 0),(0,r.Cg)([U.sH],et.prototype,"contentDescTelemetryTag",void 0),(0,r.Cg)([U.sH],et.prototype,"contentImageTelemetryTag",void 0),et=(0,r.Cg)([(0,G.E)({name:"content-bts-template-1u-card",template:tt,styles:Q})],et);const at="Segoe UI",it=Y.A`

.marketplace-content-05u a{
    text-decoration: none;
}

.marketplace-content-05u{
    position: relative;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
}

.marketplace-content-05u .mp_detailSection{
    display: flex;
    flex-direction: column;
}

.marketplace-content-05u .mp_title{
    width: 201px;
    height: 44px;
    padding-bottom: 4px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    text-overflow: ellipsis;
}

.marketplace-content-05u .mp_title .content-title{
    font-family: ${at};
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 22px;
    color: #1A1A1A;
}

.mp_classDetails{
    position: relative;
    display:flex;
    flex-direction: row;
    font-style: normal;
    font-family: ${at};
    align-items: center;
    width: 201px;
    height: 17px;
}

.mp_classDetails .text-container{
    display: flex;
    align-items: center;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    color: #1A1A1A;
}

.mp_classDetails .duration svg{
    padding-right: 6px;
}

.mp_classDetails .duration{
    padding-right: 20px;
}

.mp_classDetails .difficulty .mp_levelsLight svg{
    padding-right: 4px;
}

.mp_classDetails .difficulty .mp_levelsDark svg{
    padding-right: 4px;
    padding-top: 2px;
}

.marketplace-content-05u .content-image img{
    border-radius: 8px;
    object-fit: fill;
    width: 56px;
    height: 56px;
}

${X};

`.withBehaviors((0,K.G2)(Y.A`
        
        .marketplace-content-05u .mp_title .content-title{
            color: #FFFFFF;
        }
        .marketplace-content-05u .mp_classDetails .text-container{
            color: #FFFFFF;
        }
    `));var st=a(25109);const ot="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Difficulty1BarDark.svg",nt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Difficulty1BarLight.svg",rt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Difficulty2BarDark.svg",lt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Difficulty2BarLight.svg",ct="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Difficulty3BarDark.svg",dt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Difficulty3BarLight.svg",pt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/DifficultyNoFillDark.svg",mt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/DifficultyNoFillLight.svg",ht=Z.qy`<div class="content-section marketplace-content-05u column"><div class="mp_detailSection"><div class="mp_title"><a class= "text-container" href="${t=>t.data&&t.data.TaglineLink}" target="_blank" data-t="${t=>t.contentHeaderTelemetryTag}"><span class="content-title" title=${t=>t.data&&t.data.Tagline}>${t=>t.data&&t.data.Tagline}</span></a></div><div class="mp_classDetails">${(0,W.z)(t=>t.data&&t.data.Duration,Z.qy`<div class="duration"><a class= "text-container" href="${t=>t.data&&t.data.DurationLink}" target="_blank" data-t="${t=>t.classLengthTelemetryTag}">${(0,W.z)(t=>t.data&&(0,st.ud)(),Z.qy`<img src=${"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/ClockWhite.svg"} alt="ClockWhite" aria-hidden="true"/>`)} ${(0,W.z)(t=>t.data&&!(0,st.ud)(),Z.qy`<img src=${"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/ClockBlack.svg"} alt="ClockBlack" aria-hidden="true"/>`)}<span class="content-title" title=${t=>t.data&&t.data.Tagline}>${t=>t.data&&t.data.Duration}</span></a></div>`)} ${(0,W.z)(t=>t.data&&t.data.Level,Z.qy`<div class="difficulty"><a class= "text-container" href="${t=>t.data&&t.data.LevelLink}" target="_blank" data-t="${t=>t.classDifficultyTelemetryTag}">${t=>function(t,e){if(!e)return Z.qy``;const a=e.Level.trim().toLowerCase();if(t)switch(a){case"fundamental":case"elementary":case"all levels":return Z.qy`<div class="mp_levelsDark"> <img src=${mt} alt="DifficultyNoFillLight" aria-hidden="true"/> </div>`;case"beginner":case"middle school":return Z.qy`<div class="mp_levelsDark"> <img src=${nt} alt="Difficulty1BarLight" aria-hidden="true"/> </div>`;case"intermediate":case"high school":default:return Z.qy`<div class="mp_levelsDark"> <img src=${lt} alt="Difficulty2BarLight" aria-hidden="true"/> </div>`;case"advanced":case"college":return Z.qy`<div class="mp_levelsDark"> <img src=${dt} alt="Difficulty3BarLight" aria-hidden="true"/> </div>`}else switch(a){case"fundamental":case"elementary":case"all levels":return Z.qy`<div class="mp_levelsLight"> <img src=${pt} alt="DifficultyNoFillDark" aria-hidden="true"/> </div>`;case"beginner":case"middle school":return Z.qy`<div class="mp_levelsLight"> <img src=${ot} alt="Difficulty1BarDark" aria-hidden="true"/> </div>`;case"intermediate":case"high school":default:return Z.qy`<div class="mp_levelsLight"> <img src=${rt} alt="Difficulty2BarDark" aria-hidden="true"/> </div>`;case"advanced":case"college":return Z.qy`<div class="mp_levelsLight"> <img src=${ct} alt="Difficulty3BarDark" aria-hidden="true"/> </div>`}}((0,st.ud)(),t.data)}<span class="content-title" title=${t=>t.data&&t.data.Tagline}>${t=>t.data&&t.data.Level}</span></a></div>`)}</div></div>${(0,W.z)(t=>t.data&&t.data.ImageDataUrl,Z.qy`<a class="content-image" href="${t=>t.data&&t.data.ImageActionLink}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img class="center-image" src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageDataUrl}} title=${t=>t.data&&t.data.Tagline} alt="" /></a>`)}</div>`;let gt=class extends G.L{};(0,r.Cg)([U.sH],gt.prototype,"data",void 0),(0,r.Cg)([U.sH],gt.prototype,"contentHeaderTelemetryTag",void 0),(0,r.Cg)([U.sH],gt.prototype,"contentImageTelemetryTag",void 0),(0,r.Cg)([U.sH],gt.prototype,"classLengthTelemetryTag",void 0),(0,r.Cg)([U.sH],gt.prototype,"classDifficultyTelemetryTag",void 0),gt=(0,r.Cg)([(0,G.E)({name:"content-template-05u-card",template:ht,styles:it})],gt);const ut="Segoe UI",vt=Y.A`

.marketplace-content-1u a{
    text-decoration: none;
}

.marketplace-content-1u{
    position: relative;
    display: flex;
    flex-direction: column;
}

.marketplace-content-1u .content-image img{
    border-radius: 8px;
    object-fit: fill;
    width: 268px;
    height: 140px;
    -moz-transform: scale(1);
    -webkit-transform: scale(1);
    transform: scale(1);
    transition:0.7s ease all;
    -webkit-transition:0.7s ease all;
    -moz-transition:0.7s ease all;
}

.content-image img:hover{
    -moz-transform: scale(1.07);
    -webkit-transform: scale(1.07);
    transform: scale(1.07);
}

.marketplace-content-1u .mp_title{
    max-width: 268px;
    max-height: 22px;
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
    overflow: hidden;
    text-overflow: ellipsis;
}

.marketplace-content-1u .mp_title .content-title{
    font-family: ${ut};
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 22px;
    color: #1A1A1A;
}

.marketplace-content-1u .mp_subtitle{
    max-width: 268px;
    max-height: 42px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    text-overflow: ellipsis;
}

.marketplace-content-1u .mp_subtitle .content-title{
    font-family: ${ut};font-style:normal;font-weight:400;font-size:14px;line-height:20px;color:#1A1A1A}.mp_gradient{position:absolute;height:60px;width:268px;top:80px;background:linear-gradient(rgba(0,0,0,0) 0%,rgba(0,0,0,0) 33%,rgba(0,0,0,0.54) 67%);border-radius:0 0px 8px 8px}.mp_classDetails{position:absolute;display:flex;flex-direction:row;font-style:normal;font-family:${ut};
    align-items: center;
    top: 120px;
    left: 8px;
}

.mp_classDetails .text-container{
    display: flex;
    align-items: flex-end;
    font-weight: 400;
    font-size: 12px;
    line-height: 16px;
    color: #FFFFFF;
}

.mp_classDetails .duration svg{
    padding-right: 4px;
    padding-bottom: 0.5px;
}

.mp_classDetails .duration{
    padding-right: 12px;
}

.mp_classDetails .difficulty svg{
    padding-right: 4px;
}

${X};

`.withBehaviors((0,K.G2)(Y.A`
        
        .marketplace-content-1u .mp_title .content-title{
            color: #FFFFFF;
        }
        .marketplace-content-1u .mp_subtitle .content-title{
            color: #FFFFFF;
        }
    `)),kt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Chat.svg",ft="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/ClockWhite.svg",bt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Difficulty1BarLight.svg",xt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Difficulty2BarLight.svg",$t="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/Difficulty3BarLight.svg",Tt="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/DifficultyNoFillLight.svg",yt=Z.qy`<div class="content-section marketplace-content-1u column">${(0,W.z)(t=>t.data&&t.data.ImageDataUrl,Z.qy`<a class="content-image" href="${t=>t.data&&t.data.ImageActionLink}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img class="center-image" src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageDataUrl}} title=${t=>t.data&&t.data.Tagline} alt="" /><div class="mp_gradient"></div></a>`)}<div class="mp_classDetails">${t=>function(t){if(t&&t.Duration&&"free chat"===t.Duration.trim().toLowerCase())return Z.qy`<div class="duration"><a class= "text-container" href="${t=>t.data&&t.data.DurationLink}" target="_blank" data-t="${t=>t.classLengthTelemetryTag}"><img src=${kt} alt="Chat" aria-hidden="true"/><span class="content-title" title=${t=>t.data&&t.data.Tagline}>${t=>t.data&&t.data.Duration}</span></a></div>`;if(t&&t.Duration)return Z.qy`<div class="duration"><a class= "text-container" href="${t=>t.data&&t.data.DurationLink}" target="_blank" data-t="${t=>t.classLengthTelemetryTag}"><img src=${ft} alt="ClockWhite" aria-hidden="true"/><span class="content-title" title=${t=>t.data&&t.data.Tagline}>${t=>t.data&&t.data.Duration}</span></a></div>`}(t.data)} ${(0,W.z)(t=>t.data&&t.data.Level,Z.qy`<div class="difficulty"><a class= "text-container" href="${t=>t.data&&t.data.LevelLink}" target="_blank" data-t="${t=>t.classDifficultyTelemetryTag}">${t=>function(t){if(!t)return Z.qy``;switch(t.Level.trim().toLowerCase()){case"fundamental":case"elementary":case"all levels":return Z.qy`<img src=${Tt} alt="DifficultyNoFillLight" aria-hidden="true"/>`;case"beginner":case"middle school":return Z.qy`<img src=${bt} alt="Difficulty1BarLight" aria-hidden="true"/>`;case"intermediate":case"high school":default:return Z.qy`<img src=${xt} alt="Difficulty2BarLight" aria-hidden="true"/>`;case"advanced":case"college":return Z.qy`<img src=${$t} alt="Difficulty3BarLight" aria-hidden="true"/>`}}(t.data)}<span class="content-title" title=${t=>t.data&&t.data.Tagline}>${t=>t.data&&t.data.Level}</span></a></div>`)}</div><div class="mp_title"><a class= "text-container" href="${t=>t.data&&t.data.TaglineLink}" target="_blank" data-t="${t=>t.contentHeaderTelemetryTag}"><span class="content-title" title=${t=>t.data&&t.data.Tagline}>${t=>t.data&&t.data.Tagline}</span></a></div>${(0,W.z)(t=>t.data&&t.data.Description,Z.qy`<div class="mp_subtitle"><a class= "text-container" href="${t=>t.data&&t.data.DescriptionLink}" target="_blank" data-t="${t=>t.contentDescTelemetryTag}"><span class="content-title" title=${t=>t.data&&t.data.Description}>${t=>t.data&&t.data.Description}</span></a></div>`)}</div>`;let wt=class extends G.L{};(0,r.Cg)([U.sH],wt.prototype,"data",void 0),(0,r.Cg)([U.sH],wt.prototype,"contentHeaderTelemetryTag",void 0),(0,r.Cg)([U.sH],wt.prototype,"contentDescTelemetryTag",void 0),(0,r.Cg)([U.sH],wt.prototype,"contentImageTelemetryTag",void 0),(0,r.Cg)([U.sH],wt.prototype,"classLengthTelemetryTag",void 0),(0,r.Cg)([U.sH],wt.prototype,"classDifficultyTelemetryTag",void 0),wt=(0,r.Cg)([(0,G.E)({name:"content-template-1u-card",template:yt,styles:vt})],wt);const _t=Y.A` .multi-subject-card{width:100%;height:100%;position:relative}.mini-card-grid{display:grid;grid-column-gap:8px;grid-row-gap:8px;grid-template-columns:84px 84px 84px;grid-template-rows:84px 84px;margin:6px auto 0}.mini-card{position:relative;width:100%;height:100%;border-radius:6px;background-size:100% 100%}.mini-card p{position:absolute;margin:0;bottom:8px;left:6px;color:white;font-size:12px;line-height:14px}.description{margin:12px 0 0 0;font-size:12px;line-height:16px;color:#2B2B2B}.callToActionButton{display:flex;justify-content:center;align-items:center;background:#FFFFFF;color:#1A1A1A;border:1px solid #D6D6D6;box-sizing:border-box;border-radius:20px;width:137px;height:24px;margin-left:55px;text-decoration:none;font-size:12px;line-height:16px}.bottom-controls .arrow-button{color:rgba(0,0,0,1)}.slideCounter{color:rgba(0,0,0,0.83)}${X}
`.withBehaviors((0,K.G2)(Y.A` .description{margin:12px 0 0 0;font-size:12px;line-height:16px;color:white}.callToActionButton{display:flex;justify-content:center;align-items:center;background:rgba(255,255,255,0.09);color:#FFFFFF;border:none;border-radius:20px;width:137px;height:24px;margin-left:55px;text-decoration:none;font-size:12px;line-height:16px}`)),Ct="https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/ArrowLeft.svg",At=Z.qy`<div class="multi-subject-card"><div class="heading-spacing"></div><div class="container"><p class="description">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.Description}}</p><div class="mini-card-grid"><img src=${Ct} alt="ArrowLeft" aria-hidden="true"/></div></div><span class="bottom-controls"><button data-t="${t=>t.navigationArrowBackTelemetryTag}" @click="${t=>t.$emit("previous")}" class="pointer arrow-button">${Z.qy.partial(Ct)}</button><p class="slideCounter">${t=>t.cardNumber+1} / 8</p><button data-t="${t=>t.navigationArrowForwardTelemetryTag}" @click="${t=>t.$emit("next")}" class="pointer arrow-button">${Z.qy.partial("https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/ArrowRight.svg")}</button><a href=${t=>t.data.CallToActionLink} target="_blank" class="pointer callToActionButton" data-t="${t=>t.callToActionTelemetryTag}">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.CallToAction}}</a></span></div>`;let Dt=class extends G.L{constructor(){super(...arguments),this.data={Description:"",CallToAction:"",CallToActionLink:"",SubjectCards:[],LogoLink:""},this.cardNumber=1,this.strings={takelessonsActionButton:"",takelessonsCardCallToActionText:"",takelessonsCardDescription:"",takelessonsCardHeading:"",takelessonsHideCard:"",takelessonsMoreSettings:"",takelessonsMultipleTutorsHeading:"",takelessonsMultipleTutorsButtonText:"",takelessonsName:""}}};(0,r.Cg)([U.sH],Dt.prototype,"data",void 0),(0,r.Cg)([U.sH],Dt.prototype,"cardNumber",void 0),(0,r.Cg)([U.sH],Dt.prototype,"strings",void 0),(0,r.Cg)([U.sH],Dt.prototype,"callToActionTelemetryTag",void 0),(0,r.Cg)([U.sH],Dt.prototype,"logoHeaderTelemetryTag",void 0),(0,r.Cg)([U.sH],Dt.prototype,"miniCardTelemetryTag",void 0),(0,r.Cg)([U.sH],Dt.prototype,"navigationArrowBackTelemetryTag",void 0),(0,r.Cg)([U.sH],Dt.prototype,"navigationArrowForwardTelemetryTag",void 0),Dt=(0,r.Cg)([(0,G.E)({name:"multi-subject-card",template:At,styles:_t})],Dt);const Lt=Y.A` .single-subject-card{height:100%;width:100%;position:relative;border-radius:6px}.single-subject-card:hover h5{text-decoration:underline}.single-subject-card:hover{opacity:0.8}.take-lessons-single-card-logo{display:flex;justify-content:left;align-items:end;color:inherit;text-decoration:inherit;font-size:12px;font-weight:bold}.take-lessons-single-card-logo h5{margin:4px 0 0 0}.take-lessons-single-card-logo svg{margin-top:3px;fill:#3d88c9}.bottom-section{position:absolute;padding:16px;bottom:0px}.top-section{padding:11px 15px;display:flex}h5{font-size:24px;font-weight:600;margin:4px auto}p{font-size:20px;margin:4px auto 8px auto;font-weight:600}.small-tagline{font-size:16px}.small-headline{font-size:28px}.call-to-action-container{margin:auto;text-align:center}.call-to-action{background:#FFFFFF;color:black;border:1px solid #D6D6D6;box-sizing:border-box;min-height:24px;border-radius:20px;text-decoration:none;font-size:12px;line-height:16px;padding:4px 20px;text-align:center}.split-button-layout{display:flex;align-items:end}.split-button-layout p,a{flex:50%}.full-card-link{width:100%;height:100%;position:absolute;top:0;zIndex:0}${X}
`.withBehaviors((0,K.G2)(Y.A` .bottom-section{color:black}.take-lessons-single-card-logo{color:black}`)),Ft=Z.qy`<div class="single-subject-card" style=${t=>{var e;return`background: url(${null===(e=t.data)||void 0===e?void 0:e.ImageUrl})`}}><a class="full-card-link" href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ClickthroughUrl}} title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}} target="_blank" data-t="${t=>t.imageTelemetryTag}"></a><div class="top-section"><a class="take-lessons-single-card-logo" href="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.LogoLink}}" target="_blank" data-t="${t=>t.logoHeaderTelemetryTag}"><img src=${"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/TakelessonsLogo.svg"} alt="TakelessonsLogo" aria-hidden="true"/><span class="linkText">TAKELESSONS</span></a><slot name="action-button"></slot></div><div class="bottom-section">${(0,W.z)(t=>t.hasHeadline(),Z.qy`<a href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.HeadlineLink}}  class="inherit" title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}} target="_blank" data-t="${t=>t.headlineTelemetryTag}"><h5 class="${t=>t.hasTagline()?" small-headline":""}">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.Headline}}</h5></a>`)}<div class="${t=>t.hasHeadline()&&t.hasTagline()?" split-button-layout":"call-to-action-container"}">${(0,W.z)(t=>t.hasTagline(),Z.qy`<a href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.TaglineLink}}  target="_blank" title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}} class="inherit" data-t="${t=>t.taglineTelemetryTag}"><p class="${t=>t.hasHeadline()?" small-tagline":""}">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.Tagline}}</p></a>`)}<a href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.CallToActionLink}} title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}}  target="_blank" data-t="${t=>t.callToActionTelemetryTag}" class="pointer call-to-action">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.CallToAction}}</a></div></div></div>`;let St=class extends G.L{hasHeadline(){return null!=this.data&&""!=this.data.Headline}hasTagline(){return null!=this.data&&""!=this.data.Tagline}};(0,r.Cg)([U.sH],St.prototype,"data",void 0),(0,r.Cg)([U.sH],St.prototype,"callToActionTelemetryTag",void 0),(0,r.Cg)([U.sH],St.prototype,"headlineTelemetryTag",void 0),(0,r.Cg)([U.sH],St.prototype,"taglineTelemetryTag",void 0),(0,r.Cg)([U.sH],St.prototype,"logoHeaderTelemetryTag",void 0),(0,r.Cg)([U.sH],St.prototype,"imageTelemetryTag",void 0),St=(0,r.Cg)([(0,G.E)({name:"single-headline-card",template:Ft,styles:Lt})],St);const zt=Y.A` .full-card-link{width:100%;height:100%;top:0;zIndex:0}.single-image-card{border-radius:6px;display:flex;flex-direction:column}.top-section{margin-left:16px;margin-right:12px;margin-top:16px;display:flex;flex-direction:row}.logo-text-tl{margin-left:4px;font-size:12px;display:flex;margin-top:2px}.setting-action{margin-left:auto}.take-lessons-single-card-logo{flex:1;color:#717171;text-decoration:#717171;font-size:12px;font-weight:bold;display:flex}.take-lessons-single-card-logo svg{fill:#0078D4}.setting-action-button{display:flex;justify-content:right;align-items:end}.center-image-container{margin-top:8px;align-items:center;display:flex;justify-content:center}.center-image{border-radius:4px;width:268px;height:156px;object-fit:cover}.card-text{margin-top:8px;font-size:16px;line-height:22px;width:auto;padding:0px 20px 0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;font-weight:600;font-family:'Segoe UI';color:#1A1A1A}.card-sub-text{font-size:14px;line-height:20px;display:-webkit-box;-webkit-line-clamp:1;padding:5px 20px 0;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;font-weight:400;color:#1A1A1A;font-family:'Segoe UI'}.call-to-action{margin-top:8px;background:rgba(255,255,255,0.7);color:rgba(0,0,0,0.83);border:1px solid #D6D6D6;box-sizing:border-box;min-height:24px;border-radius:20px;text-decoration:none;font-size:12px;line-height:16px;padding:4px 20px;text-align:center;font-family:'Segoe UI'}.call-to-action-container{margin-top:4px;text-align:center}.call-to-action:hover{background:rgba(255,255,255,0.6)}.single-image-card:hover .center-image-container{opacity:0.7}.single-image-card:hover .top-section{opacity:0.7}.single-image-card:hover .card-text{text-decoration:underline}${X}
`,It=Z.qy`<div class="single-image-card"><a class="full-card-link" href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ClickthroughUrl}} title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}} target="_blank" data-t="${t=>t.imageTelemetryTag}"></a><div class="top-section"><a class="take-lessons-single-card-logo" href="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.LogoLink}}" target="_blank" data-t="${t=>t.logoHeaderTelemetryTag}"><img src=${"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/TakelessonsLogo.svg"} alt="TakelessonsLogo" aria-hidden="true"/><span class="logo-text-tl">${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Logo)??""}}</span></a><slot class="setting-action" name="action-button"></slot></div><div class="center-image-container" title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}}><a href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ClickthroughUrl}} target="_blank" data-t="${t=>t.imageTelemetryTag}"><img class="center-image" src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.ImageUrl}} alt="" /></a></div><div class="card-text" title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}}><a href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.HeadlineLink}} class="inherit" title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}} target="_blank" data-t="${t=>t.headlineTelemetryTag}">${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}}</a></div><div class="card-sub-text" title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}}><a href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.TaglineLink}} target="_blank" title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}} class="inherit" data-t="${t=>t.taglineTelemetryTag}">${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Tagline)??""}}</a></div><div class="call-to-action-container"><a href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.CallToActionLink}} title=${t=>{var e;return(null===(e=t.data)||void 0===e?void 0:e.Headline)??""}} target="_blank" data-t="${t=>t.callToActionTelemetryTag}" class="pointer call-to-action">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.CallToAction}}</a></div></div>`;let Ut=class extends G.L{};(0,r.Cg)([U.sH],Ut.prototype,"data",void 0),(0,r.Cg)([U.sH],Ut.prototype,"callToActionTelemetryTag",void 0),(0,r.Cg)([U.sH],Ut.prototype,"headlineTelemetryTag",void 0),(0,r.Cg)([U.sH],Ut.prototype,"taglineTelemetryTag",void 0),(0,r.Cg)([U.sH],Ut.prototype,"logoHeaderTelemetryTag",void 0),(0,r.Cg)([U.sH],Ut.prototype,"imageTelemetryTag",void 0),Ut=(0,r.Cg)([(0,G.E)({name:"single-small-image-card",template:It,styles:zt})],Ut);const Bt=Y.A` .single-subject-card{height:100%;width:100%;color:white;position:relative;border-radius:6px}.bottom-section{position:absolute;padding:0px 16px;bottom:45px}.bottom-section h5,p{margin:0 auto}.bottom-section h5{font-size:16px;line-height:22px}.bottom-section p{font-size:14px;line-height:20px}.bottom-controls .call-to-action{display:flex;justify-content:center;align-items:center;background:rgba(255,255,255,0.40);color:#FFFFFF;border:none;box-sizing:border-box;width:137px;height:24px;border-radius:20px;margin-left:55px;text-decoration:none;font-size:12px;line-height:16px}.bottom-controls .arrow-button{color:white}.slideCounter{color:rgba(255,255,255,0.83)}.full-card-link{width:100%;height:100%;position:absolute;top:0;zIndex:0}${X}
`,Mt=Z.qy`<div class="single-subject-card" style=${t=>{var e;return`background: linear-gradient(0deg, rgba(0, 0, 0, 0.74) 40%, rgba(0, 0, 0, 0) 60%, rgba(0,0,0,0) 85%, rgba(0,0,0,0.74) 100%), url(${null===(e=t.data)||void 0===e?void 0:e.ImageURL})`}}><div class="heading-spacing"></div><a class="full-card-link" href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.SecondaryClickthroughUrl}} target="_blank" data-t="${t=>t.headlineTelemetryTag}"></a><div class="bottom-section"><a class="inherit" href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.SecondaryClickthroughUrl}} target="_blank" data-t="${t=>t.headlineTelemetryTag}"><h5>${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.Title}}</h5><p>${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.Description}}</p></a></div><div class="bottom-controls"><button data-t="${t=>t.navigationArrowBackTelemetryTag}" class="pointer arrow-button" @click="${t=>t.$emit("previous")}"><img src=${"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/ArrowLeft.svg"} alt="ArrowLeft" aria-hidden="true"/></button><p class="slideCounter">${t=>t.cardNumber+1} / 8</p><button class="pointer arrow-button" data-t="${t=>t.navigationArrowForwardTelemetryTag}" @click="${t=>t.$emit("next")}">${Z.qy.partial("https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/marketplace-takelessons/ArrowRight.svg")}</button><a href=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.CallToActionLink}} target="_blank" class="pointer call-to-action" data-t="${t=>t.callToActionTelemetryTag}">${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.CallToAction}}</a></div></div>`;let Pt=class extends G.L{constructor(){super(...arguments),this.strings={takelessonsActionButton:"",takelessonsCardCallToActionText:"",takelessonsCardDescription:"",takelessonsCardHeading:"",takelessonsHideCard:"",takelessonsMoreSettings:"",takelessonsMultipleTutorsHeading:"",takelessonsMultipleTutorsButtonText:"",takelessonsName:""}}};var jt;(0,r.Cg)([U.sH],Pt.prototype,"data",void 0),(0,r.Cg)([U.sH],Pt.prototype,"cardNumber",void 0),(0,r.Cg)([U.sH],Pt.prototype,"strings",void 0),(0,r.Cg)([U.sH],Pt.prototype,"callToActionTelemetryTag",void 0),(0,r.Cg)([U.sH],Pt.prototype,"headlineTelemetryTag",void 0),(0,r.Cg)([U.sH],Pt.prototype,"logoHeaderTelemetryTag",void 0),(0,r.Cg)([U.sH],Pt.prototype,"navigationArrowBackTelemetryTag",void 0),(0,r.Cg)([U.sH],Pt.prototype,"navigationArrowForwardTelemetryTag",void 0),Pt=(0,r.Cg)([(0,G.E)({name:"single-subject-card",template:Mt,styles:Bt})],Pt);const Ht=`${null===(jt=(0,a(58792).rA)())||void 0===jt?void 0:jt.StaticsUrl}latest/icons-wc/icons/marketplace-takelessons/TakelessonsLogo.svg`;J.MsnActionsMenu;const Rt=Z.qy` ${t=>{var e,a;return(0,V.m)(null===(e=t.superSDSetting)||void 0===e?void 0:e.actionsMenuButtonElement,null===(a=t.superSDSetting)||void 0===a?void 0:a.menuItems)}}
`,Et=Z.qy` ${(t,e)=>(0,V.V)(()=>{var a;return null===(a=t.superSDSetting)||void 0===a?void 0:a.toggleActionMenu(!t.superSDSetting.isActionMenuOpen,e.event)},t.customizeTelemetryTag??"",t.strings.takelessonsActionButton,"toggle-button")}
`,Nt=Z.qy`<multi-subject-card :data=${t=>t.marketplaceData} :cardNumber=${t=>0} :callToActionTelemetryTag=${t=>t.callToActionTelemetryTag} :logoHeaderTelemetryTag=${t=>t.logoHeaderTelemetryTag} :miniCardTelemetryTag=${t=>t.miniCardTelemetryTag} :navigationArrowBackTelemetryTag=${t=>t.navigationArrowBackTelemetryTag} :navigationArrowForwardTelemetryTag=${t=>t.navigationArrowForwardTelemetryTag} :strings=${t=>t.strings} @next=${t=>t.nextCard()} @previous=${t=>t.previousCard()}></multi-subject-card>`,Ot=Z.qy`<fluent-card class="_1x_2y marketplace_card_container"><single-headline-card :data=${t=>t.marketplaceData} :callToActionTelemetryTag=${t=>t.callToActionTelemetryTag} :headlineTelemetryTag=${t=>t.headlineTelemetryTag} :taglineTelemetryTag=${t=>t.taglineTelemtryTag} :logoHeaderTelemetryTag=${t=>t.logoHeaderTelemetryTag} :imageTelemetryTag=${t=>t.imageTelemetryTag}><span class="more-actions" slot="action-button">${Et}</span></single-headline-card>${(0,W.z)(t=>{var e;return null===(e=t.superSDSetting)||void 0===e?void 0:e.isActionMenuOpen},Rt)}</fluent-card>`,Jt=Z.qy`<fluent-card class="_1x_2y marketplace_card_container"><div class="heading-wrapper ${t=>0!=t.cardNumber?" light":""}"><span><a class="take-lessons-logo" href=${t=>0!=t.cardNumber?t.logoLink[t.cardNumber-1]:t.mainCardLogoLink} target="_blank" data-t="${t=>t.logoHeaderTelemetryTag}"><img src=${Ht} alt="TakelessonsLogo" aria-hidden="true"/><span class="linkText">${t=>t.strings.takelessonsName}</span></a></span><span class="more-actions">${Et}</span></div>${(0,W.z)(t=>0==t.cardNumber,Nt)} ${(0,W.z)(t=>0!=t.cardNumber,t=>{return e=t.cardNumber,Z.qy`<single-subject-card :data=${t=>{var a;return null===(a=t.marketplaceData)||void 0===a?void 0:a.SubjectCards[e-1]}} :cardNumber=${t=>e} :callToActionTelemetryTag=${t=>t.callToActionTelemetryTag} :headlineTelemetryTag=${t=>t.headlineTelemetryTag} :logoHeaderTelemetryTag=${t=>t.logoHeaderTelemetryTag} :navigationArrowBackTelemetryTag=${t=>t.navigationArrowBackTelemetryTag} :navigationArrowForwardTelemetryTag=${t=>t.navigationArrowForwardTelemetryTag} :imageTelemetryTag=${t=>t.imageTelemetryTag} :strings=${t=>t.strings} @next=${t=>t.nextCard()} @previous=${t=>t.previousCard()}></single-subject-card>`;var e})} ${(0,W.z)(t=>{var e;return null===(e=t.superSDSetting)||void 0===e?void 0:e.isActionMenuOpen},Rt)}</fluent-card>`,Vt=Z.qy`<fluent-card class="_1x_2y marketplace_card_container_light"><single-small-image-card :data=${t=>t.marketplaceData} :callToActionTelemetryTag=${t=>t.callToActionTelemetryTag} :headlineTelemetryTag=${t=>t.headlineTelemetryTag} :taglineTelemetryTag=${t=>t.taglineTelemtryTag} :logoHeaderTelemetryTag=${t=>t.logoHeaderTelemetryTag} :imageTelemetryTag=${t=>t.imageTelemetryTag}><span class="more-actions" slot="action-button">${Et}</span></single-small-image-card>${(0,W.z)(t=>{var e;return null===(e=t.superSDSetting)||void 0===e?void 0:e.isActionMenuOpen},Rt)}</fluent-card>`,Zt=Z.qy`<div class="super-card-body" @load=${t=>t.callTtvr()}><content-bts-template-1u-card :data=${t=>t.btsCardData} :cardNumber=${t=>t.superSDCardNumber} :contentImageTelemetryTag=${t=>t.contentImageTelemetryTag} :contentDescTelemetryTag=${t=>t.contentDescTelemetryTag}></content-bts-template-1u-card"></div>`,Wt=Z.qy`<div class="super-card-body" @load=${t=>t.callTtvr()}><content-template-1u-card :data=${t=>t.cardData} :contentImageTelemetryTag=${t=>t.contentImageTelemetryTag} :contentHeaderTelemetryTag=${t=>t.contentHeaderTelemetryTag} :contentDescTelemetryTag=${t=>t.contentDescTelemetryTag} :classLengthTelemetryTag=${t=>t.classLengthTelemetryTag} :classDifficultyTelemetryTag=${t=>t.classDifficultyTelemetryTag}></content-template-1u-card"></div>`,Gt=(Z.qy`<div class="super-card-body" @load=${t=>t.callTtvr()}><content-template-05u-card :data=${t=>t.cardData} :contentImageTelemetryTag=${t=>t.contentImageTelemetryTag} :contentHeaderTelemetryTag=${t=>t.contentHeaderTelemetryTag} :classLengthTelemetryTag=${t=>t.classLengthTelemetryTag} :classDifficultyTelemetryTag=${t=>t.classDifficultyTelemetryTag}></content-template-05u-card"></div>`,Z.qy`<responsive-sd-card :data="${t=>t.data}">${(0,W.z)(t=>t.btsCardData,Z.qy`<div slot="card-content">${Zt}</div>`)}</responsive-sd-card>`),qt=Z.qy`<responsive-sd-card :data="${t=>t.data}">${(0,W.z)(t=>t.cardData,Z.qy`<div slot="card-content">${Wt}</div>`)}</responsive-sd-card>`,Yt=Z.qy`<div>${(0,W.z)(t=>!0,t=>function(t){if(!t)return Z.qy`<div></div>`;const e=t.CardType;return"SINGLE_HEADLINE_CARD"==e?Ot:"BTS_MULTI_SD_CARD"==e?Gt:"SINGLE_SMALL_IMAGE_CARD"==e?Vt:"MULTIPLE_SD_CARD"==e?qt:Jt}(t.marketplaceData))}</div>`;i.p,s.m.define(o.c.registry),(0,n.o)();const Kt={experienceConfigSchema:undefined}},80541(t,e){e.A='<svg width="17" height="17" viewBox="0 0 17 17"><path d="M.02 5.88A8.5 8.5 0 0 1 1.8 2.8a.5.5 0 0 1 .54-.13l1.92.68a1 1 0 0 0 1.32-.76l.37-2a.5.5 0 0 1 .39-.4 8.53 8.53 0 0 1 3.55 0 .5.5 0 0 1 .39.4l.37 2a1 1 0 0 0 1.32.76l1.91-.68a.5.5 0 0 1 .54.13 8.5 8.5 0 0 1 1.78 3.08.5.5 0 0 1-.15.54L14.5 7.74a1 1 0 0 0 0 1.52l1.55 1.32a.5.5 0 0 1 .15.54 8.5 8.5 0 0 1-1.78 3.08.5.5 0 0 1-.54.13l-1.91-.68a1 1 0 0 0-1.32.76l-.37 2a.5.5 0 0 1-.39.4 8.53 8.53 0 0 1-3.55 0 .5.5 0 0 1-.4-.4l-.36-2a1 1 0 0 0-1.32-.76l-1.92.68a.5.5 0 0 1-.54-.13 8.49 8.49 0 0 1-1.78-3.08.5.5 0 0 1 .16-.54l1.55-1.32a1 1 0 0 0 0-1.52L.18 6.42a.5.5 0 0 1-.16-.54Zm1.06 0 1.3 1.1a2 2 0 0 1 0 3.04l-1.3 1.1c.3.79.72 1.51 1.25 2.16l1.6-.58a2 2 0 0 1 2.64 1.53l.3 1.67a7.56 7.56 0 0 0 2.49 0l.3-1.67a2 2 0 0 1 2.64-1.53l1.6.57a7.5 7.5 0 0 0 1.24-2.15l-1.29-1.1a2 2 0 0 1 0-3.05l1.3-1.1a7.5 7.5 0 0 0-1.25-2.15l-1.6.57a2 2 0 0 1-2.64-1.52l-.3-1.67a7.55 7.55 0 0 0-2.49 0l-.3 1.67A2 2 0 0 1 3.93 4.3l-1.6-.57a7.5 7.5 0 0 0-1.25 2.15ZM5.62 8.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0Zm1 0a1.5 1.5 0 1 0 3 0 1.5 1.5 0 0 0-3 0Z" fill-opacity=".83"/></svg>'},91956(t,e,a){a.d(e,{p(){return u}});var i=a(56911),s=a(92011),o=a(38493);const n=a(74849).A` .controls{direction:ltr;display:grid;grid-auto-flow:column;grid-template-columns:min-content;grid-gap:12px}.container{padding:0 12px 12px 12px}.dark-theme-instructions{display:flex;flex-direction:column;padding:0 12px;height:100%}.dark-theme-instructions-filler{flex:1}.close-dark-theme-instructions-button{margin-bottom:12px}`;var r=a(96950),l=a(97004);const c=r.qy`<fluent-design-system-provider use-defaults fill-color=${t=>t.isDarkTheme?"#333333":"#F7F7F7"} base-layer-luminance=${t=>t.isDarkTheme?l.y.DarkMode:l.y.LightMode} direction=${t=>t.contentDirection}><div class="controls"><fluent-switch checked=${t=>"rtl"===t.contentDirection} @change=${t=>t.toggleDirection()}><span style="padding-inline-end: 8px;">Direction</span><span slot="unchecked-message">ltr</span><span slot="checked-message">rtl</span></fluent-switch><fluent-switch readonly checked=${t=>t.isDarkTheme} @click=${t=>t.showDarkThemeInstructions()}><span style="padding-inline-end: 8px;">Theme</span><span slot="checked-message">Dark</span><span slot="unchecked-message">Light</span></fluent-switch></div><div class="container" dir=${t=>t.contentDirection}><slot></slot></div><fluent-dialog hidden=${t=>!t.isDarkThemeInstructionsVisible||void 0} modal><div class="dark-theme-instructions"><div><h3>Testing dark theme</h3><p>Currently, testing dark theme requires the manual steps listed below.</p><h4>Step 1</h4><p>Open browser developer tools (CTRL+SHIFT+I).</p><h4>Step 2</h4><p>Open the command prompt (CTRL+SHIFT+P).</p><h4>Step 3</h4><p>Choose "Emulate CSS prefers-color-schema: dark" (or light).</p></div><div class="dark-theme-instructions-filler"></div><fluent-button class="close-dark-theme-instructions-button" @click=${t=>t.closeDarkThemeInstructions()}>Got it</fluent-button></div></fluent-dialog></fluent-design-system-provider>`;var d=a(2958),p=a(37180),m=a(4731),h=a(69400),g=a(7014);a(45755).G.registerDefaultStyleTarget(),d.m.define(p.c.registry),m.m.define(p.c.registry),h.m.define(p.c.registry),g.m.define(p.c.registry);let u=class extends s.L{constructor(){super(...arguments),this.isDarkTheme=!1,this.isDarkThemeInstructionsVisible=!1,this.contentDirection="ltr"}connectedCallback(){super.connectedCallback();const t=t=>{this.isDarkTheme=t};t(window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches),window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",function(e){t(e.matches)})}toggleDirection(){this.contentDirection="ltr"===this.contentDirection?"rtl":"ltr"}showDarkThemeInstructions(){this.isDarkThemeInstructionsVisible=!0}closeDarkThemeInstructions(){this.isDarkThemeInstructionsVisible=!1}};(0,i.Cg)([(0,o.CF)({mode:"boolean"})],u.prototype,"isDarkTheme",void 0),(0,i.Cg)([(0,o.CF)({mode:"boolean"})],u.prototype,"isDarkThemeInstructionsVisible",void 0),(0,i.Cg)([o.CF],u.prototype,"contentDirection",void 0),u=(0,i.Cg)([(0,s.E)({name:"experience-local-tester",template:c,styles:n})],u)}}]);