"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-earnings-quote-list"],{4968(e,t,r){r.d(t,{f(){return l}});var i=r(64187),a=r(74849),o=r(42792),s=r(99657),n=r(36452);const l=a.A.partial`position: relative; z-index: ${s.D};`;a.A`
    ${o.e}
    ${o.nH}

    ${(0,i.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${n.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${n.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${n.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},34648(e,t,r){r.r(t),r.d(t,{EarningsQuoteItem(){return M}});var i=r(56911),a=r(92707);class o extends a.z{contentTemplate(e,t,r){return this.isSeeMore?e:"_1x_1y"===this.viewModel.cardSize?t:r}stockNames(e){const{quote:{ShortName:t,DisplayName:r,Symbol:i}}=this.viewModel;return[t||r||"",i][e]}}var s=r(92011),n=r(48751),l=r(64003),d=r(4283),c=r(12640),g=r(74849),h=r(4968);const u=g.A` .see-more-text{color:#5FAFFF}`,p=g.A` .quote{position:relative;background:var(--quote-background);border-radius:8px;box-sizing:border-box;display:block;text-decoration:none;${h.f}}.quote:hover{background:var(--quote-hover-background)}.quote:active{background:var(--quote-active-background)}.quote.large{height:50px;width:268px;display:grid;grid-template-columns:24px 82px 64px 54px;gap:8px;align-items:center;padding:8px 10px}.logo{width:24px;height:24px;object-fit:contain;border:1px solid rgba(0,0,0,0.1622);border-radius:80px}.quote.small{height:66px;width:116px;padding:6px}.bold{font-weight:600}.large .symb,.large .est-date,.large .change{margin-bottom:2px;color:${n.l}}.est-date{color:${n.l}}.large .name,.large .mark-status,.est-text{color:${l.c}}.large .change,.large .est-text{text-align:end}.symb,.name,.est-date,.mark-status,.change,.est-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.row-2{display:flex;align-items:baseline;margin-bottom:4px}.row-3{display:flex;align-items:center}.small .name,.small .est-text{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px)}.small .name{color:${n.l};margin-bottom:2px}.small .est-text,.status-icon{margin:0px 4px}.small .change{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.vertical-quote-list.small{display:flex;flex-direction:row;flex-wrap:nowrap;gap:8px}.see-more-container{height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center}.see-more-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:${d.OS};
    }
`.withBehaviors(new c.N(null,u));var x=r(96950),f=r(69259),m=r(58792);const v=`${(0,m.rA)().StaticsUrl}latest/money/icons/StockEmptyStateCircle.svg`,b=`${(0,m.rA)().StaticsUrl}latest/money/icons/SeeMoreArrow.svg`,$=x.qy`<a class="quote small see-more" href="${e=>e.viewModel.seeMoreLink}" title="${e=>e.viewModel.seeMoreText}" target="_blank" data-t="${e=>e.viewModel.telemetryTag}"><div class="see-more-container"><div aria-hidden="true" role="presentation"><img src=${b} alt=${e=>e.viewModel.seeMoreText}></div><div class="see-more-text">${e=>e.viewModel.seeMoreText}</div></div></a>`,y=x.qy`<a class="quote small" href="${e=>e.viewModel.quoteUrl}" title="${e=>e.viewModel.tooltipText}" target="_blank" data-t="${e=>e.viewModel.telemetryTag}"><div><div class="name bold">${e=>e.viewModel.quote.DisplayName}</div></div><div class="row-2"><div class="change bold" style="color: ${e=>e.viewModel.changeColor}">${e=>e.viewModel.quote.EpsForecast.toFixed(2)}</div><div class="est-text">${e=>e.viewModel.epsEstText}</div></div><div class="row-3"><div class="est-date bold">${e=>e.viewModel.reportDate}</div><img class="status-icon" src=${e=>e.viewModel.marketStatusIcon} alt=${e=>e.viewModel.marketStatus}></div></a>`,k=x.qy` ${(0,f.z)(e=>e.viewModel.quote.IconUrl,x.qy`<img class="logo" src=${e=>e.viewModel.quote.IconUrl} alt=${e=>e.viewModel.quote.Symbol}>`)} ${(0,f.z)(e=>!e.viewModel.quote.IconUrl,x.qy`<img class="logo" src=${v} alt=${e=>e.viewModel.quote.Symbol}>`)}
`,w=x.qy`<a class="quote large" href="${e=>e.viewModel.quoteUrl}" title="${e=>e.viewModel.tooltipText}" target="_blank" data-t="${e=>e.viewModel.telemetryTag}">${k}<div><div class="symb bold">${e=>e.stockNames(0)}</div><div class="name">${e=>e.stockNames(1)}</div></div><div><div class="est-date bold">${e=>e.viewModel.reportDate}</div><div class="mark-status">${e=>e.viewModel.marketStatus}</div></div><div><div class="change bold" style="color: ${e=>e.viewModel.changeColor}">${e=>e.viewModel.quote.EpsForecast.toFixed(2)}</div><div class="est-text">${e=>e.viewModel.epsEstText}</div></div></a>`,z=x.qy` ${e=>e.contentTemplate($,y,w)}
`,q=x.qy` ${(0,f.z)(e=>e&&void 0!==e.viewModel,z)}
`;let M=class extends o{};M=(0,i.Cg)([(0,s.E)({name:"earnings-quote-item",template:q,styles:p,shadowOptions:{delegatesFocus:!0}})],M)},39609(e,t,r){r.r(t),r.d(t,{EarningsQuoteList(){return m}});var i=r(56911),a=r(27208),o=r(60815),s=r(92707),n=r(94043);class l extends s.z{constructor(){super(...arguments),this.currentMargin=0,this.onFocusIn=e=>{var t;const r=Array.from(this.earningsQuoteList.querySelectorAll("earnings-quote-item")).findIndex(e=>{var t,r;return!!e.shadowRoot&&!(null===(t=e.shadowRoot)||void 0===t||null===(r=t.querySelector)||void 0===r||!r.call(t,".quote:focus-visible"))});if(-1===r)return;const i=Math.floor(r/2)+1,o=null===(t=this.getState())||void 0===t?void 0:t.get(a.Xe.CurrentPageIndex);var s,n;i!==o&&(null===(s=(n=this.viewModel).flipperHandler)||void 0===s||s.call(n,i>o,e))}}disconnected(){super.disconnected(),this.currentMargin=0,(0,n.S)()&&this.earningsQuoteList.removeEventListener("focusin",this.onFocusIn)}connected(){super.connected(),"_1x_1y"===this.viewModel.cardSize&&(0,n.S)()&&this.earningsQuoteList.addEventListener("focusin",this.onFocusIn)}onCurrentPageIndexChange(e){const t=124*(this.viewModel.quoteList.length+1)-8-268,r=248*(e-1);this.currentMargin=Math.min(r,t)}initHandlers(){super.initHandlers(),this.onCurrentPageIndexChangeScoped=this.onCurrentPageIndexChange.bind(this)}addSubscriptions(){super.addSubscriptions();const e=this.getState();e&&e.subscribe(a.Xe.CurrentPageIndex,this.onCurrentPageIndexChangeScoped,{signal:this.subscriptionController.signal})}get listStyles(){return`${`height: ${this.viewModel.listHeight}`}; ${`inset-inline-end: ${this.currentMargin}px`};`}}(0,i.Cg)([o.sH],l.prototype,"currentMargin",void 0),(0,i.Cg)([o.Jg],l.prototype,"listStyles",null);var d=r(92011);const c=r(74849).A` .list{width:268px;display:flex;position:absolute;flex-direction:column;justify-content:space-between;transition:left 700ms,right 700ms}.list.small{display:flex;flex-direction:row;flex-wrap:nowrap;gap:8px}.placeholder{width:268px;height:50px}`;var g=r(96950),h=r(60402),u=r(39957),p=r(69259);const x=g.qy`<div class="list ${e=>"_1x_1y"===e.viewModel.cardSize?"small":""}" style="${e=>e.listStyles}" ${(0,h.K)("earningsQuoteList")}>${(0,u.ux)(e=>e.viewModel.quoteList,g.qy`<earnings-quote-item :viewModel="${e=>e.viewModel}"></earnings-quote-item>`)} ${(0,p.z)(e=>{var t;return"_1x_1y"===(null===(t=e.viewModel)||void 0===t?void 0:t.cardSize)},g.qy`<earnings-quote-item :viewModel="${e=>({isSeeMore:!0,seeMoreText:e.viewModel.seeMoreText,seeMoreLink:e.viewModel.seeMoreLink,telemetryTag:e.viewModel.telemetryTag})}" :isSeeMore="${()=>!0}"></earnings-quote-item>`)} ${(0,u.ux)(e=>new Array(e.viewModel.placeHoldersCount),g.qy`<div class="placeholder"></div>`)}</div>`,f=g.qy` ${(0,p.z)(e=>e&&void 0!==e.viewModel,x)}
`;let m=class extends l{};m=(0,i.Cg)([(0,d.E)({name:"earnings-quote-list",template:f,styles:c,shadowOptions:{delegatesFocus:!0}})],m)},42792(e,t,r){r.d(t,{R7(){return x},e(){return u},kc(){return p},nH(){return h}});var i=r(57416),a=r(55153),o=r(95239),s=r(26920),n=r(48751),l=r(64187),d=r(22131),c=r(74849),g=r(50882);const h=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,u=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${s.XA} * 1px) solid ${a.cu};
        border-radius: calc((${i.JU} - ${s.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${n.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${s.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,p=(0,d.mr)(c.A`
            :host {
                background: ${g.A.Canvas};
                color: ${g.A.CanvasText};
            }
        `),x=c.A`
    ${u}
    ${h}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(p)},53895(e,t,r){r.r(t),r.d(t,{EarningsQuoteItemTransformer(){return g},EarningsQuoteListTransformer(){return n}});var i=r(27208),a=r(49150),o=r(86449),s=r(96950);class n extends i.IB{async transform(e){const t=await this.getCurrentViewModel(e);return{viewTemplate:s.qy`
                <earnings-quote-list
                    :viewModel="${t}"
                ></earnings-quote-list>`}}getMaxQuoteItemCount(e){return e.cardSize===a.uE._1x_2y?4:7}getQuoteDetails(e){const t=this.getMaxQuoteItemCount(e);return e.quoteDetails.sort((e,t)=>Number(new Date(e.ExpectedReportDate))-Number(new Date(t.ExpectedReportDate))).slice(0,t)}async getQuoteListVMs(e){const t=this.getQuoteDetails(e).map(async(t,r)=>{const a=(0,o.jX)(t.DisplayName||"",t.Symbol,!0,this.transformerProvider.strings),s={cardSize:e.cardSize,tooltipText:a,experienceName:e.experienceName,tabName:e.tabName,quote:t,signature:e.signature,parentTelemetryObject:e.telemetryObject,seeMoreLink:e.seeMoreLink,seeMoreText:this.transformerProvider.strings.seeMore};return this.transformerProvider.generateView(s,i.Ai.EarningsQuoteItem)});return(await Promise.all(t)).filter(o.z2)}async getCurrentViewModel(e){const t=await this.getQuoteListVMs(e),r=this.getMaxQuoteItemCount(e)-t.length;return{quoteList:t,cardSize:e.cardSize,experienceName:e.experienceName,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{name:i.CD.seeMoreClick,signature:e.signature,headline:this.transformerProvider.strings.seeMore}),listHeight:(0,o.cf)(e.cardSize),seeMoreText:this.transformerProvider.strings.seeMore,placeHoldersCount:r,seeMoreLink:e.seeMoreLink,flipperHandler:this.transformerProvider.paginationFlipperClickHandler}}}var l=r(58792),d=r(30236);const c={20:{text:"preHours",icon:"SunIcon"},40:{text:"afterHours",icon:"MoonIcon"},default:{text:"",icon:"StopIcon"}};class g extends i.IB{async transform(e){return{viewModel:await this.getCurrentViewModel(e)}}getReportDate(e){return new Date(e.quote.ExpectedReportDate).toLocaleString(l.T3.CurrentMarket,{day:"2-digit",month:"2-digit"})}getMarketStatus(e){var t;const r=(null===(t=c[e])||void 0===t?void 0:t.text)||c.default.text;return this.transformerProvider.strings[r]||""}getMarketStatusIcon(e){var t;const r=(null===(t=c[e])||void 0===t?void 0:t.icon)||c.default.icon;return`${(0,l.rA)().StaticsUrl}/latest/money/icons/${r}.svg`}getQuoteUrl(e){return(0,d.Xe)(this.transformerProvider.config.urls,i.Rf.UpcomingEarnings,e.quote.InstrumentId,{notificationType:i.Ex.EarningRelease})}async getCurrentViewModel(e){return{cardSize:e.cardSize,experienceName:e.experienceName,marketStatusIcon:this.getMarketStatusIcon(e.quote.Timeslot),telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,{name:i.CD.quoteItemClick,signature:e.signature,headline:e.quote.Symbol,id:e.quote.InstrumentId}),quote:e.quote,changeColor:(0,o.BK)((0,o.jJ)(),e.quote.EpsForecast,this.transformerProvider.config.swapGainLossColor),reportDate:this.getReportDate(e),epsEstText:this.transformerProvider.strings.earningsEPSEstimated,tooltipText:e.tooltipText,quoteUrl:this.getQuoteUrl(e),marketStatus:this.getMarketStatus(e.quote.Timeslot),seeMoreText:e.seeMoreText,seeMoreLink:e.seeMoreLink}}}Promise.resolve().then(r.bind(r,39609)),Promise.resolve().then(r.bind(r,34648))},92707(e,t,r){r.d(t,{z(){return l}});var i=r(56911),a=r(27208),o=r(60815),s=r(92011),n=r(31525);let l=class extends s.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return a.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const e=this.getState();e&&(e.subscribe(a.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(e){}onChartDictChange(e){}onShowNotificationTextChange(e){}onQuoteItemDictChange(e){}onCardWidthChanged(e){}};(0,i.Cg)([o.sH],l.prototype,"viewModel",void 0),l=(0,i.Cg)([n.x],l)},99657(e,t,r){r.d(t,{D(){return s},I(){return o}});var i=r(45755);const{create:a}=i.G,o=a("sloppy-click-z-index",1),s=a("click-z-index",1)}}]);