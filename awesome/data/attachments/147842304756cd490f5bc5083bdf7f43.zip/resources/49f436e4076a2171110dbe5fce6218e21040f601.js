// © Microsoft Corporation. All rights reserved.
import { headData } from "@msnews/core";
import { getMuidCookie } from "@msnews/cookie-utils";
import { desktopConfig, mobileConfig } from "./displayAdConfig";
import { adChoicesStyle, adChoicesTemplate } from "./adChoicesTemplate";
/**
 * The class to load the appNexusAdsWrapper behavior
 * @export
 * @class
 */
class AppNexusAdsWrapper {
    constructor() {
        this.apnMemberId = this.getApnMemberId();
        this.externalUid = getMuidCookie();
        this.maxRefresh = 2;
    }
    getLocaleConfig() {
        const locale = headData.Locale;
        return this.isMobile() ? mobileConfig[locale] : desktopConfig[locale];
    }
    /**
     * Get the Member id for Microsoft
     * 280 is default value except in en-au and en-nz
     */
    getApnMemberId() {
        const locale = headData.Locale;
        const excludedMarkets = ["en-au", "en-nz"];
        return excludedMarkets.includes(locale) ? 1705 : 280;
    }
    createSdkScript() {
        const d = document;
        const script = d.createElement("script");
        const p = d.getElementsByTagName("head")[0];
        script.type = "text/javascript";
        script.async = true;
        script.src = "//acdn.adnxs.com/ast/ast.js";
        p.insertBefore(script, p.firstChild);
        return script;
    }
    isMobile() {
        let isMobile = false;
        if (headData && headData.ClientSettings) {
            const clientSettings = headData.ClientSettings;
            isMobile = ((clientSettings.browser && clientSettings.browser.ismobile === "true") || clientSettings.deviceFormFactor === "phone" /* DeviceFormFactorType.Phone */);
        }
        return isMobile;
    }
    getAdSize(ad) {
        const deviceDefaultConfig = this.isMobile() ? mobileConfig.defaultAdPlacementConfig : desktopConfig.defaultAdPlacementConfig;
        const width = ad?.width || deviceDefaultConfig.width;
        const height = ad?.height || deviceDefaultConfig.height;
        return [width, height];
    }
    addAdChoices(width) {
        $(".banner-container").append(adChoicesTemplate);
        const style = document.createElement("style");
        style.appendChild(document.createTextNode(adChoicesStyle(width)));
        document.head.appendChild(style);
    }
    /**
     * Render an Ad with the SDK
     */
    renderAd(divId) {
        if (!globalThis.apntag) {
            // @ts-ignore
            globalThis.apntag = {
                anq: []
            };
        }
        // @ts-ignore
        const localeConfig = this.getLocaleConfig();
        if (!localeConfig) {
            if (!this.isMobile()) {
                // closes the space left for banner ad in desktop mode
                document.getElementById("frame1").style.top = "375px";
            }
            return;
        }
        const adPlacement = localeConfig.adPlacements.find((ad) => ad.adName == "banner1");
        if (!adPlacement) {
            return;
        }
        const [width, height] = this.getAdSize(adPlacement);
        const appnexusObject = {
            member: this.apnMemberId,
            sizes: [width, height],
            targetId: divId,
            invCode: adPlacement.pageGroup,
            keywords: {
                flight: [
                    "prg-ad-xan-dl"
                ],
                msft_refresh: [this.maxRefresh.toString()]
            }
        };
        const pageOptions = {
            user: {
                externalUid: this.externalUid
            }
        };
        const isMobile = this.isMobile();
        const adScript = this.createSdkScript();
        this.addAdChoices(width);
        adScript.addEventListener("load", function () {
            // @ts-ignore
            globalThis.apntag.anq.push(function () {
                // set global options
                // @ts-ignore
                globalThis.apntag.setPageOpts(pageOptions);
            });
            // @ts-ignore
            globalThis.apntag.defineTag(appnexusObject);
            globalThis.apntag.onEvent("adLoaded", divId, function (adInfoObject) {
                // closes the space left for banner ad in desktop mode
                if (!adInfoObject && !isMobile) {
                    document.getElementById("frame1").style.top = "375px";
                }
            });
            // @ts-ignore
            globalThis.apntag.loadTags();
            // @ts-ignore
            globalThis.apntag.anq.push(function () {
                // signal to script that this DOM element has been loaded and is ready to be populated with an ad
                // @ts-ignore
                globalThis.apntag.showTag(divId);
            });
        });
    }
    /**
     * Renders a new ad 3 times for every 30 sec
     */
    renderAdWithRefresh(divId) {
        this.renderAd(divId);
        let refreshCount = 0;
        const intervalId = setInterval(() => {
            globalThis.apntag.refresh([divId]);
            refreshCount += 1;
            if (refreshCount >= this.maxRefresh) {
                clearInterval(intervalId);
            }
        }, 30000);
    }
}
export const appNexusAdsWrapper = new AppNexusAdsWrapper();
//# sourceMappingURL=AppNexusAdsWrapper.js.map