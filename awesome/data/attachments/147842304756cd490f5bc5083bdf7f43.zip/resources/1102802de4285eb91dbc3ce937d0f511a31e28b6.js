"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-hide-popup"],{2993(t,e,o){o.r(e),o.d(e,{SportsHidePopupTransformer(){return r}});var i=o(23587),a=o(54229);class r extends i.Bc{static getInstance(t){return r.instance||(r.instance=new r(t)),r.instance}async transform(t){this.parentTelemetryObject=t.parentTelemetryObject;return{viewModel:await this.getViewModel(t)}}async getViewModel(t){var e,o;return{changeLeagueTeamCallback:()=>{var t,e,o,i;null===(t=(e=this.transformerProvider).hidePopupToggleHandler)||void 0===t||t.call(e,!1),null===(o=(i=this.transformerProvider).openSearchViewHandler)||void 0===o||o.call(i,!0)},sendFeedbackCallback:()=>{var t,e;null===(t=(e=this.transformerProvider).hidePopupToggleHandler)||void 0===t||t.call(e,!1)},hideSportsCardCallback:()=>{var t,e,o,i;null===(t=(e=this.transformerProvider).hidePopupToggleHandler)||void 0===t||t.call(e,!1),null===(o=(i=this.transformerProvider).hideClickHandler)||void 0===o||o.call(i,"")},cancelHideCallback:()=>{var t,e;null===(t=(e=this.transformerProvider).hidePopupToggleHandler)||void 0===t||t.call(e,!1)},gobackToSportsCard:()=>{var t,e;null===(t=(e=this.transformerProvider).hidePopupToggleHandler)||void 0===t||t.call(e,!1)},handleSportsNotInterested:()=>{var e,o,i,a,r;null===(e=(o=this.transformerProvider).hidePopupToggleHandler)||void 0===e||e.call(o,!1),null===(i=(a=this.transformerProvider).hideClickHandler)||void 0===i||i.call(a,(null===(r=t.cardData)||void 0===r?void 0:r.primaryEntityId)||"")},feedbackDialogConfigInfo:this.transformerProvider.config.feedbackDialogConfigInfo,telemetryTag:this.transformerProvider.telemetryBuilder.createViewTelemetryTag(this.parentTelemetryObject,{...t.telemetryConstants,name:i.BP.PopupHideSport}),changeLeagueTeamTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(this.parentTelemetryObject,{...t.telemetryConstants,name:i.BP.ChangeLeagueTeam},a.YJ.Customize),feedbackTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(this.parentTelemetryObject,{...t.telemetryConstants,name:i.BP.Feedback},a.YJ.Paginate),popupHideSportTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(this.parentTelemetryObject,{...t.telemetryConstants,name:i.BP.PopupHide},a.YJ.Hide),popupCancelTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(this.parentTelemetryObject,{...t.telemetryConstants,name:i.BP.PopupCancel},a.YJ.Cancel),popupCloseTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(this.parentTelemetryObject,{...t.telemetryConstants,name:i.BP.PopupClose},a.YJ.Close),menuDislikeSportTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(this.parentTelemetryObject,{...t.telemetryConstants,name:i.BP.DislikeSports},a.YJ.Dislike),strings:{...this.transformerProvider.strings,sportsNotInterestedFormatted:null===(e=this.transformerProvider.strings)||void 0===e||null===(e=e.sportsNotInterested)||void 0===e?void 0:e.replace("{0}",(null===(o=t.cardData)||void 0===o?void 0:o.primaryEntityName)||"")}}}}Promise.resolve().then(o.bind(o,28044))},4968(t,e,o){o.d(e,{f(){return d}});var i=o(64187),a=o(74849),r=o(42792),n=o(99657),l=o(36452);const d=a.A.partial`position: relative; z-index: ${n.D};`;a.A`
    ${r.e}
    ${r.nH}

    ${(0,i.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${d}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(r.kc)},28044(t,e,o){o.r(e),o.d(e,{SportsHidePopup(){return M}});var i=o(56911),a=o(92011),r=o(41123),n=o(89580),l=o(92393),d=o(48751),s=o(37302),p=o(86856),c=o(74849),g=o(4968),h=o(22131),u=o(50882);const b=c.A` .refresh-button{margin-left:4px}.manage-button{margin-right:4px}.popup-close-button{left:auto;right:12px}`,f=c.A` .refresh-button{margin-right:4px}.manage-button{margin-left:4px}.popup-close-button{left:12px;right:auto}`,x=c.A` .sports-hide-popup{${g.f};z-index:900}.hide-popup-actions{display:grid;grid-template-columns:var(--button-min-width) var(--button-min-width);justify-content:center;grid-gap:var(--space-between-buttons);margin-top:4px}.popup-action-button{border-radius:var(--button-border-radius);font-size:14px}.hide-popup{display:flex;flex-direction:column;margin:18px 0 4px;width:328px;outline:none}.hide-popup-menu{margin-bottom:16px;border-radius:20px;width:280px;align-self:center}::part(control){position:relative}fluent-button::part(control){width:-webkit-fill-available}fluent-button::part(content){text-overflow:ellipsis;overflow:hidden}::part(heading){position:initial;margin-bottom:18px;margin-top:4px;padding:0 12px;width:314px}::part(heading span){margin:24px}.hide-reminder{margin:0;padding:16px;font-size:${r.K};
        line-height: ${n.v};font-weight:600}.setting-link{text-transform:uppercase;text-decoration:none;color:${l.W_};
        background: none;
        border: none;
        padding: 0;
        cursor: pointer;
        font-weight: 600;
        font-size: ${r.K}}.action-button{display:flex;width:300px;padding:16px;box-sizing:border-box;position:absolute}.manage-button{min-height:32px;margin-top:8px;width:100%;margin-right:4px}.refresh-button{min-height:32px;margin-top:8px;width:100%;margin-left:4px}.check-icon{display:flex;justify-content:center;fill:var(--neutral-foreground-rest);padding:56px 0}.popup-close-button{position:absolute;top:12px;display:inline-flex;justify-content:center;align-items:center;min-width:32px;height:32px;line-height:1;padding:0 10px;box-sizing:border-box;border-radius:2px;color:${d.l};font-family:inherit;background:inherit;cursor:pointer;transition:all 0.1s ease-in-out}.popup-close-button:hover{background:${s.X4}}.popup-close-button svg{width:8px;height:8px;fill:${d.l}}:host([colormode="dark"]) .report-option-container .report-inputbox::part(control)::placeholder{color:rgba(255,255,255,0.54);fill:#4A4A4A}`.withBehaviors(new p.t(b,f),(0,h.mr)(c.A` :host{forced-color-adjust:auto}@media screen and (-ms-high-contrast:active){.popup-close-button:hover{background:${u.A.Highlight};
                        color: ${u.A.HighlightText}}.popup-close-bitton:focus-visible{border-color:1px solid transparent;box-shadow:0 0 0 1px inset ${u.A.ButtonText}}.popup-close-button svg path{fill:${u.A.ButtonText};
                    }
                }
            `));var v=o(96950),$=o(69259),m=o(63250),k=o(68017),w=o(15302),y=o(65055);k.n;const z=v.qy`
    ${t=>(0,y.yN)(t.viewModel.feedbackDialogConfigInfo,{properties:{visible:t.loadDialog}})}
`,T=v.qy`
    <div class="hide-popup" tabindex="0">
        ${(0,$.z)((t,e)=>!(0,w.o)(t.viewModel.strings.sportsNotInterestedFormatted),v.qy`
            <fluent-button
                class="hide-popup-menu"
                tabindex="0"
                aria-label=${t=>t.viewModel.strings.sportsNotInterestedFormatted}
                role="button"
                title=${t=>t.viewModel.strings.sportsNotInterestedFormatted}
                @click="${(t,e)=>t.viewModel.handleSportsNotInterested()}"
                @keypress="${(t,e)=>e.event&&"Enter"==e.event.key&&t.viewModel.handleSportsNotInterested()}"
                data-t="${t=>t.viewModel.menuDislikeSportTelemetryTag}"
            >
                ${t=>t.viewModel.strings.sportsNotInterestedFormatted}
            </fluent-button>
        `)}
        <fluent-button
            class="hide-popup-menu"
            tabindex="0"
            aria-label=${t=>t.viewModel.strings.popupChangeLeagueTeam}
            role="button"
            title=${t=>t.viewModel.strings.popupChangeLeagueTeam}
            @click="${(t,e)=>t.changeLeagueTeamClickHandler(e.event)}"
            @keypress="${(t,e)=>e.event&&"Enter"==e.event.key&&t.changeLeagueTeamClickHandler(e.event)}"
            data-t="${t=>t.viewModel.changeLeagueTeamTelemetryTag}"
        >
            ${t=>t.viewModel.strings.popupChangeLeagueTeam}
        </fluent-button>
        <fluent-button
            class="hide-popup-menu"
            tabindex="0"
            aria-label=${t=>t.viewModel.strings.popupSendFeedback}
            role="button"
            title=${t=>t.viewModel.strings.popupSendFeedback}
            @click="${(t,e)=>t.sendFeedbackClickHandler(e.event)}"
            @keypress="${(t,e)=>e.event&&"Enter"==e.event.key&&t.sendFeedbackClickHandler(e.event)}"
            data-t="${t=>t.viewModel.feedbackTelemetryTag}"
            >
            ${t=>t.viewModel.strings.popupSendFeedback}
        </fluent-button>
    </div>
`,S=v.qy`
    <msn-action-dialog
        class="sports-hide-popup"
        headline=${t=>t.viewModel.strings.hidePopupTitle}
        ariaLabel=${t=>t.viewModel.strings.hidePopupTitle}
        @action-dialog-dismiss=${t=>t.viewModel.gobackToSportsCard()}
        data-t="${t=>t.viewModel.telemetryTag}"
        modal
    >
        <div
            slot="close-button"
            class="popup-close-button"
            tabindex="0"
            aria-label=${t=>t.viewModel.strings.closeButton}
            role="button"
            title=${t=>t.viewModel.strings.closeButton}
            @click=${(t,e)=>t.cancelClickHandler(e.event)}
            @keypress="${(t,e)=>e.event&&"Enter"==e.event.key&&t.cancelClickHandler(e.event)}"
            data-t="${t=>t.viewModel.popupCloseTelemetryTag}"
        >
            ${v.qy.partial(m.A)}
        </div>
        <div>
            ${T}
            <div class="hide-popup-actions">
                <fluent-button
                    class="popup-action-button"
                    appearance="accent"
                    tabindex="0"
                    @click=${(t,e)=>t.hideSportsCardClickHandler(e.event)}
                    @keypress="${(t,e)=>e.event&&"Enter"==e.event.key&&t.hideSportsCardClickHandler(e.event)}"
                    aria-label=${t=>t.viewModel.strings.popupHideButton}
                    role="button"
                    title=${t=>t.viewModel.strings.popupHideButton}
                    data-t="${t=>t.viewModel.popupHideSportTelemetryTag}"
                >
                    ${t=>t.viewModel.strings.popupHideButton}
                </fluent-button>
                <fluent-button
                    class="popup-action-button"
                    tabindex="0"
                    @click=${(t,e)=>t.cancelClickHandler(e.event)}
                    @keypress="${(t,e)=>e.event&&"Enter"==e.event.key&&t.cancelClickHandler(e.event)}"
                    aria-label=${t=>t.viewModel.strings.cancel}
                    role="button"
                    title=${t=>t.viewModel.strings.cancel}
                    data-t="${t=>t.viewModel.popupCancelTelemetryTag}"
                >
                    ${t=>t.viewModel.strings.cancel}
                </fluent-button>
            </div>
        </div>
    </msn-action-dialog>
    `,C=v.qy`
    ${(0,$.z)(t=>t.isHidePopupOpen,S)}
    ${(0,$.z)(t=>t.loadDialog,z)}
`,I=v.qy`
    ${(0,$.z)(t=>null!=t.viewModel,C)}
`;var _=o(77367),j=o(85349),E=o(60815),H=o(84564),P=o(66287),A=o(54229),D=o(85312);class L extends H.z{constructor(){super(...arguments),this.isHidePopupOpen=!1,this.loadDialog=!1,this.changeLeagueTeamClickHandler=t=>{t&&(t.stopPropagation(),t.preventDefault(),_.YT.sendActionEvent(t.target,j.EG.Click)),this.viewModel.changeLeagueTeamCallback()},this.sendFeedbackClickHandler=t=>{t&&(t.stopPropagation(),t.preventDefault(),_.YT.sendActionEvent(t.target,j.EG.Click)),this.viewModel.sendFeedbackCallback(),this.openFeedbackPopup()},this.hideSportsCardClickHandler=t=>{t&&(t.stopPropagation(),t.preventDefault(),_.YT.sendActionEvent(t.target,j.EG.Click)),this.viewModel.hideSportsCardCallback()},this.cancelClickHandler=t=>{t&&(t.stopPropagation(),t.preventDefault(),_.YT.sendActionEvent(t.target,j.EG.Click)),this.viewModel.cancelHideCallback()},this.openFeedbackPopup=()=>{this.viewModel.feedbackDialogConfigInfo?(this.loadDialog||(this.loadDialog=!0),A.aC.safeExecute(()=>{window.requestAnimationFrame(()=>{var t,e;this.feedbackDialog||(this.feedbackDialog=null===(t=this.shadowRoot)||void 0===t||null===(e=t.querySelector)||void 0===e?void 0:e.call(t,"feedback-dialog-wc"));this.feedbackDialog&&(this.feedbackDialog.visible=!0)})},void 0,D.TE,"SportsInfo - error when opening feedback module")):this.hookAPI()}}hookAPI(){A.aC.safeExecute(()=>{var t;if(null!==(t=window.chrome)&&void 0!==t&&null!==(t=t.ntpSettingsPrivate)&&void 0!==t&&t.launchEdgeFeedback){const t=(0,P.KI)();if(t){const e=new URL(window.location.href),o=e.hash;e.hash=`pivot-${t}`,history.replaceState(history.state,"",e),window.location.reload(),window.chrome.ntpSettingsPrivate.launchEdgeFeedback(),window.stop(),e.hash=o||"",history.replaceState(history.state,"",e)}else window.chrome.ntpSettingsPrivate.launchEdgeFeedback()}},void 0,D.TE,"SportsInfo - error when opening edge NTP feedback module")}}(0,i.Cg)([E.sH],L.prototype,"isHidePopupOpen",void 0),(0,i.Cg)([E.sH],L.prototype,"loadDialog",void 0);let M=class extends L{};M=(0,i.Cg)([(0,a.E)({name:"sports-hidepopup",template:I,styles:x})],M)},42792(t,e,o){o.d(e,{R7(){return b},e(){return h},kc(){return u},nH(){return g}});var i=o(57416),a=o(55153),r=o(95239),n=o(26920),l=o(48751),d=o(64187),s=o(22131),p=o(74849),c=o(50882);const g=p.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=p.A`
    ${(0,d.V)("flex")} :host {
        background: ${r.p};
        outline: calc(${n.XA} * 1px) solid ${a.cu};
        border-radius: calc((${i.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${l.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,s.mr)(p.A`
            :host {
                background: ${c.A.Canvas};
                color: ${c.A.CanvasText};
            }
        `),b=p.A`
    ${h}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},68017(t,e,o){o.d(e,{n(){return w}});var i=o(56911),a=o(92011),r=o(26633),n=o(38493);class l extends r.b{constructor(){super(...arguments),this.headinglevel=2,this.dismiss=()=>{this.$emit("action-dialog-dismiss")}}}(0,i.Cg)([(0,n.CF)({attribute:"headline"})],l.prototype,"headline",void 0);var d=o(57416),s=o(71157),p=o(62198),c=o(74849),g=o(64187);const h=c.A`
    ${(0,g.V)("flex")} :host{--dialog-height:var(--action-dialog-height,auto);--dialog-width:var(--action-dialog-width,auto);--button-border-radius:20px;--button-min-width:160px;--control-corner-radius:2px;--dialog-padding:24px;--space-above-title:20px;--space-between-buttons:8px;z-index:var(--action-dialog-z-index,0)}.body{margin:0 var(--dialog-padding) var(--dialog-padding) var(--dialog-padding)}.content{display:flex;flex-direction:column}.controls{display:grid;grid-template-columns:auto auto;grid-gap:var(--space-between-buttons);justify-content:center}.heading{display:grid;grid-template-columns:1fr auto;grid-template-rows:1;position:relative;width:100%;border-top-left-radius:calc(${d.JU} * 1px);
        border-top-right-radius: calc(${d.JU} * 1px);overflow:hidden}.heading span{font-size:${s.T};
        font-weight: 600;
        line-height: ${p.a};
        margin-inline-start: var(--dialog-padding);
        margin-top: var(--space-above-title);
    }
`;var u=o(96950),b=o(69259),f=o(60402);const x=u.qy`<div class="positioning-region" part="positioning-region">${(0,b.z)(t=>t.modal,u.qy`<div class="overlay" part="overlay" role="presentation" tabindex="-1" @click="${t=>t.dismiss()}"></div>`)}<div role="dialog" class="control" part="control" aria-modal="${t=>t.modal}" aria-describedby="${t=>t.ariaDescribedby}" aria-labelledby="${t=>t.ariaLabelledby}" aria-label="${t=>t.ariaLabel}" ${(0,f.K)("dialog")}><div class="heading" part="heading"><span role="heading" aria-level=${t=>t.headinglevel}>${t=>t.headline}</span><slot name="close-button"></slot></div><div class="body" part="body"><div class="content" part="content"><slot></slot></div><div class="controls" part="controls"><slot name="action-button"></slot><slot name="cancel-button"></slot></div></div></div></div>`;var v=o(37998),$=o(95239),m=o(26920);const k=c.A` :host([hidden]){display:none}:host{--elevation:14;--dialog-height:480px;--dialog-width:640px;display:block}.overlay{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.3);touch-action:none}.positioning-region{display:flex;justify-content:center;position:fixed;top:0;bottom:0;left:0;right:0;overflow:auto}.control{${v.ET}
    margin-top: auto;
    margin-bottom: auto;
    border-radius: calc(${d.JU} * 1px);
    width: var(--dialog-width);
    height: var(--dialog-height);
    background: ${$.p};
    z-index: 1;
    border: calc(${m.XA} * 2px) solid transparent;
    position: relative;
  }
`;let w=class extends l{};w=(0,i.Cg)([(0,a.E)({name:"msn-action-dialog",template:x,styles:[k,h],shadowOptions:{delegatesFocus:!0}})],w)},84564(t,e,o){o.d(e,{z(){return n}});var i=o(56911),a=o(60815),r=o(92011);class n extends r.L{}(0,i.Cg)([a.sH],n.prototype,"viewModel",void 0)},99657(t,e,o){o.d(e,{D(){return n},I(){return r}});var i=o(45755);const{create:a}=i.G,r=a("sloppy-click-z-index",1),n=a("click-z-index",1)}}]);