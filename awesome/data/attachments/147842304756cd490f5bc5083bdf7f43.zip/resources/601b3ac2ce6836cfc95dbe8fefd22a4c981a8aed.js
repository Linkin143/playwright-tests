"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["boost-ad-card"],{4968(t,e,i){i.d(e,{f(){return l}});var o=i(64187),a=i(74849),s=i(42792),n=i(99657),r=i(36452);const l=a.A.partial`position: relative; z-index: ${n.D};`;a.A`
    ${s.e}
    ${s.nH}

    ${(0,o.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${r.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${r.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${r.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(s.kc)},13509(t,e){e.A='<svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path clip-rule="evenodd" d="M7.5 9c0 .7-.24 1.33-.63 1.84l2.77 2.77a.37.37 0 1 1-.53.53l-2.77-2.77A3 3 0 1 1 7.5 9Zm-3 2.25a2.25 2.25 0 1 0 0-4.5 2.25 2.25 0 0 0 0 4.5Z"/><path clip-rule="evenodd" d="M4.13 2.25c-.21 0-.38.17-.38.38v2.7c-.26.05-.51.13-.75.23V2.63C3 2 3.5 1.5 4.13 1.5h3.8c.3 0 .6.12.8.33l2.94 2.94c.21.2.33.5.33.8v6.8c0 .63-.5 1.13-1.13 1.13h-.44c-.05-.15-.14-.3-.26-.42l-.33-.33h1.04c.2 0 .37-.17.37-.38V6H8.62C8 6 7.5 5.5 7.5 4.87V2.25H4.12Zm4.12.16v2.46c0 .21.17.38.38.38h2.46L8.25 2.41Z"/></svg>'},25717(t,e,i){i.d(e,{T(){return a}});var o=i(96950);function a(){return o.qy`
        <slot></slot>
    `}},26391(t,e,i){i.d(e,{T(){return s}});var o=i(93552),a=i(22341);const s=(0,i(91454).sx)(o.WQp,"sendAdImageLoadError")(t=>{let{isBoost:e,...i}=t;(0,a.vV)(e?o.H77:o.MxD,"Ads image is not loaded properly",n(i),{shouldSampleErrorsForTreatement1:!e})}),n=t=>{let{id:e,rLink:i,imgLink:o,event:a,retryCount:s,isRetrySuccessful:n,status:r,statusText:l,type:d,redirected:c,errorMessage:h}=t;return JSON.stringify({id:e,rLink:i,imgLink:o||a&&a.target.src,retryCount:s,isRetrySuccessful:n,status:r,statusText:l,type:d,redirected:c,errorMessage:h})}},31422(t,e){e.A='<svg width="14" height="14" viewBox="0 0 14 14"><path d="M.4.15A.5.5 0 0 0 .37.8l.05.05 2.69 2.7A6.66 6.66 0 0 0 .46 7.36a.5.5 0 0 0 .97.25 5.66 5.66 0 0 1 2.39-3.36l1.2 1.2A2.67 2.67 0 0 0 8.8 9.25l3.95 3.94a.5.5 0 0 0 .75-.65l-.04-.05L9.37 8.4l-.8-.8L6.66 5.7 4.74 3.77l-.76-.75L1.13.15a.5.5 0 0 0-.71 0Zm5.33 6.03 2.36 2.35a1.67 1.67 0 0 1-2.36-2.35Zm1.2-3.85A6.66 6.66 0 0 0 5 2.62l.83.82a5.67 5.67 0 0 1 6.6 4.18.5.5 0 0 0 .96-.24 6.67 6.67 0 0 0-6.46-5.05Zm.13 2.34 2.53 2.54a2.67 2.67 0 0 0-2.53-2.54Z" fill-opacity=".83"/></svg>'},33393(t,e,i){i.r(e),i.d(e,{BoostAdCard(){return U},BoostAdCardStyles(){return E},BoostAdCardTemplate(){return mt},BoostCardTemplate(){return gt},ToolingInfo(){return pt},fetchBoost(){return Z}});var o=i(75003),a=i(37180),s=i(7574),n=i(56911);const r="hide",l="AmplifyCard",d="privacysettings",c="tagline",h="image",u="TTBoost.LoadingToBoost",v="TTBoost.LoadingToNews",g="TTBoost.OnDemandDuration";var m=i(15148),p=i(93552),b=i(22341),f=i(17918),x=i(77367),y=i(85349),k=i(80895),$=i(60815),T=i(77793),w=i(12680),A=i(33477),C=i(29658),L=i(38319),M=i(39671),B=i(58792),S=i(25109),F=i(71398),_=i(34230),D=i(2789);const H=`${B.T3.StaticsUrl}latest/icons-wc/icons`,I={PersonLock:{lightMode:`${H}/PersonLock.svg`,darkMode:`${H}/dark-mode/PersonLock.svg`},HideV2:{lightMode:`${H}/HideV2.svg`,darkMode:`${H}/dark-mode/HideV2.svg`},MicrosoftLogo:`${B.T3.StaticsUrl}latest/community/img/logo/microsoft.svg`};class U extends M.U{constructor(){super(),this.isActionMenuOpen=!1,this.actionMenuItems=[],this.refreshFeedCard=()=>{this.refreshFeed?this.refreshFeed():this.$emit("refreshSDCardSection")},this.mapSuperSDCardData=()=>{var t,e,i,o,a,s,n,r;this.cardData=this.mapPromotionData(this.boostAdData);const l={footerLink:{text:null===(t=this.cardData)||void 0===t?void 0:t.callToActionText,navigationUrl:null===(e=this.cardData)||void 0===e?void 0:e.callToActionLink},telemetryHeadlines:{footerLink:null===(i=this.cardData)||void 0===i?void 0:i.tagline}};this.skipPrefetch&&(this.boostTimeEvent[u]=Math.round(performance.now())-this.loadingCardReady,x.YT.sendLoadTimeEvent({markers:this.boostTimeEvent})),this.data={id:"boost-ad-card",gridArea:"",childTemplateType:"sd-card",cardSize:this.cardSize||"_1x_2y",metadata:{cardType:C.s.BoostCard},headerData:{isHideCardAvailable:!1,isMoreSettingAvailable:!1,headerLogo:null===(o=this.cardData)||void 0===o?void 0:o.headerLogo,title:null===(a=this.cardData)||void 0===a?void 0:a.logoText,titleNavigationLink:null===(s=this.cardData)||void 0===s?void 0:s.clickthroughUrl,actionMenuData:{items:this.actionsMenuItems},telemetryHeadlines:{logo:null===(n=this.cardData)||void 0===n?void 0:n.tagline,title:null===(r=this.cardData)||void 0===r?void 0:r.tagline}},footerData:!this.isHalfu||this.enableBoostCTA?l:void 0,contextualFeedbackData:this.wpoMetadata&&this.wpoMetadata.isGA?{cFId:this.wpoMetadata.cfId,cFMetadataType:this.wpoMetadata.cFMetadataType}:void 0,parentTelemetryObject:this.boostAdCardTelemetryObject}},this.mapPromotionData=t=>{const{destinationUrl:e,imageUrl:i,tagLine:o,logoText:a,imageUrlFallback:s,actionText:n,logoUrl:r}=t;return{cardType:"Boost_Ad",imageDataUrl:this.isProng2&&!this.isHalfu?s:i,imageActionLink:e,callToActionText:n||this.strings.boostCardCallToActionText,callToActionLink:e,logoText:a,clickthroughUrl:e,tagline:o,taglineLink:e,headerLogo:r?this.getHeaderLogo(r):this.getHeaderLogo(I.MicrosoftLogo)}},this.hideCard=async()=>{try{let t=!1;return t=await F.d.updateSegmentCardsEnableStatus([{cardType:C.s.BoostCard,enabled:!1}]),t&&(this.refreshFeedCard?this.refreshFeedCard():this.$emit("refreshSDCardSection")),t}catch(t){return(0,b.c_)(t,p.kBB,"boost card hide error"),!1}},this.getBoostAd=async()=>{const t=Math.round(performance.now()),e=await Z(this.boostAdMetadata);var i,o;e?(this.boostTimeEvent[g]=Math.round(performance.now())-t,this.showLoadingCard=!1,this.setTmpl(),this.boostAdData=(0,D.$3)(e,!0),this.isProng1=null===(i=this.boostAdData)||void 0===i?void 0:i.isProng1Promotion,this.isProng2=null===(o=this.boostAdData)||void 0===o?void 0:o.isProng2Promotion,this.mapSuperSDCardData()):(this.boostTimeEvent[v]=Math.round(performance.now())-this.loadingCardReady,x.YT.sendLoadTimeEvent({markers:this.boostTimeEvent}),document.dispatchEvent(new CustomEvent("replaceWithNewsBackfill",{detail:{cardType:"BoostAd"}})))},this.loadingCardReady=0,this.boostTimeEvent={},this.data={id:"",gridArea:"",childTemplateType:"sd-card",headerData:{headerLogo:"",title:""}}}setTmpl(){x.YT.addOrUpdateTmplProperty("BoostVisible","1")}generateTelemetryTags(){var t;if(!this.telemetryObject)return;const e=null===(t=this.parentTelemetry)||void 0===t?void 0:t.contract,i=null==e?void 0:e.ext;this.boostAdCardTelemetryObject=this.telemetryObject.addOrUpdateChild({name:l,content:{type:y.b5.StructuredData},ext:i}),this.boostAdCardTelemetryTag=this.boostAdCardTelemetryObject.getMetadataTag(),this.hideBoostCardTelemetryTag=this.boostAdCardTelemetryObject.addOrUpdateChild({name:r,action:y.EG.Click,content:{type:y.b5.StructuredData},behavior:y.MS.Hide,ext:i}).getMetadataTag(),this.privacySettingsTelemetryTag=this.boostAdCardTelemetryObject.addOrUpdateChild({name:d,action:y.EG.Click,content:{type:y.b5.StructuredData},behavior:y.MS.Navigate,ext:i}).getMetadataTag(),this.contentHeaderTelemetryTag=this.boostAdCardTelemetryObject.addOrUpdateChild({name:c,action:y.EG.Click,content:{type:y.b5.StructuredData},behavior:y.MS.Navigate,ext:i}).getMetadataTag(),this.contentImageTelemetryTag=this.boostAdCardTelemetryObject.addOrUpdateChild({name:h,action:y.EG.Click,content:{type:y.b5.StructuredData},behavior:y.MS.Navigate,ext:i}).getMetadataTag()}experienceConnected(){var t,e;(this.initSuperSDSetting(),this.generateTelemetryTags(),this.actionsMenuItems=this.getActionMenuItem(),this.enableBoostCTA=this.config.enableBoostCTA,this.config.mockData&&(this.boostAdMetadata=this.config.mockData),null!=this.boostAdMetadata)&&(!this.cardSize||this.cardSize!==A.uE._1x_1y&&this.cardSize!==A.uE._05u||(this.isHalfu=!0),"BoostOnDemand"===this.boostAdMetadata.subType&&(this.skipPrefetch=!0),this.useDarkMode=(0,S.ud)()||k.F_.get(1),this.skipPrefetch?this.showLoadingCard=!0:(this.boostAdData=(0,D.$3)(this.boostAdMetadata,!1),this.isProng1=null===(t=this.boostAdData)||void 0===t?void 0:t.isProng1Promotion,this.isProng2=null===(e=this.boostAdData)||void 0===e?void 0:e.isProng2Promotion,this.setTmpl(),this.mapSuperSDCardData()))}getExperienceType(){return w.Op9}shadowDomPopulated(){(0,m.D)(()=>{const t=this.getApproxTTVRValue();(0,f.oO)(this.getExperienceType(),!1,t,!t)}),this.skipPrefetch&&k.F_.subscribe(2,async t=>{t&&(this.loadingCardReady=Math.round(performance.now()),this.getBoostAd().catch(t=>{(0,b.c_)(t,p.Azd,"boost card on demand process error")}))})}disconnectedCallback(){this.isProng1&&document.removeEventListener(T.ib,T.pl),super.disconnectedCallback(),x.YT.removeTmplProperty("BoostAdUsedTitle"),x.YT.removeTmplProperty("BoostAdUsedLongTitle")}initSuperSDSetting(){this.superSDSetting=new L.t(U,C.s.BoostCard,void 0,this.goToPersonalizeSettingsCallback,this.refreshFeedCard)}getActionMenuItem(){const t=[];return t.push({id:"hide",glyphUrls:I.HideV2,title:this.strings.boostHideCard,ariaLabel:this.strings.boostHideCard,onClick:async()=>{this.hideCard()},telemetryTag:this.hideBoostCardTelemetryTag}),t.push({id:"adChoice",glyphUrls:I.PersonLock,title:this.strings.boostPrivacySettingsText,async onClick(){return window.open("https://account.microsoft.com/privacy/ad-settings","_blank")},telemetryTag:this.privacySettingsTelemetryTag??""}),t.push({isDivider:!0}),t.push({id:"poweredBy",isText:!0,title:this.strings.boostPoweredByText,ariaLabel:this.strings.boostPoweredByText}),t}get callTtvr(){return()=>{(0,f.oO)(this.getExperienceType())}}getHeaderLogo(t){return`<img src="${t}" aria-hidden="true">`}}(0,n.Cg)([$.sH],U.prototype,"hideBoostCardTelemetryTag",void 0),(0,n.Cg)([$.sH],U.prototype,"contentHeaderTelemetryTag",void 0),(0,n.Cg)([$.sH],U.prototype,"contentImageTelemetryTag",void 0),(0,n.Cg)([$.sH],U.prototype,"privacySettingsTelemetryTag",void 0),(0,n.Cg)([$.sH],U.prototype,"boostAdCardTelemetryTag",void 0),(0,n.Cg)([$.sH],U.prototype,"actionsMenuItems",void 0),(0,n.Cg)([$.sH],U.prototype,"isActionMenuOpen",void 0),(0,n.Cg)([$.sH],U.prototype,"actionMenuItems",void 0),(0,n.Cg)([$.sH],U.prototype,"superSDSetting",void 0),(0,n.Cg)([$.sH],U.prototype,"data",void 0),(0,n.Cg)([$.sH],U.prototype,"cardData",void 0),(0,n.Cg)([$.sH],U.prototype,"useDarkMode",void 0),(0,n.Cg)([$.sH],U.prototype,"isProng1",void 0),(0,n.Cg)([$.sH],U.prototype,"isProng2",void 0),(0,n.Cg)([$.sH],U.prototype,"showLoadingCard",void 0),(0,n.Cg)([$.Jg],U.prototype,"callTtvr",null);const Z=async t=>{try{const{data:e,headers:i,url:o}=t,a=e||null,s=new URL("https://boost.mediation.trafficmanager.net/api/v1/boost/native/client"),n=await(0,_.w)(async()=>await fetch(s.href,{method:"POST",mode:"cors",headers:{...JSON.parse(i),Accept:"application/json","Content-Type":"application/json"},body:a}),"BoostOnDemand.fetch");if(!n||!n.ok){const{status:t,statusText:e}=n||{};throw new Error(`Response status: ${t}, Response statusText: ${e}`)}return 200!==n.status?null:n.json()}catch(t){return(0,b.c_)(t,p.Azd,"boost card on demand fetch error"),null}};var P=i(96950),R=i(69259),j=i(92011),O=i(4968),V=i(74849);const E=V.A`a,button{${O.f}}.feeds3{height:100%}`;var z=i(12640);const N=V.A`
.boost-content-1u .boost_title .content-title{
    color: #1A1A1A;
}`,J=V.A`
.boost-content-1u .boost_title .content-title{
    color: #FFFFFF;
}`,W=V.A` .boost-content-1u a{text-decoration:none}.boost-content-1u{position:relative;display:flex;flex-direction:column}.boost-content-1u .content-image img{border-radius:8px;width:268px;height:140px;border-radius:8px;object-fit:cover}.boost-content-1u .boost_title{max-width:268px;position:relative;overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;top:16px}.feeds3 .boost_title{-webkit-line-clamp:3;height:70px}.boost-content-1u .boost_title .content-title{font-style:normal;font-weight:600;font-size:20px;line-height:26px;color:#1A1A1A}${E};

`.withBehaviors(new z.N(N,J));var q=i(26391);const G=P.qy`<div class="content-section boost-content-1u column ${t=>t.enableFeeds3?"feeds3":""}">${(0,R.z)(t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.imageDataUrl},P.qy`<a class="content-image" href="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.imageActionLink}}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img class="center-image" src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.imageDataUrl}} title=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.tagline}} alt=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.tagline}} @load=${t=>t.visualReadinessCallback&&t.visualReadinessCallback()} @error=${(t,e)=>{var i,o;t.visualReadinessCallback&&t.visualReadinessCallback(e.event),(0,q.T)({id:"boost-ad-card",rLink:null===(i=t.data)||void 0===i?void 0:i.imageActionLink,imgLink:null===(o=t.data)||void 0===o?void 0:o.imageDataUrl,isBoost:!0})}}></img></a>`)}<div class="boost_title"><a class= "text-container" href="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.taglineLink}}" target="_blank" data-t="${t=>t.contentHeaderTelemetryTag}"><span class="content-title" title=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.tagline}}>${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.tagline}}</span></a></div></div>`;let K=class extends j.L{constructor(){super(...arguments),this.enableFeeds3=!1}};(0,n.Cg)([$.sH],K.prototype,"data",void 0),(0,n.Cg)([$.sH],K.prototype,"visualReadinessCallback",void 0),(0,n.Cg)([$.sH],K.prototype,"contentHeaderTelemetryTag",void 0),(0,n.Cg)([$.sH],K.prototype,"contentImageTelemetryTag",void 0),K=(0,n.Cg)([(0,j.E)({name:"content-template-boost-1u-card",template:G,styles:W})],K);const Q=V.A`
.boost-content-halfu .boost_title .content-title{
    color: #1A1A1A;
}`,X=V.A`
.boost-content-halfu .boost_title .content-title{
    color: #FFFFFF;
}`,Y=V.A`

.boost-content-halfu a{
    text-decoration: none;
}

.boost-content-halfu{
    position: relative;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
}

.boost-content-halfu .boost_title{
    width: 178px;
    height: 62px;
    padding-bottom: 4px;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    text-overflow: ellipsis;
}

.boost-content-halfu .boost_title .content-title{
    font-family: ${"Segoe UI"};
    font-style: normal;
    font-weight: 600;
    font-size: 16px;
    line-height: 20px;
    color: #1A1A1A;
}


.boost-content-halfu .content-image img{
    border-radius: 8px;
    object-fit: cover;
    width: 82px;
    height: 82px;
}

.boost-content-halfu .content-image-cta img{
    border-radius: 8px;
    object-fit: cover;
    width: 66px;
    height: 66px;
}

${E};

`.withBehaviors(new z.N(Q,X)),tt=P.qy`<div class="content-section boost-content-halfu column"><div class="boost_title"><a class= "text-container" href="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.taglineLink}}" target="_blank" data-t="${t=>t.contentHeaderTelemetryTag}"><span class="content-title" title=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.tagline}}>${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.tagline}}</span></a></div>${(0,R.z)(t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.imageDataUrl},P.qy`<a class=${t=>t.enableBoostCTA?"content-image-cta":"content-image"} href="${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.imageActionLink}}" target="_blank" data-t="${t=>t.contentImageTelemetryTag}"><img class="center-image" src=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.imageDataUrl}} title=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.tagline}} alt=${t=>{var e;return null===(e=t.data)||void 0===e?void 0:e.tagline}} @load=${t=>t.visualReadinessCallback&&t.visualReadinessCallback()} @error=${(t,e)=>{var i,o;t.visualReadinessCallback&&t.visualReadinessCallback(e.event),(0,q.T)({id:"boost-ad-card",rLink:null===(i=t.data)||void 0===i?void 0:i.imageActionLink,imgLink:null===(o=t.data)||void 0===o?void 0:o.imageDataUrl,isBoost:!0})}}></img></a>`)}</div>`;let et=class extends j.L{constructor(){super(...arguments),this.enableBoostCTA=!1}};(0,n.Cg)([$.sH],et.prototype,"data",void 0),(0,n.Cg)([$.sH],et.prototype,"visualReadinessCallback",void 0),(0,n.Cg)([$.sH],et.prototype,"contentHeaderTelemetryTag",void 0),(0,n.Cg)([$.sH],et.prototype,"contentImageTelemetryTag",void 0),et=(0,n.Cg)([(0,j.E)({name:"content-template-boost-halfu-card",template:tt,styles:Y})],et);class it extends j.L{constructor(){super(...arguments),this.isHalfu=!0}}(0,n.Cg)([$.sH],it.prototype,"isHalfu",void 0);const ot="16px",at="4px",st=V.A` :host{display:block;--skeleton-fill-default:var(--neutral-fill-secondary-rest)}.loading-card{border-radius:calc(var(--layer-corner-radius) * 1px);box-shadow:0 0 calc((var(--elevation) * 0.225px) + 2px) rgba(0,0,0,calc(0.11 * (2 - var(--background-luminance,1)))),0 calc(var(--elevation) * 0.4px) calc((var(--elevation) * 0.9px)) rgba(0,0,0,calc(0.13 * (2 - var(--background-luminance,1))))}.loading-card-medium{height:302px}.loading-card-small{height:144px}.skeleton-medium{border-radius:${at};
        width: 267px;
        height: 14px;
        margin-bottom: 8px;
        margin-inline-start: ${ot};
        margin-inline-end: ${"15px"}}.skeleton-medium:first-child{margin:15px 0 50px 0;margin-inline-start:${ot};width:77px}.skeleton-medium:nth-child(3){margin-bottom:35px}.skeleton-medium:nth-child(5){margin-bottom:44px}.skeleton-small{margin-inline-start:${ot}}.skeleton-small-title{display:flex;flex-direction:row;align-items:center;margin:16px 0 28px 0;margin-inline-start:${ot}}.skeleton-small-body{display:flex;margin-inline-start:${ot};
        border-radius: ${at}}.skeleton-small-image{width:42px;height:42px;margin-inline-end:${ot}}.skeleton-small-title fluent-skeleton:first-child{width:20px;height:20px}.skeleton-small-title fluent-skeleton:nth-child(2){width:76px;height:10px;margin-inline-start:12px;border-radius:${at}}.skeleton-small-first{width:164px;height:14px;margin-bottom:14px;border-radius:${at}}.skeleton-small-second{width:109px;height:14px;border-radius:${at};
    }`.withBehaviors(new z.N(V.A` .loading-card{background:#F6F6F6;border:1px solid rgba(0,0,0,0.0578)}`,V.A` fluent-skeleton{--skeleton-fill-default:#383838;--skeleton-animation-gradient-default:linear-gradient( 270deg,var(--skeleton-fill,var(--skeleton-fill-default)) 0%,#333333 51.13%,var(--skeleton-fill,var(--skeleton-fill-default)) 100% )}.loading-card{background:#2C2C2C;border:1px solid rgba(0,0,0,0.1)}`));var nt=i(39957);const rt=P.qy`<div class="loading-card loading-card-small"><div class="skeleton-small-title"><fluent-skeleton shape="circle" shimmer></fluent-skeleton><fluent-skeleton shape="rect" shimmer></fluent-skeleton></div><div class="skeleton-small-body"><fluent-skeleton class="skeleton-small-image" shape="rect" shimmer></fluent-skeleton><div><fluent-skeleton class="skeleton-small-first" shape="rect" shimmer></fluent-skeleton><fluent-skeleton class="skeleton-small-second" shape="rect" shimmer></fluent-skeleton></div></div></div>`,lt=P.qy`<div class="loading-card loading-card-medium">${(0,nt.ux)(t=>[...Array(7).keys()],P.qy`<fluent-skeleton class="skeleton-medium" shape="rect" shimmer></fluent-skeleton>`)}</div>`,dt=P.qy` ${t=>t.isHalfu?rt:lt}
`;let ct=class extends it{};ct=(0,n.Cg)([(0,j.E)({name:"promotion-loading-card",template:dt,styles:st})],ct);const ht=P.qy`<div class="super-card-body"><content-template-boost-1u-card :data=${t=>t.cardData} :contentImageTelemetryTag=${t=>t.contentImageTelemetryTag} :contentHeaderTelemetryTag=${t=>t.contentHeaderTelemetryTag} :visualReadinessCallback=${t=>t.visualReadinessCallback} :enableFeeds3=${t=>t.config.useFeeds3Design} ${(0,T.Ib)(!0,!0,!1)}></content-template-boost-1u-card"></div>`,ut=P.qy`<div class="super-card-body"><content-template-boost-halfu-card :data=${t=>t.cardData} :contentImageTelemetryTag=${t=>t.contentImageTelemetryTag} :contentHeaderTelemetryTag=${t=>t.contentHeaderTelemetryTag} :visualReadinessCallback=${t=>t.visualReadinessCallback} :enableBoostCTA=${t=>t.enableBoostCTA} ${(0,T.Ib)(!0,!0,!1)}></content-template-boost-halfu-card"></div>`,vt=P.qy`<promotion-loading-card :isHalfu=${t=>t.isHalfu}></promotion-loading-card>`,gt=P.qy`<div class="Boost-Card ${t=>t.config.useFeeds3Design?"feeds3":""}" data-t="${t=>t.boostAdCardTelemetryTag}"><responsive-sd-card :data="${t=>t.data}" :size="${t=>t.cardSize}" ?feeds3-design="${t=>t.config.useFeeds3Design}" ${(0,T.Ib)(!0,!0,!1)}>${(0,R.z)(t=>t.cardData,P.qy`<div slot="card-content">${t=>t.isHalfu?ut:ht}</div>`)}</responsive-sd-card></div>`,mt=P.qy` ${t=>t.showLoadingCard?vt:gt} `;o.m.define(a.c.registry),(0,s.o)();const pt={experienceConfigSchema:undefined}},37256(t,e,i){i.d(e,{R(){return h}});var o=i(64187),a=i(22131),s=i(74849),n=i(50882),r=i(37998),l=i(57416),d=i(95239),c=i(48751);const h=s.A`
    ${(0,o.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${d.p};
        color: ${c.l};
        border-radius: calc(${l.JU} * 1px);
        ${r.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,a.mr)(s.A`
            :host {
                forced-color-adjust: none;
                background: ${n.A.Canvas};
                box-shadow: 0 0 0 1px ${n.A.CanvasText};
            }
        `))},38319(t,e,i){i.d(e,{t(){return u}});var o=i(56911),a=i(13509),s=i(31422),n=i(80541),r=i(93552),l=i(77367),d=i(60815),c=i(71398),h=i(40865);class u{constructor(t,e,i,o,a){this.menuItems=[],this.isActionMenuOpen=!1,this.actionsMenuButtonElement=null,this.onOutsideClick=t=>{const e=t.composedPath()&&t.composedPath()[0];t.target instanceof this.currentSDClass||(0,h.W)(this.actionsMenuButtonElement,e)||this.toggleActionMenu(!1,null)},this.onKeydown=t=>{"Escape"===t.code&&this.toggleActionMenu(!1,null)},this.moreSettingAction=async()=>{this.toggleActionMenu(!1,null),this.goToPersonalizeSettingsCallback&&this.goToPersonalizeSettingsCallback()},this.hideSettingAction=async()=>{if(!this.segmentSdCardType)return!1;try{const t=await c.d.updateSegmentCardsEnableStatus([{cardType:this.segmentSdCardType,enabled:!1}]);return t&&this.refreshSDCardSection&&this.refreshSDCardSection(),this.toggleActionMenu(!1,null),t}catch(t){return l.YT.sendAppErrorEvent({...r.N2u,message:`Fail to hide ${this.segmentSdCardType} Card .`,pb:{...r.N2u.pb,customMessage:`Failed with exception : ${t}`}}),!1}},this.currentSDClass=t,this.settingMenuConfig=i,this.goToPersonalizeSettingsCallback=o,this.refreshSDCardSection=a,this.menuItems=this.getBaseActionMenuItems(),this.segmentSdCardType=e}updateMenuItems(t,e){this.menuItems=e?this.menuItems.concat(t):t.concat(this.menuItems)}toggleActionMenu(t,e){this.isActionMenuOpen=t,t?(this.actionsMenuButtonElement=e&&e.currentTarget,this.setAriaExpanded(t),document.addEventListener("click",this.onOutsideClick),document.addEventListener("keydown",this.onKeydown)):(this.setAriaExpanded(t),this.actionsMenuButtonElement=null,document.removeEventListener("click",this.onOutsideClick),document.removeEventListener("keydown",this.onKeydown))}setAriaExpanded(t){this.actionsMenuButtonElement&&(this.actionsMenuButtonElement.ariaExpanded=String(t))}getBaseActionMenuItems(){var t,e;if(!this.settingMenuConfig)return[];const i=[];if(null!==(t=this.settingMenuConfig.interestSetting)&&void 0!==t&&t.onClick){const t=this.settingMenuConfig.interestSetting;i.push({glyph:s.A,title:t.title,id:"dislike",onClick:t.onClick,telemetryTag:t.telemetryTag})}if(null!==(e=this.settingMenuConfig.dataProviderSetting)&&void 0!==e&&e.onClick){const t=this.settingMenuConfig.dataProviderSetting;i.push({glyph:a.A,title:t.title,id:"dataProvider",onClick:t.onClick,telemetryTag:t.telemetryTag})}if(this.settingMenuConfig.hideSetting){const t=this.settingMenuConfig.hideSetting;i.push({glyph:s.A,title:t.title,id:"hide",onClick:t.onClick?t.onClick:()=>this.hideSettingAction(),telemetryTag:t.telemetryTag})}if(this.settingMenuConfig.moreSetting){const t=this.settingMenuConfig.moreSetting;i.push({glyph:n.A,ariaLabel:t.ariaLabel,title:t.title,id:"more",onClick:t.onClick?t.onClick:()=>this.moreSettingAction(),telemetryTag:t.telemetryTag})}return i}}(0,o.Cg)([d.sH],u.prototype,"menuItems",void 0),(0,o.Cg)([d.sH],u.prototype,"isActionMenuOpen",void 0)},38380(t,e,i){i.d(e,{v(){return o}});const o=(0,i(25717).T)()},72526(t,e,i){i.d(e,{L(){return g}});var o=i(56911),a=i(96193),s=i(47429),n=i(60815),r=i(22870),l=i(38493),d=i(95239),c=i(31023),h=i(24458),u=i(5291),v=i(57606);class g extends a.z{cardFillColorChanged(t,e){if(e){const t=(0,r.Hs)(e);null!==t&&(this.neutralPaletteSource=e,d.p.setValueFor(this,u.q.create(t.r,t.g,t.b)))}}neutralPaletteSourceChanged(t,e){if(e){const t=(0,r.Hs)(e),i=u.q.create(t.r,t.g,t.b);c.r.setValueFor(this,v.p.create(i))}}handleChange(t,e){this.cardFillColor||d.p.setValueFor(this,t=>t(h.M3).evaluate(t,t(d.p)))}connectedCallback(){super.connectedCallback();const t=(0,s.Zo)(this);if(t){const e=n.cP.getNotifier(t);e.subscribe(this,"fillColor"),e.subscribe(this,"neutralPalette"),this.handleChange(t,"fillColor")}}}(0,o.Cg)([(0,l.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,o.Sn)("design:type",String)],g.prototype,"cardFillColor",void 0),(0,o.Cg)([(0,l.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,o.Sn)("design:type",String)],g.prototype,"neutralPaletteSource",void 0)},75003(t,e,i){i.d(e,{m(){return r}});var o=i(37180),a=i(72526),s=i(37256),n=i(38380);const r=a.L.compose({name:`${o.c.prefix}-card`,template:n.v,styles:s.R})},80541(t,e){e.A='<svg width="17" height="17" viewBox="0 0 17 17"><path d="M.02 5.88A8.5 8.5 0 0 1 1.8 2.8a.5.5 0 0 1 .54-.13l1.92.68a1 1 0 0 0 1.32-.76l.37-2a.5.5 0 0 1 .39-.4 8.53 8.53 0 0 1 3.55 0 .5.5 0 0 1 .39.4l.37 2a1 1 0 0 0 1.32.76l1.91-.68a.5.5 0 0 1 .54.13 8.5 8.5 0 0 1 1.78 3.08.5.5 0 0 1-.15.54L14.5 7.74a1 1 0 0 0 0 1.52l1.55 1.32a.5.5 0 0 1 .15.54 8.5 8.5 0 0 1-1.78 3.08.5.5 0 0 1-.54.13l-1.91-.68a1 1 0 0 0-1.32.76l-.37 2a.5.5 0 0 1-.39.4 8.53 8.53 0 0 1-3.55 0 .5.5 0 0 1-.4-.4l-.36-2a1 1 0 0 0-1.32-.76l-1.92.68a.5.5 0 0 1-.54-.13 8.49 8.49 0 0 1-1.78-3.08.5.5 0 0 1 .16-.54l1.55-1.32a1 1 0 0 0 0-1.52L.18 6.42a.5.5 0 0 1-.16-.54Zm1.06 0 1.3 1.1a2 2 0 0 1 0 3.04l-1.3 1.1c.3.79.72 1.51 1.25 2.16l1.6-.58a2 2 0 0 1 2.64 1.53l.3 1.67a7.56 7.56 0 0 0 2.49 0l.3-1.67a2 2 0 0 1 2.64-1.53l1.6.57a7.5 7.5 0 0 0 1.24-2.15l-1.29-1.1a2 2 0 0 1 0-3.05l1.3-1.1a7.5 7.5 0 0 0-1.25-2.15l-1.6.57a2 2 0 0 1-2.64-1.52l-.3-1.67a7.55 7.55 0 0 0-2.49 0l-.3 1.67A2 2 0 0 1 3.93 4.3l-1.6-.57a7.5 7.5 0 0 0-1.25 2.15ZM5.62 8.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0Zm1 0a1.5 1.5 0 1 0 3 0 1.5 1.5 0 0 0-3 0Z" fill-opacity=".83"/></svg>'}}]);