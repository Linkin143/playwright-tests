"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-cricket"],{4968(t,e,r){r.d(e,{f(){return l}});var o=r(64187),n=r(74849),i=r(42792),a=r(99657),s=r(36452);const l=n.A.partial`position: relative; z-index: ${a.D};`;n.A`
    ${i.e}
    ${i.nH}

    ${(0,o.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(i.kc)},10500(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},22726(t,e,r){r.r(e),r.d(e,{SportsCricketTransformer(){return c}});var o=r(23587),n=r(79811),i=r(31157),a=r(54229),s=r(58792),l=r(96950);const p="yet to bat";class c extends o.Bc{constructor(){super(...arguments),this.getShowMatchCount=t=>{switch(t){case"_1x_2y":case"medium":return 3;case"_1x_3y":case"large":return 4;default:return 1}},this.getGameDate=t=>(new Date).toDateString()===new Date(t).toDateString()?this.transformerProvider.strings.today:t,this.getMatchSummaryText=t=>{if(!t)return"";switch(t.detailedGameState){case o.Xp.preGame:return t.venueInfo?t.venueInfo:t.venue?`${null===(e=t.venue)||void 0===e?void 0:e.name}, ${(null===(r=t.venue)||void 0===r?void 0:r.state)||(null===(n=t.venue)||void 0===n?void 0:n.city)||""}`:"";var e,r,n;case o.Xp.inprogressGame:case o.Xp.dinner:case o.Xp.tea:case o.Xp.drinks:case o.Xp.fog:case o.Xp.innings:case o.Xp.lunch:case o.Xp.stumps:case o.Xp.break:case o.Xp.superover:case o.Xp.abandoned:case o.Xp.postponed:case o.Xp.delayed:return t.gameSummaryInfo||t.tossInfo||"";case o.Xp.postGame:return t.gameSummaryInfo||"";case o.Xp.toss:return t.tossInfo||"";case o.Xp.nonlive:{const e=t.detailedGameState;return this.transformerProvider.strings[e]||e||""}default:return""}}}async transform(t){const e=await this.getViewModel(t);return{viewTemplate:l.qy`
                <sports-cricket
                    :viewModel="${e}"
                ></sports-cricket>`}}async getViewModel(t){const e=this.getMatchData(t),r=t.cardSize,s=this.getShowMatchCount(r),l={...t.telemetryConstants,name:o.BP.Game};return{cardSize:r,enabledCricketMatchSummaryInfo:s>1,followClickHandler:this.transformerProvider.followClickEntityHandler,followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:o.BP.FollowTeam},!0),followedMap:e.followedMap,isExploration:t.isExploration,isIPL:"Cricket_IPL"===t.leagueId,isRTL:document.dir===i.O.rtl,linkTarget:"_blank",matchData:e.matches,matchSummaryMap:e.matchSummaryMap,scoreClassNameMap:e.scoreClassNameMap,scoresMap:e.scoresMap,showMatchCount:s,shouldShowPinToDesk:!1,isDarkMode:(0,n.jJ)(),pinToDeskClick(){},strings:{...this.transformerProvider.strings},telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,l),pinToDeskButtonTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(t.telemetryObject,{telemetryContentContext:l,name:o.BP.PinToDesk},a.YJ.Customize)}}getMatchData(t){var e;const r=(null===(e=t.matchData)||void 0===e?void 0:e.map(t=>null==t?void 0:t.sportsMatchData))||[],i=t.followedSports||new Map,a=new Map,l=new Map,p=new Map,c=new Map;return r.forEach(t=>{if(t){var e;const r=t.participantOne||{},d=t.participantTwo||{},u=t.gameId||"";let h=t.gameDate;const g=(0,n.yn)(t.gameStartDateTime);h=(0,n.AL)(g,s.T3.CurrentMarket),t.gameStartTime=(t.gameStartDateTimeIsToBeAnnounced?null:(0,n.ry)(g,s.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA;const S="string"!=typeof t.gameState?(0,n.m5)(t.gameState.state):t.gameStateCatetory,m=t.gameState&&"string"!=typeof t.gameState?this.getDetailedGameStatus(null===(e=t.gameState)||void 0===e?void 0:e.detailedGameState):t.detailedGameState;t.detailedGameState=m!==o.Xp.nonlive?m:S;let f="";f=m&&m!==o.Xp.nonlive?m:S===o.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:S,t.gameStateCatetory=S,t.gameState=f,r.imageUrl=this.getParticipantIconUrl(r.imageUrl||(0,n.iK)(r.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced)||""),d.imageUrl=this.getParticipantIconUrl(d.imageUrl||(0,n.iK)(d.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced)||""),r.gameCenterUrl&&(r.scheduleUrl=(0,n.Ot)(r.gameCenterUrl)),d.gameCenterUrl&&(d.scheduleUrl=(0,n.Ot)(d.gameCenterUrl)),t.gameCenterUrl&&!t.matchClickthroughUrl&&(t.matchClickthroughUrl=(0,n.Ot)(t.gameCenterUrl)),a.set(`${u}${r.satoriId}`,this.getParticipantScoreClassname(r,d,!0)),a.set(`${u}${d.satoriId}`,this.getParticipantScoreClassname(d,r,!1)),l.set(`${u}${r.satoriId}`,this.getScoreLines(r)),l.set(`${u}${d.satoriId}`,this.getScoreLines(d)),t.gameDate=this.getGameDate(h||""),t.gameStateCatetory=t.cricketGameCategory||t.gameStateCatetory,p.set(u,this.getMatchSummaryText(t)),(0,n.gK)(r,i)&&c.set(r.satoriId,!0),(0,n.gK)(d,i)&&c.set(d.satoriId,!0)}}),{matches:r,scoreClassNameMap:a,scoresMap:l,matchSummaryMap:p,followedMap:c}}getParticipantIconUrl(t){return null==t?void 0:t.replace(/w=([\d]*)?&h=([\d]*)?/,"w=72&h=72")}getParticipantScoreClassname(t,e,r){let o="participant-score";var n;t&&(r&&(o+=" text-align-end"),t.isWinner?o+=" winner":null!=e&&e.isWinner&&(o+=" loser"),(null===(n=t.score)||void 0===n?void 0:n.toLowerCase())===p&&(o+=" long-score"));return o}getScoreLines(t){if(t&&t.score){if(t.score.includes("&")){const e=t.score.split("&"),r=e[0],o=r.indexOf("(");return-1!==o&&(e[0]=r.slice(0,o)),e}return t.score.toLowerCase()===p?["--/-",t.score]:t.score.split(" ")}return[]}getDetailedGameStatus(t){switch(t){case"InProgressGame":case"InProgress":return o.Xp.inprogressGame;case"Drinks":return o.Xp.drinks;case"Dinner":return o.Xp.dinner;case"Tea":return o.Xp.tea;case"Lunch":return o.Xp.lunch;case"Fog":return o.Xp.fog;case"Innings":return o.Xp.innings;case"Stumps":return o.Xp.stumps;case"InningsBreak":return o.Xp.break;case"Toss":return o.Xp.toss;case"SuperOver":return o.Xp.superover;case"BadWeatherCondition":return o.Xp.BadWeatherCondition;case"PreGame":return o.Xp.preGame;case"Final":case"PostGame":return o.Xp.postGame;case"Delayed":return o.Xp.delayed;case"Abandoned":return o.Xp.abandoned;case"Postponed":return o.Xp.postponed;default:return o.Xp.nonlive}}}},23587(t,e,r){var o,n,i,a,s;r.d(e,{X2(){return v},qz(){return k},pA(){return T},S_(){return M},VO(){return a},oL(){return s},GC(){return w},IG(){return b},D7(){return l},bo(){return p},ci(){return B},Bc(){return L},hi(){return R},XR(){return f},rq(){return m},Xp(){return u},kA(){return F},JC(){return D},tX(){return H},mx(){return I},aB(){return x},jx(){return g},t9(){return $},sQ(){return S},T0(){return h},Z5(){return d},pC(){return V},JH(){return A},v1(){return o},BP(){return N},kt(){return c},Qy(){return P}}),function(t){t.Standings="Standings",t.Articles="Articles",t.TeamVsTeam="TeamVsTeam",t.TeamVsTeamWithBracket="TeamVsTeamWithBracket",t.Tennis="Tennis",t.MotorSportsSingleRace="MotorSportsSingleRace",t.MotorSportsRaceList="MotorSportsRaceList",t.GolfSchedule="GolfSchedule",t.GolfLeaderBoard="GolfLeaderBoard",t.Cricket="Cricket",t.TeamVsTeamExploration="TeamVsTeamExploration",t.LeagueEventResultOneVsOne="OneVsOneEventResult",t.LeagueEventResultOneVsMany="OneVsManyEventResult",t.LeagueEventResultTeamVsTeam="TeamVsTeamEventResult",t.CricketExploration="CricketExploration",t.TennisExploration="TennisExploration",t.EventBrief="EventBrief",t.SeasonStatistics="SeasonStatistics",t.Video="Video",t.Countdown="Countdown",t.Fre="FRE",t.Spotlight="Spotlight",t.SpotlightRace="SpotlightRace",t.SpotlightTennis="SpotlightTennis",t.SpotlightGolf="SpotlightGolf",t.SpotlightFRE="SpotlightFRE",t.StandingsRankings="StandingsRankings",t.SportsMedal="TeamStandings",t.LeagueEvents="LeagueTodaysEvents",t.TeamStandingWithMedals="TeamStandingWithMedals",t.TeamStandingWithEvents="TeamStandingWithEvents",t.SpotlightCricket="SpotlightCricket",t.TournamentsList="TournamentsList",t.Spotlight2c="Spotlight2c",t.AgentSpotlight="AgentSpotlight"}(o||(o={})),function(t){t.SportsInfo="SportsInfo",t.SportsInfoSpan="SportsInfoSpan",t.SportsMatchList="SportsMatchList",t.SportsMatch="SportsMatch",t.SportsSpanMatch="SportsSpanMatch",t.SportsArticle="SportsArticle",t.SportsTeamExploration="SportsTeamExploration",t.SportsTeamExplorationMatch="SportsTeamExplorationMatch",t.SportsCricketExploration="SportsCricketExploration",t.SportsTennisExploration="SportsTennisExploration",t.SportsExplorationHead="SportsExplorationHead",t.SportsLeaderboard="SportsLeaderboard",t.SportsCricket="SportsCricket",t.SportsCricketV2="SportsCricketV2",t.SportsTennis="SportsTennis",t.SportsMarchmadness="SportsMarchmadness",t.SportsEventBrief="SportsEventBrief",t.SportsEventCountry="SportsEventCountry",t.SportsEventResults="SportsEventResults",t.FeedsNotificationToast="FeedsNotificationToast",t.SportsHidePopup="SportsHidePopup",t.SportsFre="SportsFre",t.SportsSpotlight="SportsSpotlight",t.AgentSpotlight="AgentSpotlight",t.SportsSpotlight2c="SportsSpotlight2c",t.SportsGameStats="SportsGameStats",t.SportsCountdown="SportsCountdown",t.SportsAugmentCard="SportsAugmentCard",t.SportsSpotlightRace="SportsSpotlightRace",t.SportsSpotlightTennis="SportsSpotlightTennis",t.SportsTennisMatch="SportsTennisMatch",t.SportsSpotlightGolf="SportsSpotlightGolf",t.SharedHeroNewsCard="SharedHeroNewsCard",t.SportsSimpleMatch="SportsSimpleMatch",t.SportsStandingsRankings="SportsStandingsRankings",t.SportsEventSchedule="SportsEventSchedule",t.SportsMedal="SportsMedal",t.SportsMedalV2="SportsMedalV2",t.SportsInfoList="SportsInfoList",t.SportsRecentMedal="SportsRecentMedal",t.SportsRubyPill="SportsRubyPill",t.SportsSpotlightCricket="SportsSpotlightCricket",t.SportsSpotlightCricketV2="SportsSpotlightCricketV2",t.SportsTournamentsList="SportsTournamentsList",t.SportsTournamentStatusRow="SportsTournamentStatusRow"}(n||(n={})),function(t){t.Initial="initial",t.Default="default",t.Settings="settings",t.ColdStart="coldstart"}(i||(i={})),function(t){t.scheduledTournaments="GolfSchedule",t.leaderboard="GolfLeaderBoard"}(a||(a={})),function(t){t.singleRace="MotorSportsSingleRace",t.raceList="MotorSportsRaceList"}(s||(s={}));const l=Object.freeze({unknown:"Unknown",football:"Football",baseball:"Baseball",basketball:"Basketball",basketball3x3:"Basketball3x3",cricket:"Cricket",icehockey:"IceHockey",fieldhockey:"FieldHockey","auto racing":"Racing",racing:"Racing",tennis:"Tennis",soccer:"Soccer",golf:"Golf",australianrules:"AustralianRules",rugbyunion:"RugbyUnion",rugbyleague:"RugbyLeague",archery:"Archery",athletics:"Athletics",badminton:"Badminton",cycling:"Cycling",boxing:"Boxing",canoeing:"Canoeing",climbing:"Climbing",equestrianism:"Equestrianism",fencing:"Fencing",gymnasticsartistic:"GymnasticsArtistic",gymnasticsrhytmic:"GymnasticsRhytmic",gymnasticstrampoline:"GymnasticsTrampoline",handball:"Handball",judo:"Judo",karate:"Karate",summerolympics:"SummerOlympics",paralympics:"Paralympics",pentathlon:"Pentathlon",swimmingartistic:"SwimmingArtistic",swimming:"Swimming",diving:"Diving",waterpolo:"WaterPolo",rowing:"Rowing",sailing:"Sailing",shooting:"Shooting",skateboarding:"Skateboarding",surfing:"Surfing",taekwondo:"Taekwondo",triathlon:"Triathlon",tabletennis:"TableTennis",volleyballteam:"VolleyballTeam",volleyballbeach:"VolleyballBeach",weightlifting:"Weightlifting",wrestling:"Wrestling",softball:"Softball",trackandfield:"TrackAndField",mma:"MMA",netball:"Netball",boccia:"Boccia"});var p;!function(t){t.Mentioned="Mentioned",t.Related="Related"}(p||(p={}));const c="CHAMPIONS",d=" - ";var u,h;!function(t){t.preGame="pre-game",t.inprogressGame="inprogress-game",t.postGame="post-game",t.nonlive="non-live",t.toss="Toss",t.dinner="Dinner",t.drinks="Drinks",t.fog="Fog",t.innings="Innings",t.lunch="Lunch",t.stumps="Stumps",t.tea="Tea",t.break="Break",t.superover="SuperOver",t.abandoned="Abandoned",t.postponed="Postponed",t.BadWeatherCondition="BadWeatherCondition",t.delayed="Delayed"}(u||(u={})),function(t){t.PreGame="PreGame",t.InProgressGame="InProgressGame",t.InProgress="InProgress",t.Final="Final",t.PostGame="PostGame",t.Live="Live",t.Unknown="Unknown"}(h||(h={}));const g={Badge:"Badge",Preview:"PreviewCard"},S="Sports",m="SportsFre",f={League:"League",Team:"Team"},v={Dislike:"Dislike",Follow:"Follow"};var x;!function(t){t.Leaderboard="Leaderboard",t.FRE="Fre",t.Tennis="Tennis",t.Cricket="Cricket",t.SportsSpotlight="SportsSpotlight",t.SideBySide="SideBySide",t.Countdown="Countdown"}(x||(x={}));const b={0:"recommendationNone",1:"recommendationExplicit",2:"recommendationImplicit",3:"recommendationPopular",4:"recommendationLive",5:"recommendationMIT",6:"recommendationLocalPopular",7:"recommendationRecentSelect"},w="EntityId~";var y,k,T,C,M,$;!function(t){t.Gold="Gold",t.Silver="Silver",t.Bronze="Bronze",t.Total="Total"}(y||(y={})),function(t){t.Won="Won",t.Lost="Lost",t.Tied="Tied"}(k||(k={})),function(t){t.none="None",t.unknown="Unknown",t.captain="Captain",t.batter="Batter",t.bowler="Bowler",t.wicketKeeper="WicketKeeper",t.allRounder="AllRounder"}(T||(T={})),function(t){t.one="1",t.two="2"}(C||(C={})),function(t){t.test="Test",t.odi="Odi",t.t20="T20"}(M||(M={})),function(t){t.PickTheWinner="PickTheWinner",t.PickWinner="PickWinner",t.PlayerOfMatch="PlayerOfMatch"}($||($={}));var E=r(18272),_=r(2171);const D="sportsInfoAppState";var F;!function(t){t[t.sportsInfoApiData=1]="sportsInfoApiData",t[t.sportsData=2]="sportsData",t[t.sportsSDCardView=3]="sportsSDCardView",t[t.sportsViewMode=4]="sportsViewMode",t[t.tabCurrentPageIndex=5]="tabCurrentPageIndex",t[t.currentTabEntityId=6]="currentTabEntityId",t[t.cardSize=7]="cardSize",t[t.cardType=8]="cardType",t[t.experienceName=9]="experienceName",t[t.entityDataMap=10]="entityDataMap",t[t.entityViewMap=11]="entityViewMap",t[t.sportsSuggestIDMap=12]="sportsSuggestIDMap",t[t.interestOptions=13]="interestOptions",t[t.allRecommendations=14]="allRecommendations",t[t.dislikedEntities=15]="dislikedEntities",t[t.followedSports=16]="followedSports",t[t.sportsConfig=17]="sportsConfig",t[t.sportsStrings=18]="sportsStrings",t[t.rootTelemetryObject=19]="rootTelemetryObject",t[t.telemetryExt=20]="telemetryExt",t[t.isPinned=21]="isPinned",t[t.isExplorationCard=22]="isExplorationCard",t[t.isHidePopupOpen=23]="isHidePopupOpen",t[t.widgetDimension=24]="widgetDimension",t[t.searchSuggestions=25]="searchSuggestions",t[t.toggleInterestManager=26]="toggleInterestManager",t[t.sportsFeedDataParsed=27]="sportsFeedDataParsed",t[t.feedDataTimestamp=28]="feedDataTimestamp",t[t.wpoMetadata=29]="wpoMetadata",t[t.currentSpotlightEntityId=30]="currentSpotlightEntityId",t[t.previewTypeInfo=31]="previewTypeInfo",t[t.isInit=32]="isInit",t[t.isV2Data=33]="isV2Data",t[t.skinnyDataConsumed=34]="skinnyDataConsumed",t[t.isCopilotTheme=35]="isCopilotTheme",t[t.IsRubyPill=36]="IsRubyPill",t[t.pollOptionId=37]="pollOptionId",t[t.isRubyMiniWidget=38]="isRubyMiniWidget"}(F||(F={})),(0,E.G)({getInstance(){return _.vv.get("sportsStates",()=>new Map)}});const R={SportsInfo:"sports-sd-container",SportsInfoSpan:"sports-info-span",SportsMatchList:"sports-match-list",SportsMatch:"sports-match",Articles:"sports-articles",TeamExploration:"sports-team-exploration",TeamExplorationMatch:"sports-team-exploration-match",CricketExploration:"sports-cricket-exploration",TennisExploration:"sports-tennis-exploration",ExplorationHead:"sports-exploration-head",Standings:"sports-standings",Leaderboard:"sports-leaderboard",SportsCricket:"sports-cricket",SportsCricketV2:"sports-cricket-v2",SportsTennis:"sports-tennis",SportsMarchmadness:"sports-marchmadness",FeedsNotificationToast:"feeds-notification-toast",SportsHidePopup:"sports-hidepopup",SportsFre:"sports-fre",SportsEventBrief:"sports-event-brief",SportsEventCountry:"sports-event-country",SportsEventResults:"sports-event-results",SportsSpanMatch:"sports-span-match",SportsSpotlight:"sports-spotlight",AgentSpotlight:"agent-spotlight",SportsGameStats:"sports-game-stats",SportsGameLeaders:"sports-game-leaders",SportsCountdown:"sports-countdown",SportsAugmentCard:"sports-augment-card",SportsSpotlightRace:"sports-spotlight-race",SportsSpotlightTennis:"sports-spotlight-tennis",SportsTennisMatch:"sports-tennis-match",SportsSpotlightGolf:"sports-spotlight-golf",SharedHeroNewsCard:"shared-hero-news-card",SportsSimpleMatch:"sports-simple-match",SportsStandingsRankings:"sports-standings-rankings",SportsMedal:"sports-medal",SportsMedalV2:"sports-medal-v2",SportsEventSchedule:"sports-event-schedule",SportsRecentMedal:"sports-recent-medal",SportsRubyPill:"sports-ruby-pill",SportsInfoList:"sports-info-list",SportsSpotlightCricket:"sports-spotlight-cricket",SportsSpotlightCricketV2:"sports-spotlight-cricket-v2",SportsPickWinner:"sports-pick-winner-wc",SportsMatchWithScores:"sports-match-with-scores",SportsSpotlight2c:"sports-spotlight-2c",SportsUpcomingMatches:"sports-upcoming-matches",SportsTournamentsList:"sports-tournaments-list",SportsTournamentStatusRow:"tournament-status-row"},P={TeamVsTeam:R.SportsMatchList,TeamVsTeamWithBracket:R.SportsMarchmadness,Standings:R.Standings,Articles:R.Articles,TeamVsTeamExploration:R.TeamExploration,EventBrief:R.SportsEventBrief,OneVsOneEventResult:R.SportsEventResults,OneVsManyEventResult:R.SportsEventResults,TeamVsTeamEventResult:R.SportsEventResults,TeamStandingWithEvents:R.SportsEventCountry,TeamStandingWithMedals:R.SportsEventCountry,CricketExploration:R.CricketExploration,TennisExploration:R.TennisExploration,Spotlight:R.SportsSpotlight,SpotlightFRE:R.SportsSpotlight,SpotlightRace:R.SportsSpotlightRace,SpotlightTennis:R.SportsSpotlightTennis,SpotlightGolf:R.SportsSpotlightGolf,StandingsRankings:R.SportsStandingsRankings,LeagueTodaysEvents:R.SportsEventSchedule,TeamStandings:R.SportsMedal,SpotlightCricket:R.SportsSpotlightCricket,TournamentsList:R.SportsTournamentsList,Spotlight2c:R.SportsSpotlight2c,AgentSpotlight:"AgentSpotlight"},H={SportsMatch:"SportsMatch",SportsTournamentStatusRow:"SportsTournamentStatusRow",EventSDCardSportsMIT1:"EventSDCardSportsMIT1",EventSDCardSportsMIT2:"EventSDCardSportsMIT2",EventSDCardSportsMIT3:"EventSDCardSportsMIT3",SportsSpans:"SportsSpans",SportsAugment:"SportsAugment",SportsHeroFre:"SportsHeroFre",SportsHeroLeagueTodaysEvents:"SportsHeroLeagueTodaysEvents",SportsHeroMatch1SeasonStats:"SportsHeroMatch1SeasonStats",SportsHeroMatch1Stats:"SportsHeroMatch1Stats",SportsHeroMatch2SeasonStats:"SportsHeroMatch2SeasonStats",SportsHeroMatch2Stats:"SportsHeroMatch2Stats",SportsHeroMatch3SeasonStats:"SportsHeroMatch3SeasonStats",SportsHeroMatch3Stats:"SportsHeroMatch3Stats",SportsHeroMatchStatistics:"SportsHeroMatchStatistics",SportsSpotlight2Match1:"SportsSpotlight2Match1",SportsSpotlight2Match2:"SportsSpotlight2Match2",SportsHeroNews:"SportsHeroNews",SportsHeroOneVsManyEventResult:"SportsHeroOneVsManyEventResult",SportsHeroOneVsOneEventResult:"SportsHeroOneVsOneEventResult",SportsMatchMiniWidget:"SportsMatchMiniWidget",SportsHeroSeasonStatistics:"SportsHeroSeasonStatistics",SportsHeroStandingsRankings:"SportsHeroStandingsRankings",SportsHeroTeamStandings:"SportsHeroTeamStandings",SportsHeroTeamStandingWithEvents:"SportsHeroTeamStandingWithEvents",SportsHeroTeamStandingWithMedals:"SportsHeroTeamStandingWithMedals",SportsHeroTeamVsTeam:"SportsHeroTeamVsTeam",SportsHeroTeamVsTeamEventResult:"SportsHeroTeamVsTeamEventResult",SportsHeroVideo:"SportsHeroVideo",SportsHeroMatchCard:"SportsHeroMatchCard"};var I;H.SportsMatch,H.EventSDCardSportsMIT1,H.EventSDCardSportsMIT2,H.EventSDCardSportsMIT3,H.SportsSpans,H.SportsAugment,function(t){t[t.entityViewMap=0]="entityViewMap",t[t.sportsConfig=1]="sportsConfig",t[t.sportsStrings=2]="sportsStrings",t[t.rootTelemetryObject=3]="rootTelemetryObject",t[t.sportsFeedDataParsed=4]="sportsFeedDataParsed"}(I||(I={})),(0,E.G)({getInstance(){return _.vv.get("sportsSpanStates",()=>new Map)}});var z=r(49150);class L extends z.GH{}class V extends z.GH{}class B extends z.GH{}const N=Object.freeze({SportsCard:"SportsCard",Game:"sports_game",Team:"sports_team",Vertical:"sports",DislikeSports:"HideSport",SportsSuggest:"suggestresult",SportsSuggestUrl:"suggesturl",FollowSports:"Follow",SportsFRE:"freexperience",FollowTeam:"follow_team",HeroGem:"HeroGem",SportsInfoSpotlight:"SportsInfoSpotlight",SportsDiscoverMore:"SportsDiscoverMore",ChangeLeagueTeam:"ChangeLeagueTeam",Feedback:"Feedback",PopupHideSport:"PopupHideSport",PopupHide:"popup_hide",PopupCancel:"popup_cancel",PopupClose:"popup_close",EventBriefClick:"event_brief",EventBriefContentClick:"EventBriefContent",MarchMadnessCard:"MarchMadnessCard",SportsArticle:"sports_article",SportsCarousel:"SportsCarousel",TeamVsTeam:"TeamVsTeam",ExplorationDislike:"ExplorationDislike",SportsTopSpan:"SportsTopSpan",SportsStickySpan:"SportsStickySpan",SportsTopSpanOverlay:"SportsTopSpanOverlay",SportsStickySpanOverlay:"SportsStickySpanOverlay",SeeDetails:"seedetails",SportsNotificationToast:"SportsNotificationToast",SportsNotificationToastLink:"SportsNotificationToastLink",SportsNotificationToastDismiss:"SportsNotificationToastDismiss",SportsNotificationToastYes:"SportsNotificationToastYes",SportsNotificationToastNo:"SportsNotificationToastNo",SportsAfterFollowDismiss:"SportsAfterFollowDismiss",SportsSpotlightVideo:"SpotlightVideo",Countdown:"Countdown",PinToDesk:"PinToDesk",Destination:"destination",Augment:"augment",SportsRubyClick:"SportsRubyClick",SportsSpotlightTennisCard:"SportsSpotlightTennisCard",SportsSpotlightRaceCard:"SportsSpotlightRaceCard",SportsSpotlightGolfCard:"SportsSpotlightGolfCard",SportsStandingsRankingsCard:"SportsStandingsRankingsCard",SportsStandingsRankingsTable:"SportsStandingsRankingsTable",SportsMedalCard:"SportsMedalCard",SportsAgentSpotlight:"SportsAgentSpotlight",SportsEventResults:"SportsEventResults",SportsEventScheduleCard:"SportsEventScheduleCard",SportsEventCountryCard:"SportsEventCountryCard",SportsSpotlightCricketCard:"SportsSpotlightCricketCard",SportsPickWinner:"SportsPickWinner",SportsSpotlightMatchCard2c:"SportsSpotlightMatchCard2c",SportsSpotlightScores2c:"SportsSpotlightScores2c",SportsUpcomingMatches2c:"SportsUpcomingMatches2c",SportsTournamentsListCard:"SportsTournamentsListCard",SportsInfoMiniWidget:"SportsInfoMiniWidget",SportsTournamentStatusRow:"SportsTournamentStatusRow"}),A=Object.freeze({ChannelStoreLaunched:"ChannelStoreLaunched",Badge:"SportsBadge",TaskbarRotation:"SportsTBR",SportsFrePresent:"SportsFrePresent",SportsTabType:"SportsTabType",SportsLeagueName:"SportsLeagueName",SportsDefaultLeagueShown:"SportsDefaultLeagueShown",SportsUserFollowsDefaultLeague:"SportsUserFollowsDefaultLeague",SportsUserFollowsOtherteams:"SportsUserFollowsOtherteams",SportsDropdownChangedLeague:"SportsDropdownChangedLeague",SportsUserFollowsDropdownChangedLeague:"SportsUserFollowsDropdownChangedLeague",SportsUserGroup:"SportsUserGroup",SportsExplorationReason:"SportsExplorationReason",SportsDropdownChangedViewShown:"SportsDropdownChangedViewShown",SportsCardeSize:"SportsCardeSize",SportsReasonShown:"SportsReasonShown",SportsRecommendationPopupShown:"SportsRecommendationPopupShown",SportsDfltRecoPopupShown:"SportsDefaultRecommendationPopupShown",SportsExplorationPopupShown:"SportsExplorationPopupShown",SportsUsabilityPopupShown:"SportsUsabilityPopupShown",SportsExplorationCardShown:"SportsExplorationCardShown",SportsEventBriefShown:"SportsEventBriefShown",SpotlightCardPreviewType:"SpotlightCardPreviewType",SpotlightCardEntityId:"SpotlightCardEntityId",SportsNewSpotlightCard:"SportsNewSpotlightCard",SportsCardType:"SportsCardType",SportsVideoSpotlightShown:"SportsVideoSpotlightShown",SportsNewSpotlightCountdown:"SportsNewSpotlightCountdown",SportsPinToDeskShown:"SportsPinToDeskShown",SportsDataV2:"SportsDataV2",SportsPinToDeskEdgeFeatureEnabled:"SportsPinToDeskEdgeFeatureEnabled",SportsNewSpotlightExploration:"SportsNewSpotlightExploration",SportsNewSpotlightTennis:"SportsNewSpotlightTennis",SportsNewSpotlightRace:"SportsNewSpotlightRace",SportsNewSpotlightGolf:"SportsNewSpotlightGolf",SportsCardCurrentTabId:"SportsCardCurrentTabId",SportsCardCopilotCurrentTabId:"SportsCardCopilotCurrentTabId",SportsStandingsRankings:"SportsStandingsRankings",SportsCardIsInViewPort:"SportsCardIsInViewPort",SportsNewSpotlightCricket:"SportsSpotlightCricket",SportsCardFirstTagName:"SportsCardFirstTagName",SportsRubyPillShown:"SportsRubyPillShown",SportsTournamentsList:"SportsTournamentsList"})},32954(t,e,r){r.r(e),r.d(e,{SportsCricket(){return z}});var o=r(56911),n=r(23587),i=r(92079),a=r(50180),s=r(54229);class l extends i.a{handleClickFollowIcon(t,e,r,o){if(t&&t.currentTarget){t.preventDefault(),t.stopPropagation();const n="keydown"===t.type||"keypress"===t.type||"keyup"===t.type;(0,s.LE)(t.currentTarget,n,e),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(r,e,o)}}getScoreClassName(t,e){var r;return(null===(r=this.viewModel.scoreClassNameMap)||void 0===r?void 0:r.get(`${t}${e.satoriId}`))||""}getScoreLineByIndex(t,e,r){const o=this.viewModel.scoresMap.get(`${t}${e.satoriId}`),n=o&&o.length>r?o[r]:void 0;return null==n?void 0:n.trim()}getMiddleTemplate(t){return t==n.Xp.preGame?"pre":t==n.Xp.postGame?"post":"live"}getMiddleTemplateClass(t){return t===n.Xp.superover?"state-top":t===n.Xp.postponed?"state-bottom":""}getParticipant(t,e){return this.viewModel.isRTL?t?e.participantTwo:e.participantOne:t?e.participantOne:e.participantTwo}getLiveText(t){var e;return t==n.Xp.inprogressGame?null===(e=this.viewModel.strings)||void 0===e?void 0:e.sportsLive:t}getFollowIconTitle(t,e){var r,o;return(0,a.GP)((e?null===(r=this.viewModel.strings)||void 0===r?void 0:r.followSports:null===(o=this.viewModel.strings)||void 0===o?void 0:o.haveFollowed)||"",t.name||"")}getGameTime(t){return(t.tvChannel?`${t.gameStartTime}, ${t.tvChannel}`:t.gameStartTime)||""}isScoreMultiLine(t,e){const r=this.viewModel.scoresMap.get(`${t}${e.satoriId}`);return!!r&&r.length>1}shouldRenderResults(t){return t!=n.Xp.preGame&&t!=n.Xp.toss}shouldShowSuperOver(t){return t===n.Xp.superover}shouldShowPostPoned(t){return t===n.Xp.postponed}}var p=r(92011),c=r(86856),d=r(12640),u=r(74849),h=r(22131),g=r(4968);const S=u.A` :host{--bg-color:rgba(255,255,255,0.06);--bg-color-hover:#3D3D3D}.match-content{color:#FFFFFF}.ipl-super-over{background:rgba(255,255,255,0.09)}.expl .ipl-super-over,.expl .detailed-game-state{background-color:rgba(255,255,255,0.3)}.cricket-final{color:#FFFFFF}.expl .cricket-final{background:rgba(255,255,255,0.3)}.winner-tag path{fill:#FFFFFF}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#0078d4}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.cricket-live-tag{background:rgba(36,214,87,1);color:#000000}.expl .cricket-live-tag{background-color:rgba(233,143,109)}.match-footer{color:#FFFFFF}.pin-to-desk-block{background:rgba(91,51,143,1);background-image:linear-gradient(45deg,rgb(255,0,165) 0,rgb(255,0,165) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgba(255,0,165,0.8) 87%,rgb(255,0,165) 100%);color:white}.pin-to-desk-button{border:1px solid white}.win-light{display:none}.win-dark{display:block}`,m=u.A`

`,f=u.A` .flip-h .follow-icon{float:left}.match-footer{right:calc(50% - 90px)}.pin-to-desk-button > img{margin-left:4px}`,v=u.A` :host{--participant-height:55px;--match-content-height:54px;--bg-color:rgba(255,255,255,0.5);--bg-color-hover:#F7F7F7}.match-data{text-align:center;align-items:center;display:grid;row-gap:4px;position:relative;height:100%}.match-content{background:var(--sports-item-background);display:flex;flex-direction:row;justify-content:space-between;align-items:center;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:#000000;width:268px;backdrop-filter:blur(6px);height:54px;${g.f}}.match-content:hover,.match-content:focus-visible{background:var(--sports-item-hover-background)}.match-content:active{background:var(--sports-item-active-background)}._1x_1y .match-content{height:var(--match-content-height)}._1x_1y .participant-container{height:var(--match-content-height)}._1x_1y .participant-container .follow-icon{top:-5px;right:-8px}._1x_3y .match-content{height:72px}._1x_3y .participant-content{height:100%}._1x_3y .participant-score span{margin-top:3px}._1x_3y .participant-score{margin-top:10px}:host([isMobile=true]) .match-content{width:100%}:host([cardlayout="_1x_1y"]) .match-content{padding:0}:host([isMobile=true]) .match-content{margin:0 auto;margin-bottom:8px}:host([isMobile=true]) .participant-container{padding:20px;box-sizing:border-box}:host([cardlayout="_1x_1y"]) .participant-container{max-height:70px}:host([isMobile=true]),:host([isMobile=true]) *:active,:host([isMobile=true]) *:hover{border:none;outline:none;box-shadow:none;text-decoration:none;-webkit-tap-highlight-color:transparent;-webkit-highlight:none}.participant-container{width:108px;max-width:132px;margin:0 0 0 13px;height:100%}.participant-container.flip-h{margin:0 13px 0 0}.results{display:flex}.flip-h .results{flex-flow:row-reverse}.single{align-items:center}.single .participant-score span.score-line1{margin:0 0 5px 0}.participant-info{display:flex;flex-direction:column;justify-content:center;align-items:center;position:relative}.participant-content{display:flex;column-gap:7px;height:var(--participant-height);position:relative}.flip-h .participant-content{flex-flow:row-reverse}.match-detail{height:var(--participant-height);display:flex;align-items:center}.ipl .match-detail.state-top{height:80px}._1x_1y .match-detail{height:var(--match-content-height)}.participant-icon{width:32px;height:auto;border-radius:8px}.participant-name{font-weight:600;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:80px;margin:0 auto}.participant-score span{overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);max-width:62px}.participant-score{max-height:36px;text-align:start;display:flex;flex-direction:column}.participant-score span.score-line1{margin-top:5px;font-size:14px;font-weight:600;line-height:18px}.flip-h .participant-score{text-align:end}.winner{font-weight:600}.winner-tag{position:absolute;height:100%;display:flex;align-items:center;left:-5px;margin-top:-8px;transform:scaleX(-1)}.flip-h .winner-tag{transform:scaleX(1);right:-5px;left:auto}.winner-tag > svg{fill:currentColor}.middle-detail{align-items:center;display:flex;flex-direction:column;direction:ltr}.game-detail{margin-top:-15px}.game-date{font-weight:600;font-size:14px;line-height:20px}.game-time{font-weight:400;font-size:12px;line-height:16px}.pre-game{width:120px}.cricket-live-tag{display:inline-block;background:rgb(7,148,48);color:rgb(255,255,255);font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-1-line-height,16px);height:16px;padding:1px 6px;margin:0;border-radius:3px;font-weight:600;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;text-transform:uppercase}.status-text{font-size:12px;line-height:14px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.ipl-super-over{background:rgba(255,255,255,0.4);display:flex;justify-content:center;align-items:center;border-radius:6px}.super-over-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0 4px 0 4px;font-size:10px;font-weight:400;line-height:14px}.state-top{flex-direction:column;justify-content:center}.state-top .middle-detail{flex:1;margin-top:15px}.state-bottom{flex-direction:column;justify-content:center;height:100%;margin-top:10px}.live-text{text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;margin-top:1px}.detail-live-animation{height:1px;transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate;background:white}@keyframes liveAnimation{0%{width:20px}100%{width:4px}}.match-extended-details{width:180px;text-align:center;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;padding:0px 10px;box-sizing:border-box}.match-footer{color:#1A1A1A;font-style:normal;font-weight:400;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);width:180px;display:inline-block;position:absolute;bottom:5px;left:calc(50% - 90px)}:host([cardlayout="_1x_1y"]) .match-footer{bottom:4px}.super-over-words{background:rgba(255,255,255,0.35);border-radius:3px;color:rgb(101,107,155);font-style:italic;font-weight:600;width:130px;height:30px;font-size:20px;transform:scale(0.5);line-height:14px;display:flex;align-items:center;justify-content:center;padding:0 3px 5px 0;box-sizing:border-box}.cricket-final{width:21px;height:21px;background:var(--sports-item-background);border-radius:21px;font-weight:400;font-size:10px;line-height:21px;color:#000000}.participant-hover{display:flex;align-items:center;justify-content:center;width:36px;height:28px}.ipl .participant-hover{border:0.5px solid rgba(186,186,186,0.22);border-radius:5px}.detail-live-animation .bottom-game-detail{line-height:14px}@keyframes liveAnimationCommon{0%{width:40px}100%{width:4px}}.participant-container .follow-icon{opacity:0;pointer-events:none;height:20px;position:absolute;bottom:35px;left:25px}.flip-h .follow-icon{float:right}.participant-container:hover .follow-icon,.match-content:focus-visible .follow-icon,.follow-icon:focus-visible{opacity:1;pointer-events:all}.match-content:focus-visible{outline-offset:-1px}._1x_1y.match-data:focus-visible{outline:none}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.pin-to-desk-block{background-color:rgb(255,241,250);background-image:linear-gradient(45deg,rgb(252,151,216) 0,rgb(252,151,216) 11%,transparent 11%),linear-gradient(45deg,transparent 87%,rgb(252,151,216) 87%,rgb(252,151,216) 100%);display:flex;flex-direction:column;justify-content:center;align-items:center;gap:6px;padding:6px 0;position:relative;border-radius:6px;text-decoration:none;color:black;width:268px;backdrop-filter:blur(6px);height:54px}.pin-to-desk-block:hover{cursor:pointer}.pin-to-desk-des,.pin-to-desk-button{font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;line-height:16px}.pin-to-desk-button{display:flex;height:28px;padding:2px 10px;justify-content:center;align-items:center;border-radius:100px;border:1px solid black}.pin-to-desk-button > img{margin-right:4px}.win-dark{display:none}._1x_1y .pin-to-desk-block{height:var(--match-content-height)}._1x_3y .pin-to-desk-block{height:72px}:host([isMobile=true]) .pin-to-desk-block{width:100%}:host([cardlayout="_1x_1y"]) .pin-to-desk-block{padding:0}:host([isMobile=true]) .pin-to-desk-block{margin:0 auto;margin-bottom:8px}.detailed-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);font-weight:600;padding:2px 6px;border-radius:3px;text-transform:uppercase;background:rgba(53,21,105,1)}.final-game-state{font-size:var(--type-ramp-minus-2-font-size,10px);padding:2px 6px;border-radius:3px;background:rgba(53,21,105,0.5)}.expl._1x_2y .match-content,.expl._1x_3y .match-content{box-sizing:border-box;height:66px}.expl._1x_3y{row-gap:6px}.expl._1x_3y .participant-score{margin-top:0px}.expl .match-content{box-sizing:border-box;height:66px;background-color:var(--bg-color)}.expl .match-content:hover{background-color:var(--bg-color-hover)}.expl .cricket-final{background:rgba(26,26,26,0.1)}.expl .cricket-live-tag{background-color:rgb(196,43,28)}.expl .ipl-super-over,.expl .detailed-game-state{background-color:rgba(26,26,26,0.1)}`.withBehaviors(new c.t(m,f),new d.N(null,S),(0,h.mr)(u.A` :host{forced-color-adjust:auto}`));var x=r(96950),b=r(69259),w=r(39957),y=r(10500),k=r(36516),T=r(58792);const C=x.qy`
    <img
        src="${()=>(0,T.rA)().StaticsUrl}latest/sports/icons/PinBlack.svg"
        class="win-light"
    >
    <img
        src="${()=>(0,T.rA)().StaticsUrl}latest/sports/icons/PinWhite.svg"
        class="win-dark"
    />
`,M=(t,e,r,o)=>x.qy`
<div class="participant-container${t=>e?"":" flip-h"}" title="${(null==r?void 0:r.name)||""}">
<div class="participant-content" index="-1">
            <div class="winner-tag">    
                ${(0,b.z)(t=>null==r?void 0:r.isWinner,x.qy`${x.qy.partial('<svg width="5" height="10" viewBox="0 0 5 10" fill="none"><path d="M5 0 0 5.22 5 10V0Z"/></svg>')}`)}
            </div>
            <div class="participant-info" index="-1">
                <div class="participant-hover">
                    <img class="participant-icon" role="presentation" src="${t=>r.imageUrl}"/>
                </div>
                <div class="participant-name">${(null==r?void 0:r.name)||""}</div>
                ${(t,e)=>{var o;return((t,e)=>x.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${(r,o)=>o.parent.getFollowIconTitle(t,e)}"
        @click="${(r,o)=>o.parent.handleClickFollowIcon(o.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:n.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||"")}"
        @keyup="${(r,o)=>o&&o.event&&"Enter"===o.event.key?o.parent.handleClickFollowIcon(o.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:n.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||""):null}"
        data-t="${(t,e)=>e.parent.viewModel.followTelemetryTag}"
    >
    <div class="${t=>e?"icon-add":"icon-selected"}"> ${x.qy.partial(e?k.A:y.A)}</div>
    </div>
`)(r||{},1!=(null===(o=e.parent.viewModel.followedMap)||void 0===o?void 0:o.get(r.satoriId)))}}
            </div>
            ${(0,b.z)((t,e)=>e.parent.shouldRenderResults(o),((t,e,r)=>x.qy`
    <div class="results ${(e,o)=>o.parent.getScoreLineByIndex(t,r,1)?"":"single"}">
        <div class="${(e,o)=>o.parent.getScoreClassName(t,r)}">
            <span class="score-line1">${(e,o)=>o.parent.getScoreLineByIndex(t,r,0)}</span>
            ${(0,b.z)((e,o)=>o.parent.isScoreMultiLine(t,r),x.qy`
                        <span>${(e,o)=>o.parent.getScoreLineByIndex(t,r,1)}</span>`)}
        </div>
    </div>
`)(t,0,r))}
        </div>
    </div>
`,$=x.qy`
    <div class="cricket-live-detail">
        ${(0,b.z)(t=>t.detailedGameState!=n.Xp.nonlive,x.qy`
            <div class="cricket-live-tag">
                <span class="live-text">${(t,e)=>e.parent.getLiveText(t.detailedGameState)}</span>
            </div>
        `)}
    </div>
`,E=x.qy`
    <div class="game-detail pre-game">
        <div class="game-date">
            ${t=>t.gameDate}
        </div>
        <div class="game-time">
            ${(t,e)=>e.parent.getGameTime(t)}
        </div>
    </div>
`,_=x.qy`
    <div class="game-detail post-game">
        <div class="game-state cricket-final">
            ${(t,e)=>{var r;return(null===(r=e.parent.viewModel.strings)||void 0===r?void 0:r.sportsVS)||"VS"}}
        </div>
    </div>
`,D=x.qy`
 <div class="middle-detail">
     ${(t,e)=>{switch(e.parent.getMiddleTemplate(t.detailedGameState)){case"pre":return E;case"post":return _;case"live":return $;default:return""}}}
 </div>
`,F=(x.qy`
<div class="detailed-game-state">
    ${t=>t.detailedGameState}
</div>
`,x.qy`
<div class="detailed-game-state">
    ${t=>n.Xp.postponed}
</div>
`,x.qy`
    <div class="match-detail ${(t,e)=>e.parent.getMiddleTemplateClass(t.detailedGameState)}">
        ${D}
    </div>
`),R=x.qy`  
    <a class="match-content"
        tabindex="0"
        href="${t=>t.matchClickthroughUrl?t.matchClickthroughUrl:void 0}"
        target="${(t,e)=>e.parent.viewModel.linkTarget}"
        data-t="${(t,e)=>e.parent.viewModel.telemetryTag}"
    >
        ${(t,e)=>M(t.gameId||"",!0,e.parent.getParticipant(!0,t)||{},t.detailedGameState)}
        ${F}
        ${(t,e)=>M(t.gameId||"",!1,e.parent.getParticipant(!1,t)||{},t.detailedGameState)}
        <div class="match-footer">${(t,e)=>{return r=e.parent.viewModel.matchSummaryMap.get(t.gameId),x.qy`
    <div>
        <div class="match-extended-details" title="${r||""}">
            ${r||""}
        </div>
    </div>
`;var r}}</div>
    </a>
`,P=x.qy`
    <a class="pin-to-desk-block"
        tabindex="0"
        role="button"
        @click="${t=>t.viewModel.pinToDeskClick&&t.viewModel.pinToDeskClick()}"
        data-t="${t=>t.viewModel.pinToDeskButtonTelemetryTag}"
    >
        <div class="pin-to-desk-des">
            ${t=>t.viewModel.strings.pinToDeskDesc||"Follow the latest games on desktop"}
        </div>
        <div class="pin-to-desk-button">
            ${C}${t=>t.viewModel.strings.pinToDeskButton||"Pin live score"}
        </div>
    </a>
`,H=x.qy`
    ${(0,b.z)(t=>t.viewModel.matchData.length>0,x.qy`
        <div class="match-data ${t=>t.viewModel.cardSize} ${t=>t.viewModel.isIPL?"ipl":""} ${t=>t.viewModel.isExploration?"expl":""}">
            ${(0,w.ux)(t=>t.viewModel.matchData.slice(0,t.viewModel.shouldShowPinToDesk?t.viewModel.showMatchCount-1:t.viewModel.showMatchCount),R,{positioning:!0})}
            ${(0,b.z)(t=>t.viewModel.shouldShowPinToDesk,P)}
        </div>`)}
`,I=x.qy`
    ${(0,b.z)(t=>null!=t.viewModel,H)}
`;let z=class extends l{};z=(0,o.Cg)([(0,p.E)({name:"sports-cricket",template:I,styles:v,shadowOptions:{delegatesFocus:!0}})],z)},36516(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},42792(t,e,r){r.d(e,{R7(){return S},e(){return h},kc(){return g},nH(){return u}});var o=r(57416),n=r(55153),i=r(95239),a=r(26920),s=r(48751),l=r(64187),p=r(22131),c=r(74849),d=r(50882);const u=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${i.p};
        outline: calc(${a.XA} * 1px) solid ${n.cu};
        border-radius: calc((${o.JU} - ${a.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${n.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${n.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${a.XA} * 1px) ${n.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${n.QG} * 1px);
        height: calc(${n.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${n.QG} * 1px);
        height: calc((${n.l8} * 2px) + (${n.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${n.QG} * 2px) + (${n.Sn} * 1px));
        height: calc((${n.l8} * 2px) + (${n.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${n.QG} * 2px) + (${n.Sn} * 1px));
        height: calc(${n.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,g=(0,p.mr)(c.A`
            :host {
                background: ${d.A.Canvas};
                color: ${d.A.CanvasText};
            }
        `),S=c.A`
    ${h}
    ${u}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(g)},49150(t,e,r){var o;r.d(e,{GH(){return s},uE(){return o},_n(){return n},iD(){return i},CE(){return a}}),function(t){t._1x_1y="_1x_1y",t._1x_2y="_1x_2y",t._1x_3y="_1x_3y",t._1x_4y="_1x_4y",t._1x_5y="_1x_5y",t._2x_1y="_2x_1y",t._2x_2y="_2x_2y",t._2x_3y="_2x_3y",t._2x_4y="_2x_4y",t._2x_6y="_2x_6y",t._3x_1y="_3x_1y",t._3x_2y="_3x_2y",t._4x_1y="_4x_1y",t._4x_2y="_4x_2y",t._5x_1y="_5x_1y",t._5x_2y="_5x_2y",t._125u="1.25u",t._15u="1.5u",t._05u="0.5u",t._2c="2c",t.pill="pill"}(o||(o={}));const n={DropdownRecommendation:"dropdown-recommendation",DefaultRecommendation:"default-recommendation",DefaultNotification:"default-notification",ExplorationTab:"exploration-tab",ExplorationReco:"exploration-recommendation",UsabilityFeedbackToast:"usability-feedback-toast"},i={dropdownHistory:"dropdownHistory",dismissHistory:"dismissHistory",suppressHistory:"suppressHistory",usefulTipHistoryYes:"usefulTipHistoryYes",usefulTipHistoryNo:"usefulTipHistoryNo",usefulTipHistoryDismiss:"usefulTipHistoryDismiss"};function a(t,e){return 0!==t&&["_1x_3y","_1x_1y"].includes(e)&&304===t}class s{constructor(t){this.transformerProvider=t}}},54229(t,e,r){r.d(e,{aC(){return f},YJ(){return i},x1(){return a},iJ(){return S},h9(){return m},LE(){return u},Eh(){return c},Ai(){return p},dI(){return d},j8(){return h},ao(){return g}});var o=r(85349),n=r(19359);const i={Customize:o.MS.Customize,Paginate:o.MS.Paginate,Hide:o.MS.Hide,Cancel:o.MS.Cancel,Close:o.MS.Close,Dislike:o.MS.Dislike,Show:o.MS.Show,Click:o.MS.Click};class a{createTelemetryObjectTag(t){return t?t.getMetadataTag():""}createTelemetryObject(t,e,r,i){if(!t||!e)return;const{name:a,content:s,...l}=e,p={...s,type:(null==s?void 0:s.type)||o.b5.StructuredData,vertical:this.verticalName,category:this.categoryName,subcategory:this.subCategoryName},c={...this.ext,signature:r};i&&(c.previewType=i);const d={...l,ext:c,zone:this.zone};return(0,n.g)(a,p,d)}createViewTelemetryObject(t,e){return this.createTelemetryObject(t,{name:e.name,action:o.EG.View,behavior:o.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType)}createViewTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,behavior:o.MS.View,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createNavClickTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:o.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createAddClickTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:o.MS.Add,type:o.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createHoverShowTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,action:o.EG.Hover,behavior:o.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createMouseLeaveCloseTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,action:o.EG.MouseLeave,behavior:o.MS.Close,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createDislikeActionTelemetryTag(t,e){const r=this.createTelemetryObject(t,{name:e.name,behavior:o.MS.Dislike,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(r)}createFollowTelemetryTag(t,e,r){const n=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:r?o.MS.Follow:o.MS.Unfollow,type:o.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createMenuDataProviderTelemetryTag(t,e,r){const n=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:o.MS.Undefined,type:o.MJ.ActionButton,content:{headline:e.headline},zone:r},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createNavClickWithTypeTelemetryTag(t,e,r){const n=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:o.MS.Navigate,type:r,content:{headline:e.headline,id:e.id,brandId:e.brandId,type:e.type||o.b5.StructuredData}},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createBehaviorTelemetryTag(t,e,r){const n=this.createTelemetryObject(t,{name:e.name,action:o.EG.Click,behavior:r,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(n)}createBaseContentCardTelemetryContext(t,e){const r=this.createTelemetryObject(t,{name:e.name,type:o.MJ.ContentCard,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType),n=this.createTelemetryObject(r,{name:e.name,type:o.MJ.Headline,behavior:o.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);if(r&&n)return{contentCard:r,destination:n}}initTelemetryBuilder(t,e,r,o,n){this.verticalName=t,this.categoryName=e,this.ext=r,this.zone=o,this.subCategoryName=n}updateExt(t){this.ext=t}}var s=r(77367),l=r(84742);function p(t){try{s.YT.sendActionEvent(t,o.EG.MouseLeave,o.MS.Close)}catch(t){return}}function c(t){try{s.YT.sendActionEvent(t,o.EG.Hover,o.MS.Show)}catch(t){return}}function d(t,e){try{s.YT.sendActionEvent(t,o.EG.Click,o.MS.Navigate,e)}catch(t){return}}function u(t,e,r){try{s.YT.sendActionEvent(t,e?o.EG.KeyPress:o.EG.Click,r?o.MS.Follow:o.MS.Unfollow)}catch(t){return}}function h(t){try{if(!t)throw new Error("Current target is undefined, cannot send content view telemetry.");s.YT.sendContentViewEvent(t,l.ym.View)}catch(t){return}}function g(t,e){const r=e?`${e}`:"";s.YT.addOrUpdateTmplProperty(t,r)}function S(t){s.YT.removeTmplProperty(t)}function m(t){for(const e of t)S(e)}var f,v=r(22341);!function(t){t.safeExecute=function(t,e,r,o,n){let i=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return t()}catch(t){return r&&(0,v.vV)(r,`${o}: ${null==t?void 0:t.message}`,n,i),e}},t.safeExecuteAsync=async function(t,e,r,o,n){let i=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return await t()}catch(t){return r&&(0,v.vV)(r,`${o}: ${null==t?void 0:t.message}`,n,i),Promise.resolve(e)}},t.logExceptionWithFormat=function(t,e,r,o,n){let i=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};(0,v.c_)(t,e,`${o}${o?": ":""}${r}`,n,i)},t.logErrorWithFormat=function(t,e,r,o){let n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:{};(0,v.vV)(t,`${r}${r?": ":""}${e}`,o,n)}}(f||(f={}))},73197(t,e,r){r.r(e),r.d(e,{SportsCricketTransformer(){return o.SportsCricketTransformer}});var o=r(22726);Promise.resolve().then(r.bind(r,32954))},79811(t,e,r){r.d(e,{AL(){return ct},B5(){return gt},CP(){return X},EZ(){return lt},F_(){return W},HX(){return T},Hn(){return J},Hv(){return P},IR(){return Q},K4(){return et},Lw(){return j},Ot(){return st},PH(){return St},UU(){return b},VQ(){return O},VY(){return K},Yf(){return E},Yo(){return tt},ZL(){return y},Zi(){return w},_K(){return H},_S(){return xt},bm(){return V},bw(){return A},d(){return vt},d$(){return k},gK(){return bt},gS(){return pt},iK(){return at},jJ(){return rt},ju(){return L},lb(){return G},m5(){return ht},nD(){return mt},or(){return U},p6(){return B},qM(){return z},ry(){return dt},s$(){return ot},sP(){return q},wB(){return I},ww(){return Y},yl(){return N},yn(){return ut},z2(){return F},zy(){return ft}});var o=r(23587),n=r(3083),i=r(85312),a=r(22341),s=r(80895),l=r(58792),p=r(90366),c=r(2827),d=r(42161),u=r(54229),h=r(49150),g=r(97266),S=r(50180),m=r(25109),f=r(26220),v=r(94016),x=r(52356);const b="OSC.LBUDD745586EC750353FBC1F3971212F2F92540502D2A29306D4081FAD3D5858B79B",w="#A71930",y="#036779",k="#B10E1C",T="#DC626D",C="sportshero",M="sportsspotlight2",$=[o.v1.TeamVsTeamExploration,o.v1.CricketExploration,o.v1.TennisExploration],E=t=>{if(t){return _(t)}return""},_=t=>t?(D(t)?t+="&h=50&w=50&m=6&q=100&u=t&o=t&l=f&f=png":t.indexOf("//www.bing.com/th?")>=0&&t.indexOf("&w=")>0&&(t=t.split("&w=")[0]+"&w=100&h=100&qlt=100&c=0&rs=1"),t):t,D=t=>["//img-s-msn-com.akamaized.net/tenant/amp/entityid","//img-s.msn.cn/tenant/amp/entityid"].some(e=>t.indexOf(e)>=0);function F(t){return null!=t}const R=t=>!t||!t.trim(),P=t=>H(t,80,80,!0),H=function(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"",e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:40,r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:40,o=arguments.length>3&&void 0!==arguments[3]&&arguments[3];return t?t.replace(/w=([\d]*)?&h=([\d]*)?/,`w=${o?r+20:r}&h=${o?e+20:e}`):null},I=t=>t.get(o.kA.sportsData),z=t=>{var e;const r=A(t);return u.aC.safeExecute(()=>{var t;return(null===(t=r.tabContent)||void 0===t||null===(t=t.league)||void 0===t||null===(t=t.sportsMatches)||void 0===t?void 0:t.map(t=>({sportsMatchData:t})))||[]},void 0,i.ON,`Sports V2 sportsMatches is not valid. sportsMatches=${JSON.stringify(null===(e=r.tabContent)||void 0===e||null===(e=e.league)||void 0===e?void 0:e.sportsMatches)}; tabType=${r.tabType};`)},L=t=>{var e;return null===(e=A(t).tabContent)||void 0===e||null===(e=e.freTeams)||void 0===e?void 0:e.map(t=>({...t,id:t.id||t.satoriId}))},V=t=>A(t).reason||"-1",B=t=>{var e;return null===(e=A(t).tabContent)||void 0===e?void 0:e.sportsSpotLightData},N=t=>t.get(o.kA.pollOptionId),A=t=>{var e;const r=I(t),o=q(t)-1;return null===(e=r.Model)||void 0===e?void 0:e.Tabs[o]},O=t=>Boolean(t)&&$.includes(t),G=t=>t===o.v1.Fre,W=t=>t===o.v1.SpotlightFRE,U=t=>t===o.v1.StandingsRankings,j=(t,e)=>{const r=t.get(o.kA.dislikedEntities);return null==r?void 0:r.has(e)},q=t=>t.get(o.kA.tabCurrentPageIndex)||1,Y=t=>{const e=A(t);return e?Z(e.tabType):o.v1.TeamVsTeam},Z=t=>{switch(t){case o.v1.TeamVsTeamExploration:case o.v1.CricketExploration:case o.v1.TennisExploration:case o.v1.EventBrief:case o.v1.TeamVsTeamWithBracket:case o.v1.SpotlightTennis:case o.v1.SpotlightRace:case o.v1.SpotlightGolf:case o.v1.SpotlightFRE:case o.v1.StandingsRankings:case o.v1.SportsMedal:case o.v1.LeagueEventResultOneVsOne:case o.v1.LeagueEventResultOneVsMany:case o.v1.LeagueEventResultTeamVsTeam:case o.v1.LeagueEvents:case o.v1.TeamStandingWithEvents:case o.v1.TeamStandingWithMedals:case o.v1.SpotlightCricket:case o.v1.TournamentsList:case o.v1.Spotlight2c:return t;case o.v1.SeasonStatistics:case o.v1.Video:case o.v1.Countdown:case o.v1.Spotlight:return o.v1.Spotlight;default:return o.v1.TeamVsTeam}};function J(t){return"boolean"==typeof t?t:!!t&&("1"===t||"true"===t.toLowerCase())}function X(t){switch(t){case h.uE._1x_1y:return"small";case h.uE._1x_3y:return"large";default:return"medium"}}const K=(t,e)=>void 0!==t&&void 0!==e&&(e.get(t)||!1),Q=(t,e,r)=>{switch(t){case h.uE._15u:case h.uE._1x_2y:return 3;case h.uE._1x_3y:return e===o.aB.Cricket?4:r;default:return 1}},tt=t=>t.some(t=>t&&t.sportsMatchData&&t.sportsMatchData.gameStateCatetory===o.Xp.inprogressGame),et=(t,e,r,o)=>{const n=o;return n&&n[r]&&n[r][e.toString()]?(0,S.GP)((t=>{let e=146;return t===h.uE._1x_2y?e=304:t===h.uE._1x_3y&&(e=462),`https://img-s-msn-com.akamaized.net/tenant/amp/entityid/{0}.img?w=300&h=${e}&q=90&m=6&f=jpg&u=t`})(r),n[r][e.toString()]):null},rt=()=>l.T3.AppType===v.u.BingHomepage?x.y.appInDarkMode():(null===s.F_||void 0===s.F_?void 0:s.F_.get(s.nz.IsDarkMode))??(0,m.ud)(),ot=(t,e,r,n)=>{const i=+t;if(!n||Number.isNaN(i)||i<0)return"";if(1===i)return r===o.XR.League?e.followedReasonLeague:e.followedReasonTeam;const a=o.IG[t];return a&&e[a]||""},nt="BB1dV8FG",it="MSports";function at(t){let e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],r=arguments.length>2?arguments[2]:void 0;const o={format:n.f5.PNG,enableDpiScaling:!1,crop:0,...r};return R(t)?e?(0,n.XP)(nt,o):null:t.indexOf(".")>0?(0,n.oQ)(`${n.Ro}?id=${t}&pid=${it}`,o):(0,n.XP)(t,o)}function st(t){if(null!=t&&t.startsWith("http"))return t;if(!t)return"";const e=(0,d.g2)((0,p.t7)(t));return(0,c.oh)()?function(t){if(!t)return t;try{const e=new URL((0,f.$N)()),r=new URL(t),o=e.searchParams.getAll("item").find(t=>t.startsWith("flights:"));return o&&r.searchParams.append("item",o),r.href}catch{return t}}(e):e}function lt(t,e){if(!t||!e)return t;try{const r=new URL(t),o=r.searchParams;return Object.keys(e).forEach(t=>{t&&e[t]&&o.set(t,e[t])}),r.toString()}catch{return t}}function pt(t){return t&&!t.startsWith("#")?`#${t}`:t}function ct(t,e){const r=new g.e;try{return r.localizedMonthDate(t,e)}catch(r){(0,a.vV)(i.Gu,"Sports card localizedMonthDate exception.",`date=${t} market=${e} error=${r&&r.message}`);let o=t.toLocaleDateString("en-us",{month:"short",day:"numeric"});return o||(o=t.toDateString()),o?o.replace(/\u200E/g,"").replace(/\u200F/g,""):o}}function dt(t,e){const r=new g.e;try{return r.formatTimeFromDate(t,e)}catch(r){return(0,a.vV)(i.Gu,"Sports card formatTimeFromDate exception.",`date=${t} market=${e} error=${r&&r.message}`),t.toTimeString()}}function ut(t){const e=60*(new Date).getTimezoneOffset()*1e3,r=new Date(t).valueOf();return new Date(r-e)}function ht(t){switch(t){case"PreGame":default:return o.Xp.preGame;case"InProgressGame":case"InProgress":return o.Xp.inprogressGame;case"Final":case"PostGame":return o.Xp.postGame}}function gt(t){var e;return"string"!=typeof t.gameState?ht(null===(e=t.gameState)||void 0===e?void 0:e.state):t.gameStateCatetory}function St(t){if(!t||"string"==typeof t)return"";const{gamePeriod:e,gameClock:r}=t;return e&&r?`${e} ${r}`:e||r||""}function mt(t){return!t||"object"==typeof t&&0===Object.keys(t).length}function ft(t){var e;return(null===(e=t.get(o.kA.cardType))||void 0===e?void 0:e.toLowerCase().startsWith(C))||!1}function vt(t){var e;return(null===(e=t.get(o.kA.cardType))||void 0===e?void 0:e.toLowerCase().startsWith(M))||!1}function xt(t,e){if(t.id&&e){const r=new URL(e);r.searchParams.append("videoId",t.id),e=r.toString()}return e}function bt(t,e){return!t.hasExplicitInterest||null!=e&&e.has(t.satoriId)||null!=e&&e.has(t.yId)?!0===(null==e?void 0:e.get(t.satoriId||""))||!0===(null==e?void 0:e.get(t.yId||"")):(null==e||e.set(t.satoriId,!0),!0)}},92079(t,e,r){r.d(e,{a(){return a}});var o=r(56911),n=r(92011),i=r(31525);let a=class extends n.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};a=(0,o.Cg)([i.x],a)},94016(t,e,r){var o,n;r.d(e,{u(){return o}}),function(t){t.BingHomepage="bingHomepage",t.ChannelMobile="channelmobile",t.Community="community",t.ContentTools="contentTools",t.EdgeChromium="edgeChromium",t.EdgeMobile="edgeMobile",t.Finance="finance",t.Gaming="gaming",t.CGHomePage="cgHomePage",t.CGSideBar="cgSideBar",t.HomePage="homePage",t.Hub="hub",t.Health="health",t.KnowledgeAgents="knowledgeAgents",t.Office="office",t.Personalize="personalize",t.qna="qna",t.msn="msn",t.MSNStudio="msnStudio",t.SharedWidgets="sharedWidgets",t.SuperApp="superApp",t.Shopping="shopping",t.Sports="sports",t.Distribution="distribution",t.Traffic="traffic",t.Travel="travel",t.UGC="ugc",t.Views="views",t.Weather="weather",t.WeatherWidgets="weatherWidgets",t.WeatherLocal="weatherLocal",t.Windows="windows",t.WindowsNewsPlus="windowsNewsPlus",t.WindowsNewsWidgets="winWidgets",t.WindowsShell="windowsShell",t.WindowsShellV2="windowsShellV2",t.WebWidgets="webWidgets"}(o||(o={})),function(t){t.Default="Default",t.WinDashboard="WinDashboard",t.Edge="Edge"}(n||(n={}))},99657(t,e,r){r.d(e,{D(){return a},I(){return i}});var o=r(45755);const{create:n}=o.G,i=n("sloppy-click-z-index",1),a=n("click-z-index",1)}}]);