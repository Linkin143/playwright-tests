// © Microsoft Corporation. All rights reserved.
import { RequestStorage } from "@cs-core/fast-ssr";
import { headData } from "@msnews/core";
import { initSignInStateIsValid } from "@msnews/auth";
import { patchPrefersColorThemeMediaQuery } from "@msnews/ssr-server-utils";
const moduleScopedElementDefinitions = new Map();
const noop = () => { };
export function patchDomShim(req, clientData, templateData, allowNoHeader) {
    var _a, _b;
    headData.initializeHeadData(clientData);
    initSignInStateIsValid();
    const window = RequestStorage.get("window");
    RequestStorage.set("elementDefinitions", moduleScopedElementDefinitions);
    // Required to be set for adding TTVR markers for SSR case
    window.isSSREnabled = true;
    // Required to be set for the nonce to be added to the script tags in the html template
    window.NONCE_ID = templateData.nonce;
    document.body = document.body || {};
    document.body.addEventListener = noop;
    document.dir = clientData.marketDir;
    const isLocalhost = window?.location?.host?.startsWith("localhost");
    if (allowNoHeader || isLocalhost) {
        (_a = req.headers)["sec-ch-viewport-width"] ?? (_a["sec-ch-viewport-width"] = "1920");
        (_b = req.headers)["sec-ch-prefers-color-scheme"] ?? (_b["sec-ch-prefers-color-scheme"] = "light");
    }
    const reqViewportWidth = parseInt(req?.headers?.["sec-ch-viewport-width"]);
    const reqViewportHeight = parseInt(req?.headers?.["sec-ch-viewport-height"]);
    const screenWidth = parseInt(req?.query?.["screenWidth"]);
    const screenHeight = parseInt(req?.query?.["screenHeight"]);
    const innerWidth = reqViewportWidth || screenWidth;
    if (!innerWidth) {
        // innerWidth is required for rendering as it will determine the column
        throw new Error("Viewport width is not set");
    }
    window.innerWidth = innerWidth;
    // innerHeight is not required for rendering
    window.innerHeight = reqViewportHeight || screenHeight || 950;
    const colorPreference = req.headers["sec-ch-prefers-color-scheme"];
    patchPrefersColorThemeMediaQuery(colorPreference);
    if (req.headers["referer"]) {
        window.document.referrer = req.headers["referer"];
    }
}
//# sourceMappingURL=patch-dom-shim.js.map