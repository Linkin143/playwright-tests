"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-cricket-v2"],{4968(e,r,t){t.d(r,{f(){return l}});var a=t(64187),i=t(74849),o=t(42792),n=t(99657),s=t(36452);const l=i.A.partial`position: relative; z-index: ${n.D};`;i.A`
    ${o.e}
    ${o.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},18614(e,r,t){t.r(r),t.d(r,{SportsCricketV2(){return j}});var a=t(56911),i=t(23587),o=t(92079);const n={preGame:{postponedStates:new Set([i.Xp.abandoned,i.Xp.postponed,i.Xp.delayed])},live:{liveTagStates:new Set([i.Xp.superover,i.Xp.inprogressGame,i.Xp.lunch,i.Xp.tea,i.Xp.dinner,i.Xp.drinks]),plainTextStates:new Set([i.Xp.stumps,i.Xp.abandoned,i.Xp.delayed])}};class s extends o.a{get gameStateCategoriesMap(){return n}getParticipant(e,r){return this.viewModel.isRTL?e?r.participantTwo:r.participantOne:e?r.participantOne:r.participantTwo}getLiveText(e){var r;return e==i.Xp.inprogressGame?null===(r=this.viewModel.strings)||void 0===r?void 0:r.sportsLive:e}getGameTime(e){return(e.tvChannel?`${e.gameStartTime}, ${e.tvChannel}`:e.gameStartTime)||""}isScoreMultiLine(e){var r,t;return Boolean((null===(r=e.inningsScore)||void 0===r?void 0:r.length)&&(null===(t=e.inningsScore)||void 0===t?void 0:t.length)>1||e.overs)}getRubyMiddleTemplate(e){return e===i.Xp.preGame?"pre":e===i.Xp.postGame?"post":"live"}getYetToBatClass(e){return e.yetToBat||e.notToBat?"r-to-bat":"score-line1"}showMatchNameInfo(e){return Boolean(this.viewModel.isRubySpotlight)&&Boolean(e.matchNameInfo)&&"0.5u"!==this.viewModel.cardSize}showVenueCityInfo(e){return Boolean(this.viewModel.isRubySpotlight)&&Boolean(e.venueCity)&&"0.5u"!==this.viewModel.cardSize}}var l=t(92011),c=t(86856),d=t(12640),p=t(74849),g=t(22131),h=t(4968);const u=p.A` :host{--bg-color:rgba(255,255,255,0.06);--bg-color-hover:#3D3D3D;--ruby-text-color:#D7DEEF;--ruby-grey-text-color:rgba(130,139,172,1);--ruby-live-text-bg:rgba(9,102,32,0.2);--ruby-live-text-color:rgba(108,197,123,1)}.r-winner-tag-icon{filter:invert(1) hue-rotate(45deg)}`,v=p.A`
`,f=p.A`
`,x=p.A` :host{--ruby-text-color:rgba(40,37,35,1);--ruby-grey-text-color:rgba(99,93,90,1);--ruby-live-text-bg:rgba(237,246,232,1);--ruby-live-text-color:rgba(0,127,48,1)}.match-data{text-align:center;align-items:center;display:grid;row-gap:0;position:relative;height:100%}.ruby-match-wrapper{text-decoration:none;padding:8px 0;color:var(--ruby-text-color);min-width:0px;${h.f}}.ruby-match-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;height:77px}.ruby-match-detail{flex:1;min-width:0px}.r-partcpnt-img img{width:40px}.r-partcpnt-name{font-size:15px;line-height:20px;font-weight:500}.r-pre-game .r-toss-state{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-base-line-height,16px);font-weight:500;color:rgba(0,127,48,1);text-transform:uppercase}.r-pre-game .r-post-poned-state{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-3-line-height,26px);font-weight:500;text-transform:uppercase}.r-game-date{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-base-line-height,16px);font-weight:400}.r-game-time{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-3-line-height,26px);font-weight:500}.ruby-spotlight .r-game-time{font-size:var(--type-ramp-plus-4-font-size,28px);line-height:var(--type-ramp-plus-3-line-height,32px)}.r-game-venue{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-plus-1-line-height,18px);color:var(--ruby-grey-text-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.r-middle-detail-score{display:flex;gap:12px;justify-content:center}.r-score .score-line1{display:flex;flex-direction:row-reverse;justify-content:start;align-items:center;gap:5px;font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-3-line-height,26px);font-weight:600;color:var(--ruby-text-color)}.r-score.left .score-line1{flex-direction:row;justify-content:end}.r-score .participant-score{font-size:12px;line-height:16px;color:var(--ruby-grey-text-color)}.r-score{font-size:12px;flex:1;position:relative}.r-score.left{text-align:right}.r-score.right{text-align:left}.r-post-game .r-score .loser,.r-post-game .loser .score-line1{color:var(--ruby-grey-text-color)}.r-participant-score{display:flex;flex-direction:column;font-variant-ligatures:none}.r-winner-tag{margin-top:-2px}.r-score.left .r-winner-tag{transform:scaleX(1)}.r-score.right .r-winner-tag{transform:scaleX(-1)}.r-winner-tag > svg{fill:currentColor}.r-live-tag{background:var(--ruby-live-text-bg,rgba(237,246,232,1));width:max-content;display:flex;align-items:center;justify-content:center;text-align:center;margin:auto;border-radius:8px;padding:3px 9px 3px 4px;font-size:12px;font-weight:600;margin-top:-10px}.r-live-text{color:var(--ruby-live-text-color,rgba(0,127,48,1));line-height:14px;text-transform:uppercase}.r-detailed-live-game-state{font-size:12px;line-height:16px;font-weight:500;text-transform:uppercase;margin-top:-10px}.r-detailed-live-game-state.stumps{color:var(--ruby-live-text-color,rgba(0,127,48,1))}.r-detailed-live-game-state.abandoned{color:var(--ruby-text-color)}.r-detailed-live-game-state.delayed,.r-post-poned-state.delayed{color:rgba(192,65,63,1)}.live-ping{position:relative;width:20px;height:20px}.live-ping::before{content:"";position:absolute;top:50%;left:50%;width:12px;height:12px;background-color:#007F30;opacity:0.2;border-radius:9999px;transform:translate(-50%,-50%);}.r-game-info{font-size:12px;line-height:16px;font-weight:400;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block;width:100%;max-width:270px;margin:0 auto 10px auto}.r-to-bat{color:var(--ruby-grey-text-color);line-height:28px;font-size:15px;padding-top:3px}@keyframes ping{0%{transform:translate(-50%,-50%) scale(1);opacity:0.6}75%{transform:translate(-50%,-50%) scale(1.50);opacity:0}100%{opacity:0}}`.withBehaviors(new c.t(v,f),new d.N(null,u),(0,g.mr)(p.A` :host{forced-color-adjust:auto}`));var b=t(96950),m=t(69259),y=t(39957),$=t(58792);const w=()=>`${(0,$.rA)().StaticsUrl}/latest/icons-wc/icons/sports/LiveIcon.svg`,k=(e,r)=>b.qy`
    <div class="r-partcpnt">
        <div class="r-partcpnt-img">
            <img role="presentation" src="${e=>r.imageUrl}"/>
        </div>
        <div class="r-partcpnt-name">${(e,t)=>r.name||""}</div>
    </div>
`,z=b.qy`
    <div class="r-pre-game">
        ${e=>e.detailedGameState===i.Xp.toss?b.qy`<div class="r-toss-state">
            ${e=>e.detailedGameState}
        </div>
        `:b.qy`<div class="r-game-date">
            ${e=>e.gameDate}
        </div>`}
        ${(e,r)=>r.parent.gameStateCategoriesMap.preGame.postponedStates.has(e.detailedGameState)?b.qy`<div class="r-post-poned-state ${e=>e.detailedGameState.toLowerCase()}">
                    ${e=>e.detailedGameState}
                </div>`:b.qy`
                <div class="r-game-time">
                    ${(e,r)=>r.parent.getGameTime(e)}
                </div>
            `}
        ${(0,m.z)((e,r)=>r.parent.showVenueCityInfo(e),b.qy`
            <div class="r-game-venue">
                ${e=>e.venueCity}
            </div>
        `)}
    </div>
`,S=(e,r,t)=>b.qy`
    <div class="r-participant-score ${e.isWinner?"":"loser"}">
        <div class="${(r,t)=>t.parent.getYetToBatClass(e)}">
            <div class="r-winner-tag">
                ${(0,m.z)(r=>null==e?void 0:e.isWinner,b.qy`<img src=${`${(0,$.rA)().StaticsUrl}/latest/icons-wc/icons/sports/WinnerTagIcon.svg`} alt="Winner Tag" class="r-winner-tag-icon">`)}
            </div>
            ${(r,t)=>t.parent.viewModel.getFirstScoreLine(e)}
        </div>
        ${(0,m.z)((r,t)=>t.parent.isScoreMultiLine(e),b.qy`
            <span>${(a,i)=>i.parent.viewModel.getSecondScoreLine(e,r,t)}</span>
        `)}
    </div>
`,M=function(){let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];return b.qy`
<div class="r-middle-detail-score">
    <div class="r-score left">
    ${(r,t)=>{const a=t.parent.getParticipant(!0,r);return a?S(a,e,r.detailedGameState):""}}
    </div>
    <div class="r-score right">
    ${(r,t)=>{const a=t.parent.getParticipant(!1,r);return a?S(a,e,r.detailedGameState):""}}
    </div>
</div>
`},D=b.qy`
    <div class="r-post-game">
        <div class="r-game-date">
            ${e=>e.gameDate}
        </div>
        ${M(!0)}
    </div>
`,T=b.qy`
    <div class="r-live-game">
    ${(e,r)=>r.parent.gameStateCategoriesMap.live.liveTagStates.has(e.detailedGameState)?b.qy`<div class="r-live-tag">
                <span class="live-ping"><img src=${w} /></span> <span class="r-live-text">${(e,r)=>r.parent.getLiveText(e.detailedGameState)}</span>
            </div>`:r.parent.gameStateCategoriesMap.live.plainTextStates.has(e.detailedGameState)?b.qy`
                <div class="r-detailed-live-game-state ${e=>e.detailedGameState.toLowerCase()}">
                    ${e=>e.detailedGameState}
                </div>
            `:void 0}
    ${M()}
    </div>
`,I=b.qy`
 <div class="ruby-middle-detail">
     ${(e,r)=>{switch(r.parent.getRubyMiddleTemplate(e.gameStateCatetory)){case"pre":return z;case"post":return D;case"live":return T;default:return""}}}
 </div>
`,_=b.qy`
    <div class="ruby-match-detail">
        ${I}
    </div>
`,B=b.qy`
    <a class="ruby-match-wrapper"
        tabindex="0"
        href="${e=>e.matchClickthroughUrl?e.matchClickthroughUrl:void 0}"
        target="${(e,r)=>r.parent.viewModel.linkTarget}"
        data-t="${(e,r)=>r.parent.viewModel.telemetryTag}"
    >
        ${(0,m.z)((e,r)=>r.parent.showMatchNameInfo(e),b.qy`<div class="r-game-info">${e=>e.matchNameInfo}</div>`)}
        <div class="ruby-match-content">
            ${(e,r)=>k(0,r.parent.getParticipant(!0,e)||{})}
            ${_}
            ${(e,r)=>k(0,r.parent.getParticipant(!1,e)||{})}
        </div>
    </a>
`,C=b.qy`
    ${(0,m.z)(e=>e.viewModel.matchData.length>0,b.qy`
        <div class="match-data ${e=>e.viewModel.isRubySpotlight?"ruby-spotlight":""}">
            ${(0,y.ux)(e=>e.viewModel.matchData,B,{positioning:!0})}
        </div>`)}
`,P=b.qy`
    ${e=>e.viewModel?b.qy`${C}`:b.qy`<div></div>`}
`;let j=class extends s{};j=(0,a.Cg)([(0,l.E)({name:"sports-cricket-v2",template:P,styles:x,shadowOptions:{delegatesFocus:!0}})],j)},42792(e,r,t){t.d(r,{R7(){return v},e(){return h},kc(){return u},nH(){return g}});var a=t(57416),i=t(55153),o=t(95239),n=t(26920),s=t(48751),l=t(64187),c=t(22131),d=t(74849),p=t(50882);const g=d.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=d.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${n.XA} * 1px) solid ${i.cu};
        border-radius: calc((${a.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${i.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${i.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${i.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${i.QG} * 1px);
        height: calc(${i.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${i.QG} * 1px);
        height: calc((${i.l8} * 2px) + (${i.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${i.QG} * 2px) + (${i.Sn} * 1px));
        height: calc((${i.l8} * 2px) + (${i.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${i.QG} * 2px) + (${i.Sn} * 1px));
        height: calc(${i.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,c.mr)(d.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),v=d.A`
    ${h}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},58142(e,r,t){t.d(r,{U(){return l}});var a=t(49150),i=t(23587),o=t(79811),n=t(58792),s=t(96950);class l extends i.Bc{constructor(){super(...arguments),this.getShowMatchCount=e=>e===a.uE._15u?3:1,this.getGameDate=e=>{const r=new Date,t=new Date(e);if(r.toDateString()===t.toDateString())return this.transformerProvider.strings.today;return t.toLocaleDateString(n.T3.CurrentMarket,{weekday:"short",day:"numeric",month:"long"})},this.getFirstScoreLine=e=>{var r,t;if(e.yetToBat)return null===(r=this.transformerProvider.strings)||void 0===r?void 0:r.yetToBat;if(e.notToBat)return null===(t=this.transformerProvider.strings)||void 0===t?void 0:t.didNotBat;const a=e.inningsScore||[];return a.length>0?a[0]:""},this.getSecondScoreLine=(e,r,t)=>{const{inningsScore:a=[],overs:o,target:n,targetOver:s}=e;return r&&t===i.Xp.superover&&a.length>0?`${a[1]?a[1]:""} (SO)`:n&&s&&o&&a.length>0?`(${s}/${o}) T:${n}`:2===a.length?o?`${a[1]} (${o})`:a[1]:1===a.length&&o?`(${o})`:a.length>1?a[1]:""}}async transform(e){const r=await this.getViewModel(e);return{viewTemplate:s.qy`
                <sports-cricket-v2
                    :viewModel="${r}"
                ></sports-cricket-v2>`}}async getViewModel(e){const{cardSize:r}=e,t=this.getShowMatchCount(r),a=this.getMatchData(e,t),n={...e.telemetryConstants,name:i.BP.Game};return{cardSize:r,isRubySpotlight:e.isRubySpotlight,linkTarget:"_blank",matchData:a.matches,isDarkMode:(0,o.jJ)(),strings:{...this.transformerProvider.strings},telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,n),getFirstScoreLine:this.getFirstScoreLine,getSecondScoreLine:this.getSecondScoreLine}}getMatchData(e,r){var t;const a=(null===(t=e.matchData)||void 0===t?void 0:t.map(e=>null==e?void 0:e.sportsMatchData).slice(0,r))||[],s=e.followedSports||new Map,l=new Map,c=new Map,d=new Map;return a.forEach(e=>{if(e){var r;const t=e.participantOne||{},a=e.participantTwo||{},l=(0,o.yn)(e.gameStartDateTime);e.gameStartTime=(e.gameStartDateTimeIsToBeAnnounced?null:(0,o.ry)(l,n.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA;const c="string"!=typeof e.gameState?(0,o.m5)(e.gameState.state):e.gameStateCatetory,p=e.gameState&&"string"!=typeof e.gameState?this.getDetailedGameStatus(null===(r=e.gameState)||void 0===r?void 0:r.detailedGameState):e.detailedGameState;e.detailedGameState=p!==i.Xp.nonlive?p:c;let g="";g=p&&p!==i.Xp.nonlive?p:c===i.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:c,e.gameStateCatetory=c,e.gameState=g,t.imageUrl=this.getParticipantIconUrl(t.imageUrl||(0,o.iK)(t.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced)||""),a.imageUrl=this.getParticipantIconUrl(a.imageUrl||(0,o.iK)(a.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced)||""),t.gameCenterUrl&&(t.scheduleUrl=(0,o.Ot)(t.gameCenterUrl)),a.gameCenterUrl&&(a.scheduleUrl=(0,o.Ot)(a.gameCenterUrl)),e.gameCenterUrl&&!e.matchClickthroughUrl&&(e.matchClickthroughUrl=(0,o.Ot)(e.gameCenterUrl)),e.gameDate=this.getGameDate(l.toString()||""),e.gameStateCatetory=e.cricketGameCategory||e.gameStateCatetory,(0,o.gK)(t,s)&&d.set(t.satoriId,!0),(0,o.gK)(a,s)&&d.set(a.satoriId,!0)}}),{matches:a,scoreClassNameMap:l,matchSummaryMap:c,followedMap:d}}getParticipantIconUrl(e){return null==e?void 0:e.replace(/w=([\d]*)?&h=([\d]*)?/,"w=72&h=72")}getDetailedGameStatus(e){switch(e){case"InProgressGame":case"InProgress":return i.Xp.inprogressGame;case"Drinks":return i.Xp.drinks;case"Dinner":return i.Xp.dinner;case"Tea":return i.Xp.tea;case"Lunch":return i.Xp.lunch;case"Fog":return i.Xp.fog;case"Innings":return i.Xp.innings;case"Stumps":return i.Xp.stumps;case"InningsBreak":return i.Xp.break;case"Toss":return i.Xp.toss;case"SuperOver":return i.Xp.superover;case"BadWeatherCondition":return i.Xp.BadWeatherCondition;case"PreGame":return i.Xp.preGame;case"Final":case"PostGame":return i.Xp.postGame;case"Delayed":return i.Xp.delayed;case"Abandoned":return i.Xp.abandoned;case"Postponed":return i.Xp.postponed;default:return i.Xp.nonlive}}}},81821(e,r,t){t.r(r),t.d(r,{SportsCricketV2Transformer(){return a.U}});var a=t(58142);Promise.resolve().then(t.bind(t,18614))},92079(e,r,t){t.d(r,{a(){return n}});var a=t(56911),i=t(92011),o=t(31525);let n=class extends i.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,a.Cg)([o.x],n)},99657(e,r,t){t.d(r,{D(){return n},I(){return o}});var a=t(45755);const{create:i}=a.G,o=i("sloppy-click-z-index",1),n=i("click-z-index",1)}}]);