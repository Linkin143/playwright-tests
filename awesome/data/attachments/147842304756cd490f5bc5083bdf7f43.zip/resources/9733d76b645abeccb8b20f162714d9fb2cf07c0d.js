"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["feedDependencies"],{3641(t,o,l){l.d(o,{v(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy,C1:C.uE._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_halfy,C4:C.uE._2x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy,C1:C.uE._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy,C1:C.uE._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:s}},12814(t,o,l){l.d(o,{m(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3],C2:[1,3],C1:[1,3]}}],styles:s}},16127(t,o,l){l.d(o,{AnaheimLayoutTemplateMap(){return CC}});var C=l(33477),s=l(74849);const e=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot7"
        "slot4 slot5 slot6 slot7"
        "slot8 slot9 slot10 slot11"
        "slot8 slot9 slot10 slot11";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot2 slot4 slot7"
        "slot2 slot4 slot7"
        "slot6 slot5 slot11"
        "slot6 slot5 slot11"
        "slot8 slot9 slot10"
        "slot8 slot9 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot4 slot7"
        "slot4 slot7"
        "slot5 slot11"
        "slot5 slot11"
        "slot6 slot8"
        "slot6 slot8"
        "slot9 slot10"
        "slot9 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11";
}
`.withBehaviors(),r={cardCount:11,rowHeightPx:{C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(22)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:3,C2:2},telemetryRowCol:{C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:2,C2:3},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:4,C2:4},telemetryRowCol:{C4:[3,1],C3:[3,2],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:7,C2:6},telemetryRowCol:{C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:6,C2:8},telemetryRowCol:{C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:5,C2:5},telemetryRowCol:{C4:[3,4],C3:[3,3],C2:[5,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:9,C2:9},telemetryRowCol:{C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:10,C2:10},telemetryRowCol:{C4:[5,2],C3:[7,2],C2:[11,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:11,C2:11},telemetryRowCol:{C4:[5,3],C3:[7,3],C2:[11,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:8,C2:7},telemetryRowCol:{C4:[5,4],C3:[5,3],C2:[7,2],C1:[21,1]}}],styles:e},a=s.A`
    :host([layout="C5"]) {
        grid-template-areas:
            "slot1 slot1 slot2 slot3 slot4"
            "slot1 slot1 slot2 slot3 slot4"
            "slot5 slot6 slot7 slot7 slot8"
            "slot5 slot6 slot7 slot7 slot8";
    }

    :host([layout="C4"]) {
        grid-template-areas:
            "slot1 slot1 slot2 slot3"
            "slot1 slot1 slot2 slot3"
            "slot4 slot5 slot6 slot6"
            "slot4 slot5 slot6 slot6";
    }

    :host([layout="C3"]) {
        grid-template-areas:
            "slot1 slot1 slot2"
            "slot1 slot1 slot2"
            "slot3 slot4 slot5"
            "slot3 slot4 slot5";
    }

    :host([layout="C2"]) {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot2 slot3"
            "slot2 slot3";
    }

    :host([layout="C1"]) {
        grid-template-areas:
            "slot1"
            "slot1"
            "slot2"
            "slot2";
    }
`.withBehaviors(),d=(0,C.P)(2),y={colWidthPx:C.f1,gutterPx:C.iw,styles:a},m=[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y}}],i=t=>{const o={},l=[];for(let C=1;C<=t;C++){const t=`C${C}`;o[t]=d;for(let o=1;o<=m.length;o++){const C=m[o-1];if(C.layouts[t]){let s=l[o-1];if(!s){const{layouts:t,...o}=C;s={...o,layouts:{}},l.push(s)}s.layouts[t]=C.layouts[t]}}}return{...y,cardCount:l.length,rowHeightPx:o,cardSlots:l}};var g=l(74050),u=l(69721),c=l(72547),w=l(54267),_=l(42411),h=l(64865),R=l(68683),D=l(56614),O=l(36271),p=l(40094),n=l(12814),x=l(3641),P=l(93833),f=l(90773),v=l(69827);const H=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot5 slot3 slot2 slot4"
        "slot1 slot5 slot3 slot2 slot4"
        "slot6 slot6 slot7 slot7 slot8"
        "slot6 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot3 slot5 slot8"
        "slot3 slot5 slot8"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot6"
        "slot6 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),S={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:H,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[3,1],C3:[3,2],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,1],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[9,2],C1:[15,1]}}]},W=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot5 slot3 slot2 slot4"
        "slot1 slot5 slot3 slot2 slot4"
        "slot6 slot6 slot7 slot8 slot8"
        "slot6 slot6 slot7 slot8 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot3 slot5 slot8"
        "slot3 slot5 slot8"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot6"
        "slot6 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),b={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:W,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[3,1],C3:[3,2],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,1],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[9,2],C1:[15,1]}}]},k=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot4"
        "slot1 slot2 slot3 slot3 slot4"
        "slot5 slot5 slot7 slot6 slot8"
        "slot5 slot5 slot7 slot6 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot7 slot5 slot6 slot8"
        "slot7 slot5 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot4"
        "slot1 slot3 slot4"
        "slot2 slot5 slot5"
        "slot2 slot5 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot3 slot3"
        "slot3 slot3"
        "slot6 slot2"
        "slot6 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),T={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:k,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:4,C2:5,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[3,1],C2:[5,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:3,C3:2,C2:3,C1:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:4,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:6,C3:5,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:6,C2:4,C1:6},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,1],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:5,C3:7,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,1],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},$=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot4"
        "slot1 slot2 slot3 slot3 slot4"
        "slot5 slot5 slot6 slot7 slot8"
        "slot5 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot6 slot5 slot7 slot8"
        "slot6 slot5 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot4"
        "slot1 slot3 slot4"
        "slot2 slot5 slot5"
        "slot2 slot5 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot3 slot3"
        "slot3 slot3"
        "slot6 slot2"
        "slot6 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),F={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:$,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:4,C2:5},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[3,1],C2:[5,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:5,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:6,C2:4},telemetryRowCol:{C5:[3,3],C4:[3,1],C3:[5,1],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:7,C2:7},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:8,C2:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},E=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot2 slot1 slot3 slot3 slot4"
        "slot2 slot1 slot3 slot3 slot4"
        "slot5 slot5 slot6 slot7 slot8"
        "slot5 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot3 slot4"
        "slot2 slot1 slot3 slot4"
        "slot6 slot5 slot7 slot8"
        "slot6 slot5 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot4"
        "slot1 slot3 slot4"
        "slot2 slot5 slot5"
        "slot2 slot5 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot3 slot3"
        "slot3 slot3"
        "slot6 slot2"
        "slot6 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),X={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:E,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:4,C2:5,C1:2},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[3,1],C2:[5,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:3,C3:2,C2:3,C1:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:4,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:6,C3:5,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:5,C3:6,C2:4,C1:6},telemetryRowCol:{C5:[3,3],C4:[3,1],C3:[5,1],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:7,C2:7,C1:7},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},A=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3 slot4"
        "slot1 slot2 slot3 slot3 slot4"
        "slot5 slot5 slot6 slot7 slot8"
        "slot5 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot6 slot5 slot7 slot8"
        "slot6 slot5 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot3 slot5 slot5"
        "slot3 slot5 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot3 slot3"
        "slot3 slot3"
        "slot6 slot2"
        "slot6 slot2"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),L={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:A,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:2,C2:5},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[5,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:4,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:5,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:6,C2:4},telemetryRowCol:{C5:[3,3],C4:[3,1],C3:[5,1],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:7,C2:7},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:8,C2:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},j=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot3"
        "slot1 slot1 slot2 slot3 slot3"
        "slot4 slot5 slot6 slot7 slot8"
        "slot4 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot3 slot3"
        "slot1 slot1 slot3 slot3"
        "slot4 slot2 slot6 slot6"
        "slot4 slot2 slot6 slot6"
        "slot7 slot7 slot5 slot8"
        "slot7 slot7 slot5 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot4 slot2 slot8"
        "slot4 slot2 slot8"
        "slot5 slot6 slot7"
        "slot5 slot6 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot3 slot6"
        "slot3 slot6"
        "slot2 slot8"
        "slot2 slot8"
        "slot4 slot5"
        "slot4 slot5"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),M={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,3],C4:[3,2],C3:[3,2],C2:[5,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:2,C2:2},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:3,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:7,C2:3},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[3,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:j},Q=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot2"
        "slot1 slot1 slot2 slot2"
        "slot5 slot3 slot4 slot4"
        "slot5 slot3 slot4 slot4"
        "slot7 slot7 slot6 slot8"
        "slot7 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot5 slot3 slot8"
        "slot5 slot3 slot8"
        "slot6 slot4 slot7"
        "slot6 slot4 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),Z={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:2,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:7,C2:3},telemetryRowCol:{C5:[1,5],C4:[3,3],C3:[5,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:3,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:Q},q=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3"
        "slot1 slot1 slot2 slot2 slot3"
        "slot4 slot5 slot6 slot7 slot8"
        "slot4 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot4 slot3"
        "slot1 slot1 slot4 slot3"
        "slot2 slot2 slot5 slot5"
        "slot2 slot2 slot5 slot5"
        "slot7 slot7 slot6 slot8"
        "slot7 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot2 slot5 slot8"
        "slot2 slot5 slot8"
        "slot4 slot6 slot7"
        "slot4 slot6 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot5 slot8"
        "slot5 slot8"
        "slot4 slot6"
        "slot4 slot6"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),z={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[3,1],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:6,C2:6},telemetryRowCol:{C5:[3,1],C4:[1,3],C3:[5,1],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:7,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,2],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:q},B=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot3 slot8"
        "slot5 slot3 slot3 slot8"
        "slot6 slot6 slot7 slot7"
        "slot6 slot6 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot5 slot6 slot7"
        "slot5 slot6 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),G={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:6,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:7,C3:7,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,2],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:8,C3:8,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:6,C3:5,C2:5,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:B},I=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot4"
        "slot1 slot2 slot3 slot4 slot4"
        "slot5 slot5 slot6 slot7 slot8"
        "slot5 slot5 slot6 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot5 slot4"
        "slot3 slot5 slot4"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot4"
        "slot6 slot4"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),J={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:I,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:2,C2:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:3,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:5,C2:6},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[3,3],C2:[7,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:4,C2:4},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:6,C2:5},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:7,C2:7},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:8,C2:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},K=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot3 slot4"
        "slot2 slot1 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot4"
        "slot2 slot1 slot4"
        "slot3 slot7 slot7"
        "slot3 slot7 slot7"
        "slot5 slot6 slot8"
        "slot5 slot6 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot4"
        "slot2 slot4"
        "slot1 slot1"
        "slot1 slot1"
        "slot5 slot3"
        "slot5 slot3"
        "slot7 slot7"
        "slot7 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),N={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:K,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:2,C3:2,C2:3,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,2],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:1,C3:1,C2:1,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,1],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:3,C3:4,C2:5,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[5,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:4,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:5,C3:6,C2:4,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:5,C2:6,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[3,2],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},U=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot8"
        "slot5 slot6 slot7 slot8 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot7 slot6 slot8"
        "slot5 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot5 slot4"
        "slot3 slot5 slot4"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot4"
        "slot6 slot4"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),V={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:U,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:2,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:3,C2:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:5,C2:6},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[7,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:4,C2:4},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:6,C2:5},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},Y=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot8"
        "slot5 slot6 slot7 slot8 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot5 slot4"
        "slot3 slot5 slot4"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot4"
        "slot6 slot4"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),tt={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:Y,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:2,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:3,C2:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:5,C2:6},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[7,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:4,C2:4},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:6,C2:5},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:7,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},ot=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot3 slot7 slot7"
        "slot3 slot7 slot7"
        "slot5 slot6 slot8"
        "slot5 slot6 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot2 slot2"
        "slot2 slot2"
        "slot5 slot3"
        "slot5 slot3"
        "slot7 slot7"
        "slot7 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),lt={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:ot,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:3,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:3,C3:4,C2:5,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[5,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:4,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:5,C3:6,C2:4,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:5,C2:6,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[3,2],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}]},Ct=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot3 slot4"
        "slot1 slot1 slot3 slot4"
        "slot5 slot6 slot2 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot5 slot3 slot8"
        "slot5 slot3 slot8"
        "slot6 slot2 slot7"
        "slot6 slot2 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot5 slot4"
        "slot5 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot2 slot6"
        "slot2 slot6"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),st={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,styles:Ct,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:6,C3:7,C2:6,C1:2},telemetryRowCol:{C5:[1,3],C4:[3,3],C3:[5,2],C2:[7,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:2,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:2,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:5,C3:6,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:8,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[4,3],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:5,C2:5,C1:8},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[15,1]}}]},et=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot8"
        "slot5 slot6 slot7 slot8 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot6 slot7 slot8"
        "slot6 slot7 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot4 slot4"
        "slot4 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),rt={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,2],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[5,3],C2:[9,2],C1:[15,1]}}],styles:et},at=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot7 slot6 slot5 slot5 slot8"
        "slot7 slot6 slot5 slot5 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot8"
        "slot3 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot6 slot5 slot7"
        "slot6 slot5 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot7"
        "slot6 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),dt={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,1],C4:[4,2],C3:[5,3],C2:[9,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:at},yt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot8"
        "slot3 slot7 slot6 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot6 slot5 slot7"
        "slot6 slot5 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot5"
        "slot5 slot5"
        "slot6 slot7"
        "slot6 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),mt={cardCount:8,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,3],C4:[4,2],C3:[5,3],C2:[9,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[15,1]}}],styles:yt},it=s.A`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3"
        "slot5 slot2"
        "slot5 slot2"
        "slot4 slot6"
        "slot4 slot6"
        "slot8 slot7"
        "slot8 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8";
}
`.withBehaviors(),gt={cardCount:8,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(8),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:2,C2:4},telemetryRowCol:{C4:[1,2],C3:[1,3],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:3,C2:2},telemetryRowCol:{C4:[1,3],C3:[3,1],C2:[1,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:5},telemetryRowCol:{C4:[1,4],C3:[3,2],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:5,C2:3},telemetryRowCol:{C4:[3,1],C3:[3,3],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:6},telemetryRowCol:{C4:[3,2],C3:[5,2],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:6,C2:8},telemetryRowCol:{C4:[3,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:8,C2:7},telemetryRowCol:{C4:[3,4],C3:[5,3],C2:[7,1],C1:[15,1]}}],styles:it},ut=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot15 slot7 slot16 slot9"
        "slot10 slot11 slot12 slot13 slot14"
        "slot10 slot17 slot18 slot13 slot14";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot16"
        "slot5 slot3 slot15 slot16"
        "slot17 slot8 slot7 slot9"
        "slot18 slot8 slot7 slot9"
        "slot10 slot13 slot11 slot14"
        "slot10 slot13 slot12 slot14";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot16"
        "slot7 slot15 slot16"
        "slot17 slot8 slot5"
        "slot18 slot8 slot5"
        "slot11 slot11 slot10"
        "slot11 slot11 slot10"
        "slot12 slot13 slot14"
        "slot12 slot13 slot14";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot15 slot16"
        "slot17 slot11"
        "slot18 slot11"
        "slot10 slot14"
        "slot10 slot14"
        "slot12 slot13"
        "slot12 slot13";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot15"
        "slot7"
        "slot7"
        "slot8"
        "slot16"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot17"
        "slot12"
        "slot18"
        "slot13"
        "slot13"
        "slot14"
        "slot14";
}
`.withBehaviors(),ct={cardCount:18,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(12),C2:(0,C.P)(16),C1:(0,C.P)(28)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:12,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:11,C3:6,C2:7,C1:8},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:8,C4:10,C3:11,C2:9,C1:9},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:12,C3:5,C2:5,C1:11},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:12,C4:14,C3:15,C2:15,C1:12},telemetryRowCol:{C5:[5,1],C4:[7,1],C3:[9,3],C2:[13,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_1y},cardDomOrder:{C5:13,C4:16,C3:14,C2:13,C1:13},telemetryRowCol:{C5:[5,2],C4:[7,3],C3:[9,1],C2:[11,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_1y},cardDomOrder:{C5:14,C4:18,C3:16,C2:17,C1:15},telemetryRowCol:{C5:[5,3],C4:[8,3],C3:[11,1],C2:[15,1],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:15,C4:15,C3:17,C2:18,C1:17},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[11,2],C2:[15,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:16,C4:17,C3:18,C2:16,C1:18},telemetryRowCol:{C5:[5,5],C4:[7,4],C3:[11,3],C2:[13,2],C1:[27,1]}},{grid_area:"slot15",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:10,C4:8,C3:9,C2:10,C1:7},telemetryRowCol:{C5:[4,2],C4:[4,3],C3:[6,2],C2:[10,1],C1:[12,1]}},{grid_area:"slot16",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:11,C4:7,C3:8,C2:11,C1:10},telemetryRowCol:{C5:[4,4],C4:[3,4],C3:[5,3],C2:[10,2],C1:[16,1]}},{grid_area:"slot17",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:17,C4:9,C3:10,C2:12,C1:14},telemetryRowCol:{C5:[6,2],C4:[5,1],C3:[7,1],C2:[11,1],C1:[22,1]}},{grid_area:"slot18",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:18,C4:13,C3:13,C2:14,C1:16},telemetryRowCol:{C5:[6,3],C4:[6,1],C3:[8,1],C2:[12,1],C1:[24,1]}}],styles:ut},wt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot11 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot9"
        "slot5 slot3 slot6 slot9"
        "slot7 slot10 slot8 slot11"
        "slot7 slot10 slot8 slot11";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8"
        "slot10 slot11 slot5"
        "slot10 slot11 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8"
        "slot10 slot11"
        "slot10 slot11";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11";
}
`.withBehaviors(),_t={cardCount:11,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(22)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:11,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:10,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[5,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:12,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:9,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,2],C3:[7,1],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:11,C3:10,C2:11,C1:11},telemetryRowCol:{C5:[4,2],C4:[5,4],C3:[7,2],C2:[11,2],C1:[21,1]}}],styles:wt},ht=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot11 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot9"
        "slot5 slot3 slot6 slot9"
        "slot8 slot10 slot7 slot11"
        "slot8 slot10 slot7 slot11";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8"
        "slot10 slot11 slot5"
        "slot10 slot11 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8"
        "slot10 slot11"
        "slot10 slot11";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11";
}
`.withBehaviors(),Rt={cardCount:11,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(22)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:11,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:10,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:8,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:11,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:9,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,2],C3:[7,1],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:11,C3:10,C2:11,C1:11},telemetryRowCol:{C5:[4,2],C4:[5,4],C3:[7,2],C2:[11,2],C1:[21,1]}}],styles:ht},Dt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot11 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot8"
        "slot5 slot3 slot6 slot8"
        "slot10 slot11 slot7 slot9"
        "slot10 slot11 slot7 slot9";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot7 slot6 slot9"
        "slot7 slot6 slot9"
        "slot10 slot11 slot5"
        "slot10 slot11 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8"
        "slot10 slot11"
        "slot10 slot11";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11";
}
`.withBehaviors(),Ot={cardCount:11,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(22)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:11,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:10,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:7,C3:5,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[3,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:11,C4:11,C3:8,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[5,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:8,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,1],C3:[7,1],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:9,C3:10,C2:11,C1:11},telemetryRowCol:{C5:[4,2],C4:[5,2],C3:[7,2],C2:[11,2],C1:[21,1]}}],styles:Dt},pt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9"
        "slot10 slot10 slot11 slot12 slot13"
        "slot10 slot10 slot11 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot7 slot3 slot9"
        "slot5 slot7 slot3 slot9"
        "slot6 slot6 slot8 slot13"
        "slot6 slot6 slot8 slot13"
        "slot12 slot11 slot10 slot10"
        "slot12 slot11 slot10 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot5 slot2 slot9"
        "slot5 slot2 slot9"
        "slot3 slot7 slot13"
        "slot3 slot7 slot13"
        "slot6 slot6 slot8"
        "slot6 slot6 slot8"
        "slot10 slot11 slot12"
        "slot10 slot11 slot12";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot13"
        "slot5 slot13"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot10"
        "slot8 slot10"
        "slot11 slot12"
        "slot11 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),nt={cardCount:13,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(14),C1:(0,C.P)(26)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:4,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:6,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[5,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:9,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[7,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:7,C2:9},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,2],C2:[9,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[7,3],C2:[11,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:13,C3:11,C2:11},telemetryRowCol:{C5:[5,1],C4:[7,3],C3:[9,1],C2:[11,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:12,C3:12,C2:12},telemetryRowCol:{C5:[5,3],C4:[7,2],C3:[9,2],C2:[13,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:11,C3:13,C2:13},telemetryRowCol:{C5:[5,4],C4:[7,1],C3:[9,3],C2:[13,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:8,C2:7},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[7,2],C1:[25,1]}}],styles:pt},xt=s.A`

:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot4 slot2 slot5"
        "slot1 slot4 slot3 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot2 slot1"
        "slot2 slot2 slot1"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot2"
        "slot2 slot2"
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5";
}
`.withBehaviors(),Pt={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(4),C2:(0,C.P)(6),C1:(0,C.P)(10)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:2,C2:2},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,3],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:1,C2:1},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:4},telemetryRowCol:{C5:[1,3],C4:[2,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:4,C2:5},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[3,2],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:5,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[3,2],C1:[9,1]}}],styles:xt},ft=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot4"
        "slot3 slot4 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4";
}
`.withBehaviors(),vt={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(4),C2:(0,C.P)(4),C1:(0,C.P)(8)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,3],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,2],C2:[3,2],C1:[7,1]}}],styles:ft},Ht=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot3 slot2 slot2"
        "slot3 slot2 slot2";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4";
}
`.withBehaviors(),St={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(4),C2:(0,C.P)(4),C1:(0,C.P)(8)},colWidthPx:C.f1,gutterPx:C.iw,styles:Ht,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:4},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[3,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}}]},Wt=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot6 slot7 slot8 slot9"
        "slot6 slot6 slot7 slot8 slot9"
        "slot10 slot11 slot12 slot13 slot14"
        "slot10 slot11 slot12 slot13 slot14";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot4 slot2 slot5"
        "slot1 slot4 slot2 slot5"
        "slot3 slot3 slot6 slot9"
        "slot3 slot3 slot6 slot9"
        "slot7 slot8 slot10 slot14"
        "slot7 slot8 slot10 slot14"
        "slot11 slot12 slot13 slot13"
        "slot11 slot12 slot13 slot13";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot9"
        "slot3 slot4 slot9"
        "slot6 slot7 slot14"
        "slot6 slot7 slot14"
        "slot8 slot8 slot10"
        "slot8 slot8 slot10"
        "slot11 slot12 slot13"
        "slot11 slot12 slot13";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot9"
        "slot2 slot9"
        "slot3 slot14"
        "slot3 slot14"
        "slot4 slot6"
        "slot4 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot10 slot11"
        "slot10 slot11"
        "slot12 slot13"
        "slot12 slot13";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14";
}
`.withBehaviors(),bt={cardCount:14,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(14),C1:(0,C.P)(28)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:4,C2:5},telemetryRowCol:{C5:[1,3],C4:[3,1],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:5,C2:7},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[3,2],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:8},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:8,C2:9},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:11,C2:11},telemetryRowCol:{C5:[5,1],C4:[5,3],C3:[7,3],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:12,C3:12,C2:12},telemetryRowCol:{C5:[5,2],C4:[7,1],C3:[9,1],C2:[11,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:13,C3:13,C2:13},telemetryRowCol:{C5:[5,3],C4:[7,2],C3:[9,2],C2:[13,1],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:14,C3:14,C2:14},telemetryRowCol:{C5:[5,4],C4:[7,3],C3:[9,3],C2:[13,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:11,C3:9,C2:6},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[5,2],C1:[27,1]}}],styles:Wt},kt=s.A`
:host {
    grid-template-areas:
        "slot2 slot3 slot6 slot4 slot5"
        "slot2 slot3 slot6 slot4 slot5"
        "slot1 slot1 slot7 slot10 slot9"
        "slot1 slot1 slot7 slot10 slot9"
        "slot8 slot11 slot12 slot13 slot14"
        "slot8 slot11 slot12 slot13 slot14";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot4 slot3 slot5"
        "slot2 slot4 slot3 slot5"
        "slot1 slot1 slot6 slot9"
        "slot1 slot1 slot6 slot9"
        "slot8 slot10 slot12 slot14"
        "slot8 slot10 slot12 slot14"
        "slot11 slot13 slot7 slot7"
        "slot11 slot13 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot9"
        "slot3 slot4 slot9"
        "slot6 slot7 slot14"
        "slot6 slot7 slot14"
        "slot8 slot8 slot10"
        "slot8 slot8 slot10"
        "slot11 slot12 slot13"
        "slot11 slot12 slot13";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot9"
        "slot2 slot9"
        "slot3 slot14"
        "slot3 slot14"
        "slot4 slot6"
        "slot4 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot10 slot11"
        "slot10 slot11"
        "slot12 slot13"
        "slot12 slot13";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14";
}
`.withBehaviors(),Tt={cardCount:14,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(14),C1:(0,C.P)(28)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:5,C3:1,C2:1},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:2,C2:3},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:3,C3:4,C2:5},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:2,C3:5,C2:7},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[3,2],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:6,C3:7,C2:8},telemetryRowCol:{C5:[1,3],C4:[3,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:14,C3:8,C2:9},telemetryRowCol:{C5:[3,3],C4:[7,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:8,C3:10,C2:10},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:7,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:9,C3:11,C2:11},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,3],C2:[11,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:11,C4:12,C3:12,C2:12},telemetryRowCol:{C5:[5,2],C4:[7,1],C3:[9,1],C2:[11,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:12,C4:10,C3:13,C2:13},telemetryRowCol:{C5:[5,3],C4:[5,3],C3:[9,2],C2:[13,1],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:13,C4:13,C3:14,C2:14},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,3],C2:[13,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:14,C4:11,C3:9,C2:6},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[5,2],C1:[27,1]}}],styles:kt},$t=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1 slot1";
    grid-auto-rows: auto !important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1"
        "slot1 slot1 slot1 slot1";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot1"
        "slot1 slot1 slot1";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
`.withBehaviors(),Ft={cardCount:1,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._5x_2y,C4:C.uE._4x_2y,C3:C.uE._3x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:$t},Et=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot4 slot3"
        "slot1 slot1 slot2 slot4 slot3"
        "slot5 slot8 slot6 slot7 slot9"
        "slot5 slot8 slot6 slot7 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot5 slot4 slot6 slot6"
        "slot5 slot4 slot6 slot6"
        "slot7 slot7 slot8 slot9"
        "slot7 slot7 slot8 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot4 slot2 slot9"
        "slot4 slot2 slot9"
        "slot6 slot6 slot8"
        "slot6 slot6 slot8"
        "slot5 slot7 slot7"
        "slot5 slot7 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot4 slot5"
        "slot4 slot5"
        "slot6 slot6"
        "slot6 slot6"
        "slot8 slot9"
        "slot8 slot9"
        "slot7 slot7"
        "slot7 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),Xt={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,1],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,1],C2:[5,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,2],C2:[11,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,3],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[9,2],C1:[17,1]}}],styles:Et},At=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot4 slot3"
        "slot1 slot2 slot2 slot4 slot3"
        "slot5 slot8 slot6 slot7 slot9"
        "slot5 slot8 slot6 slot7 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3"
        "slot5 slot5 slot6 slot6"
        "slot5 slot5 slot6 slot6"
        "slot4 slot7 slot8 slot9"
        "slot4 slot7 slot8 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6"
        "slot7 slot8 slot9"
        "slot7 slot8 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot5"
        "slot5 slot5"
        "slot7 slot8"
        "slot7 slot8"
        "slot6 slot9"
        "slot6 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),Lt={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:2,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:3,C2:3,C1:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:6,C3:4,C2:4,C1:4},telemetryRowCol:{C5:[1,4],C4:[5,1],C3:[3,1],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:5,C2:5,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:5,C3:6,C2:8,C1:6},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[3,3],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:7,C3:7,C2:6,C1:7},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[5,1],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:8,C3:8,C2:7,C1:8},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,2],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:9,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[5,3],C2:[9,2],C1:[17,1]}}],styles:At},jt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot3 slot4"
        "slot1 slot1 slot3 slot4"
        "slot5 slot2 slot6 slot6"
        "slot5 slot2 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),Mt={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:5,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[3,2],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:2,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:9,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:7,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:jt},Qt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot3 slot2 slot4"
        "slot1 slot1 slot3 slot2 slot4"
        "slot5 slot6 slot8 slot7 slot9"
        "slot5 slot6 slot8 slot7 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot6"
        "slot5 slot3 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),Zt={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,3],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:9,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:Qt},qt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot6"
        "slot5 slot3 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),zt={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:9,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:6,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:8,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:qt},Bt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot7 slot6 slot8 slot9"
        "slot5 slot7 slot6 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot6"
        "slot3 slot5 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),Gt={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:4,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:5,C3:9,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:7,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:Bt},It=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot7 slot6 slot6"
        "slot5 slot7 slot6 slot6"
        "slot8 slot8 slot3 slot9"
        "slot8 slot8 slot3 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot5"
        "slot8 slot8 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),Jt={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[5,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:9,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:6,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:8,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:It},Kt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot8 slot3 slot9"
        "slot5 slot8 slot3 slot9"
        "slot6 slot6 slot7 slot7"
        "slot6 slot6 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot5 slot8 slot6"
        "slot5 slot8 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),Nt={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:6,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:8,C2:7},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,3],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:9,C2:8},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[6,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:7,C2:9},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[5,2],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:Kt},Ut=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot8 slot7 slot7"
        "slot5 slot8 slot7 slot7"
        "slot6 slot6 slot3 slot9"
        "slot6 slot6 slot3 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot5 slot8 slot6"
        "slot5 slot8 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),Vt={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:8,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[5,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:6,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:7,C3:8,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,3],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:6,C3:9,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[6,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:5,C3:7,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[5,2],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:Ut},Yt=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot5 slot7 slot8 slot8"
        "slot5 slot7 slot8 slot8"
        "slot9 slot9 slot6 slot4"
        "slot9 slot9 slot6 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot5 slot7 slot3"
        "slot5 slot7 slot3"
        "slot6 slot8 slot8"
        "slot6 slot8 slot8"
        "slot9 slot9 slot4"
        "slot9 slot9 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot5 slot2"
        "slot5 slot2"
        "slot7 slot3"
        "slot7 slot3"
        "slot8 slot6"
        "slot8 slot6"
        "slot9 slot4"
        "slot9 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),to={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:2,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:5,C2:5},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[3,3],C2:[5,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[1,5],C4:[5,4],C3:[7,3],C2:[9,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[3,2],C2:[5,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:6},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,2],C2:[7,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:8,C2:8},telemetryRowCol:{C5:[3,5],C4:[5,1],C3:[7,1],C2:[9,1],C1:[17,1]}}],styles:Yt},oo=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot2"
        "slot1 slot1 slot2 slot2"
        "slot5 slot3 slot4 slot4"
        "slot5 slot3 slot4 slot4"
        "slot6 slot8 slot7 slot9"
        "slot6 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot5"
        "slot1 slot1 slot5"
        "slot3 slot2 slot2"
        "slot3 slot2 slot2"
        "slot4 slot4 slot7"
        "slot4 slot4 slot7"
        "slot6 slot8 slot9"
        "slot6 slot8 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot5 slot2"
        "slot5 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),lo={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:4,C2:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,2],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:5,C2:5},telemetryRowCol:{C5:[1,5],C4:[3,3],C3:[5,1],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:2},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[1,3],C2:[3,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:6},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[7,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:6,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:8,C2:8},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[7,3],C2:[9,2],C1:[17,1]}}],styles:oo},Co=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot7 slot7 slot8 slot8"
        "slot7 slot7 slot8 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot7"
        "slot6 slot5 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),so={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:6,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:8,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[6,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:Co},eo=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot9"
        "slot5 slot6 slot7 slot7 slot9";
}

:host([layout="C5"]) fluent-card[style*="grid-area:slot8"] {
    display: none;
}

:host([layout="C5"]) msft-article-card[style*="grid-area:slot8"] {
    display: none;
}

:host([layout="C5"]) cs-article-card[style*="grid-area:slot8"] {
    display: none;
}

:host([layout="C5"]) [class="card-container"][style*="grid-area:slot8"] {
    display: none;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot7 slot7 slot8 slot8"
        "slot7 slot7 slot8 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot7"
        "slot6 slot5 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),ro={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:6,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:8,C3:8,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:9},telemetryRowCol:{C4:[5,3],C3:[6,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:eo},ao=s.A`
:host {
    grid-template-areas:
        "slot2 slot3 slot5 slot8 slot4"
        "slot2 slot3 slot5 slot8 slot4"
        "slot1 slot1 slot7 slot6 slot9"
        "slot1 slot1 slot7 slot6 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot8 slot8 slot4"
        "slot2 slot8 slot8 slot4"
        "slot1 slot1 slot3 slot6"
        "slot1 slot1 slot3 slot6"
        "slot7 slot5 slot5 slot9"
        "slot7 slot5 slot5 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot3 slot4"
        "slot2 slot3 slot4"
        "slot1 slot1 slot9"
        "slot1 slot1 slot9"
        "slot7 slot5 slot5"
        "slot7 slot5 slot5"
        "slot8 slot8 slot6"
        "slot8 slot8 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot4"
        "slot2 slot4"
        "slot1 slot1"
        "slot1 slot1"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot2"
        "slot2"
        "slot1"
        "slot1"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),yo={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:4,C3:4,C2:3,C1:2},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:5,C3:2,C2:4,C1:3},telemetryRowCol:{C5:[1,2],C4:[3,3],C3:[1,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:3,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:8,C3:7,C2:6,C1:5},telemetryRowCol:{C5:[1,3],C4:[5,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:6,C3:9,C2:8,C1:6},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[7,3],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:2,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:ao},mo=s.A`
:host {
    grid-template-areas:
        "slot2 slot8 slot5 slot3 slot4"
        "slot2 slot8 slot5 slot3 slot4"
        "slot1 slot1 slot7 slot6 slot9"
        "slot1 slot1 slot7 slot6 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot8 slot8 slot4"
        "slot2 slot8 slot8 slot4"
        "slot1 slot1 slot3 slot6"
        "slot1 slot1 slot3 slot6"
        "slot7 slot5 slot5 slot9"
        "slot7 slot5 slot5 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot3 slot4"
        "slot2 slot3 slot4"
        "slot1 slot1 slot9"
        "slot1 slot1 slot9"
        "slot7 slot5 slot5"
        "slot7 slot5 slot5"
        "slot8 slot8 slot6"
        "slot8 slot8 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot4"
        "slot2 slot4"
        "slot1 slot1"
        "slot1 slot1"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot2"
        "slot2"
        "slot1"
        "slot1"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),io={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:4,C3:4,C2:3,C1:2},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:5,C3:2,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[1,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:3,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:8,C3:7,C2:6,C1:5},telemetryRowCol:{C5:[1,3],C4:[5,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:6,C3:9,C2:8,C1:6},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[7,3],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:mo},go=s.A`
:host {
    grid-template-areas:
        "slot2 slot1 slot1 slot3 slot4"
        "slot2 slot1 slot1 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot1 slot4"
        "slot2 slot1 slot1 slot4"
        "slot5 slot3 slot6 slot6"
        "slot5 slot3 slot6 slot6"
        "slot8 slot8 slot7 slot9"
        "slot8 slot8 slot7 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot1"
        "slot2 slot1 slot1"
        "slot5 slot3 slot4"
        "slot5 slot3 slot4"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot8 slot9"
        "slot8 slot8 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),uo={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:1},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:2},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:5,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:8,C3:6,C2:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:7,C3:8,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:5},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[7,3],C2:[5,2],C1:[17,1]}}],styles:go},co=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot7 slot7 slot8 slot8"
        "slot7 slot7 slot8 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot7"
        "slot6 slot5 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9";
}
`.withBehaviors(),wo={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:8,C2:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,3],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[6,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}}],styles:co},_o=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot2 slot1 slot9"
        "slot2 slot2 slot1 slot9"
        "slot3 slot4 slot6 slot6"
        "slot3 slot4 slot6 slot6"
        "slot5 slot7 slot7 slot8"
        "slot5 slot7 slot7 slot8";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot3"
        "slot2 slot1 slot3"
        "slot4 slot5 slot5"
        "slot4 slot5 slot5"
        "slot6 slot6 slot9"
        "slot6 slot6 slot9"
        "slot8 slot7 slot7"
        "slot8 slot7 slot7";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3"
        "slot2 slot2"
        "slot2 slot2"
        "slot4 slot6"
        "slot4 slot6"
        "slot7 slot5"
        "slot7 slot5"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot9"
        "slot9"
        "slot8"
        "slot8";
}
`.withBehaviors(),ho={cardCount:9,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(18)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:2,C3:2,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,3],C3:[1,2],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:1,C3:1,C2:3,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,1],C3:[1,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:4,C3:3,C2:2,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[1,3],C2:[1,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:5,C3:4,C2:4,C1:4},telemetryRowCol:{C5:[1,5],C4:[3,2],C3:[3,1],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:7,C3:5,C2:7,C1:5},telemetryRowCol:{C5:[3,1],C4:[5,1],C3:[3,2],C2:[7,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:6,C2:5,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:8,C3:9,C2:6,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[7,2],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:9,C3:8,C2:8,C1:9},telemetryRowCol:{C5:[3,4],C4:[5,4],C3:[7,1],C2:[9,1],C1:[17,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:3,C3:7,C2:9,C1:8},telemetryRowCol:{C5:[3,5],C4:[1,4],C3:[5,3],C2:[9,2],C1:[15,1]}}],styles:_o},Ro=s.A`
:host {
    grid-template-areas:
        "slot1 slot3 slot3 slot2 slot4"
        "slot1 slot3 slot3 slot2 slot4"
        "slot1 slot6 slot5 slot5 slot7"
        "slot1 slot6 slot5 slot5 slot7";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot1 slot5 slot6 slot7"
        "slot1 slot5 slot6 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot4"
        "slot1 slot2 slot4"
        "slot1 slot3 slot7"
        "slot1 slot3 slot7"
        "slot6 slot5 slot5"
        "slot6 slot5 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot1 slot3"
        "slot1 slot3"
        "slot5 slot4"
        "slot5 slot4"
        "slot6 slot7"
        "slot6 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7";
}
`.withBehaviors(),Do={cardCount:7,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(8),C1:(0,C.P)(16)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_4y,C4:C.uE._1x_4y,C3:C.uE._1x_4y,C2:C.uE._1x_4y,C1:C.uE._1x_4y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,4],C4:[1,2],C3:[1,2],C2:[1,2],C1:[5,1]}},{grid_area:"slot3",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[3,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:4,C3:7,C2:6},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[5,2],C1:[9,1]}},{grid_area:"slot5",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:5,C3:5,C2:5},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,2],C2:[5,1],C1:[11,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:4,C2:4},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[7,1],C1:[13,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:6,C2:7},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[7,2],C1:[15,1]}}],styles:Ro},Oo=s.A`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot7"
        "slot4 slot5 slot6 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot4 slot3 slot5"
        "slot4 slot3 slot5"
        "slot7 slot7 slot6"
        "slot7 slot7 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot6 slot5"
        "slot6 slot5"
        "slot4 slot7"
        "slot4 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7";
}
`.withBehaviors(),po={cardCount:7,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(8),C1:(0,C.P)(14)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:2,C2:2},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:4,C2:3},telemetryRowCol:{C4:[1,4],C3:[3,2],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:6},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:5,C2:5},telemetryRowCol:{C4:[3,2],C3:[3,3],C2:[5,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:4},telemetryRowCol:{C4:[3,3],C3:[5,3],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C4:[3,4],C3:[5,1],C2:[7,2],C1:[13,1]}}],styles:Oo},no=s.A`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot7"
        "slot4 slot5 slot6 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot3"
        "slot1 slot1 slot3"
        "slot2 slot6 slot5"
        "slot2 slot6 slot5"
        "slot7 slot7 slot4"
        "slot7 slot7 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot6 slot5"
        "slot6 slot5"
        "slot4 slot7"
        "slot4 slot7";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7";
}
`.withBehaviors(),xo={cardCount:7,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(6),C2:(0,C.P)(8),C1:(0,C.P)(14)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:7,C2:6},telemetryRowCol:{C4:[3,1],C3:[5,3],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:5,C2:5},telemetryRowCol:{C4:[3,2],C3:[3,3],C2:[5,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:4,C2:4},telemetryRowCol:{C4:[3,3],C3:[3,2],C2:[5,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:6,C2:7},telemetryRowCol:{C4:[3,4],C3:[5,1],C2:[7,2],C1:[13,1]}}],styles:no},Po=s.A`
:host {
    grid-template-areas:
    "slot1 slot1 slot2 slot3 slot4"
    "slot1 slot1 slot5 slot3 slot4"
    "slot7 slot14 slot10 slot6 slot9"
    "slot8 slot15 slot11 slot6 slot9"
    "slot16 slot16 slot17 slot12 slot13"
    "slot16 slot16 slot17 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
    "slot1 slot1 slot2 slot4"
    "slot1 slot1 slot5 slot4"
    "slot3 slot7 slot6 slot9"
    "slot3 slot8 slot6 slot9"
    "slot16 slot16 slot10 slot13"
    "slot16 slot16 slot11 slot13"
    "slot14 slot12 slot17 slot17"
    "slot15 slot12 slot17 slot17";
    
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot5 slot3 slot9"
        "slot6 slot7 slot13"
        "slot6 slot8 slot13"
        "slot16 slot16 slot10"
        "slot16 slot16 slot11"
        "slot14 slot12 slot17"
        "slot15 slot12 slot17";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot5 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot16 slot16"
        "slot16 slot16"
        "slot6 slot13"
        "slot6 slot13"
        "slot7 slot10"
        "slot8 slot11"
        "slot17 slot17"
        "slot17 slot17"
        "slot14 slot12"
        "slot15 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot5"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot7"
        "slot8"
        "slot6"
        "slot6"
        "slot10"
        "slot11"
        "slot14"
        "slot15"
        "slot9"
        "slot9"
        "slot16"
        "slot16"
        "slot17"
        "slot17"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),fo={cardCount:17,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(16),C1:(0,C.P)(26)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:5,C2:5,C1:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:2,C2:4,C1:5},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:3,C4:3,C3:4,C2:3,C1:3},telemetryRowCol:{C5:[2,3],C4:[2,3],C3:[4,1],C2:[4,1],C1:[4,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:12,C4:8,C3:7,C2:8,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:6,C4:6,C3:8,C2:10,C1:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[11,1],C1:[9,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:7,C4:7,C3:9,C2:11,C1:7},telemetryRowCol:{C5:[4,1],C4:[4,2],C3:[6,2],C2:[12,1],C1:[10,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:13,C4:9,C3:6,C2:6,C1:13},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:10,C4:11,C3:12,C2:12,C1:9},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[7,3],C2:[11,2],C1:[13,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:11,C4:12,C3:13,C2:13,C1:10},telemetryRowCol:{C5:[4,3],C4:[6,3],C3:[8,3],C2:[12,2],C1:[14,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:16,C4:16,C3:16,C2:17,C1:16},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,2],C2:[15,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:17,C4:13,C3:10,C2:9,C1:17},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[9,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:8,C4:14,C3:14,C2:15,C1:11},telemetryRowCol:{C5:[3,2],C4:[7,1],C3:[9,1],C2:[15,1],C1:[15,1]}},{grid_area:"slot15",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:9,C4:15,C3:15,C2:16,C1:12},telemetryRowCol:{C5:[4,2],C4:[8,1],C3:[10,1],C2:[16,1],C1:[16,1]}},{grid_area:"slot16",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:14,C4:10,C3:11,C2:7,C1:14},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[7,1],C2:[7,1],C1:[19,1]}},{grid_area:"slot17",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:15,C4:17,C3:17,C2:14,C1:15},telemetryRowCol:{C5:[5,3],C4:[7,3],C3:[9,3],C2:[13,1],C1:[21,1]}}],styles:Po},vo=s.A`
:host {
    grid-template-areas:
    "slot1 slot1 slot2 slot3 slot4"
    "slot1 slot1 slot5 slot3 slot4"
    "slot7 slot6 slot10 slot14 slot9"
    "slot8 slot6 slot11 slot15 slot9"
    "slot16 slot16 slot17 slot12 slot13"
    "slot16 slot16 slot17 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
    "slot1 slot1 slot2 slot4"
    "slot1 slot1 slot5 slot4"
    "slot3 slot7 slot6 slot9"
    "slot3 slot8 slot6 slot9"
    "slot16 slot16 slot10 slot13"
    "slot16 slot16 slot11 slot13"
    "slot14 slot12 slot17 slot17"
    "slot15 slot12 slot17 slot17";
    
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot5 slot3 slot9"
        "slot6 slot7 slot13"
        "slot6 slot8 slot13"
        "slot16 slot16 slot10"
        "slot16 slot16 slot11"
        "slot14 slot12 slot17"
        "slot15 slot12 slot17";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot5 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot16 slot16"
        "slot16 slot16"
        "slot6 slot13"
        "slot6 slot13"
        "slot7 slot10"
        "slot8 slot11"
        "slot17 slot17"
        "slot17 slot17"
        "slot14 slot12"
        "slot15 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot5"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot7"
        "slot8"
        "slot6"
        "slot6"
        "slot10"
        "slot11"
        "slot14"
        "slot15"
        "slot9"
        "slot9"
        "slot16"
        "slot16"
        "slot17"
        "slot17"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),Ho={cardCount:17,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(16),C1:(0,C.P)(26)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:5,C2:5,C1:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:2,C2:4,C1:5},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:3,C4:3,C3:4,C2:3,C1:3},telemetryRowCol:{C5:[2,3],C4:[2,3],C3:[4,1],C2:[4,1],C1:[4,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:7,C2:8,C1:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:6,C4:6,C3:8,C2:10,C1:6},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[11,1],C1:[9,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:7,C4:7,C3:9,C2:11,C1:7},telemetryRowCol:{C5:[4,1],C4:[4,2],C3:[6,2],C2:[12,1],C1:[10,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:13,C4:9,C3:6,C2:6,C1:13},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:9,C4:11,C3:12,C2:12,C1:9},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[7,3],C2:[11,2],C1:[13,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:10,C4:12,C3:13,C2:13,C1:10},telemetryRowCol:{C5:[4,3],C4:[6,3],C3:[8,3],C2:[12,2],C1:[14,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:16,C4:16,C3:16,C2:17,C1:16},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,2],C2:[15,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:17,C4:13,C3:10,C2:9,C1:17},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[9,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:11,C4:14,C3:14,C2:15,C1:11},telemetryRowCol:{C5:[3,4],C4:[7,1],C3:[9,1],C2:[15,1],C1:[15,1]}},{grid_area:"slot15",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},cardDomOrder:{C5:12,C4:15,C3:15,C2:16,C1:12},telemetryRowCol:{C5:[4,4],C4:[8,1],C3:[10,1],C2:[16,1],C1:[16,1]}},{grid_area:"slot16",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:14,C4:10,C3:11,C2:7,C1:14},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[7,1],C2:[7,1],C1:[19,1]}},{grid_area:"slot17",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:15,C4:17,C3:17,C2:14,C1:15},telemetryRowCol:{C5:[5,3],C4:[7,3],C3:[9,3],C2:[13,1],C1:[21,1]}}],styles:vo},So=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot2 slot8 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot11 slot7 slot13 slot9 slot10"
        "slot11 slot12 slot13 slot14 slot15"
        "slot16 slot12 slot17 slot14 slot15";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot3 slot2 slot5"
        "slot6 slot3 slot2 slot5"
        "slot6 slot9 slot4 slot10"
        "slot12 slot9 slot7 slot10"
        "slot12 slot8 slot7 slot13"
        "slot11 slot8 slot15 slot16"
        "slot11 slot14 slot15 slot17";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot5"
        "slot2 slot3 slot5"
        "slot6 slot3 slot10"
        "slot6 slot9 slot10"
        "slot12 slot9 slot4"
        "slot12 slot7 slot4"
        "slot8 slot7 slot11"
        "slot8 slot13 slot11"
        "slot15 slot13 slot14"
        "slot15 slot16 slot17";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot5"
        "slot2 slot5"
        "slot1 slot1"
        "slot1 slot1"
        "slot10 slot9"
        "slot10 slot9"
        "slot6 slot3"
        "slot6 slot3"
        "slot4 slot4"
        "slot4 slot4"
        "slot12 slot11"
        "slot12 slot11"
        "slot15 slot7"
        "slot15 slot7"
        "slot8 slot8"
        "slot8 slot8"
        "slot13 slot14"
        "slot13 slot14"
        "slot16 slot17"
        "slot16 slot17";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14"
        "slot15"
        "slot15"
        "slot16"
        "slot16"
        "slot17"
        "slot17";
}
`.withBehaviors(),Wo={cardCount:17,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(7),C3:(0,C.P)(10),C2:(0,C.P)(20),C1:(0,C.P)(34)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:2,C2:3},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,2],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:1,C2:1},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:4,C2:7},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[2,2],C2:[7,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:9,C2:8},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[5,3],C2:[9,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:5},telemetryRowCol:{C5:[2,1],C4:[2,1],C3:[3,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:10,C3:10,C2:12},telemetryRowCol:{C5:[3,2],C4:[4,3],C3:[6,2],C2:[13,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:11,C3:11,C2:13},telemetryRowCol:{C5:[2,3],C4:[5,2],C3:[7,1],C2:[15,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:5},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[4,2],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:13,C3:12,C2:10},telemetryRowCol:{C5:[4,1],C4:[6,1],C3:[7,3],C2:[11,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:13,C4:9,C3:8,C2:9},telemetryRowCol:{C5:[5,2],C4:[4,1],C3:[5,1],C2:[11,1],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:12,C4:13,C2:14},telemetryRowCol:{C5:[4,3],C4:[5,4],C3:[8,2],C2:[17,1],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:16,C3:15,C2:15},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,3],C2:[17,2],C1:[27,1]}},{grid_area:"slot15",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:14,C3:14,C2:15},telemetryRowCol:{C5:[5,5],C4:[6,3],C3:[9,1],C2:[13,1],C1:[29,1]}},{grid_area:"slot16",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:15,C2:11},telemetryRowCol:{C5:[6,1],C4:[6,4],C3:[10,2],C2:[19,1],C1:[31,1]}},{grid_area:"slot17",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[6,3],C4:[7,4],C3:[10,3],C2:[19,2],C1:[33,1]}}],styles:So},bo=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot7 slot3 slot9 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot12 slot8 slot14 slot10"
        "slot11 slot12 slot13 slot14 slot15"
        "slot11 slot16 slot13 slot17 slot15";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot4 slot5"
        "slot3 slot1 slot6 slot5"
        "slot3 slot7 slot6 slot10"
        "slot8 slot7 slot11 slot10"
        "slot8 slot9 slot11 slot15"
        "slot13 slot9 slot12 slot15"
        "slot13 slot16 slot16 slot17"
        "slot14 slot16 slot16 slot17";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot4 slot3"
        "slot2 slot7 slot3"
        "slot1 slot7 slot5"
        "slot1 slot9 slot5"
        "slot6 slot9 slot10"
        "slot6 slot8 slot10"
        "slot12 slot8 slot15"
        "slot12 slot13 slot15"
        "slot14 slot13 slot11"
        "slot16 slot17 slot11";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot5"
        "slot2 slot5"
        "slot4 slot4"
        "slot4 slot4"
        "slot1 slot10"
        "slot1 slot10"
        "slot3 slot15"
        "slot3 slot15"
        "slot7 slot7"
        "slot7 slot7"
        "slot9 slot8"
        "slot9 slot8"
        "slot6 slot12"
        "slot6 slot12"
        "slot14 slot14"
        "slot14 slot14"
        "slot11 slot16"
        "slot11 slot16"
        "slot17 slot13"
        "slot17 slot13";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14"
        "slot15"
        "slot15"
        "slot16"
        "slot16"
        "slot17"
        "slot17";
}
`.withBehaviors(),ko={cardCount:17,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(20),C1:(0,C.P)(34)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:5,C2:4},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[3,1],C2:[5,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,2],C4:[1,1],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C2:6},telemetryRowCol:{C5:[1,3],C4:[2,1],C3:[1,3],C2:[7,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,2],C2:[3,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:6,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C3:8,C2:11},telemetryRowCol:{C5:[3,1],C4:[2,3],C3:[5,1],C2:[13,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C3:4,C2:8},telemetryRowCol:{C5:[2,2],C4:[3,2],C3:[2,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,3],C4:[4,1],C3:[6,2],C2:[11,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:11,C3:7,C2:9},telemetryRowCol:{C5:[2,4],C4:[5,2],C3:[4,2],C2:[11,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:9,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[5,3],C2:[5,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:13,C4:10,C3:15,C2:14},telemetryRowCol:{C5:[5,1],C4:[4,3],C3:[9,3],C2:[17,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:11,C4:14,C3:11},telemetryRowCol:{C5:[4,2],C4:[6,3],C3:[7,1],C2:[13,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:14,C2:17},telemetryRowCol:{C5:[5,3],C4:[6,1],C3:[8,2],C2:[19,2],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:12,C4:15,C2:13},telemetryRowCol:{C5:[4,4],C4:[8,1],C3:[9,1],C2:[15,1],C1:[27,1]}},{grid_area:"slot15",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:12,C3:12,C2:7},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[7,3],C2:[7,2],C1:[29,1]}},{grid_area:"slot16",layouts:{C5:C.uE._1x_1y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C2:15},telemetryRowCol:{C5:[6,2],C4:[7,2],C3:[10,1],C2:[17,2],C1:[31,1]}},{grid_area:"slot17",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C2:16},telemetryRowCol:{C5:[6,4],C4:[7,4],C3:[10,2],C2:[19,1],C1:[33,1]}}],styles:bo},To=s.A`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3"
        "slot4 slot4 slot5 slot6"
        "slot4 slot4 slot5 slot6";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot2"
        "slot1 slot3 slot2"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3"
        "slot4 slot2"
        "slot4 slot2"
        "slot5 slot6"
        "slot5 slot6";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6";
}
`.withBehaviors(),$o={cardCount:6,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(4),C2:(0,C.P)(6),C1:(0,C.P)(12)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:4},telemetryRowCol:{C4:[1,2],C3:[1,3],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:2},telemetryRowCol:{C4:[1,3],C3:[1,2],C2:[1,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:3},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:5,C2:5},telemetryRowCol:{C4:[3,3],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:6,C2:6},telemetryRowCol:{C4:[3,4],C3:[3,3],C2:[5,2],C1:[11,1]}}],styles:To},Fo=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5"
        "slot1 slot1 slot2 slot5"
        "slot3 slot9 slot4 slot10"
        "slot3 slot9 slot4 slot10"
        "slot6 slot8 slot7 slot7"
        "slot6 slot8 slot7 slot7";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot3 slot5"
        "slot1 slot3 slot5"
        "slot2 slot4 slot10"
        "slot2 slot4 slot10"
        "slot6 slot9 slot7"
        "slot6 slot9 slot8";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot10"
        "slot2 slot10"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Eo={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(6),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:4,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:2,C2:5},telemetryRowCol:{C5:[1,3],C4:[3,1],C3:[1,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:5,C2:6},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[3,2],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:7,C2:7},telemetryRowCol:{C5:[3,1],C4:[5,1],C3:[5,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:9,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:10,C2:9},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[6,3],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:8,C2:10},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[5,2],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[19,1]}}],styles:Fo},Xo=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot10"
        "slot5 slot6 slot7 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot1 slot4"
        "slot2 slot1 slot1 slot4"
        "slot5 slot3 slot7 slot10"
        "slot5 slot3 slot7 slot10"
        "slot9 slot8 slot8 slot6"
        "slot9 slot8 slot8 slot6";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot10"
        "slot2 slot3 slot10"
        "slot6 slot5 slot9"
        "slot6 slot5 slot9"
        "slot7 slot8 slot8"
        "slot7 slot8 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot10"
        "slot3 slot10"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot9"
        "slot6 slot9"
        "slot8 slot8"
        "slot8 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Ao={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,styles:Xo,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,1],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:6,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,4],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:9,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[7,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[11,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:8,C2:9},telemetryRowCol:{C5:[4,4],C4:[5,1],C3:[5,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[19,1]}}]},Lo=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot10"
        "slot5 slot6 slot7 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot7 slot10"
        "slot5 slot3 slot7 slot10"
        "slot8 slot8 slot6 slot9"
        "slot8 slot8 slot6 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot10"
        "slot2 slot3 slot10"
        "slot6 slot5 slot9"
        "slot6 slot5 slot9"
        "slot7 slot8 slot8"
        "slot7 slot8 slot8";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot10"
        "slot3 slot10"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot9"
        "slot6 slot9"
        "slot8 slot8"
        "slot8 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),jo={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,styles:Lo,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:7,C2:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,2],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:6,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:9,C2:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[7,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,2],C2:[11,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:8,C2:9},telemetryRowCol:{C5:[4,4],C4:[5,4],C3:[5,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[19,1]}}]},Mo=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot10 slot8 slot9";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot8 slot3 slot9"
        "slot5 slot8 slot3 slot9"
        "slot6 slot6 slot7 slot10"
        "slot6 slot6 slot7 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot5 slot8 slot6"
        "slot5 slot8 slot6"
        "slot7 slot7 slot10"
        "slot7 slot7 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot10 slot8";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Qo={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:6,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,3],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:6,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[5,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:8,C3:8,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,3],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:9,C3:9,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[7,1],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:5,C3:7,C2:10,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,2],C3:[5,2],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:10,C3:10,C2:9,C1:10},telemetryRowCol:{C5:[4,3],C4:[5,4],C3:[7,3],C2:[10,1],C1:[19,1]}}],styles:Mo},Zo=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot9"
        "slot5 slot3 slot6 slot9"
        "slot7 slot10 slot8 slot8"
        "slot7 slot10 slot8 slot8";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8"
        "slot10 slot10 slot5"
        "slot10 slot10 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),qo={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:10,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:8,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:10,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[5,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,2],C3:[7,1],C2:[10,2],C1:[19,1]}}],styles:Zo},zo=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot5"
        "slot6 slot4 slot7 slot7"
        "slot6 slot4 slot7 slot7"
        "slot9 slot9 slot8 slot10"
        "slot9 slot9 slot8 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot10"
        "slot3 slot4 slot10"
        "slot8 slot7 slot7"
        "slot8 slot7 slot7"
        "slot9 slot9 slot6"
        "slot9 slot9 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot2"
        "slot3 slot2"
        "slot4 slot10"
        "slot4 slot10"
        "slot6 slot8"
        "slot6 slot8"
        "slot7 slot9"
        "slot7 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Bo={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:4,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:3,C3:4,C2:3,C1:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:6,C3:5,C2:5,C1:4},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:2,C1:5},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:5,C3:10,C2:7,C1:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:8,C2:9,C1:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:9,C3:7,C2:8,C1:8},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:8,C3:9,C2:10,C1:9},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:10,C3:6,C2:6,C1:10},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[19,1]}}],styles:zo},Go=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot5"
        "slot6 slot8 slot7 slot7"
        "slot6 slot8 slot7 slot7"
        "slot4 slot4 slot9 slot10"
        "slot4 slot4 slot9 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot6 slot3 slot10"
        "slot6 slot3 slot10"
        "slot8 slot7 slot7"
        "slot8 slot7 slot7"
        "slot4 slot4 slot9"
        "slot4 slot4 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot2"
        "slot3 slot2"
        "slot4 slot10"
        "slot4 slot10"
        "slot6 slot8"
        "slot6 slot8"
        "slot7 slot9"
        "slot7 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Io={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:4,C1:2},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:3,C3:5,C2:3,C1:3},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,2],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:8,C3:9,C2:5,C1:4},telemetryRowCol:{C5:[1,4],C4:[5,1],C3:[7,1],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:3,C2:2,C1:5},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:5,C3:4,C2:7,C1:6},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,1],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:8,C2:9,C1:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:6,C3:7,C2:8,C1:8},telemetryRowCol:{C5:[3,3],C4:[3,2],C3:[5,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:10,C2:10,C1:9},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[7,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:10,C3:6,C2:6,C1:10},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[19,1]}}],styles:Go},Jo=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot3 slot5"
        "slot4 slot4 slot7 slot10"
        "slot4 slot4 slot7 slot10"
        "slot6 slot8 slot9 slot9"
        "slot6 slot8 slot9 slot9";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot3 slot10"
        "slot3 slot3 slot10"
        "slot4 slot6 slot6"
        "slot4 slot6 slot6"
        "slot7 slot8 slot9"
        "slot7 slot8 slot9";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot10"
        "slot2 slot10"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Ko={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:2,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:4,C2:5},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:6,C2:6},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[5,1],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:7,C2:7},telemetryRowCol:{C5:[3,1],C4:[5,1],C3:[5,2],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:8,C2:8},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[7,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[7,2],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,3],C3:[7,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[19,1]}}],styles:Jo},No=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot6"
        "slot5 slot3 slot6 slot6"
        "slot8 slot10 slot7 slot9"
        "slot8 slot10 slot7 slot9";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot6"
        "slot7 slot6 slot6"
        "slot8 slot10 slot5"
        "slot8 slot10 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Uo={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:10,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:9,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:7,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:10,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:8,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,2],C3:[7,2],C2:[10,2],C1:[19,1]}}],styles:No},Vo=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot10 slot9";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot6 slot9"
        "slot5 slot3 slot6 slot9"
        "slot8 slot8 slot7 slot10"
        "slot8 slot8 slot7 slot10";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot7 slot6 slot8"
        "slot7 slot6 slot8"
        "slot10 slot10 slot5"
        "slot10 slot10 slot5";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot7"
        "slot5 slot7"
        "slot6 slot8"
        "slot6 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Yo={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:10,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,3],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:7,C2:8,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,2],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:9,C3:6,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[5,1],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:9,C1:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:7,C3:5,C2:5,C1:9},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:10,C3:9,C2:10,C1:10},telemetryRowCol:{C5:[4,4],C4:[5,4],C3:[7,1],C2:[10,2],C1:[19,1]}}],styles:Vo},tl=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9"
        "slot10 slot10 slot11 slot12 slot13"
        "slot10 slot10 slot11 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot7 slot12 slot10 slot13"
        "slot8 slot12 slot11 slot13";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot13"
        "slot6 slot5 slot13"
        "slot7 slot12 slot10"
        "slot8 slot12 slot11";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot5 slot13"
        "slot5 slot13"
        "slot6 slot7"
        "slot6 slot8"
        "slot10 slot12"
        "slot11 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot4"
        "slot4"
        "slot9"
        "slot9"
        "slot2"
        "slot2"
        "slot6"
        "slot6"
        "slot3"
        "slot3"
        "slot5"
        "slot5"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot13"
        "slot13"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12";
}
`.withBehaviors(),ol={cardCount:13,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(26)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2,C1:4},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[7,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4,C1:6},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[11,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3,C1:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[3,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:7,C2:6,C1:7},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[7,1],C1:[13,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:6,C2:8,C1:5},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[9,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:9,C2:9,C1:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[7,1],C2:[9,2],C1:[15,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10,C1:9},telemetryRowCol:{C5:[3,4],C4:[6,1],C3:[8,1],C2:[10,2],C1:[17,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5,C1:3},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[5,1]}},{grid_area:"slot10",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C4:11,C3:12,C2:11,C1:11},telemetryRowCol:{C5:[5,1],C4:[5,3],C3:[7,3],C2:[11,1],C1:[21,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_2y},cardDomOrder:{C4:12,C3:13,C2:12,C1:12},telemetryRowCol:{C5:[5,3],C4:[6,3],C3:[8,3],C2:[12,1],C1:[23,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:11,C2:13,C1:13},telemetryRowCol:{C5:[5,4],C4:[5,2],C3:[7,2],C2:[11,2],C1:[25,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:13,C3:8,C2:7,C1:10},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[7,2],C1:[19,1]}}],styles:tl},ll=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot7 slot8"
        "slot5 slot6 slot7 slot7 slot8"
        "slot9 slot10 slot11 slot12 slot13"
        "slot9 slot10 slot11 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot5 slot3 slot7 slot7"
        "slot5 slot3 slot7 slot7"
        "slot10 slot10 slot6 slot8"
        "slot10 slot10 slot6 slot8"
        "slot9 slot11 slot12 slot13"
        "slot9 slot11 slot12 slot13";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot8"
        "slot2 slot3 slot8"
        "slot6 slot7 slot7"
        "slot6 slot7 slot7"
        "slot5 slot10 slot13"
        "slot5 slot10 slot13"
        "slot9 slot11 slot12"
        "slot9 slot11 slot12";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot8"
        "slot3 slot8"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot13"
        "slot7 slot13"
        "slot9 slot12"
        "slot9 slot12"
        "slot10 slot11"
        "slot10 slot11";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),Cl={cardCount:13,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(14),C1:(0,C.P)(26)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:3,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:5,C3:4,C2:4,C1:3},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:3,C3:2,C2:3,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:4,C3:8,C2:6,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[7,1],C2:[7,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:8,C3:6,C2:7,C1:6},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,1],C2:[7,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:6,C3:7,C2:8,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,2],C2:[9,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:9,C3:5,C2:5,C1:8},telemetryRowCol:{C5:[3,5],C4:[5,4],C3:[3,3],C2:[5,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:10,C3:11,C2:10,C1:9},telemetryRowCol:{C5:[5,1],C4:[7,1],C3:[9,1],C2:[11,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:7,C3:9,C2:12,C1:10},telemetryRowCol:{C5:[5,2],C4:[5,1],C3:[7,2],C2:[13,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:11,C4:11,C3:12,C2:13,C1:11},telemetryRowCol:{C5:[5,3],C4:[7,2],C3:[9,2],C2:[13,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:12,C4:12,C3:13,C2:11,C1:12},telemetryRowCol:{C5:[5,4],C4:[7,3],C3:[9,3],C2:[11,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:13,C4:13,C3:10,C2:9,C1:13},telemetryRowCol:{C5:[5,5],C4:[7,4],C3:[7,3],C2:[9,2],C1:[25,1]}}],styles:ll},sl=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot9"
        "slot5 slot6 slot7 slot8 slot9"
        "slot10 slot10 slot11 slot12 slot13"
        "slot10 slot10 slot11 slot12 slot13";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot4"
        "slot1 slot1 slot2 slot4"
        "slot3 slot5 slot6 slot9"
        "slot3 slot5 slot6 slot9"
        "slot10 slot10 slot7 slot13"
        "slot10 slot10 slot7 slot13"
        "slot8 slot12 slot11 slot11"
        "slot8 slot12 slot11 slot11";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot4"
        "slot2 slot3 slot9"
        "slot2 slot3 slot9"
        "slot6 slot5 slot13"
        "slot6 slot5 slot13"
        "slot10 slot10 slot7"
        "slot10 slot10 slot7"
        "slot8 slot12 slot11"
        "slot8 slot12 slot11";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot2 slot4"
        "slot3 slot9"
        "slot3 slot9"
        "slot10 slot10"
        "slot10 slot10"
        "slot6 slot13"
        "slot6 slot13"
        "slot5 slot7"
        "slot5 slot7"
        "slot11 slot11"
        "slot11 slot11"
        "slot8 slot12"
        "slot8 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13";
}
`.withBehaviors(),el={cardCount:13,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(8),C3:(0,C.P)(10),C2:(0,C.P)(16),C1:(0,C.P)(26)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:7,C2:9},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[5,2],C2:[11,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:6,C2:7},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:10,C2:10},telemetryRowCol:{C5:[3,3],C4:[5,3],C3:[7,3],C2:[11,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:11,C3:11,C2:12},telemetryRowCol:{C5:[3,4],C4:[7,1],C3:[9,1],C2:[15,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:5},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:9,C2:6},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[7,1],C2:[7,1],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:13,C3:13,C2:11},telemetryRowCol:{C5:[5,3],C4:[7,3],C3:[9,3],C2:[13,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:12,C3:12,C2:13},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,2],C2:[15,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:8,C2:8},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[5,3],C2:[9,2],C1:[25,1]}}],styles:sl},rl=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3"
        "slot1 slot1 slot2 slot2 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot2"
        "slot2 slot2"
        "slot3 slot3"
        "slot3 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3";
}
`.withBehaviors(),al={cardCount:3,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(6),C1:(0,C.P)(6)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:2},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:3,C3:3,C2:3},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[5,1],C1:[5,1]}}],styles:rl},dl=s.A`
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot3"
        "slot1 slot2 slot3 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot3 slot3"
        "slot3 slot3"
        "slot1 slot2"
        "slot1 slot2";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3";
}
`.withBehaviors(),yl={cardCount:3,rowHeightPx:{C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(6)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:2},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:2,C2:3},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[3,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:3,C2:1},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[1,1],C1:[5,1]}}],styles:dl};var ml=l(22131),il=l(86856),gl=l(87944);const ul=s.A`
    :host {
        --background-gradient-angle: 170deg;
    }
`,cl=s.A`
    :host {
        --background-gradient-angle: -170deg;
    }
`,wl=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot1 slot1 slot1"
        "slot2 slot3 slot4 slot5 slot6"
        "slot2 slot3 slot4 slot5 slot6";
    padding: 20px;
    border-radius: 4px;
    grid-auto-rows: 52px 146px 146px !important;
    --gradient-background: var(--background-gradient-angle), #FEFAD7 1.17%, #FFE0D9 90.12%;
    background: linear-gradient(var(--gradient-background));
}
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot1 slot1"
        "slot2 slot4 slot5 slot6"
        "slot3 slot4 slot5 slot6";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot1"
        "slot2 slot4 slot5"
        "slot3 slot4 slot5";
    height: ${(0,gl.c)(2*C.Cm+52+24)};
    width: ${(0,gl.c)(3*C.f1+24)};
}

:host([layout="C3"]) fluent-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C3"]) msft-article-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C3"]) cs-article-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot2 slot4"
        "slot3 slot4";
    height: ${(0,gl.c)(2*C.Cm+52+24)};
    width: ${(0,gl.c)(2*C.f1+12)};
}

:host([layout="C2"]) fluent-card[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) fluent-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C2"]) msft-article-card[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) msft-article-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C2"]) cs-article-card[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) cs-article-card[style*="grid-area:slot6"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot2"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6";
    grid-auto-rows: 52px 146px 146px 146px 146px 146px 146px 146px 146px !important;
}
`.withBehaviors(new il.t(ul,cl),(0,ml.mr)(s.A`
            :host {
                forced-color-adjust: auto;
            }
        `),(0,ml.G2)(s.A`
            :host([layout]) {
                    --background-gradient-angle-dark-mode: 134.62deg;
                    --gradient-background-dark-mode: var(--background-gradient-angle-dark-mode), #512C2C 1.14%, #252C4E 86.08%;
                    background: linear-gradient(var(--gradient-background-dark-mode));
            }
        `)),_l={cardCount:6,rowHeightPx:{C5:[52,146,146],C4:[52,146,146],C3:[52,146,146],C2:[52,146,146],C1:[52,146,146,146,146,146,146,146,146]},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._5x_1y,C4:C.uE._4x_1y,C3:C.uE._3x_1y,C2:C.uE._2x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[2,1],C4:[2,1],C3:[2,1],C2:[2,1],C1:[2,1]},cardDomOrder:{C5:2,C4:2,C3:2,C2:2,C1:2}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[2,2],C4:[3,1],C3:[3,1],C2:[3,1],C1:[3,1]},cardDomOrder:{C5:3,C4:3,C3:3,C2:3,C1:3}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[2,3],C4:[2,2],C3:[2,2],C2:[2,2],C1:[4,1]},cardDomOrder:{C5:4,C4:4,C3:4,C2:4,C1:4}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[2,4],C4:[2,3],C3:[2,3],C1:[6,1]},cardDomOrder:{C5:5,C4:5,C3:5,C1:5}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[2,5],C4:[2,4],C1:[8,1]},cardDomOrder:{C5:6,C4:6,C1:6}}],styles:wl},hl=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8 slot8"
        "slot5 slot6 slot7 slot8 slot8"
        "slot9 slot10 slot11 slot11 slot12"
        "slot9 slot10 slot11 slot11 slot12";
}
 
:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8"
        "slot9 slot10 slot11 slot12"
        "slot9 slot10 slot11 slot12";
}
 
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6"
        "slot7 slot8 slot9"
        "slot7 slot8 slot9"
        "slot10 slot11 slot12"
        "slot10 slot11 slot12";
}
 
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10"
        "slot11 slot12"
        "slot11 slot12";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12";
}
`.withBehaviors(),Rl={cardCount:12,rowHeightPx:{C5:(0,C.P)(6),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(12),C1:(0,C.P)(24)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:1,C4:1,C3:1,C2:1,C1:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:2,C4:2,C3:2,C2:2,C1:2},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:3,C4:3,C3:3,C2:3,C1:3},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:4,C4:4,C3:4,C2:4,C1:4},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[3,1],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:5,C4:5,C3:5,C2:5,C1:5},telemetryRowCol:{C5:[3,1],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:6,C4:6,C3:6,C2:6,C1:6},telemetryRowCol:{C5:[3,2],C4:[3,2],C3:[3,3],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:7,C4:7,C3:7,C2:7,C1:7},telemetryRowCol:{C5:[3,3],C4:[3,3],C3:[5,1],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:8,C4:8,C3:8,C2:8,C1:8},telemetryRowCol:{C5:[3,4],C4:[3,4],C3:[5,2],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:9,C4:9,C3:9,C2:9,C1:9},telemetryRowCol:{C5:[5,1],C4:[5,1],C3:[5,3],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:10,C4:10,C3:10,C2:10,C1:10},telemetryRowCol:{C5:[5,2],C4:[5,2],C3:[7,1],C2:[9,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:11,C4:11,C3:11,C2:11,C1:11},telemetryRowCol:{C5:[5,3],C4:[5,3],C3:[7,2],C2:[11,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C5:12,C4:12,C3:12,C2:12,C1:12},telemetryRowCol:{C5:[5,5],C4:[5,4],C3:[7,3],C2:[11,2],C1:[23,1]}}],styles:hl},Dl=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot2 slot7 slot4 slot5"
        "slot6 slot9 slot7 slot11 slot12"
        "slot8 slot9 slot10 slot11 slot12";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot3 slot6 slot5"
        "slot4 slot3 slot2 slot5"
        "slot4 slot7 slot2 slot12"
        "slot11 slot7 slot9 slot12"
        "slot11 slot8 slot9 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot2 slot1 slot5"
        "slot2 slot3 slot5"
        "slot4 slot3 slot12"
        "slot4 slot11 slot12"
        "slot9 slot11 slot8"
        "slot9 slot7 slot8"
        "slot6 slot7 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot2 slot5"
        "slot2 slot5"
        "slot1 slot1"
        "slot1 slot1"
        "slot12 slot11"
        "slot12 slot11"
        "slot4 slot3"
        "slot4 slot3"
        "slot6 slot6"
        "slot6 slot6"
        "slot9 slot7"
        "slot9 slot7"
        "slot8 slot10"
        "slot8 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12";
}
`.withBehaviors(),Ol={cardCount:12,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(5),C3:(0,C.P)(7),C2:(0,C.P)(14),C1:(0,C.P)(24)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:2,C2:3},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,2],C2:[3,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:1,C2:1},telemetryRowCol:{C5:[1,2],C4:[2,3],C3:[1,1],C2:[1,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:4,C2:7},telemetryRowCol:{C5:[1,3],C4:[1,2],C3:[2,2],C2:[7,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:5,C2:6},telemetryRowCol:{C5:[1,4],C4:[2,1],C3:[3,1],C2:[7,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:3,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:11,C2:8},telemetryRowCol:{C5:[2,1],C4:[1,3],C3:[7,1],C2:[9,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C3:10,C2:10},telemetryRowCol:{C5:[2,3],C4:[3,2],C3:[6,2],C2:[11,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:9,C2:11},telemetryRowCol:{C5:[4,1],C4:[5,2],C3:[5,3],C2:[13,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:11,C3:8,C2:9},telemetryRowCol:{C5:[3,2],C4:[4,3],C3:[5,1],C2:[11,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:12,C3:12,C2:12},telemetryRowCol:{C5:[4,3],C4:[5,4],C3:[7,3],C2:[13,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:7,C2:5},telemetryRowCol:{C5:[3,4],C4:[4,1],C3:[4,2],C2:[5,2],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:6,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[5,1],C1:[23,1]}}],styles:Dl},pl=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10"
        "slot11 slot12 slot13 slot14 slot15"
        "slot11 slot12 slot13 slot14 slot15"
        "slot16 slot17 slot18 slot19 slot20"
        "slot16 slot17 slot18 slot19 slot20";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4"
        "slot5 slot6 slot7 slot8"
        "slot5 slot6 slot7 slot8"
        "slot9 slot10 slot11 slot12"
        "slot9 slot10 slot11 slot12"
        "slot13 slot14 slot15 slot16"
        "slot13 slot14 slot15 slot16"
        "slot17 slot18 slot19 slot20"
        "slot17 slot18 slot19 slot20";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6"
        "slot7 slot8 slot9"
        "slot7 slot8 slot9"
        "slot10 slot11 slot12"
        "slot10 slot11 slot12"
        "slot13 slot14 slot15"
        "slot13 slot14 slot15"
        "slot16 slot17 slot18"
        "slot16 slot17 slot18"
        "slot19 slot20 slot20"
        "slot19 slot20 slot20";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10"
        "slot11 slot12"
        "slot11 slot12"
        "slot13 slot14"
        "slot13 slot14"
        "slot15 slot16"
        "slot15 slot16"
        "slot17 slot18"
        "slot17 slot18"
        "slot19 slot20"
        "slot19 slot20";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10"
        "slot11"
        "slot11"
        "slot12"
        "slot12"
        "slot13"
        "slot13"
        "slot14"
        "slot14"
        "slot15"
        "slot15"
        "slot16"
        "slot16"
        "slot17"
        "slot17"
        "slot18"
        "slot18"
        "slot19"
        "slot19"
        "slot20"
        "slot20";
}
`.withBehaviors(),nl={cardCount:20,rowHeightPx:{C5:(0,C.P)(8),C4:(0,C.P)(10),C3:(0,C.P)(14),C2:(0,C.P)(20),C1:(0,C.P)(40)},colWidthPx:C.f1,gutterPx:C.iw,styles:pl,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[3,1],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[3,1],C3:[3,2],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,2],C3:[3,3],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,2],C4:[3,3],C3:[5,1],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,3],C4:[3,4],C3:[5,2],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[5,3],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,5],C4:[5,2],C3:[7,1],C2:[9,2],C1:[19,1]}},{grid_area:"slot11",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[5,1],C4:[5,3],C3:[7,2],C2:[11,1],C1:[21,1]}},{grid_area:"slot12",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[5,2],C4:[5,4],C3:[7,3],C2:[11,2],C1:[23,1]}},{grid_area:"slot13",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[5,3],C4:[7,1],C3:[9,1],C2:[13,1],C1:[25,1]}},{grid_area:"slot14",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[5,4],C4:[7,2],C3:[9,2],C2:[13,2],C1:[27,1]}},{grid_area:"slot15",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[5,5],C4:[7,3],C3:[9,3],C2:[15,1],C1:[29,1]}},{grid_area:"slot16",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[7,1],C4:[7,4],C3:[11,1],C2:[15,2],C1:[31,1]}},{grid_area:"slot17",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[7,2],C4:[9,1],C3:[11,2],C2:[17,1],C1:[33,1]}},{grid_area:"slot18",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[7,3],C4:[9,2],C3:[11,3],C2:[17,2],C1:[35,1]}},{grid_area:"slot19",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[7,4],C4:[9,3],C3:[13,1],C2:[19,1],C1:[37,1]}},{grid_area:"slot20",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[7,5],C4:[9,4],C3:[13,2],C2:[19,2],C1:[39,1]}}]},xl=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot10"
        "slot4 slot5 slot6 slot10"
        "slot9 slot8 slot7 slot7"
        "slot9 slot8 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot6 slot6 slot7"
        "slot6 slot6 slot7"
        "slot8 slot9 slot10"
        "slot8 slot9 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Pl={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,styles:xl,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,3],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3},telemetryRowCol:{C5:[1,3],C4:[1,4],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5},telemetryRowCol:{C5:[1,5],C4:[3,2],C3:[3,3],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,1],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,3],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[7,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8},telemetryRowCol:{C5:[3,4],C4:[5,1],C3:[7,2],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[7,3],C2:[9,2],C1:[19,1]}}]},fl=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 "
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot7"
        "slot4 slot5 slot6 slot7"
        "slot8 slot9 slot10 slot10"
        "slot8 slot9 slot10 slot10";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot6 slot6 slot7"
        "slot6 slot6 slot7"
        "slot8 slot9 slot10"
        "slot8 slot9 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),vl={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,3],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,4],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[3,2],C3:[3,3],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,1],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,2],C4:[3,4],C3:[5,3],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[7,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[3,5],C4:[5,3],C3:[7,3],C2:[9,2],C1:[19,1]}}],styles:fl},Hl=s.A`

:host([layout="C5"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot10"
        "slot4 slot5 slot6 slot10"
        "slot8 slot9 slot7 slot7"
        "slot8 slot9 slot7 slot7";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot2"
        "slot3 slot4 slot5"
        "slot3 slot4 slot5"
        "slot6 slot6 slot7"
        "slot6 slot6 slot7"
        "slot8 slot9 slot10"
        "slot8 slot9 slot10";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4"
        "slot5 slot6"
        "slot5 slot6"
        "slot7 slot8"
        "slot7 slot8"
        "slot9 slot10"
        "slot9 slot10";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),Sl={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,styles:Hl,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[1,3],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3},telemetryRowCol:{C5:[1,3],C4:[1,4],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4},telemetryRowCol:{C5:[1,4],C4:[3,1],C3:[3,2],C2:[3,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5},telemetryRowCol:{C5:[1,5],C4:[3,2],C3:[3,3],C2:[5,1],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,1],C2:[5,2],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10},telemetryRowCol:{C5:[3,2],C4:[5,3],C3:[5,3],C2:[7,1],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8},telemetryRowCol:{C5:[3,3],C4:[5,1],C3:[7,1],C2:[7,2],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9},telemetryRowCol:{C5:[3,4],C4:[5,2],C3:[7,2],C2:[9,1],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[7,3],C2:[9,2],C1:[19,1]}}]},Wl=s.A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5"
        "slot6 slot7 slot8 slot9 slot10"
        "slot6 slot7 slot8 slot9 slot10";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 "
        "slot1 slot1 slot2 slot5"
        "slot3 slot4 slot6 slot10"
        "slot3 slot4 slot6 slot10"
        "slot7 slot8 slot8 slot9"
        "slot7 slot8 slot8 slot9";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot5"
        "slot1 slot1 slot5"
        "slot2 slot3 slot10"
        "slot2 slot3 slot10"
        "slot4 slot6 slot7"
        "slot4 slot6 slot7"
        "slot8 slot8 slot9"
        "slot8 slot8 slot9";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot2 slot10"
        "slot2 slot10"
        "slot3 slot4"
        "slot3 slot4"
        "slot6 slot7"
        "slot6 slot7"
        "slot8 slot9"
        "slot8 slot9";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6"
        "slot7"
        "slot7"
        "slot8"
        "slot8"
        "slot9"
        "slot9"
        "slot10"
        "slot10";
}
`.withBehaviors(),bl={cardCount:10,rowHeightPx:{C5:(0,C.P)(4),C4:(0,C.P)(6),C3:(0,C.P)(8),C2:(0,C.P)(10),C1:(0,C.P)(20)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:1,C3:1,C2:1},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:2,C3:3,C2:3},telemetryRowCol:{C5:[1,2],C4:[1,3],C3:[3,1],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:4,C3:4,C2:5},telemetryRowCol:{C5:[1,3],C4:[3,1],C3:[3,2],C2:[5,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:5,C3:6,C2:6},telemetryRowCol:{C5:[1,4],C4:[3,2],C3:[5,1],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:3,C3:2,C2:2},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:6,C3:7,C2:7},telemetryRowCol:{C5:[3,1],C4:[3,3],C3:[5,2],C2:[7,1],C1:[11,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:8,C3:8,C2:8},telemetryRowCol:{C5:[3,2],C4:[5,1],C3:[5,3],C2:[7,2],C1:[13,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:9,C3:9,C2:9},telemetryRowCol:{C5:[3,3],C4:[5,2],C3:[7,1],C2:[9,1],C1:[15,1]}},{grid_area:"slot9",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:10,C3:10,C2:10},telemetryRowCol:{C5:[3,4],C4:[5,4],C3:[7,3],C2:[9,2],C1:[17,1]}},{grid_area:"slot10",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},cardDomOrder:{C4:7,C3:5,C2:4},telemetryRowCol:{C5:[3,5],C4:[3,4],C3:[3,3],C2:[3,2],C1:[19,1]}}],styles:Wl},kl=s.A`

:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2"
        "slot3 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4";
}
`.withBehaviors(),Tl={cardCount:4,rowHeightPx:{C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(8)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[1,3],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[1,4],C3:[2,3],C2:[3,2],C1:[7,1]}}],styles:kl},$l=s.A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3"
        "slot4 slot5 slot6 slot6"
        "slot4 slot5 slot6 slot6";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3"
        "slot4 slot5 slot6"
        "slot4 slot5 slot6";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot3"
        "slot2 slot3"
        "slot4 slot5"
        "slot4 slot5"
        "slot6 slot6"
        "slot6 slot6";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5"
        "slot6"
        "slot6";
}
`.withBehaviors(),Fl={cardCount:6,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(4),C2:(0,C.P)(8),C1:(0,C.P)(12)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[1,3],C3:[1,2],C2:[3,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[1,4],C3:[1,3],C2:[3,2],C1:[5,1]}},{grid_area:"slot4",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[5,1],C1:[7,1]}},{grid_area:"slot5",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[5,2],C1:[9,1]}},{grid_area:"slot6",layouts:{C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C4:[3,3],C3:[3,3],C2:[7,1],C1:[11,1]}}],styles:$l},El=s.A`

    :host {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1";
    }
}
`.withBehaviors(),Xl={cardCount:1,rowHeightPx:{C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}}],styles:El},Al=s.A`

    :host {
        grid-template-areas:
            "slot1 slot2"
            "slot1 slot2"
            "slot3 slot4"
            "slot3 slot4"
            "slot5 slot6"
            "slot5 slot6"
            "slot7 slot8"
            "slot7 slot8";
    }
}
`.withBehaviors(),Ll={cardCount:8,rowHeightPx:{C4:(0,C.P)(8),C3:(0,C.P)(8),C2:(0,C.P)(8)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[5,1],C3:[5,1],C2:[5,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[5,2],C3:[5,2],C2:[5,2]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[7,1],C3:[7,1],C2:[7,1]}},{grid_area:"slot8",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[7,2],C3:[7,2],C2:[7,2]}}],styles:Al},jl=s.A`
:host {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
    grid-auto-rows: auto !important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1";
}
`.withBehaviors(),Ml={cardCount:1,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._2x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:jl},Ql=s.A`

    :host {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot2 slot3"
            "slot2 slot3"
            "slot4 slot5"
            "slot4 slot5"
            "slot6 slot7"
            "slot6 slot7";
    }
}
`.withBehaviors(),Zl={cardCount:7,rowHeightPx:{C4:(0,C.P)(8),C3:(0,C.P)(8),C2:(0,C.P)(8)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[5,1],C3:[5,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[5,2],C3:[5,2],C2:[5,2]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[7,1],C3:[7,1],C2:[7,1]}},{grid_area:"slot7",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[7,2],C3:[7,2],C2:[7,2]}}],styles:Ql},ql=s.A`

    :host {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot2 slot3"
            "slot2 slot3"
            "slot4 slot4"
            "slot4 slot4"
            "slot5 slot6"
            "slot5 slot6";
    }
}
`.withBehaviors(),zl={cardCount:6,rowHeightPx:{C4:(0,C.P)(8),C3:(0,C.P)(8),C2:(0,C.P)(8)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}},{grid_area:"slot4",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y},telemetryRowCol:{C4:[5,1],C3:[5,1],C2:[5,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[7,1],C3:[7,1],C2:[7,1]}},{grid_area:"slot6",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[7,2],C3:[7,2],C2:[7,2]}}],styles:ql},Bl=s.A`

    :host {
        grid-template-areas:
            "slot1 slot1"
            "slot1 slot1"
            "slot2 slot3"
            "slot2 slot3";
    }
}
`.withBehaviors(),Gl={cardCount:3,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(4),C2:(0,C.P)(4)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[3,2],C3:[3,2],C2:[3,2]}}],styles:Bl},Il=s.A`

    :host {
        grid-template-areas:
            "slot1 slot2"
            "slot1 slot2";
    }
}
`.withBehaviors(),Jl={cardCount:2,rowHeightPx:{C4:(0,C.P)(4),C3:(0,C.P)(4),C2:(0,C.P)(4)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1],C2:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C4:[1,2],C3:[1,2],C2:[1,2]}}],styles:Il},Kl=s.A`

    :host {
        grid-template-areas:
            "slot1"
            "slot1"
            "slot2"
            "slot2"
            "slot3"
            "slot3"
            "slot4"
            "slot4";
    }

}
`.withBehaviors(),Nl={cardCount:4,rowHeightPx:{C4:(0,C.P)(8),C3:(0,C.P)(8)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y},telemetryRowCol:{C4:[1,1],C3:[1,1]}},{grid_area:"slot2",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y},telemetryRowCol:{C4:[3,1],C3:[3,1]}},{grid_area:"slot3",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y},telemetryRowCol:{C4:[5,1],C3:[5,1]}},{grid_area:"slot4",layouts:{C4:C.uE._1x_2y,C3:C.uE._1x_2y},telemetryRowCol:{C4:[7,1],C3:[7,1]}}],styles:Kl},Ul=s.A`
:host {
    grid-template-areas:
        "slot1"
        "slot1";
}

:host([layout="C4"]) {
    grid-template-areas:
    "slot1"
    "slot1";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
`.withBehaviors(),Vl={cardCount:1,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:Ul};var Yl=l(41523),tC=l(71350),oC=l(99541),lC=l(56512);const CC={"above-the-fold-eleven-card":r,"msft-top-section":_l,"river-section-one-row":Tl,"river-section-two-row":Fl,"hero-section-one-row-11111":c.D,"hero-section-one-row-122":_.L,"hero-section-one-row-1211":w.r,"hero-section-one-row-2111":h.x,"hero-section-one-row-2111-b":R.$,"hero-section-one-row-21155":D.k,"hero-section-one-row-221":O.b,"hero-section-one-row-25511":p.w,"hero-section-one-row-3-cards":n.m,"hero-section-one-row-3-mini-widgets":x.v,"hero-section-one-row-5-mini-widgets-drp":f.v,"hero-section-one-row-5-mini-widgets":v.X,"hero-section-one-row-4-cards":P.R,"hero-section-first-river-4-cards":g.O,"hero-section-first-river-5-cards":u.Z,"widgets-cards-1":Yl.X,"widgets-cards-2":tC.Q,"widgets-cards-3":oC.X,"widgets-cards-4":lC.c,"msft-twelve-card-five-col-waterfall":Ol,"msft-twelve-card-five-col":Rl,"enterprise-thirteen-card-five-col":nt,"msft-two-row-five-col":vl,"msft-two-row-five-col-two":bl,"msft-two-row-five-col-three":Sl,"msft-two-row-five-col-deep":Pl,"msft-three-card-four-col":yl,"msft-three-card-five-col":al,"msft-six-card-four-col-deep":$o,"msft-seven-card-four-col-atf":po,"msft-seven-card-four-col-btf":xo,"msft-seven-card-five-col-w14":Do,"msft-eight-card-four-col-deep":gt,"msft-four-card-five-col":vt,"msft-four-card-five-col-three":St,"msft-five-card-five-col":Pt,"msft-eight-card-five-col":rt,"msft-eight-card-five-col-3":S,"msft-eight-card-five-col-5":b,"msft-eight-card-five-col-two":mt,"msft-eight-card-five-col-three":dt,"msft-eight-card-five-col-four":tt,"msft-eight-card-five-col-five":V,"msft-eight-card-five-col-six":st,"msft-eight-card-five-col-seven":lt,"msft-eight-card-five-col-eight":N,"msft-eight-card-five-col-deep":J,"msft-eight-card-five-col-btf":F,"msft-eight-card-five-col-btf-two":L,"msft-eight-card-five-col-btf-three":X,"msft-eight-card-five-col-btf-four":T,"msft-eight-card-five-col-cold-a":M,"msft-eight-card-five-col-cold-b":Z,"msft-eight-card-five-col-cold-c":z,"msft-eight-card-five-col-cold-d":G,"msft-eighteen-card-five-col":ct,"msft-eleven-card-five-col":_t,"msft-eleven-card-five-col-two":Ot,"msft-eleven-card-five-col-three":Rt,"msft-seventeen-card-five-col-half-u-a1":fo,"msft-seventeen-card-five-col-half-u":Ho,"msft-seventeen-card-five-col-waterfall-v1":Wo,"msft-seventeen-card-five-col-waterfall-v2":ko,"wpo-rrail-T1-1":Vl,"wpo-rrail-T4":Nl,"wpo-sc-T1-full-width_1":Ml,"wpo-sc-T6":zl,"wpo-sc-T7":Zl,"wpo-sc-T8":Ll,"wpo-sc-T3":Gl,"wpo-sc-T2":Jl,"msft-infopanecard-fordenseriver":Xl,"msft-nine-card-five-col":wo,"msft-nine-card-five-col-1":Xt,"msft-nine-card-five-col-5":Lt,"msft-nine-card-five-col-atf":zt,"msft-nine-card-five-col-atf-two":Jt,"msft-nine-card-five-col-atf-three":Gt,"msft-nine-card-five-col-atf-four":Zt,"msft-nine-card-five-col-atf-five":Mt,"msft-nine-card-five-col-btf":Nt,"msft-nine-card-five-col-btf-two":Vt,"msft-nine-card-five-col-double-cg-two":ro,"msft-nine-card-five-col-double-cg":so,"msft-nine-card-five-col-cold-d":to,"msft-nine-card-five-col-cold-e":lo,"msft-nine-card-five-col-move-info":uo,"msft-nine-card-five-col-low-info":yo,"msft-nine-card-five-col-low-info-two":io,"msft-nine-card-five-col-twoc-ad":ho,"msft-ten-card-five-col":Ko,"msft-ten-card-five-col-two":Yo,"msft-ten-card-five-col-three":Uo,"msft-ten-card-five-col-four":qo,"msft-ten-card-five-col-five":Qo,"msft-ten-card-five-col-six":Io,"msft-ten-card-five-col-da":jo,"msft-ten-card-five-col-da-move-info":Ao,"msft-ten-card-five-col-btf":Eo,"msft-ten-card-five-col-oneu-info":Bo,"msft-twenty-card-five-col-all-one":nl,"msft-thirteen-card-five-col":ol,"msft-thirteen-card-five-col-two":el,"msft-thirteen-card-five-col-three":Cl,"msft-fourteen-card-five-col":bt,"msft-fourteen-card-five-col-three":Tt,"msft-full-wide-one-card-five-col":Ft,"msft-placeholder-c1":i(1),"msft-placeholder-c2":i(2),"msft-placeholder-c3":i(3),"msft-placeholder-c4":i(4),"msft-placeholder-c5":i(5)}},36271(t,o,l){l.d(o,{b(){return e}});var C=l(33477);const s=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot2 slot3"
        "slot1 slot1 slot2 slot2 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3]}}],styles:s}},40094(t,o,l){l.d(o,{w(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot4 slot5"
        "slot1 slot1 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot5 slot4"
        "slot1 slot1 slot3 slot5 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot5 slot4"
        "slot1 slot3 slot5 slot4";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot5 slot2 slot4"
        "slot1 slot5 slot3 slot4";
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,2],C1:[1,3]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[2,3],C4:[2,3],C3:[2,3],C2:[2,2],C1:[2,3]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,5],C3:[1,5],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,3],C1:[1,2]}}],styles:s}},41523(t,o,l){l.d(o,{X(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1";
}
`.withBehaviors(),e={cardCount:1,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}}],styles:s}},42411(t,o,l){l.d(o,{L(){return e}});var C=l(33477);const s=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot3"
        "slot1 slot2 slot2 slot3 slot3";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot2"
        "slot1 slot2 slot2";
}
:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot3"
        "slot1 slot3";
}
:host([layout="C2"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C2:[1,2]}}],styles:s}},54267(t,o,l){l.d(o,{r(){return e}});var C=l(33477);const s=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot2 slot3"
        "slot1 slot2 slot2 slot3";
}
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:s}},56512(t,o,l){l.d(o,{c(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,4],C4:[1,4]}}],styles:s}},56614(t,o,l){l.d(o,{k(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot4 slot1 slot1 slot2"
        "slot5 slot1 slot1 slot2";
}
:host([layout="C4"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot4"
        "slot1 slot1 slot5";
}
:host([layout="C3"]) *[style*="grid-area:slot2"] {
    display: none;
}

:host([layout="C3"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot4 slot2"
        "slot5 slot2";
}

:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,4],C2:[3,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y},telemetryRowCol:{C5:[1,4]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y},telemetryRowCol:{C5:[1,5],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y},telemetryRowCol:{C5:[2,5],C4:[2,1],C3:[2,3],C2:[4,1]}}],styles:s}},64865(t,o,l){l.d(o,{x(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot2 slot1 slot1 slot4"
        "slot3 slot1 slot1 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot1 slot2"
        "slot1 slot1 slot3";
}

:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot1"
        "slot1 slot1"
        "slot2 slot4"
        "slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._2x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,2],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,1],C3:[1,3],C2:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y},telemetryRowCol:{C5:[1,4],C4:[2,1],C3:[2,3],C2:[4,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C2:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C2:[3,2]}}],styles:s}},68683(t,o,l){l.d(o,{$(){return e}});var C=l(33477);const s=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot1 slot2 slot3 slot4"
        "slot1 slot1 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot1 slot2 slot3"
        "slot1 slot1 slot2 slot3";
}
 
:host([layout="C4"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._2x_2y,C4:C.uE._2x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:s}},69721(t,o,l){l.d(o,{Z(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot5"
        "slot1 slot2 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot5"
        "slot1 slot2 slot5"
        "slot3 slot4 slot4"
        "slot3 slot4 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot5"
        "slot1 slot5"
        "slot3 slot3"
        "slot3 slot3"
        "slot2 slot4"
        "slot2 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot2"
        "slot2"
        "slot3"
        "slot3"
        "slot4"
        "slot4"
        "slot5"
        "slot5";
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(4),C2:(0,C.P)(6),C1:(0,C.P)(10)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[5,1],C1:[3,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._1x_2y,C2:C.uE._2x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[3,1],C2:[3,1],C1:[5,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_1y,C3:C.uE._2x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[2,3],C3:[3,2],C2:[5,2],C1:[7,1]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,3],C2:[1,2],C1:[9,1]}}],styles:s}},69827(t,o,l){l.d(o,{X(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
}

`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy,C1:C.uE._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy,C1:C.uE._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy,C1:C.uE._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy,C1:C.uE._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy,C1:C.uE._1x_halfy},telemetryRowCol:{C5:[1,5],C4:[1,5],C3:[1,5],C2:[1,5],C1:[1,5]}}],styles:s}},71350(t,o,l){l.d(o,{Q(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),e={cardCount:2,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}}],styles:s}},72547(t,o,l){l.d(o,{D(){return e}});var C=l(33477);const s=l(74849).A`

:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5"
        "slot1 slot2 slot3 slot4 slot5";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3"
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2"
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5]}}],styles:s}},74050(t,o,l){l.d(o,{O(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot4 slot3"
        "slot1 slot2 slot4 slot3";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot4 slot2"
        "slot1 slot4 slot3";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot4"
        "slot1 slot4"
        "slot2 slot3"
        "slot2 slot3";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1"
        "slot1"
        "slot4"
        "slot4"
        "slot2"
        "slot2"
        "slot3"
        "slot3";
}
`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(4),C1:(0,C.P)(8)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,3],C2:[3,1],C1:[5,1]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_1y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,4],C3:[2,3],C2:[3,2],C1:[7,1]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,3],C3:[1,2],C2:[1,2],C1:[3,1]}}],styles:s}},90773(t,o,l){l.d(o,{v(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3 slot4 slot5";
    
    grid-template-rows: 88px!important;
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4";
}
:host([layout="C4"]) *[style*="grid-area:slot5"] {
    display: none;
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C3"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C3"]) *[style*="grid-area:slot4"] {
    display: none;
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot5"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot4"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
`.withBehaviors(),e={cardCount:5,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy,C1:C.uE._1x_halfy},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy,C2:C.uE._1x_halfy},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy,C3:C.uE._1x_halfy},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_halfy,C4:C.uE._1x_halfy},telemetryRowCol:{C5:[1,4],C4:[1,4]}},{grid_area:"slot5",layouts:{C5:C.uE._1x_halfy},telemetryRowCol:{C5:[1,5]}}],styles:s}},93833(t,o,l){l.d(o,{R(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot2 slot3 slot4"
        "slot1 slot2 slot2 slot3 slot4";
}

:host([layout="C4"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C3"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

:host([layout="C1"]) {
    grid-template-areas:
        "slot1 slot2 slot3 slot4"
        "slot1 slot2 slot3 slot4";
}

`.withBehaviors(),e={cardCount:4,rowHeightPx:{C5:(0,C.P)(2),C4:(0,C.P)(2),C3:(0,C.P)(2),C2:(0,C.P)(2),C1:(0,C.P)(2)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._2x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2],C1:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,4],C4:[1,3],C3:[1,3],C2:[1,3],C1:[1,3]}},{grid_area:"slot4",layouts:{C5:C.uE._1x_2y,C4:C.uE._1x_2y,C3:C.uE._1x_2y,C2:C.uE._1x_2y,C1:C.uE._1x_2y},telemetryRowCol:{C5:[1,5],C4:[1,4],C3:[1,4],C2:[1,4],C1:[1,4]}}],styles:s}},99541(t,o,l){l.d(o,{X(){return e}});var C=l(33477);const s=l(74849).A`
:host {
    grid-template-areas:
        "slot1 slot2 slot3";
}
:host([layout="C2"]) {
    grid-template-areas:
        "slot1 slot2";
}
:host([layout="C2"]) *[style*="grid-area:slot3"] {
    display: none;
}
:host([layout="C1"]) {
    grid-template-areas:
        "slot1";
}
:host([layout="C1"]) *[style*="grid-area:slot2"] {
    display: none;
}
:host([layout="C1"]) *[style*="grid-area:slot3"] {
    display: none;
}
`.withBehaviors(),e={cardCount:3,rowHeightPx:{C5:(0,C.P)(1),C4:(0,C.P)(1),C3:(0,C.P)(1),C2:(0,C.P)(1),C1:(0,C.P)(1)},colWidthPx:C.f1,gutterPx:C.iw,cardSlots:[{grid_area:"slot1",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,1],C4:[1,1],C3:[1,1],C2:[1,1],C1:[1,1]}},{grid_area:"slot2",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,2],C4:[1,2],C3:[1,2],C2:[1,2]}},{grid_area:"slot3",layouts:{C5:C.uE._1x_1y,C4:C.uE._1x_1y,C3:C.uE._1x_1y,C2:C.uE._1x_1y,C1:C.uE._1x_1y},telemetryRowCol:{C5:[1,3],C4:[1,3],C3:[1,3]}}],styles:s}}}]);