// © Microsoft Corporation. All rights reserved.
// This file will contain a dynamic import for each experience bundle that needs to be generated.
//
// registerExperience("interests", () => import(/* webpackChunkName: "interests" *//*"@msnews/interests")); <<
//                                                ^^^^^^ it needs to wrapped if you want to split into a separate chunk and to be lazy downloaded
//
// This is the place to list out which experiences will be lazy loaded for the Entry Point / page.
// This file must be included in the page experience by including the following line in the page experience page.ts file
// import "./bundler"
import * as experiencesConstants from "@msnews/experiences-constants";
import { DynamicBundles } from "@msnews/core";
const { registerExperience } = DynamicBundles;
// for eager loaded experiences
registerExperience(experiencesConstants.ExperienceIds_entryPointHpWC, () => import(/* webpackMode: "eager" */ "@msnews/entry-point-hp-wc"));
registerExperience(experiencesConstants.ExperienceIds_superNav, () => import(/* webpackChunkName: "super-nav" */ "@msnews/super-nav"));
registerExperience(experiencesConstants.ConnectorNamespaces_ExperienceTrackerHomePageData, () => import(/* webpackMode: "eager" */ "@msnews/experience-tracker-homepage"));
// Preload experiences
registerExperience(experiencesConstants.ExperienceIds_meStripeWC, () => import(/* webpackPrefetch: true */ "@msnews/me-stripe-wc"));
registerExperience(experiencesConstants.ExperienceIds_displayAdsWC, () => import(/* webpackPrefetch: true */ "@msnews/display-ads-wc"));
// Components only used in classic view
if (__IS_FEEDVIEW_VARIANT__ !== true) {
    registerExperience(experiencesConstants.ExperienceIds_stripeWC, () => import(/* webpackChunkName: "stripe-wc" */ "@msnews/stripe-wc"));
    registerExperience(experiencesConstants.ExperienceIds_homepageHeader, () => import(/* webpackMode: "eager" */ "@msnews/homepage-header"));
    registerExperience(experiencesConstants.ExperienceIds_breakingNewsWC, () => import(/* webpackMode: "lazy" */ "@msnews/breaking-news-wc"));
    registerExperience(experiencesConstants.ExperienceIds_feedNavigationHp, () => import(/* webpackChunkName: "feed-navigation-hp" */ "@msnews/feed-navigation-hp"));
    registerExperience(experiencesConstants.ExperienceIds_moneyInfoCardWC, () => import(/* webpackMode: "lazy" */ "@msnews/money-info-card-wc"));
    registerExperience(experiencesConstants.ExperienceIds_healthArticlesCardWC, () => import(/* webpackChunkName: "lazy" */ "@msnews/health-articles-card"));
    registerExperience(experiencesConstants.ExperienceIds_videoCardWC, () => import(/* webpackMode: "lazy" */ "@msnews/video-card-wc"));
    registerExperience(experiencesConstants.ExperienceIds_backgroundGallery, () => import(/* webpackChunkName: "background-gallery" */ "@msnews/background-gallery"));
    registerExperience(experiencesConstants.ExperienceIds_floatButtonGroupWC, () => import(/* webpackChunkName: "float-button-group-wc" */ "@msnews/float-button-group-wc"));
}
// for lazy loaded experiences
registerExperience(experiencesConstants.ExperienceIds_interestsWC, () => import(/* webpackChunkName: "interests-wc" */ "@msnews/interests-wc"));
registerExperience(experiencesConstants.ExperienceIds_channelStore, () => import(/* webpackChunkName: "channel-store" */ "@msnews/channel-store"));
registerExperience(experiencesConstants.ExperienceIds_socialBarWC, () => import(/* webpackMode: "lazy" */ "@msnews/social-bar-wc"));
registerExperience(experiencesConstants.ExperienceIds_homepageFooter, () => import(/* webpackMode: "lazy" */ "@msnews/homepage-footer"));
registerExperience(experiencesConstants.ExperienceIds_feedbackDialogWC, () => import(/* webpackMode: "lazy" */ "@msnews/feedback-dialog-wc"));
registerExperience(experiencesConstants.ConnectorNamespaces_WeatherData, () => import(/* webpackMode: "lazy" */ "@msnews/weather-data-connector"));
registerExperience(experiencesConstants.ConnectorNamespaces_WeatherCardData, () => import(/* webpackMode: "lazy" */ "@msnews/weather-card-data-connector"));
registerExperience(experiencesConstants.ExperienceIds_conditionalBannerHpWC, () => import(/* webpackMode: "lazy" */ "@msnews/conditional-banner-hp-wc"));
registerExperience(experiencesConstants.ConnectorNamespaces_IrisData, () => import(/* webpackMode: "lazy" */ "@msnews/iris-data-connector"));
registerExperience(experiencesConstants.ExperienceIds_msRewardsWC, () => import(/* webpackMode: "lazy" */ "@msnews/ms-rewards-wc"));
registerExperience(experiencesConstants.ConnectorNamespaces_LocationData, () => import(/* webpackMode: "lazy" */ "@msnews/location-data-connector"));
// Desktop
DynamicBundles.registerExperience(experiencesConstants.ExperienceIds_gridViewFeed, () => import(/* webpackChunkName: "grid-view-feed" */ "@msnews/grid-view-feed"));
registerExperience(experiencesConstants.ExperienceIds_widgetsRegion, () => import(/* webpackChunkName: "widgets-region" */ "@msnews/widgets-region"));
registerExperience(experiencesConstants.ExperienceIds_codexBingChat, () => import(/* webpackChunkName: "codex-bing-chat" */ "@msnews/codex-bing-chat"));
registerExperience(experiencesConstants.ExperienceIds_commonAutoSuggest, () => import(/* webpackChunkName: "common-auto-suggest" */ "@msnews/common-auto-suggest"));
registerExperience(experiencesConstants.ExperienceIds_cardActionWC, () => import(/* webpackMode: "lazy" */ "@msnews/card-action-wc"));
registerExperience(experiencesConstants.ExperienceIds_casualGamesCard, () => import(/* webpackMode: "lazy" */ "@msnews/casual-games-card"));
registerExperience(experiencesConstants.ExperienceIds_casualGamesStripeCarouselCard, () => import(/* webpackMode: "lazy" */ "@msnews/casual-games-stripe-carousel-card"));
registerExperience(experiencesConstants.ExperienceIds_mailSignoutBanner, () => import(/* webpackMode: "lazy" */ "@msnews/mail-signout-banner"));
registerExperience(experiencesConstants.ExperienceIds_notificationBellWC, () => import(/* webpackChunkName: "notification-bell-wc" */ "@msnews/notification-bell-wc"));
registerExperience(experiencesConstants.ExperienceIds_pageRefreshWC, () => import(/* webpackMode: "lazy" */ "@msnews/page-refresh-wc"));
registerExperience(experiencesConstants.ExperienceIds_pollsCardWC, () => import(/* webpackMode: "lazy" */ "@msnews/polls-card-wc"));
registerExperience(experiencesConstants.ExperienceIds_searchHistoryEdgeNextWC, () => import(/* webpackMode: "lazy" */ "@msnews/search-history-edgenext-wc"));
registerExperience(experiencesConstants.ExperienceIds_shoppingCarouselWC, () => import(/* webpackMode: "lazy" */ "@msnews/shopping-carousel-experience-wc"));
registerExperience(experiencesConstants.ExperienceIds_travelDestination, () => import(/* webpackMode: "lazy" */ "@msnews/travel-destination"));
registerExperience(experiencesConstants.ExperienceIds_travelSdDestinationsCard, () => import(/* webpackMode: "lazy" */ "@msnews/travel-sd-destinations-card"));
registerExperience(experiencesConstants.ExperienceIds_travelSdFlightsCard, () => import(/* webpackMode: "lazy" */ "@msnews/travel-sd-flights-card"));
registerExperience(experiencesConstants.ExperienceIds_travelSdCarrentalsCard, () => import(/* webpackMode: "lazy" */ "@msnews/travel-sd-carrentals-card"));
registerExperience(experiencesConstants.ExperienceIds_travelSdHotelsCard, () => import(/* webpackMode: "lazy" */ "@msnews/travel-sd-hotels-card"));
registerExperience(experiencesConstants.ExperienceIds_travelSdThemesCard, () => import(/* webpackMode: "lazy" */ "@msnews/travel-sd-themes-card"));
registerExperience(experiencesConstants.ExperienceIds_viewsNativeAd, () => import(/* webpackMode: "lazy" */ "@msnews/views-native-ad"));
registerExperience(experiencesConstants.ExperienceIds_weatherCardWC, () => import(/* webpackChunkName: "weather-card-wc" */ "@msnews/weather-card-wc"));
registerExperience(experiencesConstants.ExperienceIds_weatherMinimapWC, () => import(/* webpackChunkName : "weather-minimap-wc" */ "@msnews/weather-minimap-wc"));
registerExperience(experiencesConstants.ExperienceIds_shoppingBannerSdCard, () => import(/* webpackChunkName: "shopping-banner-sd-card" */ "@msnews/shopping-banner-sd-card"));
registerExperience(experiencesConstants.ExperienceIds_shoppingSdCard, () => import(/* webpackChunkName: "shopping-sd-card" */ "@msnews/shopping-sd-card"));
registerExperience(experiencesConstants.ExperienceIds_shoppingBuyingGuidesCard, () => import(/* webpackChunkName: "shopping-buying-guides-card" */ "@msnews/shopping-buying-guides-card"));
// CKJ markets
registerExperience(experiencesConstants.ExperienceIds_denseCard, () => import(/* webpackMode: "lazy" */ "@msnews/dense-card"));
registerExperience(experiencesConstants.ExperienceIds_recommendedSitesWC, () => import(/* webpackMode: "lazy" */ "@msnews/recommended-sites-wc"));
// Bundles that are used according to the flight
registerExperience(experiencesConstants.ExperienceIds_welcomeGreetingWC, () => import(/* webpackChunkName: "welcome-greeting-wc" */ "@msnews/welcome-greeting-wc"));
// Dynamic Data connector bundles
registerExperience(experiencesConstants.ConnectorNamespaces_AdsManager, () => import(/* webpackMode: "lazy" */ "@msnews/ads-manager"));
registerExperience(experiencesConstants.ConnectorNamespaces_CategoryData, () => import(/* webpackMode: "lazy" */ "@msnews/category-data-connector"));
registerExperience(experiencesConstants.ConnectorNamespaces_DisplayAdsManager, () => import(/* webpackMode: "lazy" */ "@msnews/display-ads-manager"));
registerExperience(experiencesConstants.ConnectorNamespaces_FeedbackData, () => import(/* webpackMode: "lazy" */ "@msnews/feedback-data-connector"));
registerExperience(experiencesConstants.ConnectorNamespaces_RewardsData, () => import(/* webpackMode: "lazy" */ "@msnews/rewards-data-connector"));
registerExperience(experiencesConstants.ConnectorNamespaces_NavigationData, () => import(/* webpackMode: "lazy" */ "@msnews/navigation-data-connector"));
registerExperience(experiencesConstants.ConnectorNamespaces_PlacementManager, () => import(/* webpackMode: "lazy" */ "@msnews/placement-manager"));
registerExperience(experiencesConstants.ConnectorNamespaces_SmartListSharedData, () => import(/* webpackMode: "lazy" */ "@msnews/smartlist-shared-data"));
registerExperience(experiencesConstants.ConnectorNamespaces_TelemetryData, () => import(/* webpackMode: "lazy" */ "@msnews/telemetry-data-connector"));
registerExperience(experiencesConstants.ConnectorNamespaces_NurturingPlacementManager, () => import(/* webpackChunkName: "nurturing-placement-manager" */ "@msnews/nurturing-placement-manager-connector"));
registerExperience(experiencesConstants.ConnectorNamespaces_TopicData, () => import(/* webpackChunkName: "topic-data-connector" */ "@msnews/topics-shared-state"));
// Waterfall View Feed for WPO
registerExperience(experiencesConstants.ExperienceIds_waterfallViewFeed, () => import(/* webpackMode: "lazy" */ "@msnews/waterfall-view-feed"));
// Dynamic Experience bundles (delay loaded)
registerExperience(experiencesConstants.ExperienceIds_superBreakingNews, () => import(/* webpackChunkName: "superBreakingNews" */ "@msnews/super-breaking-news"));
registerExperience(experiencesConstants.ExperienceIds_articleRelatedStories, () => import(/* webpackChunkName: "articleRelatedStories" */ "@msnews/article-related-stories"));
registerExperience(experiencesConstants.ExperienceIds_articleTopComment, () => import(/* webpackChunkName: "articleTopComment" */ "@msnews/article-top-comment"));
registerExperience(experiencesConstants.ExperienceIds_boostAdCard, () => import(/* webpackChunkName: "boost-ad-card" */ "@msnews/boost-ad-card"));
registerExperience(experiencesConstants.ExperienceIds_bingHealthCard, () => import(/* webpackChunkName: "bingHealthCard" */ "@msnews/bing-health-card"));
registerExperience(experiencesConstants.ExperienceIds_healthFitnessCarousel, () => import(/* webpackChunkName: "healthFitnessCarousel" */ "@msnews/health-fitness-carousel"));
registerExperience(experiencesConstants.ExperienceIds_cardActionWC, () => import(/* webpackChunkName: "card-actions-wc" */ "@msnews/card-action-wc"));
registerExperience(experiencesConstants.ExperienceIds_casualGamesCard, () => import(/* webpackChunkName: "casual-games-card" */ "@msnews/casual-games-card"));
registerExperience(experiencesConstants.ExperienceIds_casualGamesCarouselCard, () => import(/* webpackChunkName: "casual-games-carousel-card" */ "@msnews/casual-games-carousel-card"));
registerExperience(experiencesConstants.ExperienceIds_channelStore, () => import(/* webpackChunkName: "channel-store" */ "@msnews/channel-store"));
registerExperience(experiencesConstants.ExperienceIds_coldStartWC, () => import(/* webpackChunkName: "cold-start-wc" */ "@msnews/cold-start-wc"));
registerExperience(experiencesConstants.ExperienceIds_communityCard, () => import(/* webpackChunkName: "community-card" */ "@msnews/community-card"));
registerExperience(experiencesConstants.ExperienceIds_contentGroupCard, () => import(/* webpackChunkName: "content-group-card" */ "@msnews/content-group-card"));
registerExperience(experiencesConstants.ExperienceIds_denseCard, () => import(/* webpackChunkName: "dense-card" */ "@msnews/dense-card"));
registerExperience(experiencesConstants.ExperienceIds_devTools, () => import(/* webpackChunkName: "dev-tools" */ "@msnews/dev-tools"));
registerExperience(experiencesConstants.ExperienceIds_digestCard, () => import(/* webpackChunkName: "digest-card" */ "@msnews/digest-card"));
registerExperience(experiencesConstants.ExperienceIds_feedbackLinkWC, () => import(/* webpackChunkName: "feedback" */ "@msnews/feedback-link-wc"));
registerExperience(experiencesConstants.ExperienceIds_healthTipWC, () => import(/* webpackChunkName: "health-tip-wc" */ "@msnews/health-tip-wc"));
registerExperience(experiencesConstants.ExperienceIds_followingFreConfirmation, () => import(/* webpackChunkName: "following-fre-confirmation" */ "@msnews/following-fre-confirmation"));
registerExperience(experiencesConstants.ExperienceIds_followingFreFullWidth, () => import(/* webpackChunkName: "following-fre-full-width" */ "@msnews/following-fre-full-width"));
registerExperience(experiencesConstants.ExperienceIds_generalElections, () => import(/* webpackChunkName: "general-elections" */ "@msnews/general-elections"));
registerExperience(experiencesConstants.ExperienceIds_electionCard, () => import(/* webpackChunkName: "election-card" */ "@msnews/election-card"));
registerExperience(experiencesConstants.ExperienceIds_horoscopeAnswerCardWC, () => import(/* webpackChunkName: "horoscope-answer-card-wc" */ "@msnews/horoscope-answer-card-wc"));
registerExperience(experiencesConstants.ExperienceIds_interestFreCard, () => import(/* webpackChunkName: "interest-fre-card" */ "@msnews/interest-fre-card"));
registerExperience(experiencesConstants.ExperienceIds_interestManagementCard, () => import(/* webpackChunkName: "interest-management-card" */ "@msnews/interest-management-card"));
registerExperience(experiencesConstants.ExperienceIds_marketplaceCardWC, () => import(/* webpackChunkName: "marketplace-card-wc" */ "@msnews/marketplace-card-wc"));
registerExperience(experiencesConstants.ExperienceIds_marketLanguageToggleWC, () => import(/* webpackChunkName: "market-language-toggle-wc" */ "@msnews/market-language-toggle-wc"));
registerExperience(experiencesConstants.ExperienceIds_moneyInfo, () => import(/* webpackChunkName: "money-info" */ "@msnews/money-info"));
registerExperience(experiencesConstants.ExperienceIds_msRewardsWC, () => import(/* webpackChunkName: "ms-rewards-wc" */ "@msnews/ms-rewards-wc"));
registerExperience(experiencesConstants.ExperienceIds_navigationPageExperience, () => import(/* webpackChunkName: "navigation-page-experience" */ "@msnews/navigation-page-experience"));
registerExperience(experiencesConstants.ExperienceIds_notificationBellWC, () => import(/* webpackChunkName: "notification-bell-wc" */ "@msnews/notification-bell-wc"));
registerExperience(experiencesConstants.ExperienceIds_notificationMiniCard, () => import(/* webpackChunkName: "notification-mini-card" */ "@msnews/notification-mini-card"));
registerExperience(experiencesConstants.ExperienceIds_onThisDayCardWC, () => import(/* webpackChunkName: "on-this-day-card-wc" */ "@msnews/on-this-day-card-wc"));
registerExperience(experiencesConstants.ExperienceIds_personalizeNavButton, () => import(/* webpackChunkName: "personalize-nav-button" */ "@msnews/personalize-nav-button"));
registerExperience(experiencesConstants.ExperienceIds_pollsCardWC, () => import(/* webpackChunkName: "polls-card-wc" */ "@msnews/polls-card-wc"));
registerExperience(experiencesConstants.ExperienceIds_poweredByLegendWC, () => import(/* webpackChunkName: "poweredby-legend-wc" */ "@msnews/poweredby-legend-wc"));
registerExperience(experiencesConstants.ExperienceIds_prismSdCard, () => import(/* webpackChunkName: "prism-sd-card" */ "@msnews/prism-sd-card"));
registerExperience(experiencesConstants.ExperienceIds_qna, () => import(/* webpackChunkName: "qna-card" */ "@msnews/qna-card"));
registerExperience(experiencesConstants.ExperienceIds_quizCard, () => import(/* webpackChunkName: "quiz-card" */ "@msnews/quiz-card"));
registerExperience(experiencesConstants.ExperienceIds_recipesSdCard, () => import(/* webpackChunkName: "recipes-sd-card" */ "@msnews/recipes-sd-card"));
registerExperience(experiencesConstants.ExperienceIds_rewardsCardWC, () => import(/* webpackChunkName: "rewards-card-wc" */ "@msnews/rewards-card-wc"));
registerExperience(experiencesConstants.ExperienceIds_sdCardMaskWC, () => import(/* webpackChunkName: "sd-card-mask-wc" */ "@msnews/sd-card-mask-wc"));
registerExperience(experiencesConstants.ExperienceIds_selectCarousel, () => import(/* webpackChunkName: "select-carousel" */ "@msnews/select-carousel"));
registerExperience(experiencesConstants.ExperienceIds_signalOverlay, () => import(/* webpackChunkName: "signal-overlay" */ "@msnews/signal-overlay"));
registerExperience(experiencesConstants.ExperienceIds_sharedLinks, () => import(/* webpackChunkName: "shared-links" */ "@msnews/shared-links"));
registerExperience(experiencesConstants.ExperienceIds_sharepointNewsCard, () => import(/* webpackChunkName: "sharepoint-news-card" */ "@msnews/sharepoint-news-card"));
registerExperience(experiencesConstants.ExperienceIds_shoppingCardWC, () => import(/* webpackChunkName: "shopping-card-wce" */ "@msnews/shopping-card-wce"));
registerExperience(experiencesConstants.ExperienceIds_socialAvatar, () => import(/* webpackChunkName: "social-avatar" */ "@msnews/social-avatar"));
registerExperience(experiencesConstants.ExperienceIds_socialBarWC, () => import(/* webpackChunkName: "social-bar-wc" */ "@msnews/social-bar-wc"));
registerExperience(experiencesConstants.ExperienceIds_socialReportMenu, () => import(/* webpackChunkName: "social-report-menu" */ "@msnews/social-report-menu"));
registerExperience(experiencesConstants.ExperienceIds_premiumProfilePromoCard, () => import(/* webpackChunkName: "premium-profile-promo-card" */ "@msnews/premium-profile-promo-card"));
registerExperience(experiencesConstants.ExperienceIds_sportsInfo, () => import(/* webpackChunkName: "sports-info" */ "@msnews/sports-info"));
registerExperience(experiencesConstants.ExperienceIds_stackCard, () => import(/* webpackChunkName: "stack-card" */ "@msnews/stack-card"));
registerExperience(experiencesConstants.ExperienceIds_spotlightCardWC, () => import(/* webpackChunkName: "spotlight-card-wc" */ "@msnews/spotlight-card-wc"));
registerExperience(experiencesConstants.ExperienceIds_superNavCoachMark, () => import(/* webpackChunkName: "super-nav-coach-mark" */ "@msnews/super-nav-coach-mark"));
registerExperience(experiencesConstants.ExperienceIds_toastWC, () => import(/* webpackChunkName: "toast-wc" */ "@msnews/toast-wc"));
registerExperience(experiencesConstants.ExperienceIds_publisherSubscribeFollowButton, () => import(/* webpackChunkName: "publisher-subscribe-follow-button" */ "@msnews/publisher-subscribe-follow-button"));
registerExperience(experiencesConstants.ExperienceIds_trafficCardWC, () => import(/* webpackChunkName: "traffic-card-wc" */ "@msnews/traffic-card-wc"));
registerExperience(experiencesConstants.ExperienceIds_trafficHero, () => import(/* webpackChunkName: "traffic-hero" */ "@msnews/traffic-hero"));
registerExperience(experiencesConstants.ExperienceIds_travelDestination, () => import(/* webpackChunkName: "travel-destination" */ "@msnews/travel-destination"));
registerExperience(experiencesConstants.ExperienceIds_travelCarousel, () => import(/* webpackChunkName: "travel-carousel" */ "@msnews/travel-carousel"));
registerExperience(experiencesConstants.ExperienceIds_travelHotelCarousel, () => import(/* webpackChunkName: "travel-hotel-carousel" */ "@msnews/travel-hotel-carousel"));
registerExperience(experiencesConstants.ExperienceIds_travelFlightCarousel, () => import(/* webpackChunkName: "travel-flight-carousel" */ "@msnews/travel-flight-carousel"));
registerExperience(experiencesConstants.ExperienceIds_waffleWC, () => import(/* webpackChunkName: "waffle-wc" */ "@msnews/waffle-wc"));
registerExperience(experiencesConstants.ExperienceIds_waterfallViewFeed, () => import(/* webpackChunkName: "waterfall-view-feed" */ "@msnews/waterfall-view-feed"));
registerExperience(experiencesConstants.ExperienceIds_weatherHeroExperience, () => import(/* webpackChunkName: "weather-hero-experience" */ "@msnews/weather-hero-experience"));
registerExperience(experiencesConstants.ExperienceIds_weatherMinimapWC, () => import(/* webpackChunkName: "weather-minimap-wc" */ "@msnews/weather-minimap-wc"));
registerExperience(experiencesConstants.ExperienceIds_weatherVideoEntryWC, () => import(/* webpackChunkName: "weather-video-entry-wc" */ "@msnews/weather-video-entry-wc"));
registerExperience(experiencesConstants.ExperienceIds_weatherOneLiner, () => import(/* webpackChunkName: "weather-one-liner" */ "@msnews/weather-one-liner"));
registerExperience(experiencesConstants.ExperienceIds_welcomeGreetingLight, () => import(/* webpackChunkName: "welcomeGreetingLight" */ "@msnews/welcome-greeting-light"));
registerExperience(experiencesConstants.ExperienceIds_prismCarouselCard, () => import(/* webpackChunkName: "prism-carousel-card" */ "@msnews/prism-carousel-card"));
registerExperience(experiencesConstants.ExperienceIds_trendingSearchCard, () => import(/* webpackChunkName: "trending-search-card" */ "@msnews/trending-search-card"));
registerExperience(experiencesConstants.ExperienceIds_realEstateCard, () => import(/* webpackChunkName: "real-estate-card" */ "@msnews/real-estate-card"));
registerExperience(experiencesConstants.ExperienceIds_shoppingEventsDealCard, () => import(/* webpackChunkName: "shopping-events-deal-card" */ "@msnews/shopping-events-deal-card"));
registerExperience(experiencesConstants.ExperienceIds_shoppingSdCard, () => import(/* webpackChunkName: "shopping-sd-card" */ "@msnews/shopping-sd-card"));
registerExperience(experiencesConstants.ExperienceIds_travelSdThemesCard, () => import(/* webpackChunkName: "travel-sd-themes-card" */ "@msnews/travel-sd-themes-card"));
registerExperience(experiencesConstants.ExperienceIds_travelSdDestinationsCard, () => import(/* webpackChunkName: "travel-sd-destinations-card" */ "@msnews/travel-sd-destinations-card"));
registerExperience(experiencesConstants.ExperienceIds_travelSdHotelsCard, () => import(/* webpackChunkName: "travel-sd-hotels-card" */ "@msnews/travel-sd-hotels-card"));
registerExperience(experiencesConstants.ExperienceIds_travelSdCarrentalsCard, () => import(/* webpackChunkName: "travel-sd-flights-card" */ "@msnews/travel-sd-carrentals-card"));
registerExperience(experiencesConstants.ExperienceIds_travelSdFlightsCard, () => import(/* webpackChunkName: "travel-sd-flights-card" */ "@msnews/travel-sd-flights-card"));
registerExperience(experiencesConstants.ExperienceIds_contextualFeedbackWC, () => import(/* webpackChunkName: "contextual-feedback-wc" */ "@msnews/contextual-feedback-wc"));
registerExperience(experiencesConstants.ExperienceIds_hotListCard, () => import(/* webpackChunkName: "hot-list-card" */ "@msnews/hot-list-card"));
registerExperience(experiencesConstants.ExperienceIds_codexBingChat, () => import(/* webpackChunkName: "codex-bing-chat" */ "@msnews/codex-bing-chat"));
registerExperience(experiencesConstants.ExperienceIds_shoppingGroupedCarousel, () => import(/* webpackChunkName: "shopping-grouped-carousel" */ "@msnews/shopping-grouped-carousel"));
registerExperience(experiencesConstants.ExperienceIds_viewsNativeAd, () => import(/* webpackChunkName: "views-native-mon" */ "@msnews/views-native-ad"));
registerExperience(experiencesConstants.ExperienceIds_moneyAugmentCard, () => import(/* webpackChunkName: "money-augment-card" */ "@msnews/money-augment-card"));
registerExperience(experiencesConstants.ExperienceIds_sportsAugmentCard, () => import(/* webpackChunkName: "sports-augment-card" */ "@msnews/sports-augment-card"));
registerExperience(experiencesConstants.ExperienceIds_entertainmentPremierCard, () => import(/* webpackChunkName: "entertainment-premier-card" */ "@msnews/entertainment-premier-card"));
registerExperience(experiencesConstants.ExperienceIds_donationNpoCard, () => import(/* webpackChunkName: "donation-npo-card" */ "@msnews/donation-npo-card"));
registerExperience(experiencesConstants.ExperienceIds_commonAutoSuggest, () => import(/* webpackChunkName: "common-auto-suggest" */ "@msnews/common-auto-suggest"));
registerExperience(experiencesConstants.ExperienceIds_richCalendarCard, () => import(/* webpackChunkName: "rich-calendar-card" */ "@msnews/rich-calendar-card"));
registerExperience(experiencesConstants.ExperienceIds_shoppingAugmentCard, () => import(/* webpackChunkName: "shopping-augment-card" */ "@msnews/shopping-augment-card"));
registerExperience(experiencesConstants.ExperienceIds_issueReportingWC, () => import(/* webpackChunkName: "issue-reporting-wc" */ "@msnews/issue-reporting-wc"));
registerExperience(experiencesConstants.ExperienceIds_streaksBadgeWC, () => import(/* webpackChunkName: "streaks-badge-wc" */ "@msnews/streaks-badge-wc"));
registerExperience(experiencesConstants.ExperienceIds_healthAugmentCard, () => import(/* webpackChunkName: "health-augment-card" */ "@msnews/health-augment-card"));
registerExperience(experiencesConstants.ExperienceIds_shoppingRiverCard, () => import(/* webpackChunkName: "shopping-river-card" */ "@msnews/shopping-river-card"));
registerExperience(experiencesConstants.ExperienceIds_hpFeedSwitch, () => import(/* webpackChunkName: "hp-feed-switch" */ "@msnews/hp-feed-switch"));
registerExperience(experiencesConstants.ExperienceIds_nurturingBanner, () => import(/* webpackMode: "lazy", webpackChunkName: "nurturing-banner" */ "@msnews/nurturing-banner"));
registerExperience(experiencesConstants.ExperienceIds_topCommentsCard, () => import(/* webpackChunkName: "top-comments-card" */ "@msnews/top-comments-card"));
registerExperience(experiencesConstants.ExperienceIds_sharedHeroNewsCard, () => import(/* webpackChunkName: "shared-hero-news-card" */ "@msnews/shared-hero-news-card"));
registerExperience(experiencesConstants.ExperienceIds_momentInTimeHero, () => import(/* webpackChunkName: "moment-in-time-hero" */ "@msnews/moment-in-time-hero"));
registerExperience(experiencesConstants.ExperienceIds_dailyWonderCopilotCard, () => import(/* webpackChunkName: "daily-wonder-copilot-card" */ "@msnews/daily-wonder-copilot-card"));
registerExperience(experiencesConstants.ExperienceIds_dailyBriefCard, () => import(/* webpackChunkName: "daily-brief-card" */ "@msnews/daily-brief-card"));
registerExperience(experiencesConstants.ExperienceIds_dailyMomentsCard, () => import(/* webpackChunkName: "daily-moments-card" */ "@msnews/daily-moments-card"));
registerExperience(experiencesConstants.ExperienceIds_dailyWonderCard, () => import(/* webpackChunkName: "daily-wonder-card" */ "@msnews/daily-wonder-card"));
registerExperience(experiencesConstants.ExperienceIds_msnFeed, () => import(/* webpackChunkName: "msn-feed" */ "@msnews/msn-feed"));
registerExperience(experiencesConstants.ExperienceIds_commonSearchBoxEdgeNext, () => import(/* webpackMode: "eager" */ "@msnews/common-search-box-edgenext"));
registerExperience(experiencesConstants.ExperienceIds_topSitesEdgeNextWC, () => import(/* webpackMode: "eager" */ "@msnews/top-sites-edgenext-wc"));
registerExperience(experiencesConstants.ExperienceIds_commonSettingsEdgeNext, () => import(/* webpackChunkName: "common-settings-edgenext" */ "@msnews/common-settings-edgenext"));
registerExperience(experiencesConstants.ExperienceIds_pillWC, () => import(/* webpackChunkName: "pill-wc" */ "@msnews/pill-wc"));
registerExperience(experiencesConstants.ExperienceIds_weatherTopSectionCard, () => import(/* webpackChunkName: "weather-top-section-card" */ "@msnews/weather-top-section-card"));
registerExperience(experiencesConstants.ExperienceIds_creatorSpotlightCard, () => import(/* webpackChunkName: "creator-spotlight-card" */ "@msnews/creator-spotlight-card"));
//# sourceMappingURL=bundler.js.map