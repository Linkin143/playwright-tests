"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["recipes-sd-card"],{4968(e,t,i){i.d(t,{f(){return c}});var a=i(64187),s=i(74849),r=i(42792),n=i(99657),o=i(36452);const c=s.A.partial`position: relative; z-index: ${n.D};`;s.A`
    ${r.e}
    ${r.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${c}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${o.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${o.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${o.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(r.kc)},7014(e,t,i){i.d(t,{m(){return M}});var a=i(56911),s=i(38493),r=i(60815),n=i(55230),o=i(92011),c=i(56863);class l extends o.L{}class d extends((0,c.dx)(l)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class h extends d{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(!this.readOnly)switch(e.key){case n.Mm:case n.gG:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,t){super.checkedChanged(e,t),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,a.Cg)([(0,s.CF)({attribute:"readonly",mode:"boolean"}),(0,a.Sn)("design:type",Boolean)],h.prototype,"readOnly",void 0),(0,a.Cg)([r.sH,(0,a.Sn)("design:type",Array)],h.prototype,"defaultSlottedNodes",void 0);var p=i(37180),u=i(74849),m=i(64187),g=i(60993),b=i(73477),v=i(22131),f=i(50882),w=i(48196),y=i(86856),k=i(7896),x=i(74838),T=i(79288),$=i(46203),C=i(26920),S=i(43774),R=i(95239),U=i(14996),D=i(48751),P=i(41123),O=i(74089),I=i(4283);const H=u.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,m.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${k.O};
        margin: calc(${x.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${T.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${g.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${w.D} / 2) + ${x.vR}) * 2px);
        height: calc(((${w.D} / 2) + ${x.vR}) * 1px);
        background: ${$.le};
        border-radius: calc(${w.D} * 1px);
        border: calc(${C.XA} * 1px) solid ${S.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${$.jM};
        border-color: ${S.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${$.RS};
        border-color: ${S.p4};
    }

    :host(:${b.N}) .switch {
        box-shadow: 0 0 0 2px ${R.p}, 0 0 0 4px ${U.WN};
        border-color: ${U.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${w.D} - (${x.vR} * 5.5)) * 1px);
        width: calc((${w.D} - (${x.vR} * 5.5)) * 1px);
        top: calc(${x.vR} * 1px);
        background: ${D.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${D.l};
        cursor: pointer;
        font-size: ${P.K};
        line-height: ${P.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${D.l};
        font-size: ${P.K};
        line-height: ${P.Z};
        margin-inline-end: calc(${x.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${x.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${O.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${I.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${I.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${O.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${I.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${O.J_};
    }

    :host([aria-checked="true"]:${b.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${R.p}, 0 0 0 4px ${U.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new y.t(u.A`
            .checked-indicator {
                left: calc(${x.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${w.D} / 2) + ${x.vR}) + ${x.vR}) * 1px
                );
            }
        `,u.A`
            .checked-indicator {
                right: calc(${x.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${w.D} / 2) + ${x.vR}) + ${x.vR}) * 1px
                );
            }
        `),(0,v.mr)(u.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${f.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${f.A.Field};
                border-color: ${f.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${f.A.HighlightText};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${f.A.Highlight};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${f.A.HighlightText};
                border-color: ${f.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${f.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${f.A.Highlight};
            }
            :host(:${b.N}) .switch {
                border-color: ${f.A.Highlight};
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([aria-checked="true"]:${b.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${f.A.Field},
                    0 0 0 4px ${f.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${f.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${f.A.Field};
                border-color: ${f.A.GrayText};
            }
            .status-message,
            .label {
                color: ${f.A.FieldText};
            }
        `));var z=i(96950),F=i(82774),L=i(18893);const _=function(e={}){return z.qy`
        <template
            role="switch"
            aria-checked="${e=>e.checked}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            tabindex="${e=>e.disabled?null:0}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <label
                part="label"
                class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,F.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,L.R)(e.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:z.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),M=class extends h{}.compose({name:`${p.c.prefix}-switch`,template:_,styles:H})},11549(e,t,i){i.r(t),i.d(t,{RecipesSdCard(){return A},RecipesSdCardStyles(){return re},RecipesSdCardTemplate(){return q},ToolingInfo(){return ne}});var a=i(7574),s=i(4731),r=i(37180),n=i(45899),o=i(44767),c=i(73079),l=i(53755),d=i(91956),h=i(12680),p=i(56911),u=i(74998),m=i(22341),g=i(93552),b=i(38319),v=i(85349);const f="RecipesCard",w="RecipesCard_recipe",y="RecipesCard_seemore",k="RecipesCard_customization",x="RecipesCard_customization_report",T="RecipesCard_customization_hide",$="RecipesCard_customization_moresettings",C="RecipesCard_BowheadPipeline",S="RecipesCard_Customization";var R=i(29658),U=i(39671),D=i(15474);const P={Id:null,Type:"recipe-card",data:'[{"Title":"Make-Ahead Cranberry Sauce","PreperationTime":"30 min","ServingPerRecipe":"2","Rating":"4.5","RatingScale":"5","ReviewCount":"188","Calories":"676","Domain":"www.foodnetwork.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%228a03d8b3e2a54e61c6dc98aa0a986ba7%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.ed63634167eeb77a7bfce6e1654577f4","ThumbnailId":"OSK.ed63634167eeb77a7bfce6e1654577f4","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.foodnetwork.com/recipes/ina-garten/make-ahead-cranberry-sauce-3160641","DisplayName":"Food Network"},{"Title":"The Ultimate Potato Soup Recipe","PreperationTime":"30 min","ServingPerRecipe":"8","Rating":"4.98","RatingScale":"5","ReviewCount":"7","Calories":"521","Domain":"sugarspunrun.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%229030ec38b5ae70711df71d680465269c%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.ff26052e61fc8a72024fd4b53d29c47d","ThumbnailId":"OSK.ff26052e61fc8a72024fd4b53d29c47d","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://sugarspunrun.com/creamy-potato-soup-recipe/","DisplayName":"Sugar Spun Run"},{"Title":"Arancini","Rating":"0","ReviewCount":"0","Calories":"549","Domain":"www.jamieoliver.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%224e425609c043ea522fbaa3d26d9fddc4%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.4c44689e1151c802c5955998fef49e55","ThumbnailId":"OSK.4c44689e1151c802c5955998fef49e55","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.jamieoliver.com/recipes/rice/arancini/","DisplayName":"Jamie Oliver"},{"Title":"Ultimate Slow Cooker Pot Roast","PreperationTime":"8 hr 15 min","ServingPerRecipe":"8","Rating":"4.86","RatingScale":"5","ReviewCount":"344","Calories":"498","Domain":"dinnerthendessert.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%2258a799e3cf5f1360978f4a2ecca44567%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.2917be41dc5158b3dfd9de70a68a29ea","ThumbnailId":"OSK.2917be41dc5158b3dfd9de70a68a29ea","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://dinnerthendessert.com/ultimate-slow-cooker-pot-roast/","DisplayName":"Dinner Then Dessert"},{"Title":"BEST Chicken Salad","PreperationTime":"4 hr 15 min","ServingPerRecipe":"8","Rating":"4.92","RatingScale":"5","ReviewCount":"6","Calories":"360","Domain":"www.daringgourmet.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22644dc0f93ab206b3e98cd3dc637fe29c%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.f18f75d027afa0a8daea76b01c3314f3","ThumbnailId":"OSK.f18f75d027afa0a8daea76b01c3314f3","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.daringgourmet.com/classic-chicken-salad/","DisplayName":"Daring Gourmet"},{"Title":"Candied Yams Recipe","PreperationTime":"40 min","ServingPerRecipe":"6","Rating":"4.42","RatingScale":"5","ReviewCount":"48","Calories":"443","Domain":"www.lovebakesgoodcakes.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22597b08b323cf9890ba96834721503fac%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.935e2a392305c47e5bd1edfbc92520a2","ThumbnailId":"OSK.935e2a392305c47e5bd1edfbc92520a2","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.lovebakesgoodcakes.com/candied-yams-recipe/","DisplayName":"Love Bakes Good Cakes"},{"Title":"Vegan Gluten Free Cupcakes","PreperationTime":"17 min","ServingPerRecipe":"12","Rating":"5","RatingScale":"5","ReviewCount":"7","Calories":"177","Domain":"thebigmansworld.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22eec3abe61e2eae837878e4efc30f3453%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.82059e5b20aee3857abfa5c230be00bd","ThumbnailId":"OSK.82059e5b20aee3857abfa5c230be00bd","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://thebigmansworld.com/vegan-chocolate-cupcakes/","DisplayName":"The Big Man\'s World"},{"Title":"The Best Classic Zucchini Bread Recipe","PreperationTime":"1 hr 5 min","ServingPerRecipe":"12","Rating":"4.97","RatingScale":"5","ReviewCount":"15","Calories":"214","Domain":"www.thewholesomedish.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22fb2e1c1e25b956b0a1183c1c18c1fe1d%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.a36c1e1d702d33f6e46fc9776d9942f7","ThumbnailId":"OSK.a36c1e1d702d33f6e46fc9776d9942f7","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.thewholesomedish.com/the-best-classic-zucchini-bread/","DisplayName":"The Wholesome Dish"},{"Title":"One Pot Chicken Parmesan Pasta","PreperationTime":"30 min","ServingPerRecipe":"6","Rating":"4.61","RatingScale":"5","ReviewCount":"10","Calories":"582","Domain":"www.thechunkychef.com","ClickThroughUrl":"https://www.bing.com/search?q=Popular Recipes&filters=sid:%22dac84e545711b27c7564cd2eba21444d%22%20supwlcar:%221%22%20tsource:%22EntitySegments%22%20catesegtype:%22recipe%22%20segtype:%22UmVjaXBl%22%20ctype:%220%22%20mltype:%225%22%20eltypedim1:%22Recipe%22%20userscenario:%22dsb%22%20ForceHighConfRecipe:%22true%22&idpbck=1&setmkt=en-us&setlang=en&cc=us&form=recsdc","Thumbnail":{"ThumbnailUrl":"/th?id=OSK.3f088cfacd8e3acdf906819587e62003","ThumbnailId":"OSK.3f088cfacd8e3acdf906819587e62003","ThumbnailHeight":"0","ThumbnailWidth":"0","ThumbnailType":"0"},"HandOffType":"19","QSCode":"recsdc","RecipeUrl":"https://www.thechunkychef.com/one-pot-chicken-parmesan-pasta/","DisplayName":"The Chunky Chef"}]',DataType:null,Version:1,Previews:null,Badges:null,Metadata:{market:"en-us",language:"en",region:"us"},PreviewsV2:null,IsSkipped:null,PulseData:null,ClusterIds:null,AdditionalNewsContent:[],message:"",BowheadMetadata:{PipelineTag:"TEST"},debugLogs:[]};var O=i(60815),I=i(71398),H=i(58792),z=i(25109);const F=e=>`${(0,H.rA)().StaticsUrl}latest/recipes/${e}`,L=()=>F(`recipes-icon.${(0,z.ud)()?"dark":"light"}.svg`);var _=i(91224),M=i(19359),j=i(35102),B=i(41065);class A extends U.U{constructor(){super(),this.dataType="RecipesSdCard",this.isActionMenuOpen=!1,this.recipes=[],this.seeMoreUrl=new URL('https://www.bing.com/search?q=Popular Recipes&filters=userscenario:"dsb" ForceHighConfRecipe:"true"'),this.childTelemetryObjects={},this.market=(null===u.Rb||void 0===u.Rb?void 0:u.Rb.Locale)??"en-us",this.version="superSDCard",this.pageNumber=0,this.maxRecipeNumber=4}experienceConnected(){try{(0,D.uC)(this.config.cardActionWC)}catch(e){(0,m.c_)(e,g.TQ$,"Failed to load cardActionWc")}try{var e;const t=(null===(e=this.mapperArgs)||void 0===e?void 0:e.cardMetadata)??P;this.loadData(t)}catch(e){(0,m.c_)(e,g.TQ$,"Failed to load cardMetaData",e),this.recipes=null,this.pipelineName=null}this.maxRecipeNumber=this.recipes.length??0,this.dataIsValid(this.recipes)&&(this.setupTelemetryObjects(),this.initSuperSDSetting(),this.loadUI())}getLocalizedPreparationTime(e){if(!e)return"";const t=e.split(" ");if(2===t.length){const e="min"===t[1]?this.strings.minutes:this.strings.hours;return`${t[0]} ${e}`}return`${t[0]} ${this.strings.hours} ${t[2]} ${this.strings.minutes}`}loadData(e){var t;if(!e)return;const i=JSON.parse(e.data);for(let e=0;e<this.maxRecipeNumber;e++){const t=i[e].ClickThroughUrl,a=new URL(t);a.searchParams.has("setmkt")&&this.seeMoreUrl.searchParams.set("setmkt",a.searchParams.get("setmkt")),a.searchParams.has("setlang")&&this.seeMoreUrl.searchParams.set("setlang",a.searchParams.get("setlang")),a.searchParams.has("cc")&&this.seeMoreUrl.searchParams.set("cc",a.searchParams.get("cc")),a.searchParams.has("q")&&this.seeMoreUrl.searchParams.set("q",a.searchParams.get("q")),this.recipes.push({href:a.toString(),thumbnailUrl:this.getRecipeThumbnailUrl(i[e].Thumbnail),thumbnailId:i[e].Thumbnail.ThumbnailId,name:i[e].Title,hasVideo:!1,siteName:i[e].Domain,siteUrl:i[e].Domain,preparationTime:this.getLocalizedPreparationTime(i[e].PreperationTime),calorieContent:i[e].Calories,starRating:i[e].Rating,displayName:i[e].DisplayName})}this.pipelineName=(null===(t=e.BowheadMetadata)||void 0===t?void 0:t.PipelineTag)??C}loadUI(){var e,t,i,a,s,r,n,o;this.cardTelemetryObject?this.cardTelemetryObject.contract=(0,_.u)(this.dataType??"",{type:v.b5.StructuredData,vertical:"Recipe"},{ext:{...null===(i=this.parentTelemetry)||void 0===i||null===(i=i.contract)||void 0===i?void 0:i.ext,...null===(a=this.telemetryObject)||void 0===a||null===(a=a.contract)||void 0===a?void 0:a.ext,recipeList:this.recipes.map(e=>this.getSatoriId(null==e?void 0:e.href)),signature:this.getSatoriId(null===(s=this.recipes[this.pageNumber])||void 0===s?void 0:s.href)}}):this.cardTelemetryObject=(0,M.g)(this.dataType??"",{type:v.b5.StructuredData,vertical:"Recipe"},{ext:{...null===(r=this.parentTelemetry)||void 0===r||null===(r=r.contract)||void 0===r?void 0:r.ext,...null===(n=this.telemetryObject)||void 0===n||null===(n=n.contract)||void 0===n?void 0:n.ext,recipeList:this.recipes.map(e=>this.getSatoriId(null==e?void 0:e.href)),signature:this.getSatoriId(null===(o=this.recipes[this.pageNumber])||void 0===o?void 0:o.href)}});this.sdData={id:this.id,isSpotlightCard:!0,cardSize:"_1x_2y",childTemplateType:"",headerData:{headerLogo:`<img src=${L()} alt="" />`,title:this.strings.title,titleNavigationLink:this.seeMoreUrl.toString(),actionMenuData:{hideCardCallback:this.hideCardCallback.bind(this),moreSettingsPersonalizeCallback:this.moreSettingsCallback.bind(this)},telemetryContext:{headerTelemetryObject:this.getChildTelemetry({name:"header",action:v.EG.Click,behavior:v.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}),headerTitleTelemetryObject:null===(e=this.getChildTelemetry({name:"headertitle",action:v.EG.Click,behavior:v.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}))||void 0===e?void 0:e.getMetadataTag(),headerLogoTelemetryTag:null===(t=this.getChildTelemetry({name:"headerlogo",action:v.EG.Click,behavior:v.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}))||void 0===t?void 0:t.getMetadataTag(),pinTelemetryTag:this.getChildTelemetry({name:"pin",action:v.EG.Click,behavior:v.MS.Pin}),actionMenuTelemetryTag:this.getChildTelemetry({name:"actionmenu",action:v.EG.Click,behavior:v.MS.ContextMenu}),hideCard:this.getChildTelemetry({name:"hidecard",action:v.EG.Click,behavior:v.MS.Hide}),moreSettings:this.getChildTelemetry({name:"moresettings",action:v.EG.Click,behavior:v.MS.More})}},footerData:{footerLink:{text:this.strings.seeMore,navigationUrl:this.seeMoreUrl.toString()},paginationData:{currentPageIndex:this.pageNumber+1,pageCount:this.maxRecipeNumber,onFlipperClick:this.dataPaginationCallback.bind(this),onDotClick:(e,t)=>{this.pageNumber=e,this.loadUI()}},telemetryContext:{footerLink:this.getChildTelemetry({name:"footerlink",action:v.EG.Click,behavior:v.MS.Navigate,destinationUrl:this.seeMoreUrl.toString()}),previousFlipper:this.getChildTelemetry({name:"previous",action:v.EG.Click,behavior:v.MS.Paginate}),nextFlipper:this.getChildTelemetry({name:"next",action:v.EG.Click,behavior:v.MS.Paginate})}},contextualFeedbackData:this.wpoMetadata&&this.wpoMetadata.isGA?{cFId:this.wpoMetadata.cfId,cFMetadataType:this.wpoMetadata.cFMetadataType}:null,telemetryContext:{contentCard:this.getChildTelemetry({name:"SuperSDCard"})}}}isHidden(e){return e!=this.pageNumber}setupTelemetryObjects(){var e,t;if(null==this.telemetryObject)return;const i=null===(e=this.parentTelemetry)||void 0===e||null===(e=e.contract)||void 0===e?void 0:e.ext;this.recipesTelemetryObject=(0,M.g)(f,{id:f,type:v.b5.StructuredData},v.MS.View,v.EG.View,{...i,signature:this.getSatoriId(null===(t=this.recipes[this.pageNumber])||void 0===t?void 0:t.href)},{type:v.MJ.Module}),this.wholeCardTelemetryTag=this.recipesTelemetryObject.getMetadataTag();for(let e=0;e<this.maxRecipeNumber;e++)this.recipes[e].telemetryTag=(0,M.g)(w,{id:this.recipes[e].entityId,type:v.b5.StructuredData,headline:this.recipes[e].name},v.MS.Navigate,v.EG.Click,i,{type:v.MJ.ContentCard}).getMetadataTag();this.seeMoreTelemetryTag=(0,M.g)(y,{id:y,type:v.b5.StructuredData,headline:y},v.MS.Navigate,v.EG.Click,i,{type:v.MJ.Footer}).getMetadataTag(),this.actionsMenuTelemetryTag=(0,M.g)(k,{id:k,type:v.b5.StructuredData,headline:k},v.MS.More,v.EG.Click,i,{type:v.MJ.ActionButton}).getMetadataTag(),this.recipesReportTelemetryObject=(0,M.g)(x,{id:x,type:v.b5.StructuredData,headline:x},v.MS.Report,v.EG.Click,i,{type:v.MJ.ActionButton}),this.pipelineTelemetryTag=(0,M.g)(C,{id:C,type:v.b5.StructuredData,headline:this.pipelineName},v.MS.View,v.EG.View,i,{type:v.MJ.ContentCard}).getMetadataTag(),this.customizeTelemetryTag=(0,M.g)(S,{type:v.b5.StructuredData,headline:"More options"},v.MS.More,{ext:i}).getMetadataTag(),this.reportTelemetryTag=this.recipesReportTelemetryObject.getMetadataTag(),this.moreSettingTelemetryTag=(0,M.l)($,{id:$,type:v.b5.StructuredData,headline:$},v.MS.Navigate,v.EG.Click,v.MJ.ActionButton).getMetadataTag(),this.hideCardTelemetryTags=(0,M.l)(T,{id:T,type:v.b5.StructuredData,headline:T},v.MS.Hide,v.EG.Click,v.MJ.ActionButton).getMetadataTag()}shadowDomPopulated(){try{var e,t;this.cardActionRef=null===(e=this.shadowRoot)||void 0===e||null===(t=e.querySelector)||void 0===t?void 0:t.call(e,"card-action"),this.markVisuallyReadyRaf()}catch(e){(0,m.c_)(e,g.TQ$,"Failed to get cardActionRef")}}getSatoriId(e){var t;return(null===(t=new URLSearchParams(e).get("filters"))||void 0===t||null===(t=t.split(" ")[0])||void 0===t||null===(t=t.split("sid:"))||void 0===t||null===(t=t[1])||void 0===t?void 0:t.slice(1,-1))??""}getExperienceType(){return h.Lz8}getRecipeThumbnailUrl(e){return e&&e.ThumbnailUrl?"https://www.bing.com"+e.ThumbnailUrl:"https://www.bing.com/th?id=empty"}async hideCardCallback(){try{var e;if(await I.d.updateSegmentCardsEnableStatus([{cardType:R.s.RecipesCard,enabled:!1}]))null!==(e=this.mapperArgs)&&void 0!==e&&e.refreshSDCardSection?this.mapperArgs.refreshSDCardSection():this.$emit("refreshSDCardSection")}catch(e){(0,m.c_)(e,g.fKW,"Failed to call pdp service to hide card")}}moreSettingsCallback(){var e;null!==(e=this.mapperArgs)&&void 0!==e&&e.goToPersonalizeSettingsCallback?this.mapperArgs.goToPersonalizeSettingsCallback():this.$emit("goToPersonalizeSettingsCallback")}initSuperSDSetting(){const e={moreSetting:{title:this.strings.moreSettings,telemetryTag:this.moreSettingTelemetryTag},hideSetting:{title:this.strings.hideCard,telemetryTag:this.hideCardTelemetryTags}};this.superSDSetting=new b.t(A,R.s.RecipesCard,e,this.goToPersonalizeSettingsCallback,this.refreshSDCardSection)}getChildTelemetry(e){var t,i,a;null!==(t=this.childTelemetryObjects)&&void 0!==t&&t[e.name]?this.childTelemetryObjects[e.name].contract=(0,j.C)(null==e?void 0:e.name,null==e?void 0:e.behavior,null==e?void 0:e.action,{...null===(i=this.cardTelemetryObject)||void 0===i||null===(i=i.contract)||void 0===i?void 0:i.ext,...e.ext},{destinationUrl:null==e?void 0:e.destinationUrl}):this.childTelemetryObjects[e.name]=(0,B.u)(null==e?void 0:e.name,null==e?void 0:e.behavior,null==e?void 0:e.action,{...null===(a=this.cardTelemetryObject)||void 0===a||null===(a=a.contract)||void 0===a?void 0:a.ext,...e.ext},{destinationUrl:null==e?void 0:e.destinationUrl});return this.childTelemetryObjects[e.name]}dataPaginationCallback(e){const t=this.recipes.length||1,i=(this.pageNumber+(e?1:-1)+t)%t;this.pageNumber=i,this.loadUI()}handleNext(){this.pageNumber=(this.pageNumber+1)%this.maxRecipeNumber,this.currentPage=this.recipes[this.pageNumber]}handlePrev(){this.pageNumber=(this.pageNumber+this.maxRecipeNumber-1)%this.maxRecipeNumber,this.currentPage=this.recipes[this.pageNumber]}dataIsValid(e){if(!Array.isArray(e)||e.length<this.maxRecipeNumber)return!1;for(const t of e)if(!t.href||!t.name)return!1;return e.length>=0}}(0,p.Cg)([O.sH],A.prototype,"isActionMenuOpen",void 0),(0,p.Cg)([O.sH],A.prototype,"actionMenuItems",void 0),(0,p.Cg)([O.sH],A.prototype,"superSDSetting",void 0),(0,p.Cg)([O.sH],A.prototype,"sdData",void 0),(0,p.Cg)([O.sH],A.prototype,"customizeTelemetryTag",void 0),(0,p.Cg)([O.sH],A.prototype,"reportTelemetryTag",void 0),(0,p.Cg)([O.sH],A.prototype,"moreSettingTelemetryTag",void 0),(0,p.Cg)([O.sH],A.prototype,"hideCardTelemetryTags",void 0),(0,p.Cg)([O.sH],A.prototype,"pageNumber",void 0),(0,p.Cg)([O.sH],A.prototype,"currentPage",void 0);var N=i(96950),V=i(39957),E=i(69259);const K=N.qy` ${(0,V.ux)(e=>e.recipes.slice(e.pageNumber,e.pageNumber+1),N.qy`<div class="recipe_supersd_content"><a class="recipe" href="${e=>e.href}" target="_blank" @click=${(e,t)=>t.parent.handleClickCard(t.event)} data-t="${e=>e.telemetryTag}"><div class="${e=>e.hasVideo?"video":""}"><img src="${e=>e.thumbnailUrl}" alt="${e=>e.name}" height=126px width=268px /></div><div class="metadata"><div class="site">${e=>e.displayName||e.siteName}</div><div class="name" title=${e=>e.name}>${e=>e.name}</div><div class="recipe-info">${(0,E.z)(e=>e.starRating,N.qy`<div class="rating"><img class="star-icon" src="${`${(0,H.rA)().StaticsUrl}latest/fluent-icons/star_16_filled.svg`}" alt="Star Icon"/><div>${e=>Number.isInteger(Number(e.starRating))?Number(e.starRating).toFixed(1):e.starRating}</div></div>`)} ${(0,E.z)(e=>e.calorieContent||e.preparationTime,N.qy`<div class="recipe-details">${(0,E.z)(e=>e.preparationTime,N.qy`<div class="preparation-time">${e=>e.preparationTime}</div>`)} ${(0,E.z)(e=>e.calorieContent&&e.preparationTime,N.qy`<div class="dot">·</div>`)} ${(0,E.z)(e=>e.calorieContent,N.qy`<div class="nutritional-value">${(e,t)=>{var i;return`${e.calorieContent} ${(null===(i=t.parent.strings)||void 0===i?void 0:i.calorieUnit)||"cals"}`}}</div>`)}</div>`)}</div></div></a></div>`)}
`,Z=N.qy`<responsive-sd-card :data="${e=>e.sdData}" data-t=""><div class="container" slot="card-content">${K}</div></responsive-sd-card>`,q=N.qy`<div class="root" data-t="${e=>e.wholeCardTelemetryTag}">${Z}</div>`;var W=i(57416),Q=i(64003),X=i(48751),G=i(86856),J=i(74849),Y=i(22131),ee=i(4968);const te=J.A`
    .star-icon{
        --invertStarIcon: 64.84%; // #adadad
    }
`,ie=J.A`
    .star-icon{
        --invertStarIcon: 14.2%; // #242424
    }
`,ae=J.A` .more-options{right:10px}.v2 .more-options{right:16px}`,se=J.A` .more-options{left:10px}.v2 .more-options{right:16px}`,re=J.A`
:host{border-radius:calc(${W.JU} * 1px);font-family:"Segoe UI";font-size:12px;line-height:16px}@media (prefers-color-scheme:light){.v1,.v2{h5,.site,.disclaimer{color:${Q.c}}.name{color:${X.l}}}.root.rootv2{background:linear-gradient(144.59deg,rgba(200,220,243,0.1) 0%,rgba(200,220,243,0.4) 88.78%)}}@media (prefers-color-scheme:dark){.v1,.v2{.site,.disclaimer{color:${Q.c}}h5,.name{color:${X.l}}}.root.rootv2{background:linear-gradient(122.3deg,rgba(28,46,68,0.4) 0%,rgba(28,46,68,0.8) 84.48%)}}h5{margin:0;margin-bottom:24px;padding:0;height:16px;font-size:12px}a{text-decoration:none}.recipe{margin:16px 0;height:90px;display:flex;column-gap:12px}img{object-fit:cover;border-radius:calc(${W.JU} * 1px);
}

.video {
    position: relative;
}

.video::after {
    content: ' ';
    position: absolute;
    top: 4px;
    left: 4px;
    height: 20px;
    width: 20px;
    z-index: 1;
    background-size: 20px 20px;
    background-image: url('data:image/svg+xml;charset=UTF-8,<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="black" fill-opacity="0.5"/><path d="M7.5 12.9694V7.03063C7.50001 6.89073 7.53762 6.7534 7.60888 6.63301C7.68014 6.51262 7.78245 6.4136 7.9051 6.34629C8.02774 6.27898 8.16622 6.24587 8.30605 6.25041C8.44587 6.25495 8.58191 6.29699 8.69993 6.37211L13.3657 9.34148C13.4766 9.41199 13.5678 9.50932 13.631 9.62446C13.6943 9.7396 13.7274 9.86884 13.7274 10.0002C13.7274 10.1316 13.6943 10.2608 13.631 10.3759C13.5678 10.4911 13.4766 10.5884 13.3657 10.6589L8.69993 13.6279C8.58191 13.703 8.44587 13.745 8.30605 13.7496C8.16622 13.7541 8.02774 13.721 7.9051 13.6537C7.78245 13.5864 7.68014 13.4874 7.60888 13.367C7.53762 13.2466 7.50001 13.1093 7.5 12.9694Z" fill="white"/></svg>');
}

.metadata {
    min-width: 0;
}

.v2 .site {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.v1 .name,
.v2 .name {
    margin: 4px 0;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}

.recipes-footer {
    display: flex;
    justify-content: center;
}

.sd-action {
    border-radius: 20px;
    height: 24px;
    font-size: 12px;
}

.toggle-button {
    position: absolute;
    top: 12px;
    right: 10px;
    --control-corner-radius: 16;
    min-width: 24px;
    width: 24px;
    height: 24px;
    z-index: 1;
}

.more-options {
    position: absolute;
    top: 12px;
    --control-corner-radius: 16;
    min-width: 24px;
    width: 24px;
    height: 24px;
    z-index: 1;
}

msn-actions-menu {
    z-index: 700;
}

.rootV2 {
    user-select: none;
    padding: 16px 16px 12px;
    background: linear-gradient(144.59deg, rgba(200, 220, 243, 0.1) 0%, rgba(200, 220, 243, 0.4) 88.78%);
}

.v2 {
    height: 276px;
}

.v2 h5 {
    margin: 0;
    margin-bottom: 8px;
    padding: 0;
    height: 16px;
    font-size: 12px;
}

.v2 a {
    text-decoration: none;
}

.v2 a:hover .name {
    text-decoration: underline;
}

.v2 .recipe {
    height: 90px;
    display: initial;
}

.v2 img {
    object-fit: cover;
    border-radius: calc(${W.JU} * 1px);
}

.v2 .video {
    position: relative;
}

.v2 .video::after {
    content: ' ';
    position: absolute;
    top: 42px;
    left: 114px;
    height: 40px;
    width: 40px;
    z-index: 1;
    background-size: 40px 40px;
    background-image: url('data:image/svg+xml;charset=UTF-8,<svg width="40" height="40" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="10" cy="10" r="10" fill="black" fill-opacity="0.5"/><path d="M7.5 12.9694V7.03063C7.50001 6.89073 7.53762 6.7534 7.60888 6.63301C7.68014 6.51262 7.78245 6.4136 7.9051 6.34629C8.02774 6.27898 8.16622 6.24587 8.30605 6.25041C8.44587 6.25495 8.58191 6.29699 8.69993 6.37211L13.3657 9.34148C13.4766 9.41199 13.5678 9.50932 13.631 9.62446C13.6943 9.7396 13.7274 9.86884 13.7274 10.0002C13.7274 10.1316 13.6943 10.2608 13.631 10.3759C13.5678 10.4911 13.4766 10.5884 13.3657 10.6589L8.69993 13.6279C8.58191 13.703 8.44587 13.745 8.30605 13.7496C8.16622 13.7541 8.02774 13.721 7.9051 13.6537C7.78245 13.5864 7.68014 13.4874 7.60888 13.367C7.53762 13.2466 7.50001 13.1093 7.5 12.9694Z" fill="white"/></svg>');
}

.v2 .metadata {
    min-width: 0;
    margin-top: 12px;
}

.v2 .site {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.v2 .name {
    margin: 4px 0;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}

.v2 .recipes-footer {
    position: absolute;
    bottom: 12px;
    display: flex;
    justify-content: space-between;
    width: 268px;
    height: 24px;
    line-height: 24px;
}

.v2 .recipes-footer .button {
    width: 24px;
    height: 24px;
    border-radius: 1000px;
}

.prev-button, .next-button {
    background: #00000012;
    float: left;
}

.v2 .prev-button svg {
    margin: 8px 10px 8px 9px;
}

.v2 .next-button svg {
    margin: 8px 9px 8px 10px;
}

.v2 .page-number {
    margin: 0 8px;
    float: left;
}

.v2 .sd-action {
    border-radius: 20px;
    height: 24px;
    font-size: 12px;
    background-color: transparent;
}

.v2 .see-more-text {
    float: left;
}

.v2 .recipes-footer .see-more-button {
    float: right;
    margin-left: 8px;
    background: #0078D4;
}

.v2 .recipes-footer .see-more-button svg {
    margin: 8px 7px;
}

.recipe_supersd_content {
    position: absolute;
    width: 268px;
    ${ee.f} .recipe{display:flex;flex-direction:column;row-gap:16px;margin:0;height:auto;.metadata{color:${X.l};display:flex;flex-direction:column;row-gap:6px;.name{overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:1;white-space:nowrap;font-size:14px;font-style:normal;font-weight:600;line-height:20px}.recipe-info{display:flex;column-gap:8px;align-items:center;font-size:12px;color:var(--color-neutral-foreground-3);font-family:"Segoe UI";.rating{display:flex;justify-content:space-between;height:24px;padding:0px 6px 0px 4px;align-items:center;gap:2px;background-color:var(--color-neutral-background-2);border-radius:4px;font-weight:600;.star-icon{filter:invert(var(--invertStarIcon,0))}}.recipe-details{display:flex;align-items:center;column-gap:4px;font-style:normal;font-weight:400}}}}}`.withBehaviors((0,Y.G2)(te),(0,Y.C7)(ie),new G.t(ae,se)),ne={experienceConfigSchema:undefined},oe=h.Lz8;d.p&&l.L.registerExperience(oe,()=>i.e("experiences_recipes-sd-card_src_index_ts").then(i.bind(i,25314))),s.m.define(r.c.registry),n.m.define(r.c.registry),o.m.define(r.c.registry),c.m.define(r.c.registry),(0,a.d)()},13509(e,t){t.A='<svg width="15" height="15" viewBox="0 0 15 15" fill="none"><path clip-rule="evenodd" d="M7.5 9c0 .7-.24 1.33-.63 1.84l2.77 2.77a.37.37 0 1 1-.53.53l-2.77-2.77A3 3 0 1 1 7.5 9Zm-3 2.25a2.25 2.25 0 1 0 0-4.5 2.25 2.25 0 0 0 0 4.5Z"/><path clip-rule="evenodd" d="M4.13 2.25c-.21 0-.38.17-.38.38v2.7c-.26.05-.51.13-.75.23V2.63C3 2 3.5 1.5 4.13 1.5h3.8c.3 0 .6.12.8.33l2.94 2.94c.21.2.33.5.33.8v6.8c0 .63-.5 1.13-1.13 1.13h-.44c-.05-.15-.14-.3-.26-.42l-.33-.33h1.04c.2 0 .37-.17.37-.38V6H8.62C8 6 7.5 5.5 7.5 4.87V2.25H4.12Zm4.12.16v2.46c0 .21.17.38.38.38h2.46L8.25 2.41Z"/></svg>'},31422(e,t){t.A='<svg width="14" height="14" viewBox="0 0 14 14"><path d="M.4.15A.5.5 0 0 0 .37.8l.05.05 2.69 2.7A6.66 6.66 0 0 0 .46 7.36a.5.5 0 0 0 .97.25 5.66 5.66 0 0 1 2.39-3.36l1.2 1.2A2.67 2.67 0 0 0 8.8 9.25l3.95 3.94a.5.5 0 0 0 .75-.65l-.04-.05L9.37 8.4l-.8-.8L6.66 5.7 4.74 3.77l-.76-.75L1.13.15a.5.5 0 0 0-.71 0Zm5.33 6.03 2.36 2.35a1.67 1.67 0 0 1-2.36-2.35Zm1.2-3.85A6.66 6.66 0 0 0 5 2.62l.83.82a5.67 5.67 0 0 1 6.6 4.18.5.5 0 0 0 .96-.24 6.67 6.67 0 0 0-6.46-5.05Zm.13 2.34 2.53 2.54a2.67 2.67 0 0 0-2.53-2.54Z" fill-opacity=".83"/></svg>'},35102(e,t,i){i.d(t,{C(){return n},R(){return r}});var a=i(77381),s=i(93320);function r(){return(0,s.R)(...arguments)}function n(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];if(!t||t.length<2||!(0,a.P5)(t[t.length-1]))throw new Error("Invalid arguments");const r=t.pop(),n=(0,s.R)(...t);return Object.assign(n,r)}},38319(e,t,i){i.d(t,{t(){return p}});var a=i(56911),s=i(13509),r=i(31422),n=i(80541),o=i(93552),c=i(77367),l=i(60815),d=i(71398),h=i(40865);class p{constructor(e,t,i,a,s){this.menuItems=[],this.isActionMenuOpen=!1,this.actionsMenuButtonElement=null,this.onOutsideClick=e=>{const t=e.composedPath()&&e.composedPath()[0];e.target instanceof this.currentSDClass||(0,h.W)(this.actionsMenuButtonElement,t)||this.toggleActionMenu(!1,null)},this.onKeydown=e=>{"Escape"===e.code&&this.toggleActionMenu(!1,null)},this.moreSettingAction=async()=>{this.toggleActionMenu(!1,null),this.goToPersonalizeSettingsCallback&&this.goToPersonalizeSettingsCallback()},this.hideSettingAction=async()=>{if(!this.segmentSdCardType)return!1;try{const e=await d.d.updateSegmentCardsEnableStatus([{cardType:this.segmentSdCardType,enabled:!1}]);return e&&this.refreshSDCardSection&&this.refreshSDCardSection(),this.toggleActionMenu(!1,null),e}catch(e){return c.YT.sendAppErrorEvent({...o.N2u,message:`Fail to hide ${this.segmentSdCardType} Card .`,pb:{...o.N2u.pb,customMessage:`Failed with exception : ${e}`}}),!1}},this.currentSDClass=e,this.settingMenuConfig=i,this.goToPersonalizeSettingsCallback=a,this.refreshSDCardSection=s,this.menuItems=this.getBaseActionMenuItems(),this.segmentSdCardType=t}updateMenuItems(e,t){this.menuItems=t?this.menuItems.concat(e):e.concat(this.menuItems)}toggleActionMenu(e,t){this.isActionMenuOpen=e,e?(this.actionsMenuButtonElement=t&&t.currentTarget,this.setAriaExpanded(e),document.addEventListener("click",this.onOutsideClick),document.addEventListener("keydown",this.onKeydown)):(this.setAriaExpanded(e),this.actionsMenuButtonElement=null,document.removeEventListener("click",this.onOutsideClick),document.removeEventListener("keydown",this.onKeydown))}setAriaExpanded(e){this.actionsMenuButtonElement&&(this.actionsMenuButtonElement.ariaExpanded=String(e))}getBaseActionMenuItems(){var e,t;if(!this.settingMenuConfig)return[];const i=[];if(null!==(e=this.settingMenuConfig.interestSetting)&&void 0!==e&&e.onClick){const e=this.settingMenuConfig.interestSetting;i.push({glyph:r.A,title:e.title,id:"dislike",onClick:e.onClick,telemetryTag:e.telemetryTag})}if(null!==(t=this.settingMenuConfig.dataProviderSetting)&&void 0!==t&&t.onClick){const e=this.settingMenuConfig.dataProviderSetting;i.push({glyph:s.A,title:e.title,id:"dataProvider",onClick:e.onClick,telemetryTag:e.telemetryTag})}if(this.settingMenuConfig.hideSetting){const e=this.settingMenuConfig.hideSetting;i.push({glyph:r.A,title:e.title,id:"hide",onClick:e.onClick?e.onClick:()=>this.hideSettingAction(),telemetryTag:e.telemetryTag})}if(this.settingMenuConfig.moreSetting){const e=this.settingMenuConfig.moreSetting;i.push({glyph:n.A,ariaLabel:e.ariaLabel,title:e.title,id:"more",onClick:e.onClick?e.onClick:()=>this.moreSettingAction(),telemetryTag:e.telemetryTag})}return i}}(0,a.Cg)([l.sH],p.prototype,"menuItems",void 0),(0,a.Cg)([l.sH],p.prototype,"isActionMenuOpen",void 0)},43774(e,t,i){i.d(t,{p4(){return g},ls(){return b},vA(){return m},nF(){return u}});var a=i(45755),s=i(68009),r=i(95239);const{create:n}=a.G,o=n("neutral-stroke-strong-hover-delta",40),c=n("neutral-stroke-strong-active-delta",16),l=n("neutral-stroke-strong-focus-delta",25);var d=i(31023);const{create:h}=a.G,p=h({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,t,i,a,r,n){const o=(0,s.F)(t),c=e.colorContrast(t,i),l=e.closestIndexOf(c);return{rest:c,hover:e.get(l+o*a),active:e.get(l+o*r),focus:e.get(l+o*n)}}(e(d.r),e(r.p),3,e(o),e(c),e(l))}}),u=h("neutral-stroke-strong-rest",e=>e(p).evaluate(e).rest),m=h("neutral-stroke-strong-hover",e=>e(p).evaluate(e).hover),g=h("neutral-stroke-strong-active",e=>e(p).evaluate(e).active),b=h("neutral-stroke-strong-focus",e=>e(p).evaluate(e).focus)},80541(e,t){t.A='<svg width="17" height="17" viewBox="0 0 17 17"><path d="M.02 5.88A8.5 8.5 0 0 1 1.8 2.8a.5.5 0 0 1 .54-.13l1.92.68a1 1 0 0 0 1.32-.76l.37-2a.5.5 0 0 1 .39-.4 8.53 8.53 0 0 1 3.55 0 .5.5 0 0 1 .39.4l.37 2a1 1 0 0 0 1.32.76l1.91-.68a.5.5 0 0 1 .54.13 8.5 8.5 0 0 1 1.78 3.08.5.5 0 0 1-.15.54L14.5 7.74a1 1 0 0 0 0 1.52l1.55 1.32a.5.5 0 0 1 .15.54 8.5 8.5 0 0 1-1.78 3.08.5.5 0 0 1-.54.13l-1.91-.68a1 1 0 0 0-1.32.76l-.37 2a.5.5 0 0 1-.39.4 8.53 8.53 0 0 1-3.55 0 .5.5 0 0 1-.4-.4l-.36-2a1 1 0 0 0-1.32-.76l-1.92.68a.5.5 0 0 1-.54-.13 8.49 8.49 0 0 1-1.78-3.08.5.5 0 0 1 .16-.54l1.55-1.32a1 1 0 0 0 0-1.52L.18 6.42a.5.5 0 0 1-.16-.54Zm1.06 0 1.3 1.1a2 2 0 0 1 0 3.04l-1.3 1.1c.3.79.72 1.51 1.25 2.16l1.6-.58a2 2 0 0 1 2.64 1.53l.3 1.67a7.56 7.56 0 0 0 2.49 0l.3-1.67a2 2 0 0 1 2.64-1.53l1.6.57a7.5 7.5 0 0 0 1.24-2.15l-1.29-1.1a2 2 0 0 1 0-3.05l1.3-1.1a7.5 7.5 0 0 0-1.25-2.15l-1.6.57a2 2 0 0 1-2.64-1.52l-.3-1.67a7.55 7.55 0 0 0-2.49 0l-.3 1.67A2 2 0 0 1 3.93 4.3l-1.6-.57a7.5 7.5 0 0 0-1.25 2.15ZM5.62 8.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0Zm1 0a1.5 1.5 0 1 0 3 0 1.5 1.5 0 0 0-3 0Z" fill-opacity=".83"/></svg>'},91224(e,t,i){i.d(t,{u(){return r}});var a=i(77381),s=i(93320);function r(){for(var e=arguments.length,t=new Array(e),i=0;i<e;i++)t[i]=arguments[i];if(!t||t.length<3||!(0,a.P5)(t[t.length-1]))throw new Error("Invalid arguments");const r=t.pop(),n=(0,s.J)(...t);return Object.assign(n,r)}},91956(e,t,i){i.d(t,{p(){return g}});var a=i(56911),s=i(92011),r=i(38493);const n=i(74849).A` .controls{direction:ltr;display:grid;grid-auto-flow:column;grid-template-columns:min-content;grid-gap:12px}.container{padding:0 12px 12px 12px}.dark-theme-instructions{display:flex;flex-direction:column;padding:0 12px;height:100%}.dark-theme-instructions-filler{flex:1}.close-dark-theme-instructions-button{margin-bottom:12px}`;var o=i(96950),c=i(97004);const l=o.qy`<fluent-design-system-provider use-defaults fill-color=${e=>e.isDarkTheme?"#333333":"#F7F7F7"} base-layer-luminance=${e=>e.isDarkTheme?c.y.DarkMode:c.y.LightMode} direction=${e=>e.contentDirection}><div class="controls"><fluent-switch checked=${e=>"rtl"===e.contentDirection} @change=${e=>e.toggleDirection()}><span style="padding-inline-end: 8px;">Direction</span><span slot="unchecked-message">ltr</span><span slot="checked-message">rtl</span></fluent-switch><fluent-switch readonly checked=${e=>e.isDarkTheme} @click=${e=>e.showDarkThemeInstructions()}><span style="padding-inline-end: 8px;">Theme</span><span slot="checked-message">Dark</span><span slot="unchecked-message">Light</span></fluent-switch></div><div class="container" dir=${e=>e.contentDirection}><slot></slot></div><fluent-dialog hidden=${e=>!e.isDarkThemeInstructionsVisible||void 0} modal><div class="dark-theme-instructions"><div><h3>Testing dark theme</h3><p>Currently, testing dark theme requires the manual steps listed below.</p><h4>Step 1</h4><p>Open browser developer tools (CTRL+SHIFT+I).</p><h4>Step 2</h4><p>Open the command prompt (CTRL+SHIFT+P).</p><h4>Step 3</h4><p>Choose "Emulate CSS prefers-color-schema: dark" (or light).</p></div><div class="dark-theme-instructions-filler"></div><fluent-button class="close-dark-theme-instructions-button" @click=${e=>e.closeDarkThemeInstructions()}>Got it</fluent-button></div></fluent-dialog></fluent-design-system-provider>`;var d=i(2958),h=i(37180),p=i(4731),u=i(69400),m=i(7014);i(45755).G.registerDefaultStyleTarget(),d.m.define(h.c.registry),p.m.define(h.c.registry),u.m.define(h.c.registry),m.m.define(h.c.registry);let g=class extends s.L{constructor(){super(...arguments),this.isDarkTheme=!1,this.isDarkThemeInstructionsVisible=!1,this.contentDirection="ltr"}connectedCallback(){super.connectedCallback();const e=e=>{this.isDarkTheme=e};e(window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches),window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change",function(t){e(t.matches)})}toggleDirection(){this.contentDirection="ltr"===this.contentDirection?"rtl":"ltr"}showDarkThemeInstructions(){this.isDarkThemeInstructionsVisible=!0}closeDarkThemeInstructions(){this.isDarkThemeInstructionsVisible=!1}};(0,a.Cg)([(0,r.CF)({mode:"boolean"})],g.prototype,"isDarkTheme",void 0),(0,a.Cg)([(0,r.CF)({mode:"boolean"})],g.prototype,"isDarkThemeInstructionsVisible",void 0),(0,a.Cg)([r.CF],g.prototype,"contentDirection",void 0),g=(0,a.Cg)([(0,s.E)({name:"experience-local-tester",template:l,styles:n})],g)}}]);