"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_video-card-wc_dist_index_js-libs_ads-utils_dist_GDPRHelper_js-libs_views-helpers_-0300fe"],{1413(t,e,i){i.d(e,{P(){return a},y(){return r}});var o=i(96950),n=i(82774);function a(t,e){return e?.some(e=>e.slot===t)}function r(t){const e=t.slotName??"";return o.qy`
        <div id="${e}" class="${e}" part="${e}">
            <slot
                name="${e}"
                ${t.slottedRef?(0,n.e)(t.slottedRef):""}
            >
                ${t.slottedDefault??""}
            </slot>
        </div>
    `}},6632(t,e,i){i.d(e,{r1(){return L},BL(){return N},Yk(){return U}});var o=i(36514),n=i(91043),a=i(93552),r=i(68989),s=i(58792),d=i(42161),l=i(4350),h=i(74998),c=i(31756),u=i(34230),p=i(6277),v=i(43594),g=i(77367),m=i(2171),y=i(94043),b=i(50180),f=i(10526),x=i(27659),w=i(22341),P=i(85198),$=i(43570),k=i(83127);const S="Return Error while calling fetch data from super app bridge for views";function _(t){return{url:t,error:arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},medataData:arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},responseHeader:arguments.length>3&&void 0!==arguments[3]?arguments[3]:{},activityId:s.T3.ActivityId}}async function C(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:null,i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:1e3,o=arguments.length>3&&void 0!==arguments[3]&&arguments[3];try{let n={};o&&(n=await(0,$.U)()),n[l.aS.activityId]=s.T3.ActivityId;const r={url:t,headers:n,needHeader:!0,processError:!0};if(window.navigator.onLine&&(r.refresh=!0),e){const t=`${"news/contentview"}/${e}`;r.cacheKey=t}const d=await function(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:new Error("Promise timed out");const o=new Promise((t,o)=>{setTimeout(()=>{o(i)},e)});return Promise.race([t,o])}((0,k.XN)(r),i);if(!d)return(0,w.vV)(a.TXh,S,"Return empty response while calling fetch from super app bridge",_(t,"",r)),null;const h=JSON.parse(d),{header:c,result:u,body:p,error:v}=h,g=c&&JSON.parse(c);if(v)return(0,w.vV)(a.n6e,S,"Return Error while calling fetch from super app bridge",_(t,v,r,g)),null;if("Success"!==u)return(0,w.vV)(a.uSS,S,"Return not success result while calling fetch from super app bridge",_(t,v,r,g)),null;if(!p)return(0,w.vV)(a.KkS,S,"Get empty body while calling fetch from super app bridge",_(t,v,r,g)),null;return p&&JSON.parse(p)}catch(e){return(0,w.vV)(a.k5z,S,"Error while calling fetch from super app bridge",_(t,e)),null}}const A="ViewsSAFetch";var T=i(38001);const I={"prg-cvvariant1":"e2etest1","prg-cvslmformat0":"slmformat0"};var E,V;!function(t){t.ArticleDataApi="api/article/",t.ContentDetail="view/v2/Detail/",t.ContentDetailWithLocale="view/v2/Detail/{0}/",t.ContentFull="view/v1/Full/",t.ContentV1Detail="view/v1/Detail/",t.ContentV2DetailWithLocale="view/v2/Detail/{0}/",t.ContentPreviewApi="https://api.msn.com/msn/contentpreviews?ids=",t.ContentProvider="view/v2/provider/",t.ImagesDataApi="api/images/",t.ProviderFeedApiFormat="news/providers/{0}/items",t.ContentFromVerticalDataApi="msn/feed",t.SearchCMSApi="v1/cms/api/amp/search"}(E||(E={}));class z extends Error{}class D extends Error{}!function(t){t.Main="Main",t.Embed="Embed",t.Scroll="Scroll",t.Other="Other"}(V||(V={}));class F{static get instance(){return m.vv.get(this.instanceKey)}static set instance(t){m.vv.set(this.instanceKey,t)}constructor(){this.cache=new Map}static getInstance(){return this.instance||(this.instance=new F),this.instance}get(t){return this.cache.get(t)}set(t,e){this.cache.set(t,e)}clear(){this.cache.clear()}}F.instanceKey=Symbol("instance");const M=(0,y.S)()?window.fetch.bind(window):r.GC,O=(0,o.xS)({fetchImpl:M}),L=async function(t,e){let i=arguments.length>2&&void 0!==arguments[2]&&arguments[2],o=arguments.length>3&&void 0!==arguments[3]&&arguments[3],n=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"Main";const{url:a,requestInit:r}=await R(t,e,o);return j(a.href,!0,r,i,n,t)},R=async(t,e,i)=>{if((0,T.bK)()){const e={method:"GET",credentials:"include",headers:await c.WR.getOneServiceHeaders()};return{url:new URL(`/ingestion/preview/internal/${t}`,"https://api.msn.com"),requestInit:e}}if(i)return{url:B(t,e),requestInit:null};let o=new URL(`${(0,b.GP)(E.ContentDetailWithLocale,e)}${t}`,s.T3.ContentServiceUrlBase);return o=function(t,e){for(const[i,o]of Object.entries(I))if(e.has(i)){t.searchParams.append("variant",o);break}return t}(o,(0,T.oO)()),{url:o,requestInit:null}},B=(t,e)=>{const i=new URL("/msn/contentviews/","https://api.msn.com");return i.searchParams.append("ids",t),i.searchParams.append("market",e),i.searchParams.append("ocid",(0,d.En)()||""),i.searchParams.append("apikey",s.T3.OneServiceApiKey),i.searchParams.append("viewType","Detail"),i},N=function(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"Other";const o=new URL(`${(0,b.GP)(E.ContentV2DetailWithLocale,e)}${t}`,s.T3.ContentServiceUrlBase);return j(o.href,!0,null,!0,i)},U=(t,e)=>{const i=[{key:"$select",value:"sourceId"},{key:"timeOut",value:"1000"},{key:s.T3.OneServiceContentMarketQspKey,value:s.T3.CurrentMarket},{key:"query",value:`${t}`},{key:"contentType",value:"video"},{key:"$top",value:"16"}];return H(i,E.ContentFromVerticalDataApi,e)},j=function(t){let e,i,o,r,s,d=arguments.length>1&&void 0!==arguments[1]&&arguments[1],h=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,p=arguments.length>3&&void 0!==arguments[3]&&arguments[3],m=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"Other",y=arguments.length>5&&void 0!==arguments[5]?arguments[5]:null;if(F.getInstance().get(t))return F.getInstance().get(t);const b=(0,u.w)(async()=>{try{var d;if((0,P.RH)()){n.M.startMark(A);const e=await C(t,y);if(n.M.endMark(A),n.M.clearMeasures(A),e)return e;g.YT.sendAppErrorEvent({...a.RBD,message:`Fallback to native fetch from sapphire fetch for url ${t}.`})}const u="Main"===m,b=h||await c.WR.getBaseRequestData("GET");b.urlMapper=u?v._H:v.aJ;const f=await O(t,b);if(f.headers&&(e=f.headers.get(l.pc.debugId),i=f.headers.get("akamai-request-id"),o=f.headers.get("akamai-server-ip"),r=f.headers.get("x-ceto-ref")),!f.ok){const n=f.status,s=`"Failed to get data from ${t}. Status: ${n} ${f.statusText}`;let d;x.v.logError(s);let l=G(m);return 404===n?(u&&(l=a.RTA),d=new D(s)):410===n?(l=Y(t)?a.XXk:W(m),d=new z(s)):d=new Error(s),g.YT.sendAppErrorEvent({...l,message:"Failed to get data",pb:{...l.pb,customMessage:s,status:n,stack:d.stack,debugId:e,akRequestId:i,akServerIp:o,xCetoRef:r}}),p?d:void 0}if(null!==(d=f.headers)&&void 0!==d&&d.get("X-Statics-Fallback")){const n=`Response from ${t} fell back to statics on page ${window.location.href}`;x.v.logError(n),g.YT.sendAppErrorEvent({...a.vDo,message:"Content view API fell back to static content",pb:{...a.vDo.pb,customMessage:n,fetchUrl:t,pageUrl:window.location.href,debugId:e,akRequestId:i,akServerIp:o,xCetoRef:r}})}return q()&&(s=f.clone()),f.json()}catch(n){const a=G(m);return g.YT.sendAppErrorEvent({...a,message:"Failed to get data",pb:{...a.pb,customMessage:`${t}. Error: ${n}`,stack:n.stack,debugId:e,akRequestId:i,akServerIp:o,xCetoRef:r}}),q()&&void 0!==s&&J(s,t,e,i,o,r),n.responseHeaders={debugId:e,akRequestId:i,akServerIp:o,xCetoRef:r},p?n:void 0}},"fetchDocumentAsync").catch(n=>{throw d&&F.getInstance().set(t,void 0),q()&&void 0!==s&&J(s,t,e,i,o,r),n.responseHeaders={debugId:e,akRequestId:i,akServerIp:o,xCetoRef:r},n});return d&&F.getInstance().set(t,b),b},G=t=>{switch(t){case"Main":return a.DqN;case"Embed":return a.AMA;case"Scroll":return a.L6k;default:return a.ANf}},W=t=>{switch(t){case"Main":return a.ZEA;case"Embed":return a.YSB;case"Scroll":return a.Vgs;default:return a.Y1H}},H=async(t,e,i)=>{const o={method:"GET",credentials:"include",headers:await c.WR.getOneServiceHeaders()},n=2===await(0,f.XK)(),r=n?c.WR.getOneServiceParamsWithAuth(s.T3.UserId,i,!1):c.WR.getOneServiceParamsWithoutAuth(s.T3.UserId,i,!1);n&&(o.credentials="include");const d=[...r,...t],l=(0,p.nI)(e);d.forEach(t=>t.value&&l.searchParams.set(t.key,t.value));const h=await(0,u.w)(async()=>{const t=l.href;try{const e=await O(t,o);if(!e.ok){const i=`"Failed to get data from ${t}. Status: ${e.statusText}`;return void g.YT.sendAppErrorEvent({...a.DqN,message:"Failed to get data",pb:{...a.DqN.pb,customMessage:i}})}return e}catch(e){g.YT.sendAppErrorEvent({...a.DqN,message:"Failed to get data",pb:{...a.DqN.pb,customMessage:`${t}. Error: ${e}`}})}},"fetchContentsFromOneServiceAsync");return h&&h.json()},Y=t=>{const e=t.split("/")[8]??"";return v.S1.includes(e)},q=()=>{var t;return null===(t=h.Rb.CurrentFlightSet)||void 0===t?void 0:t.has("prg-log-ctvd-res")},J=(t,e,i,o,n,r)=>{t.text().then(t=>{(0,w.vV)(a.TJ,`Content view API response: ${t}`,void 0,{...a.TJ.pb,fetchUrl:e,pageUrl:window.location.href,debugId:i,akRequestId:o,akServerIp:n,xCetoRef:r})})}},9368(t,e,i){i.d(e,{RenminPlayer(){return l}});var o=i(2171),n=i(93552),a=i(22341),r=i(17852),s=i(11206),d=i(93940);class l extends s.a{constructor(){super(...arguments),this.playerReadyFlag=!1,this.type="Renmin",this.loadPlayerScripts=t=>(l.loadPromise||(l.loadPromise=(0,r.k)({id:l.scriptId,src:l.scriptSrc,retryNumber:t?5:0,retryDelayMs:t?200:0})),l.loadPromise),this.createEvents=t=>({onReady:e=>{d.M.set(this.instance,e.videoConfig.duration),0==this.playerReadyFlag&&(t(),this.perfObserver.mark("ready"),this.perfObserver.mark("loaded"),window.setTimeout(()=>this.triggerEvent("ready",this.normalizeEvent()))),this.playerReadyFlag=!0},onStateChange:this.onStateChange,onTimeUpdate:this.onTimeUpdate,onError:t=>{var e;const i={...t??{},innerId:null===(e=this.playerInfo.video)||void 0===e?void 0:e.id},o=JSON.stringify(i);(0,a.vV)(n.EX5,o,"An error occurred during playing a Renmin video.")},onVolumeChange:this.onVolumeChange}),this.triggerAdStart=()=>{this.triggerEvent("AdPlayStarted",this.normalizeEvent())},this.triggerAdFinish=()=>{this.triggerEvent("AdPlayCompleted",this.normalizeEvent())},this.triggerAdSkipped=()=>{this.triggerEvent("AdPlaySkipped",this.normalizeEvent())},this.triggerAdSlotEnded=t=>{this.triggerEvent("AdSlotEnded",this.normalizeEvent(void 0,t))},this.setIsAdsPlying=t=>{this._isAdsPlying=t},this.onTimeUpdate=t=>{this.triggerEvent("timeupdate",this.normalizeEvent(t))},this.onStateChange=t=>{const e=t.playerState,{ENDED:i,PLAYING:o,PAUSED:n}=window.PD.PLAYER_STATE,a=this.normalizeEvent(t);switch(e){case i:this.triggerEvent("ended",a);break;case o:{const t=this.wasPaused?"resume":"play";this.wasPaused=!1,this.triggerEvent(t,a);break}case n:this.wasPaused=!0,this.triggerEvent("pause",a)}},this.onVolumeChange=t=>{this.triggerEvent("volumechange",this.normalizeEvent(t))},this.normalizeEvent=(t,e)=>{const i=this.createContentEvent(),{content:o}=i,n=(null==t?void 0:t.playerState)??this.instance.getPlayerState(),a=(null==t?void 0:t.videoConfig.currentTime)??this.instance.getCurrentTime()??0;return{...i,...e??{},isPlayerPaused:n===window.PD.PLAYER_STATE.PAUSED,content:{...o,videoPositionSec:a,title:this.instance.videoTitle??o.title,videoDuration:d.M.get(this.instance)??o.videoDuration},originEvent:t}}}static get loadPromise(){return o.vv.get(this.loadPromiseKey)}static set loadPromise(t){o.vv.set(this.loadPromiseKey,t)}static get scriptSrc(){return o.vv.get(this.scriptSrcKey,()=>`https://micvideo.peopletech.cn/static/jssdk/pd-player-min.js?t=${Date.now()}`)}static set scriptSrc(t){o.vv.set(this.scriptSrcKey,t)}static get scriptId(){return o.vv.get(this.scriptIdKey,()=>"RenminVideoPlayerSDK")}static set scriptId(t){o.vv.set(this.scriptIdKey,t)}async initialize(t){var e;const{container:i,playerInfo:o}=t,r=i.clientHeight,s=i.clientWidth;try{await this.loadPlayerScripts(t.shouldUseRetryWithDelay)}catch(t){(0,a.vV)(n.EX5,JSON.stringify(t),"An error occurred during loading Renmin sdk.")}if(null!==(e=window.PD)&&void 0!==e&&e.Player)return new Promise(t=>{var e;const n=new window.PD.Player(i,{height:String(r),width:String(s),events:this.createEvents(t)});n[Symbol("identifier")]=null===(e=o.video)||void 0===e?void 0:e.id,super.init(n,i,o)})}play(){super.play(),this.instance.play()}pause(){super.pause(),this.instance.pause()}setMute(t){t?this.instance.mute():this.instance.unmute()}setVolume(t){const e=this.normalizeVolume(t);this.instance.setVolume(e)}seekBySeconds(t){throw new Error(`seekBySeconds is not implemented for this player, cannot seek ${t} seconds`)}get isMuted(){return this.instance.isMuted()}get volume(){const t=this.instance.getVolume();return this.normalizeVolume(t)}get canProvideVideoPosition(){return!0}get shouldEmulateTimeUpdate(){return!0}createTimeUpdateEventData(){return this.normalizeEvent()}dispose(){this.instance.destroy(),super.dispose()}}l.loadPromiseKey=Symbol("loadPromise"),l.scriptSrcKey=Symbol("scriptSrc"),l.scriptIdKey=Symbol("scriptId"),l.buildIframeSrc=(t,e)=>{const i=new URL(t);return i.searchParams.set("mute","1"),e&&i.searchParams.set("autoplay","1"),i.href}},11206(t,e,i){i.d(e,{a(){return l}});var o=i(2171),n=i(22341),a=i(93552),r=i(24752);class s{constructor(){this.initTime=0,this._markers={},this._timeToStartObserver=new r.H}get markers(){return this._markers}get timeToStartObserver(){return this._timeToStartObserver}get bufferWaitTime(){return(async()=>{const t=await this.videoStartupTime,e=this.markers.loaded;if(e&&t)return t>=e?t-e:t})()}get videoStartupTime(){return this.timeToStartObserver.getTimeToPlay()}init(){this.initTime=performance.now()}dispose(){this.initTime=0,this._markers={},this.timeToStartObserver.unobserve()}mark(t,e){this._markers[t]=Math.round(performance.now()-this.initTime-(e??0))}}var d=i(87440);class l{constructor(){this.lastContentContinueTimeSec=0,this.eventListeners=new Map,this.previousVideoPosition=0,this.watchedSec=0,this._volume=0,this._isMuted=!0,this.isClosedCaptionEnabled=!1,this._isAdsPlying=!1,this.wasPaused=!1,this.hasStartedPlaying=!1,this._isPlaying=!1,this._perfObserver=new s,this._isAdShown=!1,this.enableContentContinueEventEmulation=()=>{this.addEventListener("timeupdate",(t,e,i)=>{const o=this.watchedSec;o-this.lastContentContinueTimeSec<l.contentContinueEventIntervalSec||(this.lastContentContinueTimeSec=o,this.triggerEvent("contentContinue",i))})},this.logPlayStartError=(t,e)=>{var i;if(null===(i=this.htmlElement)||void 0===i||!i.isConnected)return;const{id:o,title:a,provider:r,sourceId:s,isWebContent:d,recoId:l}=this.playerInfo.video;(0,n.vV)(t,e,"",{id:o,title:a,provider:r,sourceId:s,isWebContent:d,recoId:l})}}static get timeThresholdSec(){return o.vv.get(this.timeThresholdSecKey,()=>.1)}static set timeThresholdSec(t){o.vv.set(this.timeThresholdSecKey,t)}static get contentContinueEventIntervalSec(){return o.vv.get(this.contentContinueEventIntervalSecKey,()=>20)}static set contentContinueEventIntervalSec(t){o.vv.set(this.contentContinueEventIntervalSecKey,t)}init(t,e,i,o){this.perfObserver.init(),this.htmlElement=e;const n=o||e.parentElement;if(!n)throw new Error("Telemetry target is not found");this.setTelemetryTarget(n),this.player=t,this.setPlayerInfo(i),this.shouldEmulateTimeUpdate&&this.enableTimeUpdateEventEmulation(),this.enableWatchTimeCounting(),this.enableContentContinueEventEmulation(),i.isAutoplay&&this.measureTimeToStart()}play(){this.measureTimeToStart()}pause(){this.perfObserver.timeToStartObserver.unobserve()}requestPictureInPicture(){}setMute(t){this._isMuted=t}setVolume(t){this._volume=t}setClosedCaptions(t){this.isClosedCaptionEnabled=t}seekBySeconds(t){throw new Error(`seekBySeconds is not implemented for this player, cannot seek ${t} seconds`)}addEventListener(t,e,i){if("function"!=typeof e)throw new Error("Listener must be a function");const o=Array.isArray(t)?t:[t];for(const t of o){var n;this.eventListeners.has(t)||this.eventListeners.set(t,[]),null===(n=this.eventListeners.get(t))||void 0===n||n.push({listener:e,options:i})}}removeEventListener(t,e){if("function"!=typeof e)return;const i=Array.isArray(t)?t:[t];for(const t of i){const i=this.eventListeners.get(t);i&&this.eventListeners.set(t,i.filter(t=>t.listener!==e))}}setPlayerInfo(t){this.playerInfoStorage=t}updatePlayerInfo(t){(0,d.A)(this.playerInfoStorage,t)}resetPlayer(){this.previousVideoPosition=0,this.lastContentContinueTimeSec=0,this.watchedSec=0,this.hasStartedPlaying=!1,this.wasPaused=!1}setTelemetryTarget(t){this.telemetryTarget=t}dispose(){this.perfObserver.dispose(),clearTimeout(this.timeUpdateIntervalId),this.eventListeners.clear(),this.htmlElement=void 0,this.player=void 0,this._isPlaying=!1}get enableLeadsGenVideoAds(){var t;return null===(t=this.playerInfo.useLeadsGenVideoAds)||void 0===t?void 0:t.includes(this.type.toLowerCase())}get instance(){if(!this.player)throw new Error("Player is not initialized or was disposed. Please call init() first.");return this.player}get width(){var t;return(null===(t=this.htmlElement)||void 0===t?void 0:t.clientWidth)??0}get height(){var t;return(null===(t=this.htmlElement)||void 0===t?void 0:t.clientHeight)??0}get isAdsPlying(){return this._isAdsPlying}get isAdShown(){return this._isAdShown}get watchedTimeSec(){return this.watchedSec}get lastVideoPositionSec(){return this.previousVideoPosition}get htmlEl(){return this.htmlElement}get telemetryTargetElement(){if(!this.telemetryTarget)throw new Error("Telemetry target is not set");return this.telemetryTarget}get isMuted(){return this._isMuted}get volume(){return this._volume}get colorSample(){return this.playerInfo.video.colorSample}get playerInfo(){if(!this.playerInfoStorage)throw new Error("Player info is not set");return this.playerInfoStorage}get isPlaying(){return this._isPlaying}get perfObserver(){return this._perfObserver}triggerEvent(t,e){if(!t)throw new Error("Event type cannot be empty.");const i=this.eventListeners.get(t)??[];for(const{listener:o,options:r}of i)try{o(this,t,e),this.postProcessListenerOptions(o,t,r)}catch(e){const i=e instanceof Error?e:new Error(String(e));(0,n.c_)(i,a.TmI,"An unknown error while executing an video player event listener.",void 0,{eventType:t,playerType:this.type,video:this.playerInfo.video})}}normalizeVolume(t){return t>1?Math.min(t,100)/100:t}createContentEvent(){const{id:t,title:e,durationSec:i,provider:o,categories:n,sourceId:a,recoId:r,isWebContent:s,isContentBingmm:d,isVideoPreview:l=!1,isPartnerEmbed:h,url:c}=this.playerInfo.video,{isInline:u,isLocal:p,isFirstVideoFromPlaylist:v}=this.playerInfo;return{isPlayerPaused:this.wasPaused,content:{videoId:t,title:e,videoPositionSec:0,videoDuration:i,videoWidth:this.width,videoHeight:this.height,sourceId:a,isWebContent:s,isContentBingmm:d,isLocal:p,provider:o,categories:n,recoId:r,isPartnerEmbed:h,videoUrl:c,isVideoPreview:l},isInline:u,isFirstVideoFromPlaylist:v}}enableTimeUpdateEventEmulation(){this.addEventListener(["play","resume"],()=>{this.timeUpdateIntervalId&&clearInterval(this.timeUpdateIntervalId);let t=performance.now();this.timeUpdateIntervalId=window.setInterval(()=>{const e=this.createTimeUpdateEventData();if(!this.canProvideVideoPosition){const i=performance.now(),o=(i-t)/1e3;e.content.videoPositionSec=this.previousVideoPosition+o,t=i}const{content:{videoPositionSec:i}}=e;Math.abs(i-this.previousVideoPosition)<l.timeThresholdSec||this.triggerEvent("timeupdate",e)},1e3)}),this.addEventListener(["pause","ended"],()=>{clearInterval(this.timeUpdateIntervalId)})}seekingThresholdInSeconds(){return 5}enableWatchTimeCounting(){const t=this.seekingThresholdInSeconds();this.addEventListener(["play","resume","pause","timeupdate","ended"],(e,i,o)=>{if(this.isAdsPlying)return;const{content:{videoPositionSec:n},isPlayerPaused:a}=o;switch(i){case"play":case"resume":this._isPlaying=!0,this.previousVideoPosition=n;break;case"pause":case"ended":this._isPlaying=!1,this.previousVideoPosition=n;break;case"timeupdate":{const e=n-this.previousVideoPosition;a||e<0||e>t||(this.watchedSec+=e),this.previousVideoPosition=n;break}}})}async measureTimeToStart(){this.canProvideVideoPosition&&this.perfObserver.timeToStartObserver.measure(()=>{try{var t;return(null===(t=this.createTimeUpdateEventData())||void 0===t?void 0:t.content.videoPositionSec)||0}catch(t){return 0}},()=>{try{return this.perfObserver.markers.adPlayStarted||0}catch(t){return 0}},()=>this.logPlayStartError(a.g3N,`VST Error: Video not started before timeout threshold of ${r.q.timeout}ms`))}postProcessListenerOptions(t,e,i){if(!i)return;const{once:o}=i;o&&this.removeEventListener(e,t)}}l.timeThresholdSecKey=Symbol("timeThresholdSec"),l.contentContinueEventIntervalSecKey=Symbol("contentContinueEventIntervalSec")},11310(t,e,i){i.d(e,{W(){return g}});var o=i(56911),n=i(71008),a=i(50866),r=i(95239),s=i(14475),d=i(92011),l=i(47429),h=i(60815),c=i(87122),u=i(74849),p=i(22870),v=i(38493);class g extends d.L{constructor(){super(...arguments),this.headingLevel=2,this.immersiveCard=!1,this.animateVideo=!1,this.subscribed=!1,this.target=s.z._blank,this.mediaSlot=[],this.loaded=!1,this.gradientVariables=null,this.cardSize=()=>this.size?this.size:this.parent&&this.parent instanceof n.h?this.parent.size:a.qJ._1x_2y,this.colorSwatch=()=>{if(this.parent&&this.parent instanceof n.h)return this.parent.cardFillColor??r.p.getValueFor(this.parent).toColorString()}}animateVideoChanged(){this.loaded=!0}isColorSampled(){return!!(this.parent&&this.parent instanceof n.h)&&!!this.parent.cardSecondaryColor}generateGradientVariables(t){let e,i;return this.isColorSampled()?(e=new c.M(t.r,t.g,t.b,0).toStringWebRGBA(),i=new c.M(t.r,t.g,t.b,.8).toStringWebRGBA()):(e=new c.M(0,0,0,0).toStringWebRGBA(),i=new c.M(0,0,0,.54).toStringWebRGBA()),u.A`
            :host {
                --image-gradient-overlay-start-color: ${e};
                --image-gradient-overlay-end-color: ${i};
            }
        `}handleContentCardLinkClick(t){return this.$emit("link-invoked",t),!0}connectedCallback(){super.connectedCallback(),this.parent=(0,l.Zo)(this),!this.parent||this.parent instanceof n.h||(this.parent=(0,l.Zo)(this.parent)),this.parent&&(this.handleChange(),h.cP.getNotifier(this.parent).subscribe(this,"cardFillColor"),h.cP.getNotifier(this.parent).subscribe(this,"cardSecondaryColor"),h.cP.getNotifier(this.parent).subscribe(this,"size"))}handleChange(){if(this.size=this.cardSize(),this.cardColor=this.colorSwatch(),this.cardColor){const t=(0,p.Hs)(this.cardColor);this.gradientVariables&&this.$fastController.removeStyles(this.gradientVariables),t&&(this.gradientVariables=this.generateGradientVariables(t),this.$fastController.addStyles(this.gradientVariables))}}}(0,o.Cg)([(0,v.CF)({attribute:"heading-level",mode:"fromView",converter:v.R$}),(0,o.Sn)("design:type",Number)],g.prototype,"headingLevel",void 0),(0,o.Cg)([v.CF,(0,o.Sn)("design:type",String)],g.prototype,"size",void 0),(0,o.Cg)([(0,v.CF)({attribute:"immersive-card",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],g.prototype,"immersiveCard",void 0),(0,o.Cg)([(0,v.CF)({attribute:"media-type"}),(0,o.Sn)("design:type",Object)],g.prototype,"mediaType",void 0),(0,o.Cg)([(0,v.CF)({attribute:"animate-video",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],g.prototype,"animateVideo",void 0),(0,o.Cg)([(0,v.CF)({attribute:"subscribed",mode:"boolean"}),(0,o.Sn)("design:type",Boolean)],g.prototype,"subscribed",void 0),(0,o.Cg)([v.CF,(0,o.Sn)("design:type",Object)],g.prototype,"href",void 0),(0,o.Cg)([v.CF,(0,o.Sn)("design:type",String)],g.prototype,"target",void 0),(0,o.Cg)([h.sH,(0,o.Sn)("design:type",Array)],g.prototype,"childElements",void 0),(0,o.Cg)([h.sH,(0,o.Sn)("design:type",Array)],g.prototype,"mediaSlot",void 0),(0,o.Cg)([h.sH,(0,o.Sn)("design:type",Object)],g.prototype,"parent",void 0),(0,o.Cg)([h.sH,(0,o.Sn)("design:type",Boolean)],g.prototype,"loaded",void 0),(0,o.Cg)([h.sH,(0,o.Sn)("design:type",String)],g.prototype,"anchorTelemetryTag",void 0)},24197(t,e,i){i.d(e,{YiDianPlayer(){return l}});var o=i(2171),n=i(93552),a=i(22341),r=i(17852),s=i(11206);const d={map:{},getInstanceId(t){const e=Object.getOwnPropertySymbols(t).find(t=>"Symbol(identifier)"===t.toString());if(e)return t[e]},get(t){const e=this.getInstanceId(t);return e&&this.map[e]},set(t,e){const i=this.getInstanceId(t);i&&!this.map[i]&&(this.map[i]=e)}};class l extends s.a{constructor(){super(...arguments),this.playerReadyFlag=!1,this.executionQueue=[],this.type="Yidianzixun",this.loadPlayerScripts=t=>(l.loadPromise||(l.loadPromise=new Promise(e=>(window.onYiDianIframeAPIReady=e,(0,r.k)({id:l.scriptId,src:l.scriptSrc,retryNumber:t?5:0,retryDelayMs:t?200:0})))),l.loadPromise),this.createEvents=t=>({onReady:e=>{if(d.set(this.instance,e.data.duration),0==this.playerReadyFlag){t(),this.perfObserver.mark("ready"),this.perfObserver.mark("loaded");const e=window.setTimeout(()=>{this.triggerEvent("ready",this.normalizeEvent()),this.executeAllTriggerEvent(),window.clearTimeout(e)})}this.playerReadyFlag=!0},onStateChange:this.onStateChange,onTimeUpdate:this.onTimeUpdate,onError:t=>{var e;const i={...t.data??{},innerId:null===(e=this.playerInfo.video)||void 0===e?void 0:e.id},o=JSON.stringify(i);(0,a.vV)(n.tDh,o,"An error occurred during playing a Yidian video.")},onVolumeChange:this.onVolumeChange,onWheelEvent:this.triggerWheel,onCanplayEvent:this.handleOnCanPlayEvent}),this.handleOnCanPlayEvent=()=>{this.addExecutionCallback("canplay",this.normalizeEvent())},this.triggerAdStart=()=>{this.triggerEvent("AdPlayStarted",this.normalizeEvent())},this.triggerAdFinish=()=>{this.triggerEvent("AdPlayCompleted",this.normalizeEvent())},this.triggerAdSkipped=()=>{this.triggerEvent("AdPlaySkipped",this.normalizeEvent())},this.triggerWheel=t=>{this.triggerEvent("wheel",t.data)},this.triggerAdSlotEnded=t=>{this.triggerEvent("AdSlotEnded",this.normalizeEvent(void 0,t))},this.setIsAdsPlying=t=>{this._isAdsPlying=t},this.onTimeUpdate=()=>{this.triggerEvent("timeupdate",this.normalizeEvent())},this.onStateChange=t=>{const e=t.data,{Ended:i,Playing:o,Paused:n}=window.YD.PlayerState,a=this.normalizeEvent();switch(e){case i:this.triggerEvent("ended",a);break;case o:{const t=this.wasPaused?"resume":"play";this.wasPaused?this.triggerEvent(t,a):this.addExecutionCallback(t,a),this.wasPaused=!1;break}case n:this.wasPaused=!0,this.triggerEvent("pause",a)}},this.onVolumeChange=t=>{this.triggerEvent("volumechange",this.normalizeEvent(t))},this.normalizeEvent=(t,e)=>{const i=this.createContentEvent(),{content:o}=i;return{...i,...e??{},isPlayerPaused:this.instance.getPlayerState()===window.YD.PlayerState.Paused,content:{...o,videoPositionSec:this.instance.getCurrentTime()??0,title:this.instance.videoTitle??o.title,videoDuration:d.get(this.instance)??o.videoDuration},originEvent:t}}}static get loadPromise(){return o.vv.get(this.loadPromiseKey)}static set loadPromise(t){o.vv.set(this.loadPromiseKey,t)}static get scriptSrc(){return o.vv.get(this.scriptSrcKey,()=>`https://static.yidianzixun.com/modules/msn/yidian_iframe_api.js?t=${Date.now()}`)}static set scriptSrc(t){o.vv.set(this.scriptSrcKey,t)}static get scriptId(){return o.vv.get(this.scriptIdKey,()=>"YiDianVideoPlayerSDK")}static set scriptId(t){o.vv.set(this.scriptIdKey,t)}async initialize(t){const{container:e,playerInfo:i,isAutoplay:o}=t,n=e.clientHeight,a=e.clientWidth;return await this.loadPlayerScripts(t.shouldUseRetryWithDelay),new Promise(t=>{const r=new window.YD.Player(e,{height:String(n),width:String(a),autoplay:o?1:0,events:this.createEvents(t)});super.init(r,e,i)})}play(){(!(arguments.length>0&&void 0!==arguments[0])||arguments[0])&&super.play(),this.instance.playVideo()}pause(){super.pause(),this.instance.pauseVideo()}setMute(t){t?this.instance.muteVideo():this.instance.unmuteVideo()}setVolume(t){const e=this.normalizeVolume(t);this.instance.setVolume(e)}seekBySeconds(t){throw new Error(`seekBySeconds is not implemented for this player, cannot seek ${t} seconds`)}get isMuted(){return this.instance.isMuted()}get volume(){const t=this.instance.getVolume();return this.normalizeVolume(t)}get canProvideVideoPosition(){return!0}get shouldEmulateTimeUpdate(){return!0}createTimeUpdateEventData(){return this.normalizeEvent()}addExecutionCallback(t,e){this.playerReadyFlag?this.triggerEvent(t,e||this.normalizeEvent()):this.executionQueue.push(t)}executeAllTriggerEvent(){this.executionQueue.length&&(this.executionQueue.forEach(t=>{this.triggerEvent(t,this.normalizeEvent())}),this.executionQueue.length=0)}dispose(){this.instance.destroy(),super.dispose()}}l.loadPromiseKey=Symbol("loadPromise"),l.scriptSrcKey=Symbol("scriptSrc"),l.scriptIdKey=Symbol("scriptId"),l.buildIframeSrc=(t,e)=>{try{const i=new URL(t).pathname.split("/"),o=i[i.length-1],n=new Map([["s","op1259"],["appid","s3rd_op1259"],["pureContent",1],["muted",1],["autoplay",e?1:0],["origin",window.location.origin]]);return`https://doris.yidianzixun.com/article/${o}?${Array.from(n).map(t=>{let[e,i]=t;return`${e}=${i}`}).join("&")}`}catch(e){return(0,a.vV)(n.tDh,`An error occurred during building yidian iframe src from ${t}`),t}},o.vv.set("videoDurationStorage",d),o.vv.get("videoDurationStorage")},24752(t,e,i){i.d(e,{H(){return a},q(){return o}});const o={lateStart:2500,observePeriod:5,timeout:1e4};class n{constructor(){this.isObserving=!1}observe(t){let{checkForChange:e,callbacks:i}=t;this.isObserving||(this.isObserving=!0,this.watchForChange(e,performance.now(),i))}unobserve(){this.resetSession(!0)}watchForChange(t,e,i){let{onAbort:n,onComplete:a,onTimeout:r}=i;this.onAbort=()=>n(),this.timeoutTimer=setTimeout(()=>{this.resetSession(!1),r&&r()},o.timeout),this.observeTimer=setInterval(()=>{t()&&(this.resetSession(!1),a(Math.round(performance.now()-e)))},o.observePeriod)}resetSession(t){this.clearTimers(),this.isObserving=!1,t&&this.onAbort&&this.onAbort(),this.onAbort=void 0}clearTimers(){this.observeTimer&&clearInterval(this.observeTimer),this.timeoutTimer&&clearTimeout(this.timeoutTimer),this.observeTimer=void 0,this.timeoutTimer=void 0}}class a{get playerTimeChangeObserver(){return this._playerTimeChangeObserver||(this._playerTimeChangeObserver=new n),this._playerTimeChangeObserver}async getTimeToPlay(){return this._timeToPlay}measure(t,e,i){this._timeToPlay=new Promise(o=>{const n=t();this.playerTimeChangeObserver.observe({checkForChange(){return Math.abs(t()-n)>0||e()>0},callbacks:{onAbort(){return o(void 0)},onComplete(t){return o(t)},onTimeout(){i&&i(),o(void 0)}}})})}unobserve(){this.playerTimeChangeObserver.unobserve()}}},25717(t,e,i){i.d(e,{T(){return n}});var o=i(96950);function n(){return o.qy`
        <slot></slot>
    `}},26391(t,e,i){i.d(e,{T(){return a}});var o=i(93552),n=i(22341);const a=(0,i(91454).sx)(o.WQp,"sendAdImageLoadError")(t=>{let{isBoost:e,...i}=t;(0,n.vV)(e?o.H77:o.MxD,"Ads image is not loaded properly",r(i),{shouldSampleErrorsForTreatement1:!e})}),r=t=>{let{id:e,rLink:i,imgLink:o,event:n,retryCount:a,isRetrySuccessful:r,status:s,statusText:d,type:l,redirected:h,errorMessage:c}=t;return JSON.stringify({id:e,rLink:i,imgLink:o||n&&n.target.src,retryCount:a,isRetrySuccessful:r,status:s,statusText:d,type:l,redirected:h,errorMessage:c})}},28439(t,e,i){i.d(e,{Vv(){return a},f9(){return n},lp(){return r},nK(){return o}});const o="consumption-trigger-star-rating",n="gallery-hide-ad",a="underline-ad-title",r="gallery-ad-hover-effects-change"},30581(t,e,i){i.d(e,{yr(){return L}});var o=i(87993),n=i(96950),a=i(60402),r=i(69259),s=i(416),d=i(10108),l=i(82774),h=i(58792);const c=(0,i(75307).Eo)("MicrosoftLogoWithText","4806176","icons-wc/icons/shopping"),u=n.qy`<div class="footer ${t=>t.hasAbstract?"has-abstract-footer":""}" part="footer"><span part="start-actions" ${(0,a.K)("startActionsContainer")}><slot name="start-actions" ${(0,a.K)("startActions")} @slotchange=${t=>t.handleStartActionsContentChange()}></slot></span><span part="end-actions" ${(0,a.K)("endActionsContainer")}><slot name="end-actions" ${(0,a.K)("endActions")} @slotchange=${t=>t.handleEndActionsContentChange()}></slot></span></div>`,p=n.qy`<div style=" background: linear-gradient(265deg, rgb(18, 113, 3) 0%, rgb(69, 153, 3) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><img class="delivery-icon" loading="lazy" src="${(0,h.rA)().StaticsUrl}pr-3980746/shopping/deliveryTruckIcon.svg"><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">Free shipping</span></div>`,v=/\d+% cash ?back/i,g=n.qy`<div style=" background: linear-gradient(270deg, rgb(21, 61, 219) 0%, rgb(0, 113, 246) 100%); display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding-left: 2px; padding-top: 0px; align-items:center; "><span style=" text-transform: uppercase; color: white; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size)); padding:2px; align-items: center; ">${t=>{var e;return(t.title&&(null===(e=t.title.match(v))||void 0===e?void 0:e[0]))??"Earn cash back"}}</span></div>`,m=(t,e)=>n.qy`<div style=" background: #424242; display: flex; border-radius: 4px; margin-left: 10px; margin-top: 10px; position: relative; padding: 0px 2px; padding-top: 0px; align-items:center; "><img src="${e}" aria-hidden="true" onerror="this.style.display='none'"/><span style=" ${t.includes("Holiday Deals")?"font-weight: 600;":"text-transform: uppercase; font-size: var(--annotation-font-size, var(--type-ramp-minus-1-font-size));"} color: white; padding:2px; align-items: center; ">${t}</span></div>`,y=n.qy`<div style="display: flex;">${t=>t.id.includes("__")?n.qy` ${(0,r.z)(t=>t.id.includes("_Christmas"),m("Holiday Deals","https://www.bing.com/th?id=OSS.BT4443E8F9A2BBD34313F790F7FC3FD09DD960AF1BCACA6A40544E8EBF98066A80"))} ${(0,r.z)(t=>t.id.includes("_BlackFriday"),m("Black Friday Offer",(0,h.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))} ${(0,r.z)(t=>t.id.includes("_CyberMonday"),m("Cyber Monday Offer",(0,h.rA)().StaticsUrl+"pr-4318916/forum/buyDirectBlackFriday.svg"))}`:n.qy` ${(0,r.z)(t=>t&&!t.id.includes("_NoCashback"),g)} ${(0,r.z)(t=>t,p)} `}</div>`,b=n.qy`<div style="background: no-repeat center url('${t=>t.querySelector("img").src}');background-size: cover;filter: blur(40px); height: 100%; width:100%;position: absolute;"></div>`,f=n.qy`<div class="logo-container"><img src=${c} alt="Microsoft Logo" aria-hidden="true" /></div>`,x=n.qy`<template ${(0,s.Y)({property:"mediaNodes",filter:(0,d.Y)("[slot='media'], [slot='icon']")})}><span part="background-image" class='${t=>t.id.includes("contentcard_InfoBuyDirectCard")?"bd-background-image":"background-image"}'>${(0,r.z)(t=>t.id.includes("contentcard_tripleCashback"),f)} ${(0,r.z)(t=>t.id.includes("contentcard_edgeReclaim"),f)} ${(0,r.z)(t=>t.id.includes("contentcard_InfoBuyDirectCard"),b)}<slot name="background-image" ${(0,a.K)("backgroundImage")}></slot></span>${(0,r.z)(t=>t.id.includes("BuyDirectCard"),y)}<div class="mask" part="mask"></div><div class="body ${t=>t.hasAbstract?"has-abstract":""} ${t=>t.isGrid?"grid":""}" part="body">${(0,r.z)(t=>{var e;return(null==t||null===(e=t.mediaNodes)||void 0===e?void 0:e.length)>0},n.qy`<div class="media-wrapper" part="media-wrapper"><div part="media" ${(0,a.K)("mediaContainer")}><slot name="media" ${(0,a.K)("media")} @slotchange=${t=>t.handleMediaContentChange()}></slot><slot name="content-indicator" ${(0,l.e)("contentIndicatorNodes")}></slot><span part="icon" ${(0,a.K)("iconContainer")} class="${t=>t.iconSlottedNodes&&t.iconSlottedNodes.length?"icon":"icon__hidden"}"><slot name="icon" ${(0,a.K)("icon")} ${(0,l.e)("iconSlottedNodes")}></slot></span></div></div>`)}<div class="heading-container" part="heading-container">${(0,r.z)(t=>{var e;return 0===(null==t||null===(e=t.mediaNodes)||void 0===e?void 0:e.length)},n.qy`<slot name="content-indicator" ${(0,l.e)("contentIndicatorNodes")}></slot>`)}<slot name="attribution"></slot><span class="heading-wrapper" part="heading-wrapper" role="heading" aria-level=${t=>t.headinglevel} name="heading"><a class="heading" part="heading" href=${t=>t.href?t.href:void 0} target=${t=>t.target?t.target:void 0} @click=${(t,e)=>t.handleContentCardLinkClick(e.event)} data-t="${t=>t.anchorTelemetryTag}"><slot></slot></a></span></div><div class="abstract" part="abstract"><slot name="abstract" ${(0,l.e)("abstract")}></slot></div>${(0,r.z)(t=>t.layout!==o.S.default,u)}</div>${(0,r.z)(t=>t.layout===o.S.default,u)}<span part="hover-actions" class="${t=>t.hoverActionsSlottedNodes&&t.hoverActionsSlottedNodes.length?"hover-actions":"hover-actions__hidden"}"><slot name="hover-actions" ${(0,l.e)("hoverActionsSlottedNodes")}></slot></span><slot name="call-to-action"></slot></template>`;var w=i(64187),P=i(73477),$=i(22131),k=i(74849),S=i(50882),_=i(7896),C=i(61138),A=i(64003),T=i(41123),I=i(48751),E=i(89580),V=i(95239),z=i(86856);const D=k.A` :host([layout="default"]) .media-wrapper{float:right}`,F=k.A` :host([layout="default"]) .media-wrapper{float:left}`,M=k.A`
    ${(0,w.V)("flex")} :host{--icon-size:24px;position:relative;width:auto;box-sizing:border-box;font-family:${_.O};flex-direction:column;outline:none;height:100%;overflow:hidden}:host(:hover) .hover-actions{opacity:1;transition:opacity 0.2s ease-in-out}.body{display:grid;justify-content:center;row-gap:8px;column-gap:10px;grid-template-columns:1fr auto;grid-template-rows:auto}:host([layout="default"]) .body .abstract{display:none}:host([layout="default"]) .body{display:block}:host([layout="default"]) .body.grid{display:grid}:host([layout="default"]) .body.grid .media-wrapper{float:none}:host([layout="default"]) .has-abstract .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([layout="default"]) .has-abstract .media-wrapper{margin-inline-start:16px}:host([image-priority]) .has-abstract .media-wrapper{margin-inline-start:0}.footer{padding-inline-start:var(--footer-start-padding,16px);padding-inline-end:var(--footer-start-padding,16px);padding-top:var(--footer-padding-top,0);padding-bottom:var(--footer-padding-bottom,4px);margin-top:auto;font-size:var(--footer-font-size,${C.k});
        line-height: var(--footer-line-height, ${C.F})}.logo-container{display:flex;align-items:center;position:fixed;bottom:16px;z-index:1000;left:17px}.footer,.start-actions,.end-actions{display:flex;flex-direction:row;align-items:center;justify-content:space-between;color:${A.c};
        fill: ${A.c}}.footer__hidden{display:none}.hover-actions{display:flex;flex-direction:column;position:absolute;top:8px;z-index:2;opacity:0}.hover-actions__hidden{display:none}.hover-actions:focus-within{opacity:1}.heading-container{grid-row:1;display:flex;flex-direction:column;padding-inline-start:var(--heading-start-padding,16px);padding-inline-end:var(--heading-end-padding,16px);padding-bottom:0;padding-top:16px}.heading-wrapper a:after{bottom:0;content:"";height:100%;left:0;position:absolute;right:0;top:0;width:100%;z-index:1}:host([layout="condensed"]) .body{gap:0}:host([layout="condensed"]) .footer{grid-row:2;grid-column-start:1;grid-column-end:var(--footer-grid-column-end,auto);padding-inline-start:16px}:host([layout="condensed"]) .media-wrapper{position:relative;grid-row:1 / span 2;margin-top:5px}:host([layout="condensed"]) .heading-container{padding-top:0px;--heading-end-padding:12px}:host([layout="condensed"]) ::slotted([slot="attribution"]){margin-bottom:0px}.icon{position:absolute;display:inline-flex;top:auto;bottom:0;justify-content:center;align-items:center;margin:0 0 4px 0;margin-inline-start:4px}.hover-actions{inset-inline-end:8px}.icon{inset-inline-start:0}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){inset-inline-start:8px}.icon__hidden{display:none}::slotted([slot="icon"]){width:var(--icon-size);height:var(--icon-size);fill:#FFF}::slotted([slot="attribution"]){margin-bottom:6px}::slotted([slot="abstract"]){margin:2px 0}.media-wrapper{grid-row:1;grid-column:2;margin-inline-end:var(--media-inline-padding,16px);margin-top:16px}.media{display:flex;position:relative}:host([image-priority]) .heading{-webkit-line-clamp:var(--heading-max-lines,2)}:host([image-priority]) .body{grid-template-columns:1}:host([image-priority]) .media-wrapper{grid-row:1;grid-column:span 2;margin:0}:host([image-priority]) .heading-container{grid-row:2;grid-column:span 2;padding-top:10px;padding-inline-start:var(--heading-start-padding,16px)}:host([image-priority]) ::slotted([slot="media"]),:host([layout="infoPaneSplitHorizontal"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPane"]) .media-wrapper,:host([layout="infoPane1x3y"]) .media-wrapper{grid-row:1;grid-column:1;margin-top:0;width:fit-content;height:fit-content}:host([layout="infoPane"]) .icon,:host([layout="infoPaneSplitVertical"]) .icon,:host([layout="infoPane1x3y"]) .icon{display:inline;left:0;top:0;margin:4px 0 0;margin-inline-start:4px}:host([layout="infoPaneSplitVertical"]) .icon{display:block}:host([layout="infoPaneSplitHorizontal"]) .icon{bottom:0px}:host([layout="infoPaneSplitHorizontal"]) .heading-container,:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{align-self:end}:host([layout="infoPaneSplitHorizontal"]) .body,:host([layout="infoPane"]) .body,:host([layout="infoPane1x3y"]) .body{height:100%;grid-template-rows:1fr auto}::slotted([slot="call-to-action"]){width:calc(100% - 32px);grid-row:3;z-index:1;grid-column:1 / span 2;margin:0 16px}::slotted([slot="media"]){border-radius:calc(var(--content-card-corner-radius,2) * 2px)}:host([layout="default"]) .grid .heading-container{grid-area:initial !important}:host([layout="default"]) .has-abstract .abstract{display:block;padding:0 16px 16px 16px}.abstract{position:relative;margin:0;font-size:var(--abstract-font-size,${T.K});
        line-height: var(--abstract-line-height, ${T.Z});
        font-weight: 400;
        grid-column: span 2;
        box-sizing: content-box;
        color: ${A.c};padding:0 16px}::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){z-index:2;display:grid;gap:5px;align-items:center;grid-auto-flow:column}::slotted([slot="call-to-action"]){z-index:2}::slotted(fluent-button[slot="start-actions"]),::slotted(fluent-button[slot="end-actions"]){color:${A.c};
        fill: ${A.c}}::slotted(fluent-button[appearance="stealth"]:not(:hover)),:slotted([slot="hover-actions"]:not(:hover)){background:transparent}.heading{text-decoration:none;outline:none;color:${I.l};
        font-size: var(--heading-font-size, ${E.Y});
        line-height: var(--heading-line-height, ${E.v});font-weight:600;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:var(--heading-max-lines,3);white-space:initial}.mask{display:none}.heading:hover,.heading:${P.N}{text-decoration:underline}.heading::after{position:absolute;content:"";top:0;left:0;right:0;bottom:0}:host([layout="infoPane"]),:host([layout="infoPane1x3y"]){justify-content:flex-end;border:none}:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{position:absolute;bottom:0;right:0;left:0;background:${V.p};
        box-shadow: 0px -25px 15px ${V.p}}:host([layout="infoPane"]) .heading-container,:host([layout="infoPane1x3y"]) .heading-container{grid-column:1 / 3;z-index:1}:host([layout="infoPane"]) .has-abstract .heading-container,:host([layout="infoPane1x3y"]) .has-abstract .heading-container{grid-area:2/ 1 / span 2 / auto;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:8px;align-self:flex-start}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{grid-row:2;grid-column:2;color:${I.l};padding:8px 16px 0 16px;align-self:end;display:-webkit-box;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:4}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract{display:none}:host([layout="infoPane"]) .has-abstract,:host([layout="infoPane1x3y"]) .has-abstract{grid-template-columns:1fr 1fr;gap:0 10px}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer{min-height:calc(40px - 4px)}:host([layout="infoPane"]) .has-abstract .abstract,:host([layout="infoPane1x3y"]) .has-abstract .abstract{display:-webkit-box;align-self:flex-end}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{display:flex;position:absolute;top:0;left:0;right:0;bottom:0;background-image:var(--mask-gradient,linear-gradient(to top,rgba(0,0,0,1),rgba(0,0,0,0) 176px))}:host([layout="infoPane1x3y"]) .mask{background-image:var(--mask-gradient,linear-gradient(rgba(0,0,0,0),rgba(0,0,0,1) 69px,rgba(0,0,0,1)));top:257px}:host([layout="infoPane"]) .has-abstract .has-abstract-footer,:host([layout="infoPane1x3y"]) .has-abstract .has-abstract-footer{grid-row:3;grid-column:2;position:inherit;align-self:flex-end;max-height:40px}:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer{margin-top:unset;grid-row:2;grid-column:1 / span 2;padding-inline-start:16px;padding-inline-end:16px}:host([layout="infoPane"]) ::slotted(msft-attribution[slot="attribution"]),:host([layout="infoPane1x3y"]) ::slotted(msft-attribution[slot="attribution"]){color:${I.l};text-shadow:0px 0.4px 0.9px rgba(0,0,0,0.13),0px 0px 2.22px rgba(0,0,0,0.11)}:host([layout="infoPaneSplitVertical"]){grid-template-columns:304px 1fr;grid-template-rows:auto;background:${V.p}}:host([layout="infoPaneSplitVertical"]) ::slotted([slot="media"]){border-radius:0px}:host([layout="infoPaneSplitVertical"]) .media-wrapper{grid-row:1 / span 2;grid-column:1;margin:0}:host([layout="infoPaneSplitVertical"]) .heading-container{grid-row:1;grid-column:2;--heading-start-padding:4px;--heading-end-padding:16px;padding-bottom:0;padding-top:16px}:host([layout="infoPaneSplitVertical"]) .footer{grid-row:2;grid-column:2;padding-inline-start:0;padding-inline-end:16px;padding-top:0}:host([layout="infoPaneSplitHorizontal"]) .body{grid-template-columns:1fr 1fr;grid-template-rows:326px auto auto;row-gap:4px;background:${V.p}}:host([layout="infoPaneSplitHorizontal"]) .media-wrapper{grid-column:1 / span 2;margin:0}:host([layout="infoPaneSplitHorizontal"]) .heading-container{grid-column:1;grid-row:2 / span 2;--heading-start-padding:16px;--heading-end-padding:0;padding-bottom:12px;padding-top:12px}:host([layout="infoPaneSplitHorizontal"]) .footer{grid-column:2;grid-row:3;box-shadow:none}:host([layout="infoPaneSplitHorizontal"]) .abstract{color:inherit;align-self:inherit;padding:12px 16px 0 16px}.background-image{position:absolute;top:0;left:0;right:0;bottom:0}:host([layout="infoPane1x3y"]) .background-image{position:absolute;top:0;left:0;right:0;bottom:136px}.background-image ::slotted(img){width:100%;height:100%;object-fit:cover}.bd-background-image ::slotted(img){width:100%;height:100%;object-fit:contain;position:absolute;top:0px}:host([layout="infoPane1x3y"]) ::slotted([slot="content-indicator"]),:host([layout="infoPane"]) ::slotted([slot="content-indicator"]),.media-wrapper ::slotted([slot="content-indicator"]){position:absolute;top:8px;z-index:1}::slotted([slot="content-indicator"]){margin-bottom:26px;align-self:flex-start}`.withBehaviors(new z.t(D,F),(0,$.mr)(k.A` .heading{color:${S.A.LinkText};
                    background: ${S.A.ButtonFace}}.abstract{color:${S.A.ButtonText}}.icon{background-color:#000;height:fit-content}:host([layout="infoPane"]) .abstract,:host([layout="infoPane1x3y"]) .abstract,:host([layout="infoPaneSplitHorizontal"]) .abstract{color:${S.A.ButtonText};
                    background: ${S.A.ButtonFace}}.footer,.start-actions,.end-actions,::slotted([slot="start-actions"]),::slotted([slot="end-actions"]){background:${S.A.ButtonFace};
                    color: ${S.A.ButtonText};fill:currentcolor}:host([layout="infoPane"]) .mask,:host([layout="infoPane1x3y"]) .mask{background-image:none}:host([layout="infoPane"]) .has-abstract .footer,:host([layout="infoPane1x3y"]) .has-abstract .footer,:host([layout="infoPane"]) .footer,:host([layout="infoPane1x3y"]) .footer,:host(:not([layout="infoPane"])) .has-abstract-footer,:host(:not([layout="infoPane1x3y"])) .has-abstract-footer{background:${S.A.ButtonFace};box-shadow:none}::slotted(fluent-button[appearance="stealth"]:not(:hover)){background:${S.A.ButtonFace};
                }
            `));var O=i(99900);const L=o.m.compose({name:`${O.i.prefix}-content-card`,template:x,styles:M,shadowOptions:{delegatesFocus:!0}})},37256(t,e,i){i.d(e,{R(){return c}});var o=i(64187),n=i(22131),a=i(74849),r=i(50882),s=i(37998),d=i(57416),l=i(95239),h=i(48751);const c=a.A`
    ${(0,o.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${l.p};
        color: ${h.l};
        border-radius: calc(${d.JU} * 1px);
        ${s.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,n.mr)(a.A`
            :host {
                forced-color-adjust: none;
                background: ${r.A.Canvas};
                box-shadow: 0 0 0 1px ${r.A.CanvasText};
            }
        `))},37725(t,e,i){i.d(e,{H8(){return s},RD(){return a},Wr(){return d},qK(){return l}});var o=i(93552),n=i(22341);const a=(t,e,i)=>{var n;return null!=t&&t.title?(null!=t&&null!==(n=t.thumbnail)&&void 0!==n&&n.image||d(o.r5T,`Video ID [${s(null==t?void 0:t.id,e,i)}] has an empty headline image but the content is valid.`),r(t,e,i)):(d(o.Ta7,`Video ID [${s(null==t?void 0:t.id,e,i)}] has an empty headline.`),!1)},r=(t,e,i)=>{var n;if(null!=t&&null!==(n=t.videoMetadata)&&void 0!==n&&null!==(n=n.externalVideoFiles)&&void 0!==n&&n.length){const n=t.videoMetadata.externalVideoFiles;return!(null==n?void 0:n.find(t=>!t.url&&!t.format))||(d(o.WWk,`Video ID [${s(t.id,e,i)}] has an invalid 1pp video file.`),!1)}return!1},s=(t,e,i)=>`${t??e??"N/A"}${i?" (playlist) ":""}`,d=(t,e)=>{(0,n.vV)(t,"Data returned by content view does not contain expected video data.",e,{...t.pb})},l=t=>{var e;const{cardContent:i,metadata:o}=t;return{id:t.id,title:null==i?void 0:i.title,thumbnail:{image:null==i||null===(e=i.images)||void 0===e?void 0:e[0]},videoMetadata:{playTime:null==o?void 0:o.videoMetadata.playTime,externalVideoFiles:null==i?void 0:i.videoFiles},sourceId:(null==i?void 0:i.sourceId)||""}}},38380(t,e,i){i.d(e,{v(){return o}});const o=(0,i(25717).T)()},42792(t,e,i){i.d(e,{R7(){return g},e(){return p},kc(){return v},nH(){return u}});var o=i(57416),n=i(55153),a=i(95239),r=i(26920),s=i(48751),d=i(64187),l=i(22131),h=i(74849),c=i(50882);const u=h.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,p=h.A`
    ${(0,d.V)("flex")} :host {
        background: ${a.p};
        outline: calc(${r.XA} * 1px) solid ${n.cu};
        border-radius: calc((${o.JU} - ${r.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${r.XA} * 1px) ${n.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${r.XA} * 1px) ${n.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${r.XA} * 1px) ${n.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${n.QG} * 1px);
        height: calc(${n.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${n.QG} * 1px);
        height: calc((${n.l8} * 2px) + (${n.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${n.QG} * 2px) + (${n.Sn} * 1px));
        height: calc((${n.l8} * 2px) + (${n.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${n.QG} * 2px) + (${n.Sn} * 1px));
        height: calc(${n.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,v=(0,l.mr)(h.A`
            :host {
                background: ${c.A.Canvas};
                color: ${c.A.CanvasText};
            }
        `),g=h.A`
    ${p}
    ${u}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(v)},45844(t,e,i){i.r(e),i.d(e,{ToolingInfo(){return vo},VideoCardWC(){return Qt},VideoCardWCStyles(){return Ut},VideoCardWCTemplate(){return po},VideoCardWrapperTemplate(){return uo},createEmbedMediaFromId(){return ot},createPlayerInfoFromDirectEmbedMedia(){return it},createVideoCardProps(){return M},createVideoPlayerInfoFromVideoData(){return et},formatNextVideosOverlayData(){return W},formateVideoTime(){return rt},get3PPConfigByProviderId(){return R},get3PPConfigByVideoPlayerName(){return B},getIsVideoAdDisabled(){return F},getNumberOfCardsOnPauseSlate(){return H},getVideoAdCardProps(){return pt},getVideoCardNavLink(){return dt},getVideoCardPropsLocalizedStrings(){return ut},getVideoPreviewUrlFromMotionThumbnail(){return ht},getWatchMoreButtonUrl(){return ct},globalStyles(){return jt},isYouTube(){return N},landscapeAspectRatio(){return z},postProcessRelatedVideoData(){return lt},postProcessVideoData(){return st},scalePosterUrl(){return q},videoEndSlateConstants(){return U},watchBrowserSize(){return Y}});var o=i(56911),n=i(93552),a=i(22341),r=i(23429),s=i(60815),d=i(38493),l=i(85349),h=i(77367),c=i(70775),u=i(74998);function p(t,e){const i=v(t,e);return!!i&&("prepareForVirtualization"in i&&"function"==typeof i.prepareForVirtualization&&(i.prepareForVirtualization(),!0))}function v(t,e){if(!t)return null;const i=e.toLowerCase();for(const e of Array.from(t.children)){if(e.tagName.toLowerCase()===i)return e;const t=v(e.shadowRoot,i);if(t)return t;const o=v(e,i);if(o)return o}return null}var g=i(81583),m=i(37725);function y(){return"vp"===c._3.getQueryParameterByName("reqsrc",location.href)||"1"===c._3.getQueryParameterByName("vptest",location.href)}var b=i(6632),f=i(88635);function x(t,e){var i,o;if(!e||!e.length)return"";return(t?null===(i=e.find(t=>t.isDarkMode))||void 0===i?void 0:i.hexColor:null===(o=e.find(t=>!t.isDarkMode))||void 0===o?void 0:o.hexColor)||""}var w,P=i(38001);!function(t){t.LO="101",t.SD="102",t.HQ="103",t.HD="104",t.FHD="105",t["4K"]="107",t.Source="1001",t.SmoothStreaming="1004",t.HLS="1006",t.DASH="1007"}(w||(w={}));var $=i(77348),k=i(3083);function S(t){if(!t)return{name:"",isPremium:!1};const{logo:e}=t;return{name:t.name||"",logo:{src:(null==e?void 0:e.url)&&(0,k.oQ)(null==e?void 0:e.url,{width:16,height:16,enableDpiScaling:!1})||"",alt:(null==e?void 0:e.title)||"",caption:(null==e?void 0:e.title)||""},isPremium:t.isPremium||!1}}var _=i(97015),C=i(68648),A=i(15525),T=i(35341);const I={width:0,height:0,title:"",rid:"",provider:""},E=/(?:[?&]v=|\/embed\/|\/1\/|\/v\/|https:\/\/(?:www\.)?youtu\.be\/)([^&\n?#]+)/,V=/shorttv\.live\/([^&\n?#]+)/,z=16/9,D="videoInitiallyMuted";function F(t,e){return Boolean("boolean"==typeof(null==e?void 0:e.isVideoAdDisabled)?e.isVideoAdDisabled:t.isVideoAdDisabled)}function M(t,e,i,o){var n;const{adTimeBasedCapSec:a=90,bufferOptions:r,disableOutOfViewAdPause:s=!1,disableQualityMenu:d=!1,disableSeekButtons:l=!1,disableVolumeControlBar:h=!1,enableAdPauseBeforePlay:c=!1,enableAdStartingSoonLabel:u=!1,enableAlwaysOutOfViewAdPause:p=!1,enableAutoPlayOnAutoPauseOnly:v=!1,enableAutoPlayToggle:g=!1,enableLargeTitle:m=!1,enableOpaqueControls:y=!1,enableControlSpacing:b=!1,enableSeekbarThumbnails:f=!1,enableRelatedVideosShadowBox:x=!1,enableVisibilityService:w=!1,forbidAnyObserver:P=!1,hasAdTimeBasedCap:$=!1,hasPreRollForEveryVideo:k=!1,inStreamVideoAd:_,localizedStrings:C,shouldUseRetryWithDelay:A=!1,thirdPartyPlayersConfig:T={players:[]},vhsTreatment:E,watchMoreButton:V=!1}=e||{},{directEmbedMediaPlayerProps:z=I,inStreamVideoAd:D,isLocal:M=!1,posterUrl:O,leadsGenVideoAdsSkipDuration:R,enableVideoPreview:B,playerFeedIdx:N,relatedVideosData:U,isPartnerEmbed:j}=i||{},{videoData:G,directEmbedMedia:W}=t||{},H=F(e,i),Y=ut(C,i),et=function(t,e){if(tt())return!1;if(t.enableTitleAtBottom)return Boolean(null==e?void 0:e.isInViewPlayEnabled);return Boolean(t.enablePlayInViewport3pp)}(e,t);if(t&&W)return{directEmbedMedia:{...W,width:z.width,height:z.height,title:z.title,rid:z.rid,provider:z.provider,providerId:z.providerId,metadata:z.metadata},thirdPartyPlayersConfig:void 0,card3ppConfig:void 0,isVideoAdDisabled:H,isAutoPlayEnabledForWebContent:Z(e,i),forbidAnyObserver:P,playerConfigProps:Q(e,i),shouldUseRetryWithDelay:A,hasAdTimeBasedCap:$,adTimeBasedCapSec:a,disableQualityMenu:d,disableSeekButtons:l,localizedStrings:Y,leadsGenVideoAdsSkipDuration:R,playerFeedIdx:N,...X(e)};const it=G?function(t,e,i,o){if(t&&t.title){var n;const{thumbnail:a={}}=t,r=t.videoMetadata||(null==o||null===(n=o.videoData)||void 0===n?void 0:n.videoMetadata),s=a&&a.image;let d;s&&(d=i.enablePosterScaling?q(e.embeddedDimensions,s,Boolean(i.useWebPImageFormat)):s.url);return{posterUrl:d,videoMetadataProps:{abstract:t.abstract,closedCaptions:K(r),controls:!0,title:t.title,videoSources:J(r)}}}return}(G,t,e,i):{};if(!it)return{posterUrl:void 0,videoMetadataProps:void 0,playerConfigProps:void 0,thirdPartyPlayersConfig:void 0,isAutoPlayEnabledForWebContent:!1,shouldUseRetryWithDelay:!1,hasAdTimeBasedCap:!1,adTimeBasedCapSec:90,card3ppConfig:void 0,disableQualityMenu:!1,disableSeekButtons:!1,localizedStrings:Y};const{adStringText:ot="Ad",skipAdText:nt="Skip Ad",preSkipAdButtonText:at="",nonSkippableAdButtonText:rt=""}=Y||{},{id:st="",provider:lt,sourceId:ht,videoMetadata:vt}=G||{},gt=function(t){const{config:e,configOverrides:i}=t;if(!e&&!i)return;const{videoId:o,sourceVideoId:n,videoProviderId:a,videoPlayTime:r,isVideoAdDisabled:s,adLabelText:d,shouldDisplayPrerollAd:l,skipAdButtonText:h,preSkipAdButtonText:c,nonSkippableAdButtonText:u,articleId:p}=t,{placementId:v,bidderConfigs:g=[],prebidFloorPrice:m=1,preRollAdPgCode:y,maxOneMidrollReqPerVideo:b=!1,intimateMidrollAds:f=!1,isPrebidEnabled:x=!1,enableProgTimeBasedMidrollAds:w=!1,passBrandSafetySignals:P,passAdOcidRegSize:$,enableAddingAdCoords:k,enableTeraPgCodes:S}=e||{},{verticalKeyOverride:_,pageTypeOverride:C}=i||{};return{shouldDisplayAd:Boolean(!s&&l),placementId:v,bidderConfigs:g,prebidFloorPrice:m,adLabelText:d,skipAdButtonBehavior:{delaySec:5,videoDurationSec:15,skipAdButtonText:h,preSkipAdButtonText:c,nonSkippableAdButtonText:u},intimateMidrollAds:f,inventoryCode:y,isPrebidEnabled:x,pageTypeOverride:C,passBrandSafetySignals:P,passAdOcidRegSize:$,enableAddingAdCoords:k,maxOneMidrollReqPerVideo:b,verticalKeyOverride:_,videoId:o,sourceVideoId:n,videoProviderId:a,videoPlayTime:r,enableProgTimeBasedMidrollAds:w,enableTeraPgCodes:S,articleId:p}}({config:_,configOverrides:D,videoId:st,videoProviderId:(null==lt?void 0:lt.id)||"",videoPlayTime:null==vt?void 0:vt.playTime,sourceVideoId:ht,isVideoAdDisabled:H,adLabelText:ot,shouldDisplayPrerollAd:k,skipAdButtonText:nt,preSkipAdButtonText:at,nonSkippableAdButtonText:rt,articleId:o}),mt=B||(null==G?void 0:G.is360VideoAd),yt=dt(i,G),bt=Boolean(B&&!(null!=U&&U.length));return{posterUrl:O||it.posterUrl,watchMoreButtonUrl:ct(i,G),disableWatchMoreButtonByParent:null==i?void 0:i.disableWatchMoreButtonByParent,onMessage:it.onMessage,videoMetadataProps:it.videoMetadataProps,playerConfigProps:Q(e,i,t),...X(e),inStreamVideoAdSettings:mt?void 0:gt,videoData:G,thirdPartyPlayersConfig:T,forbidAnyObserver:P,isVideoAdDisabled:H,isAutoPlayEnabledForWebContent:Z(e,i),card3ppConfig:L(null==G?void 0:G.thirdPartyVideoPlayer,null==G?void 0:G.provider,T),watchMoreButton:!j&&V,localizedStrings:Y,playerFeedIdx:N,isLocal:M,enableLargeTitle:m,enableOpaqueControls:y,enableControlSpacing:b,enableSeekbarThumbnails:f,enableAdStartingSoonLabel:u,enableAutoPlayOnAutoPauseOnly:v,enableVisibilityService:w,enableShadowBox:x,providerData:S(null===(n=t.videoData)||void 0===n?void 0:n.provider),hasAdTimeBasedCap:$,adTimeBasedCapSec:a,bufferOptions:r,shouldUseRetryWithDelay:A,enableAutoPlayToggle:g,enablePlayInViewport3pp:et,disableQualityMenu:d,disableSeekButtons:l,disableVolumeControlBar:h,disableOutOfViewAdPause:s,enableAlwaysOutOfViewAdPause:p,enableAdPauseBeforePlay:c,openWatchMoreInSameTab:e.openWtchMoreSameTab,recoRequestId:z&&z.recoRequestId,enablePersistentMute:null==i?void 0:i.enablePersistentMute,enableUnmuteCTA:null==e?void 0:e.enableUnmuteCTA,enableOppositeUnmuteCTA:null==e?void 0:e.enableOppositeUnmuteCTA,enableUnmuteCTATextAutoShow:null==e?void 0:e.enableUnmuteCTATextAutoShow,enableFullAreaUnmute:null==e?void 0:e.enableFullAreaUnmute,vhsTreatment:E,viewDetailsButton:bt,shouldReplayOnCanPlay:B,enableSessionPersistentVolume:null==i?void 0:i.enableSessionPersistentVolume,navLink:yt,...pt(G,i)}}function O(t){const e={};return t.vhsNoBandwidthSeed&&(e.bandwidth=void 0),t.vhsHighDPR&&(e.useDevicePixelRatio=!0),t.vhsCustomPixelRatio&&(e.customPixelRatio=1.5),e}function L(t,e,i){if(!i||!t)return;const{name:o}=t,{players:n=[]}=i;if(N(o))return n.find(t=>N(t.name));if(!e)return;const{id:a="",name:r}=e,s=R(i,a)||B(i,o);return s&&!s.displayName&&(s.displayName=r),s}function R(t,e){return t.players.find(t=>t.providerId.includes(e))}function B(t,e){if(e)return t.players.find(t=>t.name.toLowerCase()==e.toLowerCase())}function N(){return(arguments.length>0&&void 0!==arguments[0]?arguments[0]:"").toLowerCase()=="YouTube".toLowerCase()}const U={TmplName:"nextVideosOverlayClicksTmpl",TmplNameWithNoTimer:"nextVideosOverlayClicksTmplNoTimer"};function j(t){let e=0,i=0;t&&(i=Math.floor(t/60),e=t-60*i);return{sec:e.toString().padStart(2,"0"),min:i.toString()}}function G(t,e){if(!t||!t.url)return;const{url:i,source:o}=t;return e||"msn"===o?i:`${i}&h=60&w=106&m=6&o=t&l=f&f=png`}function W(t){const e=[];for(const n of t){var i,o;const{id:t,title:a,videoMetadata:r,provider:s,thumbnail:d,destinationUrl:l}=n,h=0===(null==r||null===(i=r.externalVideoFiles)||void 0===i?void 0:i.length),c=G(null==d?void 0:d.image,h);t&&c&&a&&e.push({title:a,mediaSrc:c,durationTime:j((null==r?void 0:r.playTime)||0),providerName:(null==s?void 0:s.name)||"",providerLogo:(null==s||null===(o=s.logo)||void 0===o?void 0:o.url)||"",id:t,destinationUrl:l??""})}return e}function H(){let t=0;return(Y((0,f.AE)(f.j1.c3))||Y((0,f.AE)(f.j1.c4))||Y((0,f.AE)(f.j1.c5)))&&(t=3),t}function Y(t){return window.matchMedia(t).matches}function q(t,e,i){if(!t)return(0,a.vV)(n.wlN,"No render dimensions available."),e.url;try{const o=new URL(e.url||""),{width:n,height:a}=t,{width:r=0}=e,s={format:i?k.f5.WEBP:void 0,enableDpiScaling:!0,devicePixelRatio:1};return n&&r>n&&(s.width=n,s.height=a),(0,k.oQ)(o.href,s)}catch(t){return(0,a.vV)(n.wlN,"Error processing URL.",e.url),e.url}}function J(t){return t&&t.externalVideoFiles||[]}function K(t){const e=[];if(t&&t.closedCaptions&&t.closedCaptions.length)for(const i of t.closedCaptions)e.push({kind:"captions",label:"Auto generated",srclang:i.locale,src:i.href+"&vtt=true"});return e}function X(t){return{customStyle:t?t.customStyle??"":""}}function Q(t,e,i){var o;const n=function(t,e){if(tt())return!1;return Boolean("boolean"==typeof(null==e?void 0:e.autoplay)?e.autoplay:t.autoplay)}(t,e),a=function(t,e,i){if(tt())return!1;if(t.enableTitleAtBottom)return Boolean(null==i?void 0:i.isInViewPlayEnabled);return Boolean("boolean"==typeof(null==e?void 0:e.autoplay)?e.autoplay:t.iframeAutoplay)}(t,e,i),r=function(t){if(tt())return!1;return Boolean(null==t?void 0:t.isInViewPlayEnabled)}(i)&&!(null!=e&&e.disableInViewPlayByParent),s=t.enableTitleAtBottom,d="boolean"==typeof(null==e?void 0:e.mobileMode)?e.mobileMode:t.mobileMode,l="boolean"==typeof(null==e?void 0:e.progressiveMode)?e.progressiveMode:t.progressiveMode,h=(null==e?void 0:e.startVideoPositionSec)||0,c=!t||t.muted;let u=c;u&&t.enableSessionPersistentVolume&&"false"===(0,C.W9)().getItem(D)&&(u=!1);const p=(null==e?void 0:e.enableVideoPreview)||(null==e||null===(o=e.videoData)||void 0===o?void 0:o.is360VideoAd),v=null!=t&&t.enableAttemptedUnmutedPlay?"true"===(0,A.Lg)().getItem(D):void 0;return{autoplay:n,autoReplay:!!t&&t.autoReplay,continuePlay:!t||t.continuePlay,disCaptionSettings:!!t&&t.disCaptionSettings,disableCCButton:!!e&&e.disableCCButton,disableSeekButtons:!!t&&t.disableSeekButtons,disableFullscreen:!!t&&t.disableFullscreen,disablePlacehldrErrTelemetry:!!t&&t.disablePlacehldrErrTelemetry,enableExternalVolPanel:!!t&&t.enableExternalVolPanel,enableImmersiveView:!!t&&t.enableImmersiveView,enableAutoplayRefresh:s,enableManagedAutoplay:null==t?void 0:t.enableManagedAutoplay,enableAttemptedUnmutedPlay:null==t?void 0:t.enableAttemptedUnmutedPlay,userPersistedMutePreference:v,hidePrivacyLinks:!!t&&t.hidePrivacyLinks,hideTitle:!!t&&t.hideTitle,inActivityTimeoutMs:t?t.inActivityTimeoutMs:void 0,initialVolume:t?t.initialVolume:void 0,iframeAutoplay:a,inViewPlay:r,inViewPlayRatio:t?t.inViewPlayRatio:void 0,mobileMode:d,muted:u,configMuted:c,pictureInPictureToggle:Boolean(null==e?void 0:e.openPipWindow),openPipWindow:null==e?void 0:e.openPipWindow,setPipStylesCallback:null==e?void 0:e.setPipStylesCallback,pipCoachmarkDelaySeconds:null==t?void 0:t.pipCoachmarkDelaySeconds,preferredVideoFormat:t.preferredVideoFormat,progressiveMode:l,replayWhenInView:!t||t.replayWhenInView,startVideoPositionSec:h,useProgressiveVideoFallback:!!t&&t.useProgressiveVideoFallback,blockPlayOnInViewCheck:!!t&&t.blockPlayOnInViewCheck,useMp4:p,enableSessionPersistentVolume:!!t.enableSessionPersistentVolume,vhsOptionsOverride:{...(null==e?void 0:e.vhsOptionsOverride)||{},...O(t)},shouldEnforceHigherQuality:null==e?void 0:e.shouldEnforceHigherQuality,disabledControlsByParent:null==e?void 0:e.disabledControlsByParent}}function Z(t,e){return!tt()&&Boolean("boolean"==typeof(null==e?void 0:e.isAutoPlayEnabledForWebContent)?e.isAutoPlayEnabledForWebContent:t.isAutoPlayEnabledForWebContent)}function tt(){var t;return null!==u.Rb&&void 0!==u.Rb&&null!==(t=u.Rb.CurrentFlightSet)&&void 0!==t&&t.has(T.nj)?(0,$.Od)():(0,$.Cl)()}function et(t,e,i,o,n,a,r,s,d,l,h){if(null==t||!t.id)return;const{sourceId:c,provider:u,colorSamples:p,id:v,videoMetadata:g,categories:m=[],title:y="",seo:b}=t;return{video:{id:v,title:y,durationSec:(null==g?void 0:g.playTime)??0,sourceId:c,colorSample:e?x((0,P.DK)(),p):"",provider:u,isWebContent:!1,categories:m,isPartnerEmbed:i,isContentBingmm:o,url:null==b?void 0:b.canonicalUrl,isVideoPreview:!1,recoId:d},isAutoplay:s,isFirstVideoFromPlaylist:n,isInline:a,isLocal:r,enableAttemptedUnmutedPlay:l,userPersistedMutePreference:h}}function it(t,e,i,o,n,a,r,s,d){const{rid:l}=e,{id:h,videoSrcUrl:c}=t,u=l??h;if(!u||!h)return;const{title:p="",provider:v,providerId:g,metadata:m,durationSec:y}=e;return{video:{id:u,title:p,recoId:l,durationSec:y??0,sourceId:h,colorSample:"",provider:{name:v,id:g},isWebContent:!0,isPartnerEmbed:i,isContentBingmm:o,categories:m?[{product:m.vertical,label:m.category}]:[],url:c},isAutoplay:s,isFirstVideoFromPlaylist:n,isInline:a,isLocal:r,useLeadsGenVideoAds:d}}function ot(t,e){if(t.toLowerCase().includes("GenericIframe".toLowerCase()))return{type:"GenericIframe",id:"GenericIframePlayerId",videoSrcUrl:null==e?void 0:e.playerUrl};if(t.startsWith("https://")){let e=nt(t,"YouTube",E,t=>t[1]);return e?(e.videoSrcUrl=t,e):(e=nt(t,"ShortTv",V,t=>t[1]),e&&(e.videoSrcUrl=t),e)}return t.toLowerCase().includes("PlutoTv".toLowerCase())?{type:"PlutoTv",id:"plutoTvId"}:null!=e&&e.playerUrl?{type:at(e.playerUrl),id:t,videoSrcUrl:e.playerUrl}:void 0}function nt(t,e,i,o){const n=t.match(i);return n?{type:e,id:o(n)}:void 0}function at(t){const e=new URL(t);return e.host.endsWith("yidianzixun.com")?"Yidianzixun":e.host.endsWith("huya.com")?"Huya":e.host.endsWith("micvideo.peopletech.cn")?"Renmin":"YouTube"}function rt(t){if(!t||isNaN(t)||t<=0)return"0:00";return`${Math.floor(t/60)}:${Math.floor(t%60).toString().padStart(2,"0")}`}function st(t){var e;const i=ht((null===(e=t.videoMetadata)||void 0===e?void 0:e.motionThumbnailUrl)??"");return{...t,videoMetadata:{...t.videoMetadata||{},externalVideoFiles:[{url:i,contentType:"video/mp4",format:w.HQ}]}}}function dt(t,e){if(!e)return"";if(null!=t&&t.enableVideoPreview){const t=(0,g.Kc)(e.id??"");return(0,g.CW)(t,e.destinationUrl??"")}return""}function lt(t){var e,i,o,n,a,r;if(!t.jsonDataMap)return t;const s=JSON.parse(t.jsonDataMap.displayValue||"{}"),d=ht((null===(e=s.Video)||void 0===e?void 0:e.MotionThumbnailLink)??"");return{...t,destinationUrl:s.Url,thumbnail:{image:{url:s.ImageUrl,width:s.ImageWidth,height:s.ImageHeight}},videoMetadata:{allowEmbed:"true"===(null===(i=s.Video)||void 0===i?void 0:i.AllowEmbed),allowHttpsEmbed:"true"===(null===(o=s.Video)||void 0===o?void 0:o.AllowHttpsEmbed),allowMobileEmbed:"true"===(null===(n=s.Video)||void 0===n?void 0:n.AllowMobileEmbed),viewCount:Number(null===(a=s.Video)||void 0===a?void 0:a.ViewCount),motionThumbnailUrl:null===(r=s.Video)||void 0===r?void 0:r.MotionThumbnailLink,externalVideoFiles:[{url:d,contentType:"video/mp4",format:w.HQ}]}}}function ht(t){return(0,_._Z)(t)?(0,_.x3)(t):"https://thaka.bing.com/th?id=OCGE.emptyvideoplaceholder"}function ct(t,e){var i;if(null!=t&&t.enableVideoPreview&&null!==(i=t.relatedVideosData)&&void 0!==i&&i.length){const t=(0,g.Kc)((null==e?void 0:e.id)??"");return(0,g.CW)(t,(null==e?void 0:e.destinationUrl)??"")}return null==t?void 0:t.watchMoreButtonUrl}function ut(t,e){var i;return null!=e&&e.enableVideoPreview&&null!==(i=e.relatedVideosData)&&void 0!==i&&i.length?{...t??{},viewOnWatch:null==t?void 0:t.viewDetails}:t}function pt(t,e){const i=null==t?void 0:t.is360VideoAd;return{showAdLabel:i,showAdSkip:i&&!(null!=e&&e.isInDetailPage)}}var vt=i(12680),gt=i(65114),mt=i(47077),yt=i(53588),bt=i(44623),ft=i(11206);const xt=["AdReady","AdError","AdInitiated","AdRequestStarted","AdLoading","AdPlayStarted","AdResume","AdPause","AdPlayCompleted","AdSlotEnded"];var wt=i(24752);class Pt extends ft.a{constructor(){super(...arguments),this.eventNames=["canplay","play","playing","pause","timeupdate","seeked","ended","volumechange","mouseout","mouseover","touchend","progress","qualitychange","waiting","enterpictureinpicture","leavepictureinpicture"],this.type="VideoJs",this.setIsAdsPlaying=t=>{this._isAdsPlying=t},this.normalizeEventData=()=>{const t=this.createContentEvent(),{content:e}=t,{title:i,videoDuration:o}=e;return{...t,isPlayerPaused:this.instance.paused(),content:{...e,videoPositionSec:this.instance.currentTime()??0,title:i,videoDuration:o||this.instance.duration(),videoFormatCode:this.videoFormatCode??mt.s$.HLS}}},this.createAdEventData=(t,e)=>{["AdPlayStarted","AdResume"].includes(t)&&(this._isAdShown=!0,this.setIsAdsPlaying(!0)),["AdPause","AdPlayCompleted","AdSlotEnded"].includes(t)&&this.setIsAdsPlaying(!1),"AdSlotEnded"===t&&(this._isAdShown=!1);const{video:i,pageGroupCode:o,adIndex:n,totalAdTimeWatched:a,adDuration:r,adType:s}=e,{isInline:d,content:l}=this.createContentEvent();return{isInline:d,isPlayerPaused:this.instance.paused()||"AdPause"===t,content:l,ad:{isThirdParty:!1,pageGroupCode:o,adIndex:n,totalAdTimeWatched:a,adDuration:r,adType:s,video:i}}}}initialize(t){let{player:e,playerInfo:i,options:o}=t;this.options=o,super.init(e,e.el(),i),this.subscribeToEvents(),this.observePerfMarkers(),queueMicrotask(()=>this.triggerEvent("ready",this.normalizeEventData()))}play(){this._isAdShown?this.instance.trigger(bt.a0):(super.play(),this.playerInfo.enableAttemptedUnmutedPlay?(0,yt.Q)(this.instance,this.playerInfo.userPersistedMutePreference):this.instance.play(),this.markPlayRequested())}pause(){super.pause(),this._isAdShown&&this.instance.trigger(bt.ds),this.instance.pause()}requestPictureInPicture(){try{!this.instance.isInPictureInPicture()&&this.isPlaying&&this.instance.requestPictureInPicture()}catch(t){}}setMute(t){this.instance.muted(t)}setVolume(t){this.instance.volume(this.normalizeVolume(t))}setClosedCaptions(t){const e=this.instance.textTracks();for(let i=0;i<e.length;i++){const o=e[i];"captions"===o.kind&&(o.mode=t?"showing":"hidden")}}seekBySeconds(t){const e=this.instance.currentTime(),i=this.instance.duration(),o=(0,_.z7)(e,i,t);this.instance.currentTime(o)}dispose(){this.instance.off(),this.instance.dispose(),super.dispose()}get isMuted(){return this.instance.muted()??!1}get volume(){return this.instance.volume()??0}get canProvideVideoPosition(){return!0}get shouldEmulateTimeUpdate(){return!1}createTimeUpdateEventData(){return this.normalizeEventData()}subscribeToEvents(){var t;for(const t of this.eventNames)this.instance.on(t,()=>{if(!this.isAdsPlying||"volumechange"===t)switch(t){case"play":{const t=this.hasStartedPlaying?"resume":"play";this.hasStartedPlaying=!0,this.triggerEvent(t,this.normalizeEventData());break}case"pause":if(this.instance.duration()-this.instance.currentTime()<.5)break;this.triggerEvent("pause",this.normalizeEventData());break;default:this.triggerEvent(t,this.normalizeEventData())}});this.instance.on("fullscreenchange",()=>{const t=this.instance.isFullscreen()?"FullScreenEnter":"FullScreenExit";this.triggerEvent(t,this.normalizeEventData())}),this.instance.on("error",t=>{const{value:e,...i}=(0,_.we)(this.instance.error()??t);return(0,a.vV)(n.Zdj,e,void 0,{videoInfo:this.playerInfo.video,...i})}),null!==(t=this.options)&&void 0!==t&&t.logWaitingErrors&&this.instance.on("waiting",t=>{const e=Math.round(this.instance.currentTime()),i=Math.round(this.instance.duration());return(0,a.vV)(n.mBO,"Video player encountered buffering.","",{videoInfo:this.playerInfo.video,time:e,duration:i})});for(const t of xt)this.instance.on(t,e=>this.triggerEvent(t,this.createAdEventData(t,e)));const e=this.instance.textTracks();e.addEventListener("change",()=>{this.triggerEvent((()=>{for(let t=0;t<e.length;t++){if("showing"===e[t].mode)return"enableSubsCap"}return"disableSubsCap"})(),this.normalizeEventData())})}get qualityLevel(){const t=this.instance.qualityLevels();if(!t)return t[t.selectedIndex]}get videoFormatCode(){if(this.qualityLevel)return mt.s$[this.qualityLevel.label]}observePerfMarkers(){this.observeVideoMarkers(),this.observeVideoAdMarkers()}observeVideoMarkers(){this.addEventListener("ready",()=>{this.perfObserver.mark("ready")},{once:!0}),this.addEventListener("progress",()=>{this.perfObserver.mark("loaded")},{once:!0})}observeVideoAdMarkers(){this.addEventListener("AdInitiated",()=>{this.perfObserver.mark("adRequestStarted",this.playRequestedTime)},{once:!0}),this.addEventListener(["AdPlayStarted","AdError"],()=>{this.perfObserver.mark("adRequestCompleted",this.playRequestedTime)},{once:!0}),this.addEventListener("AdPlayStarted",()=>{this.perfObserver.mark("adPlayStarted",this.playRequestedTime)},{once:!0})}markPlayRequested(){this.perfObserver.markers.playRequested||this.perfObserver.mark("playRequested")}get playRequestedTime(){return this.perfObserver.markers.playRequested}async measureTimeToStart(){super.measureTimeToStart(),this.perfObserver.videoStartupTime.then(t=>{t&&t>wt.q.lateStart&&this.logPlayStartError(n.dmW,`VST Warning: Video started late (passing ${wt.q.lateStart}ms) at ${t}ms`)})}}var $t=i(58792),kt=i(17852),St=i(2171),_t=i(6205),Ct=i(82288),At=i(39750);const Tt=new Map;St.vv.set("videoAdsCacheMap",Tt),St.vv.set("cachedVideoAdsData",[]);class It{static get videoAdsCacheMap(){return St.vv.get("videoAdsCacheMap")}static get cachedVideoAdsData(){return St.vv.get("cachedVideoAdsData")}static set cachedVideoAdsData(t){St.vv.set("cachedVideoAdsData",t)}constructor(t,e,i){this.mouseRecordInfo={x:0,y:0,startTime:0,endTime:0,w:0,h:0},this.isClicked=!1,this.isNotFirstAutoplay=!1,this.previousMutedState=!0,this.prepareSendClickTracking=!1,this.lastWatchedSec=0,this.handleVideoPlayTrack=()=>{var t,e,i;if(null===(t=this.videoData)||void 0===t||null===(t=t.videoAd360Data)||void 0===t||!t.vstarttk.length)return;if(this.isNotFirstAutoplay=!(null===(e=this.getCache(this.videoData.id))||void 0===e||!e.isPlay||this.isClicked),this.isNotFirstAutoplay)return;const o=null===(i=this.player)||void 0===i?void 0:i.isMuted;this.videoData.videoAd360Data.vstarttk.forEach(t=>{const e=this.generalMacroStringReplace(t).replace("__AUDIO_STAT__",o?"0":"1");this.sendTracking(e)}),this.setCache(this.videoData.id,{isPlay:!0}),this.sendTelemetry("AdPlayStarted")},this.handleVideoPauseTrack=()=>{var t;null!==(t=this.videoData)&&void 0!==t&&null!==(t=t.videoAd360Data)&&void 0!==t&&t.vpausetk.length&&this.isClicked&&(this.videoData.videoAd360Data.vpausetk.forEach(t=>{const e=this.generalMacroStringReplace(t);this.sendTracking(e)}),this.sendTelemetry("AdPause"))},this.handleVideoResumeTrack=()=>{var t;null!==(t=this.videoData)&&void 0!==t&&null!==(t=t.videoAd360Data)&&void 0!==t&&t.vcontitk.length&&(0===this.player.lastVideoPositionSec?(this.sendOptTracking("9"),this.isNotFirstAutoplay=!this.isClicked,this.sendTelemetry("AdReplay")):(this.videoData.videoAd360Data.vcontitk.forEach(t=>{const e=this.generalMacroStringReplace(t);this.sendTracking(e)}),this.sendTelemetry("AdResume")))},this.handleVideoEndedTrack=()=>{var t;null!==(t=this.videoData)&&void 0!==t&&null!==(t=t.videoAd360Data)&&void 0!==t&&t.vcomptk.length&&!this.isNotFirstAutoplay&&(this.mouseRecordInfo={...this.mouseRecordInfo,x:0,y:0,startTime:0,endTime:0},this.videoData.videoAd360Data.vcomptk.forEach(t=>{const e=this.generalMacroStringReplace(t);this.sendTracking(e)}),this.sendTelemetry("AdPlayCompleted"))},this.handleVideoClickTrack=t=>{var e,i;if(!this.player||null!==(e=t.target.classList)&&void 0!==e&&e.contains("vjs-video-ad-skip"))return;const{x:o,y:n}=this.player.instance.el().getBoundingClientRect();this.mouseRecordInfo.x=Math.floor(t.clientX-o),this.mouseRecordInfo.y=Math.floor(t.clientY-n),this.mouseRecordInfo.endTime=+new Date,"VIDEO"===(null===(i=t.target)||void 0===i?void 0:i.nodeName)&&(this.prepareSendClickTracking=!0,h.YT.sendActionEvent(t.target,l.EG.Click,l.MS.Navigate),this.sendClickTracking());const a=window.setTimeout(()=>{this.isClicked=!1,window.clearTimeout(a)},50)},this.handleVideoMouseDownTrack=()=>{this.isClicked=!0,this.mouseRecordInfo.startTime=+new Date},this.handleVideoFullScreenEnterTrack=()=>{this.sendOptTracking("3")},this.handleVideoFullScreenExitTrack=()=>{this.sendOptTracking("4")},this.handleVideoVolumeChangeTrack=()=>{this.previousMutedState!==this.player.isMuted&&(this.sendOptTracking(this.player.isMuted?"6":"5"),this.previousMutedState=this.player.isMuted)},this.handleVideoTimeUpdateTrack=()=>{var t;const e=this.player.watchedTimeSec-this.lastWatchedSec,i=(null===(t=this.getCache(this.videoData.id))||void 0===t?void 0:t.totalWatchedSec)??0;this.setCache(this.videoData.id,{totalWatchedSec:i+e}),this.lastWatchedSec=this.player.watchedTimeSec},this.handleVideoAdTitleClick=t=>{var e;(null===(e=t.detail)||void 0===e?void 0:e.id)===this.videoData.id&&(this.player.htmlEl&&h.YT.sendActionEvent(this.player.instance.el(),l.EG.Click,l.MS.Navigate),this.sendClickTracking())},this.handleAdSkipClick=()=>{var t;null!==(t=this.videoData.videoAd360Data)&&void 0!==t&&null!==(t=t.acstk)&&void 0!==t&&t.length&&this.videoData.videoAd360Data.acstk.forEach(t=>{const e=this.generalMacroStringReplace(t).replace("__CLOSE_SCENE_ID__","1").replace("__CLOSE_TAG__","跳过广告");this.sendTracking(e)})},this.player=t,this.videoData=e,this.options=i,this.processPlayer()}static async fetchAds(){var t;if(null!==(t=It.cachedVideoAdsData)&&void 0!==t&&t.length){const t=It.cachedVideoAdsData[0];return It.cachedVideoAdsData=It.cachedVideoAdsData.slice(1),It.sendAdLoadTelemetry(t),t}return new Promise(t=>{try{var e,i;const o=Date.now(),r=`videoAds360Callback_${o}`,s=`videoAds360Script_${o}`;window[r]=function(e){var i;const n=Object.keys(e.adspaces||{});if(!n.length)return It.logEmptyResponseError(),void t(void 0);const a=null===(i=e.adspaces[n[0]])||void 0===i?void 0:i.ads;if(!a.length)return It.logEmptyResponseError(),void t(void 0);const r=a.map((t,e)=>{const i={id:`${o.toString()}_${e}`,abstract:"",posterUrl:t.img??"",title:t.title,is360VideoAd:!0,is3PPVideo:!0,is1PPVideo:!1,isLocalContent:!1,isLocalNews:!1,isWebContent:!0,destinationUrl:t.curl??"",metadata:{},providerLogoUrl:"",providerName:"",url:t.video??"",thumbnail:{image:{url:t.img??""}},videoMetadata:{playTime:t.duration??0,externalVideoFiles:[{url:t.video??"",contentType:"video/mp4",format:w.HQ}]},videoAd360Data:t};return{type:"video",videoDataContentView:i,...i}});It.cachedVideoAdsData=r.slice(1),It.sendAdLoadTelemetry(r[0]),t(r[0])};const d=(null===(e=(0,A.Lg)())||void 0===e?void 0:e.getItem("videoAdPVSingnal"))??"",l=$t.T3.UserId||(null===(i=(0,A.Lg)())||void 0===i?void 0:i.getItem("MUID")),h=(0,At.MD5)(`${l}${window.location.host}${d}`);(0,kt.k)({id:s,src:`https://show-g.mediav.com/s?of=4&newf=2&type=1&showids=C4Whv9&scheme=https&jqhm=1&uid=${h.toString()}&jsonp=${r}`}).catch(t=>{delete window[r],(0,a.vV)(n.mit,`fetch 360 video ads failed: ${(0,_t.M5)(t)}`)}).finally(()=>{const t=document.getElementById(s);t&&t.remove()})}catch(t){(0,a.vV)(n.mit,`fetch 360 video ads failed: ${(0,_t.M5)(t)}`)}})}static async insertAdsToFeed(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:0;if(e<2||t.length<e)return t;const o=[];let n=0;for(let r=0;r<t.length;r++){var a;if(o.push(t[r]),!t[r].is360VideoAd&&"video"===t[r].type)if(n++,!(i!==n&&(n-i)%e!==0||null!==(a=t[r+1])&&void 0!==a&&a.is360VideoAd)){const t=await It.fetchAds();t&&o.push(t)}}return o}static logEmptyResponseError(){"www.msn.cn"===window.location.hostname&&(0,a.vV)(n.mit,"fetch 360 video ads returns as empty")}static sendAdLoadTelemetry(t){t&&h.YT.sendVideoPlayEvent({type:61,name:"360VideoAdEvent",content:{headline:t.title},ext:{eventType:Ct.sy.get("AdLoading"),timeElasped:0,videoDuration:0,title:t.title,playDuration:0,videoUrl:t.url}},void 0,!0)}processPlayer(){if(!this.player)return;const t=this.player.instance.el();this.mouseRecordInfo.w=t.clientWidth,this.mouseRecordInfo.h=t.clientHeight,this.player.addEventListener("play",this.handleVideoPlayTrack),this.player.addEventListener("pause",this.handleVideoPauseTrack),this.player.addEventListener("resume",this.handleVideoResumeTrack),this.player.addEventListener("ended",this.handleVideoEndedTrack),this.player.addEventListener("FullScreenEnter",this.handleVideoFullScreenEnterTrack),this.player.addEventListener("FullScreenExit",this.handleVideoFullScreenExitTrack),this.player.addEventListener("volumechange",this.handleVideoVolumeChangeTrack),this.player.addEventListener("timeupdate",this.handleVideoTimeUpdateTrack),document.addEventListener("videoAdTitleClick",this.handleVideoAdTitleClick),t.addEventListener("click",this.handleVideoClickTrack),t.addEventListener("mousedown",this.handleVideoMouseDownTrack),this.observerElement(t)}destroy(){var t,e,i,o,n,a,r,s,d;if(null===(t=this.player)||void 0===t||t.removeEventListener("play",this.handleVideoPlayTrack),null===(e=this.player)||void 0===e||e.removeEventListener("pause",this.handleVideoPauseTrack),null===(i=this.player)||void 0===i||i.removeEventListener("resume",this.handleVideoResumeTrack),null===(o=this.player)||void 0===o||o.removeEventListener("ended",this.handleVideoEndedTrack),null===(n=this.player)||void 0===n||n.removeEventListener("FullScreenEnter",this.handleVideoFullScreenEnterTrack),null===(a=this.player)||void 0===a||a.removeEventListener("FullScreenExit",this.handleVideoFullScreenExitTrack),null===(r=this.player)||void 0===r||r.removeEventListener("volumechange",this.handleVideoVolumeChangeTrack),null===(s=this.player)||void 0===s||s.removeEventListener("timeupdate",this.handleVideoTimeUpdateTrack),document.removeEventListener("videoAdTitleClick",this.handleVideoAdTitleClick),null!==(d=this.player)&&void 0!==d&&d.htmlEl){var l;const t=null===(l=this.player)||void 0===l?void 0:l.instance.el();null==t||t.removeEventListener("click",this.handleVideoClickTrack),null==t||t.removeEventListener("mousedown",this.handleVideoMouseDownTrack)}}observerElement(t){var e;if(this.videoData&&null!==(e=this.getCache(this.videoData.id))&&void 0!==e&&e.isImp)return;const i=new IntersectionObserver(t=>{t.forEach(t=>{t.intersectionRatio>=.01&&(this.sendExposureTracking(),i.disconnect())})},{threshold:[.01]});i.observe(t)}sendExposureTracking(){var t,e,i,o,n;null===(t=this.videoData)||void 0===t||null===(t=t.videoAd360Data)||void 0===t||!t.imptk.length||null!==(e=this.getCache(this.videoData.id))&&void 0!==e&&e.isImp||(null===(i=this.videoData)||void 0===i||null===(i=i.videoAd360Data)||void 0===i||i.imptk.forEach(t=>{this.sendTracking(t)}),this.setCache(this.videoData.id,{isImp:!0}),null===(o=this.options)||void 0===o||null===(n=o.onImpression)||void 0===n||n.call(o),this.sendTelemetry("AdInitiated"))}setCache(t,e){const i=It.videoAdsCacheMap;null!=i&&i.has(t)?i.set(t,{...i.get(t)??{},...e}):null==i||i.set(t,e)}getCache(t){const e=It.videoAdsCacheMap;return null==e?void 0:e.get(t)}sendClickTracking(){var t,e;(null!==(t=this.videoData)&&void 0!==t&&null!==(t=t.videoAd360Data)&&void 0!==t&&null!==(t=t.hovtk)&&void 0!==t&&t.length||null!==(e=this.videoData)&&void 0!==e&&null!==(e=e.videoAd360Data)&&void 0!==e&&null!==(e=e.clktk)&&void 0!==e&&e.length)&&(this.videoData.videoAd360Data.hovtk.forEach(t=>{const e=this.generalMacroStringReplace(t).replace("__VIDEO_ACTION_ID__","2").replace("__VIDEO_CLIOP_ID__","1");this.sendTracking(e)}),this.videoData.videoAd360Data.clktk.forEach(t=>{const e=this.generalMacroStringReplace(t);this.sendTracking(e)}),window.open(this.curl))}sendOptTracking(t){var e;null!==(e=this.videoData.videoAd360Data)&&void 0!==e&&e.voptk.length&&this.videoData.videoAd360Data.voptk.forEach(e=>{const i=this.generalMacroStringReplace(e).replace("__VIDEO_ACTION_ID__",t);this.sendTracking(i)})}generalMacroStringReplace(t){var e,i;const o=(null===(e=this.getCache(this.videoData.id))||void 0===e?void 0:e.totalWatchedSec)??0,n=Math.floor(o).toString(),a=Math.floor((null===(i=this.player)||void 0===i?void 0:i.lastVideoPositionSec)??0).toString(),r=0===this.mouseRecordInfo.startTime?"__EVENT_TIME_START__":this.mouseRecordInfo.startTime.toString(),s=0===this.mouseRecordInfo.endTime?"__EVENT_TIME_END__":this.mouseRecordInfo.endTime.toString();return t.replace("__ADSIZE_TYPE__","0").replace("__VIDEO_DURATION__",n).replace("__VIDEO_TIME__",a).replace("__EVENT_TIME_START__",r).replace("__EVENT_TIME_END__",s).replace("__OFFSET_X__",this.mouseRecordInfo.x.toString()).replace("__OFFSET_Y__",this.mouseRecordInfo.y.toString()).replace("__ADSPACE_W__",this.mouseRecordInfo.w.toString()).replace("__ADSPACE_H__",this.mouseRecordInfo.h.toString())}sendTracking(t){const e=new Image;e.src=t,e.onload=()=>{e.remove()},e.onerror=()=>{e.remove()}}sendTelemetry(t){var e;if(!this.player.htmlEl)return;const i=this.player.instance.el(),o=Math.floor((null===(e=this.getCache(this.videoData.id))||void 0===e?void 0:e.totalWatchedSec)??0),n=Ct.sy.get(t),a={type:61,name:"360VideoAdEvent",content:{headline:this.videoData.title},ext:{eventType:n,timeElasped:o,videoDuration:this.player.instance.duration(),title:this.videoData.title,isMuted:this.player.isMuted,playDuration:Math.floor(this.player.lastVideoPositionSec??0),videoUrl:this.videoData.url}};h.YT.sendVideoPlayEvent(a,i,!0)}get curl(){return this.videoData?this.generalMacroStringReplace(this.videoData.destinationUrl):""}}var Et=i(11316);class Vt{static async createAndRegister(t,e){const{id:i}=e.playerInfo.video,o=Et.N.getInstance(),n=o.getPlayer(i);if(n)return n;const a=await Vt.create(t,e);if(a){const t=a;t.setTelemetryTarget(e.telemetryTarget),o.registerPlayer(i,t)}return a}static async create(t,e){switch(t.toLowerCase()){case"YouTube".toLowerCase():{const{YouTubePlayer:t}=await Promise.resolve().then(i.bind(i,77848)),o=new t;return await o.initialize(e),o}case"Dailymotion".toLowerCase():{const{DailymotionPlayer:t}=await i.e("experiences_spotlight-card-wc_dist_Mappers_OnThisDay_OnThisDayCardMapper_js-experiences_video-cca9b6").then(i.bind(i,20142)),{js:o,...n}=e;if(!o)return;const a=new t;return await a.initialize({js:o,...n}),a}case"Glomex".toLowerCase():{const{GLomexPlayer:t}=await i.e("libs_windows-widget-shared_dist_compliance_setupMockFeedRegistration_js-libs_video-manager_di-d3cf1d").then(i.bind(i,99437)),{js:o,...n}=e;if(!o)return;const a=new t;return await a.initialize({js:o,...n}),a}case"TimesOfIndia".toLowerCase():{const{TimesOfIndiaPlayer:t}=await i.e("experiences_spotlight-card-wc_dist_Mappers_OnThisDay_OnThisDayCardMapper_js-experiences_video-cca9b6").then(i.bind(i,61449)),o=new t;return await o.initialize(e),o}case"Expressen".toLowerCase():{const{ExpressenPlayer:t}=await i.e("experiences_spotlight-card-wc_dist_ContentTemplates_FollowedPublishers_FollowedPublishersCard-dbc18c").then(i.bind(i,19642)),o=new t;return await o.initialize(e),o}case"MTVKatsomo".toLowerCase():{const{MTVKatsomoPlayer:t}=await i.e("experiences_spotlight-card-wc_dist_ContentTemplates_LocalEvents_LocalEventsCard_template_js-e-d6a770").then(i.bind(i,71390)),o=new t;return await o.initialize(e),o}case"Oath".toLocaleLowerCase():{const{OathPlayer:t}=await i.e("MarketRoamingCoachMark").then(i.bind(i,91231)),o=new t;return await o.initialize(e),o}case"CorriereDellaSera".toLocaleLowerCase():{const{CorriereTVPlayer:t}=await i.e("ChannelStoreMarketSelector").then(i.bind(i,28528)),o=new t;return await o.initialize(e),o}case"RAI".toLocaleLowerCase():{const{RAIPlayer:t}=await i.e("nurturing-placement-manager").then(i.bind(i,19389)),o=new t;return await o.initialize(e),o}case"Mediaset".toLocaleLowerCase():{const{MediasetPlayer:t}=await i.e("experiences_spotlight-card-wc_dist_ContentTemplates_LocalEvents_LocalEventsCard_template_js-e-d6a770").then(i.bind(i,75351)),o=new t;return await o.initialize(e),o}case"Stadium".toLocaleLowerCase():{const{StadiumPlayer:t}=await i.e("CnexEndBanner").then(i.bind(i,87530)),o=new t;return await o.initialize(e),o}case"NBCSports".toLocaleLowerCase():{const{NBCSportsPlayer:t}=await i.e("experiences_spotlight-card-wc_dist_ContentTemplates_DailyQuiz_DailyQuizCard_styles_js-libs_fi-fbe3c0").then(i.bind(i,56639)),o=new t;return await o.initialize(e),o}default:return}}}class zt{static async createAndRegister(t,e){const i=Et.N.getInstance(),{id:o}=e.playerInfo.video,n=i.getPlayer(o);if(n)return n;const a=await zt.create(t,e);return a&&i.registerPlayer(o,a),a}static async create(t,e){switch(t.toLowerCase()){case"YouTube".toLowerCase():{const{YouTubePlayer:t}=await Promise.resolve().then(i.bind(i,77848)),o=new t;return await o.initialize(e),o}case"PlutoTv".toLowerCase():{const{PlutoTvPlayer:t}=await i.e("na-trending").then(i.bind(i,86677)),o=new t;return await o.initialize(e),o}case"Yidianzixun".toLowerCase():{const{YiDianPlayer:t}=await Promise.resolve().then(i.bind(i,24197)),o=new t;return await o.initialize(e),o}case"ShortTv".toLowerCase():{const{ShortTvPlayer:t}=await i.e("nurturing-placement-manager").then(i.bind(i,93373)),o=new t;return await o.initialize(e),o}case"GenericIframe".toLowerCase():{const{GenericIframePlayer:t}=await i.e("na-trending").then(i.bind(i,30556)),o=new t;return await o.initialize(e),o}case"Huya".toLowerCase():{const{HuYaPlayer:t}=await Promise.resolve().then(i.bind(i,80790)),o=new t;return await o.initialize(e),o}case"Renmin".toLowerCase():{const{RenminPlayer:t}=await Promise.resolve().then(i.bind(i,9368)),o=new t;return await o.initialize(e),o}default:return}}}var Dt=i(39671),Ft=i(74849);const Mt="#616161",Ot=Ft.A` .toggle-switch{margin:0}.toggle-switch::part(switch){border-color:${Mt}}.toggle-switch::part(checked-indicator){background:${Mt}}.checked::part(checked-indicator){background:#FFF}`;var Lt=i(77558);const Rt=Ft.A`
.cbsEmbed_root{margin-bottom:calc(48px - 13%)}.cbsEmbed_root > iframe{aspect-ratio:1600/1120}@media (max-width:599px){.cbsEmbed_root{margin-bottom:calc(28px - 13%)}}`,Bt=Ft.A` .leads-gen-ads-player{position:absolute;top:0;right:0;bottom:0;left:0;&.hidden{display:none}}`,Nt=Ft.A`
carded-container video-wrapper{clip-path:inset(0% round 8px)}carded-container .related-video-divider-top{border:none;padding-top:0}carded-container .video-title{display:flex;font-size:14px;margin:-2px 0px 10px}carded-container .related-video-divider-bottom::after{content:none}carded-container .videocardRelatedVideo,carded-container .videocardRelatedVideo3PP{margin-bottom:3px}`,Ut=Ft.A`
:host{display:block;height:var(--custom-video-card-host-height,100%)}:host([hidden]){display:none}.video-title{overflow:hidden;-webkit-line-clamp:2;display:-webkit-box;-webkit-box-orient:vertical}.video-footer-container{align-items:end;display:grid;grid-template-columns:2;grid-template-rows:20px 24px;padding-top:8px;padding-inline-start:22px;position:relative}.video-footer-container::before{position:absolute;top:6px;display:inline-block;height:12px;width:12px;border-left:2px solid #0078D4;border-bottom:2px solid #0078D4;content:""}.video-footer-container > span{font-weight:400;line-height:20px;overflow:hidden;-webkit-line-clamp:1;display:-webkit-box;-webkit-box-orient:vertical}.video-footer-title{font-size:14px;grid-column:1 / 3;grid-row:2;height:20px}.video-footer-provider{height:100%;display:flex;align-items:center;line-height:20px}.video-footer-provider-title{font-size:14px;grid-column:1;grid-row:1;padding-inline-start:5px}.video-button-container{grid-column:2;grid-row:1;display:flex;flex-direction:row-reverse}.partner-embed-placeholder{aspect-ratio:16 /9;width:100%;background:#F2F2F2;border-radius:6px}.related-video-title-bold{font-weight:600}.related-video-divider{border-bottom:1px solid rgba(0,0,0,0.09);margin-bottom:20px;padding-bottom:8px}.related-video-divider > svg{padding-right:8px}.related-video-divider-top{border-top:1px solid rgba(0,0,0,0.09);padding-top:8px;margin-block-end:8px}.related-video-divider-top:focus-visible{outline-offset:-2px}.related-video-divider-top > img{margin-inline-end:8px;background-image:linear-gradient(white,white);background-size:8px 8px;background-position:center;background-repeat:no-repeat}.related-video-divider-bottom::after{content:'';border-bottom:1px solid rgba(0,0,0,0.09);position:absolute;left:0;right:0;margin-top:20px;bottom:-20px}.related-video-divider-bottom-title::after{content:'';border-bottom:1px solid rgba(0,0,0,0.09);position:absolute;left:0;right:0;bottom:-15px}.related-video-link{color:inherit;text-decoration:none}.related-video-link[href]:hover{text-decoration:underline}.blue-marker-before::before{content:'';position:absolute;width:48px;height:4px;left:0;right:0;top:-10px;background:#0078D4}.blue-marker-after:after{content:'';position:absolute;width:48px;height:4px;left:0;right:0;margin-top:9px;background:#0078D4}.video-clear-div{clear:both;display:block}.video-wrapper{position:relative;width:100%;height:100%}.video-wrapper:focus-visible{outline:none}.video-wrapper:focus-visible::before{content:"";inset:0;position:absolute;border:3px solid black;border-radius:12px 12px 0px 0px;filter:drop-shadow(0px 0px 2px white);pointer-events:none;z-index:${Lt.P.Above.toString()}}.video-wrapper-error{display:block;width:100%;border-radius:6px;overflow:hidden;aspect-ratio:16/9}.video-wrapper.is-in-iframe{height:100vh}.video-wrapper:hover unmuted-button::part(unmuted-button){background:rgba(0,0,0,0.5)}.video-wrapper:hover unmuted-button::part(unmuted-button-text){opacity:1}.videocard1PP{position:relative;width:100%;height:100%}.videocardImagePlaceholderContainer{overflow:hidden;position:relative;opacity:1;transition:opacity 1s ease-out;z-index:${Lt.P.Default.toString()}}.video-play-button-container{display:block;height:40px;left:50%;opacity:1;padding:0;position:absolute;top:124px;transform:translate(-50%,-50%);transition:all 0.4s ease 0s;width:40px}.video-play-button{align-items:center;display:flex;height:100%;justify-content:center;width:100%}.videocard1PP .video-js.vjs-msn{position:absolute}.videocard1PP .vjs-menu-item-text{font-size:.9em}.videocard1PP .vjs-menu-content{max-height:20em;width:115%}.videocard1PP .vjs-text-track-settings{position:absolute !important}.bingEmbed_root{position:relative;width:100%;height:100%}.directEmbed_root{position:relative;width:100%;height:100%}.directEmbed_root.fb{display:flex;justify-content:center}.videocard3PP{position:relative;aspect-ratio:16/9;width:100%;height:100%}.videocard3PP iframe{overflow:hidden}::slotted([slot="js-embed"]){width:100%;height:100%;overflow:hidden;align-content:center}.videocard3PPNotice{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);height:15px;padding:0 .1rem;float:left}.videocardRelatedVideo{box-sizing:content-box !important;margin-bottom:32px;position:relative;aspect-ratio:16/9}.videocardRelatedVideo3PP{margin-bottom:36px}.videocard3PPNotice a,.videocard3PPNotice a:link{color:#004}.video-embed-common-ux-impr{border-radius:6px}.remove-overflow{overflow:hidden}.video-card-image-preview-overlay{z-index:0;position:absolute;top:0;left:0;width:100%;height:100%;aspect-ratio:1.77778 / 1}.video-card-image-preview-overlay img{width:100%;height:100%;object-fit:cover;cursor:pointer;border-radius:6px}.is-cn-consumption-page next-videos-overlay-wc::part(next-videos-overlay),.is-cn-consumption-page .videocard1PP{z-index:1}${Rt}

${Ot}

${Nt}
    
${Bt}

`.withBehaviors((0,P.sX)(Ft.A` .videocard3PPNotice{color:var(--videocard3ppnotice-dark,#FFF)}.videocard3PPNotice a,.videocard3PPNotice a:link{color:var(--videocard3ppnotice-link-dark,#AAF)}.related-video-divider{border-bottom-color:rgba(100,100,100,1)}.related-video-divider-top{border-top-color:rgba(100,100,100,1)}.related-video-divider-bottom::after{border-bottom-color:rgba(100,100,100,1)}.related-video-divider-bottom-title::after{border-bottom-color:rgba(100,100,100,1)}.partner-embed-placeholder{background:#4A4A4A}`)),jt=" body,html{margin:0;padding:0}";class Gt{static enableGamepadListeners(t){if(t){const e=e=>{t.connectHandler(e)},i=e=>{t.disconnecthandler(e)};window.addEventListener("gamepadconnected",e),window.addEventListener("gamepaddisconnected",i),t.connectKeyboardHandler(),t.addFocusListeners()}}static disableGamepadListeners(t){if(t){const e=e=>{t.connectHandler(e)},i=e=>{t.disconnecthandler(e)};window.removeEventListener("gamepadconnected",e),window.removeEventListener("gamepaddisconnected",i),t.disconnectKeyboardHandler(),t.removeFocusListeners()}}}var Wt=i(83222),Ht=i(77381),Yt=i(93320);function qt(){for(var t=arguments.length,e=new Array(t),i=0;i<t;i++)e[i]=arguments[i];if(!e||e.length<2||!(0,Ht.P5)(e[e.length-1]))throw new Error("Invalid arguments");const o=e.pop(),n=(0,Yt.R)(...e),a=Object.assign(n,o);return new Wt.$(a).render()}var Jt=i(41065),Kt=i(19359),Xt=i(90719);class Qt extends Dt.U{get currentPlayer(){return this.videoCardManager.getPlayer(this.videoId)}get hasReceivedSlateData(){var t;return null===(t=this.context)||void 0===t?void 0:t.slateDataGetter}get shouldFetchSlateData(){return this.config.enableSlate&&!this.hasReceivedSlateData}get shouldAddRelatedPlaylist(){var t;let e=this.config.addRelatedPlayList||!1;return void 0!==(null===(t=this.context)||void 0===t?void 0:t.addRelatedPlayListOverride)&&(e=this.context.addRelatedPlayListOverride),e}get deeplinkUrl(){var t,e;if(null===(t=this.videoCardProps)||void 0===t||null===(t=t.videoData)||void 0===t||!t.id||null===(e=this.videoCardProps)||void 0===e||null===(e=e.videoData)||void 0===e||!e.title)return null;const{videoData:i,directEmbedMedia:o}=this.videoCardProps||{},{id:n,title:a,destinationUrl:r}=i||{};if(!n||!a||o&&N(o.type))return null;if(this.isChinaArticleComsuptionPage){const t=(0,g.Kc)(n);return(0,g.CW)(t,r??"",a)}return(0,g.FA)(n,a)}get enableImagePreview(){var t,e;if(null===(t=this.context)||void 0===t||!t.enableVideoPreview)return!1;const i=null===(e=this.videoCardState)||void 0===e||null===(e=e.videoData)||void 0===e||null===(e=e.videoMetadata)||void 0===e?void 0:e.motionThumbnailUrl;if(!i)return!0;const o=new URL(i);return!Object.values(gt.yB).includes(o.origin)}constructor(){super(),this.ensureObservableBeforeConnect=!0,this.videoPlayList=[],this.isVideoPlayListDefined=!1,this.vidId="",this.videoIds=[],this.nextVideosOverlayFetchedData=[],this.stopPlayOnError=!1,this.extractedRelatedData=[],this.isFirstVideoFromPlaylist=!0,this.videoPlayType="pb",this.id="",this.errorMessage="",this.videoCardState={},this.hasValidPreviewData=!1,this.isRecommendedVideos=!1,this.didFireUnwantedVideoError=!1,this.atLeastOneValidVideoFetched=!1,this.configureTimeBasedAdFrequencyCap=()=>{const t=F(this.config,this.context);if(this.config.hasAdTimeBasedCap&&!t){var e,i,o,n;const{adTimeBasedCapSec:t=90,inStreamVideoAd:a}=this.config,{preRollPgCode:r,midRollPgCode:s}=(null===(e=this.context)||void 0===e?void 0:e.inStreamVideoAd)||{},d=r||(null==a?void 0:a.preRollAdPgCode),l=s||(null==a?void 0:a.midRollAdPgCode)||(null!==(i=this.config)&&void 0!==i&&i.enableMidOverridePgCode?null===(o=this.config)||void 0===o?void 0:o.consumptionMidrollPGCode:void 0),h=null==a?void 0:a.enableProgTimeBasedMidrollAds;(d||this.isChinaArticleComsuptionPage||null!==(n=this.config)&&void 0!==n&&n.enableMidOverridePgCode&&l)&&this.videoCardManager.enableTimeBasedAdCap(t,{preRollPgCode:d??"",midRollPgCode:l},!!h)}},this.handleMessages=async(t,e)=>{if(t&&"boolean"!=typeof t)switch(t.type){case"ended":if(!this.config.continuePlay&&!this.hasReceivedSlateData)break;if(this.config.enableSlate){this.showSlate("ended");const t=null==e?void 0:e.getChild("TitleBar");t&&t.hide();break}!this.config.enableAutoPlayToggle&&this.getUserPreferenceForPlaylistToggle()&&this.tryFetchNextVideoFromPlayList();break;case"pause":this.shouldShowPauseSlate(e)&&this.showSlate("pause");break;case"play":!this.didFireUnwantedVideoError&&this.isCurrentVideoUnwanted()&&(this.didFireUnwantedVideoError=!0,this.sendUnwantedVideoError()),this.config.enableSlate&&this.hideSlate();break;case"resume":case"seeked":this.hideSlate();break;case"ready":this.setUpMsnPlayer(e)}},this.onPauseSlateOverlayClick=()=>{var t;this.hideSlate(),null===(t=this.currentPlayer)||void 0===t||t.play()},this.onEndSlateOverlayClick=()=>{var t,e;this.hideSlate(),null===(t=this.currentPlayer)||void 0===t||t.resetPlayer(),null===(e=this.currentPlayer)||void 0===e||e.play()},this.eventsCallbackFromUpNextVideoCard=async t=>{void 0!==t&&(this.nextVideosOverlayFetchedData=[],this.hideSlate(),this.isFirstVideoFromPlaylist=!1,this.videoPlayList.shift(),await this.fetchVideoDocument(t,!0),this.shouldAddRelatedPlaylist&&this.setVideoTitlePrefix(t))},this.handleNextVideoFromPlaylist=t=>{const e=this.videoIds[this.videoIds.length-1];this.videoCardManager.getPlayer(e)&&t&&this.videoCardManager.deregisterPlayer(e)},this.isVideoDataValid=(t,e,i)=>{var o;if(!t||t instanceof Error)return(0,m.Wr)(n.IIt,`Video ID [${(0,m.H8)(void 0,e,i)}] is null.`),!1;if(Array.isArray(t))return(0,m.Wr)(n.SEO,`Video ID [${(0,m.H8)(void 0,e,i)}] was taken down.`),!1;return!!((null===(o=this.context)||void 0===o?void 0:o.enableVideoPreview)||this.is360VideoAd||(0,m.RD)(t,e,i)||this.isFetchedContentDetails3PPValid(t))||((0,m.Wr)(n.WWk,`Video ID [${(0,m.H8)(t.id,e,i)}] has invalid 3pp content.`),!1)},this.setUpMsnPlayer=t=>{var e,i,o,n,a,r;const s=null===(e=this.videoCardState)||void 0===e?void 0:e.videoData;if(!t||null==s||!s.id)return;const{isInline:d=!1,colorSampling:l=!1}=this.config,{isContentBingmm:h=!1,isPartnerEmbed:c,isLocal:u=!1}=this.context||{},p=!(null===(i=this.videoCardProps)||void 0===i||null===(i=i.playerConfigProps)||void 0===i||!i.autoplay),v=et(s,l,c,h,this.isFirstVideoFromPlaylist,d,u,p,null===(o=this.context)||void 0===o?void 0:o.recoId,null===(n=this.videoCardProps)||void 0===n||null===(n=n.playerConfigProps)||void 0===n?void 0:n.enableAttemptedUnmutedPlay,null===(a=this.videoCardProps)||void 0===a||null===(a=a.playerConfigProps)||void 0===a?void 0:a.userPersistedMutePreference);if(!v)return;const{id:g}=v.video;if(this.videoCardManager.getPlayer(g))return;const m=new Pt;m.initialize({playerInfo:v,player:t,options:{logWaitingErrors:null===(r=this.config.bufferOptions)||void 0===r?void 0:r.logWaitingErrors}}),this.videoCardManager.registerPlayer(g,m),this.setUpEventsCallbackTrigger(m),s.is360VideoAd&&(this.videoAds360Service=new It(m,s))},this.setUpThirdPartyPlayers=async(t,e,i,o)=>{const{autoReplay:n,isInline:a=!1,shouldUseRetryWithDelay:r=!1,continuePlay:s=!1,colorSampling:d=!1}=this.config,{isPartnerEmbed:l,isContentBingmm:h=!1,isLocal:c=!1}=this.context||{},{videoData:u,enablePlayInViewport3pp:p,isAutoPlayEnabledForWebContent:v,playerConfigProps:g}=this.videoCardProps||{},m=Boolean(null==g?void 0:g.autoplay),y=Boolean(null==g?void 0:g.inViewPlay),b=null==g?void 0:g.inViewPlayRatio,f=et(u,d,l,h,this.isFirstVideoFromPlaylist,a,c,m,void 0,null==g?void 0:g.enableAttemptedUnmutedPlay,null==g?void 0:g.userPersistedMutePreference);if(!f)return;if(Boolean(Et.N.getInstance().getPlayer(f.video.id)))return;const x=this.thirdPartyPlayerParentContainerRef,w=this.thirdPartyPlayerContainerRef;if(!w||!x)throw new Error("Third party player container or its parent is not defined");const P={playerInfo:f,container:w,telemetryTarget:x,isAutoplay:Boolean(this.config.enableTitleAtBottom?this.videoCardState.isInViewPlayEnabled:v),isAutoReplay:n||!1,shouldUseRetryWithDelay:r,feedId:null==u?void 0:u.feedId,playerSettingsId:i,playerNoAutoPlaySettingsId:o,seo:null==u?void 0:u.seo,enablePlayInViewport3pp:p,inViewPlay:y,inViewPlayRatio:b};if(e&&e.src){const{src:t,async:i=!0,propBag:o,externalLibs:n=[]}=e;P.js={src:t,async:i,propBag:o,externalLibs:n}}const $=await Vt.createAndRegister(t,P);$&&(this.setUpEventsCallbackTrigger($),s&&!l&&this.enablePlayerPlaylistMode($))},this.loadDirectEmbedMediaPlayer=async(t,e)=>{if(!this.demPlayerContainerRef)return;const{id:i,type:o}=t;if(!i||!o)return;const{isInline:n=!1,autoReplay:a=!1,shouldUseRetryWithDelay:r=!1,useLeadsGenVideoAds:s=[]}=this.config,{isPartnerEmbed:d,isContentBingmm:l=!1,isLocal:h=!1}=this.context||{},{isAutoPlayEnabledForWebContent:c=!1,playerConfigProps:u}=this.videoCardProps||{},p=Boolean(null==u?void 0:u.inViewPlay),v=null==u?void 0:u.inViewPlayRatio,g=it(t,e,d,l,this.isFirstVideoFromPlaylist,n,h,c,s);if(!g)return;const m={playerInfo:g,container:this.demPlayerContainerRef,isAutoplay:c,isAutoReplay:a,shouldUseRetryWithDelay:r,inViewPlay:p,inViewPlayRatio:v},y=await zt.createAndRegister(o,m);y&&(this.setUpEventsCallbackTrigger(y),this.embedMediaPlayer=y,y.enableLeadsGenVideoAds&&this.videoCardManager.registerPlayer(g.video.id,y))},this.setupVPTestFlights=()=>{if(!y())return;const t={"*":"MSNTESTPG",autos:"MSNTESTPG",entertainment:"MSNTESTPG",lifestyle:"MSNTESTPG",money:"MSNTESTPG",news:"MSNTESTPG",sports:"MSNTESTPG",weather:"MSNTESTPG",foodanddrink:"MSNTESTPG",health:"MSNTESTPG",travel:"MSNTESTPG"},e={"*":t,article:t,video:t};this.config.inStreamVideoAd?"string"==typeof this.config.inStreamVideoAd.preRollAdPgCode?this.config.inStreamVideoAd.preRollAdPgCode=e:"object"==typeof this.config.inStreamVideoAd.preRollAdPgCode&&(this.config.inStreamVideoAd.preRollAdPgCode.article=t,this.config.inStreamVideoAd.preRollAdPgCode.video=t):this.config.inStreamVideoAd={preRollAdPgCode:e,midRollAdPgCode:e,isPrebidEnabled:!0}},this.handleAdSkipClick=()=>{var t,e,i;this.is360VideoAd&&(null===(t=this.videoAds360Service)||void 0===t||t.handleAdSkipClick(),null===(e=this.context)||void 0===e||null===(i=e.skipVideoAdHandler)||void 0===i||i.call(e))},this.videoCardManager=Et.N.getInstance()}async experienceConnected(){this.setupVPTestFlights(),this.markVisuallyReadyRaf(),this.buildTelemetryContext(this.telemetryObject),await this.initializeExperience();const{getPrivacyLinks:t,relatedVideosData:e}=this.context||{};var i;e&&(this.extractedRelatedData=e,this.context&&(this.context.isLocal=!(null===(i=this.extractedRelatedData)||void 0===i||!i.length||!this.extractedRelatedData[0].isLocal)));t&&this.getThirdPartyLinks()}disconnectedCallback(){var t,e;super.disconnectedCallback(),null===(t=this.videoAds360Service)||void 0===t||t.destroy(),this.videoCardManager.disableBingIframeCommunicator(),this.deregisterPlayer(),Gt.disableGamepadListeners(null===(e=this.gamepadYTService)||void 0===e?void 0:e.getInstance())}async shadowDomPopulated(){this.shouldRenderLoadingState&&await this.fetchVideoPlayer(),await this.conditionallyLoadDirectEmbedMediaPlayer()}async initializeExperience(){var t;const{isContentBingmm:e,isPartnerEmbed:i}=this.context||{};this.videoPlayType=e||i?"embed":"pb",this.stopPlayOnError=Boolean(this.config.stopPlayOnError&&i),this.initVideoCardManagerConfig();await this.initDirectEmbedMedia()||(this.vidId=this.id,this.initVideoCardState(),null!==(t=this.config)&&void 0!==t&&t.enableConsumptionMidroll&&this.scheduleMidRollAd(),this.shouldRenderLoadingState||await this.fetchVideoPlayer())}initVideoCardState(){var t;this.videoCardState.isContentBingmm=null===(t=this.context)||void 0===t?void 0:t.isContentBingmm,this.videoCardState.embeddedDimensions=this.estimatedDimensions,this.videoCardState.isInViewPlayEnabled=this.config.inViewPlay}scheduleMidRollAd(){var t,e;const i=Xt.o3.getInstance(),o=(null===(t=this.config)||void 0===t?void 0:t.consumptionMidrollPGCode)??"VDLXUEMRRBHP";if(i.hasMidRollAds){if(null!==(e=this.config)&&void 0!==e&&e.enableMidOverridePgCode&&i.scheduledMidRollPgCode!==o){var n;i.markMidRollAdAsRequested(!1),i.scheduleMidRollAd({pgCode:o,isFixedSlotAd:!0});const{inStreamVideoAd:t}=this.config,{preRollPgCode:e}=(null===(n=this.context)||void 0===n?void 0:n.inStreamVideoAd)||{},a=e||(null==t?void 0:t.preRollAdPgCode)||"";this.videoCardManager.updateTimeBasedAdCapPgCodes({preRollPgCode:a,midRollPgCode:o})}}else i.scheduleMidRollAd({pgCode:o,isFixedSlotAd:!0})}async initDirectEmbedMedia(){var t;if(null!==(t=this.context)&&void 0!==t&&t.enableVideoPreview||this.is360VideoAd)return!1;const e=await this.createEmbedMediaFromURL();var i;return!!e&&(e.videoSrcUrl&&this.ytGamepadSatoriId&&await this.initializeNextVideosGamepadYT(e.videoSrcUrl),e.eventsCallback=null===(i=this.context)||void 0===i?void 0:i.eventsCallback,this.videoCardState.directEmbedMedia=e,this.updateVideoCardProps(),!0)}initVideoCardManagerConfig(){var t,e,i,o;const{contentContinueEventIntervalSec:n,enableOutOfViewPlayLogger:a,enablePreviewEvents:r,enableSingleVideoPlayService:s,enableStarRatingSvc:d,enableVisibilityService:l,isInIframe:h,inViewPlayRatio:u,stopOutOfViewPlay:p,enableRecoSignals:v}=this.config;"number"==typeof n&&(ft.a.contentContinueEventIntervalSec=n),this.configureTimeBasedAdFrequencyCap(),this.configureCustomTimeouts(),this.configurePlayerPreferenceService(),null!==(t=this.config)&&void 0!==t&&t.enableMidOverridePgCode&&this.videoCardManager.enableMidRollOverride(),s&&this.videoCardManager.enableSingleVideoPlayService(),v&&this.videoCardManager.enableRecoSignals(),d&&null!==(e=this.context)&&void 0!==e&&e.canTriggerStarRating&&this.videoCardManager.enableTriggerStarRatingService(),h&&(this.id=c._3.getQueryParameterByName("id",location.href)||"",this.applyGlobalStyles(),this.videoCardManager.enableBingIframeCommunicator()),l&&this.videoCardManager.enableVisibilityService(u,p),(r||null!==(i=this.context)&&void 0!==i&&i.enablePreviewEventsByParent)&&this.videoCardManager.enablePreviewEventDispatcher(),a&&this.videoCardManager.enableOutOfViewPlayLogger(),this.videoCardManager.enableTelemetry(),null!==(o=this.context)&&void 0!==o&&o.enableVideoPreview||this.config.isCNProviderPage||this.videoCardManager.enableComscore(),this.videoCardManager.enableBBCTrackingService()}async fetchVideoPlayer(){this.vidId||(this.fetchVideoPlaylistFromFeed(),this.vidId=this.popNextVideoFromPlaylist()),await this.fetchVideoAndLoadPlayer()}configureCustomTimeouts(){const{hasCustomTimeouts:t}=this.config;if(t){const{loadInactivitySec:t=2,mouseInactivitySec:e=2,touchEndInactivityTimeoutSec:i=2}=this.config;this.videoCardManager.hasCustomTimeouts(t,e,i)}}configurePlayerPreferenceService(){const{enablePlayerPreferenceService:t}=this.config;if(t){var e,i;const{enableStickyCCPreference:t=!1,enableStickyVolPreference:o=!1,enablePersistentVolume:n=!1,enableSessionPersistentVolume:a=!1,enableTitleAtBottom:r=!1,pictureInPictureToggle:s=!1,enableAttemptedUnmutedPlay:d=!1}=this.config,l=null!==(e=this.context)&&void 0!==e&&e.enableDetailEnhance&&null!==(i=this.context)&&void 0!==i&&i.isInDetailPage?.5:void 0;this.videoCardManager.enablePlayerPreferenceService({enableStickyCC:t,enableStickyVolume:o,enablePersistentVolume:n,enableSessionPersistentVolume:a,enableInViewPlayToggle:r,enablePersistentMute:d,enablePip:s,defaultPersistentVolume:l})}}async conditionallyLoadDirectEmbedMediaPlayer(){var t,e;if(null!==(t=this.videoCardProps)&&void 0!==t&&t.directEmbedMedia){if(null===(e=this.context)||void 0===e||!e.directEmbedMediaPlayerProps)return this.ytGamepadSatoriId&&this.gamepadYTService?(await this.loadDirectEmbedMediaPlayer(this.videoCardProps.directEmbedMedia,{}),void this.initializeXboxGamepadControls()):void 0;await this.loadDirectEmbedMediaPlayer(this.videoCardProps.directEmbedMedia,this.context.directEmbedMediaPlayerProps)}}initializeXboxGamepadControls(){var t;this.gamepadYTService.setInstance(this.currentPlayer,this.videoCardRef,null===(t=this.videoCardProps)||void 0===t?void 0:t.localizedStrings),Gt.enableGamepadListeners(this.gamepadYTService.getInstance()),this.gamepadYTService.ready()}async createGamepadService(){const{GamepadService:t}=await i.e("libs_gamepad-utils_dist_index_js").then(i.bind(i,58512));this.gamepadYTService=t}buildTelemetryContext(t){var e;t?(t.contract.ext=this.createVideoTelemetryExtContractDataWebContent(null===(e=this.context)||void 0===e?void 0:e.directEmbedMediaPlayerProps),this.videoTelemetryContext={parentTelemetry:t,parentTelemetryTags:t.render(),thirdPartyPlayerTelemetryTags:qt("VideoCard3PP",{type:l.MJ.VideoPlayer}),autoPlayToggleTelemetryTags:{autoPlayOn:(0,Jt.N)("AutoPlayToggleOn",l.MS.TurnOn,l.MJ.ActionButton).getMetadataTag(),autoPlayOff:(0,Jt.N)("AutoPlayToggleOff",l.MS.TurnOff,l.MJ.ActionButton).getMetadataTag()},relatedVideoTitleLink:(0,Kt.l)("RelatedVideoTitleLink",{id:this.id},l.MS.Navigate)}):this.videoTelemetryContext={}}async fetchVideoAndLoadPlayer(){await this.fetchVideoDocument(this.vidId),this.shouldAddRelatedPlaylist&&this.setVideoTitlePrefix(this.vidId,!0)}createVideoTelemetryExtContractDataWebContent(t){if(!t)return{};const{rid:e,width:i=0,height:o=0,title:n,recoRequestId:a}=t;return{videoCs:e,videoFormatCode:1006,title:n,videoDuration:0,pageGroup:"",playerInstanceId:"",playType:this.videoPlayType,playerTech:"HTML5",pluginVersion:"HTML5",recoId:a,size:`${i}x${o}`,videoPlayerType:"mp4:progressive",playerType:"HTML5",videoUrl:this.id}}getExperienceType(){return vt.Jqf}updateVideoCardProps(){var t,e,i;const o=(null===(t=this.context)||void 0===t?void 0:t.isContentBingmm)&&(null===(e=this.extractedRelatedData)||void 0===e?void 0:e.length)&&this.extractedRelatedData.filter(t=>{var e;return t.id==(null===(e=this.videoCardState.videoData)||void 0===e?void 0:e.id)})||[];null!=o&&o.length&&(!this.context&&(this.context={}),this.context.isLocal=o[0].isLocal);const n=this.processConfigForVideoCardProps(),a=this.config.enableContentSpecificAdKvp?(null===(i=this.telemetryOverrides)||void 0===i?void 0:i.parentId)||this.vidId:void 0;this.videoCardProps=M(this.videoCardState,n,this.context,a),this.config.enableTitleAtBottom&&void 0===this.videoCardProps.onMessage&&(this.videoCardProps.onMessage=this.handleMessages)}processConfigForVideoCardProps(){const t={};return this.isChinaArticleComsuptionPage&&(t.muted=this.videoCardManager.getPreference("isMuted")??this.config.muted),this.enableImagePreview&&(t.disableFullscreen=!0),{...this.config,...t}}getThirdPartyLinks(){var t,e,i;const o=null===(t=this.config.thirdPartyPlayersConfig)||void 0===t?void 0:t.players;null===(e=this.context)||void 0===e||null===(i=e.getPrivacyLinks)||void 0===i||i.call(e,o)}getUserPreferenceForPlaylistToggle(){return void 0===this.config.inViewPlay||this.config.inViewPlay}shouldShowPauseSlate(t){if(!t)return;const e=t.currentTime(),i=t.duration(),o=!t.seeking();return i-e>=1&&e>5&&o}showSlate(t){this.shouldFetchSlateData?this.showSlateWithFetchedData(t):this.showSlateWithProvidedData(t)}showSlateWithFetchedData(t){var e;const i=W(this.nextVideosOverlayFetchedData)||[];let o=!1,n=!1,a=0;switch(t){case"pause":if(a=H(),n=0!==a&&i.length>=a,!n)return;break;case"ended":if(a=3,o=i.length===a,!o)return this.nextVideosOverlayFetchedData=[],void this.tryFetchNextVideoFromPlayList();n=!0}const r=this.videoCardProps&&this.videoCardProps.localizedStrings,s={upNextVideoSec:this.config.upNextSec||0,relatedVideoLocalizedText:r&&r.moreVideos?r.moreVideos:"More videos",nextVideosOverlayData:i.slice(0,a),upNextCardLocalizedText:r&&r.upNextIn?r.upNextIn:"Up next in",showUpNextCard:o,noTimer:this.shouldNotHaveNextVideosOverlayTimer((null===(e=i[0])||void 0===e?void 0:e.id)||""),showPauseSlate:n,isLargeTitleVideoPlayer:this.config.enableLargeTitle,onCloseClick:()=>this.hideSlate(),onOverlayClick:o?()=>!0:this.onPauseSlateOverlayClick,onUpNextVideoTimerDone:this.eventsCallbackFromUpNextVideoCard,applyEmbeddedVideoThumbnailStyles:this.applyEmbeddedVideoThumbnailStyles};this.nextVideosOverlayData=s}showSlateWithProvidedData(t){var e;if(null===(e=this.context)||void 0===e||!e.slateDataGetter)return;const{disablePauseSlate:i,disablePauseOnBlur:o,disableUpNextLink:n,enableReplayOnBackdropClick:a,endSlateCountDownTime:r,onEndSlateCountDownComplete:s,applyDynamicAlignmentStyles:d,videos:l=[]}=this.context.slateDataGetter()||{},{localizedStrings:h}=this.videoCardProps||{},{upNextSec:c}=this.config||{},u=r??c,p=l.slice(0,Math.max(1,H())),v={upNextVideoSec:u,relatedVideoLocalizedText:(null==h?void 0:h.moreVideos)??"",nextVideosOverlayData:p,upNextCardLocalizedText:(null==h?void 0:h.upNextIn)??"",showUpNextCard:"ended"==t,noTimer:!u||u<0,showPauseSlate:!i,isLargeTitleVideoPlayer:this.config.enableLargeTitle,onOverlayClick:a?this.onEndSlateOverlayClick:()=>!0,onUpNextVideoTimerDone:t=>{null==s||s(t),this.hideSlate()},applyEmbeddedVideoThumbnailStyles:this.applyEmbeddedVideoThumbnailStyles,applyDynamicAlignmentStyles:d,disablePauseOnBlur:o,disableUpNextLink:n};this.nextVideosOverlayData=v}hideSlate(){this.nextVideosOverlayData=void 0}shouldNotHaveNextVideosOverlayTimer(t){var e;return null===(e=this.context)||void 0===e||!e.isContentBingmm||!this.extractedRelatedData.map(t=>t.id).includes(t)||this.config.enableAutoPlayToggle&&!this.getUserPreferenceForPlaylistToggle()}async fetchSlateData(){this.isVideoPlayListDefined||await this.fetchVideoPlaylistFromFeed();const t=this.videoPlayList.slice();for(;this.nextVideosOverlayFetchedData.length<3&&t.length>0;){const i=t.shift();let o=await this.fetchContentViewData(i);if(this.isVideoDataValid(o,i,!0)){if(this.isChinaArticleComsuptionPage){var e;if(o=lt(o),!(0,_._Z)(null===(e=o.videoMetadata)||void 0===e?void 0:e.motionThumbnailUrl))continue;this.hasValidPreviewData=!0}this.nextVideosOverlayFetchedData.push(o)}}this.isChinaArticleComsuptionPage&&(this.videoPlayList=this.nextVideosOverlayFetchedData.map(t=>t.id))}fetchContentViewData(t){var e,i,o,n;if(null!==(e=this.context)&&void 0!==e&&e.enableVideoPreview&&!this.isChinaArticleComsuptionPage||this.is360VideoAd)return null===(n=this.context)||void 0===n?void 0:n.videoData;let a="Other";(null!==(i=this.context)&&void 0!==i&&i.isPartnerEmbed||null!==(o=this.context)&&void 0!==o&&o.relatedVideosData)&&(a="Embed");const r=this.isChinaArticleComsuptionPage?(0,g.Kc)(t):t;return(0,b.BL)(r,u.Rb.Locale,a)}async fetchVideoDocument(t){var e,i,o,s;let d=arguments.length>1&&void 0!==arguments[1]&&arguments[1];if(!t)return void this.logNoVideosPlayedErrorIfApplicable();let l=await this.fetchContentViewData(t);if(!this.isVideoDataValid(l,t,d)){if(this.config.continuePlay&&!this.stopPlayOnError)return this.tryFetchNextVideoFromPlayList();if(this.errorMessage=this.strings.loadedError||"We're sorry, this video is not available.",this.onError){const t={errorMessage:this.errorMessageText||this.errorMessage,hasError:!0};this.onError(t)}return}if(null!==(e=this.context)&&void 0!==e&&e.enableVideoPreview&&(l=this.isChinaArticleComsuptionPage?lt(l):st(l)),this.isChinaArticleComsuptionPage&&!(0,_._Z)(null===(i=l.videoMetadata)||void 0===i?void 0:i.motionThumbnailUrl))return this.tryFetchNextVideoFromPlayList();var h,c,u;if(this.atLeastOneValidVideoFetched=!0,this.hasValidPreviewData=!0,this.videoCardState.videoData=l,h=this.context,c=null===(o=this.videoCardState)||void 0===o||null===(o=o.videoData)||void 0===o?void 0:o.jsonDataMap,h&&!h.isContentBingmm&&"article"===(null===(u=h.inStreamVideoAd)||void 0===u?void 0:u.pageTypeOverride)&&(h.isLocal="1"===(null==c?void 0:c.isLocalNews)||!1),null===(s=this.thirdPartyPlayerContainerRef)||void 0===s||s.remove(),this.updateVideoCardProps(),this.videoCardProps&&(this.videoCardProps.onMessage=this.handleMessages),d){var p,v,g;const{isInline:t=!1}=this.config,{isContentBingmm:e=!1,isPartnerEmbed:i,isLocal:o=!1}=this.context||{},n=Boolean(null===(p=this.videoCardProps)||void 0===p||null===(p=p.playerConfigProps)||void 0===p?void 0:p.autoplay),a=et(this.videoCardState.videoData,Boolean(this.config.colorSampling),i,e,this.isFirstVideoFromPlaylist,t,o,n,void 0,null===(v=this.videoCardProps)||void 0===v||null===(v=v.playerConfigProps)||void 0===v?void 0:v.enableAttemptedUnmutedPlay,null===(g=this.videoCardProps)||void 0===g||null===(g=g.playerConfigProps)||void 0===g?void 0:g.userPersistedMutePreference);this.handleNextVideoFromPlaylist(a)}this.videoIds.push(this.videoId);const{card3ppConfig:m}=this.videoCardProps||{};if(this.shouldFetchSlateData&&!m&&await this.fetchSlateData(),m){const{name:e,js:i,playerSettingsId:o,playerNoAutoPlaySettingsId:s}=m;r.L.enqueue(async()=>{try{await this.setUpThirdPartyPlayers(e,i,o,s)}catch(e){var r;(0,a.vV)(n.O0d,"Error setting up 3rd party video player",`Error setting up 3PP for contentId [${t}]: ${e.message}`,{contentId:t}),null===(r=window)||void 0===r||r.dispatchEvent(new CustomEvent("VideoPlayer3PPError",{detail:{contentId:t}}))}})}}isFetchedContentDetails3PPValid(t){const{thirdPartyVideoPlayer:e,provider:i={},feedId:o="",id:r="",sourceId:s=""}=t||{},{enabled:d,name:l=""}=e||{},h=i.id||"";if(d&&N(l))return!0;const c=R(this.config.thirdPartyPlayersConfig,h),u=B(this.config.thirdPartyPlayersConfig,l),{name:p=""}=c||{},v={id:r,sourceId:s};return l?(c&&p.toLowerCase()!==l.toLowerCase()&&(0,a.vV)(n.DBO,`Wrong provider config for ${h}. Expected: ${l}. Actual: ${c.name}`,`FeedID: ${o}`,v),d||(0,a.vV)(n.JUf,`Provider ${h} has thirdPartyPlayer disabled`,`FeedID: ${o}`,v)):(0,a.vV)(n.HSH,`Provider ${h} with content ${t.id} is missing thirdPartyPlayer prop`,`FeedID: ${o}`,v),c?(t.thirdPartyVideoPlayer={enabled:!0,name:c.name},!0):u?(t.thirdPartyVideoPlayer={enabled:!0,name:u.name},!0):((0,a.vV)(n.GML,`Missing provider config for ${h} and also missing thirdPartyPlayer config`,`FeedID: ${o}`,v),!1)}async fetchVideoPlaylistFromFeed(t,e){var i;if(t||(t="WATCH"),e||(e="views-cpp-videoplay"),this.shouldAddRelatedPlaylist)return this.videoPlayList=[...this.extractedRelatedData.slice(null!==(i=this.context)&&void 0!==i&&i.isContentBingmm?1:0).map(t=>t.id)],void(this.videoPlayList.length&&(this.isVideoPlayListDefined=!0));await(0,b.Yk)(t,e).then(e=>{var i;e?null===(i=e.value)||void 0===i||i.map(t=>{var e;null===(e=t.subCards)||void 0===e||e.map(t=>{if(t.sourceId)try{this.videoPlayList.push(encodeURIComponent(t.sourceId))}catch{(0,m.Wr)(n.WWk,`Video ID [${t.sourceId}] cannot be encoded.`)}})}):h.YT.sendAppErrorEvent({...n.IIt,message:"Video list from oneservice returned empty with provided interest name.",pb:{...n.IIt.pb,customMessage:t}})}),this.videoPlayList.length&&(this.isVideoPlayListDefined=!0)}setVideoTitlePrefix(t){let e=arguments.length>1&&void 0!==arguments[1]&&arguments[1];var i,o;this.videoCardProps&&(this.extractedRelatedData.map(t=>t.id).includes(t)||e?this.videoTitlePrefix=null===(i=this.videoCardProps.localizedStrings)||void 0===i?void 0:i.relatedVideo:this.videoTitlePrefix=null===(o=this.videoCardProps.localizedStrings)||void 0===o?void 0:o.recommendedVideo)}async tryFetchNextVideoFromPlayList(){this.isVideoPlayListDefined||await this.fetchVideoPlaylistFromFeed();const t=this.popNextVideoFromPlaylist();this.shouldAddRelatedPlaylist&&this.setVideoTitlePrefix(t),await this.fetchVideoDocument(t,!0)}popNextVideoFromPlaylist(){return this.videoPlayList.length?(this.isFirstVideoFromPlaylist=!1,this.videoPlayList.shift()||""):""}deregisterPlayer(){this.videoCardManager.deregisterPlayer(this.videoId)}get videoId(){const{videoData:t,directEmbedMedia:e}=this.videoCardProps||{};return e&&N(e.type)?e.rid||e.id||"":e?this.id:(null==t?void 0:t.id)||""}get contentVideoPlayerProps(){var t;if(this.videoCardProps)return{...this.videoCardProps,allowAutoPlay:null===(t=this.context)||void 0===t?void 0:t.isUserAutoPlayEnabled,controls:!this.ytGamepadSatoriId,enableSlate:this.config.enableSlate,enablePlaySpeed:this.config.enablePlaySpeed,enableImagePreview:this.enableImagePreview}}get is360VideoAd(){var t;return null===(t=this.context)||void 0===t||null===(t=t.videoData)||void 0===t?void 0:t.is360VideoAd}get isChinaArticleComsuptionPage(){var t,e;return Boolean((null===(t=this.context)||void 0===t?void 0:t.enableVideoPreview)&&(null===(e=this.context.relatedVideosData)||void 0===e?void 0:e.length))}enablePlayerPlaylistMode(t){t.addEventListener("ended",()=>this.tryFetchNextVideoFromPlayList())}setUpEventsCallbackTrigger(t){var e,i,o,n;if(this.hasReceivedSlateData&&t.addEventListener("ended",t=>this.handleMessages({type:"ended"},t)),"function"!=typeof(null===(e=this.context)||void 0===e?void 0:e.eventsCallback))return;const a=["ready","play","playing","canplay","pause","resume","ended","volumechange","waiting",...null!==(i=this.context)&&void 0!==i&&i.enableTimeUpdateEventCallback?["timeupdate"]:[],...null!==(o=this.context)&&void 0!==o&&o.enableDetailEnhance?["wheel"]:[]];t.addEventListener(a,null===(n=this.context)||void 0===n?void 0:n.eventsCallback)}applyGlobalStyles(){const t=document.createElement("style");t.innerHTML=jt,document.head.appendChild(t)}getBlueMarkerClassNames(t){var e;if(null===(e=this.context)||void 0===e||!e.isContentBingmm)return"";if("topCarded"===t)return"related-video-divider-top";const i="top"===t?"blue-marker-before":"blue-marker-after";let o="";return o="bottom"===t?this.config.enableTitleAtBottom?"related-video-divider-bottom-title":"related-video-divider-bottom":this.config.hasRltdVidDividerTop?"related-video-divider-top":"related-video-divider",this.config.enableLargeTitle?o:i}getVideoThumbnailsStylesOverride(){return{width:"auto",height:"auto",padding:"32px"}}get estimatedDimensions(){if(!this.parentElement)return;const t=this.parentElement.clientWidth||0,e=Math.round(t/z);return{width:t,height:this.parentElement.clientHeight||e}}isCurrentVideoUnwanted(){if(!this.context)return!1;const{isContentBingmm:t,isPartnerEmbed:e}=this.context;return t?!this.extractedRelatedData.filter(t=>t.id===this.videoId).length:!!e&&this.videoId!=this.id}sendUnwantedVideoError(){const t=[];if(this.context){const{isContentBingmm:e,isPartnerEmbed:i}=this.context;e&&t.push("isContentBingmm"),i&&t.push("isPartnerEmbed")}(0,a.vV)(n.gsJ,`Video with id: ${this.videoId} is unwanted but it's playing`,t.join(" "),{originalId:this.id,currentId:this.videoId})}async createEmbedMediaFromURL(){var t;this.ytGamepadSatoriId=c._3.getQueryParameterByName("ytGamepadSatoriId",location.href);const e=ot(this.id,null===(t=this.context)||void 0===t?void 0:t.directEmbedMediaPlayerProps);return this.ytGamepadSatoriId?(await this.createGamepadService(),e||await this.gamepadYTService.createDirectEmbedMedia(this.ytGamepadSatoriId)):e}async initializeNextVideosGamepadYT(t){if(this.nextVideosOverlayData={upNextVideoSec:5,relatedVideoLocalizedText:"More videos",upNextCardLocalizedText:"Up next in",showUpNextCard:!1,showPauseSlate:!0,isLargeTitleVideoPlayer:!0},!this.ytGamepadSatoriId)return;const e=await this.gamepadYTService.getVideosRelatedToGame(this.ytGamepadSatoriId,t);this.nextVideosOverlayData.nextVideosOverlayData=e}logNoVideosPlayedErrorIfApplicable(){!this.config.enableLogNoVideosPlayed||this.videoPlayList.length||this.atLeastOneValidVideoFetched||(0,a.vV)(n.c0J,"End of playlist reached and no valid videos found. Player is potentially empty.")}prepareForVirtualization(){p(this.shadowRoot,"content-video-player")}}Qt.definition={shadowOptions:{delegatesFocus:!0}},(0,o.Cg)([s.sH],Qt.prototype,"nextVideosOverlayData",void 0),(0,o.Cg)([d.CF],Qt.prototype,"videoTitlePrefix",void 0),(0,o.Cg)([d.CF],Qt.prototype,"id",void 0),(0,o.Cg)([d.CF],Qt.prototype,"errorMessageText",void 0),(0,o.Cg)([d.CF],Qt.prototype,"onError",void 0),(0,o.Cg)([s.sH],Qt.prototype,"errorMessage",void 0),(0,o.Cg)([s.sH],Qt.prototype,"videoTelemetryContext",void 0),(0,o.Cg)([s.sH],Qt.prototype,"videoCardProps",void 0),(0,o.Cg)([s.sH],Qt.prototype,"videoCardState",void 0),(0,o.Cg)([s.sH],Qt.prototype,"shouldAddExtraStylingForRelatedVideos",void 0),(0,o.Cg)([(0,d.CF)({mode:"boolean"})],Qt.prototype,"shouldRenderLoadingState",void 0),(0,o.Cg)([s.sH],Qt.prototype,"isAutoPlayToggleChecked",void 0),(0,o.Cg)([s.sH],Qt.prototype,"contentVideoPlayerBodyChildren",void 0),(0,o.Cg)([s.sH],Qt.prototype,"contentVideoPlayerStyleOverrides",void 0),(0,o.Cg)([s.sH],Qt.prototype,"embedMediaPlayer",void 0),(0,o.Cg)([s.sH],Qt.prototype,"hasValidPreviewData",void 0);var Zt=i(96950),te=i(69259),ee=i(60402),ie=i(90366);const oe=Zt.qy`<fluent-switch class="toggle-switch" checked=${t=>t.isAutoPlayToggleChecked} current-checked="${t=>t.isAutoPlayToggleChecked}" @change=${t=>{}} data-t="${t=>{var e,i;return t.isAutoPlayToggleChecked?null===(e=t.videoTelemetryContext)||void 0===e||null===(e=e.autoPlayToggleTelemetryTags)||void 0===e?void 0:e.autoPlayOff:null===(i=t.videoTelemetryContext)||void 0===i||null===(i=i.autoPlayToggleTelemetryTags)||void 0===i?void 0:i.autoPlayOn}}"><label><slot name="title">${t=>{var e;return null===(e=t.config.localizedStrings)||void 0===e?void 0:e.autoPlayToggleButtonText}}</slot></label></fluent-switch>`;var ne=i(53532),ae=i(92011);const re=Zt.qy`<div class="related-videos-container"><div class="skeleton header-skeleton"></div><div class="skeleton embed-video-skeleton"></div></div>`;var se=i(22131);const de=Ft.A` .skeleton{background:rgba(0,0,0)}@keyframes pulse{0%{opacity:0.06}50%{opacity:0.1}100%{opacity:0.06}}`,le=Ft.A` .skeleton{background:rgba(255,255,255)}@keyframes pulse{0%{opacity:0.1}50%{opacity:0.15}100%{opacity:0.1}}`,he=Ft.A`.flex-row{display:flex;flex-direction:row}.flex-col{display:flex;flex-direction:column}.skeleton{animation:pulse 1.5s alternate infinite;animation-timing-function:linear}`.withBehaviors((0,se.C7)(de),(0,se.G2)(le)),ce=Ft.A`
    ${he} .header-skeleton{border-radius:4px;height:17px;width:200px;margin-bottom:13px}.embed-video-skeleton{border-radius:8px;aspect-ratio:16 / 9}.related-videos-container{padding:24px 0;border-top:1px solid rgba(0,0,0,0.09);border-bottom:1px solid rgba(0,0,0,0.09)}`.withBehaviors((0,se.G2)(Ft.A` .related-videos-container{border-top:1px solid rgba(100,100,100,1);border-bottom:1px solid rgba(100,100,100,1)}bottom:-20px;`));class ue extends ae.L{}let pe=class extends ue{};pe=(0,o.Cg)([(0,ae.E)({name:"loading-state-watch-feed",template:re,styles:ce})],pe);var ve=i(75003),ge=i(37180),me=i(71608),ye=i(99900),be=i(30581),fe=i(27233);const xe="nextVideosOverlayClicksTmpl",we="nextVideosOverlayClicksTmplNoTimer";var Pe;!function(t){t.category="category",t.ytGamepadSatoriId="ytGamepadSatoriId"}(Pe||(Pe={}));const $e=t=>(0,Jt.u)("relatedPlayListSlate",{action:l.EG.Click,type:l.MJ.VideoPlayer,overrideDestinationUrl:t??""}),ke=t=>{const e=new URL("https://www.msn.com/widgets/fullpage/views/xboxvideo"),i=new URLSearchParams({autoplay:"true",category:c._3.getQueryParameterByName("category",location.href),embed:"true",experiences:"VideoCardWC",id:encodeURIComponent(t),ytGamepadSatoriId:c._3.getQueryParameterByName("ytGamepadSatoriId",location.href)});return e.search=i.toString(),e.toString()},Se=(t,e,i)=>{if(!e){if($t.T3.CurrentMarket===fe.DX.ZHCN){const e=(0,g.Kc)(t.id);return(0,g.CW)(e,t.destinationUrl,t.title)}return i?ke(t.id):(0,g.FA)(t.id,t.title)}};class _e extends ae.L{constructor(){super(...arguments),this.upNextVideoSec=0,this.videos=[],this.showUpNextCard=!1,this.noTimer=!1,this.showPauseSlate=!1,this.isLargeTitleVideoPlayer=!1,this.listenFocusForCountdown=()=>{window.addEventListener("focus",this.startCount),window.addEventListener("blur",this.pauseCount),"visible"===document.visibilityState&&document.hasFocus()&&this.startCount()},this.startCount=()=>{if(isNaN(this.upNextVideoSec))return;const t=()=>{if(0===this.upNextVideoSec)return this.pauseCount(),void this.executeOnTimerDoneCallback();this.upNextVideoSec--,this.clearTimerId=window.setTimeout(t,1e3)};t()},this.pauseCount=()=>{this.clearTimerId&&clearTimeout(this.clearTimerId)}}connectedCallback(){super.connectedCallback(),this.noTimer?h.YT.addOrUpdateTmplProperty(we,"1"):h.YT.addOrUpdateTmplProperty(xe,"1"),this.showUpNextCard&&!this.noTimer&&(this.disablePauseOnBlur?this.startCount():this.listenFocusForCountdown())}disconnectedCallback(){super.disconnectedCallback(),clearTimeout(this.clearTimerId),window.removeEventListener("focus",this.startCount),window.removeEventListener("blur",this.pauseCount)}handleClickOnPlaylist(t){return t&&(h.YT.sendActionEvent(t.currentTarget,l.EG.Click),t.stopPropagation()),!0}handleUpNextClick(t){return this.disableUpNextLink&&(h.YT.sendActionEvent(t.currentTarget,l.EG.Click),this.executeOnTimerDoneCallback()),this.pauseCount(),this.noTimer=!0,!0}getPauseEndSlateClassNames(){if(this.isLargeTitleVideoPlayer&&this.showUpNextCard)return"largeTitle-endSlate";let t="pauseSlateOverlay";return this.isLargeTitleVideoPlayer&&(t+=" largeTitlePauseSlateOverlay largeTitlePauseSlateReDesign"),t}executeOnTimerDoneCallback(){var t,e;null===(t=this.onUpNextVideoTimerDone)||void 0===t||t.call(this,null===(e=this.videos[0])||void 0===e?void 0:e.id)}handleClosePauseSlateClick(t){var e;t.stopPropagation(),h.YT.sendActionEvent(t.currentTarget,l.EG.Click),null===(e=this.onCloseClick)||void 0===e||e.call(this)}handleOverlayClick(t){var e;return this.showUpNextCard&&!this.disableUpNextLink||h.YT.sendActionEvent(t.currentTarget,l.EG.Click),null===(e=this.onOverlayClick)||void 0===e?void 0:e.call(this)}shouldHideDurationLabel(t){return this.hideDurationLabel&&"0"===t.durationTime.min&&"00"===t.durationTime.sec}get slateTelemetryTag(){const t=this.showUpNextCard?"EndSlate":"PauseSlate";return(0,Jt.N)(t,l.MS.Play).getMetadataTag()}get closePauseSlateTelemetryTag(){return(0,Jt.N)("ClosePauseSlate",l.MS.Hide).getMetadataTag()}}(0,o.Cg)([d.CF],_e.prototype,"upNextVideoSec",void 0),(0,o.Cg)([d.CF],_e.prototype,"relatedVideoLocalizedText",void 0),(0,o.Cg)([s.sH],_e.prototype,"videos",void 0),(0,o.Cg)([s.sH],_e.prototype,"showUpNextCard",void 0),(0,o.Cg)([s.sH],_e.prototype,"noTimer",void 0),(0,o.Cg)([(0,d.CF)({mode:"boolean"})],_e.prototype,"showPauseSlate",void 0),(0,o.Cg)([(0,d.CF)({mode:"boolean"})],_e.prototype,"isLargeTitleVideoPlayer",void 0),(0,o.Cg)([s.sH],_e.prototype,"onUpNextVideoTimerDone",void 0),(0,o.Cg)([d.CF],_e.prototype,"upNextCardLocalizedText",void 0),(0,o.Cg)([s.sH],_e.prototype,"onCloseClick",void 0),(0,o.Cg)([s.sH],_e.prototype,"onOverlayClick",void 0),(0,o.Cg)([d.CF],_e.prototype,"applyEmbeddedVideoThumbnailStyles",void 0),(0,o.Cg)([s.sH],_e.prototype,"applyDynamicAlignmentStyles",void 0),(0,o.Cg)([s.sH],_e.prototype,"disablePauseOnBlur",void 0),(0,o.Cg)([s.sH],_e.prototype,"disableUpNextLink",void 0),(0,o.Cg)([s.sH],_e.prototype,"isXboxGamepadVideo",void 0),(0,o.Cg)([s.sH],_e.prototype,"hideDurationLabel",void 0),(0,o.Cg)([s.Jg],_e.prototype,"slateTelemetryTag",null);const Ce=Ft.A` .dynamic-alignment-container{aspect-ratio:auto;text-align:start;z-index:1}.dynamic-alignment-container .thumbnail-next-video .upnext-link:hover{background:rgba(255,255,255,.2);clip-path:inset(0% round 8px);overflow:hidden;margin:-10px;padding:10px}@media (min-width:600px) and (max-width:1600px){.dynamic-alignment-container .endSlate-ThumbnailOverlay{display:flex;flex-direction:row}.dynamic-alignment-container .thumbnail-video-list{display :none}.dynamic-alignment-container .thumbnail-next-video{flex-direction:column;width:100%;box-sizing:border-box}.dynamic-alignment-container .upnext-thumbnail{flex-direction:row}.dynamic-alignment-container .thumbnail-container{margin-bottom:0}.dynamic-alignment-container .thumbnail-next-video .upnext-link{width:100%;display:grid;grid-template-columns:min(360px,40%) auto;gap:12px}.dynamic-alignment-container .thumbnail-upnext-timer{width:100%}.dynamic-alignment-container .upnext-thumbnail-abstract{justify-content:center}}@media (min-width:600px) and (max-width:1400px){.dynamic-alignment-container .upnext-thumbnail-abstract .thumbnail-title{font-size:16px}}@media (max-width:599px){.dynamic-alignment-container .thumbnail-next-video{padding:0px 20px 40px}.dynamic-alignment-container .thumbnail-next-video .upnext-link{grid-template-columns:20vw auto;gap:16px}.dynamic-alignment-container .thumbnail-container{aspect-ratio:1;height:auto;width:100%;margin-bottom:0}}@media (max-width:468px){.dynamic-alignment-container .thumbnail-next-video .upnext-link{grid-template-columns:15vw auto;gap:12px}.dynamic-alignment-container .thumbnail-abstract-subhead{margin-bottom:6px}}@media (max-width:400px){.dynamic-alignment-container .thumbnail-upnext-timer{font-size:12px;margin-bottom:4px}.dynamic-alignment-container .upnext-thumbnail-abstract .thumbnail-title{font-size:12px;line-height:normal}}`,Ae=Ft.A` :host{--image-width:106px;--image-height:60px;--card-width:312px;--card-height:76px;--white-color:#FFF;--heading-font-size:14px;--heading-line-height:20px;--company-font-size:12px;box-sizing:border-box;cursor:pointer;outline:none}.endSlateOverlay{position:absolute;top:0;left:0;right:0;bottom:4.8em;display:grid;grid-template-rows:1fr auto;height:100%;background:rgba(0,0,0,0.65);cursor:pointer;z-index:66}.pauseSlateOverlay{position:absolute;top:0px;left:0px;right:0px;bottom:4.8em;display:grid;grid-template-rows:1fr;height:100%;width:100%;background:linear-gradient(rgba(34,34,34,0.7) 11%,rgb(17,17,17) 100%);cursor:default;z-index:0}.largeTitlePauseSlateOverlay{background:linear-gradient(0deg,rgba(2,0,36,0) 0%,rgba(0,0,0,0.6) 13%,rgba(0,0,0,0.5) 59%,rgba(0,0,0,0) 90%)}.largeTitlePauseSlateReDesign{border-radius:6px}.playlist{overflow:hidden;height:auto;padding-left:1.2em;padding-right:1.2em;padding-top:0.6em;margin-bottom:4.8em}.endSlatePlaylist{margin-bottom:4.8em;position:absolute;height:auto;left:0;right:0;bottom:0}ul{list-style-type:none;padding:0;margin-top:2px;margin-bottom:0px}.playlist-container--info{color:white;display:flex;justify-content:space-between;font-size:14px;font-weight:600;line-height:16px;width:100%;margin-left:0px;padding:8px 0px;cursor:default}.thumbnail-list-wrapper{align-items:center;justify-content:space-between;margin-top:4px;gap:10px;display:flex}.thumbnail-list-wrapper li{border:2px solid rgba(255,255,255,0.4);border-radius:4px;cursor:default;width:235px;height:135px}.playlist-thumbnail{position:relative;width:100%;height:100%;overflow:hidden}.playlist-thumbnail img{display:block;width:100%;height:100%;opacity:0.9;border-radius:4px;aspect-ratio:16/9}.thumbnail-overlay{position:absolute;display:flex;flex-direction:column;top:0;bottom:0;left:0;right:0;height:100%;width:100%;transition:all 0.5s ease 0s;background:rgba(0,0,0,0.55);backdrop-filter:blur(10px);opacity:0;color:white}.playlist-thumbnail:hover .thumbnail-overlay{opacity:1}.thumbnail-abstract{display:flex;flex-direction:column;position:absolute;top:0px;margin:12px}.thumbnail-title{font-weight:600;font-size:14px;line-height:20px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;color:rgb(251,251,251)}.thumbnail-abstract-subhead{display:flex;font-style:normal;font-weight:400;font-size:12px;line-height:16px;align-items:center;color:rgb(255,255,255);margin-bottom:12px;opacity:0.8}.thumbnail-abstract-subhead-nga{margin-bottom:0px}.thumbnail-abstract-subhead img{width:16px;height:16px;left:0px;top:0px;margin-right:6px}.thumbnail-abstract-timer{display:flex;flex-direction:row;align-items:center;padding:2px 8px 2px 4px;width:54px;height:20px;background:rgba(0,0,0,0.6);border-radius:4px;position:absolute;bottom:0px;margin:12px;font-weight:600;font-size:12px;line-height:16px}.thumbnail-abstract-timer span{width:12px;height:12px;margin:4px 6px 4px 6px}.pause-slate-close{cursor:pointer;color:#FFFFFF;padding:3px 4px 1px}.center-pause-info{width:480px;margin:auto}.endSlate-ThumbnailOverlay{position:absolute;top:0;left:0;right:0;bottom:0;z-index:68;backdrop-filter:blur(6px);background:rgba(0,0,0,0.8);cursor:pointer;z-index:66;display:grid;grid-template-columns:1fr auto;aspect-ratio:16 / 9;overflow:hidden}.largeTitle-endSlate{border-radius:6px}.thumbnail-next-video{display:flex;flex-direction:column;justify-content:center;align-items:center;padding:0 40px;margin-top:calc(-40px - (1 * 1vw))}.thumbnail-next-video a{text-decoration:none;width:304px}.thumbnail-video-list{display:flex;flex-direction:column;background:rgba(0,0,0,0.9);padding:40px;align-items:center}.thumbnail-video-list a{display:block;width:240px;height:150px;border:1px solid rgba(255,255,255,0.2);margin:0px 0px 16px;border-radius:4px}${(0,f.H5)(f.j1.c4)}{.thumbnail-video-list a{width:215px;height:121px}}.thumbnail-video-list-nga a{width:auto;height:auto}.thumbnail-video-list-nga{position:relative;padding:32px}.thumbnail-video-list-nga .video-list-title{left:32px}.thumbnail-container{display:flex;aspect-ratio:1.6;width:100%;position:relative;margin-bottom:12px}.thumbnail-container img{width:100%;height:100%;border:1px solid rgba(255,255,255,0.2);border-radius:4px;object-fit:cover}.upnext-thumbnail{position:relative}.upnext-content-wrapper{position:absolute;top:0;bottom:0;right:0;left:0;display:flex;flex-direction:column;justify-content:center;align-items:center;color:white}.upnext-content-wrapper svg{width:min(50%,40px)}.upnext-timer{left:6px;display:flex;flex-direction:row;align-items:center;padding:2px 8px 2px 4px;width:54px;height:20px;background:rgba(0,0,0,0.6);border-radius:4px;position:absolute;bottom:4px;margin:12px;font-weight:600;font-size:12px;line-height:16px}.upnext-timer span{width:12px;height:12px;margin:4px 6px 4px 6px}.upnext-thumbnail-abstract{display:flex;flex-direction:column;position:relative;top:0px}.upnext-thumbnail-abstract .thumbnail-title{font-weight:600;font-size:20px;line-height:26px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;color:rgb(251,251,251)}.thumbnail-upnext-timer{display:flex;color:white;font-weight:600;width:304px;font-size:14px;line-height:20px;text-align:start;margin-bottom:min(max(calc(16px + (1vw - 32px)),4px),16px)}.video-list-title{position:absolute;width:240px;height:150px;color:white;top:10px;font-weight:600;font-size:14px;line-height:20px}@media (max-width:941px){.pauseSlateOverlay{display:none}}@media (max-width:1363px){.endSlate-ThumbnailOverlay{display:flex;flex-direction:row}.thumbnail-video-list{display :none}.thumbnail-next-video{flex-direction:column;width:100%}.upnext-thumbnail{flex-direction:row}.thumbnail-next-video a{width:100%;display:grid;grid-template-columns:min(270px,40%) auto;gap:24px}.thumbnail-upnext-timer{width:100%}.upnext-thumbnail-abstract{justify-content:center}}@media (max-width:599px){.thumbnail-video-list{display :none}.thumbnail-next-video{flex-direction:column;width:100%}.upnext-thumbnail{flex-direction:row}.upnext-timer{display:none}.thumbnail-next-video a{width:100%;display:grid;grid-template-columns:100px auto;gap:16px}.thumbnail-upnext-timer{margin-bottom:12px}.upnext-thumbnail-abstract .thumbnail-title{font-size:14px;line-height:20px}.thumbnail-container{width:100px;height:100px}}@media (min-width:1051px) and (max-width:1263px){.thumbnail-list-wrapper li{width:137px;height:77px}.center-pause-info{width:442px}.thumbnail-abstract-subhead{font-size:10px;line-height:14px;margin-bottom:8px}.thumbnail-title{font-size:12px;line-height:16px}.thumbnail-abstract-timer{display:none}}@media (min-width:942px) and (max-width:1050px){.thumbnail-list-wrapper li{width:155px;height:87px}.center-pause-info{width:442px}}${(0,f.H5)(f.j1.c3)}{.thumbnail-list-wrapper li{width:137px;height:77px}.center-pause-info{width:442px}.thumbnail-abstract-subhead{font-size:10px;line-height:14px;margin-bottom:8px}.thumbnail-title{font-size:12px;line-height:16px}.thumbnail-abstract-timer{display:none}}@media (max-width:1051px){.thumbnail-list-wrapper li{width:155px;height:87px}.center-pause-info{width:442px}}${Ce}
`;var Te=i(39957),Ie=i(66591);const Ee=Zt.qy`
    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" slot="icon">
        <g filter="url(#filter0_b_30_15226)">
            <circle cx="20" cy="20" r="19" fill="url(#paint0_linear_30_15226)" />
            <circle cx="20" cy="20" r="19.5" stroke="url(#paint1_linear_30_15226)" />
        </g>
        <path d="M27.2221 18.6846C28.2586 19.2544 28.2586 20.7437 27.2221 21.3135L17.2226 26.8105C16.2229 27.36 15 26.6367 15 25.496L15 14.5021C15 13.3614 16.2229 12.6381 17.2226 13.1877L27.2221 18.6846Z" fill="white" />
        <defs>
            <filter id="filter0_b_30_15226" x="-10" y="-10" width="60" height="60" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
                <feFlood flood-opacity="0" result="BackgroundImageFix" />
                <feGaussianBlur in="BackgroundImage" stdDeviation="5" />
                <feComposite in2="SourceAlpha" operator="in" result="effect1_backgroundBlur_30_15226" />
                <feBlend mode="normal" in="SourceGraphic" in2="effect1_backgroundBlur_30_15226" result="shape" />
            </filter>
            <linearGradient id="paint0_linear_30_15226" x1="1" y1="1" x2="39" y2="39" gradientUnits="userSpaceOnUse">
                <stop stop-opacity="0.5" />
                <stop offset="1" stop-opacity="0.7" />
            </linearGradient>
            <linearGradient id="paint1_linear_30_15226" x1="20" y1="1" x2="20" y2="39" gradientUnits="userSpaceOnUse">
                <stop stop-color="white" stop-opacity="0.4" />
                <stop offset="1" stop-color="white" stop-opacity="0.2" />
            </linearGradient>
        </defs>
    </svg>
`,Ve=Zt.qy`<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6 0C9.31371 0 12 2.68629 12 6C12 9.31371 9.31371 12 6 12C2.68629 12 0 9.31371 0 6C0 2.68629 2.68629 0 6 0ZM6 1C3.23858 1 1 3.23858 1 6C1 8.76142 3.23858 11 6 11C8.76142 11 11 8.76142 11 6C11 3.23858 8.76142 1 6 1ZM5.50153 3C5.74699 3 5.95114 3.17688 5.99347 3.41012L6.00153 3.5V6H7.5C7.77614 6 8 6.22386 8 6.5C8 6.74546 7.82312 6.94961 7.58988 6.99194L7.5 7H5.50153C5.25607 7 5.05192 6.82312 5.00958 6.58988L5.00153 6.5V3.5C5.00153 3.22386 5.22538 3 5.50153 3Z" fill="white"/>
</svg>`,ze=Zt.qy`<svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M0.588591 0.715694L0.646447 0.646447C0.820013 0.47288 1.08944 0.453595 1.28431 0.588591L1.35355 0.646447L6 5.293L10.6464 0.646447C10.8417 0.451185 11.1583 0.451185 11.3536 0.646447C11.5488 0.841709 11.5488 1.15829 11.3536 1.35355L6.707 6L11.3536 10.6464C11.5271 10.82 11.5464 11.0894 11.4114 11.2843L11.3536 11.3536C11.18 11.5271 10.9106 11.5464 10.7157 11.4114L10.6464 11.3536L6 6.707L1.35355 11.3536C1.15829 11.5488 0.841709 11.5488 0.646447 11.3536C0.451185 11.1583 0.451185 10.8417 0.646447 10.6464L5.293 6L0.646447 1.35355C0.47288 1.17999 0.453595 0.910563 0.588591 0.715694L0.646447 0.646447L0.588591 0.715694Z" fill="white"/>
</svg>`,De=Zt.qy`<ul class="thumbnail-list-wrapper">${(0,Te.ux)(t=>t.showUpNextCard?t.videos.slice(1):t.videos,Zt.qy`<li><a role="link" data-t="${(t,e)=>{var i;return null===(i=$e(e.parent.isXboxGamepadVideo?ke(t.id):(0,g.FA)(t.id,t.title)))||void 0===i?void 0:i.getMetadataTag()}}" href="${(t,e)=>Se(t,e.parent.disableUpNextLink,e.parent.isXboxGamepadVideo)}" target="${(t,e)=>e.parent.isXboxGamepadVideo?"_self":"_blank"}" @click=${(t,e)=>e.parent.handleClickOnPlaylist(e.event)}><div class="playlist-thumbnail"><img slot="media" src=${t=>t.mediaSrc} alt=${t=>t.title} title=${t=>t.title}><div class="thumbnail-overlay"><div class="thumbnail-abstract"><span class="thumbnail-abstract-subhead">${(0,te.z)(t=>t.providerLogo,Zt.qy`<img src=${t=>t.providerLogo} alt=${t=>t.providerName}/>`)} ${t=>t.providerName}</span><span role="heading" class="thumbnail-title" aria-level="2" aria-label=${t=>t.title}>${t=>t.title}</span></div>${(0,te.z)((t,e)=>!e.parent.shouldHideDurationLabel(t),Zt.qy`<div class="thumbnail-abstract-timer"><span>${Ve}</span>${t=>t.durationTime.min}:${t=>t.durationTime.sec}</div>`)}</div></div></a></li>`)}</ul>`,Fe=Zt.qy`<div class="thumbnail-video-list ${t=>t.applyEmbeddedVideoThumbnailStyles?"thumbnail-video-list-nga":""}"><div class="video-list-title">${t=>t.relatedVideoLocalizedText}</div>${(0,Te.ux)(t=>t.videos.slice(1),Zt.qy`<a role="link" data-t="${(t,e)=>{var i;return null===(i=$e(e.parent.isXboxGamepadVideo?ke(t.id):(0,g.FA)(t.id,t.title)))||void 0===i?void 0:i.getMetadataTag()}}" href="${(t,e)=>Se(t,e.parent.disableUpNextLink,e.parent.isXboxGamepadVideo)}" target="${(t,e)=>e.parent.isXboxGamepadVideo?"_self":"_blank"}" @click=${(t,e)=>e.parent.handleClickOnPlaylist(e.event)}><div class="playlist-thumbnail"><img slot="media" src=${t=>t.mediaSrc} alt=${t=>t.title} title=${t=>t.title}><div class="thumbnail-overlay"><div class="thumbnail-abstract"><span class="thumbnail-abstract-subhead">${(0,te.z)(t=>t.providerLogo,Zt.qy`<img src=${t=>t.providerLogo} alt=${t=>t.providerName}/>`)} ${t=>t.providerName}</span><span role="heading" class="thumbnail-title" aria-level="2" aria-label=${t=>t.title}>${t=>t.title}</span></div>${(0,te.z)((t,e)=>!e.parent.shouldHideDurationLabel(t),Zt.qy`<div class="thumbnail-abstract-timer"><span>${Ve}</span>${t=>t.durationTime.min}:${t=>t.durationTime.sec}</div>`)}</div></div></a>`)}</div>`,Me=Zt.qy`<div class="thumbnail-next-video">${(0,te.z)(t=>!t.noTimer,Zt.qy`<div class="thumbnail-upnext-timer"><span>${t=>t.upNextCardLocalizedText} ${t=>t.upNextVideoSec}...</span></div>`)}<a role="link" class="upnext-link" data-t="${t=>{var e;return null===(e=$e(t.isXboxGamepadVideo?ke(t.videos[0].id):(0,g.FA)(t.videos[0].id,t.videos[0].title)))||void 0===e?void 0:e.getMetadataTag()}}" href="${t=>Se(t.videos[0],t.disableUpNextLink,t.isXboxGamepadVideo)}" target="${t=>t.isXboxGamepadVideo?"_self":"_blank"}" @click=${(t,e)=>e.event&&t.handleUpNextClick(e.event)}><div class="thumbnail-container"><img src=${t=>t.videos[0].mediaSrc} alt=${t=>t.videos[0].title} title=${t=>t.videos[0].title}><div class="upnext-content-wrapper">${Ee} ${(0,te.z)(t=>t.videos[0].durationTime&&!t.shouldHideDurationLabel(t.videos[0]),Zt.qy`<div class="upnext-timer"><span>${Ve}</span>${t=>t.videos[0].durationTime.min}:${t=>t.videos[0].durationTime.sec}</div>`)}</div></div><div class="upnext-thumbnail-abstract"><span class="thumbnail-abstract-subhead ${t=>t.applyEmbeddedVideoThumbnailStyles?"thumbnail-abstract-subhead-nga":""}">${(0,te.z)(t=>t.videos[0].providerLogo,Zt.qy`<img src=${t=>t.videos[0].providerLogo} alt=${t=>t.videos[0].providerName} title=${t=>t.videos[0].providerName}>`)} ${t=>t.videos[0].providerName}</span><span role="heading" class="thumbnail-title" aria-level="2" aria-label=${t=>t.videos[0].title}>${t=>t.videos[0].title}</span></div></a></div>${(0,te.z)(t=>t.videos.length>1,Fe)}
`,Oe=Zt.qy`<div class="playlist ${t=>t.showUpNextCard?"":"endSlatePlaylist"}"><div class="playlist-container--info ${t=>2===t.videos.length?"center-pause-info":""} "><span>${t=>t.relatedVideoLocalizedText}</span>${t=>t.showUpNextCard?"":Zt.qy`<span data-t="${t=>t.closePauseSlateTelemetryTag}" @click=${(t,e)=>t.handleClosePauseSlateClick(e.event)} role="button" class="pause-slate-close">${ze}</span>`}</div>${De}</div>`,Le=Zt.qy`<div class="${t=>(t=>(0,Ie.x)(t.showUpNextCard?"endSlate-ThumbnailOverlay":t.getPauseEndSlateClassNames(),["dynamic-alignment-container",t.applyDynamicAlignmentStyles]))(t)}" @click=${(t,e)=>t.handleOverlayClick(e.event)} data-t="${t=>t.slateTelemetryTag}" data-test-id="next-videos-overlay" part="next-videos-overlay">${t=>t.showUpNextCard?Me:Oe}</div>`;let Re=class extends _e{};Re=(0,o.Cg)([(0,ae.E)({name:"next-videos-overlay-wc",template:Le,styles:Ae})],Re),ve.m.define(ge.c.registry),me.Af.define(ye.i.registry),be.yr.define(ye.i.registry);class Be extends ae.L{constructor(){super(...arguments),this.autoScrollNextVideoMessage="",this.isActive=!1,this.countdown=5}get formattedAutoScrollMessage(){return this.autoScrollNextVideoMessage.replace("{0}",String(this.countdown))}isActiveChanged(t,e){e?this.startCountdown():this.clearCountdown()}disconnectedCallback(){super.disconnectedCallback(),this.clearCountdown()}startCountdown(){y()||(this.clearCountdown(),this.countdown=5,this.countdownTimer=window.setInterval(()=>{var t;(this.countdown--,this.countdown<=0)&&(this.clearCountdown(),null===(t=this.onAutoScrollComplete)||void 0===t||t.call(this))},1e3))}clearCountdown(){void 0!==this.countdownTimer&&(window.clearInterval(this.countdownTimer),this.countdownTimer=void 0)}}(0,o.Cg)([(0,d.CF)({attribute:"auto-scroll-next-video-message"})],Be.prototype,"autoScrollNextVideoMessage",void 0),(0,o.Cg)([s.sH],Be.prototype,"isActive",void 0),(0,o.Cg)([s.sH],Be.prototype,"countdown",void 0),(0,o.Cg)([s.sH],Be.prototype,"onAutoScrollComplete",void 0),(0,o.Cg)([s.Jg],Be.prototype,"formattedAutoScrollMessage",null);const Ne=Ft.A` .error-card-container{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;background:linear-gradient(119.33deg,#222222 32.01%,#111111 103.96%)}.video-unavailable-icon{margin-bottom:16px;max-width:60%;max-height:60%}.video-unavailable-icon img{width:100%;height:100%;object-fit:contain}.auto-scroll-next-video-msg{margin:8px 16px 0;text-align:center;color:#D4D4D4;font-size:18px}`,Ue=Zt.qy`<div class="error-card-container"><span class="video-unavailable-icon"><img src="${$t.T3.StaticsUrl}latest/views/icons/ErrorIceCream.png" alt="Error" /></span>${(0,te.z)(t=>t.autoScrollNextVideoMessage,Zt.qy`<span class="auto-scroll-next-video-msg">${t=>t.formattedAutoScrollMessage}</span>`)}</div>`;let je=class extends Be{};je=(0,o.Cg)([(0,ae.E)({name:"video-card-error",template:Ue,styles:Ne})],je);var Ge=i(77848),We=i(24197),He=i(80790),Ye=i(9368);const qe=new Map([["NBCSports",(t,e,i)=>t.includes("-")?e:i]]);var Je=i(21154),Ke=i(94043),Xe=i(31756),Qe=i(34230),Ze=i(68989);const ti={api:{baseUrl:"https://api.msn.com/msn/v0/pages/CasualGames/GameHubV2",qsp:[["apiKey","815OFUpUhXOWSB8eMuBSy9iV8FQfTpD9h9oF9nmBfO"],["ocid","cg-landing"],["3pvendor","videolg"],["contentType","GameHubV2"],["ids",""],["cm","zh-cn"],["fdhead","prg-1sw-lgvads1"],["it","edgeid"],["scn","AL_APP_ANON"]]}},ei=(0,Ke.S)()?function(t){for(var e=arguments.length,i=new Array(e>1?e-1:0),o=1;o<e;o++)i[o-1]=arguments[o];return fetch(t,...i)}:function(t){for(var e=arguments.length,i=new Array(e>1?e-1:0),o=1;o<e;o++)i[o-1]=arguments[o];return(0,Ze.GC)(t,...i)};class ii{constructor(){this.adsQueue=[],this.currentIndex=0,this.curPreload=null}static get instance(){return St.vv.get(this.instanceKey)}static set instance(t){St.vv.set(this.instanceKey,t)}static getInstance(){return this.instance||(this.instance=new ii),this.instance}async getLeadsGenAdList(){var t,e;const i=await Xe.WR.getBaseRequestData("GET"),o=new URL(ti.api.baseUrl);ti.api.qsp.forEach(t=>{let[e,i]=t;return o.searchParams.set(e,i)});const n=await(0,Qe.w)(async()=>await ei(o.href,i),"FetchLeadsGenAds"),a=await n.json(),r=null==a||null===(t=a.value)||void 0===t||null===(t=t[0])||void 0===t?void 0:t.data;return(null===(e=("string"==typeof r?JSON.parse(r):r).gamesByLeaderboard)||void 0===e||null===(e=e[0])||void 0===e?void 0:e.games)??[]}async getNextAds(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:100;if(!this.curPreload)throw new Error("please call preload first");const[e,i]=this.curPreload,o=await Promise.any([new Promise(e=>setTimeout(()=>e(null),t)),i]);return this.preloadByIndex(e>=this.adsQueue.length-1?0:e+1),o}async fetchAdsData(){try{const t=await this.getLeadsGenAdList();this.adsQueue=t.map(t=>({id:t.id,thumbnailUrl:t.thumbnailId||"",playUrl:t.playUrl||""})),this.currentIndex=0}catch(t){this.adsQueue=[]}}preloadByIndex(t){this.curPreload=[t,new Promise(e=>{const i=()=>{const i=this.adsQueue[t];fetch(i.thumbnailUrl).then(t=>{t.arrayBuffer().then(t=>{const o=URL.createObjectURL(new Blob([t],{type:"video/mp4"}));e({...i,thumbnailUrl:o})})})};this.adsQueue.length?i():this.fetchAdsData().then(()=>{if(!this.adsQueue.length)return this.curPreload=null,void e(null);i()})})]}preload(){this.curPreload||this.preloadByIndex(0)}}ii.instanceKey=Symbol("instance");var oi=i(36042);const ni=Je.default;class ai{constructor(t,e,i,o){if(this.videoAdManager=Xt.o3.getInstance(),this.progress=0,this.currentTime="0:00",this.duration="0:00",this.hadMidRollRequest=!1,this.triggeredPlayEvent=!1,this.timerIds=[],this.playPreRollAd=async(t,e,i)=>{if(this.videoAdManager.checkIfEligibleForPreRoll(i.content.videoDuration,i.content.videoPositionSec)&&this.videoAdManager.hasPreRollAds){const t=this.videoAdManager.markPreRollAdAsRequested(!1);t&&this.playAd("pre",t)}},this.playMidRollAd=(t,e,i)=>{const o=this.videoAdManager.checkIfEligibleForMidRoll(i.content.videoDuration,i.content.videoPositionSec),n=this.hadMidRollRequest;if(o&&!n&&this.videoAdManager.hasMidRollAds){const t=this.videoAdManager.markMidRollAdAsRequested(!1);this.hadMidRollRequest=!0,t&&this.playAd("mid",t)}},this.handleVideoPlayerTimeUpdate=(0,oi.A)((t,e,i)=>{if(!this.triggeredPlayEvent&&i.content.videoPositionSec<1.5)return this.playPreRollAd(t,"play",i),void(this.triggeredPlayEvent=!0);this.playMidRollAd(t,"play",i)},1e3),this.handleVideoPlayerVolumeChange=(t,e,i)=>{var o,n,a,r,s;(this.videoVolume=(null===(o=i.originEvent)||void 0===o?void 0:o.data.volume)??.1,this.videoVolume<=0)?null===(n=(a=this.options).onAdsMute)||void 0===n||n.call(a):null===(r=(s=this.options).onAdsUnmute)||void 0===r||r.call(s)},this.playAd=async(t,e)=>{try{var i,o;const r=await this.leadsGenVideoAdsDataService.getNextAds();var n,a;if(null==r||!r.thumbnailUrl)return void(null===(n=this.videoPlayer)||void 0===n||null===(a=n.triggerAdSkipped)||void 0===a||a.call(n));this.adInfo={adRoll:e,adRollStage:t,adData:r},null===(i=(o=this.videoPlayer).triggerAdStart)||void 0===i||i.call(o),await this.initAdPlayer(r),this.setupAdPlayer(),await this.adVideoPlayer.play()}catch(t){this.handleAdError()}},this.initAdPlayer=t=>new Promise(e=>{if(this.adVideoPlayer)return this.adVideoPlayer.src({src:t.thumbnailUrl,type:"video/mp4"}),void e();this.adVideoPlayer=ni(this.adVideoEle,{autoplay:!0,controls:!1,controlBar:!1,loop:!1,muted:!1,preload:"auto",fluid:!0},e),this.adVideoPlayer.src({src:t.thumbnailUrl,type:"video/mp4"})}),this.handleAdError=()=>{var t,e,i,o;null===(t=(e=this.options).onAdsHide)||void 0===t||t.call(e),this.videoPlayer.play(),null===(i=(o=this.videoPlayer).setIsAdsPlying)||void 0===i||i.call(o,!1),this.stopAdPlayer()},this.clearTimers=()=>{this.timerIds.forEach(t=>{window.clearTimeout(t),window.clearInterval(t)})},this.handleAdPlay=()=>{var t,e,i,o,n,a,r,s;this.adVideoPlayer&&(this.startAdSkipCountDown(),null===(t=(e=this.videoPlayer).triggerAdStart)||void 0===t||t.call(e),this.videoPlayer.pause(),null===(i=(o=this.videoPlayer).setIsAdsPlying)||void 0===i||i.call(o,!0),null===(n=(a=this.options).onAdsShow)||void 0===n||n.call(a,this.adInfo),null===(r=(s=this.options).onAdsPlay)||void 0===r||r.call(s))},this.handleAdTimeUpdate=()=>{var t,e,i,o;if(!this.adVideoPlayer)return;const n=this.adVideoPlayer.currentTime(),a=this.adVideoPlayer.duration();a&&!isNaN(a)&&(this.progress=n/a*100,this.currentTime=this.formatTime(n),this.duration=this.formatTime(a),null===(t=(e=this.options).onProgressChange)||void 0===t||t.call(e,this.progress),null===(i=(o=this.options).onTimeUpdate)||void 0===i||i.call(o,this.currentTime,this.duration))},this.handleAdEnded=()=>{var t,e,i,o,n,a,r,s,d,l,h,c;this.progress=100,null===(t=(e=this.options).onProgressChange)||void 0===t||t.call(e,this.progress),null===(i=(o=this.options).onSkipStateChange)||void 0===i||i.call(o,"finished",void 0),null===(n=(a=this.options).onAdsHide)||void 0===n||n.call(a),null===(r=(s=this.options).onAdsPlayEnd)||void 0===r||r.call(s),this.stopAdPlayer(),null===(d=(l=this.videoPlayer).triggerAdFinish)||void 0===d||d.call(l),this.videoPlayer.play(),null===(h=(c=this.videoPlayer).setIsAdsPlying)||void 0===h||h.call(c,!1)},this.startAdSkipCountDown=()=>{var t,e;let i=this.videoCardProps.leadsGenVideoAdsSkipDuration??5;null===(t=(e=this.options).onSkipStateChange)||void 0===t||t.call(e,"init");const o=window.setTimeout(()=>{var t,e;null===(t=(e=this.options).onSkipStateChange)||void 0===t||t.call(e,"countingDown",i)},3),n=window.setInterval(()=>{var t,e,o,a;if(i<=1)return null===(o=(a=this.options).onSkipStateChange)||void 0===o||o.call(a,"finished",void 0),void clearInterval(n);null===(t=(e=this.options).onSkipStateChange)||void 0===t||t.call(e,"countingDown",--i)},1e3);this.timerIds.push(o,i)},!e||!i||!o)throw new Error("Required parameters are missing");this.leadsGenVideoAdsDataService=ii.getInstance(),this.videoPlayer=t,this.adVideoEle=e,this.videoCardProps=i,this.options=o,this.init()}async init(){this.videoPlayer.addEventListener("timeupdate",this.handleVideoPlayerTimeUpdate),this.videoPlayer.addEventListener("volumechange",this.handleVideoPlayerVolumeChange),this.leadsGenVideoAdsDataService.preload()}setupAdPlayer(){this.adVideoPlayer&&(this.adVideoPlayer.volume(this.videoVolume??.1),this.adVideoPlayer.one("play",this.handleAdPlay),this.adVideoPlayer.on("timeupdate",this.handleAdTimeUpdate),this.adVideoPlayer.on("ended",this.handleAdEnded),this.adVideoPlayer.on("error",this.handleAdError))}stopAdPlayer(){this.adVideoPlayer&&(this.adVideoPlayer.off("play",this.handleAdPlay),this.adVideoPlayer.off("timeupdate",this.handleAdTimeUpdate),this.adVideoPlayer.off("ended",this.handleAdEnded),this.adVideoPlayer.off("error",this.handleAdError))}dispose(){var t;null===(t=this.adVideoPlayer)||void 0===t||t.dispose(),this.clearTimers(),this.videoPlayer&&(this.videoPlayer.removeEventListener("timeupdate",this.handleVideoPlayerTimeUpdate),this.videoPlayer.removeEventListener("volumechange",this.handleVideoPlayerVolumeChange))}formatTime(t){if(!t||isNaN(t))return"0:00";return`${Math.floor(t/60)}:${Math.floor(t%60).toString().padStart(2,"0")}`}togglePlay(){var t,e,i,o;this.adVideoPlayer&&(this.adVideoPlayer.paused()?(this.adVideoPlayer.play(),null===(t=(e=this.options).onAdsPlay)||void 0===t||t.call(e)):(this.adVideoPlayer.pause(),null===(i=(o=this.options).onAdsPause)||void 0===i||i.call(o)))}toggleMute(){var t,e,i,o;this.adVideoPlayer&&(this.adVideoPlayer.volume()?(null===(t=(e=this.options).onAdsMute)||void 0===t||t.call(e),this.adVideoPlayer.volume(0)):(null===(i=(o=this.options).onAdsUnmute)||void 0===i||i.call(o),this.adVideoPlayer.volume(this.videoVolume||.1)))}skipAd(){var t,e,i,o,n,a,r;null===(t=this.adVideoPlayer)||void 0===t||t.pause(),this.stopAdPlayer(),null===(e=(i=this.options).onAdsHide)||void 0===e||e.call(i),null===(o=(n=this.videoPlayer).triggerAdSkipped)||void 0===o||o.call(n),this.videoPlayer.play(),null===(a=(r=this.videoPlayer).setIsAdsPlying)||void 0===a||a.call(r,!1)}}ai.instanceKey=Symbol("instance");const ri={placementId:"CN-Video-Leadsgen"};class si extends ae.L{constructor(){super(...arguments),this.showLeadsGenAds=!1,this.progress=0,this.skipStage="init",this.currentTime="0:00",this.duration="0:00",this.isAdPlaying=!1,this.isAdMuted=!0,this.handlePlayerCreated=t=>{var e,i;const o=(null===(e=this.videoCardProps)||void 0===e||null===(e=e.directEmbedMedia)||void 0===e?void 0:e.id)??"";this.isAdMuted=(null===(i=this.videoCardProps)||void 0===i||null===(i=i.playerConfigProps)||void 0===i?void 0:i.muted)??!0,t.playerInfo.video.id===o&&this.adVideo&&this.videoCardProps&&(this.leadsGenVideoAdsManager=new ai(t,this.adVideo,this.videoCardProps,this.getAdsManagerCallbacks()))},this.sendAdsTelemetry=t=>{var e;const i=this.adInfo;i&&h.YT.sendClientLogEvent({message:t,type:"metrics",pb:{...ri,brandId:(null===(e=this.videoCardProps)||void 0===e||null===(e=e.directEmbedMedia)||void 0===e?void 0:e.id)??"unknown",adId:i.adData.id,rollStage:i.adRollStage,pgCode:i.adRoll.pgCode}})},this.sendAdsShowTelemetry=()=>{this.sendAdsTelemetry("video: Leads-gen video ads Exposure")},this.sendAdsClickTelemetry=()=>{this.sendAdsTelemetry("video: Leads-gen video ads Click")},this.handleAdsShow=t=>{this.adInfo=t,this.showLeadsGenAds=!0,this.sendAdsShowTelemetry()},this.clickAd=()=>{this.adInfo&&(this.sendAdsClickTelemetry(),window.open(this.adInfo.adData.playUrl,"_blank"))}}getAdsManagerCallbacks(){return{onAdsShow:this.handleAdsShow,onAdsHide:()=>{this.showLeadsGenAds=!1},onProgressChange:t=>{this.progress=t},onTimeUpdate:(t,e)=>{this.currentTime=t,this.duration=e},onSkipStateChange:(t,e)=>{this.skipCountdown=e,this.skipStage=t},onAdsMute:()=>{this.isAdMuted=!0},onAdsUnmute:()=>{this.isAdMuted=!1},onAdsPlay:()=>{this.isAdPlaying=!0,this.telemetryForAdPlayStartEle&&h.YT.sendActionEvent(this.telemetryForAdPlayStartEle)},onAdsPause:()=>{this.isAdPlaying=!1},onAdsPlayEnd:()=>{this.telemetryForAdPlayEndEle&&h.YT.sendActionEvent(this.telemetryForAdPlayEndEle)}}}connectedCallback(){var t;super.connectedCallback(),this.telemetryContext={telemetryForVideoClick:(0,Jt.u)("clickAd",{action:l.EG.Click}),telemetryForSkipAdFail:(0,Jt.u)("skipAdFail",{action:l.EG.Click}),telemetryForSkipAdSuccess:(0,Jt.u)("skipAdSuccess",{action:l.EG.Click}),telemetryForAdPlayStart:(0,Jt.u)("adStartPlay",{action:l.EG.Click}),telemetryForAdPlayEnd:(0,Jt.u)("adPlayEnd",{action:l.EG.Click})};const e=null===(t=this.videoCardProps)||void 0===t||null===(t=t.directEmbedMedia)||void 0===t?void 0:t.id;e&&(this.videoCardManager=Et.N.getInstance(),this.videoCardManager.addPlayerEventListener(e,"ready",this.handlePlayerCreated,{once:!0}))}disconnectedCallback(){var t;super.disconnectedCallback(),null===(t=this.leadsGenVideoAdsManager)||void 0===t||t.dispose()}handleVideoControl(t){this.leadsGenVideoAdsManager&&this.showLeadsGenAds&&this.leadsGenVideoAdsManager[t]()}toggleAdPlay(){this.handleVideoControl("togglePlay")}toggleAdMute(){this.handleVideoControl("toggleMute")}skipAd(){"finished"===this.skipStage&&this.handleVideoControl("skipAd")}get locStrForSkipAd(){var t;const e=null===(t=this.videoCardProps)||void 0===t?void 0:t.localizedStrings;if(e)return"init"===this.skipStage?e.nonSkippableAdButtonText:"countingDown"===this.skipStage?`${e.skipAdText} ${this.skipCountdown}`:"finished"===this.skipStage?e.skipAdText:""}locStr(t){var e;const i=null===(e=this.videoCardProps)||void 0===e?void 0:e.localizedStrings;return i?"skipAdText"===t?this.locStrForSkipAd:i[t]:""}get telemetryForVideoClick(){var t;return null===(t=this.telemetryContext)||void 0===t||null===(t=t.telemetryForVideoClick)||void 0===t?void 0:t.getMetadataTag()}get telemetryForSkipAd(){var t,e;return"finished"!==this.skipStage?null===(t=this.telemetryContext)||void 0===t||null===(t=t.telemetryForSkipAdFail)||void 0===t?void 0:t.getMetadataTag():null===(e=this.telemetryContext)||void 0===e||null===(e=e.telemetryForSkipAdSuccess)||void 0===e?void 0:e.getMetadataTag()}get telemetryForAdPlayStart(){var t;return null===(t=this.telemetryContext)||void 0===t||null===(t=t.telemetryForAdPlayStart)||void 0===t?void 0:t.getMetadataTag()}get telemetryForAdPlayEnd(){var t;return null===(t=this.telemetryContext)||void 0===t||null===(t=t.telemetryForAdPlayEnd)||void 0===t?void 0:t.getMetadataTag()}}var di,li,hi,ci;(0,o.Cg)([s.sH],si.prototype,"videoCardProps",void 0),(0,o.Cg)([s.sH],si.prototype,"showLeadsGenAds",void 0),(0,o.Cg)([s.sH],si.prototype,"progress",void 0),(0,o.Cg)([s.sH],si.prototype,"skipStage",void 0),(0,o.Cg)([s.sH],si.prototype,"skipCountdown",void 0),(0,o.Cg)([s.sH],si.prototype,"currentTime",void 0),(0,o.Cg)([s.sH],si.prototype,"duration",void 0),(0,o.Cg)([s.sH],si.prototype,"isAdPlaying",void 0),(0,o.Cg)([s.sH],si.prototype,"isAdMuted",void 0),(0,o.Cg)([s.sH],si.prototype,"telemetryContext",void 0),(0,o.Cg)([s.Jg],si.prototype,"locStrForSkipAd",null);const ui=`${null===(di=(0,$t.rA)())||void 0===di?void 0:di.StaticsUrl}/latest/fluent-icons/speaker_2_20_regular.svg`,pi=`${null===(li=(0,$t.rA)())||void 0===li?void 0:li.StaticsUrl}/latest/fluent-icons/speaker_mute_20_regular.svg`,vi=`${null===(hi=(0,$t.rA)())||void 0===hi?void 0:hi.StaticsUrl}/latest/fluent-icons/play_20_regular.svg`,gi=`${null===(ci=(0,$t.rA)())||void 0===ci?void 0:ci.StaticsUrl}/latest/fluent-icons/pause_20_regular.svg`,mi=Ft.A`
    :host {
        display: block;
    }
    
    .telemetry-mock {
        position: absolute;
        visibility: hidden;
    }
    
    .leads-gen-ad-player {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        background: black;
        position: relative;
        
        & .ad-video-wrap {
            width: 100%;
            height: 100%;
        }

        & .ad-video {
            width: 100%;
            height: 100%;
            object-fit: fill;
            cursor: pointer;
            
            & > video {
                width: 100%;
                height: 100%;
                object-fit: fill;
            }
        }
    }

    .ad-controls {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        background: linear-gradient(to bottom, transparent, rgba(28, 28, 28, 0.9));
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        padding: 0;
    }

    .progress-bar {
        margin: 12px 24px;
        width: calc(100% - 48px);
        height: 3px;
        background: rgba(255, 255, 255, 0.3);
    }

    .progress-bar-fill {
        height: 100%;
        background: #FFA500;
        transition: width 0.1s linear;
    }

    .ad-controls-left {
        display: flex;
        align-items: center;
        gap: 16px;
        color: #fff;
        font-size: 18px;
        padding: 16px 24px;
    }

    .play-pause-button {
        background: none;
        border: none;
        color: #fff;
        cursor: pointer;
        width: 32px;
        height: 32px;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0.9;
        font-size: 24px;
    }

    .play-toggle {
        display: block;
        width: 22px;
        height: 22px;
        background: #fff;
        
        &.play {
            mask: url(${vi}) center center / contain no-repeat;
        }
        
        &.pause {
            mask: url(${gi}) center center / contain no-repeat;
        }
    }

    .mute-button {
        position: absolute;
        right: 24px;
        background: none;
        border: none;
        color: #fff;
        cursor: pointer;
        width: 32px;
        height: 32px;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        opacity: 0.9;
    }
    
    .ad-speaker {
        display: block;
        width: 22px;
        height: 22px;
        background: #fff;
        
        &.muted {
            mask: url(${pi}) center center / contain no-repeat;
        }
        
        &.un-muted {
            mask: url(${ui}) center center / contain no-repeat;
        }
    }

    .progress-controls {
        position: absolute;
        top: -40px;
        left: 7px;
        right: 7px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .controls-wrapper {
        width: 100%;
        display: flex;
        flex-direction: column;
    }
    .ad-controls-menu{
        height:50px;
        margin-top:-10px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        
    }
    .ad-controls-right {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .ad-text {
        color: #fff;
        font-size: 12px;
        text-transform: uppercase;
        background: rgba(255, 255, 255, 0.2);
        padding: 3px 8px;
        border-radius: 2px;
    }

    .skip-button {
        color: #fff;
        font-size: 14px;
        padding: 8px 16px;
        background: rgba(255, 255, 255, 0.2);
        border-radius: 2px;
        cursor: pointer;
        transition: background-color 0.2s;
    }

    .skip-button:hover {
        background: rgba(255, 255, 255, 0.3);
    }

    .skip-button[hidden] {
        display: none;
    }

    .time-display {
        color: #fff;
        font-size: 18px;
        opacity: 0.9;
    }


    .vjs-big-play-button,
    .vjs-control-bar,
    .vjs-controls-disabled .vjs-big-play-button,
    .vjs-controls-disabled .vjs-control-bar,
    .vjs-error .vjs-big-play-button,
    .vjs-error .vjs-control-bar
    .vjs-error-display,
    .vjs-has-started .vjs-big-play-button,
    .vjs-loading-spinner,
    .vjs-modal-dialog,
    .vjs-text-track-display,
    .vjs-using-native-controls .vjs-big-play-button,
    .vjs-using-native-controls .vjs-control-bar {
        display: none!important
    }

    .ad-label {
        color: #fff;
        font-size: 12px;
        background: rgba(28, 28, 28, 0.7);
        padding: 4px 8px;
        border-radius: 2px;
        position: absolute;
        left: 16px;
        top: 16px;
    }

    .video-after {
        color: #fff;
        font-size: 14px;
        background: rgba(28, 28, 28, 0.7);
        padding: 4px 12px;
        border-radius: 2px;
        position: absolute;
        right: 16px;
        top: 16px;
        
        &:hover {
            cursor: pointer;
            background: rgba(28, 28, 28, 1);
        }
    }
`,yi=Zt.qy`<template class="${t=>(0,Ie.x)("leads-gen-ads-player",["hidden",!t.showLeadsGenAds])}"><button class="telemetry-mock" ${(0,ee.K)("telemetryForAdPlayStartEle")} data-t="${t=>t.telemetryForAdPlayStart}" tabindex="-1"></button><button class="telemetry-mock" ${(0,ee.K)("telemetryForAdPlayEndEle")} data-t="${t=>t.telemetryForAdPlayEnd}" tabindex="-1"></button><div class="leads-gen-ad-player"><div class="ad-video-wrap" @click=${t=>t.clickAd()} role="button" tabindex="0" data-t="${t=>t.telemetryForVideoClick}"><video ${(0,ee.K)("adVideo")} src="" class="ad-video"></video></div><div class="ad-controls"><div class="controls-wrapper"><div class="progress-controls"><div class="ad-label">${t=>t.locStr("adStringText")}</div><button class="video-after" @click="${t=>t.skipAd()}" data-t="${t=>t.telemetryForSkipAd}">${t=>t.locStr("skipAdText")}</button></div><div class="progress-bar"><div class="progress-bar-fill" style="width: ${t=>t.progress}%"></div></div><div class="ad-controls-menu"><div class="ad-controls-left"><button class="play-pause-button" @click="${t=>t.toggleAdPlay()}"><span class="${t=>(0,Ie.x)("play-toggle",["play",!t.isAdPlaying],["pause",t.isAdPlaying])}"></span></button><span class="time-display">${t=>t.currentTime} / ${t=>t.duration}</span></div><div class="ad-controls-right"><button class="mute-button" @click="${t=>t.toggleAdMute()}"><span class="${t=>(0,Ie.x)("ad-speaker",["muted",t.isAdMuted],["un-muted",!t.isAdMuted])}"></span></button></div></div></div></div></div></template>`;let bi=class extends si{};bi=(0,o.Cg)([(0,ae.E)({name:"leads-gen-ad-player",template:yi,styles:mi})],bi);var fi=i(54048);class xi{static get instance(){return St.vv.get(this.instanceKey)}static set instance(t){St.vv.set(this.instanceKey,t)}constructor(t){this.currentPreloadIndex=1,this.adService=new fi._,this.nativeAdsConfig=t}static getInstance(t){return this.instance||(this.instance=new xi(t)),this.instance}async fetchNativeAds(){const t=this.createNativeAdRequest();if(!t)return;const e=await this.adService.fetchNativeAds(t);return this.nativeAdsResponse=e,e}createNativeAdRequest(){var t;if(!this.nativeAdsConfig)return;const{partnerId:e,region:i,imageHeight:o,imageWidth:n,isStrictIndices:a,useVisibilityTracking:r}=this.nativeAdsConfig;return{pageType:"video-widget"===(null===(t=$t.T3.CurrentRequestTargetScope)||void 0===t?void 0:t.pageType)?"watch":void 0,partnerId:e,shouldUseWindowVisibilityTrackingForXandr:r,placements:[{region:i,indices:[this.currentPreloadIndex],imageHeight:o.toString(),imageWidth:n.toString(),img:{w:n,h:o},isStrictIndices:a}]}}async getNextAds(){var t;if(await this.fetchNativeAds(),null===(t=this.nativeAdsResponse)||void 0===t||!t.placements.length)return null;const e=this.nativeAdsResponse.placements[0];return this.currentPreloadIndex++,e}}xi.instanceKey=Symbol("instance");const wi=[77,90,125,218,473,1167,3051,8173,22096,59944];class Pi{constructor(t,e,i){var o;this.progress=0,this.isAdPlaying=!1,this.adVisible=!1,this.adControlsVisible=!1,this.duration=0,this.countDown=0,this.skipStatus="init",this.videoAdManager=Xt.o3.getInstance(),this.triggeredPlayEvent=!1,this.hadMidRollRequest=!1,this.showSkipDelaySeconds=0,this.progressTimeId=null,this.skipDelayTimeId=null,this.adControlTimeId=null,this.skipTimeId=null,this.countAdsShown=0,this.previousAdShowWatchedSec=0,this.handleVideoPlayerTimeUpdate=(0,oi.A)((t,e,i)=>{if(!this.triggeredPlayEvent&&i.content.videoPositionSec<1.5)return this.playPreRollAd(t,"play",i),void(this.triggeredPlayEvent=!0);this.playMidRollAd(t,"play",i)},1e3),this.playPreRollAd=async(t,e,i)=>{if(this.videoAdManager.checkIfEligibleForPreRoll(i.content.videoDuration,i.content.videoPositionSec)&&this.videoAdManager.hasPreRollAds){var o,n,a,r;if(0===(null===(o=this.options)||void 0===o?void 0:o.playerFeedIdx)&&(null===(n=this.options)||void 0===n||!n.shouldBlockFirstPrerollAd))return;const e=this.videoAdManager.markPreRollAdAsRequested(!1);if(0===(null===(a=this.options)||void 0===a?void 0:a.playerFeedIdx)&&null!==(r=this.options)&&void 0!==r&&r.shouldBlockFirstPrerollAd)return;e&&(this.adInfo={adRollStage:"pre",adRoll:e},this.countAdsShown++,this.previousAdShowWatchedSec=t.watchedTimeSec,this.showAd())}},this.playMidRollAd=(t,e,i)=>{var o,n;if(this.videoAdManager.checkIfEligibleForMidRoll(i.content.videoDuration,i.content.videoPositionSec)&&(null!==(o=this.options)&&void 0!==o&&o.enableMultipleMidrollAds||!this.hadMidRollRequest)){if(null!==(n=this.options)&&void 0!==n&&n.enableMultipleMidrollAds&&this.countAdsShown>0){if(this.countAdsShown>=wi.length)return;const e=wi[this.countAdsShown];if(t.watchedTimeSec-this.previousAdShowWatchedSec<e)return}if(this.videoAdManager.hasMidRollAds){const e=this.videoAdManager.markMidRollAdAsRequested(!1);this.hadMidRollRequest=!0,e&&(this.adInfo={adRollStage:"mid",adRoll:e},this.countAdsShown++,this.previousAdShowWatchedSec=t.watchedTimeSec,this.showAd())}}},this.triggerAdSlotEnded=()=>{var t,e,i;const o="pre"===(null===(t=this.adInfo)||void 0===t?void 0:t.adRollStage)?"preroll":"midroll";null===(e=(i=this.videoPlayer).triggerAdSlotEnded)||void 0===e||e.call(i,{ad:{adType:o,isThirdParty:!1},isInline:!1,isPlayerPaused:!0})},this.options=i,this.duration=(null==i?void 0:i.adDuration)||12,this.countDown=(null==i?void 0:i.showSkipButtonTimeSeconds)||3,0===(null===(o=this.options)||void 0===o?void 0:o.showSkipButtonDelaySeconds)&&(this.skipStatus="skippable"),this.videoPlayer=t,this.videoPlayer.addEventListener("timeupdate",this.handleVideoPlayerTimeUpdate),this.service=xi.getInstance(e)}async showAd(){try{var t,e,i,o,n,a,r;const l=await(null===(t=this.service)||void 0===t?void 0:t.getNextAds());var s,d;if(!l)return null===(s=this.videoPlayer)||void 0===s||null===(d=s.triggerAdSkipped)||void 0===d||d.call(s),void this.triggerAdSlotEnded();this.nativeAdData=l,this.adVisible=!0,null===(e=(i=this.videoPlayer).triggerAdStart)||void 0===e||e.call(i),this.videoPlayer.pause(),null===(o=(n=this.videoPlayer).setIsAdsPlying)||void 0===o||o.call(n,!0),this.adControlsVisible=!0,this.play(),null===(a=this.options)||void 0===a||null===(r=a.onAdShow)||void 0===r||r.call(a)}catch{this.handleAdError()}}hideAd(){var t,e,i,o,n,a;this.initN2vData(),null===(t=(e=this.videoPlayer).triggerAdFinish)||void 0===t||t.call(e),this.triggerAdSlotEnded(),this.videoPlayer.play(),null===(i=(o=this.videoPlayer).setIsAdsPlying)||void 0===i||i.call(o,!1),null===(n=this.options)||void 0===n||null===(a=n.onAdHide)||void 0===a||a.call(n)}skipAd(){var t,e,i,o;this.disabledSkip||(this.initN2vData(),null===(t=(e=this.videoPlayer).triggerAdSkipped)||void 0===t||t.call(e),this.triggerAdSlotEnded(),this.videoPlayer.play(),null===(i=(o=this.videoPlayer).setIsAdsPlying)||void 0===i||i.call(o,!1))}initDataWhenVideoInactive(){this.initN2vData(),this.hadMidRollRequest=!1,this.triggeredPlayEvent=!1}skipDelayCountDown(){var t;const e=(null===(t=this.options)||void 0===t?void 0:t.showSkipButtonDelaySeconds)||0;e>=this.duration||(0!==e?this.skipDelayTimeId=window.setInterval(()=>{this.showSkipDelaySeconds+1>=e?(this.skipStatus="skippable",this.clearSkipDelayTimeout()):this.showSkipDelaySeconds+=1},1e3):this.skipStatus="skippable")}handleAdError(){var t,e;this.initN2vData(),this.videoPlayer.play(),null===(t=(e=this.videoPlayer).setIsAdsPlying)||void 0===t||t.call(e,!1)}initN2vData(){var t;this.adVisible=!1,this.progress=0,this.countDown=(null===(t=this.options)||void 0===t?void 0:t.showSkipButtonTimeSeconds)||5,this.skipStatus="init",this.showSkipDelaySeconds=0,this.adControlsVisible=!1,this.pause(!0)}setProgress(){this.nativeAdData&&(this.progressTimeId=window.setInterval(()=>{this.progress+1<=this.duration?this.progress+=1:(this.hideAd(),this.clearProgressTimeout()),this.duration-this.progress<=this.countDown&&"countDown"!==this.skipStatus&&(this.skipStatus="countDown",this.skipCountDown())},1e3))}skipCountDown(){this.skipTimeId=window.setInterval(()=>{this.countDown-1>=0?this.countDown-=1:this.clearSkipTimeout()},1e3)}togglePlay(){this.isAdPlaying?this.pause():this.play()}play(){var t,e,i;this.isAdPlaying=!0,this.setProgress(),this.countDown>0&&"countDown"===this.skipStatus&&this.skipCountDown(),this.showSkipDelaySeconds<((null===(t=this.options)||void 0===t?void 0:t.showSkipButtonDelaySeconds)||0)&&"init"===this.skipStatus&&this.skipDelayCountDown(),null===(e=this.options)||void 0===e||null===(i=e.onAdPlay)||void 0===i||i.call(e)}pause(){let t=arguments.length>0&&void 0!==arguments[0]&&arguments[0];var e,i;(this.isAdPlaying=!1,this.clearProgressTimeout(),this.clearSkipTimeout(),this.clearSkipDelayTimeout(),this.clearAdControlTimeout(),t)||(null===(e=this.options)||void 0===e||null===(i=e.onAdPause)||void 0===i||i.call(e))}showAdControl(){this.adControlsVisible=!0,this.clearAdControlTimeout()}hideAdControl(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:3e3;this.isAdPlaying&&(this.adControlTimeId=window.setTimeout(()=>{this.adControlsVisible=!1,this.clearAdControlTimeout()},t))}dispose(){this.clearProgressTimeout(),this.clearSkipTimeout(),this.clearSkipDelayTimeout(),this.clearAdControlTimeout(),this.videoPlayer.removeEventListener("timeupdate",this.handleVideoPlayerTimeUpdate)}get progressPercent(){return this.duration?100*Number((this.progress/this.duration).toFixed(2)):0}get disabledSkip(){var t;return"init"===this.skipStatus||"countDown"===this.skipStatus&&((null===(t=this.options)||void 0===t?void 0:t.showSkipButtonDelaySeconds)||0)>=this.duration}clearProgressTimeout(){this.progressTimeId&&(window.clearInterval(this.progressTimeId),this.progressTimeId=null)}clearSkipTimeout(){this.skipTimeId&&(window.clearInterval(this.skipTimeId),this.skipTimeId=null)}clearSkipDelayTimeout(){this.skipDelayTimeId&&(window.clearInterval(this.skipDelayTimeId),this.skipDelayTimeId=null)}clearAdControlTimeout(){this.adControlTimeId&&(window.clearTimeout(this.adControlTimeId),this.adControlTimeId=null)}}(0,o.Cg)([s.sH],Pi.prototype,"progress",void 0),(0,o.Cg)([s.sH],Pi.prototype,"isAdPlaying",void 0),(0,o.Cg)([s.sH],Pi.prototype,"adVisible",void 0),(0,o.Cg)([s.sH],Pi.prototype,"adControlsVisible",void 0),(0,o.Cg)([s.sH],Pi.prototype,"duration",void 0),(0,o.Cg)([s.sH],Pi.prototype,"nativeAdData",void 0),(0,o.Cg)([s.sH],Pi.prototype,"countDown",void 0),(0,o.Cg)([s.sH],Pi.prototype,"skipStatus",void 0);var $i=i(26391),ki=i(73893),Si=i(80090),_i=i(65614);const Ci={placementId:"CN-Video-Native2Video"};class Ai extends ae.L{constructor(){super(...arguments),this.handlePlayerCreated=t=>{var e,i;this.native2VideoAdsManager=new Pi(t,{isStrictIndices:!0,region:"n2v",useVisibilityTracking:!0,placementIndex:0,partnerId:"video",imageHeight:282,imageWidth:500},{showSkipButtonDelaySeconds:null===(e=this.config)||void 0===e?void 0:e.showSkipButtonDelaySeconds,onAdShow:()=>this.handleAdShow(),onAdHide:()=>this.handleAdHide(),playerFeedIdx:this.playerFeedIdx,enableMultipleMidrollAds:null===(i=this.config)||void 0===i?void 0:i.enableMultipleMidrollAds,shouldBlockFirstPrerollAd:this.disableN2vAdsEnhance})},this.sendAdsTelemetry=t=>{var e,i;const o=null===(e=this.native2VideoAdsManager)||void 0===e?void 0:e.adInfo;o&&h.YT.sendClientLogEvent({message:t,type:"metrics",pb:{...Ci,brandId:this.videoId??"unknown",adId:(null===(i=this.native2VideoAdsManager)||void 0===i||null===(i=i.nativeAdData)||void 0===i||null===(i=i.items)||void 0===i?void 0:i[0].uniqueId)??"",rollStage:o.adRollStage,pgCode:o.adRoll.pgCode}})}}connectedCallback(){if(super.connectedCallback(),this.videoId){this.videoCardManager=Et.N.getInstance(),this.videoCardManager.addPlayerEventListener(this.videoId,"ready",this.handlePlayerCreated,{once:!0}),ki.m.define(_i.G.registry),Si.m.define(_i.G.registry);const e=Xt.o3.getInstance();var t;if(this.forcePreAdOnFirstVideo&&!e.hasPreRollAds)e.schedulePreRollAd({pgCode:(null===(t=this.config)||void 0===t||null===(t=t.inStreamVideoAd)||void 0===t?void 0:t.preRollAdPgCode)??""})}}disconnectedCallback(){var t;super.disconnectedCallback(),null===(t=this.native2VideoAdsManager)||void 0===t||t.dispose()}renderStateChanged(){var t;"active"!==this.renderState&&null!==(t=this.native2VideoAdsManager)&&void 0!==t&&t.adVisible&&this.native2VideoAdsManager.initDataWhenVideoInactive()}handleImageLoadError(){var t,e,i;(0,$i.T)({id:null===(t=this.nativeAdRenderData)||void 0===t?void 0:t.uniqueId,rLink:null===(e=this.nativeAdRenderData)||void 0===e?void 0:e.destinationUrl,imgLink:null===(i=this.nativeAdRenderData)||void 0===i?void 0:i.imageUrl})}handleAdShow(){this.sendAdsTelemetry("Video: Native to video ads exposures"),this.telemetryForAdShowEl&&h.YT.sendActionEvent(this.telemetryForAdShowEl),this.telemetryForAdPlayOrPauseEl&&h.YT.sendActionEvent(this.telemetryForAdPlayOrPauseEl)}handleAdHide(){this.sendAdsTelemetry("Video: Native to video ads ends"),this.telemetryForAdHideEl&&h.YT.sendActionEvent(this.telemetryForAdHideEl)}get progress(){var t;return null!==(t=this.native2VideoAdsManager)&&void 0!==t&&t.progress?rt(this.native2VideoAdsManager.progress):"0:00"}get duration(){var t;return null!==(t=this.native2VideoAdsManager)&&void 0!==t&&t.duration?rt(this.native2VideoAdsManager.duration):"0:00"}get nativeAdRenderData(){var t;return(null===(t=this.native2VideoAdsManager)||void 0===t||null===(t=t.nativeAdData)||void 0===t||null===(t=t.items)||void 0===t?void 0:t[0])||null}get data(){var t,e;if(null===(t=this.native2VideoAdsManager)||void 0===t||!t.nativeAdData)return{};const{region:i,regionIndex:o,iasId:n,items:a}=this.native2VideoAdsManager.nativeAdData,r=`${i}-${o}-${n}`;return{...this.native2VideoAdsManager.nativeAdData,id:r,clickBeacons:null==a||null===(e=a[0])||void 0===e?void 0:e.clickBeacons}}get skipButtonText(){var t,e,i,o,n,a,r,s;return"skippable"===(null===(t=this.native2VideoAdsManager)||void 0===t?void 0:t.skipStatus)?null===(o=this.videoCardProps)||void 0===o||null===(o=o.localizedStrings)||void 0===o?void 0:o.skipAdText:"countDown"===(null===(e=this.native2VideoAdsManager)||void 0===e?void 0:e.skipStatus)?null!==(n=this.native2VideoAdsManager)&&void 0!==n&&n.countDown?`${null===(r=this.videoCardProps)||void 0===r||null===(r=r.localizedStrings)||void 0===r?void 0:r.skipAdText} ${null===(s=this.native2VideoAdsManager)||void 0===s?void 0:s.countDown}`:null===(a=this.videoCardProps)||void 0===a||null===(a=a.localizedStrings)||void 0===a?void 0:a.skipAdText:null===(i=this.videoCardProps)||void 0===i||null===(i=i.localizedStrings)||void 0===i?void 0:i.nonSkippableAdButtonText}get videoId(){var t,e;return null!==(t=this.videoCardProps)&&void 0!==t&&t.directEmbedMedia?this.videoCardProps.directEmbedMedia.id:null===(e=this.videoCardProps)||void 0===e||null===(e=e.videoData)||void 0===e?void 0:e.id}get forcePreAdOnFirstVideo(){var t,e;return(null===(t=this.config)||void 0===t?void 0:t.enableN2vOnArticlePage)&&this.isChinaArticleComsuptionPage&&this.originId===(null===(e=this.videoCardProps)||void 0===e||null===(e=e.videoData)||void 0===e?void 0:e.id)}}(0,o.Cg)([s.sH],Ai.prototype,"videoCardProps",void 0),(0,o.Cg)([s.sH],Ai.prototype,"native2VideoAdsManager",void 0),(0,o.Cg)([s.sH],Ai.prototype,"config",void 0),(0,o.Cg)([s.sH],Ai.prototype,"renderState",void 0),(0,o.Cg)([s.sH],Ai.prototype,"playerFeedIdx",void 0),(0,o.Cg)([s.sH],Ai.prototype,"telemetryForAdShowEl",void 0),(0,o.Cg)([s.sH],Ai.prototype,"telemetryForAdHideEl",void 0),(0,o.Cg)([s.sH],Ai.prototype,"telemetryForAdPlayOrPauseEl",void 0),(0,o.Cg)([s.sH],Ai.prototype,"originId",void 0),(0,o.Cg)([s.sH],Ai.prototype,"isChinaArticleComsuptionPage",void 0),(0,o.Cg)([s.sH],Ai.prototype,"disableN2vAdsEnhance",void 0),(0,o.Cg)([s.Jg],Ai.prototype,"progress",null),(0,o.Cg)([s.Jg],Ai.prototype,"duration",null),(0,o.Cg)([s.Jg],Ai.prototype,"nativeAdRenderData",null),(0,o.Cg)([s.Jg],Ai.prototype,"data",null),(0,o.Cg)([s.Jg],Ai.prototype,"skipButtonText",null);var Ti=i(77793);const Ii=Zt.qy` ${(0,te.z)(t=>t.nativeAdRenderData,Zt.qy`<div class="ad-card-container"><cs-card class="ad-card" id="native_ad_${t=>{var e;return null===(e=t.nativeAdRenderData)||void 0===e?void 0:e.uniqueId}}" size="_2x_2y"><cs-content-card class="ad-card-content" id="${t=>t.id}" href="${t=>{var e;return null===(e=t.nativeAdRenderData)||void 0===e?void 0:e.destinationUrl}}" media-type="image" size="_2x_2y" title="${t=>{var e;return(null===(e=t.nativeAdRenderData)||void 0===e?void 0:e.title)||""}}" target="_blank" :anchorTelemetryTag="${()=>(0,Jt.u)("NativeAdCard",{behavior:l.MS.Navigate,action:l.EG.Click}).getMetadataTag()}" ${(0,Ti.Ib)()}><img slot="media" alt="${t=>{var e;return(null===(e=t.nativeAdRenderData)||void 0===e||null===(e=e.images)||void 0===e?void 0:e[0].alt)||""}}" class="ad-card-image" src="${t=>{var e;return null===(e=t.nativeAdRenderData)||void 0===e?void 0:e.imageUrl}}" @error="${t=>t.handleImageLoadError()}" /><span class="ad-card-title">${t=>{var e;return null===(e=t.nativeAdRenderData)||void 0===e?void 0:e.title}}</span></cs-content-card></cs-card></div>`)}
`,Ei=Zt.qy`<div class="${t=>{var e;return(0,Ie.x)("n2v-ad-controls-container",["hidden",!(null!==(e=t.native2VideoAdsManager)&&void 0!==e&&e.adControlsVisible)])}}"><div class="n2v-ad-controls"><div class="n2v-ad-controls-progress"><div class="n2v-ad-controls-progress-holder"><div class="n2v-ad-controls-progress-play" style="width: ${t=>{var e;return null===(e=t.native2VideoAdsManager)||void 0===e?void 0:e.progressPercent}}%"></div></div></div><button ${(0,ee.K)("telemetryForAdPlayOrPauseEl")} class="${t=>{var e;return(0,Ie.x)("n2v-ad-play-button",["pause",!(null!==(e=t.native2VideoAdsManager)&&void 0!==e&&e.isAdPlaying)])}}" data-t=${t=>{var e;return(0,Jt.u)(null!==(e=t.native2VideoAdsManager)&&void 0!==e&&e.isAdPlaying?"AdPause":"AdPlay",{behavior:l.MS.Click,action:l.EG.Click}).getMetadataTag()}} title="${t=>{var e,i,o;return null!==(e=t.native2VideoAdsManager)&&void 0!==e&&e.isAdPlaying?null===(i=t.videoCardProps)||void 0===i||null===(i=i.localizedStrings)||void 0===i?void 0:i.pause:null===(o=t.videoCardProps)||void 0===o||null===(o=o.localizedStrings)||void 0===o?void 0:o.play}}" @click=${t=>{var e;return null===(e=t.native2VideoAdsManager)||void 0===e?void 0:e.togglePlay()}}></button><div class="n2v-ad-play-time">${t=>t.progress}</div><div class="n2v-ad-play-time-divide">/</div><div class="n2v-ad-play-time">${t=>t.duration}</div></div><div class="n2v-ad-provider"><div class="n2v-ad-indicator">${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.localizedStrings)||void 0===e?void 0:e.adStringText}}</div></div><button class="n2v-ad-skip" data-t=${t=>{var e;return(0,Jt.u)("AdSkip",{behavior:l.MS.Click,action:l.EG.Click,ext:{status:null===(e=t.native2VideoAdsManager)||void 0===e?void 0:e.skipStatus}}).getMetadataTag()}} @click=${t=>{var e;return null===(e=t.native2VideoAdsManager)||void 0===e?void 0:e.skipAd()}}>${t=>t.skipButtonText}</button></div>`,Vi=Zt.qy`<div class="${t=>{var e;return(0,Ie.x)("n2v-ad-player-container",["hidden",!(null!==(e=t.native2VideoAdsManager)&&void 0!==e&&e.adVisible)],["is-in-cn-consumption-page",!!t.isChinaArticleComsuptionPage])}}" data-t=${()=>(0,Jt.u)("NativeToVideo",{type:l.MJ.Module}).getMetadataTag()}>${Ii} ${Ei}<button class="telemetry-mock" ${(0,ee.K)("telemetryForAdShowEl")} data-t="${()=>(0,Jt.u)("AdShow",{behavior:l.MS.Show,action:l.EG.View}).getMetadataTag()}" tabindex="-1"></button><button class="telemetry-mock" ${(0,ee.K)("telemetryForAdHideEl")} data-t="${()=>(0,Jt.u)("AdHide",{behavior:l.MS.Show,action:l.EG.View}).getMetadataTag()}" tabindex="-1"></button></div>`,zi=(0,$t.rA)().StaticsUrl,Di=Ft.A`
    .n2v-ad-player-container {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
    }
    .n2v-ad-player-container.hidden {
        display: none;
    }
    .n2v-ad-controls-container {
        box-sizing: border-box;
        color: rgb(255, 255, 255);
        font-size: 10px;
        font-weight: 400;
    }
    .n2v-ad-controls-container.hidden {
        .n2v-ad-controls, .n2v-ad-provider, .n2v-ad-skip {
            opacity: 0;
        }
    }
    .n2v-ad-controls {
        display: flex;
        flex-wrap: wrap;
        visibility: visible;
        opacity: 0.8;
        transition: opacity 0.3s;
        border-top-left-radius: 0.6em;
        border-top-right-radius: 0.6em;
        height: 70px;
        background: linear-gradient(rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.8) 75.47%, rgba(0, 0, 0, 0.8) 100%);
        width: 100%;
        position: absolute;
        bottom: 0px;
        left: 0px;
        right: 0px;
    }
    .n2v-ad-controls-progress {
        cursor: pointer;
        flex: 0 0 calc(100% - 10px);
        display: flex;
        align-items: end;
        min-width: 4em;
        height: 1.5em;
        touch-action: none;
        top: 10px;
        z-index: 10;
        padding-left: 8px;
        padding-right: 8px;
        position: relative;
        text-align: center;
        margin: 0px;
        padding: 0px 5px;
    }
    .n2v-ad-controls-progress-holder {
        background-color: rgba(255, 255, 255, 0.4);
        margin: 0px 10px;
        position: relative;
        cursor: pointer;
        padding: 0px;
        user-select: none;
        flex: 1 1 auto;
        transition: 0.2s;
        height: 0.5em;
    }
    .n2v-ad-controls-progress-play {
        background-color: rgb(255, 255, 255);
        position: absolute;
        display: block;
        height: 100%;
        margin: 0px;
        padding: 0px;
        width: 0px;
        border-radius: 3px;
        &::before {
            font-size: 1.2em;
            position: absolute;
            right: -0.5em;
            top: -0.4em;
            content: url(${zi}latest/views/icons/video/videoCircle.svg)
        }
    }
    .n2v-ad-play-button {
        position: relative;
        text-align: center;
        margin: 0px;
        padding: 0px;
        height: calc(100% - 1.5em - 10px);
        width: 4em;
        top: 5px;
        flex: 0 0 auto;
        cursor: pointer;
        margin-left: 10px;
        outline-offset: -5px;
        &::before {
            position: absolute;
            left: 0px;
            width: 100%;
            height: 100%;
            font-size: 0px;
            line-height: 2.6;
            text-align: center;
            content: url(${zi}latest/views/icons/video/videoPause.svg);
            top: 8px;
        }
    }
    .n2v-ad-play-button.pause:before {
        content: url(${zi}latest/views/icons/video/videoPlayBig.svg);
        top: 12px;
    }
    button {
        text-transform: none;
        text-decoration: none;
        transition: none;
        appearance: none;
        user-select: none;
        display: inline-block;
        background: transparent;
        border: none;
    }
    .n2v-ad-play-time {
        font-size: 1.5em;
        padding-left: 0.4em;
        padding-right: 0.4em;
        height: calc(100% - 1.5em - 10px);
        flex: 0 0 auto;
        line-height: 3.2em;
        min-width: 2em;
        width: auto;
    }
    .n2v-ad-play-time-divide {
        font-size: 1.5em;
        height: calc(100% - 1.5em - 10px);
        flex: 0 0 auto;
        line-height: 3.2em;
    }
    .n2v-ad-provider {
        min-height: 22px;
        width: 69%;
        position: absolute;
        bottom: 63px;
        background-color: transparent;
        display: flex;
        align-items: flex-end;
        padding-left: 15px;
        transition: opacity 0.3s;
    }
    .n2v-ad-indicator {
        line-height: 16px;
        width: auto;
        border: 0.5px solid #FFFFFF;
        border-radius: 4px;
        float: left;
        font-family: 'Segoe UI Variable Static Small', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-size: 12px;
        padding: 3px 5px 3px;
        background-color: transparent;
        cursor: default;
        font-weight: 400;
        color: #FFFFFF;
        max-width: 30%;
        white-space: pre-wrap;
        text-align: center;
    }
    .ad-card-container {
        height: 100%;
        background: #000;
        .ad-card {
            width: 100%;
            height: 100%;
        }
        .ad-card-title {
            font-size: 20px;
            line-height: 26px;
            font-weight: 600;
            color: #fff;
        }
        cs-content-card::part(heading) {
            text-align: center;
        }
    }
    .n2v-ad-skip {
        position: absolute;
        bottom: 62px;
        right: 16px;
        z-index: 2;
        width: auto;
        max-width: 29%;
        background-color: transparent;
        background: rgba(34, 34, 34, 0.75);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 4px;
        padding: 5px 12px;
        min-height: 22px;
        font-weight: 400;
        font-size: 14px;
        line-height: 20px;
        color: #FFFFFF;
        white-space: pre-wrap;
        text-align: center;
        min-height: 20px;
        transition: opacity 0.3s;
        cursor: default;
    }
    .telemetry-mock {
        position: absolute;
        visibility: hidden;
    }

    .n2v-ad-player-container.is-in-cn-consumption-page {
        z-index: 100;
    }

    .n2v-ad-player-container.is-in-cn-consumption-page .n2v-ad-controls-progress-play::before {
        top: -0.6em;
    }
`;let Fi=class extends Ai{};var Mi;Fi=(0,o.Cg)([(0,ae.E)({name:"native2video-ad-player",template:Vi,styles:Di})],Fi);const Oi=`${null===(Mi=(0,$t.rA)())||void 0===Mi?void 0:Mi.StaticsUrl}latest/fluent-icons/speaker_off_20_filled.svg`,Li=Zt.qy` ${(0,te.z)(t=>t.isButtonShown,Zt.qy`<div class="unmuted-button" @click=${t=>t.handleUnmuteEvent()} data-t="${t=>t.telemetryMetadata}" role="button" tabindex="0" part="unmuted-button"><img alt="${t=>{var e;return(null===(e=t.localizedStrings)||void 0===e?void 0:e.unmuteCTA)??"Unmute"}}" src="${Oi}" /><span class="unmuted-button-text" part="unmuted-button-text">${t=>{var e;return(null===(e=t.localizedStrings)||void 0===e?void 0:e.unmuteCTA)??"Unmute"}}</span></div>`)}
`,Ri=Ft.A` .unmuted-button{position:absolute;top:24px;left:12px;z-index:60;background:transparent;border-radius:6px;cursor:pointer;display:flex;justify-content:center;align-items:center;text-decoration:none;padding-inline:6px}.unmuted-button img{filter:invert(1)}.unmuted-button-text{font-size:18px;line-height:26px;font-weight:400;margin:2px 6px 4px;opacity:0}`;let Bi=class extends ae.L{constructor(){super(...arguments),this.isButtonShown=!1,this.updateButtonShown=()=>{var t;null!==(t=this.currentPlayer)&&void 0!==t&&t.isMuted||(this.isButtonShown=!1)}}connectedCallback(){super.connectedCallback(),this.videoCardManager=Et.N.getInstance()}disconnectedCallback(){var t;super.disconnectedCallback(),null===(t=this.currentPlayer)||void 0===t||t.removeEventListener("volumechange",this.updateButtonShown)}currentPlayerChanged(){var t;this.currentPlayer&&this.videoCardManager&&(this.videoCardManager.getPreference("isMuted")||0===(null===(t=this.videoCardManager)||void 0===t?void 0:t.getPreference("volume")))&&(this.isButtonShown=!0,this.currentPlayer.addEventListener("volumechange",this.updateButtonShown))}handleUnmuteEvent(){var t;null===(t=this.currentPlayer)||void 0===t||t.setMute(!1);const e=window.setTimeout(()=>{this.isButtonShown=!1,window.clearTimeout(e)})}get telemetryMetadata(){return(0,Jt.u)("unmutedButton",{action:l.EG.Click,behavior:l.MS.Unmute}).getMetadataTag()}};(0,o.Cg)([s.sH],Bi.prototype,"currentPlayer",void 0),(0,o.Cg)([s.sH],Bi.prototype,"localizedStrings",void 0),(0,o.Cg)([s.sH],Bi.prototype,"isButtonShown",void 0),(0,o.Cg)([s.sH],Bi.prototype,"videoCardManager",void 0),Bi=(0,o.Cg)([(0,ae.E)({name:"unmuted-button",template:Li,styles:Ri})],Bi),ne.oD;const Ni=Zt.qy` ${(0,te.z)(t=>t.config.enableNative2Video,Zt.qy`<native2video-ad-player :videoCardProps=${t=>t.videoCardProps} :config=${t=>t.config} :renderState=${t=>{var e;return null===(e=t.context)||void 0===e?void 0:e.renderState}} :playerFeedIdx=${t=>{var e;return null===(e=t.context)||void 0===e?void 0:e.playerFeedIdx}} :originId=${t=>t.id} :isChinaArticleComsuptionPage=${t=>t.isChinaArticleComsuptionPage} :disableN2vAdsEnhance=${t=>{var e;return null===(e=t.context)||void 0===e?void 0:e.disableN2vAdsEnhance}}></native2video-ad-player>`)}
`,Ui=Zt.qy` ${Ni} ${(0,te.z)(t=>{var e;return(null===(e=t.context)||void 0===e?void 0:e.enableDetailEnhance)&&t.context.isInDetailPage&&$t.T3.IsChinaCompliance},Zt.qy`<unmuted-button :localizedStrings=${t=>t.config.localizedStrings} :currentPlayer=${t=>t.embedMediaPlayer}></unmuted-button>`)}
`,ji=Zt.qy`<div class="directEmbed_root" data-t="${t=>{var e;return null===(e=t.videoTelemetryContext)||void 0===e||null===(e=e.parentTelemetry)||void 0===e?void 0:e.getMetadataTag()}}"><iframe width="100%" height="100%" ${(0,ee.K)("demPlayerContainerRef")} src="${t=>(t=>{const{directEmbedMedia:e,isAutoPlayEnabledForWebContent:i=!1}=t.videoCardProps||{},{language:o}=navigator,n=Boolean(t.ytGamepadSatoriId);return Ge.YouTubePlayer.buildIframeSrc((null==e?void 0:e.id)??"",{disableControls:n,isAutoplay:i,language:o,privacyMode:n})})(t)}" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen class="video-embed-common"></iframe>${(0,te.z)(t=>Boolean(t.ytGamepadSatoriId),()=>((async()=>{const{GamepadYouTubePlayerControls:t}=await i.e("experiences_video-card-wc_dist_components_gamepad-youtube-player-controls_index_js").then(i.bind(i,24301))})(),Zt.qy`<gamepad-youtube-player-controls></gamepad-youtube-player-controls>`))}</div>`,Gi=Zt.qy`<div class="directEmbed_root" data-t="${t=>{var e;return null===(e=t.videoTelemetryContext)||void 0===e||null===(e=e.parentTelemetry)||void 0===e?void 0:e.getMetadataTag()}}">${(0,te.z)(t=>{var e;return void 0!==(null===(e=t.videoCardProps)||void 0===e?void 0:e.leadsGenVideoAdsSkipDuration)},Zt.qy`<leads-gen-ad-player :videoCardProps=${t=>t.videoCardProps}></leads-gen-ad-player>`)} ${Ui}<iframe width="100%" height="100%" ${(0,ee.K)("demPlayerContainerRef")} src="${t=>{var e,i;return We.YiDianPlayer.buildIframeSrc((null===(e=t.videoCardProps)||void 0===e||null===(e=e.directEmbedMedia)||void 0===e?void 0:e.videoSrcUrl)??"",(null===(i=t.videoCardProps)||void 0===i?void 0:i.isAutoPlayEnabledForWebContent)??!1)}}" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen class="video-embed-common"></iframe></div>`,Wi=Zt.qy`<div class="directEmbed_root" data-t="${t=>{var e;return null===(e=t.videoTelemetryContext)||void 0===e||null===(e=e.parentTelemetry)||void 0===e?void 0:e.getMetadataTag()}}"><iframe width="100%" height="100%" ${(0,ee.K)("demPlayerContainerRef")} src="${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.directEmbedMedia)||void 0===e?void 0:e.videoSrcUrl}}" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen class="video-embed-common"></iframe></div>`,Hi=Zt.qy`<div class="cbsEmbed_root video-embed-common" data-t="${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.telemetryContext)||void 0===e||null===(e=e.parentTelemetry)||void 0===e?void 0:e.getMetadataTag()}}"><iframe width="100%" height="100%" ${(0,ee.K)("demPlayerContainerRef")} src="${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.directEmbedMedia)||void 0===e?void 0:e.videoSrcUrl}}" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen class="video-embed-common"></iframe></div>`,Yi=Zt.qy`<div class="directEmbed_root" data-t="${t=>{var e;return null===(e=t.videoTelemetryContext)||void 0===e||null===(e=e.parentTelemetry)||void 0===e?void 0:e.getMetadataTag()}}">${Ui}<iframe width="100%" height="100%" ${(0,ee.K)("demPlayerContainerRef")} src="${t=>{var e,i;return He.HuYaPlayer.buildIframeSrc((null===(e=t.videoCardProps)||void 0===e||null===(e=e.directEmbedMedia)||void 0===e?void 0:e.videoSrcUrl)??"",(null===(i=t.videoCardProps)||void 0===i?void 0:i.isAutoPlayEnabledForWebContent)??!1)}}" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen class="video-embed-common"></iframe></div>`,qi=Zt.qy`<div class="directEmbed_root" data-t="${t=>{var e;return null===(e=t.videoTelemetryContext)||void 0===e||null===(e=e.parentTelemetry)||void 0===e?void 0:e.getMetadataTag()}}">${Ui}<iframe width="100%" height="100%" ${(0,ee.K)("demPlayerContainerRef")} src="${t=>{var e,i;return Ye.RenminPlayer.buildIframeSrc((null===(e=t.videoCardProps)||void 0===e||null===(e=e.directEmbedMedia)||void 0===e?void 0:e.videoSrcUrl)??"",(null===(i=t.videoCardProps)||void 0===i?void 0:i.isAutoPlayEnabledForWebContent)??!1)}}" frameBorder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen class="video-embed-common"></iframe></div>`,Ji=Zt.qy`<div class="video-clear-div"></div>`,Ki=Zt.qy`<img alt="" src="${(0,$t.rA)().StaticsUrl}latest/icons-wc/icons/VideoBlue.svg"></img>`,Xi=Zt.qy` (${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.videoData)||void 0===e||null===(e=e.provider)||void 0===e?void 0:e.name}})
`,Qi=Zt.qy` ${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.videoData)||void 0===e?void 0:e.title}} ${(0,te.z)(t=>{var e;return!(null===(e=t.videoCardProps)||void 0===e||null===(e=e.videoData)||void 0===e||null===(e=e.provider)||void 0===e||!e.name)},Xi)}
`,Zi=Zt.qy`<div class="video-footer-container related-video-divider-bottom-title ${t=>t.getBlueMarkerClassNames("bottom")}"><span class="video-footer-title" title="${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.videoData)||void 0===e?void 0:e.title}}">${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.videoData)||void 0===e?void 0:e.title}}</span><div class="video-footer-provider"><img class="video-footer-provider-image" src="${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.providerData)||void 0===e||null===(e=e.logo)||void 0===e?void 0:e.src}}" alt="${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.providerData)||void 0===e?void 0:e.name}}"><span class="video-footer-provider-title" title="${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.providerData)||void 0===e?void 0:e.name}}">${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.providerData)||void 0===e?void 0:e.name}}</span></div><div class="video-button-container">${oe}</div></div>`,to=Zt.qy`<div class="partner-embed-placeholder"></div>`,eo=Zt.qy`<next-videos-overlay-wc :upNextVideoSec=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.upNextVideoSec}} :relatedVideoLocalizedText=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.relatedVideoLocalizedText}} :upNextCardLocalizedText=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.upNextCardLocalizedText}} :videos=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.nextVideosOverlayData}} :onUpNextVideoTimerDone=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.onUpNextVideoTimerDone}} :onCloseClick=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.onCloseClick}} :onOverlayClick=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.onOverlayClick}} :noTimer=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.noTimer}} :showPauseSlate=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.showPauseSlate}} :showUpNextCard=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.showUpNextCard}} :isLargeTitleVideoPlayer=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.isLargeTitleVideoPlayer}} :applyEmbeddedVideoThumbnailStyles=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.applyEmbeddedVideoThumbnailStyles}} :applyDynamicAlignmentStyles=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.applyDynamicAlignmentStyles}} :disableUpNextLink=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.disableUpNextLink}} :disablePauseOnBlur=${t=>{var e;return null===(e=t.nextVideosOverlayData)||void 0===e?void 0:e.disablePauseOnBlur}} :isXboxGamepadVideo=${t=>Boolean(t.ytGamepadSatoriId)} :hideDurationLabel=${t=>t.isChinaArticleComsuptionPage}></next-videos-overlay-wc>`,io=Zt.qy`<div class="videocard3PPNotice">${t=>{var e;return t.config&&(null===(e=t.config.thirdPartyPlayersConfig)||void 0===e||null===(e=e.localizedStrings)||void 0===e?void 0:e.videoPlayerFrom)}}: ${t=>{var e;return null===(e=t.videoCardProps)||void 0===e||null===(e=e.card3ppConfig)||void 0===e?void 0:e.displayName}} (<span>${t=>Zt.qy.partial((t=>{var e;const{card3ppConfig:i,thirdPartyPlayersConfig:o}=t.videoCardProps||{},n=null==o?void 0:o.localizedStrings;if(!i||!n)return"";i.privacy=null===(e=i.privacy)||void 0===e?void 0:e.replace(/%%LANG%%/g,u.Rb.Locale.substring(0,2));let a=`<a href="${i.privacy}" target="_blank">${n.privacyPolicy}</a>`;return i.terms&&(i.terms=i.terms.replace(/%%LANG%%/g,u.Rb.Locale.substring(0,2)),a+=`, <a href="${i.terms}" target="_blank">${n.terms}</a>`),a})(t))}</span>)</div>`,oo=Zt.qy`<div class="video-card-image-preview-overlay"><img alt="placeholder" src="${t=>{var e;return null===(e=t.videoCardProps)||void 0===e?void 0:e.posterUrl}}" /></div>`,no=Zt.qy`<div class="videocard3PP ${t=>t.config.enableTitleAtBottom?"":t.getBlueMarkerClassNames("bottom")} ${t=>t.shouldAddExtraStylingForRelatedVideos?"videocardRelatedVideo3PP":""}" data-t="${t=>{var e;return null===(e=t.videoTelemetryContext)||void 0===e||null===(e=e.parentTelemetry)||void 0===e?void 0:e.getMetadataTag()}}" ${(0,ee.K)("thirdPartyPlayerParentContainerRef")}><slot name="js-embed"></slot>${t=>{var e;const i=null===(e=t.videoCardProps)||void 0===e?void 0:e.card3ppConfig;if(!i)return;const{name:o,type:n}=i;if("js"===n){const e=document.createElement("div");return e.id=`${o}-video-${t.id}`,e.slot="js-embed",e.classList.add(`${o}3PPStyle`),e.style.borderRadius=t.config.enableLargeTitle?"6px":"initial",t.appendChild(e),void(t.thirdPartyPlayerContainerRef=e)}return Zt.qy`<iframe ${(0,ee.K)("thirdPartyPlayerContainerRef")} width="100%" height="100%" src="${ro}" frameBorder="0" scrolling="no" allow="${so}" allowFullScreen class="video-embed-common"></iframe>`}} ${(0,te.z)(t=>{var e;return!(null!==(e=t.videoCardProps)&&void 0!==e&&null!==(e=e.playerConfigProps)&&void 0!==e&&e.hidePrivacyLinks)},io)}</div>`,ao=Zt.qy`<div class=" videocard1PP video-embed-common ${t=>t.config.enableTitleAtBottom?"":t.getBlueMarkerClassNames("bottom")} ${t=>t.shouldAddExtraStylingForRelatedVideos?"videocardRelatedVideo":""}"><content-video-player :contentVideoPlayerProps=${t=>t.contentVideoPlayerProps} :playsInline=${!0} :toggleFullscreen=${t=>{var e;return null===(e=t.context)||void 0===e?void 0:e.toggleFullscreen}} :videoBodyChildren=${t=>t.contentVideoPlayerBodyChildren} :styleOverrides=${t=>t.contentVideoPlayerStyleOverrides} :doubleClickVideoOverride=${t=>{var e;return null===(e=t.context)||void 0===e?void 0:e.doubleClickVideoOverride}} :handleAdSkipClick=${t=>t.handleAdSkipClick}></content-video-player>${(0,te.z)(t=>t.isChinaArticleComsuptionPage&&t.config.enableN2vOnArticlePage,Ni)}</div>`,ro=t=>{const{card3ppConfig:e,playerConfigProps:i,videoData:o}=t.videoCardProps||{},{name:n,urlformat:a,altUrlformat:r}=e||{};let s=(0,ie.bI)(function(t,e,i,o){if(!e)return"";let n;return t&&o&&i&&(n=qe.get(t))?n(o,e,i):e}(n,a,r,null==o?void 0:o.sourceId));return s=s.replace(/%%SOURCE_CONTENT_ID%%/g,(null==o?void 0:o.sourceId)??""),s=s.replace(/%%WINDOW_LOCATION%%/g,encodeURIComponent(window.location.toString())),s=s.replace(/%%AUTOPLAY_STR%%/g,null!=i&&i.iframeAutoplay?"true":"false"),s=s.replace(/%%AUTOPLAY_INT%%/g,null!=i&&i.iframeAutoplay?"1":"0"),s=s.replace(/%%MUTED_STR%%/g,null!=i&&i.muted?"true":"false"),s=s.replace(/%%MUTED_INT%%/g,null!=i&&i.muted?"1":"0"),s},so=t=>{const{card3ppConfig:e}=t.videoCardProps||{};return`accelerometer; ${e&&e.disableAutoplayPolicy?"":"autoplay; "}clipboard-write; encrypted-media; gyroscope; picture-in-picture`},lo=Zt.qy`<loading-state-video-card></loading-state-video-card>`,ho=Zt.qy` ${t=>{if(t.videoCardProps){const{card3ppConfig:e,directEmbedMedia:o}=t.videoCardProps;if(o)switch(o.type){case"YouTube":return ji;case"PlutoTv":return(async()=>{(await i.e("experiences_spotlight-card-wc_dist_Mappers_OnThisDay_OnThisDayCardMapper_js-experiences_video-cca9b6").then(i.bind(i,79825))).PlutoTvPlayerElement})(),Zt.qy`<pluto-tv-player></pluto-tv-player>`;case"Yidianzixun":return Gi;case"ShortTv":return Wi;case"GenericIframe":return Hi;case"Huya":return Yi;case"Renmin":return qi;default:return}return e?no:ao}}}
`,co=t=>((async()=>{const{CardedContainer:t}=await i.e("experiences_video-card-wc_dist_components_carded-container_index_js").then(i.bind(i,57886))})(),Zt.qy`<carded-container :childConfigs=${t=>{var e,i;return{...t.config.cardedChildConfigs,videoCardPrivacyStrings:{videoPlayerFrom:null===(e=t.strings)||void 0===e?void 0:e.videoPlayerFrom,privacyPolicy:null===(i=t.strings)||void 0===i?void 0:i.privacyPolicy}}}} :videoData=${t=>{var e;return null===(e=t.videoCardProps)||void 0===e?void 0:e.videoData}} :thirdPartyProviders=${t=>{var e;return null===(e=t.config.thirdPartyPlayersConfig)||void 0===e?void 0:e.players}} :useShortDesign=${t=>t.config.useShortCardedDesign}>${t}</carded-container>`),uo=t=>Zt.qy` ${(0,te.z)(t=>{var e;return null===(e=t.context)||void 0===e?void 0:e.isContentBingmm},(t=>Zt.qy` ${(0,te.z)(e=>!t,Ji)}<a href="${t=>t.deeplinkUrl}" data-test-id="video-embed-title" class="${e=>e.getBlueMarkerClassNames(t?"topCarded":"top")} video-title related-video-link" tabindex="0" target="_blank" data-t="${t=>{var e;return null===(e=t.videoTelemetryContext)||void 0===e||null===(e=e.relatedVideoTitleLink)||void 0===e?void 0:e.getMetadataTag()}}">${(0,te.z)(t=>t.config.enableLargeTitle,Ki)}<span class=${t=>t.config.enableLargeTitle?"related-video-title-bold":""}>${t=>t.videoTitlePrefix??"Related video"}</span>${e=>e.config.enableTitleAtBottom||t?"":":"} ${(0,te.z)(e=>!e.config.enableTitleAtBottom&&!t,Qi)}</a>`)(t))}<div class="video-wrapper ${t=>t.config.isInIframe?"is-in-iframe":""} ${t=>t.ytGamepadSatoriId?"remove-overflow":""} ${t=>t.isChinaArticleComsuptionPage?"is-cn-consumption-page":""}" tabindex="0" ${(0,ee.K)("videoCardRef")}>${ho} ${(0,te.z)(t=>t.isChinaArticleComsuptionPage&&t.enableImagePreview,oo)} ${(0,te.z)(t=>t.nextVideosOverlayData,eo)}</div>${(0,te.z)(t=>t.config.enableTitleAtBottom,Zi)} ${(0,te.z)(t=>{var e;return null===(e=t.context)||void 0===e?void 0:e.isContentBingmm},Ji)}
`,po=Zt.qy` ${t=>{var e,i;if(t.hasValidPreviewData||!t.isChinaArticleComsuptionPage)return t.errorMessage?Zt.qy`<video-card-error class="video-wrapper-error" message="${t.errorMessageText||t.errorMessage}"></video-card-error`:t.videoCardProps?t.config.useCardedEmbedVideo&&null!==(e=t.context)&&void 0!==e&&e.isContentBingmm?co(uo(!0)):uo(!1):null!==(i=t.context)&&void 0!==i&&i.isContentBingmm?lo:to}}
`,vo={experienceConfigSchema:undefined}},50866(t,e,i){i.d(e,{L9(){return a},NZ(){return n},qJ(){return o}});const o={_1x_1y:"_1x_1y",_1x_2y:"_1x_2y",_2x_2y:"_2x_2y",_2x_1y:"_2x_1y"},n={DarkPlum:"dark-plum",DarkDesert:"dark-desert",DarkDawn:"dark-dawn",DarkSea:"dark-sea",DarkOrange:"dark-orange",DarkTropic:"dark-tropic",DarkMerlot:"dark-merlot",DarkPurple:"dark-purple",DarkGreen:"dark-green"},a={LightBlue:"light-blue",LightPurple:"light-purple",LightSky:"light-sky",LightPink:"light-pink",LightYellow:"light-yellow",LightBluebird:"light-bluebird",LightOrange:"light-orange",LightAqua:"light-aqua",LightGreen:"light-green"}},58960(t,e,i){var o;i.d(e,{O(){return o},v(){return n}}),function(t){t.PlayActiveVideo="previewPlayActiveVideo",t.PauseAllVideos="previewPauseAllVideos "}(o||(o={}));const n={[o.PlayActiveVideo]:new CustomEvent(o.PlayActiveVideo,{bubbles:!0}),[o.PauseAllVideos]:new CustomEvent(o.PauseAllVideos,{bubbles:!0})}},64183(t,e,i){i.d(e,{o(){return r},t(){return a}});var o=i(68009),n=i(49399);function a(t,e,i,n,a,r,s){const d=t.closestIndexOf(e);return null==s&&(s=(0,o.F)(e)),{rest:t.get(d+s*i),hover:t.get(d+s*n),active:t.get(d+s*a),focus:t.get(d+s*r)}}function r(t,e,i,o,r,s,d=void 0,l,h,c,u,p=void 0){return(0,n.H)(e)?a(t,e,l,h,c,u,p):a(t,e,i,o,r,s,d)}},65114(t,e,i){i.d(e,{yB(){return o}});const o=Object.freeze({Yidianzixun:"https://msn2.go2yd.com",Renmin:"https://jfmicsovideos.peopletech.cn"});Object.freeze({Yidianzixun:"https://doris.yidianzixun.com"})},71008(t,e,i){i.d(e,{h(){return p}});var o=i(56911),n=i(57606),a=i(5291),r=i(95239),s=i(31023),d=i(60815),l=i(74849),h=i(22870),c=i(38493),u=i(93518);class p extends u.X{constructor(){super(...arguments),this.gradientAngle="112.05deg",this.gradientColor=this.cardFillColor,this.gradientVariables=null}cardFillColorChanged(t,e){if(!e)return;if(super.cardFillColorChanged(t,e),!(0,h.Bi)(e))return this.gradientVariables&&this.$fastController.removeStyles(this.gradientVariables),r.p.deleteValueFor(this),void s.r.deleteValueFor(this);const i=(0,h.Hs)(e);i&&(this.neutralPaletteSource=e,r.p.setValueFor(this,a.q.create(i.r,i.g,i.b)))}neutralPaletteSourceChanged(t,e){if(e){const t=(0,h.Hs)(e);if(!t)return;const i=a.q.create(t.r,t.g,t.b);s.r.setValueFor(this,n.p.create(i))}}cardSecondaryColorChanged(){this.handleChange()}gradientAngleChanged(){this.handleChange()}generateGradientVariables(t,e,i){return l.A`
            :host {
                --gradient-angle: ${t};
                --gradient-start-color: ${e};
                --gradient-end-color: ${i};
            }
        `}connectedCallback(){super.connectedCallback(),d.cP.getNotifier(this).subscribe(this,"cardFillColor"),this.handleChange()}handleChange(){this.cardSecondaryColor&&(this.cardFillColor?this.gradientColor=this.cardFillColor:this.gradientColor=r.p.getValueFor(this).toColorString(),this.gradientVariables&&this.$fastController.removeStyles(this.gradientVariables),this.gradientVariables=this.generateGradientVariables(this.gradientAngle,this.gradientColor??"",this.cardSecondaryColor),this.$fastController.addStyles(this.gradientVariables))}}(0,o.Cg)([(0,c.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,o.Sn)("design:type",String)],p.prototype,"neutralPaletteSource",void 0),(0,o.Cg)([(0,c.CF)({attribute:"card-secondary-color",mode:"fromView"}),(0,o.Sn)("design:type",Object)],p.prototype,"cardSecondaryColor",void 0),(0,o.Cg)([(0,c.CF)({attribute:"gradient-angle",mode:"fromView"}),(0,o.Sn)("design:type",String)],p.prototype,"gradientAngle",void 0)},71608(t,e,i){i.d(e,{Af(){return y}});var o=i(92687),n=i(96950),a=i(60402);const r=n.qy`<span part="image" ${(0,a.K)("imageContainer")}><slot name="image" ${(0,a.K)("image")} @slotchange=${t=>t.handleImageContentChange()}></slot></span><span part="content" class="content"><slot></slot></span>`;var s=i(74849),d=i(64187),l=i(22131),h=i(7896),c=i(61138),u=i(64003),p=i(74838),v=i(50882);const g=s.A`
        ${(0,d.V)("inline-flex")} :host{box-sizing:border-box;font-family:${h.O};
            font-size: ${c.k};
            font-weight: 400;
            line-height: ${c.F};
            align-items: center;
            color: ${u.c};min-height:16px}.content{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.image{display:flex;margin-inline-end:calc(${p.vR} * 2px);
        }
    `.withBehaviors((0,l.mr)(s.A` :host,.content{color:${v.A.CanvasText};
                    fill: currentcolor;
                }
            `));var m=i(99900);const y=o.m.compose({name:`${m.i.prefix}-attribution`,template:r,styles:g})},72526(t,e,i){i.d(e,{L(){return v}});var o=i(56911),n=i(96193),a=i(47429),r=i(60815),s=i(22870),d=i(38493),l=i(95239),h=i(31023),c=i(24458),u=i(5291),p=i(57606);class v extends n.z{cardFillColorChanged(t,e){if(e){const t=(0,s.Hs)(e);null!==t&&(this.neutralPaletteSource=e,l.p.setValueFor(this,u.q.create(t.r,t.g,t.b)))}}neutralPaletteSourceChanged(t,e){if(e){const t=(0,s.Hs)(e),i=u.q.create(t.r,t.g,t.b);h.r.setValueFor(this,p.p.create(i))}}handleChange(t,e){this.cardFillColor||l.p.setValueFor(this,t=>t(c.M3).evaluate(t,t(l.p)))}connectedCallback(){super.connectedCallback();const t=(0,a.Zo)(this);if(t){const e=r.cP.getNotifier(t);e.subscribe(this,"fillColor"),e.subscribe(this,"neutralPalette"),this.handleChange(t,"fillColor")}}}(0,o.Cg)([(0,d.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,o.Sn)("design:type",String)],v.prototype,"cardFillColor",void 0),(0,o.Cg)([(0,d.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,o.Sn)("design:type",String)],v.prototype,"neutralPaletteSource",void 0)},73893(t,e,i){i.d(e,{m(){return s}});var o=i(65614),n=i(71008),a=i(42792);const r=i(96950).qy`
    <slot></slot>
`,s=n.h.compose({name:`${o.G.prefix}-card`,styles:a.R7,template:r})},75003(t,e,i){i.d(e,{m(){return s}});var o=i(37180),n=i(72526),a=i(37256),r=i(38380);const s=n.L.compose({name:`${o.c.prefix}-card`,template:r.v,styles:a.R})},75307(t,e,i){i.d(e,{Bl(){return u},Eo(){return l},KN(){return d},LG(){return h},Mj(){return p},kg(){return s},x8(){return c}});var o=i(58792),n=i(99476),a=i(26363),r=i(77367);function s(){const t=(0,n.a)();return!!t&&("1"===t.get("vptest")||"true"===t.get("vptest")||"vp"===t.get("reqsrc"))}function d(t,e){return l(t,e,"shopping/product-tracking")}function l(t,e,i){if("local"===e&&window.location.origin.indexOf("localhost")>-1)return`http://127.0.0.1:3000/shopping/${t}.svg`;if(t){const n=e?`pr-${e}`:"latest",a=i?`${i}`:"shopping";return`${(0,o.rA)().StaticsUrl}${n}/${a}/${t}.svg`}return""}function h(t){return t&&t.href&&(t.href=c(t.href)),!0}function c(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;const i=(new Date).getTime()+e,o=(0,a.G)(),n=new URL(t);return n.searchParams.set("ts",i.toString()),n.searchParams.set("m_clk",`sid-${o}`),n.toString()}function u(t){return!!t&&/p4psearch\.1688\.com/.test(t)}function p(t,e){if(t&&t.href){const i=new URL(t.href);i.searchParams.set("m_ac","176674350"),i.searchParams.set("PageId",r.YT.getRequestId()),i.searchParams.set("ct",e),t.href=c(i.toString())}return!0}},77848(t,e,i){i.d(e,{YouTubePlayer(){return l}});var o=i(93552),n=i(22341),a=i(74998),r=i(17852),s=i(11206),d=i(97015);class l extends s.a{constructor(){super(...arguments),this.type="YouTube",this.inViewport=!0,this.loadPlayerScripts=t=>(l.loadPromise||(l.loadPromise=new Promise(e=>(window.onYouTubeIframeAPIReady=e,(0,r.k)({id:l.scriptId,src:l.scriptSrc,retryNumber:t?5:0,retryDelayMs:t?200:0})))),l.loadPromise),this.createEvents=t=>({onReady:()=>{t(),this.perfObserver.mark("ready"),this.perfObserver.mark("loaded"),this.listenYTInfoDelivery(),window.setTimeout(()=>this.triggerEvent("ready",this.normalizeEvent()))},onStateChange:this.onStateChange,onError:t=>{const e=l.errorMessages.get(null==t?void 0:t.data)??"Unknown error",{id:i,title:a,provider:r,sourceId:s,isWebContent:d,recoId:h}=this.playerInfo.video;(0,n.vV)(o.uiS,e,"An error occurred during playing a YouTube video.",{id:i,title:a,provider:r,sourceId:s,isWebContent:d,recoId:h})}}),this.onStateChange=t=>{const{data:e}=t,i=this.normalizeEvent(),{ENDED:o,PLAYING:n,PAUSED:a}=window.YT.PlayerState;switch(e){case o:this.triggerEvent("ended",i);break;case n:{const t=this.wasPaused?"resume":"play";this.wasPaused=!1,this.triggerEvent(t,i);break}case a:this.wasPaused=!0,this.triggerEvent("pause",i)}},this.normalizeEvent=()=>{const t=this.createContentEvent(),{content:e}=t;return{...t,isPlayerPaused:this.instance.getPlayerState()===window.YT.PlayerState.PAUSED,content:{...e,videoPositionSec:this.instance.getCurrentTime()??0,title:this.instance.videoTitle??e.title,videoDuration:this.instance.getDuration()??e.videoDuration}}},this.youtubeInfoDeliveryHandler=t=>{if(t.data&&"function"==typeof t.data.includes&&t.data.includes("infoDelivery"))try{const e=JSON.parse(t.data);if(!e||e.id!=this.instance.id)return;"info"in e&&"volume"in e.info&&this.triggerEvent("volumechange",this.normalizeEvent())}catch(t){const{id:e,provider:i,sourceId:a,isWebContent:r}=this.playerInfo.video;(0,n.c_)(t,o.uiS,"Failed to parse Youtube's infoDelivery message.",void 0,{id:e,provider:i,sourceId:a,isWebContent:r})}}}async initialize(t){const{container:e,playerInfo:i}=t,{sourceId:o}=i.video,n=e.clientHeight,a=e.clientWidth;return await this.loadPlayerScripts(t.shouldUseRetryWithDelay),new Promise(r=>{const s=new window.YT.Player(e,{videoId:o,height:String(n),width:String(a),events:this.createEvents(r)});super.init(s,e,i),t.inViewPlay&&this.setupIntersectionObserver(t.inViewPlayRatio)})}play(){super.play(),this.resetIfEnded(),this.instance.playVideo()}pause(){super.pause(),this.instance.pauseVideo()}setMute(t){t?this.instance.mute():this.instance.unMute()}setVolume(t){const e=100*this.normalizeVolume(t);this.instance.setVolume(e)}seekBySeconds(t){const e=this.instance.getCurrentTime(),i=this.instance.getDuration(),o=(0,d.z7)(e,i,t);this.instance.seekTo(o,!0)}get isMuted(){return this.instance.isMuted()}get volume(){const t=this.instance.getVolume();return this.normalizeVolume(t)}resetIfEnded(){const t=this.instance;t.getPlayerState()===window.YT.PlayerState.ENDED&&t.seekTo(0,!0)}get canProvideVideoPosition(){return!0}get shouldEmulateTimeUpdate(){return!0}createTimeUpdateEventData(){return this.normalizeEvent()}listenYTInfoDelivery(){window.addEventListener("message",this.youtubeInfoDeliveryHandler)}setupIntersectionObserver(t){if(!this.htmlEl||this.intersectionObserver)return;const e=t??.5,i={threshold:e,rootMargin:"50px"};this.intersectionObserver=new IntersectionObserver(t=>{t.forEach(t=>{const i=t.intersectionRatio>=e;if(!i&&this.inViewport&&this.isPlaying)try{this.pause()}catch(t){const{id:e,title:i,provider:a,sourceId:r,isWebContent:s,recoId:d}=this.playerInfo.video;(0,n.c_)(t,o.uiS,"Failed to auto-pause YouTube video when out of view.",void 0,{id:e,title:i,provider:a,sourceId:r,isWebContent:s,recoId:d})}this.inViewport=i})},i),this.intersectionObserver.observe(this.htmlEl)}cleanupIntersectionObserver(){this.intersectionObserver&&(this.intersectionObserver.disconnect(),this.intersectionObserver=void 0)}dispose(){this.cleanupIntersectionObserver(),window.removeEventListener("message",this.youtubeInfoDeliveryHandler),this.instance.destroy(),super.dispose()}}l.forbiddenErrorMessage="Youtube Player error: owner of the requested video does not allow it to be played in embedded players",l.errorMessages=new Map([["2","Youtube Player invalid parameter value (eg invalid video ID)"],["5","Youtube Player unable to player content in an HTML5 player"],["100","Youtube Player requested video not found"],["101",l.forbiddenErrorMessage],["150",l.forbiddenErrorMessage]]),l.scriptSrc="https://www.youtube.com/iframe_api",l.scriptId="YouTubeSDK",l.buildIframeSrc=(t,e)=>{var i;const{disableControls:o=!1,isAutoplay:n,language:r,privacyMode:s=!1}=e,d=r??((null===(i=a.Rb.ClientSettings.locale)||void 0===i?void 0:i.language)||"en"),l=new Map([["enablejsapi",1],["mute",1],["autoplay",n?1:0],["origin",window.location.origin],["modestbranding",1],["hl",d],["cc_lang_pref",d],["cc_load_policy",1]]);o&&(l.set("controls",0),l.set("disablekb",1),l.set("fs",0),l.set("rel",0));return`https://www.youtube${s?"-nocookie":""}.com/embed/${t}?${Array.from(l).map(t=>{let[e,i]=t;return`${e}=${i}`}).join("&")}`}},80090(t,e,i){i.d(e,{m(){return I}});var o=i(65614),n=i(11310),a=i(7896),r=i(48751),s=i(41123),d=i(57416),l=i(62047),h=i(14996),c=i(89580),u=i(99657),p=i(86856),v=i(74849),g=i(73477),m=i(4126),y=i(22131),b=i(50882);const f=v.A`
    .text,
    .media-info,
    .gradient {
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
    }

    .action-tray {
        transition-duration: var(--video-transition-end-duration);
        transition-property: background-color;
    }

    ::slotted([slot="media-overlay"]) {
        color: #ffffff;
        fill: #ffffff;
        height: 40px;
        min-width: 40px;
        display: grid;
        padding: 0px;
        grid-auto-flow: column;
        grid-gap: 8px;
        box-sizing: border-box;
        align-items: center;
        justify-content: center;
        border-radius: 20px;
        border: 1px solid transparent;
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
        background: linear-gradient(
                    135deg,
                    rgba(0, 0, 0, 0.5) 0%,
                    rgba(0, 0, 0, 0.7) 100%
                )
                padding-box,
            linear-gradient(
                    180deg,
                    rgba(255, 255, 255, 0.4) 0%,
                    rgba(255, 255, 255, 0.2) 100%
                )
                border-box;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 22px;
        min-width: 22px;
        padding: 0 6px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 38px;
        min-width: 38px;
        padding: 0 6px;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([animate-video]) .media-info,
    :host([immersive-card][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_1x_2y"][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_2x_2y"][animate-video]) ::slotted([slot="media-overlay"]) {
        transition-delay: var(--video-transition-delay);
        transition-duration: var(--video-transition-start-duration);
        opacity: 0;
    }
`,x=v.A`
    .preload {
        transition: none !important;
    }

    :host {
        --content-padding: 16px;
        --no-image-action-tray-padding: 20px;
        --action-tray-padding: 10px;
        width: 100%;
        height: 100%;
        font-family: ${a.O};
        --video-transition-delay: 1s;
        --video-transition-start-duration: 1s;
        --video-transition-end-duration: 1s;
    }

    :host([subscibed])::after {
        position: absolute;
        content: "";
        bottom: 0;
        left: 0;
        right: 0;
        height: 4px;
        width: 100%;
        background: linear-gradient(90deg, #ffa03d 0%, #ffdb00 100%);
    }

    :host([size="_1x_2y"]),
    :host([size="_2x_2y"]) {
        --content-card-heading-font-size: 18px;
        --content-card-heading-line-height: 24px;
    }

    :host .content {
        display: grid;
        grid-template-columns: 1fr minmax(auto, 84px);
        grid-template-rows: 1fr auto;
        row-gap: 14px var(--content-padding) var(--content-padding) var(--content-padding);
        column-gap: 12px;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        color: ${r.l};
        position: relative;
    }

    :host([size="_1x_1y"]) .content {
        row-gap: 0px;
        padding: 14px var(--content-padding) 10px var(--content-padding);
    }

    :host([size="_2x_1y"]) .content {
        row-gap: 0px;
        padding: var(--content-padding) var(--content-padding) 14px var(--content-padding);
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        grid-template-columns: 1fr;
        column-gap: 0;
    }

    :host([size="_1x_2y"]) .content {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]) .content.no-image {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .content:not(.no-image) .text {
        padding-top: 12px;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .content:not(.no-image) .text {
        padding-top: 0;
    }

    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        align-items: end;
        grid-template-rows: 1fr auto auto;
    }

    :host([size="_2x_2y"]) .no-image {
        align-items: unset;
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content {
        padding: 0;
        row-gap: 0;
    }

    :host([size="_1x_1y"]) .content.no-image,
    :host([size="_2x_1y"]) .content.no-image,
    :host([size="_1x_2y"]) .content.no-image,
    :host([size="_2x_2y"]) .content.no-image {
        grid-template-rows: 1fr auto;
    }

    ::slotted([slot="abstract"]) {
        display: none;
        overflow: hidden;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: var(--abstract-max-lines, 7);
        margin-top: var(--abstract-margin-top, 5px);
    }

    .no-image ::slotted([slot="abstract"]) {
        display: -webkit-box;
        -webkit-line-clamp: var(--abstract-max-lines, 3);
    }

    :host([size="_1x_1y"]) .no-image ::slotted([slot="abstract"]),
    :host([size="_2x_1y"]) .no-image ::slotted([slot="abstract"]) {
        --abstract-max-lines: 1;
    }

    .text {
        grid-area: 1 / 1;
        padding: var(--content-padding) var(--content-padding) 0 var(--content-padding);
        overflow: hidden;
        font-size: ${s.K};
        line-height: ${s.Z};
    }

    :host([size="_1x_1y"]) .text,
    :host([size="_2x_1y"]) .text {
        padding: 0;
    }

    :host([size="_1x_1y"]) .no-image .text,
    :host([size="_2x_1y"]) .no-image .text {
        grid-column: 1 / span 2;
    }

    :host([size="_1x_2y"]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        padding: 14px var(--content-padding) 0 var(--content-padding);
        grid-row: 1;
    }

    :host([size="_2x_2y"]) .text,
    :host([size="_1x_2y"]) .text {
        grid-row: 2;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .text {
        background-color: var(--image-gradient-overlay-end-color);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray,
    :host([size="_1x_2y"]:not([immersive-card])) .action-tray,
    :host .no-image .action-tray {
        background-color: transparent;
    }

    :host([immersive-card]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        background: unset;
    }

    :host([size="_1x_2y"]) .action-tray,
    :host([size="_2x_2y"]) .action-tray {
        grid-row: 3;
        padding: 4px var(--content-padding) var(--action-tray-padding)
            var(--content-padding);
    }

    :host([immersive-card]) .action-tray,
    :host([size="_2x_2y"]) .content:not(.no-image) .action-tray {
        padding: var(--action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
    }

    .action-tray {
        grid-row: 2;
        grid-column: span 2;
        display: flex;
        position: relative;
        background-color: var(--image-gradient-overlay-end-color);
        padding: var(--action-tray-padding) var(--content-padding) var(--content-padding)
            var(--content-padding);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray {
        padding: 0;
    }

    :host([size="_2x_1y"]) .content:not(.no-image) .action-tray {
        grid-area: 2 / 1 / auto / auto;
    }

    :host([size="_1x_1y"]) .no-image .action-tray {
        padding: 4px 0 0 0;
    }

    :host([size="_1x_2y"]) .no-image .action-tray,
    :host([size="_2x_2y"]) .no-image .action-tray {
        padding: var(--no-image-action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
        background: none;
        grid-row: 2;
        grid-column: 1;
    }

    .media-info {
        display: grid;
        grid-auto-flow: column;
        width: fit-content;
        grid-gap: 4px;
        fill: white;
        color: white;
        margin-bottom: 8px;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .media-info {
        grid-row: 1;
        grid-column: 1;
        align-self: flex-end;
        margin-bottom: 6px;
        margin-inline-start: 6px;
    }

    :host([size="_2x_1y"]:not([immersive-card])) .media-info {
        grid-area: 1 / 2 / span2 / auto;
        align-self: flex-end;
        margin-bottom: 8px;
        margin-inline-start: 6px;
    }

    ::slotted([slot="media-info"]) {
        display: grid;
        align-items: center;
        grid-auto-flow: column;
        grid-gap: 3px;
        background-color: var(--image-gradient-overlay-end-color);
        border-radius: calc(${d.Pb} * 1px);
        padding: 2px 6px;
        font-size: ${l.t};
        line-height: ${l.e};
    }

    ::slotted([slot="hide-story"]) {
        box-sizing: border-box;
        align-items: center;
        background-color: #ffffff;
        border-radius: 100%;
        border: 1px solid #e5e5e5;
        color: rgba(0, 0, 0 1);
        cursor: pointer;
        display: flex;
        fill: currentcolor;
        font-family: ${a.O};
        font-size: ${s.K};
        height: 28px;
        justify-content: center;
        line-height: ${s.Z};
        margin-inline-start: 4px;
        min-width: 28px;
        outline: none;
        padding: 0;
        position: relative;
    }

    ::slotted([slot="hide-story"]:hover) {
        background-color: #f2f2f2;
    }

    ::slotted([slot="hide-story"]:active) {
        background-color: #f7f7f7;
    }

    :host .hide-story-wrapper {
        position: absolute;
        display: flex;
        flex-direction: row;
        top: var(--content-padding);
    }

    :host .hide-story {
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.1s linear;
    }

    :host(:hover) .hide-story,
    :host(:focus-within) .hide-story {
        opacity: 1;
    }

    :host ::slotted([slot="hide-story"]:${g.N}) {
        border-color: ${h.WN};
    }

    ::slotted([slot="media"]) {
        grid-column: 1;
        object-fit: cover;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media"]) {
        height: 84px;
        width: 84px;
        grid-row: 1;
        grid-column: 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media"]) {
        height: 114px;
        width: 216px;
        grid-area: 1 / 2 / span2 / 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_1x_2y"]) ::slotted([slot="media"]) {
        grid-row: 1;
        grid-column: 1;
        height: 157px;
        width: 100%;
        display: flex;
    }

    :host([size="_2x_2y"]) ::slotted([slot="media"]),
    :host([immersive-card]) ::slotted([slot="media"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
    }

    ::slotted([slot="attribution"]) {
        display: flex;
        grid-column: 1;
        grid-row: 1;
        margin-bottom: 8px;
    }

    :host([size="_1x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]),
    :host([size="_2x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]) {
        grid-column-end: 1;
    }

    .heading {
        color: ${r.l};
        fill: currentcolor;
        display: -webkit-box;
        outline: 0;
        overflow: hidden;
        text-decoration: none;
        -webkit-line-clamp: var(--heading-max-lines, 3);
        -webkit-box-orient: vertical;
        font-weight: 600;
        font-size: var(--content-card-heading-font-size, ${c.Y});
        line-height: var(--content-card-heading-line-height, ${c.v});
    }

    .heading:focus-visible {
        text-decoration: underline;
    }

    .heading:after {
        bottom: 0;
        content: "";
        height: 100%;
        left: 0;
        position: absolute;
        right: 0;
        width: 100%;
        z-index: ${u.I};
    }

    :host([size="_2x_2y"][immersive-card]) .heading {
        --heading-max-lines: 2;
    }

    .media-overlay {
        position: absolute;
        display: flex;
        align-items: center;
        justify-content: center;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        pointer-events: none;
    }

    :host([size="_1x_1y"]) .media-overlay {
        grid-column: 2;
        grid-row: 1;
        height: 84px;
        width: 84px;
    }

    :host([size="_1x_2y"]) .media-overlay {
        grid-row-start: 1;
        grid-row-end: 1;
    }

    :host([size="_2x_2y"]) .media-overlay,
    :host([immersive-card]) .media-overlay {
        top: 100px;
        align-items: unset;
    }

    :host([size="_1x_2y"]) .no-image .heading,
    :host([size="_2x_2y"]) .no-image .heading {
        --heading-max-lines: 9;
    }

    :host([size="_2x_1y"]) .media-overlay {
        grid-area: 1 / 2 / span2 / 2;
        height: 114px;
        width: 216px;
    }

    ::slotted(p) {
        font-weight: 400;
        font-size: var(--abstract-font-size, 14px);
        line-height: var(--abstract-line-height, 20px);
        font-kerning: auto;
        margin: 8px 0px 0px;
    }

    ::slotted([slot="footer-start"]),
    ::slotted([slot="footer-end"]),
    ::slotted([slot="hide-story"]) {
        z-index: ${u.D};
    }

    .footer-end,
    .footer-start {
        display: flex;
        align-items: center;
    }

    .footer-end {
        margin-inline-start: auto;
    }

    .gradient {
        background: linear-gradient(
            180deg,
            var(--image-gradient-overlay-start-color) 0%,
            var(--image-gradient-overlay-end-color) 100%
        );
        grid-row: 1;
        height: 100%;
        display: none;
    }

    :host([size="_2x_2y"]) .gradient,
    :host([immersive-card]) .gradient {
        display: block;
        height: 80px;
    }

    :host([size="_2x_2y"]) .no-image .gradient,
    .no-image .gradient {
        display: none;
    }

    :host([size="_2x_1y"]) .content {
        column-gap: 24px;
    }
`.withBehaviors(new m.o("mediaType","video",f),new p.t(v.A`
            :host .hide-story-wrapper {
                right: var(--content-padding);
            }
        `,v.A`
            :host .hide-story-wrapper {
                left: var(--content-padding);
            }
        `),(0,y.mr)(v.A`
            :host {
                forced-color-adjust: auto;
            }
            .gradient {
                display: none;
            }
            :host([size="_1x_2y"]) .content,
            :host([size="_1x_1y"]) .content,
            :host([size="_2x_1y"]) .content {
                background: ${b.A.ButtonFace};
            }
            :host([size="_1x_2y"]) .text,
            :host([size="_1x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .text,
            :host([size="_2x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .content,
            :host([immersive-card]) .content {
                background: transparent;
            }
            ::slotted([slot="hide-story"]) {
                color: ${b.A.ButtonText};
                fill: currentcolor;
            }
        `));var w=i(96950),P=i(82774),$=i(416),k=i(10108),S=i(69259),_=i(1413);const C=w.qy`
    <slot name="media" ${(0,P.e)("mediaSlot")}></slot>
`,A=(T={mediaTemplate:C},w.qy`
        <template
            role="article"
            ${(0,$.Y)({property:"childElements",filter:(0,k.Y)()})}
        >
            <div class="content${t=>t.mediaType?"":" no-image"}" part="content">
                ${T.mediaTemplate}
                ${(0,S.z)(t=>t&&(0,_.P)("media-info",t.childElements)&&!(t.immersiveCard||"_2x_2y"===t.size),(0,_.y)({slotName:"media-info"}))}
                <div class="gradient" part="gradient"></div>
                ${(0,_.y)({slotName:"media-overlay",slottedDefault:T.mediaOverlay})}
                <div class="text" part="text">
                    ${(0,S.z)(t=>t&&(0,_.P)("media-info",t.childElements)&&(t.immersiveCard||"_2x_2y"===t.size),(0,_.y)({slotName:"media-info"}))}
                    <slot name="attribution"></slot>
                    <a
                        id="heading"
                        class="heading"
                        part="heading"
                        href="${t=>t.href?t.href:void 0}"
                        target="${t=>t.target?t.target:void 0}"
                        @click=${(t,e)=>t.handleContentCardLinkClick(e.event)}
                        data-t="${t=>t.anchorTelemetryTag}"
                    >
                        <span role="heading" aria-level="${t=>t.headingLevel}">
                            <slot></slot>
                        </span>
                    </a>
                    ${(0,_.y)({slotName:"abstract"})}
                </div>
                <div
                    class="action-tray ${t=>t.loaded?"":"preload"}"
                    part="action-tray"
                >
                    ${(0,_.y)({slotName:"footer-start",slottedDefault:T.footerStart})}
                    ${(0,_.y)({slotName:"footer-end",slottedDefault:T.footerEnd})}
                </div>
                <div class="hide-story-wrapper" part="hide-story-wrapper">
                    ${(0,_.y)({slotName:"hide-story",slottedDefault:T.hideStory})}
                </div>
            </div>
        </template>
    `);var T;const I=n.W.compose({name:`${o.G.prefix}-content-card`,styles:x,template:A})},80790(t,e,i){i.d(e,{HuYaPlayer(){return h}});var o=i(2171),n=i(93552),a=i(22341),r=i(17852),s=i(70775),d=i(11206),l=i(93940);class h extends d.a{constructor(){super(...arguments),this.playerReadyFlag=!1,this.type="Huya",this.loadPlayerScripts=t=>(h.loadPromise||(h.loadPromise=(0,r.k)({id:h.scriptId,src:h.scriptSrc,retryNumber:t?5:0,retryDelayMs:t?200:0})),h.loadPromise),this.createEvents=t=>({onReady:e=>{l.M.set(this.instance,e.data.duration),0==this.playerReadyFlag&&(t(),this.perfObserver.mark("ready"),this.perfObserver.mark("loaded"),window.setTimeout(()=>this.triggerEvent("ready",this.normalizeEvent()))),this.playerReadyFlag=!0},onStateChange:this.onStateChange,onTimeUpdateEvent:this.onTimeUpdateEvent,onError:t=>{var e;const i={...t.data??{},innerId:null===(e=this.playerInfo.video)||void 0===e?void 0:e.id},o=JSON.stringify(i);(0,a.vV)(n.g_C,o,"An error occurred during playing a HuYa video.")},onVolumeChange:this.onVolumeChange}),this.triggerAdStart=()=>{this.triggerEvent("AdPlayStarted",this.normalizeEvent())},this.triggerAdFinish=()=>{this.triggerEvent("AdPlayCompleted",this.normalizeEvent())},this.triggerAdSkipped=()=>{this.triggerEvent("AdPlaySkipped",this.normalizeEvent())},this.triggerAdSlotEnded=t=>{this.triggerEvent("AdSlotEnded",this.normalizeEvent(void 0,t))},this.setIsAdsPlying=t=>{this._isAdsPlying=t},this.onTimeUpdateEvent=()=>{this.triggerEvent("timeupdate",this.normalizeEvent())},this.onStateChange=t=>{const e=t.data,{Ended:i,Playing:o,Paused:n}=window.HYPlayerAPI.PlayerState,a=this.normalizeEvent();switch(e){case i:this.instance.pauseVideo(),this.triggerEvent("ended",a);break;case o:{const t=this.wasPaused?"resume":"play";this.wasPaused=!1,this.triggerEvent(t,a);break}case n:this.wasPaused=!0,this.triggerEvent("pause",a)}},this.onVolumeChange=t=>{this.triggerEvent("volumechange",this.normalizeEvent(t))},this.normalizeEvent=(t,e)=>{const i=this.createContentEvent(),{content:o}=i;return{...i,...e??{},isPlayerPaused:this.instance.getPlayerState()===window.HYPlayerAPI.PlayerState.Paused,content:{...o,videoPositionSec:this.instance.getCurrentTime()??0,title:this.instance.videoTitle??o.title,videoDuration:l.M.get(this.instance)??o.videoDuration},originEvent:t}}}static get loadPromise(){return o.vv.get(this.loadPromiseKey)}static set loadPromise(t){o.vv.set(this.loadPromiseKey,t)}static get scriptSrc(){return o.vv.get(this.scriptSrcKey,()=>`https://msn.huya.com/sdk/hyPlayerAPI.js?t=${Date.now()}`)}static set scriptSrc(t){o.vv.set(this.scriptSrcKey,t)}static get scriptId(){return o.vv.get(this.scriptIdKey,()=>"HuYaVideoPlayerSDK")}static set scriptId(t){o.vv.set(this.scriptIdKey,t)}async initialize(t){const{container:e,playerInfo:i}=t,o=e.clientHeight,r=e.clientWidth;try{await this.loadPlayerScripts(t.shouldUseRetryWithDelay)}catch(t){(0,a.vV)(n.g_C,JSON.stringify(t),"An error occurred during loading HuYa sdk.")}if(window.HYPlayerAPI)return new Promise(t=>{var n;const a=new window.HYPlayerAPI(e,{height:String(o),width:String(r),events:this.createEvents(t)});a[Symbol("identifier")]=null===(n=i.video)||void 0===n?void 0:n.id,super.init(a,e,i)})}play(){super.play(),this.instance.playVideo()}pause(){super.pause(),this.instance.pauseVideo()}setMute(t){t?this.instance.muteVideo():this.instance.unmuteVideo()}setVolume(t){const e=this.normalizeVolume(t);this.instance.setVolume(e)}seekBySeconds(t){throw new Error(`seekBySeconds is not implemented for this player, cannot seek ${t} seconds`)}get isMuted(){return this.instance.isMuted()}get volume(){const t=this.instance.getVolume();return this.normalizeVolume(t)}get canProvideVideoPosition(){return!0}get shouldEmulateTimeUpdate(){return!0}createTimeUpdateEventData(){return this.normalizeEvent()}dispose(){this.instance.destroy(),super.dispose()}}h.loadPromiseKey=Symbol("loadPromise"),h.scriptSrcKey=Symbol("scriptSrc"),h.scriptIdKey=Symbol("scriptId"),h.buildIframeSrc=(t,e)=>{const i=new URL(t);i.searchParams.set("muted","1"),e||i.searchParams.set("needStop","1");const o=s._3.getQueryParameterByName("yamid",window.location.href);return o&&i.searchParams.set("mid",o),i.href}},81583(t,e,i){i.d(e,{CW(){return u},FA(){return c},Kc(){return p}});var o=i(58792),n=i(27233),a=i(42161),r=i(27659);const s={"yidianzixun.com":{link:"msn.yidianzixun.com",providerId:"AA1JHler"},"doris.yidianzixun.com":{link:"msn.yidianzixun.com",providerId:"AA1JHler"},"msn.huya.com":{link:"msn.huya.com",providerId:"AA1KuixS"},"micvideo.peopletech.cn":{link:"msn.micsoserver.cn",providerId:"AA1MDLlM"}};function d(){return o.T3.CurrentMarket===n.DX.PLPL?"wideo":"video"}function l(t){return encodeURI(t.trim().toLowerCase().replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\u00A9|\u00AE]\u3030|\u00A9|\u00AE|\u3030/gi,"").slice(0,600).replace(/[\][!"#$%&'()*+,./:;<=>?@\\^_{|}~]/g,"").replace(/\s+/g,"-").replace(/-+$/,""))||"title"}function h(t){const e=new URL(t),i=(0,a.En)();return i&&e.searchParams.set("ocid",i),e.href}function c(t,e){const i=o.T3.HostPage.verticalKey||"watch",n=d();return h(`${o.T3.NavTargetUrlWithLocale}/${n}/${i}/${l(e)}/vi-${t}`)}function u(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"web-content",a=arguments.length>3&&void 0!==arguments[3]?arguments[3]:"webcontent",c=arguments.length>4?arguments[4]:void 0;try{if(o.T3.CurrentMarket==n.DX.ZHCN)return function(t,e,i,o){try{const a=new URL(e);a.searchParams.delete("ocid");const r=s[a.hostname];if(r){const e=new URL(`https://${r.link}/${n.DX.ZHCN}/video/${i}/web-content/vi-${t}`),a=new URLSearchParams(window.location.search);return a.set("providerId",o||r.providerId),e.search=`?vid=vi-${t}&${a.toString()}`,h(e.href)}return h(a.href)}catch(t){return r.v.logError(`WatchUrlUtility: GetWatchDeeplinkForWebContentZHCN: Failed to compose web video url: ${e}`),e}}(t,e,a,c);const u=new URL(e);u.searchParams.delete("ocid");const p=d(),v=new URL(`${o.T3.NavTargetUrlWithLocale}/${p}/${a}/${l(i)}/vi-${t}`);if("www.youtube.com"==u.hostname)return v.searchParams.set("vid",u.searchParams.get("v")||""),v.searchParams.set("provider","yt"),h(v.href);if("www.facebook.com"==u.hostname){const t=e.match(/^http(?:s?):\/\/(?:www\.|web\.|m\.)?facebook\.com\/([A-z0-9.]+)\/videos(?:\/[0-9A-z].+)?\/(\d+)(?:.+)?$/);return v.searchParams.set("vid",t&&t[2]||""),v.searchParams.set("provider","fb"),h(v.href)}return h(u.href)}catch(t){return e}}function p(t){return decodeURIComponent(t)!==t?t:encodeURIComponent(t)}},83127(t,e,i){i.d(e,{al(){return h},XN(){return d},No(){return l}});var o=i(85198),n=i(95535);function a(t,e){if(function(t){try{return(null==t?void 0:t.needHeader)??!1}catch(t){s(`Failed to get feed needHeader Failed with exception : ${t}`)}}(t))try{const t=JSON.parse(e),i=JSON.parse((null==t?void 0:t.header)??null),o=(null==i?void 0:i["ddd-activityid"])??null;o&&async function(t){const e=window.localStorage.getItem(r);if(void 0!==e&&""!==e&&null!==e){const i=e.split(",");return void(i.length<10&&!i.includes(t)&&window.localStorage.setItem(r,`${e},${t}`))}window.localStorage.setItem(r,t)}(o)}catch(t){s(`Failed to get feed needHeader Failed with exception : ${t}`)}}const r="activityIds";function s(t){(0,o.RH)()&&function(t){new Promise((e,i)=>{!function(t,e){(0,o.lA)("logEvent",t,e)}(t,t=>{e(t)})})}({appId:n.H7,type:"Debug",name:"HP_WEBVIEW_SERVER_LOG",data:{message:t}})}function d(t){return new Promise((e,i)=>{!function(t,e){(0,o.lA)("getHttp",t,e)}(t,i=>{e(i),a(t,i)})})}function l(t){return new Promise((e,i)=>{!function(t,e){(0,o.lA)("postHttp",t,e)}(t,t=>{e(t)})})}function h(t){return new Promise((e,i)=>{!function(t,e){(0,o.lA)("deleteHttp",t,e)}(t,t=>{e(t)})})}},87993(t,e,i){i.d(e,{S(){return o},m(){return l}});var o,n=i(56911),a=i(60815),r=i(92011),s=i(38493),d=i(94407);!function(t){t.default="default",t.condensed="condensed",t.infoPane="infoPane",t.infoPane1x3y="infoPane1x3y",t.infoPaneSplitVertical="infoPaneSplitVertical",t.infoPaneSplitHorizontal="infoPaneSplitHorizontal"}(o||(o={}));class l extends r.L{constructor(){super(...arguments),this.layout=o.default,this.headinglevel=3}handleStartActionsContentChange(){this.startActionsContainer.classList.toggle("start-actions",this.startActions.assignedNodes().length>0)}handleEndActionsContentChange(){this.endActionsContainer.classList.toggle("end-actions",this.endActions.assignedNodes().length>0)}abstractChanged(){this.$fastController.isConnected&&(this.hasAbstract=this.abstract.length>0)}handleMediaContentChange(){this.mediaContainer.classList.toggle("media",this.media.assignedNodes().length>0)}handleContentCardLinkClick(t){return this.handleContentCardClickOverride?this.handleContentCardClickOverride(t):(this.$emit("link-invoked",t),!0)}connectedCallback(){super.connectedCallback(),this.addEventListener("mouseover",this.mouseOver),this.addEventListener("mouseout",this.mouseOut),this.addEventListener("focusin",this.focusIn),this.addEventListener("focusout",this.focusOut)}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("mouseover",this.mouseOver),this.removeEventListener("mouseout",this.mouseOut),this.removeEventListener("focusin",this.focusIn),this.removeEventListener("focusout",this.focusOut)}mouseOver(){this.setExpanded(!0),this.hasHover=!0}mouseOut(){this.hasFocus||this.setExpanded(!1),this.hasHover=!1}focusIn(){this.setExpanded(!0),this.hasFocus=!0}focusOut(){this.hasHover||this.setExpanded(!1),this.hasFocus=!1}filteredContentIndicator(){return this.contentIndicatorNodes.filter(t=>t instanceof d.L)}setExpanded(t){this.filteredContentIndicator().forEach(e=>e.expanded=t)}}(0,n.Cg)([s.CF],l.prototype,"layout",void 0),(0,n.Cg)([(0,s.CF)({attribute:"heading-level",mode:"fromView",converter:s.R$})],l.prototype,"headinglevel",void 0),(0,n.Cg)([(0,s.CF)({mode:"fromView"})],l.prototype,"href",void 0),(0,n.Cg)([a.sH],l.prototype,"isGrid",void 0),(0,n.Cg)([a.sH],l.prototype,"anchorTelemetryTag",void 0),(0,n.Cg)([a.sH],l.prototype,"mediaNodes",void 0),(0,n.Cg)([a.sH],l.prototype,"hasAbstract",void 0),(0,n.Cg)([a.sH],l.prototype,"abstract",void 0),(0,n.Cg)([a.sH],l.prototype,"iconSlottedNodes",void 0),(0,n.Cg)([(0,s.CF)({attribute:"image-priority",mode:"boolean"})],l.prototype,"imagePriority",void 0),(0,n.Cg)([s.CF],l.prototype,"target",void 0),(0,n.Cg)([a.sH],l.prototype,"hoverActionsSlottedNodes",void 0),(0,n.Cg)([a.sH],l.prototype,"handleContentCardClickOverride",void 0),(0,n.Cg)([a.sH],l.prototype,"contentIndicatorNodes",void 0)},92687(t,e,i){i.d(e,{m(){return n}});var o=i(92011);class n extends o.L{handleImageContentChange(){this.imageContainer.classList.toggle("image",this.image.assignedNodes().length>0)}}},93518(t,e,i){i.d(e,{X(){return p}});var o=i(56911),n=i(97004),a=i(64183),r=i(95239),s=i(356),d=i(31023),l=i(37302),h=i(96193),c=i(38493),u=i(50866);class p extends h.z{constructor(){super(...arguments),this.size=u.qJ._1x_2y}cardFillColorChanged(t,e){this.isDarkCardGradient()?s.l.setValueFor(this,n.y.DarkMode):this.isLightCardGradient()?s.l.setValueFor(this,n.y.LightMode):s.l.deleteValueFor(this)}isDarkCardGradient(){return Object.values(u.NZ).includes(this.cardFillColor)}isLightCardGradient(){return Object.values(u.L9).includes(this.cardFillColor)}isNamedGradientFillColor(){return this.isLightCardGradient()||this.isDarkCardGradient()}connectedCallback(){super.connectedCallback(),l.jO.setValueFor(this,{evaluate(t,e){return(0,a.o)(t(d.r),e||t(r.p),-1,1,0,0,void 0,2,3,1,2,void 0)}})}}(0,o.Cg)([(0,c.CF)({attribute:"card-fill-color"}),(0,o.Sn)("design:type",Object)],p.prototype,"cardFillColor",void 0),(0,o.Cg)([c.CF,(0,o.Sn)("design:type",String)],p.prototype,"size",void 0)},93940(t,e,i){i.d(e,{M(){return a}});var o=i(18272);class n{constructor(){this.map={}}getInstanceId(t){const e=Object.getOwnPropertySymbols(t).find(t=>"Symbol(identifier)"===t.toString());if(e)return t[e]}get(t){const e=this.getInstanceId(t);return e&&this.map[e]}set(t,e){const i=this.getInstanceId(t);i&&!this.map[i]&&(this.map[i]=e)}}const a=(0,o.G)({getInstance(){return new n}})},94407(t,e,i){i.d(e,{L(){return s}});var o=i(56911),n=i(60815),a=i(92011),r=i(38493);class s extends a.L{constructor(){super(...arguments),this.expanded=!1}defaultItemsChanged(){this.$fastController.isConnected&&(this.shouldanimate=this.defaultItems.length>0)}}(0,o.Cg)([(0,r.CF)({mode:"boolean"})],s.prototype,"expanded",void 0),(0,o.Cg)([n.sH],s.prototype,"defaultItems",void 0),(0,o.Cg)([(0,r.CF)({mode:"boolean",attribute:"animate"})],s.prototype,"shouldanimate",void 0)},96193(t,e,i){i.d(e,{z(){return n}});var o=i(92011);class n extends o.L{}},97015(t,e,i){i.d(e,{_Z(){return d},we(){return a},x3(){return s},z7(){return r}});var o=i(6205),n=i(65114);function a(t){const e="An unknown error";if("string"==typeof t)return{value:t};if(!t||"object"!=typeof t)return{value:e};if(!function(t){return Boolean(t&&"object"==typeof t&&"code"in t&&"message"in t)}(t))return{value:e,message:(0,o.M5)(t)};const{value:i,...n}=t;return"object"==typeof i?{value:(0,o.M5)(i),...n}:{value:"string"==typeof i?i:n.message,...n}}const r=(t,e,i)=>{let o=t+i;return o<0?o=0:o>e&&(o=e),o};function s(t){if(!t)return"";const e=new URL(t);return e.searchParams.set("_t",Date.now().toString()),e.searchParams.has("start")||e.searchParams.set("start","0"),e.searchParams.has("end")||e.searchParams.set("end","15"),e.href}function d(t){return t&&Object.values(n.yB).includes(new URL(t).origin)}},97686(t,e,i){i.d(e,{f(){return a}});var o=i(4007),n=i(3180);function a(){let t=!1;const e=(0,o.MI)(),{geo_country:i,geo_subdivision:a}=e,r=(null==i?void 0:i.toUpperCase())??"",s=(null==a?void 0:a.toUpperCase())??"";return r&&n.XD.includes(r)&&("CA"===r&&"QUEBEC"!==s||(t=!0)),t}},99657(t,e,i){i.d(e,{D(){return r},I(){return a}});var o=i(45755);const{create:n}=o.G,a=n("sloppy-click-z-index",1),r=n("click-z-index",1)}}]);