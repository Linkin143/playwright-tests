"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["shopping-buying-guides-card"],{88305(t,i,e){e.r(i),e.d(i,{BuyingGuidesSdCardVariant(){return r},ShoppingBuyingGuidesCard(){return E},ShoppingBuyingGuidesCardStyles(){return rt},ShoppingBuyingGuidesCardTemplate(){return Y},ToolingInfo(){return at}});var r,a=e(7574),o=e(56911),s=e(38493),n=e(60815),d=e(12680);!function(t){t.FULLBLEAD_WHITE="FULLBLEAD_WHITE"}(r||(r={}));var l=e(39671),p=e(22341);const h=async()=>{const t=await fetch("https://start-shopping-zero-code-cms.azureedge.net/zerocode/BuyingGuidesAndListicles/en-us/ShoppingBuyingGuidesListiclesCarousel.json");return{subCards:await t.json()}};var c=e(29853),u=e(89167),g=e(77367);class v extends u.X9{static buildAbsoluteUrl(t,i,e){const r=(0,u.wW)(new URLSearchParams([["catid",t],["catname",i]]),!0);return`${this.getSchemeAndDomain()}/${e}/shopping/buying-guide?${r}`}static buildAbsoluteUrlBing(t,i,e){const r=(0,u.wW)(new URLSearchParams([["catid",t],["catname",i]]),!0);return`${null==e?void 0:e.host}/${null==e?void 0:e.path}?${r}&${(null==e?void 0:e.msnrid)+g.YT.getRequestId()}&${null==e?void 0:e.adunitId}&${null==e?void 0:e.propertyId}&${null==e?void 0:e.FORM}`}static buildLandingPageUrl(t){return`${this.getSchemeAndDomain()}/${t}/shopping/buying-guide`}}var x=e(58792),f=e(85349),y=e(19359);const m="right-chevron",b="left-chevron",$="shopping",w="buying-guides",L="card";var C=e(93552);class E extends l.U{constructor(){super(...arguments),this.sdcardVariant=r.FULLBLEAD_WHITE,this.currentPageNumber=0,this.firstCardImageLoaded=!1,this.extractFeedData=()=>{if(this.mapperArgs){const{cardMetadata:t}=this.mapperArgs;if(this.CardMetadata=t,!this.CardMetadata)throw new Error("MapperArgs passed undefined Card Data")}},this.handleCardVisuallyReady=()=>{this.firstCardImageLoaded=!0}}async experienceConnected(){if(await this.getData(),this.CardMetadata)try{this.buyingGuidesData=this.CardMetadata,this.telemetryContext=(t=>{if(!t)return;return{componentRoot:t,previousFlipper:(0,y.l)(`${b}`,{id:`${b}`,vertical:$,category:w},f.MS.Show,f.EG.Click,f.MJ.Interaction),nextFlipper:(0,y.l)(`${m}`,{id:`${m}`,vertical:$,category:w},f.MS.Show,f.EG.Click,f.MJ.Interaction)}})(this.telemetryObject),this.transformData(),this.mapUIProperties()}catch(t){(0,p.c_)(t,C.Jh_,"Error in Shopping Buying Guides SD Card experience rendering")}}async getData(){try{this.config.mData?this.CardMetadata=this.config.mData:this.config.fetchDataExplicitely?this.CardMetadata=await(async t=>{const{operation:i,maxAttempts:e,retryAppError:r,retryErrorMessage:a}=t;for(let t=1;t<=e;t++)try{return await i()}catch(i){if(t>=e)throw i;(0,p.c_)(i,r,a)}throw new Error("Max retry attempts reached")})({operation:h,maxAttempts:2,retryAppError:C.xD6,retryErrorMessage:"Retry attempt failed to fetch Shopping Buying Guides SD Card experience data. Will retry"}):this.extractFeedData()}catch(t){(0,p.c_)(t,C.l$m,"Error in Shopping Buying Guides SD Card experience data fetching"),this.CardMetadata=void 0}}transformData(){var t;this.shoppingEntities=null===(t=this.buyingGuidesData)||void 0===t||null===(t=t.subCards)||void 0===t||null===(t=t.sort(()=>.5-Math.random()))||void 0===t?void 0:t.map(t=>{const i=(0,c.Cb)(t);let e=v.buildAbsoluteUrlBing(t.Id,t.UrlRefText??t.Title,this.config.urlHostAndPath);if(this.config.ocid){const t=new URL(e);t.searchParams.set("ocid",this.config.ocid),e=t.href}const r=(0,x.rA)().StaticsUrl+"/latest/shopping/discountTag.svg";return{...i,imageInfo:{sourceImageUrl:null==t?void 0:t.SourceImageUrl},clickUrl:e,telemetryTag:this.telemetryContext?(a=this.telemetryContext,o=f.MS.Navigate,s=t.Id,a&&a.componentRoot?(0,y.l)(`${L}`,{id:s,vertical:$,category:w},o,f.EG.Click).getMetadataTag():""):void 0,seller:"Microsoft Shopping",sellerImageUrl:r};var a,o,s})}mapUIProperties(){var t;(null===(t=this.shoppingEntities)||void 0===t?void 0:t.length)>0&&(this.displayedBuyingGuideEntity=this.shoppingEntities[this.currentPageNumber]),this.sdcardVariant=this.config.sdcardVariant||r.FULLBLEAD_WHITE,this.superCardData=this.mapDataForSuperCard()}mapDataForSuperCard(){if(this.sdcardVariant===r.FULLBLEAD_WHITE)return{id:"shopping-buying-guides-card",gridArea:"",childTemplateType:"",cardSize:"_1x_2y",headerData:void 0,footerData:{footerLink:void 0,paginationData:{currentPageIndex:(t=this).currentPageNumber+1,onFlipperClick(i,e){i?t.changePage(1):t.changePage(-1)},onDotClick(i,e){t.onDotClick(i)},pageCount:(null===(i=t.shoppingEntities)||void 0===i?void 0:i.length)||0},telemetryContext:t.telemetryContext}};var t,i}getExperienceType(){return d.D19}changePage(t){const i=void 0!==this.shoppingEntities?this.shoppingEntities.length:1;this.currentPageNumber=(this.currentPageNumber+t)%i,this.currentPageNumber<0&&(this.currentPageNumber=(i+this.currentPageNumber)%i),this.superCardData&&this.refreshFooterData()}refreshFooterData(){var t;null!==(t=this.superCardData)&&void 0!==t&&null!==(t=t.footerData)&&void 0!==t&&t.paginationData&&(this.superCardData={...this.superCardData,footerData:{...this.superCardData.footerData,paginationData:{...this.superCardData.footerData.paginationData,currentPageIndex:this.currentPageNumber+1}}})}onDotClick(t){void 0!==t&&(this.currentPageNumber=t,this.superCardData&&this.refreshFooterData())}superCardDataChanged(t,i){var e;i&&(this.displayedBuyingGuideEntity=null===(e=this.shoppingEntities)||void 0===e?void 0:e[this.currentPageNumber])}firstCardImageLoadedChanged(t,i){i&&this.markVisuallyReadyRaf()}}(0,o.Cg)([(0,s.CF)({attribute:"sd-card-variant"})],E.prototype,"sdcardVariant",void 0),(0,o.Cg)([n.sH],E.prototype,"buyingGuidesData",void 0),(0,o.Cg)([n.sH],E.prototype,"superCardData",void 0),(0,o.Cg)([n.sH],E.prototype,"shoppingEntities",void 0),(0,o.Cg)([n.sH],E.prototype,"firstCardImageLoaded",void 0),(0,o.Cg)([n.sH],E.prototype,"displayedBuyingGuideEntity",void 0);var D=e(96950),S=e(69259),T=e(39957),U=e(92011),B=e(23528);class I extends B.E{}var A=e(60402),k=e(85218),F=e(94288),G=e(88988);const z=D.qy`<div class="product-image-container"><img class="product-image" src="${t=>{var i;return null===(i=t.shoppingEntity)||void 0===i?void 0:i.imageInfo.sourceImageUrl}}" alt="${t=>{var i;return null===(i=t.shoppingEntity)||void 0===i?void 0:i.title}}" srcset="${t=>{var i,e;return(0,F.Je)(null===(i=t.shoppingEntity)||void 0===i?void 0:i.imageInfo.sourceImageUrl,null===(e=t.shoppingProductCarouselVariant)||void 0===e?void 0:e.imageHeight)}}" ${(0,A.K)("imageElement")} @load=${(t,i)=>t.handleImageLoad(i.event)} @error=${(t,i)=>t.handleImageLoad(i.event)} /></div>`,_=D.qy`<div class="shopping-product-card">${z} ${k.aG}</div>`,M=D.qy`<a class="anchor-wrapper" tabindex="0" href="${t=>{var i;return null===(i=t.shoppingEntity)||void 0===i?void 0:i.clickUrl}}" rel="${t=>{var i;return null!==(i=t.shoppingEntity)&&void 0!==i&&i.clickUrl?(0,G.yE)(t.shoppingEntity.clickUrl):""}}" aria-hidden="true" target="_blank" title="${t=>{var i;return null===(i=t.shoppingEntity)||void 0===i?void 0:i.title}}" @mousedown=${(t,i)=>t.handleMousedown(i.event)} @click=${(t,i)=>t.handleClick(i.event)} @keydown=${(t,i)=>t.keydownHandler(i.event)} @mouseenter="${t=>t.handleHydratedContainerMouseEnter()}" @mouseleave="${t=>t.handleHydratedContainerMouseLeave()}" data-t="${t=>{var i;return null===(i=t.shoppingEntity)||void 0===i?void 0:i.telemetryTag}}">${_}</a>`,P=D.qy`
${(0,S.z)(t=>t.shoppingEntity,M)}
${(0,S.z)(t=>!t.shoppingEntity,k.w1)}
`;var W=e(74849),H=e(82492);const R=W.A`
    ${H.YI}
    .product-image-container{
        height: 208px;
        width: 306px;
        border-radius: 0px;
    }
    .product-image{
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.7s ease-out 0s;
        pointer-events: none;
    }
    .anchor-wrapper:hover .product-image{
        transform: scale(1.05);
    }   
`,j=W.A`
    .title{
        color: #242424;
        font-size: 14px;
        line-height: 18px;
        font-weight:600;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        white-space: normal;
        text-overflow: ellipsis;
        overflow: hidden;
    }
    .anchor-wrapper:hover .title{
        text-decoration: underline;
    }    
`,V=W.A` .seller{display:flex;gap:8px;color:var(--neutral-foreground-hint);font-size:var(--type-ramp-minus-1-font-size);font-weight:400;line-height:var(--type-ramp-minus-1-line-height)}`,O=W.A`
:host{
    display: block;
    border-radius: 16px;
    background: rgba(255, 255, 255, 0.50);
    box-shadow: 0px 2px 8px 0px rgba(0, 0, 0, 0.04), 0px 0px 0px 1px rgba(0, 0, 0, 0.05);
}
.anchor-wrapper{
    text-decoration: none;
}
.shopping-product-card{
    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    box-sizing: border-box;
    gap: 8px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
}
.product-info{
    padding: 0 8px 0 8px;
    box-sizing: border-box;
    gap: 5px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 60px;
}
${R}
${j}
${V}
`;let q=class extends I{};q=(0,o.Cg)([(0,U.E)({name:"msn-shopping-buying-guide-card-light",template:P,styles:O,shadowOptions:{delegatesFocus:!0}})],q);var J=e(89989),K=e(32623);const N={attributes:[{attributeType:K.x.Title,attributeTemplate:J.BK},{attributeType:K.x.Seller,attributeTemplate:J.wj}],iconTemplateMap:void 0,imageHeight:208,imageWidth:268},Q=[{name:"title",type:2,height:20,lines:1},{name:"seller"}],X=D.qy`<msn-shopping-buying-guide-card-light :shoppingEntity="${t=>t}" :displayAttributes=${(t,i)=>Q} :shoppingProductCarouselVariant="${(t,i)=>N}" :onCardVisuallyReady="${(t,i)=>i.parent.handleCardVisuallyReady}"><img src=${t=>t.sellerImageUrl} slot="sellerImageUrl" class="sellerImageUrl"/></msn-shopping-buying-guide-card-light>`,Y=D.qy`<responsive-sd-card :data="${t=>t.superCardData}"><div slot="card-content" class="content">${(0,S.z)(t=>t.displayedBuyingGuideEntity,D.qy` ${(0,T.ux)(t=>[t.displayedBuyingGuideEntity],t=>t.sdcardVariant===r.FULLBLEAD_WHITE?X:D.qy`<div></div>`,{positioning:!0})} `)}</div></responsive-sd-card>`,Z=W.A` :host([sd-card-variant="FULLBLEAD_WHITE"]) responsive-sd-card{--sd-card-header-color:rgb(38,38,38);--sd-card-footer-pagination-color:#fafafa;--sd-card-pagination-dot-color:rgb(0 0 0 / 0.45);--sd-card-pagination-dot-color-hover:rgb(0 0 0 / 0.6063);--sd-card-chevron-svg-fill:#262626;--sd-card-chevron-background-hover:#f5f5f5;--sd-card-chevron-background-active:#f7f7f7}:host([sd-card-variant="FULLBLEAD_WHITE"]) responsive-sd-card:hover{box-shadow:0 0 0 1px rgba(0,0,0,0.0578),0px 4px 8px rgba(0,0,0,0.14)}`,tt=W.A` :host([sd-card-variant="FULLBLEAD_WHITE"]) responsive-sd-card{height:300px;width:306px}:host([sd-card-variant="FULLBLEAD_WHITE"]) msn-shopping-buying-guide-card-light{width:100%;height:100%;box-shadow:none}:host([sd-card-variant="FULLBLEAD_WHITE"]) .content{width:306px;position:relative;left:-16px}`;var it=e(12640);const et=W.A`
    ${Z}
`,rt=W.A`
    ${tt}
`.withBehaviors(new it.N(null,et));(0,a.o)();const at={experienceConfigSchema:undefined}}}]);