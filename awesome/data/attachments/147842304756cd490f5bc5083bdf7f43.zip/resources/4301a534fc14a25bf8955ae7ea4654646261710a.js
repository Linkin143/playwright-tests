"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_me-stripe-wc_dist_index_js"],{12717(e,t,i){i.d(t,{m(){return z}});var r=i(84506),o=i(37180),n=i(74849),s=i(64187),l=i(60993),a=i(73477),p=i(22131),d=i(50882),c=i(48196),h=i(48751),m=i(45476),u=i(26920),f=i(36452),g=i(79288),v=i(14996);const b=n.A`
    ${(0,s.V)("inline-flex")} :host {
        width: calc(${c.D} * 1px);
        height: calc(${c.D} * 1px);
        justify-content: center;
        align-items: center;
        margin: 0;
        position: relative;
        fill: currentcolor;
        color: ${h.l};
        background: transparent;
        border: none;
        outline: none;
        padding: 0;
    }

    :host::before {
        content: "";
        opacity: 0.8;
        background: ${m.Wl};
        border: calc(${u.XA} * 1px) solid ${f.I2};
        border-radius: 50%;
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        bottom: 0;
        transition: all 0.1s ease-in-out;
    }

    .next,
    .previous {
        position: relative;
        ${""} width: 16px;
        height: 16px;
    }

    :host([disabled]) {
        opacity: ${g.q};
        cursor: ${l.Z};
    }

    :host(:hover) {
        cursor: pointer;
    }

    :host(:hover)::before {
        background: ${m.oO};
        border-color: ${f.mb};
    }

    :host(:${a.N}) {
        outline: none;
    }

    :host(:${a.N})::before {
        box-shadow: 0 0 0 1px ${v.WN} inset;
        border-color: ${v.WN};
    }

    :host(:active)::before {
        background: ${m.wO};
        border-color: ${f.MY};
    }

    :host::-moz-focus-inner {
        border: 0;
    }
`.withBehaviors((0,p.mr)(n.A`
            :host {
                background: ${d.A.Canvas};
            }
            :host .next,
            :host .previous {
                color: ${d.A.ButtonText};
                fill: currentcolor;
            }
            :host::before {
                background: ${d.A.Canvas};
                border-color: ${d.A.ButtonText};
            }
            :host(:hover)::before {
                forced-color-adjust: none;
                background: ${d.A.Highlight};
                border-color: ${d.A.ButtonText};
                opacity: 1;
            }
            :host(:hover) .next,
            :host(:hover) .previous {
                forced-color-adjust: none;
                color: ${d.A.HighlightText};
                fill: currentcolor;
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled])::before,
            :host([disabled]:hover)::before,
            :host([disabled]) .next,
            :host([disabled]) .previous,
            :host([disabled]:hover) .next,
            :host([disabled]:hover) .previous {
                forced-color-adjust: none;
                background: ${d.A.Canvas};
                border-color: ${d.A.GrayText};
                color: ${d.A.GrayText};
                fill: ${d.A.GrayText};
            }
            :host(:${a.N})::before {
                forced-color-adjust: none;
                border-color: ${d.A.Highlight};
                box-shadow: 0 0 0 2px ${d.A.Field},
                    0 0 0 4px ${d.A.FieldText};
            }
        `));var x=i(60143),w=i(96950);const $=(0,x.B)({next:w.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M4.023 15.273L11.29 8 4.023.727l.704-.704L12.71 8l-7.984 7.977-.704-.704z"
            />
        </svg>
    `,previous:w.qy`
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg">
            <path
                d="M11.273 15.977L3.29 8 11.273.023l.704.704L4.71 8l7.266 7.273-.704.704z"
            />
        </svg>
    `});class y extends r.d{}const z=y.compose({name:`${o.c.prefix}-flipper`,template:$,styles:b})},19256(e,t,i){i.d(t,{Lm(){return o},Yd(){return n}});var r=i(75307);function o(){let e=arguments.length>0&&void 0!==arguments[0]&&arguments[0];return function(){const e=new Date,t=e.getUTCDay(),i=e.getUTCHours();return!(1==t&&i>=18||5==t&&i<22||t>=2&&t<=4)||(0,r.kg)()}()||e?30:20}function n(e){return e.toString()+"%"}},60143(e,t,i){i.d(t,{B(){return n}});var r=i(96950),o=i(18893);function n(e={}){const t={};return r.qy`
        <template
            role="button"
            aria-disabled="${e=>!!e.disabled||void 0}"
            tabindex="${e=>e.hiddenFromAT?-1:0}"
            @keyup="${(e,t)=>e.keyupHandler(t.event)}"
        >
            ${i=>function(e,i){let n=t[e];return n||(t[e]=n=r.qy`
                <span part="${e}" class="${e}">
                    <slot name="${e}">
                        ${(0,o.R)(i[e])}
                    </slot>
                </span>
            `),n}(i.direction,e)}
        </template>
    `}},75307(e,t,i){i.d(t,{Bl(){return h},Eo(){return p},KN(){return a},LG(){return d},Mj(){return m},kg(){return l},x8(){return c}});var r=i(58792),o=i(99476),n=i(26363),s=i(77367);function l(){const e=(0,o.a)();return!!e&&("1"===e.get("vptest")||"true"===e.get("vptest")||"vp"===e.get("reqsrc"))}function a(e,t){return p(e,t,"shopping/product-tracking")}function p(e,t,i){if("local"===t&&window.location.origin.indexOf("localhost")>-1)return`http://127.0.0.1:3000/shopping/${e}.svg`;if(e){const o=t?`pr-${t}`:"latest",n=i?`${i}`:"shopping";return`${(0,r.rA)().StaticsUrl}${o}/${n}/${e}.svg`}return""}function d(e){return e&&e.href&&(e.href=c(e.href)),!0}function c(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;const i=(new Date).getTime()+t,r=(0,n.G)(),o=new URL(e);return o.searchParams.set("ts",i.toString()),o.searchParams.set("m_clk",`sid-${r}`),o.toString()}function h(e){return!!e&&/p4psearch\.1688\.com/.test(e)}function m(e,t){if(e&&e.href){const i=new URL(e.href);i.searchParams.set("m_ac","176674350"),i.searchParams.set("PageId",s.YT.getRequestId()),i.searchParams.set("ct",t),e.href=c(i.toString())}return!0}},78514(e,t,i){i.r(t),i.d(t,{MeStripeWC(){return T},MeStripeWCDisableSlideAnimationStyles(){return g},MeStripeWCStyles(){return v},MeStripeWCTemplate(){return q},ToolingInfo(){return Y},getNavigationButtonTelemetryTag(){return K}});var r=i(2958),o=i(37180),n=i(12717),s=i(85173),l=i(99900),a=i(56911),p=i(86856),d=i(74849);const c=d.A`
.me-stripe msft-horizontal-card-slider{left:-50px}`,h=d.A`
.me-stripe msft-horizontal-card-slider{right:-50px}`,m=d.A` msft-horizontal-card-slider::part(flipper-next),msft-horizontal-card-slider::part(flipper-previous){height:86px;width:45px}msft-horizontal-card-slider::part(flipper-next):before,msft-horizontal-card-slider::part(flipper-previous):before{display:block;border-radius:0;border:none;width:150px;height:52px;margin-top:-5px;pointer-events:none;box-shadow:none !important}msft-horizontal-card-slider::part(flipper-next):before,msft-horizontal-card-slider::part(flipper-previous):before{height:86px;margin-top:0}msft-horizontal-card-slider::part(flipper-next):before{margin-left:-145px;background:linear-gradient(90deg,rgba(255,255,255,0) 0%,rgb(247 247 247) 70%,rgb(247 247 247) 100%)}msft-horizontal-card-slider::part(flipper-previous):before{margin-left:40px;opacity:0 !important;background:linear-gradient(90deg,#f7f7f7 0%,rgb(247 247 247) 30%,rgba(255,255,255,0) 100%)}@media (prefers-color-scheme:dark){msft-horizontal-card-slider::part(flipper-previous):before{display:none}msft-horizontal-card-slider::part(flipper-next):before{display:none}}`,u=d.A` msft-horizontal-card-slider::part(flipper-previous):before{margin-left:40px;background:linear-gradient(90deg,rgb(244,244,242) 0%,rgb(244,244,242) 30%,rgba(255,255,255,0) 100%)}msft-horizontal-card-slider::part(flipper-next):before{margin-left:-145px;background:linear-gradient(90deg,rgba(255,255,255,0) 0%,rgb(244,244,242) 70%,rgb(244,244,242) 100%)}`,f=d.A` msft-horizontal-card-slider::part(flipper-previous):before{margin-right:40px;background:linear-gradient(90deg,rgba(255,255,255,0) 0%,rgb(244 244 242) 70%,rgb(244,244,242) 100%)}msft-horizontal-card-slider::part(flipper-next):before{margin-right:-145px;background:linear-gradient(90deg,rgb(244,244,242) 0%,rgb(244,244,242) 30%,rgba(255,255,255,0) 100%)}`,g=" div.viewport{scroll-behavior:initial}",v=d.A` :host{--neutral-fill-hover:#717171;--accent-fill-active:#717171;--accent-fill-hover:#717171;--type-ramp-base-line-height:15px;width:100%}.me-stripe{position:relative;background:transparent;border:solid #dcdcda;border-width:0 0 1px;height:auto;margin-bottom:4px}.horizontal-slider-list{display:flex;list-style:none;padding:0;margin:0}.horizontal-slider-item{flex-shrink:0;}.me-stripe-compact.me-stripe{border:none}.me-stripe-windowshp{width:calc(100% - 14px)}.me-stripe msft-horizontal-card-slider{box-sizing:border-box;width:calc(100% + 100px);padding:0px 50px}.me-stripe msft-horizontal-card-slider::part(flipper-container){padding:5px 10px}.me-stripe msft-horizontal-card-slider::part(container){gap:0;display:flex;flex-flow:row;transition:transform 1s ease-in-out}@media (prefers-color-scheme:dark){.me-stripe{border:none}}${m}
`.withBehaviors(new p.t(c,h),new p.t(u,f));var b=i(90905),x=i(58792),w=i(90366),$=i(12680),y=i(39671),z=i(60815),k=i(17918),S=i(94043),M=i(10526);class T extends y.U{static isExcludedMarket(e){return this.EXCLUDED_MARKETS.includes(e)}experienceConnected(){(0,k.tD)("TTVR.MeStripe",this.getApproxTTVRValue()||performance.now()),this.addFlipperStyles()}generateM365CopilotTile(){let e="https://m365.cloud.microsoft/chat",t=-1;if(this.config.pinCopilotFirstSlot?(e+="?fromcode=cmmrtjfdzw8",t=0):this.config.pinCopilotSecondSlot?(e+="?fromcode=cmmhhimsb2d",t=1):this.config.pinCopilotThirdSlot?(e+="?fromcode=cmm4xiu5haw",t=2):this.config.pinCopilotFourthSlot&&(e+="?fromcode=cmmd6to3t87",t=3),t<0)return null;return{tile:{title:"M365 Copilot",url:e,logoUrl:`${x.T3.StaticsUrl}latest/common/icons/copilot_m365.svg`,telemetryName:"m365copilot"},insertIndex:t}}get tiles(){var e,t;let i=(null===(e=this.config)||void 0===e?void 0:e.tiles)||[];(0,S.S)()||(i=i.slice(0,8));const r=i.map(e=>({...e,url:(0,w.bI)(e.url)})),o="AAD"===(0,M.NP)(),n=(null===(t=x.T3.LocaleContentMarketString)||void 0===t?void 0:t.toLowerCase())||"",s=T.isExcludedMarket(n);if(o&&!s){const e=this.generateM365CopilotTile();e&&r.splice(e.insertIndex,0,e.tile)}return r}getExperienceType(){return $.lJH}async addFlipperStyles(){if(this.config.disableSlideAnimation&&(0,S.S)()){const i=await(e="msft-horizontal-card-slider",t=this.shadowRoot,new Promise(i=>{const r=(0,b.A)(()=>{i(t.querySelectorAll(e)),o.disconnect()}),o=new MutationObserver(r);o.observe(t,{childList:!0,subtree:!0})}));if(null!=i&&i.length&&i[0].shadowRoot){const e=g;((e,t)=>{const i=document.createElement("style");i.innerHTML=t,e.prepend(i)})(i[0].shadowRoot,e)}}var e,t}}T.EXCLUDED_MARKETS=["zh-cn","ru-ru"],(0,a.Cg)([z.Jg],T.prototype,"tiles",null);var C=i(92011),j=i(3083),L=i(85349);const E=d.A` .me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-subtitle-container{position:relative;padding-right:6px;margin:0}`,N=d.A``,P=d.A` .me-stripe-logo-container{inset-inline-start:0}.me-stripe-tile-content{display:inline-block;vertical-align:top;overflow-y:hidden;width:140px;height:auto;padding-left:0}.me-stripe-tile-content.me-stripe-compact{height:70px;width:100px}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button{height:70px;padding:0}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button:hover{background-color:unset}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-logo-container{border-radius:12px}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-container{margin-top:2px}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container{font-weight:400;font-size:12px;max-width:100%;position:relative;line-height:normal}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-main{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-subtitle-container{position:relative;margin:0}.me-stripe-tile-content.me-stripe-compact .me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-subtitle-container .me-stripe-title-subtitle{margin-top:0px}.me-stripe-tile-button{position:relative;cursor:pointer;text-decoration:none;color:rgb(43,43,43);outline-offset:0;display:flex;flex-flow:column;align-items:center;padding:13px 0 0 0;box-sizing:border-box;height:86px}.me-stripe-tile-button:hover{background-color:#E4E4E3;border-radius:6px}.me-stripe-tile-button:hover .me-stripe-title-main{text-decoration:underline}.me-stripe-logo-container{font-size:33px;font-weight:normal;position:relative;background:rgb(255,255,255);border-radius:4px;display:flex;align-items:center;justify-content:center;height:40px;width:40px;box-shadow:0px 2px 4px 0px rgba(0,0,0,0.14)}.me-stripe-tile-button .me-stripe-logo{height:24px;width:24px}.me-stripe-title-container{display:flex;padding-inline-start:0;width:100%}.me-stripe-title-main-container{font-weight:600;font-size:14px;line-height:14px;font-family:"Segoe UI Semibold","Segoe WP Semibold","Segoe WP","Segoe UI",Arial,Sans-Serif;color:#2b2b2b;line-height:20px;text-align:center;width:100%;overflow:hidden}.me-stripe-tile-button .me-stripe-title-main-container .me-stripe-title-subtitle-container{position:relative;left:0;right:0}.me-stripe-tile-button .me-stripe-title-subtitle{font-size:9px;font-weight:600;margin-top:-6px;color:#000000;opacity:1}@media (prefers-color-scheme:dark){.me-stripe-tile-button{color:var(--neutral-foreground-rest)}.me-stripe-logo-container{background:var(--neutral-stroke-rest)}.me-stripe-title-main-container,.me-stripe-tile-button .me-stripe-title-subtitle{color:var(--neutral-foreground-rest)}.me-stripe-tile-button:hover{background-color:var(--focus-stroke-outer);border-radius:6px}}`.withBehaviors(new p.t(N,E));var _=i(96950),I=i(69259),B=i(19256);const D=_.qy`<a class="me-stripe-tile-button" part="me-stripe-tile-button" href=${e=>e.tile.url} aria-label=${e=>e.tile.title} target="_blank" @click=${(e,t)=>e.openNewTab(t)} @keypress=${(e,t)=>e.handleKeyDown(t)} data-t="${e=>e.telemetryTag}"><div class="me-stripe-logo-container"><img alt="" class="me-stripe-logo" src=${e=>e.logoSrc} @error=${(e,t)=>e.handleImageError(t)} /></div>${(0,I.z)(e=>e.tile.title,_.qy`<div class="me-stripe-title-container"><div class="me-stripe-title-main-container"><div class="me-stripe-title-main">${e=>e.tile.title}</div>${(0,I.z)(e=>e.tile.subTitle,_.qy`<div class="me-stripe-title-subtitle-container"><div class="me-stripe-title-subtitle">${e=>e.tile.subTitle.replace("{cbValue}",(0,B.Yd)((0,B.Lm)()))}</div></div>`)}</div></div>`)}</a>`,U=_.qy`<div class="me-stripe-tile-content${e=>0===e.tileIndex?" me-stripe-first-item":""} ${e=>e.useCompactMode?"me-stripe-compact":""}">${D}</div>`;var A=i(55230),W=i(19359),F=i(22341),O=i(93552);let H=class extends C.L{constructor(){super(...arguments),this.openNewTab=e=>{let{event:t}=e;const{url:i}=this.tile;return t.preventDefault(),i?window.open(i,"_blank"):void 0},this.handleKeyDown=e=>{e.event.key!==A.Mm||this.openNewTab(e)},this.handleImageError=e=>{const t=null==e?void 0:e.event,i=null==t?void 0:t.target;(0,F.vV)(O.FQY,"Error loading stripe icon","Icon that failed to load: "+(null==i?void 0:i.src))},this.imgFullUrl=e=>{const t=`//img-s-msn-com.akamaized.net/tenant/amp/entityid/${e}`;return(0,j.oQ)(t,{width:27,height:27,enableDpiScaling:!1,format:j.f5.PNG})},this.getTelemetryTags=()=>{const{telemetryName:e,title:t,url:i,isAd:r}=this.tile||{},o=r?"LeadGen":"meStripe";return e?this.generateTelemetryTags(`${o}.${e}`,L.MJ.Tile,t,i):null},this.generateTelemetryTags=(e,t,i,r)=>this.telemetryObject?(0,W.g)(e,i?{headline:i}:void 0,{type:t,behavior:L.MS.Navigate,action:L.EG.Click,overrideDestinationUrl:r||void 0}).getMetadataTag():null}get logoSrc(){var e;if(this.tile)return this.tile.logoUrl??this.imgFullUrl(null===(e=this.tile)||void 0===e?void 0:e.logoId)}get telemetryTag(){return this.getTelemetryTags()}};(0,a.Cg)([z.sH],H.prototype,"telemetryObject",void 0),(0,a.Cg)([z.sH],H.prototype,"tile",void 0),(0,a.Cg)([z.sH],H.prototype,"tileIndex",void 0),(0,a.Cg)([z.Jg],H.prototype,"logoSrc",null),(0,a.Cg)([z.Jg],H.prototype,"telemetryTag",null),H=(0,a.Cg)([(0,C.E)({name:"me-stripe-tile",template:U,styles:P})],H);var R=i(39957),V=i(41065);const G=(0,V.N)("meStripe");function K(e){return(0,V.N)(e,L.MS.Paginate,L.EG.Click,L.MJ.ActionButton).getMetadataTag()}const q=_.qy`<div class="${e=>"me-stripe "+(e.config.useCompactMode?"me-stripe-compact":"")}" data-t="${e=>G.getMetadataTag()}"><msft-horizontal-card-slider class="horizontal-slider-container" part="horizontal-slider-container" :flipperPreviousTelemetryTag=${e=>K("leftarrow")} :flipperNextTelemetryTag=${e=>K("rightarrow")}><ul class="horizontal-slider-list">${(0,R.ux)(e=>e.tiles,_.qy`<li class="horizontal-slider-item"><me-stripe-tile :tile=${e=>e} :tileIndex=${(e,t)=>t.index} :useCompactMode=${(e,t)=>t.parent.config.useCompactMode} :telemetryObject=${(e,t)=>t.parent.telemetryObject} class="horizontal-item-container"></me-stripe-tile></li>`,{positioning:!0})}</ul></msft-horizontal-card-slider></div>`,Y={experienceConfigSchema:undefined};r.m.define(o.c.registry),n.m.define(o.c.registry),s.kl.define(l.i.registry)},84506(e,t,i){i.d(t,{d(){return l}});var r=i(56911),o=i(92011),n=i(38493);const s="next";class l extends o.L{constructor(){super(...arguments),this.hiddenFromAT=!0,this.direction=s}keyupHandler(e){if(!this.hiddenFromAT){const t=e.key;"Enter"!==t&&"Space"!==t||this.$emit("click",e)}}}(0,r.Cg)([(0,n.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],l.prototype,"disabled",void 0),(0,r.Cg)([(0,n.CF)({attribute:"aria-hidden",converter:n.Bs}),(0,r.Sn)("design:type",Boolean)],l.prototype,"hiddenFromAT",void 0),(0,r.Cg)([n.CF,(0,r.Sn)("design:type",String)],l.prototype,"direction",void 0)},85173(e,t,i){i.d(t,{kl(){return b}});var r=i(99900),o=i(56911),n=i(92011),s=i(60815),l=i(36042),a=i(31157),p=i(72691),d=i(31525),c=i(94043);let h=class extends n.L{constructor(){super(),this.direction=a.O.ltr,this.currentSlotElementWidth=0,this.currentContentGapSize=0,this.setFlippersVisabilityFromPageState=()=>{if(!(0,c.S)())return;const e=this.viewport.clientWidth,t=this.container.clientWidth;if(!e||!t||e>=t)return void this.setFlippersHiddenVisibility(!0,!0);const i=this.viewport.scrollLeft;0!==i?e+Math.abs(i)>=t?this.setFlippersHiddenVisibility(!1,!0):this.setFlippersHiddenVisibility(!1,!1):this.setFlippersHiddenVisibility(!0,!1)},this.handleResize=()=>{this.setFlippersVisabilityFromPageState()},this.handleResize=(0,l.A)(this.handleResize,200)}connected(){this.direction=p.o.getValueFor(this),this.handleSlotContentChange(),window.addEventListener("resize",this.handleResize)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener("resize",this.handleResize)}handleChange(){this.direction=p.o.getValueFor(this),this.flipperNext.children[0].hidden=!1,this.flipperPrevious.children[0].hidden=!0}handleSlotContentChange(){if(!(0,c.S)())return;const e=this.viewportSlot.assignedElements();e.length>0&&(this.currentSlotElementWidth=e[0].clientWidth);const t=window.getComputedStyle(this.container).rowGap;this.currentContentGapSize=t?Number(t.replace(/px/,"")):0,this.setFlippersVisabilityFromPageState()}slideKeyPressHandler(e){if(!(0,c.S)())return;const t="rtl"!==this.direction;t||(e*=-1);const i=this.viewport.scrollLeft;if(t&&e<0&&0===i||!t&&e>0&&0===i)return;const r=this.viewport.clientWidth,o=this.container.clientWidth;if(r<=0||o<=0)return;if(r>=o)return void this.setFlippersHiddenVisibility(!0,!0);const n=e*this.getScrollDistance();(t&&e>0||!t&&e<0)&&((Math.abs(n)+Math.abs(i)>=o||o-(Math.abs(n)+Math.abs(i))<=r)&&this.hideFlipperNext(!0),this.hideFlipperPrevious(!1)),t&&e<0&&(n+i<=0&&this.hideFlipperPrevious(!0),this.hideFlipperNext(!1)),!t&&e>0&&(n+i>=0&&this.hideFlipperPrevious(!0),this.hideFlipperNext(!1)),window.requestAnimationFrame(()=>{this.viewport.scrollTo(this.viewport.scrollLeft+n,0)})}hideFlipperNext(e){this.flipperNext.children[0].hidden=e}hideFlipperPrevious(e){this.flipperPrevious.children[0].hidden=e}setFlippersHiddenVisibility(e,t){this.hideFlipperPrevious(e),this.hideFlipperNext(t)}getOneElementUnit(){return this.currentSlotElementWidth+this.currentContentGapSize}getScrollDistance(){if(!(0,c.S)())return;const e=this.viewport.clientWidth;if(e<=0)return 0;const t=this.getOneElementUnit();if(!t||t<=0)return 0;const i=Math.floor(e/t)*t;return i<=0?t:i}};(0,o.Cg)([s.sH],h.prototype,"direction",void 0),(0,o.Cg)([s.sH],h.prototype,"flipperNextTelemetryTag",void 0),(0,o.Cg)([s.sH],h.prototype,"flipperPreviousTelemetryTag",void 0),h=(0,o.Cg)([d.x],h);const m=i(74849).A` :host{--viewport-width:auto;--viewport-height:auto;--element-gap:12px;height:var(--viewport-height);overflow:hidden;width:var(--viewport-width);position:relative;display:flex}.flipper-container{position:absolute;right:0;left:0;top:0;bottom:0;padding:20px;display:flex;align-items:center;pointer-events:none;z-index:0}.viewport{height:var(--viewport-height);overflow-x:hidden;scroll-behavior:smooth;width:var(--viewport-width);white-space:nowrap}.container{display:flex;flex-direction:row;gap:var(--element-gap);width:max-content}.flipper-next{margin-inline-start:auto}.flipper-next,.flipper-previous{pointer-events:all;z-index:2}`;var u=i(96950),f=i(60402),g=i(69259);const v=u.qy`<div ${(0,f.K)("viewport")} class="viewport" part="viewport" direction="${e=>e.direction?e.direction:"ltr"}"><div class="container" part="container" ${(0,f.K)("container")}><slot ${(0,f.K)("viewportSlot")} @slotchange=${e=>e.handleSlotContentChange()}></slot></div></div>${(0,g.z)(e=>(0,c.S)(),u.qy`<div class="flipper-container" part="flipper-container"><slot ${(0,f.K)("flipperPrevious")} name="flipper-previous"><fluent-flipper direction="${e=>"rtl"===e.direction?"next":"previous"}" class="flipper-previous" part="flipper-previous" @click="${e=>e.slideKeyPressHandler(-1)}" data-t="${e=>e.flipperPreviousTelemetryTag}" hidden></fluent-flipper></slot><slot ${(0,f.K)("flipperNext")} name="flipper-next"><fluent-flipper direction="${e=>"rtl"===e.direction?"previous":"next"}" class="flipper-next" part="flipper-next" @click="${e=>e.slideKeyPressHandler(1)}" data-t="${e=>e.flipperNextTelemetryTag}" hidden></fluent-flipper></slot></div>`)}
`,b=h.compose({name:`${r.i.prefix}-horizontal-card-slider`,template:v,styles:m})}}]);