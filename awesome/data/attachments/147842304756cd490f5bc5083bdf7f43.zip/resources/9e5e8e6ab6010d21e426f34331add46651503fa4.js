// © Microsoft Corporation. All rights reserved.
import { AppState, appState } from "@msnews/windows-shared";
import { AppTypeTelemetryBase } from "@msnews/entry-point-shared-utils";
import { ColumnArrangement, fastBreakpointManager } from "@msnews/experiences-base";
import { Telemetry, TrackingSystemType, initTelemetry } from "@msnews/telemetry-contracts";
import { UrlUtility, appEnvironment, canUseDigitalId, headData } from "@msnews/core";
import { xfeedPageName, xfeedPathPrefix } from "@msnews/msn-common-header";
import { CookieConsentStatus } from "@msnews/cookie-contracts";
import { IsomorphicStorage } from "@msnews/isomorphic-util";
import { TelemetryLibrary } from "@msnews/telemetry-core";
import { initDigitalIdSubscription } from "@msnews/auth";
import { removeStandbyClickEventListenerAfterHydration } from "@msnews/lite-telemetry";
import { getOcidForMsnHp, getWinOverrides, isWinHPOcid } from "@msnews/url-util";
/**
 * Initialize telemetry SDK library and setup page contract used across all telemetry events.
 * @param locationHref - The window.location.href value
 * @param requestContext - The RequestContext object
 */
export function setupPageTelemetry(locationHref, requestContext, pageExperiments, hydrationPromise, inheritByTraversingDOMOverride) {
    // super telemetry automatically merges the telemetry properties in the inheritPropertyList from ancestors
    // with the current element's telemetry data into the final telemetry data
    const traversingDomWithoutMemoizeEnabled = pageExperiments && pageExperiments.includes("prg-hptel-trdom");
    const traversingDomWithMemoizeEnabled = pageExperiments && pageExperiments.includes("prg-hptel-mtrdom");
    const inheritPropertyList = traversingDomWithoutMemoizeEnabled || traversingDomWithMemoizeEnabled || inheritByTraversingDOMOverride ? ["ext"] : undefined;
    const inheritByTraversingDOM = traversingDomWithoutMemoizeEnabled || traversingDomWithMemoizeEnabled || inheritByTraversingDOMOverride || false;
    const memoizeInheritedProperties = traversingDomWithMemoizeEnabled || false;
    // Get tracking system config
    const trackingConfig = AppTypeTelemetryBase.getAppTypeTrackingSystemConfig(false);
    const anonCookieOption = canUseDigitalId() ? undefined : { anonCookieName: appEnvironment.AuthCookieName };
    initDigitalIdSubscription();
    // Initialize Telemetry SDK library
    initTelemetry(new TelemetryLibrary({
        ...anonCookieOption,
        trackingSystems: trackingConfig,
        autoCaptureContentView: false,
        hydrationPromise,
        inheritPropertyList,
        inheritByTraversingDOM,
        memoizeInheritedProperties,
        enableTraceGenerator: true,
        enableEventsBatching: appEnvironment.BatchedEvents,
        telemetryInitOptions: appEnvironment.TelemetryInitOptions
    }));
    removeStandbyClickEventListenerAfterHydration(hydrationPromise);
    // Set "page" contract for Telemetry library
    const pageTelemetryContract = getPageTelemetryContract(locationHref, requestContext);
    AppTypeTelemetryBase.initPage(pageTelemetryContract);
    const cookieConsentStatus = appState.get(AppState.CookieConsentStatus);
    if (cookieConsentStatus !== CookieConsentStatus.NotRequired) {
        Telemetry.disableTrackingSystem(TrackingSystemType.Comscore);
    }
    // Disable unnecessary beacons.
    if (UrlUtility.getQueryParameterByName("enableTrack", locationHref) === "false") {
        Telemetry.disableTrackingSystem(TrackingSystemType.All);
    }
}
/**
 * Creates telemetry contract for page
 * @param locationHref - The window.location.href passed from requestContext
 * @param requestContext - The RequestContext object
 */
export function getPageTelemetryContract(locationHref, requestContext) {
    let pageName = "startpage";
    // Check if in the interests hub on page load to set the page name appropriately
    if (/\/personalize/.test(locationHref)) {
        pageName = "cinterests";
    }
    else if (locationHref.includes(xfeedPathPrefix)) {
        pageName = xfeedPageName;
    }
    const winOverrides = getWinOverrides(locationHref);
    const appConfig = {
        // Properties sent as part of "data.page" section of the telemetry payload
        pageCanvas: "homepage",
        pageConfiguration: 1035,
        pageName: pageName,
        pageOcid: getOcidForMsnHp(locationHref),
        pageProduct: winOverrides.pageProduct || "prime",
        pageHas3PSearch: true,
        // Properties sent as part of "data.page.content" section of the telemetry payload
        pageContentDomainId: "13041",
        pageContentSubCategory: "hpmsn",
        pageContentVertical: "homepage",
        // Properties sent as part of "data.user" section of the telemetry payload
        userSignInStatus: appState.get(AppState.IsSignedIn) === 2 /* SignedInStatus.SignedIn */,
        userSsoStatus: false,
        userAadState: 2 /* AadAccountType.Unknown */
    };
    const appOverrides = {
        pageType: winOverrides.pageType || "hp",
        pageViewType: getTelemetryViewType()
    };
    return AppTypeTelemetryBase.getAppTypeTelemetryContract(appConfig, requestContext, null, appOverrides);
}
/**
 * Setup callbacks for updating telemetry page metadata when AppState changes.
 */
export function setupTelemetryUpdateCallbacksOnAppStateChange() {
    // Add subscription to breakpoint change to update Page viewType when windows size is changed
    appState.subscribe(AppState.ColumnArrangement, () => {
        Telemetry.updatePageMetadata({ page: { viewType: getTelemetryViewType() } }, true);
    });
    // Sets theme telemetry
    let isInitialLoad = true;
    appState.subscribe(AppState.IsDarkMode, (isDarkMode) => {
        document.body.style.backgroundColor = document.documentElement.style.backgroundColor = isDarkMode ? "#242424" : "#FFFFFF";
        Telemetry.updatePageMetadata({ page: { theme: isDarkMode ? "dark" : "light" } }, true);
        // Adds listener to detect theme changes after the initial page load
        if (!isInitialLoad) {
            Telemetry.sendPageView(null, false);
        }
        isInitialLoad = false;
    });
}
/**
 * The HomePage Telemetry class
 */
export class HomePageTelemetry {
    static get viewType() { return IsomorphicStorage.get(this.viewTypeKey); }
    static set viewType(value) { IsomorphicStorage.set(this.viewTypeKey, value); }
    /**
     * The track callbacks
     *
     * @static
     * @type {TrackCallbacks}
     * @memberof HomePageTelemetry
     */
    static trackCallbacks() {
        switch (fastBreakpointManager().currentColumnArrangement) {
            case ColumnArrangement.c1:
            case ColumnArrangement.c2:
                HomePageTelemetry.viewType = "size2column";
                break;
            case ColumnArrangement.c3:
                HomePageTelemetry.viewType = "size3column";
                break;
            case ColumnArrangement.c4:
                HomePageTelemetry.viewType = "size4column";
                break;
            case ColumnArrangement.c5:
                HomePageTelemetry.viewType = "size5column";
                break;
            default:
                // leave HomePageTelemetry.viewType unchanged
                break;
        }
        return HomePageTelemetry.viewType;
    }
    /**
     * Gets the track properties
     *
     * @param window
     * @param config
     * @param locationHref
     * @returns The track properties
     */
    static getTelemetryProperties(window, config, locationHref, isWaterfall) {
        // TODO: replace getQueryParameterByName with more efficient method if multiple query param
        // inspection need to be done
        const enableTrack = !(UrlUtility.getQueryParameterByName("enableTrack", locationHref) === "false");
        const ocid = getOcidForMsnHp(locationHref);
        const isWinOcid = isWinHPOcid(ocid);
        const activityId = appEnvironment.ActivityIdLowerCaseNoHypens;
        const deviceGroup = "unknown";
        const autoRefresh = "0";
        let isMobile = "0";
        let isStaticPage = false;
        let pageProduct = "prime";
        if (headData && headData.ClientSettings) {
            const clientSettings = headData.ClientSettings;
            if (clientSettings.static_page === "true") {
                isStaticPage = true;
            }
            isMobile = ((clientSettings.browser && clientSettings.browser.ismobile === "true") || clientSettings.deviceFormFactor === "phone" /* DeviceFormFactorType.Phone */) ? "1" : "0";
        }
        const pageTypeObj = {};
        if (isMobile === "1") {
            pageProduct = "prime_mobile";
        }
        else if (isWinOcid) {
            const winOverrides = getWinOverrides(locationHref);
            pageProduct = winOverrides.pageProduct;
            pageTypeObj.pageType = winOverrides.pageType;
        }
        else if (isWaterfall) {
            pageProduct = "feedmsn";
        }
        const flightId = (appEnvironment.CurrentRequestTargetScope && appEnvironment.CurrentRequestTargetScope.pageExperiments) ? appEnvironment.CurrentRequestTargetScope.pageExperiments.join(",") : undefined;
        const trackProperties = {
            // Config driven properties
            ...config,
            // Properties from the current environment
            activityId: activityId,
            autoRefresh: autoRefresh,
            canvas: "Browser",
            channel: "homepage", // verify
            dDgk: deviceGroup,
            dImd: isMobile,
            domainId: "13041",
            enable: enableTrack,
            environment: appEnvironment.Environment,
            flightid: flightId,
            isStaticPage: isStaticPage,
            localeCode: appEnvironment.CurrentMarket,
            pageName: "startpage",
            pageProduct: pageProduct,
            pageTitle: window.document.title,
            pageUrl: window.document.URL,
            serverImpressionGuid: activityId,
            tmpl: "",
            // TODO: Add AFD logs once PCS send back the data.
            // Following the spec: https://microsoft.sharepoint.com/:w:/t/DataandInsights/EawMe8a0XKxCkuBO19CGARIByn5roly2qWG76ZElsQq5VQ?e=4PQyuM
            afd: "",
            ...pageTypeObj
        };
        if (ocid) {
            trackProperties.msnocid = ocid;
        }
        return trackProperties;
    }
    /**
     * Creates telemetry contract for page
     * @param {any} telemetryProperties
     * @param (boolean) isStaticPage
     * @param (boolean) isMobile
     * @param (string) locationHref - The window.location.href passed from requestContext
     */
    static getPageTelemetryContract(telemetryProperties, isStaticPage, isMobile, locationHref) {
        const pageTelemetryContract = {
            page: {
                appType: appEnvironment.AppType,
                name: telemetryProperties.pageName,
                config: telemetryProperties.pageConfiguration,
                product: telemetryProperties.pageProduct,
                type: telemetryProperties.pageType,
                isJSEnabled: true,
                isAutoRefresh: false,
                isStatic: isStaticPage,
                url: locationHref,
                canvas: telemetryProperties.canvas,
                ocid: telemetryProperties.msnocid || telemetryProperties.storeocid,
                isAdEnabled: false,
                content: {
                    vertical: telemetryProperties.vertical,
                    category: telemetryProperties.department,
                    title: window.document.title,
                    id: "",
                    domainId: telemetryProperties.domainId
                },
                viewType: this.trackCallbacks(),
                referral: __WEBPACK_IS_NODE__ ? document.referrer : undefined
            },
            flight: {
                id: appEnvironment.CurrentRequestTargetScope &&
                    appEnvironment.CurrentRequestTargetScope.pageExperiments &&
                    appEnvironment.CurrentRequestTargetScope.pageExperiments.join(",")
            },
            locale: {
                mkt: appEnvironment.CurrentMarket,
                lang: appEnvironment.MarketRequestInputLanguage,
                region: appEnvironment.MarketRequestInputRegion,
                geo_cc: appEnvironment.MarketRequestInputGeoCountry,
                mktReason: appEnvironment.MarketDetectionType
            },
            browser: {
                isMobile
            }
        };
        return pageTelemetryContract;
    }
}
/**
 * The view type
 */
HomePageTelemetry.viewTypeKey = Symbol("viewType");
/**
* The track callbacks
*/
function getTelemetryViewType() {
    switch (appState.get(AppState.ColumnArrangement)) {
        case ColumnArrangement.c1:
            return "size1column";
        case ColumnArrangement.c2:
            return "size2column";
        case ColumnArrangement.c3:
            return "size3column";
        case ColumnArrangement.c4:
            return "size4column";
        case ColumnArrangement.c5:
            return "size5column";
        default:
            return "";
    }
}
//# sourceMappingURL=HomePageTelemetry.js.map