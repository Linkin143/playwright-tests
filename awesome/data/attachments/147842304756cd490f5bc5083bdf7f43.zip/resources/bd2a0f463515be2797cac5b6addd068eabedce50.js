// © Microsoft Corporation. All rights reserved.
import { CreateServerDebugInfo, getCurrentAccount, headData, replaceFormatStringsFromUrl, resolver } from "@msnews/core";
import { getSSRForceExceptionScript, getSSRTelemetryDataFromProps, getStackTrace, RenderServiceResponseType, shouldForceShowException, TelemetryInstanceKey, waitInSSRAfterFeedCall } from "@msnews/ssr-util";
import { EarlyFallbackError, RootSSRElementRenderer, SSRStyleRenderer, getSSRDataStreamMarkup, getSSRFunctionExpressionMarkup, splitTemplate } from "@msnews/ssr-server-utils";
import { loadServerRenderedWCEs, skipExperience } from "@msnews/experiences-web-component-loader";
import { skipConnector } from "@msnews/experiences-redux";
import { Telemetry } from "@msnews/telemetry-contracts";
import { SSRTelemetry, flushSSRResponse, GenerateSEOMetaTags, setPageTiming, setSSRFlushImpl } from "@msnews/ssr-util";
import { fetchAndStoreMainFeed, getGlobalStyles } from "@msnews/entry-point-hp-wc";
import { AsyncResource } from "async_hooks";
import { ViewsSSRRootError, getElapsedSinceTimeOrigin, getPageTimings } from "@msnews/diagnostics";
import { NativeAdBeaconDirective } from "@msnews/native-ad-telemetry";
import { experiencesRefs, ssrExcludedExperiences, ssrExcludedConnectors, getSsrExcludedElements } from "./utils/experiencesRef";
import { IsomorphicStorage } from "@msnews/isomorphic-util";
import { getTelemetryLoginState, initAuth } from "@msnews/auth";
import { wpoTreatment } from "@msnews/wpo";
import { fastBreakpointManager } from "@msnews/experiences-base";
import { getLiteTelemetrySetupPayload, getSSRTelemetryTrackingSystemConfig } from "@msnews/lite-telemetry";
import { HomePageTelemetry } from "../HomePageTelemetry";
import { desktopTrackConfig } from "../telemetry";
import { homepageFeedManager } from "../utils/HomepageFeedManager";
import { setupBreakpoint } from "../breakpoints";
import { getRequestProps } from "./node.index";
function skipCSROnlyExperiences() {
    // For WCE, we skip the entire experience loading process to exclude it from SSR
    // So we don't need to load code, code and redux stores for skipped experiences.
    ssrExcludedExperiences.forEach(experience => skipExperience(experience));
    ssrExcludedConnectors.forEach(connector => skipConnector(connector));
}
/**
 * Processes response with web component output through Fast SSR for requested page (intended for real user scenarios).
 * @param req: ExpressRequest received from client.
 * @param res: ExpressResponse to serve. To populate it with HTML response.
 * @returns: void. Writes to {res} object.
 */
export async function processFASTWCResponse(req, requestProps, res, templateData, isWCSEO) {
    /** Has SSR result finished successfully */
    let isStreamingComplete = false;
    /** Has top part of HTML been streamed succesfully */
    let isTopHTMLStreamingComplete = false;
    let wpoFeedData = null;
    let isDataStreamingComplete = false;
    function streamSSRData(res, data = {}) {
        if (isDataStreamingComplete) {
            return;
        }
        isDataStreamingComplete = true;
        try {
            // make sure to stream remaining HTML in buffer before streaming data
            res.flush();
            if (wpoFeedData) {
                data["ssrWpoData"] = wpoFeedData;
                const { serviceContext } = wpoFeedData;
                if (serviceContext?.serviceActivityId) {
                    res.write(getSSRFunctionExpressionMarkup("updateIdxId", { IDXId: serviceContext.serviceActivityId }));
                }
                const ssrAdRequest = wpoTreatment.getSSRFirstSectionAdRequest();
                if (ssrAdRequest) {
                    data["ssrAdRequest"] = ssrAdRequest;
                }
            }
            data["ssrSizes"] = {
                ssrCol: fastBreakpointManager().currentColumnArrangement,
                ssrWidth: window.innerWidth,
                ssrHeight: window.innerHeight
            };
            res.write(getSSRDataStreamMarkup(data));
        }
        catch (ex) {
            SSRTelemetry.sendErrorServerLog("Error streaming feed data", req.id, { error: ex.message });
        }
    }
    const { templateDataHtmlTop, templateDataHtmlMiddle, templateDataHtmlBottom } = splitTemplate(templateData.html);
    // Stream SSR result onto response
    const styleRenderer = new SSRStyleRenderer();
    const requestQuery = req.query;
    const streamWriter = (part) => {
        if (res.writableFinished) {
            renderer.dispose();
            throw new EarlyFallbackError("Abort rendering because response is not writable");
        }
        // if request is aborted, dispose renderer and exit loop
        if (req.destroyed) {
            renderer.dispose();
            return false; // End the output
        }
        if (part === "") {
            return true; // Skip the output and continue
        }
        if (typeof part === "number") {
            part = String(part);
        }
        res.write(part);
        return true; // Continue
    };
    const renderer = new RootSSRElementRenderer(styleRenderer, streamWriter);
    try {
        // Set up config resolver
        resolver.setTargetScopeAndConfigServiceParams();
        resolver.initialize(Telemetry.sendAppErrorEvent.bind(Telemetry));
        const setupInitialTelemetry = () => {
            const requestProps = getRequestProps(req);
            // Initialize SSRTelemetry with mockClientData to ensure all app errors can be sent out by Telemetry
            const telemetryData = getSSRTelemetryDataFromProps(req.id, requestProps, {
                clientInfo: "",
                clientSettings: {
                    aid: "",
                    apptype: "",
                    apps_locale: "",
                    browser: {
                        browserType: "",
                        ismobile: null
                    },
                    fd_muid: "",
                    functionalonly_cookie_experience: null,
                    functional_cookie_patterns: "",
                    functional_cookies: "",
                    geo_lat: "",
                    geo_long: "",
                    locale: {
                        content: {},
                        language: ""
                    }
                },
                language: "",
                marketDir: ""
            });
            SSRTelemetry.initializeTelemetryAPI(telemetryData, getSSRTelemetryTrackingSystemConfig(), true);
        };
        // Hook handlers for when request is terminated
        res.on("close", AsyncResource.bind(() => {
            if (req.destroyed) {
                renderer && renderer.dispose();
            }
            let telemetry = IsomorphicStorage.get(TelemetryInstanceKey);
            if (!telemetry) {
                // In case response is closed before telemetry is correctly setup -- try setup initial telemetry first
                setupInitialTelemetry();
                telemetry = IsomorphicStorage.get(TelemetryInstanceKey);
            }
            Telemetry.addOrUpdateTmplProperty("isSSRFinished", "1");
            SSRTelemetry.sendLoadTime(getPageTimings(), req.id);
            if (!isStreamingComplete) {
                SSRTelemetry.sendInformationServerLog("SSR Streaming not complete", req.id, {
                    isTopHTMLStreamingComplete,
                    isDataStreamingComplete
                });
            }
            Telemetry.flush();
            IsomorphicStorage.clear();
            IsomorphicStorage.set(TelemetryInstanceKey, telemetry);
        }));
        let title = "MSN";
        let metaTagsHtml = "";
        try {
            let config;
            let description = "";
            if (isWCSEO) {
                // On feedview ssr, we don't want to block first response with config fetch
                // To get title and description from general config
                const configRef = { experienceType: "EntryPointHpWC", instanceSrc: "default" };
                const experienceConfigWrapper = await resolver.getConfig(configRef);
                config = experienceConfigWrapper && experienceConfigWrapper.properties;
                if (config) {
                    title = config.localizedStrings?.initialPageTitle || config.initialPageTitle;
                    description = config.localizedStrings?.initialPageDescription || config.description;
                }
            }
            const robotTag = "index,follow,max-image-preview:large";
            const dataType = "website";
            const twitter = "summary_large_image";
            // Object containing all content for default meta tags.
            const seoMetaData = {
                robots: robotTag,
                description: description,
                sharingUrl: undefined, // originalRequestUrl,
                twitterCard: twitter,
                ogUrl: undefined, // originalRequestUrl,
                ogType: dataType,
                ogSiteName: "MSN",
                ogTitle: title,
                ogDescription: description
            };
            const customSeoMetaTag = [
                { tagName: "application-name", tagContent: title, isPropertyField: false }
            ];
            let metaTags = GenerateSEOMetaTags(seoMetaData, customSeoMetaTag);
            if (requestProps.href) {
                const URL = requestProps.href.split("?")[0];
                metaTags += `<link rel="canonical" href="${URL}">`;
                // Ensures proper rendering on various devices by setting the viewport width to the device width, and initial scale to 1.0
                metaTags += "<meta name='viewport' content='width=device-width, initial-scale=1.0' />";
            }
            metaTagsHtml = metaTags;
        }
        catch (error) {
            res.setHeader("Cache-Control", "no-store");
            res.statusCode = 404;
            res.end();
            return;
        }
        setupBreakpoint({ enableWaterfallViewFeed: true });
        const telemetryProperties = HomePageTelemetry.getTelemetryProperties(window, desktopTrackConfig, window.location.href, true);
        const pageTelemetryContract = HomePageTelemetry.getPageTelemetryContract(telemetryProperties, telemetryProperties.isStaticPage, false, window.location.href);
        Telemetry.updatePageMetadata(pageTelemetryContract);
        initAuth();
        const currentAccount = getCurrentAccount();
        const userSignInStatus = await getTelemetryLoginState({
            isMsa: currentAccount?.account_type === "MSA" /* AccountType.MSA */,
            isAAD: currentAccount?.account_type === "AAD" /* AccountType.AAD */
        });
        Telemetry.updatePageMetadata({ user: userSignInStatus }, true);
        // Stream top part of template
        // This will stream head and other PCS data to top of html
        isTopHTMLStreamingComplete = streamHeadDataAndCSBundles(res, templateDataHtmlTop, templateDataHtmlMiddle, { title, metaTagsHtml });
        const telemetryCustomData = { "server-debug-info": CreateServerDebugInfo() };
        // For desktop, return static html including nav links for now
        if (isWCSEO) {
            const navLinksHtml = await generateNavLinks();
            res.write(navLinksHtml);
            res.write(`<script nonce="${templateData.nonce}">window.SSRONLY=true;</script>`);
            res.write(templateDataHtmlBottom);
            isStreamingComplete = true;
            res.end();
            return;
        }
        res.write(getLiteTelemetrySetupPayload(templateData.nonce, telemetryCustomData));
        // Flush immediately the JS bundles
        flushSSRResponse();
        // Skip CSR only experiences & data connectors -- Need to run this before loading components to avoid "Attempted to load unknown dynamic bundle" error
        skipCSROnlyExperiences();
        const mergedConfigs = await resolver.getConfig({
            experienceType: "AppConfig",
            instanceSrc: "default"
        });
        if (!mergedConfigs) {
            throw new Error("Failed to fetch config for SSR. Falling back to CSR");
        }
        if (requestQuery?.["ssrenable"] === "true") {
            // For cases of forced SSR, manually check need to be done in RS side. For default cases, OCIDs & Cookies check are done in the route side.
            homepageFeedManager.init();
            const entryPointConfigRef = mergedConfigs.properties.childExperiences?.entryPointHpWaterfall && homepageFeedManager.isFeedView(true) ? mergedConfigs.properties.childExperiences?.entryPointHpWaterfall?.configRef : mergedConfigs.properties.rootExperience.configRef;
            if (entryPointConfigRef.experienceType !== "EntryPointHpWC" || entryPointConfigRef.instanceSrc !== "waterfall") {
                throw new Error("Non-feed view requested. Falling back to CSR.");
            }
        }
        // Load Root WCE for SSR
        const rootExperienceConfigInfo = {
            instanceId: "EntryPointHpWC",
            configRef: {
                experienceType: "EntryPointHpWC",
                instanceSrc: "waterfall"
            }
        };
        const experienceConfigWrapper = await resolver.getConfig(rootExperienceConfigInfo.configRef);
        const entryPointHpWCConfigs = experienceConfigWrapper && experienceConfigWrapper.properties;
        wpoTreatment.onWPOFeedReady((feedResponse) => {
            wpoFeedData = feedResponse;
        });
        /** TODO: mark prg-hp-earlyfssr as unship and remove it when SSR ships */
        if (!entryPointHpWCConfigs.disableFeed) {
            fetchAndStoreMainFeed();
            await waitInSSRAfterFeedCall(headData.CurrentFlightSet);
        }
        if (res.writableFinished) {
            throw new EarlyFallbackError("Abort rendering because response is not writable");
        }
        setPageTiming("ssrLoadWCEStart", getElapsedSinceTimeOrigin());
        // TODO: current experiencesRefs are not in sync with AppConfig, needs updating
        // const experiencesToLoad = experiencesRefs.filter(expRef => !!resolver.getConfigSync(expRef.configRef));
        await loadServerRenderedWCEs(experiencesRefs);
        setPageTiming("ssrLoadWCEEnd", getElapsedSinceTimeOrigin());
        renderer.disableElements(getSsrExcludedElements());
        renderer.withViewBehaviorFactoryRenderers([
            { matcher: NativeAdBeaconDirective, *render() { } }
        ]);
        setPageTiming("ssrWCRenderStart", getElapsedSinceTimeOrigin());
        for await (let part of renderer.render(rootExperienceConfigInfo)) {
            if (res.writableFinished) {
                renderer.dispose();
                throw new EarlyFallbackError("Abort rendering because response is not writable");
            }
            // if request is aborted, dispose renderer and exit loop
            if (req.destroyed) {
                renderer.dispose();
                break;
            }
            if (typeof part === "number") {
                part = String(part);
            }
            res.write(part);
        }
        setPageTiming("ssrWCRenderEnd", getElapsedSinceTimeOrigin());
        streamSSRData(res, {
            isSSRCompleted: true
        });
        // Write bottom part
        res.write(templateDataHtmlBottom);
        isStreamingComplete = true;
        // Finalize response
        res.end();
    }
    catch (error) {
        if (shouldForceShowException(requestQuery)) {
            const stackTrace = `${error?.stack || getStackTrace()}`;
            // SSR-TODO: Remove this debugging code before production release.
            // The flag will stop re-throw exception and show it in HTML
            console.error(`[SSR] Error: ${error} Stack trace: ${stackTrace} Request Id: ${req.id}`);
            res.write(getSSRForceExceptionScript(`<b>Error: </b>${error}<br /><b>Stack trace: </b><pre>${stackTrace}</pre><br />Request Id: ${req.id}<br />`, templateData.nonce));
            isStreamingComplete = true;
            res.end();
            return;
        }
        if (Telemetry && !(error instanceof EarlyFallbackError)) {
            Telemetry.sendAppErrorEvent({
                ...ViewsSSRRootError,
                message: error?.message ?? "SSR unknown root error",
                pb: {
                    ...ViewsSSRRootError.pb,
                    errorString: JSON.stringify(error) ?? ""
                }
            });
        }
        // if we have already streamed top section, stream bottom section to complete HTML
        // client side logic will remove partial SSR response and fallback to CSR
        if (isTopHTMLStreamingComplete) {
            streamSSRData(res, {
                isCSRFallback: true
            });
            res.write(templateDataHtmlBottom);
            isStreamingComplete = true;
            res.end();
            throw error;
        }
        else {
            // no response has been sent to client, throw error forward to fallback to CSR.
            throw error;
        }
    }
}
async function generateNavLinks() {
    // To get the nav links from feed navigation config
    const configRefMFeedNav = { experienceType: "FeedNavigationHp", instanceSrc: "default" };
    const experienceConfigWrapperFeedNav = await resolver.getConfig(configRefMFeedNav);
    const feednavConfig = experienceConfigWrapperFeedNav && experienceConfigWrapperFeedNav.properties;
    const pivots = feednavConfig && feednavConfig.staticPivots;
    if (!pivots || pivots.length === 0) {
        return "";
    }
    const linkElements = pivots.map((pivot) => {
        const href = pivot.externalTargetUrl.href && replaceFormatStringsFromUrl(pivot.externalTargetUrl.href);
        const title = pivot.display || "Home";
        return `<li><a href="${href}" title="${title}" target="_blank">${title}</a></li>`;
    });
    return `<ul role="navigation" style="height:1px; overflow:hidden;">${linkElements.join("")}</ul>`;
}
function streamHeadDataAndCSBundles(res, topHtml, middleHtml, headInfo) {
    res.statusCode = 200;
    res.setHeader("Content-Type", RenderServiceResponseType.HTML);
    res.setHeader("Cache-Control", "no-store");
    setSSRFlushImpl(() => {
        // res.flush is not typed by RS in ExpressResponse
        res?.flush();
        setPageTiming("HeaderFlushed", getElapsedSinceTimeOrigin());
    });
    const styleStr = getGlobalStyles();
    // Update head to have isSSREnabled
    const updatedMarkup = topHtml.replace(/<title>[\w\s]+<\/title>/, `<title>${headInfo.title}</title>${headInfo.metaTagsHtml}<style>${styleStr}</style><script>window.isSSREnabled=true;</script>`);
    res.write(updatedMarkup);
    // Stream CSR JS bundles. Make it async to not block SSR render.
    middleHtml = middleHtml.replaceAll("></script>", " async></script>");
    res.write(middleHtml);
    return true;
}
//# sourceMappingURL=web-component-renderer.js.map