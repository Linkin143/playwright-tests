"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["premium-profile-promo-card"],{7014(e,t,i){i.d(t,{m(){return I}});var r=i(56911),o=i(38493),n=i(60815),a=i(55230),s=i(92011),l=i(56863);class d extends s.L{}class c extends((0,l.dx)(d)){constructor(){super(...arguments),this.proxy=document.createElement("input")}}class u extends c{constructor(){super(),this.initialValue="on",this.keypressHandler=e=>{if(!this.readOnly)switch(e.key){case a.Mm:case a.gG:this.checked=!this.checked}},this.clickHandler=e=>{this.disabled||this.readOnly||(this.checked=!this.checked)},this.proxy.setAttribute("type","checkbox")}readOnlyChanged(){this.proxy instanceof HTMLInputElement&&(this.proxy.readOnly=this.readOnly),this.readOnly?this.classList.add("readonly"):this.classList.remove("readonly")}checkedChanged(e,t){super.checkedChanged(e,t),this.checked?this.classList.add("checked"):this.classList.remove("checked")}}(0,r.Cg)([(0,o.CF)({attribute:"readonly",mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],u.prototype,"readOnly",void 0),(0,r.Cg)([n.sH,(0,r.Sn)("design:type",Array)],u.prototype,"defaultSlottedNodes",void 0);var h=i(37180),p=i(74849),v=i(64187),b=i(60993),g=i(73477),m=i(22131),x=i(50882),$=i(48196),f=i(86856),w=i(7896),k=i(74838),y=i(79288),A=i(46203),M=i(26920),S=i(43774),N=i(95239),P=i(14996),T=i(48751),D=i(41123),C=i(74089),L=i(4283);const z=p.A`
    :host([hidden]) {
        display: none;
    }

    ${(0,v.V)("inline-flex")} :host {
        align-items: center;
        outline: none;
        font-family: ${w.O};
        margin: calc(${k.vR} * 1px) 0;
        ${""} user-select: none;
    }

    :host([disabled]) {
        opacity: ${y.q};
    }

    :host([disabled]) .label,
    :host([readonly]) .label,
    :host([readonly]) .switch,
    :host([disabled]) .switch {
        cursor: ${b.Z};
    }

    .switch {
        position: relative;
        outline: none;
        box-sizing: border-box;
        width: calc(((${$.D} / 2) + ${k.vR}) * 2px);
        height: calc(((${$.D} / 2) + ${k.vR}) * 1px);
        background: ${A.le};
        border-radius: calc(${$.D} * 1px);
        border: calc(${M.XA} * 1px) solid ${S.nF};
    }

    :host(:enabled) .switch:hover {
        background: ${A.jM};
        border-color: ${S.vA};
        cursor: pointer;
    }

    :host(:enabled) .switch:active {
        background: ${A.RS};
        border-color: ${S.p4};
    }

    :host(:${g.N}) .switch {
        box-shadow: 0 0 0 2px ${N.p}, 0 0 0 4px ${P.WN};
        border-color: ${P.WN};
    }

    .checked-indicator {
        position: absolute;
        height: calc((${$.D} - (${k.vR} * 5.5)) * 1px);
        width: calc((${$.D} - (${k.vR} * 5.5)) * 1px);
        top: calc(${k.vR} * 1px);
        background: ${T.l};
        border-radius: 50%;
        transition: all 0.2s ease-in-out;
    }

    .status-message {
        color: ${T.l};
        cursor: pointer;
        font-size: ${D.K};
        line-height: ${D.Z};
    }

    .label__hidden {
        display: none;
        visibility: hidden;
    }

    .label {
        color: ${T.l};
        font-size: ${D.K};
        line-height: ${D.Z};
        margin-inline-end: calc(${k.vR} * 2px + 2px);
        cursor: pointer;
    }

    ::slotted(*) {
        ${""} margin-inline-start: calc(${k.vR} * 2px + 2px);
    }

    :host([aria-checked="true"]) .checked-indicator {
        background: ${C.l_};
    }

    :host([aria-checked="true"]) .switch {
        background: ${L.IR};
    }

    :host([aria-checked="true"]:enabled) .switch:hover {
        background: ${L.OS};
    }

    :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
        background: ${C.XK};
    }

    :host([aria-checked="true"]:enabled) .switch:active {
        background: ${L.am};
    }

    :host([aria-checked="true"]:enabled) .switch:active .checked-indicator {
        background: ${C.J_};
    }

    :host([aria-checked="true"]:${g.N}:enabled) .switch {
        box-shadow: 0 0 0 2px ${N.p}, 0 0 0 4px ${P.WN};
        border-color: transparent;
    }

    .unchecked-message {
        display: block;
    }

    .checked-message {
        display: none;
    }

    :host([aria-checked="true"]) .unchecked-message {
        display: none;
    }

    :host([aria-checked="true"]) .checked-message {
        display: block;
    }
`.withBehaviors(new f.t(p.A`
            .checked-indicator {
                left: calc(${k.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                left: calc(
                    (((${$.D} / 2) + ${k.vR}) + ${k.vR}) * 1px
                );
            }
        `,p.A`
            .checked-indicator {
                right: calc(${k.vR} * 1px);
            }

            :host([aria-checked="true"]) .checked-indicator {
                right: calc(
                    (((${$.D} / 2) + ${k.vR}) + ${k.vR}) * 1px
                );
            }
        `),(0,m.mr)(p.A`
            .checked-indicator,
            :host(:enabled) .switch:active .checked-indicator {
                forced-color-adjust: none;
                background: ${x.A.FieldText};
            }
            .switch {
                forced-color-adjust: none;
                background: ${x.A.Field};
                border-color: ${x.A.FieldText};
            }
            :host(:enabled) .switch:hover {
                background: ${x.A.HighlightText};
                border-color: ${x.A.Highlight};
            }
            :host([aria-checked="true"]) .switch {
                background: ${x.A.Highlight};
                border-color: ${x.A.Highlight};
            }
            :host([aria-checked="true"]:enabled) .switch:hover,
            :host(:enabled) .switch:active {
                background: ${x.A.HighlightText};
                border-color: ${x.A.Highlight};
            }
            :host([aria-checked="true"]) .checked-indicator {
                background: ${x.A.HighlightText};
            }
            :host([aria-checked="true"]:enabled) .switch:hover .checked-indicator {
                background: ${x.A.Highlight};
            }
            :host(:${g.N}) .switch {
                border-color: ${x.A.Highlight};
                box-shadow: 0 0 0 2px ${x.A.Field},
                    0 0 0 4px ${x.A.FieldText};
            }
            :host([aria-checked="true"]:${g.N}:enabled) .switch {
                box-shadow: 0 0 0 2px ${x.A.Field},
                    0 0 0 4px ${x.A.FieldText};
            }
            :host([disabled]) {
                opacity: 1;
            }
            :host([disabled]) .checked-indicator {
                background: ${x.A.GrayText};
            }
            :host([disabled]) .switch {
                background: ${x.A.Field};
                border-color: ${x.A.GrayText};
            }
            .status-message,
            .label {
                color: ${x.A.FieldText};
            }
        `));var B=i(96950),H=i(82774),E=i(18893);const F=function(e={}){return B.qy`
        <template
            role="switch"
            aria-checked="${e=>e.checked}"
            aria-disabled="${e=>e.disabled}"
            aria-readonly="${e=>e.readOnly}"
            tabindex="${e=>e.disabled?null:0}"
            @keypress="${(e,t)=>e.keypressHandler(t.event)}"
            @click="${(e,t)=>e.clickHandler(t.event)}"
        >
            <label
                part="label"
                class="${e=>e.defaultSlottedNodes&&e.defaultSlottedNodes.length?"label":"label label__hidden"}"
            >
                <slot ${(0,H.e)("defaultSlottedNodes")}></slot>
            </label>
            <div part="switch" class="switch">
                <slot name="switch">${(0,E.R)(e.switch)}</slot>
            </div>
            <span class="status-message" part="status-message">
                <span class="checked-message" part="checked-message">
                    <slot name="checked-message"></slot>
                </span>
                <span class="unchecked-message" part="unchecked-message">
                    <slot name="unchecked-message"></slot>
                </span>
            </span>
        </template>
    `}({switch:B.qy`
        <span class="checked-indicator" part="checked-indicator"></span>
    `}),I=class extends u{}.compose({name:`${h.c.prefix}-switch`,template:F,styles:z})},43774(e,t,i){i.d(t,{p4(){return b},ls(){return g},vA(){return v},nF(){return p}});var r=i(45755),o=i(68009),n=i(95239);const{create:a}=r.G,s=a("neutral-stroke-strong-hover-delta",40),l=a("neutral-stroke-strong-active-delta",16),d=a("neutral-stroke-strong-focus-delta",25);var c=i(31023);const{create:u}=r.G,h=u({name:"neutral-stroke-strong-recipe"},{evaluate(e){return function(e,t,i,r,n,a){const s=(0,o.F)(t),l=e.colorContrast(t,i),d=e.closestIndexOf(l);return{rest:l,hover:e.get(d+s*r),active:e.get(d+s*n),focus:e.get(d+s*a)}}(e(c.r),e(n.p),3,e(s),e(l),e(d))}}),p=u("neutral-stroke-strong-rest",e=>e(h).evaluate(e).rest),v=u("neutral-stroke-strong-hover",e=>e(h).evaluate(e).hover),b=u("neutral-stroke-strong-active",e=>e(h).evaluate(e).active),g=u("neutral-stroke-strong-focus",e=>e(h).evaluate(e).focus)},47264(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20"><path d="M6 10a1.25 1.25 0 1 1-2.5 0A1.25 1.25 0 0 1 6 10zM11.25 10a1.25 1.25 0 1 1-2.5 0 1.25 1.25 0 0 1 2.5 0zM15.25 11.25a1.25 1.25 0 1 0 0-2.5 1.25 1.25 0 0 0 0 2.5z"/></svg>'},49116(e,t,i){i.d(t,{sq(){return u},KY(){return h},YS(){return p},Tp(){return v}});var r=i(97266),o=i(77809),n=i(62745);class a{constructor(e,t,i){this.timeLocStrings=e,this.locale=t,this.locUtility=i}transform(e,t,i){const r=3600,a=86400;if(!e)return"";if(!this.locUtility.supportsLocaleSpecifiers)return t;const s=(0,n.KU)(e);switch((0,n.vB)(e)){case o.H.None:return"";case o.H.JustNow:return this.timeLocStrings.JustNow;case o.H.LessThanOneHour:return this.timespanString(s,s<120?this.timeLocStrings.NumberMinuteAgo:this.timeLocStrings.NumberMinutesAgo,60);case o.H.Today:return this.timespanString(s,s<7200?this.timeLocStrings.NumberHourAgo:this.timeLocStrings.NumberHoursAgo,r);case o.H.Yesterday:if(0===i){const t=this.timeLocStrings.TimeYesterday;return this.locUtility.format(t,this.locUtility.formatTimeFromDate(e,this.locale))}return s<a?this.timespanString(s,s<7200?this.timeLocStrings.NumberHourAgo:this.timeLocStrings.NumberHoursAgo,r):this.timespanString(s,s<172800?this.timeLocStrings.NumberDayAgo:this.timeLocStrings.NumberDaysAgo,a);case o.H.ThisWeek:return 0===i?this.locUtility.format(this.timeLocStrings.TimeDayOfWeek,this.locUtility.localizedWeekday(e,this.locale),this.locUtility.formatTimeFromDate(e,this.locale)):this.timespanString(s,s<172800?this.timeLocStrings.NumberDayAgo:this.timeLocStrings.NumberDaysAgo,a);case o.H.ThisYear:return this.locUtility.localizedMonthDate(e,this.locale);default:return this.locUtility.localizedDateStringMedium(e,this.locale)}}timespanString(e,t,i){const r=Math.floor(e/i);return this.locUtility.format(t,this.locUtility.localizedNumberString(r,this.locale))}}const s={JustNow:"Just Now",JustNowSimple:"now",NumberMinuteAgo:"{0} minute ago",NumberMinutesAgo:"{0} minutes ago",NumberMinutesAgoSimple:"{0}m",NumberMinutesAgoAria:"{0} minutes",NumberHourAgo:"{0} hour ago",NumberHoursAgo:"{0} hours ago",NumberHoursAgoSimple:"{0}h",NumberHoursAgoAria:"{0} hours",NumberDayAgo:"{0} day ago",NumberDaysAgo:"{0} days ago",NumberDaysAgoSimple:"{0}d",NumberDaysAgoAria:"{0} days",NumberWeekAgo:"{0} week",NumberWeeksAgo:"{0} weeks",NumberWeeksAgoSimple:"{0}w",NumberWeeksAgoAria:"{0} weeks",NumberMonthAgo:"{0} month",NumberMonthsAgo:"{0} months",NumberMonthsAgoSimple:"{0}mo",NumberMonthsAgoAria:"{0} months",NumberYearAgo:"{0} year",NumberYearsAgo:"{0} years",NumberYearsAgoSimple:"{0}y",NumberYearsAgoAria:"{0} years",TimeYesterday:"Yesterday at {0}",TimeDayOfWeek:"{0} at {1}"},l={Minute:{one:"{0} دقيقة",two:"دقيقتان",threeToTen:"{0} دقائق",elevenPlus:"{0} دقيقة"},Hour:{one:"{0} ساعة",two:"ساعتان",threeToTen:"{0} ساعات",elevenPlus:"{0} ساعة"},Day:{one:"{0} يوم",two:"يومان",threeToTen:"{0} أيام",elevenPlus:"{0} يوما"},Week:{one:"{0} أسبوع",two:"{0} أسبوع",threeToTen:"{0} أسابيع",elevenPlus:"{0} أسبوعا"},Month:{one:"{0} شهر",two:"{0} شهر",threeToTen:"{0} أشهر",elevenPlus:"{0} شهرا"},Year:{one:"{0} عام",two:"{0} عام",threeToTen:"{0} أعوام",elevenPlus:"{0} عاما"}},d={Week:{one:"{0} שבוע",two:"{0} שבועיים",three:"{0} שבועות"},Month:{one:"{0} חודש",two:"{0} חודשיים",three:"{0} חודשים"},Year:{one:"{0} שנה",two:"{0} שנתיים",three:"{0} שנים"}},c={MsPerMinute:6e4,MsPerHour:36e5,MsPerDay:864e5,MsPerWeek:6048e5,MsPerMonth:2592e6,MsPerYear:31104e6};function u(e,t,i,o,n,u,h,p){const v=t&&t.toLowerCase();if(!(e instanceof Date)||isNaN(e.valueOf()))return"";if(u&&i)return function(e,t,i,r,o,n){if(!(e instanceof Date)||isNaN(e.valueOf()))return"";const a=c.MsPerMinute,s=c.MsPerHour,u=c.MsPerDay,h=c.MsPerWeek,p=c.MsPerMonth,v=c.MsPerYear,b=t.getTime()-e.getTime();if(b<a)return n?i.JustNowAria||"":o?i.JustNowSimple||"":i.JustNow||"";let g=v,m="Year";b<s?(g=a,m="Minute"):b<u?(g=s,m="Hour"):b<h?(g=u,m="Day"):b<p?(g=h,m="Week"):b<v&&(g=p,m="Month");const x=/^[Aa][Rr]-/.test(r),$=/^[Hh][Ee]-/.test(r),f=Math.floor(b/g);let w=null;w=x?function(e,t){if(e<2)return l[t].one;if(e<3)return l[t].two;if(e<11)return l[t].threeToTen;return l[t].elevenPlus}(f,m):$?function(e,t,i,r){if(r||"Minute"==i||"Hour"==i||"Day"==i)return e[`Number${i}${t>1||r?"s":""}Ago${r?"Simple":""}`];if(t<2)return d[i].one;if(t<3)return d[i].two;return d[i].three}(i,f,m,o):n?i[`Number${m}sAgoAria`]:i[`Number${m}${f>1||o?"s":""}Ago${o?"Simple":""}`];return w?w.replace("{0}",f):""}(e,new Date,i,v,h,p);if(!i&&"zh-cn"===v)return"";i||(i=s);const b=(n=n||new r.e).localizedDateString(e,v);o||(o=0);return new a(i,v,n).transform(e,b,o)}function h(e){return e.toLocaleString("ja-JP",{hour12:!1,hour:"2-digit",minute:"2-digit",day:"2-digit",month:"2-digit",timeZone:"Asia/Tokyo"}).replace("午後","").replace("午前","")}function p(e){return v(e,30)}function v(e,t){if(!e)return!0;if(!t||t<0)return!1;try{const i=new Date(e);if(isNaN(i.getTime()))return!0;const r=(new Date).getTime()-i.getTime();return Math.floor(r/c.MsPerDay)>=t}catch{return!0}}},61772(e,t,i){i.d(t,{j(){return x}});var r=i(56911),o=i(2958),n=i(37180),a=i(7014),s=i(92011),l=i(38493);class d extends s.L{}(0,r.Cg)([l.CF],d.prototype,"userSubscriptionData",void 0),(0,r.Cg)([l.CF],d.prototype,"cardSize",void 0);var c=i(74849),u=i(25109),h=i(24458);const p=c.A`
.badge{border-radius:4px;font-size:8px}.badge svg{margin-inline-end:6px}.true{background:linear-gradient(90deg,#5051D1 0%,#797AF5 100%);padding:2px 6px 3px 8px;color:#FFFFFF}.false{background:${(0,u.ud)()?"linear-gradient(90deg, rgba(255, 255, 255, 0.88) 0%, rgba(255, 255, 255, 0.78) 100%)":"linear-gradient(90deg, rgba(0, 0, 0, 0.64) 0%, rgba(0, 0, 0, 0.46) 100%)"};
    display: flex;
    padding: 2px 6px 3px 8px;
    color: ${h.m_}}._1x_2y{display:inline-flex;margin-bottom:6px}._2x_2y{position:absolute;top:16px}`;var v=i(96950),b=i(69259);const g=v.qy`<svg width="8" height="10" xmlns="http://www.w3.org/2000/svg"><path d="M3.874.816 4 .813c1.097 0 1.994.856 2.059 1.936l.003.126v.375h.563c.621 0 1.125.504 1.125 1.125v4.5C7.75 9.496 7.246 10 6.625 10h-5.25A1.125 1.125 0 0 1 .25 8.875v-4.5c0-.621.504-1.125 1.125-1.125h.563v-.375c0-1.097.856-1.994 1.936-2.059L4 .813l-.126.003ZM4 5.875a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm.096-3.933L4 1.938a.938.938 0 0 0-.933.841l-.005.096v.375h1.876v-.375a.938.938 0 0 0-.842-.933L4 1.938l.096.004Z" fill="currentColor"/></svg>`,m=v.qy`<div class="badge ${e=>e.userSubscriptionData.isSubscribed?"true":"false"} ${e=>"_1x_2y"==e.cardSize?"_1x_2y":"_2x_2y"}">${(0,b.z)(e=>!e.userSubscriptionData.isSubscribed,v.qy` ${g}<b>${e=>{var t;return null===(t=e.userSubscriptionData)||void 0===t||null===(t=t.subscribeToViewText)||void 0===t?void 0:t.toLocaleUpperCase()}}</b>`)} ${(0,b.z)(e=>e.userSubscriptionData.isSubscribed,v.qy`<b>${e=>{var t;return null===(t=e.userSubscriptionData)||void 0===t||null===(t=t.subscribedText)||void 0===t?void 0:t.toLocaleUpperCase()}}</b>`)}</div>`;let x=class extends d{};x=(0,r.Cg)([(0,s.E)({name:"msn-subscription-badge",template:m,styles:p})],x),o.m.define(n.c.registry),a.m.define(n.c.registry)},62745(e,t,i){i.d(t,{KU(){return l},LY(){return c},_u(){return u},vB(){return h}});var r=i(77809);const o=3600,n=120,a=new RegExp("\\:([\\d]{2})");function s(){return new Date}function l(e){return(s().getTime()-e.getTime())/1e3}function d(e,t){return new Date(e.getFullYear(),e.getMonth(),e.getDate()+t,e.getHours(),e.getMinutes(),e.getSeconds(),e.getMilliseconds())}function c(e,t){return new Date(e.valueOf()+60*t*60*1e3)}function u(e,t){const i=parseInt(t),r=parseInt(a.exec(t)[1]),o=i<0?-1:1,n=new Date(e.getTime()+60*(60*i+o*r)*1e3),s=`0${Math.abs(i)}`.substr(-2)+":"+`0${Math.abs(r)}`.substr(-2);return n.toISOString().replace("Z",(o<0?"-":"+")+s)}function h(e){const t=l(e),i=function(){const e=s();return e.setHours(0,0,0,0),e}(),a=d(i,-1),c=d(i,-6),u=function(){const e=s();return new Date(e.getFullYear(),0,0,0,0,0,0)}();return t>=-3300&&t<-60?r.H.InMinutes:t<0?r.H.None:t<n?r.H.JustNow:t<o?r.H.LessThanOneHour:e>=i?r.H.Today:e>=a?r.H.Yesterday:e>=c?r.H.ThisWeek:e>=u?r.H.ThisYear:r.H.FullDate}},77809(e,t,i){var r;i.d(t,{H(){return r}}),function(e){e[e.None=0]="None",e[e.JustNow=1]="JustNow",e[e.LessThanOneHour=2]="LessThanOneHour",e[e.Today=3]="Today",e[e.Yesterday=4]="Yesterday",e[e.ThisWeek=5]="ThisWeek",e[e.ThisYear=6]="ThisYear",e[e.FullDate=7]="FullDate",e[e.InMinutes=8]="InMinutes"}(r||(r={}))},80541(e,t){t.A='<svg width="17" height="17" viewBox="0 0 17 17"><path d="M.02 5.88A8.5 8.5 0 0 1 1.8 2.8a.5.5 0 0 1 .54-.13l1.92.68a1 1 0 0 0 1.32-.76l.37-2a.5.5 0 0 1 .39-.4 8.53 8.53 0 0 1 3.55 0 .5.5 0 0 1 .39.4l.37 2a1 1 0 0 0 1.32.76l1.91-.68a.5.5 0 0 1 .54.13 8.5 8.5 0 0 1 1.78 3.08.5.5 0 0 1-.15.54L14.5 7.74a1 1 0 0 0 0 1.52l1.55 1.32a.5.5 0 0 1 .15.54 8.5 8.5 0 0 1-1.78 3.08.5.5 0 0 1-.54.13l-1.91-.68a1 1 0 0 0-1.32.76l-.37 2a.5.5 0 0 1-.39.4 8.53 8.53 0 0 1-3.55 0 .5.5 0 0 1-.4-.4l-.36-2a1 1 0 0 0-1.32-.76l-1.92.68a.5.5 0 0 1-.54-.13 8.49 8.49 0 0 1-1.78-3.08.5.5 0 0 1 .16-.54l1.55-1.32a1 1 0 0 0 0-1.52L.18 6.42a.5.5 0 0 1-.16-.54Zm1.06 0 1.3 1.1a2 2 0 0 1 0 3.04l-1.3 1.1c.3.79.72 1.51 1.25 2.16l1.6-.58a2 2 0 0 1 2.64 1.53l.3 1.67a7.56 7.56 0 0 0 2.49 0l.3-1.67a2 2 0 0 1 2.64-1.53l1.6.57a7.5 7.5 0 0 0 1.24-2.15l-1.29-1.1a2 2 0 0 1 0-3.05l1.3-1.1a7.5 7.5 0 0 0-1.25-2.15l-1.6.57a2 2 0 0 1-2.64-1.52l-.3-1.67a7.55 7.55 0 0 0-2.49 0l-.3 1.67A2 2 0 0 1 3.93 4.3l-1.6-.57a7.5 7.5 0 0 0-1.25 2.15ZM5.62 8.5a2.5 2.5 0 1 1 5 0 2.5 2.5 0 0 1-5 0Zm1 0a1.5 1.5 0 1 0 3 0 1.5 1.5 0 0 0-3 0Z" fill-opacity=".83"/></svg>'},94041(e,t,i){i.r(t),i.d(t,{PremiumProfilePromoCard(){return D},PremiumProfilePromoCardStyles(){return G},PremiumProfilePromoCardTemplate(){return R},ToolingInfo(){return Q}});var r=i(2958),o=i(37180),n=i(4731),a=i(7014);const s={socialAvatar:{instanceId:"socialAvatar",configRef:{experienceType:"SocialAvatar",instanceSrc:"default",sharedNs:"msn-ns"}},localizedStrings:{subscribeButtonText:"Subscribe to {providerName}",seeMoreStoriesText:"See more stories",subscribeButtonAriaLabel:"Subscribe button",subscriptionWord:"Subscription",viewProfileText:"View profile",ariaLabelShowMoreButton:"Show More",ariaLabelPreviousArrow:"Previous",ariaLabelNextArrow:"Next",subscribeToViewBadgeText:"SUBSCRIBE TO VIEW",subscribedBadgeText:"SUBSCRIBED",ariaLabelHideThisCard:"Hide this card",ariaLabelMoreOptions:"More options",ariaLabelHidePublisher:"Hide stories from {publisherName}"}};var l,d=i(56911),c=i(48566),u=i(39671),h=i(38493),p=i(60815),v=i(12680),b=i(49116),g=i(22341),m=i(93552);!function(e){e.LATimes="LATimes"}(l||(l={}));const x={"vid-ksdbkre0pxrdbnxqmr5xbyu056sdgdim5cna8urvbu45yi3x7jqs":l.LATimes},$={[l.LATimes]:"Discover the West Coast perspective and subscribe"},f={};var w=i(80541),k=i(93557),y=i(44853),A=i(57702),M=i(85349),S=i(77367),N=(i(84742),i(41065)),P=i(19359),T=i(40865);class D extends u.U{constructor(){super(...arguments),this.activePageIndex=0,this.isActionMenuOpen=!1,this.shouldRender=!1,this.onOutsideClick=e=>{var t;e.target instanceof D||(0,T.W)(this.actionsMenuButtonElement,null===(t=e.composedPath())||void 0===t?void 0:t[0])||this.toggleActionMenu(!1,null)},this.onKeydown=e=>{"Escape"===e.key&&this.toggleActionMenu(!1,null)},this.hidePublisherCallback=async e=>{try{await(0,A.J6)().Mute(e)&&this.refreshFeed&&this.refreshFeed(),this.toggleActionMenu(!1,null)}catch(t){(0,g.c_)(t,m.H6Q,`Error occured when hiding provider with id: ${e}}`)}}}async experienceConnected(){var e;const t=null===(e=this.profileMetadata)||void 0===e||null===(e=e.provider)||void 0===e?void 0:e.providerType;this.telemetryContext=((e,t)=>{var i;const r=null==e||null===(i=e.contract)||void 0===i?void 0:i.ext,o=(0,N.u)("ProfilePromoCardContainer",{ext:r}),n=(0,P.g)("PremiumPromoCard",{providerType:t||"publisher"},{ext:r}),a=(0,P.g)("MutePublisher",{headline:"MutePublisher"},M.MS.Hide,M.EG.Click,r,{type:M.MJ.ActionButton}),s=(0,P.g)("PreviousSlideArrow",{headline:"previousSlideArrow"},M.MS.More,M.EG.Click,r,{type:M.MJ.ActionButton}),l=(0,P.g)("NextSlideArrow",{headline:"nextSlideArrow"},M.MS.More,M.EG.Click,r,{type:M.MJ.ActionButton}),d=(0,P.l)("ViewPublisher",{headline:"ViewPublisher"},M.MS.Navigate,M.EG.Click,M.MJ.ActionButton),c=(0,P.g)("SeeMore",{headline:"SeeMore"},M.MS.More,M.EG.Click,r,{type:M.MJ.DropDown}),u=(0,P.g)("MoreOptions",{headline:"MoreOptions"},M.MS.More,M.EG.Click,r,{type:M.MJ.ActionButton}),h=(0,P.g)("Hide",{headline:"Hide"},M.MS.Hide,M.EG.Click,r,{type:M.MJ.ActionButton});return{componentRoot:o,container:n,contentLink:(e,i,o)=>(0,P.g)("destination",{id:e,headline:i,isLocal:o,providerType:t||"publisher"},M.MS.Navigate,{ext:r}),seeMoreStoriesButton:(e,t)=>(0,P.g)("SeeMoreStories",{id:e,headline:t},M.MS.Navigate,{ext:r}),previousSlideArrow:s,nextSlideArrow:l,subscribeButton:(e,t)=>(0,P.g)("Subscribe",{id:e,headline:t},M.MS.Navigate,{ext:r}),profileLink:(e,i)=>(0,P.g)("PublisherAvatarLink",{id:e,headline:i,providerType:t||"publisher"},M.MS.Navigate,{ext:r}),viewProfileButton:d,seeMore:c,moreOptionsButton:u,hideCardButton:h,hidePublisherButton:a}})(this.parentTelemetryObject,t),this.actionsMenuProps=this.generateActionsMenuProps(),await this.fetchData()}shadowDomPopulated(){this.prepareCarouselData(),this.isFree=this.cardData.isFree,this.shouldRender=!0}getExperienceType(){return v.VMF}async fetchData(){this.profileMetadata&&(this.me=await k.l.fetchMe(!1),this.isUserSubscribed=await(0,y.uS)(this.me,{id:this.profileMetadata.id}))}prepareCarouselData(){this.profileMetadata&&(this.premiumProvider=this.premiumProvider||(e=>{var t,i;if(null!=e&&null!==(t=e.provider)&&void 0!==t&&t.profileId)return x[null==e||null===(i=e.provider)||void 0===i?void 0:i.profileId]})(this.profileMetadata),this.cardData=((e,t,i)=>{if(!i)return;let r=!0;try{var o;const n=e.subCards.slice(0,6).map(e=>("premium"==e.subscriptionProductType.toLowerCase()&&(r=!1),{id:e.id,title:e.title,imageUrl:e.images&&e.images[0]&&`${e.images[0].url}?w=50&h=50&q=100&m=6&f=png&u=t`,publishedAgoText:e.publishedDateTime&&(0,b.sq)(new Date(e.publishedDateTime),e.locale,null,1),subscriptionBadgeData:{isSubscribed:!1,subscribeToViewText:null==t?void 0:t.subscribeToViewBadgeText,subscribedText:null==t?void 0:t.subscribedBadgeText},url:e.url})),a=[];for(let e=0;e<Math.floor(n.length/2);e++)a[e]=[n[2*e],n[2*e+1]];const s=`https://www.msn.com/${e.locale}/community/channel/${e.provider.profileId}`;return{id:e.id,name:e.title,avatarUrl:null===(o=e.provider.image)||void 0===o?void 0:o.url,isFollowing:null,isFree:r,profileId:e.provider.profileId,profileUrl:s,premiumProvider:i,promoStrings:{title:$[i],description:f[i]},subscribeButtonLabel:c.Qf.Format((null==t?void 0:t.subscribeButtonText)||"",{providerName:e.title}),subscribeUrl:`${s}?openSubscriptionPanel`,contentGroupedList:a}}catch(e){return void(0,g.c_)(e,m.H6Q,"Error in PremiumProfilePromoCardDataMapper")}})(this.profileMetadata,this.strings,this.premiumProvider),this.actionsMenuProps=this.generateActionsMenuProps(),this.premiumProvider==l.LATimes&&S.YT.addOrUpdateTmplProperty("LATIMES1UCARD","1"))}generateActionsMenuProps(){const e={menuItems:[{id:"more",glyph:w.A,title:this.strings.ariaLabelMoreOptions,telemetryTag:this.telemetryContext&&this.telemetryContext.moreOptionsButton&&this.telemetryContext.moreOptionsButton.getMetadataTag(),onClick:()=>{this.goToPersonalizeCallback&&this.goToPersonalizeCallback()}}]},{id:t,name:i}=this.cardData||{};return t&&i&&e.menuItems.push({id:"hideSource",glyph:'<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M16 5v8.88l-1-1V6h-1v5.88l-1-1V4h-1v5.88l-1-1V2H4.12l-1-1H12v2h2v2h2Zm-5.13 8 1 1H4v-2H2v-2H0V2.12l1 1V9h5.88l1 1H3v1h5.88l1 1H5v1h5.88ZM1.36.65l14 14-.7.7-14-14 .7-.7Z"/></svg>',title:c.Qf.Format(this.strings.ariaLabelHidePublisher,{publisherName:i}),telemetryTag:this.telemetryContext&&this.telemetryContext.hidePublisherButton&&this.telemetryContext.hidePublisherButton.getMetadataTag(),onClick:()=>{this.hidePublisherCallback(t)}}),e}toggleActionMenu(e,t){this.isActionMenuOpen=e,this.isActionMenuOpen?(this.actionsMenuButtonElement=t&&t.currentTarget,document.addEventListener("click",this.onOutsideClick),document.addEventListener("keydown",this.onKeydown)):(this.actionsMenuButtonElement=null,document.removeEventListener("click",this.onOutsideClick),document.removeEventListener("keydown",this.onKeydown))}onArrowClick(e){!e&&0==this.activePageIndex||e&&this.activePageIndex>=this.cardData.contentGroupedList.length||(e?this.activePageIndex++:this.activePageIndex--,this.listSlideElement.style.transform="translateX("+308*-this.activePageIndex+"px)")}}(0,d.Cg)([h.CF],D.prototype,"profileMetadata",void 0),(0,d.Cg)([h.CF],D.prototype,"premiumProvider",void 0),(0,d.Cg)([(0,h.CF)({mode:"boolean"})],D.prototype,"isFree",void 0),(0,d.Cg)([p.sH],D.prototype,"activePageIndex",void 0),(0,d.Cg)([p.sH],D.prototype,"listSlideElement",void 0),(0,d.Cg)([p.sH],D.prototype,"cardData",void 0),(0,d.Cg)([p.sH],D.prototype,"isActionMenuOpen",void 0),(0,d.Cg)([p.sH],D.prototype,"shouldRender",void 0),(0,d.Cg)([p.sH],D.prototype,"isUserSubscribed",void 0),(0,d.Cg)([p.sH],D.prototype,"me",void 0),(0,d.Cg)([p.sH],D.prototype,"telemetryContext",void 0);var C=i(96950),L=i(69259),z=i(60402),B=i(39957),H=i(99002),E=i(47264),F=i(73182),I=i(61772),_=i(65055);function W(e,t){return{...e,instanceId:t}}F.MsnActionsMenu,I.j;const Y=C.qy`<svg width="10" height="8" viewBox="0 0 10 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.5 4C0.5 3.72386 0.723857 3.5 1 3.5L7.79289 3.5L5.14645 0.853553C4.95118 0.658291 4.95118 0.341708 5.14645 0.146447C5.34171 -0.0488159 5.65829 -0.048816 5.85355 0.146446L9.35355 3.64645C9.54882 3.84171 9.54882 4.15829 9.35355 4.35355L5.85355 7.85355C5.65829 8.04882 5.34171 8.04882 5.14645 7.85355C4.95118 7.65829 4.95118 7.34171 5.14645 7.14645L7.79289 4.5L1 4.5C0.723857 4.5 0.5 4.27614 0.5 4Z" fill="white"/></svg>`,Z=(e,t)=>{var i,r,o,n;const a=e?null===(i=t.strings)||void 0===i?void 0:i.ariaLabelNextArrow:null===(r=t.strings)||void 0===r?void 0:r.ariaLabelPreviousArrow,s=e?null===(o=t.telemetryContext)||void 0===o?void 0:o.nextSlideArrow:null===(n=t.telemetryContext)||void 0===n?void 0:n.previousSlideArrow;return C.qy`<fluent-button appearance="neutral" class="circle-button nav-button ${e?"x-flip":""}" aria-label=${a} role="button" title=${a} @click="${()=>t.onArrowClick(e)}" tabIndex="0" data-t="${null==s?void 0:s.getMetadataTag()}">${C.qy.partial(H.A)}</fluent-button>`},V=C.qy` ${(0,L.z)(e=>e.imageUrl,C.qy`<img alt="Content Picture" class="post-img" src="${e=>e.imageUrl}" width="76" height="76" @error=${(e,t)=>t.event&&((e,t)=>{const i=e.currentTarget;i.onerror=null,t?i.src=t:i.style.display="none"})(t.event,null)} />`)}
`,O=C.qy`<msn-actions-menu :referrerButton=${e=>e.actionsMenuButtonElement} :menuItems=${e=>e.actionsMenuProps.menuItems}></msn-actions-menu>`,j=C.qy`<div class="card ${e=>{var t;return null===(t=e.cardData)||void 0===t?void 0:t.premiumProvider}}" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.container)||void 0===t?void 0:t.getMetadataTag()}}"><div class="container"><div class="header"><div><div class="cwt-avatar-container">${e=>{var t;return(0,_.yN)(W(e.config.socialAvatar,"socialAvatar1"),{memoize:!1,properties:{src:null===(t=e.cardData)||void 0===t?void 0:t.avatarUrl,size:20}})}}</div><div class="header-title">${e=>{var t;return null===(t=e.cardData)||void 0===t?void 0:t.name}}</div></div><div class="more-actions"><fluent-button class= "circle-button option-button" @click=${(e,t)=>e.toggleActionMenu&&e.toggleActionMenu(!e.isActionMenuOpen,t.event)} title=${e=>e.strings.ariaLabelShowMoreButton} aria-label=${e=>e.strings.ariaLabelShowMoreButton} role="button" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.seeMore)||void 0===t?void 0:t.getMetadataTag()}}">${C.qy.partial(E.A)}</fluent-button></div></div><div class="carousel-view-container" ${(0,z.K)("listSlideElement")}>${(0,B.ux)(e=>{var t;return null===(t=e.cardData)||void 0===t?void 0:t.contentGroupedList},C.qy`<div class="carousel-section"><div class="posts-container">${(0,B.ux)((e,t)=>e,C.qy`<a class="post-link" href="${e=>e.url}" target="_blank" tabIndex="${(e,t)=>{var i,r;return(null===(i=t.parentContext)||void 0===i?void 0:i.index)==(null===(r=t.parentContext)||void 0===r||null===(r=r.parent)||void 0===r?void 0:r.activePageIndex)?"0":"-1"}}" data-t="${(e,t)=>{var i;return null==t||null===(i=t.parentContext)||void 0===i||null===(i=i.parent)||void 0===i||null===(i=i.telemetryContext)||void 0===i||null===(i=i.contentLink(e.id,e.title,e.isLocal))||void 0===i?void 0:i.getMetadataTag()}}"><div class="post-detail">${(0,L.z)((e,t)=>!t.parentContext.parent.isFree,C.qy`<div class="post-badge"><msn-subscription-badge :userSubscriptionData="${e=>e.subscriptionBadgeData}"></msn-subscription-badge></div>`)}<div class="post-title">${e=>e.title}</div></div>${e=>V}</a>`)}</div></div>`,{positioning:!0})}<div class="carousel-section"><div class="post-items-container"><div class="posts-container profile-section"><div class="cwt-avatar-container">${e=>{var t,i;return(0,_.yN)(W(e.config.socialAvatar,"socialAvatar2"),{properties:{src:null===(t=e.cardData)||void 0===t?void 0:t.avatarUrl,size:64,link:{url:null===(i=e.cardData)||void 0===i?void 0:i.profileUrl}}})}}</div><div class="profile-section-title">${e=>{var t;return null===(t=e.cardData)||void 0===t||null===(t=t.promoStrings)||void 0===t?void 0:t.title}}</div><div class="profile-section-description">${e=>{var t;return null===(t=e.cardData)||void 0===t||null===(t=t.promoStrings)||void 0===t?void 0:t.description}}</div>${(0,L.z)(e=>!e.isFree&&!e.isUserSubscribed,C.qy`<a class="profile-section-button" aria-label="${e=>{var t;return null===(t=e.strings)||void 0===t?void 0:t.subscribeButtonAriaLabel}}" href="${e=>{var t;return null===(t=e.cardData)||void 0===t?void 0:t.subscribeUrl}}" target="_blank" tabIndex="${(e,t)=>{var i;return e.activePageIndex==(null===(i=e.cardData)||void 0===i?void 0:i.contentGroupedList.length)?"0":"-1"}}" data-t="${e=>{var t,i,r;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.subscribeButton(null===(i=e.cardData)||void 0===i?void 0:i.profileId,null===(r=e.cardData)||void 0===r?void 0:r.name))||void 0===t?void 0:t.getMetadataTag()}}"><fluent-button appearance="accent" id="subscribe"><div class="subscribe-button-text">${e=>{var t;return null===(t=e.cardData)||void 0===t?void 0:t.subscribeButtonLabel}}</div></fluent-button></a>`)} ${(0,L.z)(e=>e.isFree||e.isUserSubscribed,C.qy`<a class="profile-section-button" aria-label="${e=>{var t;return null===(t=e.strings)||void 0===t?void 0:t.viewProfileText}}" href="${e=>{var t;return null===(t=e.cardData)||void 0===t?void 0:t.profileUrl}}" target="_blank" tabIndex="${(e,t)=>{var i;return e.activePageIndex==(null===(i=e.cardData)||void 0===i?void 0:i.contentGroupedList.length)?"0":"-1"}}" data-t="${e=>{var t;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.viewProfileButton)||void 0===t?void 0:t.getMetadataTag()}}"><fluent-button appearance="accent" id="view-profile"><div class="subscribe-button-text">${e=>{var t;return null===(t=e.strings)||void 0===t?void 0:t.viewProfileText}}</div></fluent-button></a>`)}</div></div></div></div><div class="button-section"><div class="carousel-buttons">${(0,L.z)(e=>{var t;return(null===(t=e.cardData)||void 0===t?void 0:t.contentGroupedList.length)>1},C.qy` ${e=>Z(!1,e)}<div class="indicators">${e=>e.activePageIndex+1}/${e=>{var t;return(null===(t=e.cardData)||void 0===t?void 0:t.contentGroupedList.length)+1}}</div>${e=>Z(!0,e)} `)}</div><a class="more-stories-button" aria-label="${e=>{var t;return null===(t=e.strings)||void 0===t?void 0:t.seeMoreStoriesText}}" href="${e=>{var t;return null===(t=e.cardData)||void 0===t?void 0:t.profileUrl}}" target="_blank" tabIndex="${(e,t)=>{var i;return e.activePageIndex==(null===(i=e.cardData)||void 0===i?void 0:i.contentGroupedList.length)?"0":"-1"}}" data-t="${e=>{var t,i,r;return null===(t=e.telemetryContext)||void 0===t||null===(t=t.seeMoreStoriesButton(null===(i=e.cardData)||void 0===i?void 0:i.profileId,null===(r=e.cardData)||void 0===r?void 0:r.name))||void 0===t?void 0:t.getMetadataTag()}}"><fluent-button><span slot="end"><div class="more-stories-icon">${Y}</div></span>${e=>{var t;return null===(t=e.strings)||void 0===t?void 0:t.seeMoreStoriesText}}</fluent-button></a></div></div></div>`,R=C.qy`
${(0,L.z)(e=>e.shouldRender,C.qy` ${(0,L.z)(e=>e.cardData,j)} ${(0,L.z)(e=>e.isActionMenuOpen,O)}
`)}
`;var U=i(48751),J=i(4283),q=i(74849),K=i(22131);const X="\n    display: -webkit-box;\n    -webkit-box-orient: vertical;\n    overflow: hidden;\n    text-overflow: ellipsis;\n    word-break: break-word;\n",G=q.A`
.card{width:300px;height:304px;max-height:304px;border-radius:6px;background:linear-gradient(134.62deg,#E3F2FF 1.14%,#E2DEF8 85.22%);box-shadow:0px 1.6px 3.6px rgba(0,0,0,0.13),0px 0px 2.9px rgba(0,0,0,0.11)}.container{padding-left:16px;padding-right:16px;overflow:hidden;position:relative}.header{display:flex;justify-content:space-between;align-items:center;margin:15px 0px 11px}.header > div{display:flex;align-items:center}.header-profile-img{display:flex;border-radius:6px}.header-title{font-weight:600;font-size:12px;letter-spacing:0.7px;text-transform:uppercase;color:${U.l};
    margin: 0 7px;
    height: 16px;
    opacity: .75;
    -webkit-line-clamp: 1;
    ${X}}.carousel-section{margin:0 8px}.carousel-section-header{display:flex;align-items:center;height:44px}.carousel-view-container{display:flex;transition:all 0.3s ease-in-out 0s;margin:0px -20px}.profile-img{display:flex;border-radius:14px;margin:0 8px}.profile-name-link{font-weight:600;font-size:16px;color:${U.l};
    margin-top: -4px;
    -webkit-line-clamp: 2;
    ${X}}.posts-container{margin:0}.post-detail{width:184px}.post-title{font-weight:600;font-size:14px;color:${U.l};
    margin: 2px 0px;
    -webkit-line-clamp: 3;
    ${X}}.post-img{width:76px;height:76px;border-radius:4px;background-repeat:no-repeat}.post-link{display:flex;justify-content:space-between;width:292px;height:104px;padding:12px 12px 0;box-sizing:border-box}.post-link,.profile-name-link{cursor:pointer;text-decoration:none}.post-link:hover .post-title,.profile-name-link:hover{text-decoration:underline}.post-badge{background:gray;margin:-19px 0 38px;position:relative}.post-time{font-size:12px;color:${U.l};opacity:.55}.view-profile-link:hover{background:${J.OS}}.cwt-avatar-container{filter:drop-shadow(0px 1.5px 2.5px rgb(0 0 0 / 10%));display:flex;justify-content:center}.carousel-buttons{display:flex;align-items:center}.indicators{margin:0 8px;color:${U.l};font-size:12px}.circle-button{min-width:24px;width:24px;height:24px;background:rgba(0,0,0,0.07);border-radius:50%;fill:${U.l}}.circle-button:hover{background:rgba(255,255,255,.5)}.circle-button.x-flip{transform:scaleX(-1)}.button-section{display:flex;margin-top:10px;justify-content:space-between}.more-stories-button{text-decoration:none}.more-stories-button fluent-button{background:none;color:${U.l};font-size:12px;padding:0}.more-stories-button:hover{text-decoration:underline;text-decoration-color:${U.l}}.more-stories-button fluent-button::part(control){padding:0}.more-stories-button fluent-button::part(end){margin-inline-start:8px}.more-stories-icon{background:${J.IR};border-radius:12px;box-sizing:border-box;height:24px;width:24px;padding-top:1px}.profile-section{color:${U.l};margin-top:13px;text-align:center;width:292px}.section-profile-img{border:0.75px solid rgba(0,0,0,0.20);border-radius:20px}.profile-section-title{font-weight:600;font-size:20px;margin-bottom:4px;-webkit-line-clamp:2;${X}}.profile-section-description{font-size:14px;line-height:20px;margin-bottom:8px;-webkit-line-clamp:2;${X}}.profile-section-button{--control-corner-radius:999;text-decoration:none}.subscribe-button-text{font-size:12px;margin:0 10px;-webkit-line-clamp:1;${X}
}

/* THEMES */
.card.${l.LATimes}{background:linear-gradient(136.14deg,#FAF7DE 1.17%,#FDE5C9 85.95%)}`.withBehaviors((0,K.G2)(q.A` .card{background:radial-gradient(101.81% 101.81% at -5% 0%,#0B59C2 0%,#3B3B3B 110%);box-shadow:0px 0px 0.8px rgba(0,0,0,0.13),0px 2px 10px rgba(0,0,0,0.08)}.header-title{opacity:1}.circle-button{background:rgba(255,255,255,0.10)}.card.${l.LATimes}{background:radial-gradient(101.81% 101.81% at -5% 0%,#2D6C82 0%,#213441 110%)}`)),Q={experienceConfigSchema:undefined,mockConfig:s};r.m.define(o.c.registry),n.m.define(o.c.registry),a.m.define(o.c.registry)},97266(e,t,i){i.d(t,{e(){return n}});var r,o=i(48566);!function(e){e[e.Default=0]="Default",e[e.Medium=1]="Medium",e[e.MonthDate=2]="MonthDate",e[e.Weekday=3]="Weekday",e[e.Time=4]="Time"}(r||(r={}));class n{constructor(){this.dateFormatOptionsMap=new Map,this.setSupportsLocaleSpecifiers(),this.dateFormatOptionsMap.set(r.Medium,{year:"numeric",month:"short",day:"numeric"}),this.dateFormatOptionsMap.set(r.MonthDate,{month:"short",day:"numeric"}),this.dateFormatOptionsMap.set(r.Weekday,{weekday:"short"}),this.dateFormatOptionsMap.set(r.Time,{hour:"numeric",minute:"numeric"})}overrideDateFormat(e,t){e&&t&&this.dateFormatOptionsMap.set(e,t)}localizedDateString(e,t){return this.formatDate(e,r.Default,t)}localizedDateStringMedium(e,t){return this.formatDate(e,r.Medium,t)}localizedMonthDate(e,t){return this.formatDate(e,r.MonthDate,t)}localizedWeekday(e,t){return this.formatDate(e,r.Weekday,t)}formatTimeFromDate(e,t){return this.supportsLocaleSpecifiers&&this.dateFormatOptionsMap?e.toLocaleTimeString(t,this.dateFormatOptionsMap.get(r.Time)):e.toTimeString()}format(e){if(!e)return"";for(var t=arguments.length,i=new Array(t>1?t-1:0),r=1;r<t;r++)i[r-1]=arguments[r];return o.Qf.Format(e,...i)}localizedNumberString(e,t){return this.supportsLocaleSpecifiers?e.toLocaleString(t):e.toString()}formatDate(e,t,i){let o=null;if(this.supportsLocaleSpecifiers)if(t===r.Default)o=e.toLocaleDateString(i);else if(this.dateFormatOptionsMap){const r=this.dateFormatOptionsMap.get(t);o=e.toLocaleDateString(i,r)}return null===o&&(o=e.toDateString()),null!==o?o.replace(/\u200E/g,"").replace(/\u200F/g,""):o}setSupportsLocaleSpecifiers(){this.supportsLocaleSpecifiers=(()=>{try{(0).toLocaleString("i")}catch(e){return"RangeError"===e.name}return!1})()}}},99002(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M12.27 15.8a.75.75 0 0 1-1.06-.03l-5-5.25a.75.75 0 0 1 0-1.04l5-5.25a.75.75 0 1 1 1.08 1.04L7.8 10l4.5 4.73c.29.3.28.78-.02 1.06Z" fill="currentcolor"/></svg>'}}]);