"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["cs-core-desktop_responsive-list_dist_index_js","donation-npo-card"],{4968(t,e,o){o.d(e,{f(){return l}});var i=o(64187),a=o(74849),n=o(42792),r=o(99657),s=o(36452);const l=a.A.partial`position: relative; z-index: ${r.D};`;a.A`
    ${n.e}
    ${n.nH}

    ${(0,i.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(n.kc)},22162(t,e,o){var i;o.d(e,{j(){return i}}),function(t){t.image="image",t.provider="provider",t.socialBar="socialBar"}(i||(i={}))},53155(t,e,o){o.r(e),o.d(e,{DonationNpoCard(){return D},DonationNpoCardStyles(){return G},DonationNpoCardTemplate(){return R},ToolingInfo(){return W}});var i,a=o(65614),n=o(66690),r=o(59836),s=o(7574),l=o(56911),d=o(60815),c=o(12680),u=o(39671);!function(t){t[t.SubCategory=1]="SubCategory",t[t.Category=2]="Category",t[t.Trend=3]="Trend",t[t.Hot=4]="Hot"}(i||(i={}));const g={id:"2b359ab3994e4560b71bad4185364c10",type:"DonationNpoCard",dataType:"",data:'[{"CauseId":"840-010211564","RecommendType":1,"CauseName":"UNITED WAY OF ANDROSCOGGIN COUNTY INC","Description":"","CountryCode":"US","Category":"Human Services","CategoryCode":"P","SubCategory":"Human Services - Multipurpose and Other N.E.C.","SubCategoryCode":"P99","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-010211564.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-010241767","RecommendType":2,"CauseName":"United Way of Southern Maine","Description":"","CountryCode":"US","Category":"Philanthropy, Voluntarism, and Grantmaking Foundations","CategoryCode":"T","SubCategory":"Fund Raising Organizations That Cross Categories","SubCategoryCode":"T70","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-010241767.png","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-010418917","RecommendType":3,"CauseName":"PREBLE STREET","Description":"","CountryCode":"US","Category":"Human Services","CategoryCode":"P","SubCategory":"Children\\u0027s, Youth Services","SubCategoryCode":"P30","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-010418917.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-010574950","RecommendType":4,"CauseName":"Akshaya Patra Foundation USA","Description":"","CountryCode":"US","Category":"Food, Agriculture, and Nutrition","CategoryCode":"K","SubCategory":"Food Service, Free Food Distribution Programs","SubCategoryCode":"K30","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-010574950.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-010579687","CauseName":"FRIENDS OF PUBLIC RADIO ARIZONA","Description":"","CountryCode":"US","Category":"Arts, Culture, and Humanities","CategoryCode":"A","SubCategory":"Single Organization Support","SubCategoryCode":"A11","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-010579687.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-016004404","CauseName":"UNITED WAY OF KENNEBEC VALLEY","Description":"","CountryCode":"US","Category":"Philanthropy, Voluntarism, and Grantmaking Foundations","CategoryCode":"T","SubCategory":"Fund Raising Organizations That Cross Categories","SubCategoryCode":"T70","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-016004404.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-020222163","CauseName":"NEW HAMPSHIRE CATHOLIC CHARITIES INC","Description":"","CountryCode":"US","Category":"Human Services","CategoryCode":"P","SubCategory":"Human Service Organizations - Multipurpose","SubCategoryCode":"P20","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-020222163.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-020223323","CauseName":"DOVER CHILDRENS HOME","Description":"","CountryCode":"US","Category":"Human Services","CategoryCode":"P","SubCategory":"Residential, Custodial Care","SubCategoryCode":"P70","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-020223323.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-020226943","CauseName":"Gather","Description":"","CountryCode":"US","Category":"Human Services","CategoryCode":"P","SubCategory":"Human Service Organizations - Multipurpose","SubCategoryCode":"P20","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-020226943.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-020236885","CauseName":"MONADNOCK UNITED WAY INC","Description":"","CountryCode":"US","Category":"Human Services","CategoryCode":"P","SubCategory":"Human Services - Multipurpose and Other N.E.C.","SubCategoryCode":"P99","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-020236885.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-020348477","CauseName":"BIG BROTHERS BIG SISTERS OF New Hampshire","Description":"","CountryCode":"US","Category":"Youth Development","CategoryCode":"O","SubCategory":"Big Brothers, Big Sisters","SubCategoryCode":"O31","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-020348477.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-020359239","CauseName":"NASHUA SOUP KITCHEN AND SHELTER INCORPORATED","Description":"","CountryCode":"US","Category":"Food, Agriculture, and Nutrition","CategoryCode":"K","SubCategory":"Congregate Meals","SubCategoryCode":"K34","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-020359239.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-020405369","CauseName":"MAKE A WISH OF NEW HAMPSHIRE INC","Description":"","CountryCode":"US","Category":"Arts, Culture, and Humanities","CategoryCode":"A","SubCategory":"Arts, Culture, and Humanities N.E.C.","SubCategoryCode":"A99","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-020405369.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-020407497","CauseName":"MY FRIENDS PLACE INC","Description":"","CountryCode":"US","Category":"Housing and Shelter","CategoryCode":"L","SubCategory":"Homeless, Temporary Shelter For","SubCategoryCode":"L41","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-020407497.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true},{"CauseId":"840-020554654","CauseName":"STEPHEN SILLER TUNNEL TO TOWERS FOUNDATION","Description":"","CountryCode":"US","Category":"Housing and Shelter","CategoryCode":"L","SubCategory":"","SubCategoryCode":"L20","LogoUrl":"https://logos.benevity.org/400x400/public/clogos/840-020554654.jpg","TransactionUtcTime":"11/24/2023 10:05:02 AM \\u002B00:00","Metadata":"","IsReadOnly":true}]',galleryItemCount:0,isLocalContent:!1,position:0,subCards:[]};var p=o(33477);const h={1:"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/donation/npo-default-logo-1.png",2:"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/donation/npo-default-logo-2.png",3:"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/donation/npo-default-logo-3.png",4:"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/donation/npo-default-logo-4.png",5:"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/donation/npo-default-logo-5.png",6:"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/donation/npo-default-logo-6.png",7:"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/donation/npo-default-logo-7.png",8:"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/donation/npo-default-logo-8.png"};var v=o(85349);const C="destination",b="previousSlideArrow",m="nextSlideArrow",y="seeMoreNonprofits",x={name:"DonationNpoCard",content:{type:v.b5.StructuredData}},S={name:C,action:v.EG.Click,behavior:v.MS.Navigate,content:{type:v.b5.StructuredData}},f={name:b,action:v.EG.Click,behavior:v.MS.Paginate,content:{type:v.b5.StructuredData}},I={name:m,action:v.EG.Click,behavior:v.MS.Paginate,content:{type:v.b5.StructuredData}},T={name:y,action:v.EG.Click,behavior:v.MS.Navigate,content:{type:v.b5.StructuredData}},w=["USA","US","UN","UK","ACLU","UNICEF","LLS","NAACP","AT&T","AARP"],$=t=>{const e=(t||"").split("").reduce((t,e)=>t+e.toLocaleLowerCase().charCodeAt(0),0)%8+1;return h[e]};var N=o(71398),A=o(29658),U=o(22341),k=o(93552);class D extends u.U{constructor(){super(...arguments),this.listLength=3,this.npoDataLength=15,this.currentIndex=0,this.generateTelemetryObject=()=>{var t;this.cardTelemetryObject=null===(t=this.telemetryObject)||void 0===t?void 0:t.addOrUpdateChild(x)},this.extractFeedData=()=>{var t,e;this.mapperArgs?(this.cardMetadata=null===(t=this.mapperArgs)||void 0===t?void 0:t.cardMetadata,this.donationData=this.dealWithData(),this.npoDataLength=null===(e=this.donationData)||void 0===e||null===(e=e.subCards)||void 0===e?void 0:e.length):(this.cardMetadata=g,this.donationData=this.dealWithData())},this.dealWithData=()=>{try{var t;const e=JSON.parse(null===(t=this.cardMetadata)||void 0===t?void 0:t.data);return{subCards:e.map(t=>{const e=t.RecommendType,o=null==(a=t.CauseName)||null===(n=a.split)||void 0===n||null===(n=n.call(a," "))||void 0===n||null===(r=n.map)||void 0===r||null===(r=r.call(n,t=>{var e,o;return w.includes(null==t?void 0:t.toUpperCase())?null==t?void 0:t.toUpperCase():(null==t||null===(e=t[0])||void 0===e?void 0:e.toUpperCase())+(null==t||null===(o=t.slice)||void 0===o||null===(o=o.call(t,1))||void 0===o?void 0:o.toLowerCase())}))||void 0===r||null===(s=r.join)||void 0===s?void 0:s.call(r," ");var a,n,r,s;let l=t.Category;switch(e){case i.SubCategory:l=this.strings.recommendSameSubCategoryNpo;break;case i.Category:l=this.strings.recommendSameCategoryNpo;break;case i.Trend:l=this.strings.recommendHotTrendingNpo}return{id:t.CauseId,causeId:t.CauseId,causeName:o,description:l,category:t.Category,subCategory:t.SubCategory,logo:t.LogoUrl?t.LogoUrl:$(o)}})}}catch(t){return(0,U.c_)(t,k.Opc,"Failed to parse this.mapperArgs?.cardMetadata of DonationNpoCard"),{subCards:[]}}},this.reloadPaginationData=()=>{var t,e;this.superCardData&&this.superCardData.footerData&&this.superCardData.footerData.paginationData&&(this.superCardData={...this.superCardData,footerData:{...null===(t=this.superCardData)||void 0===t?void 0:t.footerData,paginationData:{...null===(e=this.superCardData)||void 0===e||null===(e=e.footerData)||void 0===e?void 0:e.paginationData,currentPageIndex:this.currentIndex/this.listLength+1}}})},this.getChildTelemetry=t=>{var e;return this.cardTelemetryObject&&this.cardTelemetryObject.addOrUpdateChild({...t,ext:{...null===(e=this.cardTelemetryObject)||void 0===e||null===(e=e.contract)||void 0===e?void 0:e.ext,...null==t?void 0:t.ext}})},this.preloadImages=()=>{this.donationData&&this.donationData.subCards.forEach(t=>{(new Image).src=t.logo})},this.onNpoItemClick=t=>{var e;const o=(null===(e=this.config)||void 0===e?void 0:e.headTitleHref)+`/explore?source=ntpSdCard&npoid=${t.causeId}`;window.open(o,"_blank")},this.onFlipperClick=(t,e)=>{t?(this.currentIndex+=this.listLength,this.currentIndex>=this.npoDataLength&&(this.currentIndex=0)):(this.currentIndex-=this.listLength,this.currentIndex<0&&(this.currentIndex+=this.npoDataLength)),this.reloadPaginationData()},this.onDotClick=(t,e)=>{this.currentIndex=t*this.listLength,this.reloadPaginationData()},this.onHeaderButtonClick=()=>{var t;const e=(null===(t=this.config)||void 0===t?void 0:t.headTitleHref)+"?source=ntpSdCard";window.open(e,"_blank")},this.onFooterButtonClick=()=>{var t;const e=(null===(t=this.config)||void 0===t?void 0:t.headTitleHref)+"/explore?source=ntpSdCard";window.open(e,"_blank")},this.onActionMenuHideClick=async()=>{try{let e=!1;var t;if(e=await N.d.updateSegmentCardsEnableStatus([{cardType:A.s.DonationNpoCard,enabled:!1}]),e)null!==(t=this.mapperArgs)&&void 0!==t&&t.refreshSDCardSection?this.mapperArgs.refreshSDCardSection():this.$emit("refreshSDCardSection");return e}catch(t){return(0,U.c_)(t,k.QsG,"Failed to disable DonationNpoCard sd card"),!1}},this.onActionMenuMoreSettingClick=()=>{var t;null!==(t=this.mapperArgs)&&void 0!==t&&t.goToPersonalizeSettingsCallback?this.mapperArgs.goToPersonalizeSettingsCallback():this.$emit("goToPersonalizeSettingsCallback")}}get currentSubCards(){var t;return null===(t=this.donationData)||void 0===t||null===(t=t.subCards)||void 0===t?void 0:t.slice(this.currentIndex,this.currentIndex+this.listLength)}experienceConnected(){var t;this.extractFeedData(),this.preloadImages(),this.generateTelemetryObject(),this.superCardData={id:(t=this).id,gridArea:"",childTemplateType:"",cardSize:p.uE._1x_2y,headerData:{headerLogo:"https://assets.msn.com/staticsb/statics/latest/icons-wc/icons/donation/DonationHeartIcon.svg",isEventCard:!0,title:t.strings.headTitle2,titleNavigationLink:"",onHeaderTitleClick:t.onHeaderButtonClick,actionMenuData:{hideCardCallback:t.onActionMenuHideClick,moreSettingsPersonalizeCallback:t.onActionMenuMoreSettingClick},isHideCardAvailable:!0,isMoreSettingAvailable:!0,isActionMenuAvailable:!0},footerData:{footerButton:{text:t.strings.footerTitle,ctaClick:t.onFooterButtonClick},paginationData:{currentPageIndex:t.currentIndex+1,pageCount:Math.ceil(t.npoDataLength/t.listLength),onFlipperClick:t.onFlipperClick,onDotClick:t.onDotClick},useSolidBGColor:!0,telemetryContext:{footerButton:t.getChildTelemetry(T),previousFlipper:t.getChildTelemetry(f),nextFlipper:t.getChildTelemetry(I)}},parentTelemetryObject:t.cardTelemetryObject,contextualFeedbackData:null}}shadowDomPopulated(){this.donationData&&this.markVisuallyReadyRaf()}getExperienceType(){return c.hEo}}(0,l.Cg)([d.sH],D.prototype,"donationData",void 0),(0,l.Cg)([d.sH],D.prototype,"superCardData",void 0),(0,l.Cg)([d.sH],D.prototype,"currentIndex",void 0),(0,l.Cg)([d.Jg],D.prototype,"currentSubCards",null);var M=o(96950),L=o(69259),O=o(39957);const E=M.qy`<a href="" class="npoItem" id=${t=>t.causeId} @click=${(t,e)=>e.parent.onNpoItemClick(t)} data-t="${(t,e)=>{var o;return null===(o=e.parent.getChildTelemetry(S))||void 0===o?void 0:o.getMetadataTag()}}"><div class="npoItemLogo"><img src=${t=>t.logo} alt=${t=>t.causeName} loading="eager" decoding="async" /></div><div class="npoItemText"><span class="npoItemName">${t=>t.causeName}</span><span class="npoItemDescription">${t=>t.description}</span></div></a>`,R=M.qy`<responsive-sd-card :data="${t=>t.superCardData}"><div class="card-content" slot="content"><div class="npoList">${(0,L.z)(t=>t.currentSubCards,M.qy` ${(0,O.ux)(t=>t.currentSubCards,E,{positioning:!0})} `)}</div></div></responsive-sd-card>`;var F=o(48751),H=o(64003),P=o(86856),B=o(74849),z=o(22131),j=o(4968);const _=B.A` .npoItem:hover{background-color:rgba(255,255,255,0.06)}`,K=B.A`
`,Y=B.A`
`,G=B.A`
:host{--sd-card-content-padding-inline:4px}.content{width:100%;height:100%;position:relative;z-index:1}.npoList{height:100%;display:flex;flex-direction:column;justify-content:space-between;overflow:hidden}.npoItem{height:58px;display:flex;flex-direction:row;overflow:hidden;padding:8px 12px;column-gap:12px;cursor:pointer;text-decoration:none;border-radius:4px;${j.f}}.npoItem:hover{background-color:rgba(0,0,0,0.04)}.npoItemLogo{width:56px;height:56px;background-color:#FFFFFF;border-radius:8px;flex:'0 0 56px'}.npoItemLogo img{width:100%;height:100%;object-fit:cover;border-radius:8px}.npoItemText{max-width:200px;display:flex;flex-direction:column;justify-content:center;flex:1;row-gap:4px}.npoItemName{font-size:14px;line-height:20px;font-weight:600;font-style:normal;color:${F.l};text-overflow:ellipsis;overflow:hidden;max-height:40px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.npoItemDescription{font-size:12px;line-height:16px;font-weight:400;color:${H.c};
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
`.withBehaviors((0,z.G2)(_),new P.t(K,Y));(0,s.d)(),n.csResponsiveList.define(a.G.registry),r.m.define(a.G.registry);const W={experienceConfigSchema:undefined}},59836(t,e,o){o.d(e,{m(){return C}});var i=o(65614),a=o(92011);class n extends a.L{}var r=o(7896),s=o(61138),l=o(48751),d=o(74838),c=o(74849),u=o(64187),g=o(22131),p=o(50882);const h=c.A`
    ${(0,u.V)("inline-flex")} :host {
        box-sizing: border-box;
        font-family: ${r.O};
        font-size: ${s.k};
        font-weight: 400;
        line-height: ${s.F};
        align-items: center;
        color: ${l.l};
        min-height: 16px;
    }

    .content {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        align-self: baseline;
    }

    ::slotted([slot="image"]) {
        display: flex;
        margin-inline-end: calc(${d.vR} * 2px);
    }
`.withBehaviors((0,g.mr)(c.A`
            :host,
            .content {
                color: ${p.A.ButtonText};
                fill: currentcolor;
            }
        `)),v=o(96950).qy`
    <slot name="image"></slot>
    <span part="content" class="content">
        <slot></slot>
    </span>
`,C=n.compose({name:`${i.G.prefix}-attribution`,styles:h,template:v})},66690(t,e,o){o.d(e,{csResponsiveList(){return z}});var i=o(89580),a=o(48751),n=o(4283),r=o(74089),s=o(4968),l=o(74849),d=o(22131),c=o(4126),u=o(69904);const g=l.A` .container{display:grid;grid-template-columns:1fr 1fr}.articleContent{height:max-content}`,p=l.A`
.articleHeadingInfo:hover .articleTitle{text-decoration:underline}`,h=l.A` .articleTitle{font-size:${i.Y};
        line-height: ${i.v};-webkit-line-clamp:3}cs-attribution{margin-bottom:6px}`,v=l.A` .articleContent.selected{background:#EBEBEB}.articleContent:hover{background:#F5F5F5}.articleContent:active{background:#E0E0E0}@media (prefers-color-scheme:dark){.articleContent.selected{background:#383838}.articleContent:hover{background:#3D3D3D}.articleContent:active{background:#1F1F1F}}`,C=l.A`
.articleContent:hover{background:rgba(255,255,255,0.06)}.articleContent.selected{background:#26292E}`,b=l.A`
.container{height:100%}.articleContent{border-radius:8px;color:${a.l};display:grid;gap:12px;grid-template-columns:auto var(--responsive-list-image-size,20.9%);height:33.33%;overflow:hidden;text-decoration:none;padding:0px 16px}a.articleContent:focus-visible{outline-offset:-1px}.articleContent.noImage{grid-template-columns:auto}.articleContent.selected{background:#F6F9FC}a{${s.f}}.articleContent:hover{background:rgba(0,0,0,0.04)}.articleHeadingInfo{height:fit-content;margin:auto 0px;min-height:60px;overflow:hidden}cs-attribution{display:flex;margin-bottom:4px;max-width:100%}cs-attribution::part(content){color:var(--content-color,${a.l})}cs-attribution .attribution-image{height:16px;width:16px}cs-attribution .divider{padding-inline-end:1px}cs-attribution .time{margin-inline-start:2px;unicode-bidi:embed}cs-attribution .webContentIcon{filter:invert(var(--iconInvert,0));margin:0px 2px;opacity:0.5;vertical-align:bottom}.articleTag{padding:1px 4px 3px;white-space:nowrap;border-radius:6px;background:${n.IR};
    color: ${r.l_}}.articleTag.breaking{background:#E10303}.articleTitle{display:-webkit-box;font-size:${u.Kg};
    font-weight: 600;
    line-height: ${u.Z6};
    overflow: hidden;
    -webkit-line-clamp: var(--responsive-list-title-lineheight, 2);
    -webkit-box-orient: vertical;
}

.articleImageContainer {
    display: flex;
    position: relative;
    align-items: center;
    justify-content: center;
}

.articleImage {
    aspect-ratio: 1/1;
    border-radius: 8px;
    margin: auto;
    max-width: 72px;
    width: 100%;
    object-fit: var(--responsive-list-image-object-fit, unset);
}

.articleContent.oneItemList {
    height: 100%;
}

.articleContent.twoItemList {
    --responsive-list-image-size: 35.8%;
    height: 50%;
}

.twoItemList .articleHeadingInfo {
    min-height: 92px;
}

.twoItemList .articleTitle {
    --responsive-list-title-lineheight: 3;
}

.twoItemList .articleImage {
    max-width: 116px;
}

.playIndicator {
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
    background: rgba(0, 0, 0, 0.3);
    border: 1px solid rgba(255, 255, 255, .2);
    border-radius: 50%;
    display: flex;
    padding: 5px;
    position: absolute;
}

.playIndicator img {
    filter: invert(1);
    width: 14px;
}

@container (width < 300px) {
    .articleHeadingInfo {
        min-height: min-content;
    }

    .articleTitle {
        --responsive-list-title-lineheight: 1;
    }
}
`.withBehaviors((0,d.G2)(C),new c.o("horizontalMode",!0,g),new c.o("useSubtleControlColors",!0,v),new c.o("useSubtleItemSize",!0,h),new c.o("underlineTitle",!0,p));var m=o(96950),y=o(69259),x=o(39957),S=o(14475),f=o(60402),I=o(22162),T=o(58792);const w=`${(0,T.rA)().StaticsUrl}/latest/fluent-icons/globe_16_regular.svg`,$=m.qy`<cs-attribution>${(0,y.z)(t=>t.attrBadge,m.qy`<span class="articleTag ${t=>{var e;return null===(e=t.attrBadge)||void 0===e?void 0:e.type}}" slot="image">${t=>{var e,o;return(null===(e=t.attrBadge)||void 0===e?void 0:e.localizedLabel)||(null===(o=t.attrBadge)||void 0===o?void 0:o.value)}}</span>`)} ${(0,y.z)(t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.logoImage},m.qy`<img alt="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}" aria-hidden="true" class="attribution-image" decoding="${t=>t.enableLazyImage?"async":""}" loading="${t=>t.enableLazyImage?"lazy":""}" part="image" slot="image" src="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.logoImage}}" title="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}" @load=${t=>t.visualReadinessCallback&&t.visualReadinessCallback(1,I.j.provider)} />`)} ${(0,y.z)(t=>t.providerData&&t.providerData.name,m.qy`<span style="unicode-bidi: embed;" class="attribution-text" title="${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}">${t=>{var e;return null===(e=t.providerData)||void 0===e?void 0:e.name}}</span>`)} ${(0,y.z)(t=>t.isWebContent&&!t.metadata.videoMetadata,m.qy`<img class="webContentIcon" src="${w}">`)} ${(0,y.z)(t=>t.publishedDateTime,m.qy`<span aria-hidden="true" class="divider" focusable="false">·</span><span class="time">${t=>t.publishedDateTime}</span>`)}</cs-attribution>`,N=m.qy`<span class="playIndicator"><img aria-hidden="true" role="presentation" src="${(0,T.rA)().StaticsUrl}/latest/fluent-icons/play_16_filled.svg"></img></span>`,A=m.qy`<div class="articleImageContainer"><img class="articleImage" part="articleImage" src=${(t,e)=>{var o;return t.imageData?e.parent.getScaledListItemImage(t.imageData.source,null===(o=t.imageData)||void 0===o?void 0:o.options):""}} alt=${t=>{var e;return(null===(e=t.imageData)||void 0===e?void 0:e.altText)??""}}>${(0,y.z)((t,e)=>{var o;return(null===(o=e.parent.contentList)||void 0===o?void 0:o.length)>1&&"video"==t.contentType},N)}</div>`,U=m.qy` ${()=>$}<span class="articleTitle" ${(0,f.K)("articleContentRef")}>${t=>t.title}</span>`,k=m.qy`<span class="articleTitle" ${(0,f.K)("articleContentRef")}>${t=>t.title}</span>${()=>$}
`,D=m.qy`<a role="listitem" part="listContent" class=${(t,e)=>{var o;return((t,e,o)=>{let i="articleContent";return 1===t&&(i+=" oneItemList"),2===t&&(i+=" twoItemList"),e||(i+=" noImage"),o&&(i+=" selected"),i})(null===(o=e.parent.contentList)||void 0===o?void 0:o.length,!!t.imageData,t.selected||!1)}} href=${t=>t.destinationUrl} target="${(t,e)=>((t,e)=>e?S.z._self:t.openLinksInNewTab?S.z._blank:t.defaultAnchorTarget||S.z._self)(t,e.parent.config.enableOpenContentInSelf)}" title=${t=>t.title} data-t="${t=>{var e;return null===(e=t.telemetryContext)||void 0===e||null===(e=e.destination)||void 0===e?void 0:e.getMetadataTag()}}" @click="${(t,e)=>e.parent.clickHandler(t,e)}"><div class="articleHeadingInfo" part="listContentInfo">${(0,y.z)((t,e)=>e.parent.enableFlipTitleProvider,k,U)}</div>${(0,y.z)(t=>t.imageData,A)}</a>`,M=m.qy`<div class="container" role="list" data-t="${t=>{var e;return null===(e=t.listContainerTelemetry)||void 0===e?void 0:e.getMetadataTag()}}">${(0,y.z)(t=>null==t?void 0:t.contentList,m.qy` ${(0,x.ux)(t=>t.contentList,D,{positioning:!0})} `)}</div>`;var L=o(56911),O=o(92011),E=o(60815),R=o(38493),F=o(3083),H=o(10809),P=o(27160);class B extends O.L{connectedCallback(){this.config=H.D.getConfig(),this.enableFlipTitleProvider=this.config.enableFlipTitleProvider,this.underlineTitle=this.contentList&&this.contentList[0]&&this.contentList[0].underlineTitle,super.connectedCallback()}getScaledListItemImage(t,e){const o={width:100,height:100,enableDpiScaling:!1,...e};return(0,F.oQ)(t,o)}clickHandler(t,e){return t.useMobile&&!t.isMsnMobile?(t.mobileCardClickCallback(e.event,P.pL.Article,t,"article card"),!1):(t.contentClickCallback&&t.contentClickCallback(t,e),!0)}}(0,L.Cg)([E.sH],B.prototype,"contentList",void 0),(0,L.Cg)([E.sH],B.prototype,"listContainerTelemetry",void 0),(0,L.Cg)([(0,R.CF)({attribute:"horizontal-mode",mode:"boolean"})],B.prototype,"horizontalMode",void 0),(0,L.Cg)([(0,R.CF)({attribute:"use-subtle-control-colors",mode:"boolean"})],B.prototype,"useSubtleControlColors",void 0),(0,L.Cg)([(0,R.CF)({attribute:"use-subtle-item-size",mode:"boolean"})],B.prototype,"useSubtleItemSize",void 0),(0,L.Cg)([(0,R.CF)({attribute:"underline-title",mode:"boolean"})],B.prototype,"underlineTitle",void 0),(0,L.Cg)([(0,R.CF)({attribute:"enable-flip-title-provider",mode:"boolean"})],B.prototype,"enableFlipTitleProvider",void 0);const z=B.compose({name:"responsive-list",styles:b,template:M})},69904(t,e,o){o.d(e,{Fr(){return u},IH(){return b},Kg(){return i},M_(){return C},Oc(){return h},TF(){return s},YO(){return d},YV(){return r},Z6(){return c},aV(){return l},bc(){return v},kS(){return a},le(){return p},tD(){return n},vr(){return g}});const i="14px",a="12px",n="10px",r="16px",s="20px",l="24px",d="28px",c="20px",u="16px",g="22px",p="24px",h="28px",v="32px",C="600",b="400"}}]);