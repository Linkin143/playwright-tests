"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-info-spotlight-2c"],{4968(t,e,i){i.d(e,{f(){return l}});var a=i(64187),r=i(74849),n=i(42792),s=i(99657),o=i(36452);const l=r.A.partial`position: relative; z-index: ${s.D};`;r.A`
    ${n.e}
    ${n.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${o.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${o.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${o.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(n.kc)},10500(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},32526(t,e,i){i.r(e),i.d(e,{SportsMatchWithScores(){return k}});var a=i(56911),r=i(84564);class n extends r.z{shouldShowTable(){return void 0!==this.viewModel.tableView}}var s=i(92011),o=i(48751),l=i(86856),d=i(12640),c=i(74849),p=i(22131);const g=c.A` :host{--line-style:rgba(61,61,61,1);--background-color:rgba(31,31,31,1)}`,h=c.A`
`,v=c.A`
`,m=c.A` :host{--line-style:#F2F2F2;--background-color:#FAFAFA}.vert-match{display:flex;height:216px;padding:8px 12px 12px 12px;flex-direction:column;align-items:flex-start;gap:12px;flex-shrink:0;border-radius:8px;background:var(--background-color);box-sizing:border-box}.match-cntnr,.game-info,.line,.scores-table{width:100%}.game-info{display:flex;flex-direction:column;align-items:flex-start;padding:4px 0px;gap:6px;border-radius:8px}.game-item{display:flex;justify-content:space-between;align-items:flex-start;align-self:stretch;gap:20px}.game-title,.game-value{line-height:var(--type-ramp-minus-1-line-height,16px);font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:400;white-space:nowrap;color:${o.l}}.game-value{text-align:right;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.line{height:1px;background:var(--line-style)}.scores-table{min-height:1px}`.withBehaviors(new l.t(h,v),new d.N(null,g),(0,p.mr)(c.A` :host{forced-color-adjust:auto}`));var u=i(96950);const x=u.qy`
    <sports-match class="match-cntnr"
        :viewModel="${t=>t.viewModel.match}"
    ></sports-match>
`,f=u.qy`
    <div class="game-info">
        <div class="game-item">
            <div class="game-title">
                ${t=>t.viewModel.gameInfoStrings.leagueTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.leagueValue}
            </div>
        </div>
        <div class="game-item">
            <div class="game-title">
                 ${t=>t.viewModel.gameInfoStrings.venueTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.venueValue}
            </div>
        </div>
        <div class="game-item">
            <div class="game-title">
                ${t=>t.viewModel.gameInfoStrings.streamTitle}
            </div>
            <div class="game-value">
                ${t=>t.viewModel.gameInfoStrings.streamValue}
            </div>
        </div>
    </div>
`,$=u.qy`
    <sports-scores-table class="scores-table"
        :viewModel="${t=>t.viewModel.tableView}"
    ></sports-scores-table>
`,b=u.qy`
<div class="vert-match">
    ${x}
    <div class="line"></div>
    ${$}
</div>
`,w=u.qy`
    <div class="vert-match">
        ${x}
        <div class="line"></div>
        ${f}
    </div>
`,y=u.qy`
    ${t=>t.shouldShowTable()?b:w}
`;let k=class extends n{};k=(0,a.Cg)([(0,s.E)({name:"sports-match-with-scores",template:y,styles:m,shadowOptions:{delegatesFocus:!0}})],k)},36516(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},42792(t,e,i){i.d(e,{R7(){return m},e(){return h},kc(){return v},nH(){return g}});var a=i(57416),r=i(55153),n=i(95239),s=i(26920),o=i(48751),l=i(64187),d=i(22131),c=i(74849),p=i(50882);const g=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${n.p};
        outline: calc(${s.XA} * 1px) solid ${r.cu};
        border-radius: calc((${a.JU} - ${s.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${o.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${r.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${r.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${s.XA} * 1px) ${r.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${r.QG} * 1px);
        height: calc(${r.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${r.QG} * 1px);
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc((${r.l8} * 2px) + (${r.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${r.QG} * 2px) + (${r.Sn} * 1px));
        height: calc(${r.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,v=(0,d.mr)(c.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),m=c.A`
    ${h}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(v)},50712(t,e,i){i.r(e),i.d(e,{SportsSpotlight2c(){return M}});var a=i(56911),r=i(84564);class n extends r.z{constructor(){super(...arguments),this.shouldShowGameStats=()=>!!this.viewModel.sportsGameStatsCard}}var s=i(92011),o=i(48751),l=i(86856),d=i(74849),c=i(22131),p=i(12640);const g=d.A`
`,h=d.A` :host{--line-color:rgba(61,61,61,1);--background-color:rgba(31,31,31,1)}`,v=d.A` :host{--line-color:#F2F2F2;--background-color:#FAFAFA;--width-1c:278px;--card-height:216px}.game-stats2c,.game-stats-teams-container,.upcmng-matches2c{display:flex;justify-content:space-between}.title,.name{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal;font-weight:600;color:${o.l}}.game-stats2c{width:580px;align-items:center}.game-stats{display:flex;width:var(--width-1c);height:var(--card-height);padding:8px 12px 12px 12px;flex-direction:column;align-items:flex-start;gap:10px;flex-shrink:0;border-radius:8px;background:var(--background-color);box-sizing:border-box}.line{width:254px;height:0px;border:1px solid var(--line-color)}.game-stats-teams-container{align-items:center;align-self:stretch}.game-stats-teams-container > div{display:flex;align-items:center;gap:6px}.icon{width:16px;height:16px}.name{max-width:100px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.icon img{max-width:100%;max-height:100%;width:auto;height:auto}.upcmng-matches2c{flex-direction:row;align-items:center;padding:0px;gap:24px}.upcmng-matches{display:flex;flex-direction:column;align-items:flex-start;padding:8px 12px 12px;gap:12px;width:var(--width-1c);height:var(--card-height);background:var(--background-color);border-radius:8px;box-sizing:border-box}.1c{display:flex;justify-content:center;align-items:center;width:268px}.upcmng-matches2c > div:first-of-type{width:var(--width-1c)}.game-stats2c > div:first-of-type{width:var(--width-1c)}`.withBehaviors(new l.t(null,g),new p.N(null,h),(0,c.mr)(d.A` :host{forced-color-adjust:auto}`));var m=i(96950),u=i(39957),x=i(69259);const f=m.qy`
    ${(0,u.ux)(t=>t.viewModel.matchesWithScores??[],m.qy`<sports-match-with-scores style="width: 100%;"
        :viewModel="${t=>t.viewModel}"
    ></sports-match-with-scores>`,{positioning:!0})}
`,$=m.qy`
    ${t=>{var e;const i=null==t||null===(e=t.viewModel)||void 0===e||null===(e=e.matchesWithScores)||void 0===e||null===(e=e[0])||void 0===e||null===(e=e.viewModel)||void 0===e?void 0:e.match;return i?(t=>{var e,i,a,r;return m.qy`
    <div class="title">
        ${t=>t.viewModel.sportsGameStatsTitle||""}
    </div>
    <div class="line">
    </div>
    <div class="game-stats-teams-container">
        <div>
            <span class="icon">
                <img
                    role="presentation"
                    src="${t.participantOneImgIcon||""}"
                    onerror="this.style.display='none';this.alt=''"
                />
            </span>
            <span class="name" title="${(null===(e=t.matchData.sportsMatchData.participantOne)||void 0===e?void 0:e.name)||""}">
                    ${(null===(i=t.matchData.sportsMatchData.participantOne)||void 0===i?void 0:i.name)||""}
            </span>
        </div>
        <div>
            <span class="name" title="${(null===(a=t.matchData.sportsMatchData.participantTwo)||void 0===a?void 0:a.name)||""}">
                    ${(null===(r=t.matchData.sportsMatchData.participantTwo)||void 0===r?void 0:r.name)||""}
            </span>
            <span class="icon">
                <img
                    role="presentation"
                    src="${t.participantTwoImgIcon||""}"
                    onerror="this.style.display='none';this.alt=''"
                />
            </span>
        </div>
    </div>
`})(i):""}}
`,b=m.qy`
    <div class="game-stats">
        ${$}
        <sports-game-stats :viewModel="${t=>{var e;return null===(e=t.viewModel.sportsGameStatsCard)||void 0===e?void 0:e.viewModel}}">
        </sports-game-stats>
    </div>
`,w=m.qy`
    <div class=upcmng-matches>
        <div class="title">${t=>t.viewModel.sportsUpcomingMatchesTitle}</div>
        ${(0,u.ux)(t=>t.viewModel.upcomingMatches??[],m.qy`
            <div class="line"></div>
            <sports-match
                :viewModel="${t=>t.viewModel}"
            ></sports-match>`,{positioning:!0})}
    </div>
`,y=m.qy`
    <div class="game-stats2c">
        <div>
            ${f}
        </div>
        ${b}
    </div>
`,k=m.qy`
    <div class="upcmng-matches2c">
        <div>
            ${f}
        </div>
        ${w}
    </div>
`,z=m.qy`
    <div class="1c">
        ${f}
    </div>
`,S=m.qy`
    ${t=>t.shouldShowGameStats()?y:k}
`,F=m.qy`
    ${t=>"_2x_2y"===t.viewModel.cardSize?S:z}
`,T=m.qy`
    ${(0,x.z)(t=>null!=t.viewModel,F)}
`;let M=class extends n{};M=(0,a.Cg)([(0,s.E)({name:"sports-spotlight-2c",template:T,styles:v,shadowOptions:{delegatesFocus:!0}})],M)},67689(t,e,i){i.d(e,{h(){return r}});var a=i(2827);function r(){return(0,a.oh)()}},70010(t,e,i){i.r(e),i.d(e,{SportsGameStatsTransformer(){return a.O},SportsMatchTransformer(){return r.SportsMatchTransformer},SportsMatchWithScoresTransformer(){return d},SportsSpotlight2cTransformer(){return g}});var a=i(70512),r=i(82724),n=i(23587),s=i(22341),o=i(93552),l=i(58792);class d extends n.Bc{async transform(t){return{viewModel:await this.getViewModel(t)}}async getViewModel(t){const e=t.matchMetadata,i=await this.transformerProvider.generateView(e,n.hi.SportsMatch),a=e.matchData.sportsMatchData,r=this.getTableViewModel(t),s={...e.telemetryConstants,name:n.BP.SportsSpotlightMatchCard2c},o=null==a?void 0:a.gameInfo,l=this.getGameInfoStrings(a);return{match:i.viewModel,gameInfo:o,tableView:r,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,s),gameInfoStrings:l}}getTableViewModel(t){try{var e;const r=t.matchMetadata,d=r.matchData.sportsMatchData,c=d.detailedScore;if(!c)return;if(!c.game||(null===(e=c.game)||void 0===e?void 0:e.length)<2)return void(0,s.vV)(o.BfS,"Sports scores table detailedScored game data missing",`market=${l.T3.CurrentMarket}`,t);const p=c.game,g=c.scoreKeyOrder,h=12;if(g.length>h)return;const v=[];var i,a;if(d.participantOne)(null===(i=d.participantOne)||void 0===i?void 0:i.shortName)&&v.push(d.participantOne.shortName),(null===(a=d.participantTwo)||void 0===a?void 0:a.shortName)&&v.push(d.participantTwo.shortName);const m=v.map((t,e)=>({gameScore:Object.values(p[e]).slice(0,g.length),participantName:t}));if(0===m.length)return;const u={...r.telemetryConstants,name:n.BP.SportsSpotlightScores2c},x=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(r.parentTelemetryObject,u),f=this.getTableStyle(g,h),$=g.length>=5;return{headerRow:g,participants:m,maxElements:h,tableStyle:f,isLarge:$,telemetryTag:x}}catch(e){return void(0,s.vV)(o.BfS,`Error generating sports scores table view model  ${e.message}; stack: ${e.stack}`,`market=${l.T3.CurrentMarket}`,t)}}getGameInfoStrings(t){const e={venueTitle:"",venueValue:"",streamTitle:"",streamValue:"",leagueTitle:"",leagueValue:""};return(null==t?void 0:t.gameInfo)&&(e.venueTitle=this.transformerProvider.strings.venue,e.venueValue=t.gameInfo.venueInfo,e.streamTitle=this.transformerProvider.strings.liveStream,e.streamValue=t.gameInfo.streamInfo,e.leagueTitle=this.transformerProvider.strings.league,e.leagueValue=t.gameInfo.league),e}getGap(t,e){const i=t,a=e;return`gap: ${Math.round(3*(a-i))}px;`}getTableStyle(t,e){const i=t.length;return i<5?`grid-template-columns: repeat(auto-fit, minmax(16px, max-content)); ${this.getGap(i,e)}`:"grid-template-columns: repeat(auto-fit, minmax(16px, 1fr));"}}var c=i(79811),p=i(96950);class g extends n.Bc{constructor(){super(...arguments),this.gameStatsFormatMap={teamEarnedRunAverage:{toFix:2,isPercent:!1},faceoffWinPct:{isPercent:!0},fieldGoalPer:{toFix:1,isPercent:!0},freeThrowsPercentage:{toFix:1,isPercent:!0},threePointersPercentage:{toFix:2,isPercent:!0}},this.gameStatsLocKeyMap={yards:"rushingYards",battingAverage:"teamBattingAverage",earnedRunAverage:"teamEarnedRunAverage",strikeouts:"strikeoutsThrown",walks:"walksAllowed",errors:"errorsCommitted",personalFouls:"fouls",fieldGoalsPercentage:"fieldGoalPer",totalYards:"yardsPerGame",passingYards:"passingYardsAllowedPerGame",penaltyYards:"penaltyYardsPerGame"}}async transform(t){const e={...t,spotlightData:this.transformSportsSpotlightData(t.spotlightData,t.upcomingMatches)},i=await this.getCurrentViewModel(e);return{viewTemplate:p.qy`
                <sports-spotlight-2c
                    :viewModel="${i}"
                ></sports-spotlight-2c>`}}async getCurrentViewModel(t){if((0,c.nD)(t))(0,s.vV)(o.BfS,"2c spotlight metadata missing",`market=${l.T3.CurrentMarket}`,t);else try{var e,i;const n=null===(e=t.spotlightData)||void 0===e?void 0:e.matchlist,d=this.getMatchesMetadata(t,n),c=await this.getMatchWithScoresViews(d);0===c.length&&(0,s.vV)(o.BfS,"2c spotlight match data missing",`market=${l.T3.CurrentMarket}`,t);const{cardSize:p}=t;let g,h,v,m;if((null===(i=t.spotlightData)||void 0===i||null===(i=i.sportsGameStats)||void 0===i?void 0:i.length)>0){var a;g=await this.getGameStatsInfo(t),v=null!==(a=t.spotlightData)&&void 0!==a&&a.isSeasonStats?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.matchStatistics}else{var r;const e=null===(r=t.spotlightData)||void 0===r?void 0:r.upcomingMatchList,i=this.getMatchesMetadata(t,e).map(t=>({...t,hasVerticalLine:!0}));h=await this.getMatchViews(i),m=this.transformerProvider.strings.upcomingGames}return{matchesWithScores:c,upcomingMatches:h,cardSize:p,sportsGameStatsCard:g,sportsGameStatsTitle:v,sportsUpcomingMatchesTitle:m,telemetryTag:""}}catch(e){(0,s.vV)(o.BfS,`Error generating sports spotlight 2c view model  ${e.message}; stack: ${e.stack}`,`market=${l.T3.CurrentMarket}`,t)}}async getGameStatsInfo(t){const{sportsGameStats:e,isSeasonStats:i=!1}=t.spotlightData||{},{cardSize:a}=t,r={cardSize:a,sportsGameStats:e,isSeasonStats:i};return await this.transformerProvider.generateView(r,n.hi.SportsGameStats)}getMatchesMetadata(t,e){if(!e)return[];const i=(0,c.nD)(t.followedSports)?new Map:t.followedSports,a=(0,c.Yo)(e);return e.map(e=>{var r,n,s,o;const l=e.sportsMatchData,d=i.get((null===(r=l.participantOne)||void 0===r?void 0:r.satoriId)||"")||i.get((null===(n=l.participantOne)||void 0===n?void 0:n.yId)||"")||!1,c=i.get((null===(s=l.participantTwo)||void 0===s?void 0:s.satoriId)||"")||i.get((null===(o=l.participantTwo)||void 0===o?void 0:o.yId)||"")||!1;return{matchData:e,parentTelemetryObject:t.telemetryObject,telemetryConstants:t.telemetryConstants,participantOneFollowed:d,participantTwoFollowed:c,isContainLiveMatch:a,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores,showMatchUXV2:t.isHeroCard,isVertical:!0}})}async getMatchViews(t){const e=t.map(t=>this.transformerProvider.generateView(t,n.hi.SportsMatch));return(await Promise.all(e)).filter(c.z2)}async getMatchWithScoresViews(t){const e=t.map(t=>this.transformerProvider.generateView({matchMetadata:t},n.hi.SportsMatchWithScores));return(await Promise.all(e)).filter(c.z2)}transformSportsSpotlightData(t,e){const{statistics:i}=t,a=t.match&&this.transformMatchData(t.match);let r,n=c.Zi,d=c.ZL;const p=[];if(a){var g,h,v,m,u;const t=(null===(g=a.participantOne)||void 0===g?void 0:g.primaryColorHex)===(null===(h=a.participantTwo)||void 0===h?void 0:h.primaryColorHex)&&"ffffff"===(null===(v=a.participantOne)||void 0===v||null===(v=v.primaryColorHex)||void 0===v?void 0:v.toLowerCase());!t&&null!==(m=a.participantOne)&&void 0!==m&&m.primaryColorHex&&(n=(0,c.gS)(a.participantOne.primaryColorHex)),!t&&null!==(u=a.participantTwo)&&void 0!==u&&u.primaryColorHex&&(d=(0,c.gS)(a.participantTwo.primaryColorHex)),a.matchClickthroughUrl?r=a.matchClickthroughUrl:a.gameCenterUrl&&(r=(0,c.Ot)(a.gameCenterUrl),a.matchClickthroughUrl=r),p.push({sportsMatchData:a})}let x=[];e&&(x=e.map(t=>(!(t=this.transformMatchData(t)).matchClickthroughUrl&&t.gameCenterUrl&&(t.matchClickthroughUrl=(0,c.Ot)(t.gameCenterUrl)),{sportsMatchData:t})));const f=this.transformGameState(i,[n,d]);if(f||0!==x.length)return{matchlist:p,upcomingMatchList:x,sportsGameStats:f,matchClickthroughUrl:r||"",isSeasonStats:i&&i.season&&2===i.season.length};(0,s.vV)(o.BfS,"Missing both game stats and upcoming match data",`market=${l.T3.CurrentMarket}`,t)}transformMatchData(t){const e=(0,c.yn)(t.gameStartDateTime);return t.gameDate=(0,c.AL)(e,l.T3.CurrentMarket),t.gameStartTime=(t.gameStartDateTimeIsToBeAnnounced?null:(0,c.ry)(e,l.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,t.gameStateCatetory="string"!=typeof t.gameState?(0,c.m5)(t.gameState.state):t.gameStateCatetory,"string"!=typeof t.gameState&&(t.gamePeriodAndClock=(0,c.PH)(t.gameState)),t.participantOne&&(t.participantOne.scheduleUrl=(0,c.Ot)(t.participantOne.gameCenterUrl)),t.participantTwo&&(t.participantTwo.scheduleUrl=(0,c.Ot)(t.participantTwo.gameCenterUrl)),t.gameCenterUrl&&(t.matchClickthroughUrl=(0,c.Ot)(t.gameCenterUrl)),t.participantOne.imageUrl=(0,c.iK)(t.participantOne.imageId,!t.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),t.participantTwo.imageUrl=(0,c.iK)(t.participantTwo.imageId,!t.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),t.gameState=t.gameStateCatetory===n.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:t.gameStateCatetory,t}transformGameState(t,e){if((0,c.nD)(t))return;let i=[];t.season&&2===t.season.length?i=t.season:t.game&&2===t.game.length&&(i=t.game);const a=[];if(i[0]&&i[1]){const r=i[0],n=i[1],s=t.statsKeyOrder||Object.keys(r);for(const t of s){const i=Number(r[t]),s=Number(n[t]),o=this.gameStatsFormatMap[t],l=this.formatGameStatsNumber(i,o),d=this.formatGameStatsNumber(s,o),c=this.calculatePercentNumbers(i,s),p={key:this.gameStatsLocKeyMap[t]||t,left:i,right:s,leftText:l,rightText:d,leftColor:e[0],rightColor:e[1],...c};a.push(p)}}return a}formatGameStatsNumber(t,e){if(!e)return t.toString();let i="";return e.isPercent&&(i="%"),void 0!==e.toFix?`${t.toFixed(e.toFix)}${i}`:`${t}${i}`}calculatePercentNumbers(t,e){let i=0,a=0,r=0;return 0!==t&&0!==e?(r=.7,i=t/(t+e)*99.3,a=e/(t+e)*99.3):0===t&&0===e?(i=0,a=0,r=0):0===t?(i=2.3,a=97,r=.7):0===e&&(i=97,a=2.3,r=.7),{leftPercent:Number(i.toFixed(1)),rightPercent:Number(a.toFixed(1)),gap:r}}}Promise.resolve().then(i.bind(i,50712)),Promise.resolve().then(i.bind(i,71891)),Promise.resolve().then(i.bind(i,76435)),Promise.resolve().then(i.bind(i,32526)),Promise.resolve().then(i.bind(i,87076))},70512(t,e,i){i.d(e,{O(){return n}});var a=i(49150),r=i(23587);class n extends r.Bc{constructor(){super(...arguments),this.getCardTitle=(t,e)=>e?this.transformerProvider.strings.teamStats:t?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.gameStats}async transform(t){return{viewModel:await this.getCurrentViewModel(t)}}async getCurrentViewModel(t){const{cardSize:e,isFullCard:i,sportsGameStats:r,isSpotlight2Card:n,participants:s,isSeasonStats:o,isCopilotTheme:l}=t;let d=0;switch(e){case a.uE._1x_2y:d=i?5:3;break;case a.uE._1x_3y:d=7;break;case a.uE._2x_2y:d=4;break;case a.uE._15u:d=3}return{sportsGameStats:r.slice(0,d).map(t=>{const e=t.key;return{...t,leftText:this.getStatText(t.leftText,e),rightText:this.getStatText(t.rightText,e),left:this.getBarPercentage(t.left,t.right,e),right:this.getBarPercentage(t.right,t.left,e),key:this.transformerProvider.strings[e]||e}}),cardSize:e,isSpotlight2Card:n,isFullCard:i,participants:s,cardTitle:this.getCardTitle(o,l),isCopilotTheme:l,telemetryTag:""}}isPercentStats(t){return null==t?void 0:t.includes("%")}getBarPercentage(t,e,i){const a=this.isPercentStats(i);return 0===t&&0===e?0:100*(a?t:t/(t+e))}getStatText(t,e){return t&&e?this.isPercentStats(e)?`${(100*parseFloat(t)).toFixed(1)}`:t:""}}},71891(t,e,i){i.r(e),i.d(e,{SportsGameStats(){return C}});var a=i(56911),r=i(84564),n=i(67689);class s extends r.z{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,n.h)()}}var o=i(92011),l=i(86856),d=i(12640),c=i(74849),p=i(4126),g=i(22131);const h=c.A` @container (min-width:180px) and (max-width:233px){.dvrg-hdr{font-size:12px}}`,v=c.A` .game-stats-title,.dtitle{color:rgba(255,255,255,1)}.game-stats-item{color:rgba(255,255,255,1)}.game-stats-item-content{background:rgba(255,255,255,0.6);outline:1px solid rgba(255,255,255,0.20)}.s-bar{background-color:rgba(255,255,255,0.05)}`,m=c.A` .game-stats-item-content{background:rgba(0,0,0,0.5)}`,u=c.A` .game-stats-item-content{transform:scaleX(-1)}`,x=c.A` :host{width:100%;position:relative}.full-card{height:100%;display:flex;flex-direction:column}.game-stats-title{height:20px;width:100%;line-height:20px;text-align:center;font-size:14px;font-weight:600;color:rgba(26,26,26,1);margin-top:10px;margin-bottom:10px}.team-container{display:flex;gap:5px;align-items:center;font-weight:600}.game-team-icons{justify-content:space-between;display:flex;padding-bottom:10px}.team-icon{height:20px}.team-name{display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}.game-stats-list{height:118px;width:100%;box-sizing:border-box;background:var(--sports-item-background);border-radius:8px;padding:10px;display:flex;flex-direction:column;justify-content:space-between;color:red}.spotlight-two .game-stats-list{height:110px}.full-card .game-stats-list{flex-grow:1;height:unset}.game-stats-item{height:26px;font-size:12px;color:rgba(26,26,26,1)}.game-stats-item-header,.dvrg-hdr{height:16px;line-height:16px;display:flex;justify-content:space-between;&>span:{display:inline-block}}.game-stats-item-content{height:8px;line-height:8px;margin-top:2px;border-radius:6px}.game-stats-item-header > span:first-child{padding-right:2px}.game-stats-item-header > span:nth-child(2){overflow:hidden;white-space:nowrap}.game-stats-item-header > span:last-child{padding-left:2px}.left{padding-left:0}.right{padding-right:0}._1x_3y{height:276px}._2x_2y{height:132px;font-weight:600;padding:0px}._15u{height:210px}.s-bars{display:flex;flex-direction:row;height:8px}.s-bar{background-color:rgba(0,0,0,0.05);height:8px;position:relative;width:calc(50%)}.bg-br-l{border-radius:6px 0px 0px 6px;padding-right:1px}.bg-br-r{border-radius:0px 6px 6px 0px;padding-left:1px}.s-bar-l{float:right;border-radius:6px 0 0 6px}.s-bar-r{border-radius:0 6px 6px 0}.s-bar > div{display:block;height:100%;overflow:hidden;position:relative}.s-dvrg,.br-cntr,.brs-cntr{display:flex;flex-direction:column}.s-dvrg,.brs-cntr{gap:12px;font-size:14px}.dtitle{height:20px;width:100%;line-height:20px;font-size:14px;font-weight:600;color:rgba(26,26,26,1)}.brs-cntr{height:118px;width:100%;box-sizing:border-box;border-radius:8px}.br-cntr{gap:4px}.dvrg-hdr{line-height:var(--smtc-text-global-body2-line-height,20px);height:auto}.dtitle{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.s-dvrg{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523);container-type:inline-size}`.withBehaviors(new l.t(null,u),new d.N(m,v),new p.o("isAdaptiveThemeEnabled",!0,h),(0,g.mr)(c.A` :host{forced-color-adjust:auto}`));var f=i(96950),$=i(69259),b=i(39957);const w=f.qy`
    <div class="game-stats-item">
        <div class="game-stats-item-header">
            <span>
                ${t=>t.leftText}
            </span>
            <span>
                ${t=>t.key}
            </span>
            <span>
                ${t=>t.rightText}
            </span>
        </div>
        <div class="game-stats-item-content"
            style="${t=>0!==t.gap?`background: linear-gradient(to right, ${t.leftColor} 0%, ${t.leftColor} ${t.leftPercent}%, #FFFFFF ${t.leftPercent}%, #FFFFFF ${t.leftPercent+t.gap}%, ${t.rightColor} ${t.leftPercent+t.gap}%, ${t.rightColor} 100%)`:""}"
        >
        </div>
    </div>
`,y=f.qy`
    <div class="team-container">
        ${(0,$.z)((t,e)=>0!==e.index,f.qy`<div class="team-name">${t=>t.name}</div>`)}
        <img class="team-icon" src="${t=>t.imageUrl}" alt="${t=>t.imageAltText}" onerror="this.style.display='none';this.alt=''" />
        ${(0,$.z)((t,e)=>0===e.index,f.qy`<div class="team-name">${t=>t.name}</div>`)}
    </div>
`,k=f.qy`
    <div class="game-team-icons">
        ${(0,b.ux)(t=>t.viewModel.participants,y,{positioning:!0})}
    </div>
`,z=f.qy`
<div class="game-stats-title">${t=>t.viewModel.cardTitle}</div>
`,S=f.qy`
    <div class="${t=>t.viewModel.isFullCard?"full-card":""} ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}">
        ${(0,$.z)(t=>t.viewModel.isFullCard&&t.viewModel.participants,k)}
        ${(0,$.z)(t=>!t.viewModel.isFullCard&&"_2x_2y"!==t.viewModel.cardSize,z)}
        <div class="game-stats-list ${t=>"1.5u"===t.viewModel.cardSize?"_15u":t.viewModel.cardSize}">
            ${(0,b.ux)(t=>t.viewModel.sportsGameStats,w)}
        </div>
    </div>
`,F=f.qy`
    <div class="s-dvrg">
        <div class="dtitle">${t=>t.viewModel.cardTitle}</div>
        <div class="brs-cntr">
            ${(0,b.ux)(t=>t.viewModel.sportsGameStats,f.qy`
        <div class="br-cntr">
            <div class="dvrg-hdr">
                <span class="left">
                    ${t=>t.leftText}
                </span>
                <span>
                    ${t=>t.key}
                </span>
                <span class="right">
                    ${t=>t.rightText}
                </span>
            </div>
            <div class="s-bars">
                <div class="s-bar bg-br-l">
                    <div class="s-bar-l"
                            style="background-color: ${t=>t.leftColor||"#A71930"};
                                width: ${t=>t.left}%;">
                    </div>
                </div>

                <div class="s-bar bg-br-r">
                    <div class="s-bar-r"
                            style="background-color: ${t=>t.rightColor||"#036779"};
                                width: ${t=>t.right}%;">
                    </div>
                </div>
            </div>
        </div>
    `)}
        </div>
    </div>
`,T=f.qy`${t=>{var e;return null!==(e=t.viewModel)&&void 0!==e&&e.isCopilotTheme?F:S}}`,M=f.qy`
    ${(0,$.z)(t=>null!=t.viewModel,T)}
`;let C=class extends s{};C=(0,a.Cg)([(0,o.E)({name:"sports-game-stats",template:M,styles:x,shadowOptions:{delegatesFocus:!0}})],C)},76435(t,e,i){i.r(e),i.d(e,{SportsMatch(){return st}});var a=i(56911),r=i(54229),n=i(84564);class s extends n.z{constructor(){super(...arguments),this.getMatchData=()=>this.viewModel.matchData.sportsMatchData,this.isVertical=()=>null!=this.viewModel&&this.viewModel.isVertical,this.isCopilotTheme=()=>null!=this.viewModel&&this.viewModel.isCopilotTheme}get isWindowsCopilot(){return null!=this.viewModel&&this.viewModel.isWindows&&this.viewModel.isCopilotTheme}handleClickFollowIcon(t,e,i,a){if(t&&t.currentTarget){t.preventDefault(),t.stopPropagation();const n="keydown"===t.type||"keypress"===t.type||"keyup"===t.type;(0,r.LE)(t.currentTarget,n,e),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,e,a)}}}var o=i(92011),l=i(48751),d=i(62047),c=i(61138),p=i(41123),g=i(71157),h=i(62198),v=i(4283),m=i(4968),u=i(12640),x=i(50882),f=i(74849),$=i(4126),b=i(22131);const w="#CD3800",y="#E98F6D",k=f.A` .date,.nodate{width:auto}`,z=f.A` :host{--line-color:rgba(61,61,61,1);--header-color-live:rgba(255,153,164,1);--ruby-live-text-bg:rgba(9,102,32,0.2);--ruby-live-text-color:rgba(108,197,123,1)}.winner-tag path{fill:#FFFFFF}.detail-live-animation{background:${y}}.game-in-progress-text{color:${y}}.side-by-side-hover-canvas:hover{background:rgba(0,0,0,0.6)}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#1A1A1A}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.live-line{border-top:1px solid ${y};
        background-color: ${y}}.standings-style{color:${l.l}}:host-context([is-ruby-feed-card]) .matchup-neutral-background{border:1px solid #5A5E63}.kcntr .post-game .kscr:not(.winner-team){color:var(--smtc-foreground-ctrl-neutral-primary-pressed,#A4ADC8)}`,S=f.A` :host{--header-color-live:#C42B1C;--standings-color:#707070;--line-color:#F2F2F2;--kumo-live-bg:rgba(171,47,64,1);--kumo-live-text:rgba(255,255,255,1);--ruby-live-text-bg:#94DC7F33;--ruby-live-text-color:rgba(0,127,48,1)}.sports-match{padding:4px 0;text-decoration:none;display:grid;row-gap:14px;border-radius:6px;height:58px;${m.f}}.sports-match.reason{padding:1px 0}.sports-match.superbowl-half-u{padding:6px 16px;height:auto}.sports-match:focus-visible{outline:${l.l} solid 2px;outline-offset:-2px}.side-by-side-matchup-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;border-radius:6px}.superbowl-half-u .side-by-side-matchup-content{padding:0}.matchup-neutral-background{border-radius:6px;background:var(--sports-item-background)}.matchup-neutral-background.no-bg{background:rgba(0,0,0,0)}.matchup-neutral-background:hover,.matchup-neutral-background:focus-visible{background:var(--sports-item-hover-background)}.matchup-neutral-background:active{background:var(--sports-item-active-background)}.side-by-side-gradient-container{height:45px;width:100%;border-radius:6px 6px 0px 0px;position:absolute}.reason .side-by-side-gradient-container{height:40px}.side-by-side-hover-canvas{display:flex;justify-content:center;align-items:center;position:absolute;width:100%;height:100%;z-index:3;font-size:14px;font-weight:bolder;background:rgba(255,255,255,0);color:rgba(0,0,0,0);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.side-by-side-hover-canvas:hover{border-radius:6px;border:1.6px solid #6581CA;background:rgba(255,255,255,0.85);color:${l.l}}.video-indicator{display:none}.middle-game-detail{display:flex;flex-direction:row;justify-content:space-around;color:${l.l};font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center}.middle-notification-game-detail{align-items:center}.bottom-game-detail{color:${l.l};
        font-size: ${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:100px}.bottom-notification-container{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;max-height:28px;text-align:center;max-width:108px}.bottom-notification-container.pregame{white-space:normal}.notification-message{display:block;max-width:108px;font-weight:400;color:${l.l}}.underline-text{text-decoration:underline}.superbowl-1-u .bottom-game-detail,.superbowl-half-u .bottom-game-detail{color:${l.l}}.foreground-rest-text-color{color:${l.l}}.top-game-detail{color:${l.l};
        font-size: ${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:140px}.finals-match .top-game-detail,.finals-match .bottom-game-detail{color:${l.l}}.super-bowl{font-weight:700;text-transform:uppercase;color:${l.l}}.game-details{display:flex;flex-direction:column;align-items:center;width:100px;overflow:hidden}.side-by-side-matchup-content:hover .game-details-wrapper .game-details{display:none}.side-by-side-matchup-content:hover .game-details-wrapper .game-details-additional-info{display:flex}.game-details-additional-info{display:none;flex-direction:column;align-items:center;justify-content:center;width:100px}.game-details-additional-info .round-info,.game-details-additional-info .round-scores-info{font-size:${c.k};
        line-height: ${c.F};
        color: ${l.l};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-details-additional-info .round-summary-info{font-size:${p.K};
        line-height: ${p.Z};
        font-weight: 600;
        color: ${l.l};max-width:110px;white-space:nowrap;overflow:hidden}.participant-container{display:flex;align-items:center;flex-direction:column;width:84px;color:${l.l};z-index:0}.spotlight-two .participant-container{width:64px}.participant-container img{width:36px;height:36px}.participant-icon{display:flex;border:none;cursor:pointer;width:36px;height:36px;border-radius:8px;align-items:center;justify-content:center;background:transparent}.participant-icon.participant-icon-large{width:70px;height:50px}.participant-container .logo-backplate.participant-icon-large img{width:40px;height:40px}.participant-icon.logo-backplate{border-radius:8px;width:40px;height:40px;img{width:28px;height:28px}}.side-by-side-matchup-content .follow-icon{opacity:0;pointer-events:none;margin-right:-20px;margin-top:-16px}.side-by-side-matchup-content:hover .follow-icon{opacity:1;pointer-events:all}.follow-icon:focus-visible,.sports-match:focus-visible .follow-icon{opacity:1;pointer-events:all}.spotlight-two .right-participant .follow-icon{position:relative;left:-18px}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.game-in-progress-text{color:${w};
        font-size: ${c.k};
        line-height: ${c.F};font-weight:400}.live-scores-detail .game-in-progress-text{border-top:1px solid ${w};
        font-size: ${d.t}}.participant-name-style{font-size:${c.k};
        line-height: ${c.F};max-width:64px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:600}.game-time-text-style{font-size:${g.T};
        line-height: ${g.O};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-time-notification-text-style{font-size:${c.k};
        line-height: ${c.F};max-width:100px}.game-score-notification-text-style{font-size:${g.T};
        line-height: ${g.O}}.game-score-text-style{color:${l.l};
        line-height: ${g.O};
        font-size: ${h.a};margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;font-weight:600}.long-score{font-size:var(--type-ramp-minus-1-font-size,12px)}.long-score .game-score-text-style{font-size:var(--type-ramp-minus-1-font-size,12px);margin:0px 2px}.detail-live-animation{height:2px;background:${w};transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate}@keyframes liveAnimation{0%{width:50px}100%{width:2px}}.video-detail,.top-detail{display:flex;align-items:center;height:14px;margin-bottom:-4px}.top-detail{max-height:40px}.video-detail > span{height:14px;color:${l.l};
        font-size: ${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:64px}.top-detail > span{font-size:${d.t};
        line-height: ${d.e};
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        color: ${l.l}}.game-winner-team,.game-winner-description{text-align:center;font-size:${p.K};
        line-height: ${p.Z};
        font-weight: 900;
        color: ${l.l};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-family:Arial,Segoe,sans-serif}.game-winner-description{margin-top:-4px}.click-for-detail{display:inline-block;background:rgb(196 43 28);color:rgb(255,255,255);font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-font-size);height:15px;padding:2px 5px;margin:3px;border-radius:4px;font-weight:600;animation:3s ease 0s infinite normal none running gradbg;-webkit-animation:3s ease 0s infinite normal none running gradbg;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}@keyframes gradbg{0%{background-position:10% 0%}50%{background-position:91% 100%}100%{background-position:10% 0%}}.detail-live-score{font-size:${c.k};
        line-height: ${c.F};
        font-weight: 600;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        color: ${v.IR};text-decoration:none}.detail-live-score:hover,.detail-live-score:focus-visible{text-decoration:underline;cursor:pointer}.winner-tag > svg{fill:currentColor;display:block;margin:0 auto}.rtl.winner-tag > svg{transform:scaleX(-1)}.winner-tag.scale-x{transform:scaleX(-1)}.game-time-dot-seperator{margin:0 4px}.live-line{border:none;border-top:1px solid ${w};
        width: 16px;
        height: 0;
        left: 126px;
        top: 20px;
        position: absolute;
        background-color: ${w}}.vert-header,.line-part div:nth-of-type(2),.in-prog-vert,.game-date{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal}.vert-noline,.matchup-vert{display:flex;flex-direction:column;align-items:flex-start}.vert-noline{gap:8px;align-self:stretch;border-radius:8px}.vert-header{font-weight:600;color:${l.l}}.matchup-vert{gap:12px;align-self:stretch}.part-vert,.part-info{display:flex;align-items:center}.part-vert{justify-content:space-between;align-self:stretch}.part-info{width:90%;gap:10px}.icon-vert{width:32px;height:32px;flex-shrink:0}.icon-vert img{max-width:100%;max-height:100%;width:auto;height:auto}.name,.score,.line-part div:nth-of-type(2),.game-date > div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.name,.score{font-size:var(--type-ramp-plus-2-font-size,20px);font-style:normal;font-weight:600;line-height:var(--type-ramp-plus-2-line-height,28px);color:${l.l}}.in-prog-vert{color:var(--header-color-live);font-weight:600}.standings-style{color:var(--standings-color);text-align:right;font-size:var(--type-ramp-base-font-size,14px);font-style:normal;font-weight:400;line-height:var(--type-ramp-base-line-height,20px)}.line-match{display:flex;flex-direction:row;align-items:center;padding:0px;gap:12px;width:100%;height:auto}.line-match > div:first-child{display:flex;flex-direction:row;align-items:flex-start;padding:0px;gap:4px;width:168px}.line-wrap{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;padding:0px;gap:8px;width:168px;height:auto}.line-part{display:flex;flex-direction:row;align-items:center;padding:0px;gap:6px;width:100%}.line-part div:nth-of-type(2){font-weight:400}.line-icon{width:24px;height:24px;flex-shrink:0}.line-icon img{max-width:100%;max-height:100%;width:auto;height:auto}.game-date{font-weight:400;text-align:center;width:68px}.vert-line{width:0px;height:50px;border:1px solid var(--line-color)}.kpart{width:48px;height:74px;gap:4px;align-items:center}.kmtch,.kscr-cntr,.kscr{display:flex;flex-direction:row}.nodate,.date,.kpart{display:flex;flex-direction:column}.kmtch{width:260px;height:74px;gap:0;justify-content:space-between;align-items:center;color:${l.l}}.kicon{width:40px;height:40px;img{width:40px;height:40px}}.kname,.pghdr,.prehdr{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.kname{max-height:24px;max-width:65px;font-weight:600;line-height:24px;font-size:var(--type-ramp-plus-1-font-size,16px);text-align:left}.long-name{max-width:72px;font-size:var(--type-ramp-base-font-size,14px)}.kscr-cntr{justify-content:space-around;font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center;gap:6px;margin-bottom:8px}.kscr{font-weight:600;text-align:center;line-height:var(--type-ramp-plus-4-line-height);font-size:var(--type-ramp-plus-5-font-size);margin:0px 4px;align-items:center;column-gap:4px;gap:6px;font-variant-ligatures:none}.ktime{font-weight:600;text-align:center;font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px);margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;margin-bottom:8px}.nodate{align-items:center;gap:4px;width:148px}.date{align-items:center;gap:4px;width:148px}.pghdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.prehdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.kcntr{text-decoration:none;${m.f}}.kcntr:focus-visible{outline-offset:-1px}.kmtch{padding:12px 0}:host(:first-of-type) :not(.kcntr) .kmtch{padding-top:0}:host(:last-of-type) :not(.kcntr) .kmtch{padding-bottom:0}.g-dtl{display:flex;flex-direction:column;gap:2px;align-items:center}:host-context(.sports-match-list) .kscr{font-size:var(--type-ramp-plus-3-font-size)}:host-context(.sports-match-list) .kcntr .kscr{font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px)}._05u .nodate,._05u .date,._05u .kpart{gap:8px}._05u.kcntr .kmtch{height:98px}.kmtch{padding:7px 0px;width:100%;height:78px;box-sizing:border-box;color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.kname{font-size:var(--smtc-text-global-body2-font-size,15px);line-height:var(--smtc-text-global-body2-line-height,20px)}.r-live-text{font-weight:400;font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);color:var(--ruby-live-text-color,rgba(0,127,48,1));font-weight:600;text-transform:uppercase}.post-game .kscr:not(.winner-team){color:var(--smtc-theme-color-foreground-secondary-650,#4c4642)}.kscr-cntr{display:grid;grid-template-columns:1fr min-content 1fr}.kscr-cntr .part-left{justify-content:end}.kpart{height:auto}.r-live-tag{background:var(--ruby-live-text-bg,rgba(237,246,232,1));border-radius:8px;padding:6px;display:grid;grid-template-columns:auto auto;gap:4px}.r-live-icon{width:20px;height:20px;margin:-2px}.kcntr .winner-tag > svg{width:10px;height:10px}.kcntr .winner-tag svg path{fill:currentColor}`.withBehaviors(new u.N(null,z),(0,b.mr)(f.A` :host{forced-color-adjust:auto}@media screen and (-ms-high-contrast:active){.super-bowl,.participant-container,.top-game-detail,.middle-game-detail,.bottom-game-detail,.top-detail > span,.game-score-text-style,.game-in-progress-text,.video-detail,.game-winner-description{color:${x.A.CanvasText}}.icon-add > svg > g > path,.icon-selected > svg > path{fill:${x.A.LinkText}}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#000000;stroke:${x.A.LinkText}}.click-for-detail{border:1px solid;background-color:${x.A.LinkText}}.detail-live-animation{background-color:${x.A.LinkText}}.scores-line{overflow:hidden}}`),new $.o("isWindowsCopilot",!0,k));var F=i(23587),T=i(50180),M=i(96950),C=i(69259),j=i(36516),A=i(10500),P='<svg width="6" height="7" viewBox="0 0 6 7" fill="none"><path d="M.38 2.82a.8.8 0 0 0 0 1.36l4.5 2.71c.5.3 1.12-.07 1.12-.67V.78c0-.6-.63-.98-1.13-.67L.38 2.82Z" fill="#1A1A1A"/></svg>';const G=(t,e)=>M.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${i=>(0,T.GP)(e?i.viewModel.strings.followSports||"":i.viewModel.strings.haveFollowed||"",t.name||"")}"
        @click="${(i,a)=>i.handleClickFollowIcon(a.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:F.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||"")}"
        @keyup="${(i,a)=>a&&a.event&&"Enter"===a.event.key?i.handleClickFollowIcon(a.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:F.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||""):null}"
        data-t="${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.followTelemetryTag}}"
    >
        <div class="${t=>e?"icon-add":"icon-selected"}"> ${M.qy.partial(e?j.A:A.A)}</div>
    </div>
`,_=M.qy`
    <div class="game-details">
        ${M.qy`<div class="top-game-detail">${t=>t.viewModel.topDetailText}</div>`}
        ${t=>function(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,a=arguments.length>3&&void 0!==arguments[3]?arguments[3]:null;switch(t.getMatchData().gameStateCatetory){case F.Xp.preGame:return null==i?J():K(i);case F.Xp.inprogressGame:return at();case F.Xp.postGame:return e?it():(0,T.oT)(t.viewModel.topDetailText)?tt(a||""):et();default:return J()}}(t,t.viewModel.shouldShowChampionPostGame,t.viewModel.preGameNotificationMessage,t.viewModel.postGameNotificationMessage)}
    </div>
`,I=M.qy`
    <div class="${t=>t.getMatchData().additionalInfo?"game-details-wrapper":""}">
        ${_}
        ${t=>L(t.getMatchData().additionalInfo)}
    </div>
`,D=()=>M.qy`
    <div class="g-dtl ${t=>t.getMatchData().gameStateCatetory}">
        <div class="nodate">
            ${t=>t.getMatchData().gameStateCatetory===F.Xp.inprogressGame?E:""}
            ${t=>t.getMatchData().gameStateCatetory===F.Xp.postGame?H:""}
            <div class="kscr-cntr">
                <span class="kscr ${t=>{var e;return null!==(e=t.getMatchData().participantOne)&&void 0!==e&&e.isWinner?"winner-team":""}} part-left">
                    ${(0,C.z)(t=>{var e;return null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.isWinner},M.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${M.qy.partial(P)}</span>`)}
                    ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)??""}}
                </span>
                ${t=>{var e,i;return(0,T.oT)((null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)||"")||(0,T.oT)((null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":O}}
                <span class="kscr ${t=>{var e;return null!==(e=t.getMatchData().participantTwo)&&void 0!==e&&e.isWinner?"winner-team":""}}">
                    ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.score)??""}}
                    ${(0,C.z)(t=>{var e;return null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.isWinner},M.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${M.qy.partial(P)}</span>`)}
                </span>
            </div>
        </div>
    </div>
`,V=()=>M.qy`
    <div class="date">
        <div class="prehdr">${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.rightHeaderText}}</div>
        <div class="ktime">${t=>t.getMatchData().gameStartTime}</div>
    </div>
`,L=t=>t?M.qy`
            <div class="game-details-additional-info">
                <div class="round-info">
                    ${t.round||""}
                </div>
                <div class="round-summary-info">
                    ${t.roundSummary||""}
                </div>
                <div class="round-scores-info">
                    ${t.scores}
                </div>
            </div>
        `:null,O=M.qy`
    <span class="scores-line">${M.qy.partial(F.Z5)}</span>
`,N=M.qy`
    <span>${M.qy.partial("·")}</span>
`,E=M.qy`
    <div class="r-live-tag">
        <img class= "r-live-icon" src="${t=>t.viewModel.liveIconUrl}" />
        <span class="r-live-text">${F.T0.Live}</span>
    </div>
`,H=M.qy`
    <div class="pghdr">
        <span>${F.T0.Final}</span>
        ${t=>t.getMatchData().gameDate?N:""}
        <span>${t=>t.getMatchData().gameDate}</span>
    </div>
`,U=M.qy`
    <div class="vert-noline">
        <div class="vert-header ${t=>t.getMatchData().gameStateCatetory===F.Xp.inprogressGame?"in-prog-vert":""}">
            ${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.header}}
        </div>
        <div class="matchup-vert">
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${t=>{var e;return null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name}}">
                        ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}
                    </div>
                </div>
                <div class="score ${t=>t.getMatchData().gameStateCatetory===F.Xp.preGame?"standings-style":""}">${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.topScoreText}}</div>
            </div>
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${t=>{var e;return null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name}}">
                        ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}
                    </div>
                </div>
                <div class="score ${t=>t.getMatchData().gameStateCatetory===F.Xp.preGame?"standings-style":""}">${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.bottomScoreText}}</div>
            </div>
        </div>
    </div>
`,B=M.qy`
    <div class="line-match">
        <div>
            <div class="line-wrap">
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}
                    </div>
                </div>
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}
                    </div>
                </div>
            </div>
            <div class="vert-line"></div>
        </div>
        <div class="game-date">
            <div>${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.leftHeaderText}}</div>
            <div>${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.rightHeaderText}}</div>
        </div>
    </div>
`,W=M.qy`
    ${t=>t.viewModel.isSpotlightCard?Y:X}
`,R=M.qy`
    <div class="kmtch">
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${t=>t.viewModel.participantOneImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}"
                />
            </div>
            <div class="kname ${t=>{var e,i;return null!==(e=t.getMatchData().participantOne)&&void 0!==e&&e.shortName||null===(i=t.getMatchData().participantOne)||void 0===i||!i.name?"":"long-name"}}" title="${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}">
                ${t=>{var e,i;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.shortName)||(null===(i=t.getMatchData().participantOne)||void 0===i?void 0:i.name)||""}}
            </div>
        </div>
        ${t=>(t=>t.getMatchData().gameStateCatetory===F.Xp.inprogressGame||t.getMatchData().gameStateCatetory===F.Xp.postGame?D():V())(t)}
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${t=>t.viewModel.participantTwoImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}"
                />
            </div>
            <div class="kname ${t=>{var e,i;return null!==(e=t.getMatchData().participantTwo)&&void 0!==e&&e.shortName||null===(i=t.getMatchData().participantTwo)||void 0===i||!i.name?"":"long-name"}}" title="${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}">
                ${t=>{var e,i;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.shortName)||(null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.name)||""}}
            </div>
        </div>
    </div>
`,X=M.qy`
    <a class="kcntr ${t=>"0.5u"===t.viewModel.cardSize?"_05u":""}"
        tabindex="${t=>t.viewModel.tabIndex}"
        href="${t=>t.getMatchData().matchClickthroughUrl?t.getMatchData().matchClickthroughUrl:void 0}"
        target="${t=>t.viewModel.linkTarget}"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        ${R}
    </a>
`,Y=M.qy`
    <div class="kcntr ${t=>"0.5u"===t.viewModel.cardSize?"_05u":""}">
        ${R}
    </div>
`,Z=M.qy`
    ${t=>t.viewModel.needsVerticalLine?B:U}
`,q=M.qy`
    <a class="
        sports-match matchup-neutral-background
        ${t=>t.viewModel.noBackgrounds?"no-bg":""}
        ${t=>t.viewModel.reason.length>0?"reason":""}
        ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}
    "
        tabindex="${t=>t.viewModel.tabIndex}"
        href="${t=>t.getMatchData().matchClickthroughUrl?t.getMatchData().matchClickthroughUrl:void 0}"
        target="${t=>t.viewModel.linkTarget}"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        <div role="presentation" class="side-by-side-gradient-container" style="${t=>`background-image: ${t.viewModel.backgroundGradient};`}"></div>
        <div class="side-by-side-matchup-content" style="${t=>t.viewModel.overrideStyleForMatch} ${t=>t.viewModel.matchupContentNotificationStyleIfNecessary}">
            <div class="participant-container ${t=>t.viewModel.shouldDisplayT4?"":" participant-one-alignment"}">
                <div class="participant-icon ${t=>t.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${t=>t.viewModel.showMatchUXV2?"logo-backplate":""}" style="${t=>`background-color: ${t.viewModel.participantOneColor};`}">
                    <img
                        role="presentation"
                        src="${t=>t.viewModel.participantOneImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${t=>G(t.getMatchData().participantOne||{},!t.viewModel.participantOneFollowed)}
                </div>
                <div class="participant-name-style" title="${t=>{var e;return null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name}}">
                    ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}
                </div>
            </div>
            ${I}
            <div class="participant-container right-participant ${t=>t.viewModel.shouldDisplayT4?"":" participant-two-alignment"}">
                <div class="participant-icon ${t=>t.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${t=>t.viewModel.showMatchUXV2?"logo-backplate":""}" style="${t=>`background-color: ${t.viewModel.participantTwoColor};`}">
                    ${(0,C.z)(t=>t.viewModel.isSpotlight2Card,M.qy`${t=>G(t.getMatchData().participantTwo||{},!t.viewModel.participantTwoFollowed)}`)}
                    <img
                        role="presentation"
                        src="${t=>t.viewModel.participantTwoImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${(0,C.z)(t=>!t.viewModel.isSpotlight2Card,M.qy`${t=>G(t.getMatchData().participantTwo||{},!t.viewModel.participantTwoFollowed)}`)}
                </div>
                <div class="participant-name-style" title="${t=>{var e;return null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name}}">
                    ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}
                </div>
            </div>
        </div>
    </a>
`,J=()=>M.qy`
    <div class="middle-game-detail" title="${t=>t.getMatchData().gameStartTime}">
        <span class="game-time-text-style" >
            ${t=>t.getMatchData().gameStartTime||""}
        </span>
    </div>
    <div class="bottom-game-detail ${t=>t.viewModel.shouldDisplayT4?"":"foreground-rest-text-color"}" title="${t=>t.getMatchData().tvChannel?`${t.getMatchData().gameDate} - ${t.getMatchData().tvChannel}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameDate||""}</span>
            ${t=>t.getMatchData().tvChannel&&t.getMatchData().gameDate?O:""}
        <span>${t=>t.getMatchData().tvChannel||""}</span>
    </div>
`,K=t=>M.qy`
    <div class="middle-game-detail" title="${t=>t.getMatchData().gameStartTime+"-"+t.getMatchData().gameDate}">
        <span class="game-time-text-style game-time-notification-text-style">
            ${t=>`${t.getMatchData().gameStartTime||""}`}
        </span>
        <span class="game-time-text-style game-time-notification-text-style game-time-dot-seperator">
            ${t=>""+(t.getMatchData().gameStartTime?"·":"")}
        </span>
        <span class="game-time-text-style game-time-notification-text-style">
            ${t=>`${t.getMatchData().gameDate}`}
        </span>
    </div>
    <div class="${"bottom-game-detail bottom-notification-container pregame"}" title="${t}">
        <span class=${t=>t.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
            ${t}
        </span>
    </div>
`,Q=()=>M.qy`
    <div class="middle-game-detail ${t=>t.viewModel.hasLongScore?"long-score":""}">
        <span class="game-score-text-style">
            ${(0,C.z)(t=>{var e;return null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.isWinner},M.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${M.qy.partial(P)}</span>`)}
            ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)??""}}
        </span>
        ${t=>{var e,i;return(0,T.oT)((null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)||"")||(0,T.oT)((null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":O}}
        <span class="game-score-text-style">
            ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.score)??""}}
            ${(0,C.z)(t=>{var e;return null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.isWinner},M.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${M.qy.partial(P)}</span>`)}
        </span>
    </div>
`,tt=t=>M.qy`
    <div class="top-game-detail"
        title="${t=>t.getMatchData().gameState?`${t.getMatchData().gameDate} - ${t.getMatchData().gameState}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameState||""}</span>
        ${t=>t.getMatchData().gameDate&&t.getMatchData().gameState?N:""}
        <span>${t=>t.getMatchData().gameDate||""}</span>
    </div>
    ${Q()}
    ${(0,C.z)(!(0,T.oT)(t),M.qy`
        <div class="${"bottom-game-detail bottom-notification-container"}" title="${t}">
            <span class=${t=>t.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
                ${t}
            </span>
        </div>
    `)}
`,et=()=>M.qy`
    ${Q()}
    <div class="bottom-game-detail"
        title="${t=>t.getMatchData().gameState?`${t.getMatchData().gameDate} - ${t.getMatchData().gameState}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameState||""}</span>
        ${t=>t.getMatchData().gameDate&&t.getMatchData().gameState?N:""}
        <span>${t=>t.getMatchData().gameDate||""}</span>
    </div>
`,it=()=>M.qy`
    <div class="top-game-detail superbowl-top">
        <div class="game-winner-team">
            ${t=>rt(t)}
        </div>
        <div class="game-winner-description" title="${t=>t.viewModel.strings.champions||""}">
            ${t=>t.viewModel.strings.championsFormatted}
        </div>
    </div>
    <div class="middle-game-detail">
        <span class="game-score-text-style">
            ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)??""}}
        </span>
        ${t=>{var e,i;return(0,T.oT)((null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)||"")||(0,T.oT)((null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":O}}
        <span class="game-score-text-style">
            ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.score)??""}}
        </span>
    </div>
`,at=()=>M.qy`
    <div class="middle-game-detail">
        ${t=>t.viewModel.enableLiveScores?M.qy`
    <span class="game-score-text-style">
        ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)??""}}
    </span>
    ${t=>{var e,i;return(0,T.oT)((null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)||"")||(0,T.oT)((null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":O}}
    <span class="game-score-text-style">
        ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.score)??""}}
    </span>
`:M.qy`
    <span class="click-for-detail" title="click to see score and details">
        ${t=>(t.viewModel.strings.sportsLive||"LIVE").toLocaleUpperCase()}
    </span>
`}
    </div>
    <div class="bottom-game-detail ${t=>t.viewModel.enableLiveScores?"live-scores-detail":""}" title="${t=>t.getMatchData().tvChannel?`${t.getMatchData().gamePeriodAndClock} - ${t.getMatchData().tvChannel}`:t.getMatchData().gamePeriodAndClock}">
        <span class="game-in-progress-text" title="${t=>t.getMatchData().gamePeriodAndClock}">
            ${t=>t.getMatchData().gamePeriodAndClock||""}
        </span>
        ${t=>t.getMatchData().gamePeriodAndClock&&t.getMatchData().tvChannel?O:""}
        <span title="${t=>t.getMatchData().tvChannel}">${t=>t.getMatchData().tvChannel||""}</span>
    </div>
`,rt=t=>{const e=t.getMatchData();if(e&&e.gameStateCatetory==F.Xp.postGame){var i,a;let t=null!==(i=e.participantOne)&&void 0!==i&&i.isWinner?null===(a=e.participantOne)||void 0===a||null===(a=a.name)||void 0===a?void 0:a.toUpperCase():null;var r,n;if(!t)t=null!==(r=e.participantTwo)&&void 0!==r&&r.isWinner?null===(n=e.participantTwo)||void 0===n||null===(n=n.name)||void 0===n?void 0:n.toUpperCase():null;return t||""}return""},nt=M.qy`
    ${t=>t.isVertical()?M.qy` ${Z} `:t.isCopilotTheme()?M.qy` ${W} `:t.viewModel?M.qy` ${q} `:void 0}
`;let st=class extends s{};st=(0,a.Cg)([(0,o.E)({name:"sports-match",template:nt,styles:S,shadowOptions:{delegatesFocus:!0}})],st)},82724(t,e,i){i.r(e),i.d(e,{SportsMatchTransformer(){return l}});var a=i(23587),r=i(79811),n=i(31157),s=i(58792),o=i(94016);class l extends a.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.getPreGameNotificationMessage=t=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==t&&t.gameStateCatetory===a.Xp.preGame?t.preGameNotificationMessage:null,this.getPostGameNotificationMessage=t=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==t&&t.gameStateCatetory===a.Xp.postGame?t.postGameNotificationMessage:null,this.getMatchupContentNotificationStyleIfNecessary=t=>this.isNotificationEnabledAndAvailable(t)?"side-by-side-matchup-content-notification":"",this.isNotificationEnabledAndAvailable=t=>null!=this.getPreGameNotificationMessage(t)||null!=this.getPostGameNotificationMessage(t),this.getTeamColor=function(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"";return null!=t&&t.primaryColor?(0,r.gS)(t.primaryColor):null!=t&&t.primaryColorHex?(0,r.gS)(t.primaryColorHex):e},this.getTeamImageUrl=t=>{if(null!=t&&t.imageUrl)return(0,r.Hv)(null==t?void 0:t.imageUrl);const e=(0,r.iK)(null==t?void 0:t.imageId,!(null!=t&&t.imageId),this.transformerProvider.config.teamImageInfoEnhanced);return(0,r.Hv)(e)},this.getBackgroundGradient=t=>{if(!t)return"";const e=this.getTeamColor(t.participantOne),i=this.getTeamColor(t.participantTwo);if(!e||!i||e===i&&"#ffffff"===e.toLowerCase())return"";const a=this.hexToRgba(e,1),r=this.hexToRgba(e,.35),n=this.hexToRgba(i,1),s=this.hexToRgba(i,.35);return`linear-gradient(\n                        ${this.isRTLDirection()?"-120deg":"120deg"},\n                        ${a} 0%,\n                        ${a} 10.75%,\n                        ${r} 11%,\n                        ${r} 14.75%,\n                        transparent 15%,\n                        transparent 85%,\n                        ${s} 85.25%,\n                        ${s} 89%,\n                        ${n} 89.25%,\n                        ${n} 100%)`},this.isRTLDirection=()=>document.dir===n.O.rtl,this.getGameDate=t=>{const{gameStartDateTime:e,gameStateCatetory:i}=t||{};if(this.isCopilotTheme){const t=(0,r.yn)(e),n=i===a.Xp.postGame?{month:"short",day:"numeric"}:{weekday:"short",day:"numeric",month:"long"};return t.toLocaleDateString(s.T3.CurrentMarket,n)}{const t=(0,r.yn)(e);return(0,r.AL)(t,s.T3.CurrentMarket)}}}async transform(t){return{viewModel:await this.getViewModel(t)}}updateAdditionalInfo(t){const{sportsMatchData:e}=t;if(e&&e.additionalInfo){if(!e.additionalInfo.round&&e.additionalInfo.roundLocKey){var i;let t=this.transformerProvider.strings[e.additionalInfo.roundLocKey];null===(i=e.additionalInfo.roundParams)||void 0===i||i.forEach((e,i)=>{var a;t=null===(a=t)||void 0===a?void 0:a.replace(`{${i}}`,e)}),e.additionalInfo.round=t}if(!e.additionalInfo.roundSummary&&e.additionalInfo.roundLocKey){var a;let t=this.transformerProvider.strings[e.additionalInfo.roundSummaryLocKey];null===(a=e.additionalInfo.roundSummaryParams)||void 0===a||a.forEach((e,i)=>{var a;t=null===(a=t)||void 0===a?void 0:a.replace(`{${i}}`,e)}),e.additionalInfo.roundSummary=t}}}getGroupInfo(t){const e=t.matchData.sportsMatchData;var i;if(e.groupInfo)return null===(i=this.transformerProvider.strings.groupText)||void 0===i?void 0:i.replace("${0}",e.groupInfo)}hexToRgba(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:1;const i=t.match(/\w\w/g);if(!i)return"";const[a,r,n]=i.map(t=>parseInt(t,16));return`rgba(${a},${r},${n},${e})`}hasLongScore(t){var e,i;const a=(null===(e=t.participantOne)||void 0===e?void 0:e.score)||"",r=(null===(i=t.participantTwo)||void 0===i?void 0:i.score)||"";return a.length+r.length>6}getHeaderText(t){var e,i,r,n;if(!t||0===Object.keys(t).length)return{header:"",topScoreText:"",bottomScoreText:"",leftHeaderText:"",rightHeaderText:""};const{gameStartDateTime:s,gameDate:o,gamePeriodAndClock:l,gameStateCatetory:d}=t,c=null===(e=t.participantOne)||void 0===e?void 0:e.score,p=null===(i=t.participantTwo)||void 0===i?void 0:i.score,g=null===(r=t.participantOne)||void 0===r?void 0:r.standings,h=null===(n=t.participantTwo)||void 0===n?void 0:n.standings,v=new Date(s).getFullYear(),m=t.gameStartTime?t.gameStartTime.toLocaleLowerCase():"";let u,x,f,$,b;switch(d){case a.Xp.preGame:u=m,x=this.isCopilotTheme?o:`${o}, ${v}`,f=g,$=h;break;case a.Xp.inprogressGame:u=this.transformerProvider.strings.sportsLive.toLocaleUpperCase(),x=l,f=c,$=p;break;case a.Xp.postGame:u=this.transformerProvider.strings.sportsStateFinal,x=`${o}, ${v}`,f=c,$=p;break;default:u=m,x=o,f=g,$=h}switch(!0){case!!u&&!!x:b=`${u} • ${x}`;break;case!!u:b=u;break;case!!x:b=x;break;default:b=""}return{header:b,topScoreText:f,bottomScoreText:$,leftHeaderText:u,rightHeaderText:x}}async getViewModel(t){const{matchData:e,isVertical:i,telemetryConstants:n,showMatchUXV2:l,noBackgrounds:d,participantOneFollowed:c,participantTwoFollowed:p,reason:g,isContainLiveMatch:h,parentTelemetryObject:v,topDetailText:m,useLargeTeamIcon:u,hasVerticalLine:x,isSpotlight2Card:f,isSpotlightCard:$}=t||{},b=e.sportsMatchData;this.isCopilotTheme=t.isCopilotTheme||!1,this.updateAdditionalInfo(e),"string"!=typeof b.gameState&&(b.gameStateCatetory=(0,r.m5)(b.gameState.state));const w=(0,r.yn)(b.gameStartDateTime);b.gameDate=this.getGameDate(b),b.gameStartTime=(b.gameStartDateTimeIsToBeAnnounced?null:(0,r.ry)(w,s.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,"string"!=typeof b.gameState&&(b.gamePeriodAndClock=(0,r.PH)(b.gameState)),"string"!=typeof b.gameState&&(b.gamePeriod=b.gameState.gamePeriod),b.participantOne&&(b.participantOne.scheduleUrl=(0,r.Ot)(b.participantOne.gameCenterUrl)),b.participantTwo&&(b.participantTwo.scheduleUrl=(0,r.Ot)(b.participantTwo.gameCenterUrl)),b.gameCenterUrl&&(b.matchClickthroughUrl=(0,r.Ot)(b.gameCenterUrl)),b.participantOne.imageUrl=(0,r.iK)(b.participantOne.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),b.participantTwo.imageUrl=(0,r.iK)(b.participantTwo.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),b.gameState=b.gameStateCatetory===a.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:b.gameStateCatetory;const y={...n,name:a.BP.Game},k=i||t.isCopilotTheme,z=this.transformerProvider.config.enableLiveScores,S=l&&!d&&!z,F=(0,r.jJ)()?`${s.T3.StaticsUrl}/pr-5772998/icons-wc/icons/sports/LiveIconDark.svg`:`${s.T3.StaticsUrl}/latest/icons-wc/icons/sports/LiveIcon.svg`;return{backgroundGradient:z||l?"":this.getBackgroundGradient(b),followClickHandler:this.transformerProvider.followClickEntityHandler,followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(v,{...y,name:a.BP.FollowTeam},!0),hasLongScore:this.hasLongScore(b),gameNumber:"number",linkTarget:"_blank",matchData:e,matchupContentNotificationStyleIfNecessary:this.getMatchupContentNotificationStyleIfNecessary(b),overrideStyleForMatch:"",participantOneColor:S?this.getTeamColor(b.participantOne):"",participantOneFollowed:c,participantOneImgIcon:this.getTeamImageUrl(b.participantOne),participantTwoColor:S?this.getTeamColor(b.participantTwo):"",participantTwoFollowed:p,participantTwoImgIcon:this.getTeamImageUrl(b.participantTwo),postGameNotificationMessage:this.getPostGameNotificationMessage(b),preGameNotificationMessage:this.getPreGameNotificationMessage(b),reason:g,shouldDisplayT4:!h,shouldShowChampionPostGame:!1,shouldShowFollowIcon:!1,shouldUnderlineNotificationMessage:!1,showLiveDetail:!1,strings:{...this.transformerProvider.strings,championsFormatted:this.transformerProvider.strings.champions&&this.transformerProvider.strings.champions.toUpperCase()||a.kt},tabIndex:0,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(v,y),cardSize:t.cardSize,topDetailText:this.getGroupInfo(t)||m||"",useLargeTeamIcon:z||u,enableLiveScores:z||l,showMatchUXV2:z||l,noBackgrounds:d,isVertical:i,headerText:k?this.getHeaderText(b):void 0,needsVerticalLine:x,liveIconUrl:F,isSpotlight2Card:f,isSpotlightCard:$,isCopilotTheme:this.isCopilotTheme,isWindows:s.T3.AppType===o.u.WindowsNewsWidgets}}}},84564(t,e,i){i.d(e,{z(){return s}});var a=i(56911),r=i(60815),n=i(92011);class s extends n.L{}(0,a.Cg)([r.sH],s.prototype,"viewModel",void 0)},87076(t,e,i){i.r(e),i.d(e,{SportsScoresTable(){return w}});var a=i(56911),r=i(92079);class n extends r.a{}var s=i(92011),o=i(48751),l=i(86856),d=i(74849),c=i(22131),p=i(12640);const g=d.A`
`,h=d.A`
`,v=d.A`
.table-cntnr{display:flex;gap:6px;align-self:stretch;justify-content:space-between}.part-row,.header-row{display:grid;align-self:stretch;justify-content:end}.header-row:last-child{gap:0}.item-cntnr{align-items:center;justify-content:end}.score-item,.header-item{text-align:center;font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:600;line-height:var(--type-ramp-minus-1-line-height,16px);min-width:16px;max-width:16px;color:${o.l}}.header-item{font-weight:400}.title-item{display:grid;text-align:left;font-size:var(--type-ramp-minus-1-font-size,12px);font-style:normal;font-weight:600;line-height:var(--type-ramp-minus-1-line-height,16px);min-width:24px;height:16px;color:${o.l};white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bold-items{font-weight:600}.title-cntnr,.item-cntnr{display:flex;flex-direction:column;gap:6px}`.withBehaviors(new l.t(null,h),new p.N(null,g),(0,c.mr)(d.A` :host{forced-color-adjust:auto}`));var m=i(96950),u=i(39957),x=i(69259);const f=m.qy`
    ${t=>{var e;return(t=>m.qy`
        ${(0,u.ux)(t=>t.viewModel.participants??[],m.qy`<div class="part-row" style=${t}>
                ${(0,u.ux)(t=>t.gameScore??[],m.qy`<div class="score-item">
                    ${t=>t}
                </div>`)}
        </div>`)}
    `)(null===(e=t.viewModel)||void 0===e?void 0:e.tableStyle)}}
`,$=m.qy`
    <div class="table-cntnr">
            <div class ="title-cntnr">
                <div class="title-item"></div>
                ${(0,u.ux)(t=>t.viewModel.participants??[],m.qy`<div class="title-item">
                    ${t=>t.participantName}
                </div>
                `)}
            </div>
            <div class="item-cntnr" style="${t=>{var e;return null!==(e=t.viewModel)&&void 0!==e&&e.isLarge?"width: 100%;":"width: 70%;"}}">
                <div class="header-row" style="${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.tableStyle}}">
                    ${(0,u.ux)(t=>t.viewModel.headerRow??[],m.qy`<div class="header-item">
                        ${t=>t}
                    </div>`)}
                </div>
                    ${f}
            </div>
    </div>
`,b=m.qy`
    ${(0,x.z)(t=>void 0!==t.viewModel,$)}
`;let w=class extends n{};w=(0,a.Cg)([(0,s.E)({name:"sports-scores-table",template:b,styles:v,shadowOptions:{delegatesFocus:!0}})],w)},92079(t,e,i){i.d(e,{a(){return s}});var a=i(56911),r=i(92011),n=i(31525);let s=class extends r.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};s=(0,a.Cg)([n.x],s)},99657(t,e,i){i.d(e,{D(){return s},I(){return n}});var a=i(45755);const{create:r}=a.G,n=r("sloppy-click-z-index",1),s=r("click-z-index",1)}}]);