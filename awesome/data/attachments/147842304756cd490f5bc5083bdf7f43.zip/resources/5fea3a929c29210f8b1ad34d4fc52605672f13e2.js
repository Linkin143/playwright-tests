(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["signal-overlay"],{903(e,t,i){"use strict";i.d(t,{D(){return d},G(){return s}});var r=i(93552),o=i(77367);let n,a;const s=()=>{a=new Map,n=new IntersectionObserver(e=>{for(const[e,t]of a.entries()){if(!(e&&t&&t.cardElement&&t.extTelemetry))return;const i=l(t.cardElement),r=i&&JSON.parse(i),o=r&&r.ext;if(!o||!o.row||!o.col)return;const n=`${o.row}-${o.col}`;e!==n&&(a.delete(e),a.set(n,{cardElement:t.cardElement,extTelemetry:o}))}e.forEach(e=>{const t=e.target,i=t&&l(t),r=i&&JSON.parse(i),o=r&&r.ext;if(!o||!o.row||!o.col)return;const n=`${o.row}-${o.col}`;e.isIntersecting?a.set(n,{cardElement:t,extTelemetry:o}):a.has(n)&&a.delete(n)})},{threshold:.99}),window.addEventListener("beforeunload",()=>{if("hidden"!==document.visibilityState)for(const[e,t]of a.entries()){if(!(e&&t&&t.cardElement&&t.extTelemetry))return;const i=e.split("-");if(isNaN(Number(i[0]))||isNaN(Number(i[1])))return;const r=parseFloat(i[0]),o=parseFloat(i[1]);c(t,a.get(`${r+1}-${o}`));c(t,a.get(`${r}-${o+1}`))}})},d=e=>{n&&e&&n.observe(e)};function l(e){if(e.classList&&e.classList.contains("infopane")){const t=e.querySelector("cs-article-card"),i=t&&t.shadowRoot&&t.shadowRoot.querySelector("cs-content-card");return i&&i.anchorTelemetryTag}return e.anchorTelemetryTag?e.anchorTelemetryTag:e.getAttribute("data-t")?e.getAttribute("data-t"):void 0}function c(e,t){if(!(e&&t&&t.cardElement&&t.extTelemetry&&e!==t))return;const i=e.cardElement.getBoundingClientRect(),n=t.cardElement.getBoundingClientRect();if(0===i.height||0===i.width||0===n.height||0===n.width)return;if(!(i.top>n.bottom||i.right<n.left||i.bottom<n.top||i.left>n.right)){const a=e.extTelemetry,s=t.extTelemetry;o.YT.sendAppErrorEvent({...r.ABd,message:"Feed cards are overlapping",pb:{...r.ABd.pb,customMessage:`{"${e.cardElement.id}": { "position": ${JSON.stringify(i)}, "slot": ${a.slot}, "template": "${a.template}", "row": ${a.row}, "col": ${a.col} },"${t.cardElement.id}": { "position": ${JSON.stringify(n)}, "slot": ${s.slot}, "template": "${s.template}", "row": ${s.row}, "col": ${s.col}}}`}})}}},1413(e,t,i){"use strict";i.d(t,{P(){return n},y(){return a}});var r=i(96950),o=i(82774);function n(e,t){return t?.some(t=>t.slot===e)}function a(e){const t=e.slotName??"";return r.qy`
        <div id="${t}" class="${t}" part="${t}">
            <slot
                name="${t}"
                ${e.slottedRef?(0,o.e)(e.slottedRef):""}
            >
                ${e.slottedDefault??""}
            </slot>
        </div>
    `}},5662(e,t,i){"use strict";i.r(t),i.d(t,{GlobalStyles(){return X},SignalOverlay(){return de},SignalOverlayStyles(){return K},SignalOverlayTemplate(){return _e},ToolingInfo(){return ze},openedInSession(){return se}});var r=i(2958),o=i(37180),n=i(54994),a=i(79454),s=i(31782),d=i(8481),l=i(5569),c=i(96950),h=i(69259),p=i(2665),g=i(74849),u=i(22131),f=i(48751),m=i(28986),v=i(58914);const x=g.A` :host(:hover){box-shadow:none !important}.interest{color:${f.l};
    }
`,b=g.A` :host([size="_1x_2y"]){width:calc(var(--card-base-width)* 1px);height:calc((var(--card-base-height)* 2px) +(var(--card-base-gap)* 1px))}:host(.disable-hover) .card-outer:hover .card-title,:host(.disable-hover) .card-outer:active .card-title .card-outer:focus-visible .card-title{text-decoration:none}:host(.disable-hover:hover) .card-image{filter:brightness(1)}:host(.disable-hover) .card-outer.shadow:hover{box-shadow:0px 1px 2px rgba(0,0,0,0.14),0px 0px 2px rgba(0,0,0,0.12)}::part(action-tray){display:none}:host(.interest-title) ::part(action-tray){display:flex;background-color:${m.Rg};justify-content:center}:host(.interest-title) cs-content-card::part(footer-end){display:none}.card-title{-webkit-line-clamp:4}::part(heading){-webkit-line-clamp:4}:host(.interest-title) .card-title{-webkit-line-clamp:3}:host(.interest-title) ::part(heading){-webkit-line-clamp:3}.interest{color:rgba(0,0,0,0.62);font-weight:600;font-size:16px}:host(.mul-article){width:300px;height:308px;box-shadow:0px 0px 25px 0px rgba(0,0,0,0.25)}:host(.mul-article) cs-card{width:300px;height:308px}:host(.mul-article) .text{height:86px}:host(.mul-article) ::part(heading){-webkit-line-clamp:3}:host(.mul-article) ::part(heading){width:auto;height:65px;font-size:18px;font-weight:600;line-height:20px;letter-spacing:0em}:host(.mul-article) img[slot="media"]{height:142px}:host(.mul-article) .card-title{font-size:14px;font-weight:600;line-height:20px;letter-spacing:0em;-webkit-line-clamp:3}`.withBehaviors((0,u.G2)(x)),y=g.A`
    ${v.l},
    ${b}
`,w=l.d.compose({name:"cs-article-card-fre",styles:y,template:(0,p._)({attribution:c.qy`${a.Au}`,footerStart:c.qy`${(0,h.z)(e=>e.interestTitle,s.LH)}`,footerEnd:void 0,title:c.qy`${d.B2}`})});var k=i(65614),$=i(84056),_=i(56911),z=i(58792);const S=()=>`${(0,z.rA)().StaticsUrl}latest/interests-manager/neutral-following-star-sparkle-light.png`,R=()=>`${(0,z.rA)().StaticsUrl}latest/interests-manager/neutral-following-star-sparkle-dark.png`,C=()=>`${(0,z.rA)().StaticsUrl}latest/interests-manager/sparkle-star-neutral-to-accent.gif`,F=()=>`${(0,z.rA)().StaticsUrl}latest/interests-manager/accent-following-star-sparkle.png`,I=()=>`${(0,z.rA)().StaticsUrl}latest/interests-manager/sparkle-to-checkmark-star-confetti.gif`;var T=i(68656),D=i(93557),P=i(82545),A=i(99262),E=i(66937),O=i(35444),U=i(12928),N=i(46528),L=i(22341),M=i(93552),q=i(17918),B=i(85349),H=i(77367),W=i(39144),j=i(6589),G=i(60815),J=i(12680),V=i(36452);const X="\nbody{overflow:hidden}",Q=g.A`
.signal-fre-wrapper{background:linear-gradient(0deg,rgba(0,0,0,0.06),rgba(0,0,0,0.06)),linear-gradient(0deg,#313131,#313131)}.feedback-btn{border:1px solid rgba(102,102,102,1)}.feedback-btn:hover{background-color:#3d3d3d;border-color:#757575}.feedback-btn:active{background-color:#1f1f1f;border-color:#6b6b6b}.feedback-btn.selected{background-color:rgba(255,255,255,1);border-color:rgba(102,102,102,1);color:rgba(0,0,0,1)}.display-ch{--content-color:#656871;background:linear-gradient(0.25turn,transparent,#888b94,transparent),linear-gradient(var(--content-color),var(--content-color)),radial-gradient(38px circle at 19px 19px,var(--content-color) 50%,transparent 51%),linear-gradient(var(--content-color),var(--content-color)),linear-gradient(var(--content-color),var(--content-color));background-size:300px 306px,300px 157px,70px 70px,210px 25px,280px 60px;background-position:-300px 0,0 0,0px 167px,48px 174px,10px 214px;background-repeat:no-repeat}.related-tag{background:rgba(55,55,55,0.8);color:rgba(255,255,255,1)}.related-tag svg{fill:rgba(255,255,255,1)}.mul-article .header-title2{color:rgba(105,161,250,1)}.fog{background:linear-gradient(180deg,rgba(0,0,0,0) 0%,#000000 68.5%)}.mul-article .so-header{background:rgba(31,31,31,0.8)}`,K=g.A`
fluent-dialog{--dialog-width:748px;--layer-corner-radius:16;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.4);backdrop-filter:blur(12.5px);display:flex;z-index:999;justify-content:center;align-items:center}.signal-fre-wrapper{display:grid;grid-template-rows:228px 326px auto;height:100%;width:100%;border-radius:16px;position:relative}.so-header{display:flex;align-items:center;flex-direction:column;justify-content:flex-start;overflow:hidden}.close-button-container{display:flex;position:absolute;width:748px;z-index:2}.close-button-container fluent-button{background:transparent;position:absolute;top:8px;inset-inline-end:20px}.close-button svg{height:24px;width:24px}.feedback-btn{font-size:20px;font-weight:600;border-radius:8px;border:2px solid rgba(0,0,0,0.08);background:transparent}.feedback-btn:hover{background-color:#f5f5f5;border-color:#c7c7c7}.feedback-btn:active{background-color:#e0e0e0;border-color:#b3b3b3}.feedback-btn.selected{background-color:rgba(41,41,41,1);border-color:rgba(0,0,0,0.18);color:rgba(255,255,255,1)}.feedback-btn svg{width:24px;height:24px}.loading-ring{width:60px;height:60px;margin:0}.done-button{font-size:20px;height:44px;border-radius:6px;padding-inline:4px}.so-header{z-index:1}.header-title1{font-size:24px;font-weight:600;line-height:32px;margin-top:16px}.header-title2{font-size:16px;font-weight:500;line-height:22px;margin-top:6px}.article-progress{width:100px;height:100px;margin:unset}.header-star-img{position:absolute;height:59px;width:59px;top:20px;left:20px}.article-progress::part(progress){overflow:visible}.article-progress::part(background){stroke-width:0.8px}.article-progress::part(determinate){stroke:url(#lingra);stroke-width:1.6px;-webkit-filter:drop-shadow( -0.5px 0px 0.3px rgba(0,0,0,.05));filter:drop-shadow( -0.5px 0px 0.3px rgba(0,0,0,.05))}.checkmark-gif{height:147px;top:-24px;width:200px;left:-48px}.hide-card{visibility:hidden}.card-holder{display:none}.display-ch{display:inherit;position:absolute;height:306px;width:300px;border-radius:16px;background:linear-gradient(0.25turn,transparent,#fff,transparent),linear-gradient(#eee,#eee),radial-gradient(38px circle at 19px 19px,#eee 50%,transparent 51%),linear-gradient(#eee,#eee),linear-gradient(#eee,#eee);background-repeat:no-repeat;background-size:300px 306px,300px 157px,70px 70px,210px 25px,280px 60px;background-position:-300px 0,0 0,0px 167px,48px 174px,10px 214px}@media (prefers-reduced-motion:no-preference){.display-ch{animation:loading 1.5s infinite}@keyframes loading{to{background-position:300px 0,0 0,0px 167px,48px 174px,10px 214px}}}.mul-article{transition:0.4s;display:flex;position:relative}.mul-article .so-header{position:absolute;width:100%;border-top-left-radius:16px;border-top-right-radius:16px;backdrop-filter:blur(10px);background:rgba(250,250,250,0.8)}.scroll-region{overflow-y:scroll;width:100%;padding-top:100px;display:flex;flex-direction:column;margin-inline-end:30px}.articles{display:grid;grid-template-columns:repeat(auto-fill,300px);gap:12px;padding-bottom:20px;width:612px;margin-inline-start:68px}.scroll-region::-webkit-scrollbar{width:6px}.scroll-region::-webkit-scrollbar-track{border-radius:4px;margin:8px;margin-top:100px}.scroll-region::-webkit-scrollbar-thumb{background:${V.I2};border-radius:20px;border:transparent;height:60px}.mul-card-container{position:relative}.mul-fb{position:absolute;bottom:12px;left:12px;width:272px;height:40px;box-shadow:none}.loading-article{display:flex;justify-content:center;height:70px}.progress{position:relative;height:100px;width:100px;margin-top:32px}.titles{display:flex;flex-direction:column;align-items:center}.mul-article .checkmark-gif{top:-22px;left:-48px}.down.mul-article{grid-template-rows:100px auto}.down .so-header{flex-direction:row;height:80px}.down .progress{margin-top:10px;margin-inline-start:40px;margin-inline-end:25px;height:60px;width:60px}.down .article-progress{width:60px;height:60px}.down .header-star-img{position:absolute;height:40px;width:40px;top:10px;left:10px}.down .checkmark-gif{top:-18px;left:-33px;height:94px;width:128px}.down .titles{width:375px;align-items:flex-start}.like-btn-title{display:none}.mul-card-container .feedback-btn:hover{background:rgba(33,105,235,1);color:rgba(255,255,255,1)}.mul-card-container .feedback-btn.selected{background:rgba(224,237,255,1);color:rgba(33,105,235,1)}.mul-card-container .feedback-btn:hover .like-btn-title{display:inherit}.mul-card-container .feedback-btn.selected .like-btn-title{display:inherit}.related{position:absolute;top:91px;left:149px;width:77px;height:18px;border-radius:4px;color:rgba(33,105,235,1);font-size:10px;font-weight:600;line-height:14px;text-align:center;background:rgba(224,237,255,1)}.related-tag{display:flex;background:rgba(0,0,0,0.8);color:rgba(255,255,255,1);border-radius:5px;font-size:12px;font-weight:400;line-height:20px;height:26px;width:181px;position:absolute;bottom:60px;left:284px;z-index:1;align-items:center;cursor:default}.related-tag svg{margin-inline:4px;margin-top:4px;height:16px;width:16px;fill:rgba(255,255,255,1)}.mul-article .so-header .loading-ring{margin-top:32px}.down .so-header .loading-ring{margin-top:10px;margin-inline-start:40px;margin-inline-end:25px;height:60px;width:60px}.mul-article .header-title2{color:rgba(33,105,235,1)}.fog{background:linear-gradient(180deg,rgba(255,255,255,0) 0%,#FFFFFF 68.5%);width:748px;height:80px;position:absolute;bottom:0;border-radius:0 0 16px 16px;display:flex;justify-content:center}.fog .done-button{width:220px;justify-content:center;margin-top:8px}fluent-progress-ring.hide{display:none}`.withBehaviors((0,u.G2)(Q));var Z=i(36067);const Y={overlay:{name:"OverlayDialog",type:B.MJ.Module},like(e){return{name:"Upvote",action:B.EG.Click,behavior:B.MS.Like,content:{id:e,type:B.b5.Article,headline:"Upvote"}}},undoLike(e){return{name:"UndoUpvote",action:B.EG.Click,behavior:B.MS.Unlike,content:{id:e,type:B.b5.Article,headline:"UndoUpvote"}}},dislike(e){return{name:"Downvote",action:B.EG.Click,behavior:B.MS.Dislike,content:{id:e,type:B.b5.Article,headline:"Downvote"}}},buildFeed:{name:"BuildMyFeed",action:B.EG.Click,behavior:B.MS.Refresh},close:{name:"Closedialog",action:B.EG.Click,behavior:B.MS.Close}};class ee{constructor(e){this.telemetryObject=e}getTelemetryTag(e){return this.telemetryObject.addOrUpdateChild(e).getMetadataTag()}}var te=i(39671),ie=i(90905),re=i(25109),oe=i(43922),ne=i(3083);const ae=function(e,t){let i,r=arguments.length>2&&void 0!==arguments[2]&&arguments[2];if(!e)return;const{url:o,focalRegion:n}=e;if(o){const e={width:300,height:r?142:156,focalRegion:n?{x1:n.x1,y1:n.y1,x2:n.x2,y2:n.y2}:void 0,enableDpiScaling:!0,mode:ne.Pz.FocalCrop,devicePixelRatio:2};i={source:(0,ne.oQ)(o,e),altText:t,imageWidth:300,imageHeight:156}}return i};let se=!1;class de extends te.U{constructor(){super(...arguments),this.isOverlayOpen=!1,this.currArticleCount=-1,this.fetchingData=!1,this.buildingFeed=!1,this.noMoreInterests=!1,this.loadingMulArticle=!1,this.articleQueue=[],this.showArticlesBelowToast=!1,this.numRelatedArticles=0,this.scrollRegionRefInitialized=!1,this.requestContext=new N.bb,this.noContents=!1,this.isEngaged=!1,this.onClickLike=(0,ie.A)(e=>{if(this.isEngaged=!0,e)if(e.selected){const t={...e,selected:!1};this.replaceArticle(e,t),this.sendAction(!0,!0,e),this.revertAnimation()}else{const t={...e,selected:!0},i=this.replaceArticle(e,t);if(-1===i)return;this.sendAction(!0,!1,e),this.fetchRelatedArticle(e,i),this.proceedMultipleArticles()}},200),this.setCardHeightHandler=(()=>{var e;const t=window.innerHeight;if(t<600)return void this.closeOverlay(A.R.Ignored);t<900&&(this.dialogHeight=530);const i=(0,N.KP)(null===(e=this.requestContext)||void 0===e||null===(e=e.data)||void 0===e?void 0:e.innerWidth,"innerWidth");(!t||i<800)&&this.closeOverlay(A.R.Ignored)}).bind(this),this.fetchNicheInterests=async e=>{var t;return this.nicheInterestService&&this.nicheInterestService.getNicheInterests({initialRequest:{...(null===(t=this.config)||void 0===t||null===(t=t.cardProviderConfig)||void 0===t?void 0:t.initialRequest)||{},freScenario:"article",freMode:e?"tag-related":"tag-exploration",count:e?this.config.numberOfRelatedArticles:this.config.numberOfTitlesToFetch,InterestIds:e,start:this.nextPageUrlSkip}},!0)||[]},this.documentKeydownHandler=e=>{"Escape"===e.key&&this.closeOverlay(A.R.Dismissed,B.EG.KeyPress,!0)},this.scrollRegionScrollHandler=(0,ie.A)(()=>{this.scrollRegionRef&&!this.loadingMulArticle&&this.scrollRegionRef.scrollTop+this.scrollRegionRef.clientHeight>=this.scrollRegionRef.scrollHeight&&(this.loadingMulArticle=!0,this.numRelatedArticles=0,this.showArticlesBelowToast=!1,this.fetchAndMapArticle())},200)}progressRingRefChanged(){this.progressRingRef&&this.colorProgressRing()}scrollRegionRefChanged(){this.scrollRegionRef&&!this.scrollRegionRefInitialized&&(this.scrollRegionRefInitialized=!0,this.scrollRegionRef.addEventListener("scroll",this.scrollRegionScrollHandler))}metadataChanged(){var e,t,i;if(!this.metadata)return;const r=null===(e=this.metadata)||void 0===e||null===(e=e.subCards)||void 0===e?void 0:e.find(e=>"Topics"===(null==e?void 0:e.type));if(!r||null===(t=r.subCards)||void 0===t||!t.length)return(0,L.vV)(M.H4J,"No interests returned"),this.noContents=!0,void this.closeOverlay(A.R.Ignored);const o=this.processArticles(r.subCards);if(!o.length&&0==this.articleQueue.length)return this.noMoreInterests=!0,this.noContents=!0,void this.closeOverlay(A.R.Ignored);const n=this.metadata.url&&(null===(i=new URL(this.metadata.url))||void 0===i?void 0:i.search);if(n){const e=new URLSearchParams(n),t=null==e?void 0:e.get("$skip");t&&(this.nextPageUrlSkip=parseInt(t))}this.articleQueue=this.articleQueue.concat(o)}get titleString(){return this.currArticleCount<this.config.maxNumberOfTitles?this.strings.multipleArticleTitle:this.strings.multipleArticleDoneTitle}get subTitleString(){return 0===this.currArticleCount?this.strings.mulTitleDescription:this.feedbackString}get feedbackString(){if(!(this.currArticleCount>=Math.min(5,this.config.maxNumberOfTitles)))switch(this.currArticleCount){case 1:return this.strings.feedbackAfter1Click;case 2:return this.strings.feedback1MoreClickToGo;default:return}}get relatedArticlesAddedString(){var e,t;return 1===this.numRelatedArticles?null===(e=this.strings.relatedArticleAdded)||void 0===e?void 0:e.replace("{0}",this.numRelatedArticles.toString()):null===(t=this.strings.relatedArticlesAdded)||void 0===t?void 0:t.replace("{0}",this.numRelatedArticles.toString())}experienceConnected(){if(se)return;H.YT.addOrUpdateTmplProperty("fre-exp-connected","1"),this.signalOverlayTelemetry||(this.signalOverlayTelemetry=new ee(this.telemetryObject)),this.starImgSrc=(0,re.ud)()?R():S(),this.initServiceClient(),this.dialogHeight=878,this.currArticleCount=0;const e={id:J.UET,display:(async()=>(this.freOppenedSettablePromise=new Z.e,await this.init().then(()=>this.onFreOverlayOpen()),await this.freOppenedSettablePromise.getResultAsync())).bind(this),priorityGroup:A.z.FreOverlay,evaluator:(async()=>!this.noContents).bind(this)};(0,E.I1)().then(t=>{t.enqueuePlacements([e])})}async init(){se||(se=!0,this.config.waitForFeedLoad&&await(0,q.dT)(),this.articlePromise&&await this.articlePromise,0!==this.articleQueue.length&&(this.isOverlayOpen=!0,this.setCardHeightHandler()))}async onFreOverlayOpen(){if(this.isOverlayOpen&&(window.dispatchEvent(new CustomEvent("toggleInfopaneRotation",{detail:{playRotation:!1}})),H.YT.addOrUpdateTmplProperty("fre-ux-rendered","1"),this.applyGlobalStyles(),document.addEventListener("keydown",this.documentKeydownHandler),await W.Q.isApiAvailableToUse())){const e=await W.Q.getPreferenceSetting(j.K5.seen_interest_fre_count);let t=1;e&&e.value&&"number"==typeof e.value&&(t=e.value+1),await W.Q.savePreferenceSetting(j.K5.seen_interest_fre_count,{setting:j.K5.seen_interest_fre_count,source:"ntp",timestamp:(new Date).getTime(),value:t})}}connectedCallback(){super.connectedCallback(),window.addEventListener("resize",this.setCardHeightHandler)}disconnectedCallback(){super.disconnectedCallback(),this.closeOverlay(A.R.Ignored)}getExperienceType(){return J.UET}closeOverlay(e){var t;let i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:void 0,r=arguments.length>2&&void 0!==arguments[2]&&arguments[2];i&&this.fluentDialogRef&&H.YT.sendActionEvent(this.fluentDialogRef,i,B.MS.Close),(r||this.currArticleCount>0)&&W.Q.savePreferenceSetting(j.K5.seen_interest_fre_count,{setting:j.K5.seen_interest_fre_count,source:"ntp",timestamp:(new Date).getTime(),value:3}),this.isOverlayOpen=!1,this.styleElement&&this.styleElement.parentElement&&this.styleElement.parentElement===window.document.head&&window.document.head.removeChild(this.styleElement),window.dispatchEvent(new CustomEvent("toggleInfopaneRotation",{detail:{playRotation:!0}})),document.removeEventListener("keydown",this.documentKeydownHandler),window.removeEventListener("resize",this.setCardHeightHandler),this.scrollRegionRef&&this.scrollRegionRef.removeEventListener("scroll",this.scrollRegionScrollHandler);let o=e;this.isEngaged&&(o=A.R.Engaged),null===(t=this.freOppenedSettablePromise)||void 0===t||t.set(o)}onClickDone(){this.isEngaged=!0,this.buildingFeed=!0;const e=new Promise(e=>{window.setTimeout(()=>{e(null)},3e3)});this.refreshCallback?Promise.race([this.refreshCallback(),e]).then(()=>{this.closeOverlay(A.R.Engaged)}):this.closeOverlay(A.R.Engaged)}proceedMultipleArticles(){this.currArticleCount++,this.handleAnimation()}assignArticleData(e){return{...e,cardSize:"_1x_2y",disableCardTitleTooltip:!0,selected:!1,isRelated:arguments.length>1&&void 0!==arguments[1]&&arguments[1]}}processArticles(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1];const i=[];return e.forEach(e=>{const r=function(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1],i=arguments.length>2&&void 0!==arguments[2]&&arguments[2];if(!e||!e.subCards||!e.subCards.length)return;const r=e.subCards[0];return{interestId:e.id,interestTitle:t?e.title:void 0,destinationUrl:void 0,id:r.id,mediaType:oe.z.image,optedOutOfReactions:!0,imageData:ae(r.images&&r.images[0],r.title,i),providerData:r.provider?{name:r.provider.name,logoImage:r.provider.logoUrl?(0,ne.oQ)(r.provider.logoUrl,{width:16,height:16,enableDpiScaling:!1}):"",profileId:r.provider.profileId,id:r.provider.id}:void 0,title:r.title}}(e);r?i.push(this.assignArticleData(r,t)):(0,L.vV)(M.KpV,"exploration article returned not valid",`{"article": ${JSON.stringify(e)}}`)}),i}async fetchAndMapArticle(){this.articlePromise=this.fetchNicheInterests(void 0);const e=await this.articlePromise;if(this.loadingMulArticle=!1,this.articlePromise=void 0,!e||!e.length)return void(this.noMoreInterests=!0);const t=this.processArticles(e);t.length||!this.config.showInterestTitle&&0!=this.articleQueue.length||(this.noMoreInterests=!0),this.articleQueue=this.articleQueue.concat(t)}async fetchRelatedArticle(e,t){if(!e||!e.interestId||!e.id)return void(0,L.vV)(M.ISx,"current article does not exist");this.relatedArticlePromise=this.fetchNicheInterests(e.interestId);let i=await this.relatedArticlePromise;if(this.relatedArticlePromise=void 0,!i||!i.length)return void(0==this.articleQueue.length&&(this.noMoreInterests=!0));i=i.slice(0,Math.min(i.length,this.config.numberOfRelatedArticles||1));const r=this.processArticles(i,!0);if(r.length||this.config.showInterestTitle||0!==this.articleQueue.length||(this.noMoreInterests=!0),this.config.attachArticlesInline){if(void 0===t||-1===t)return void(0,L.vV)(M.ISx,"current article does not exist");this.articleQueue.splice(t+1,0,...r)}else this.articleQueue.push(...r),this.showArticlesBelowToast=!0,this.numRelatedArticles+=r.length,window.setTimeout(()=>{this.numRelatedArticles=0,this.showArticlesBelowToast=!1},3e3)}sendAction(){var e;let t=!(arguments.length>0&&void 0!==arguments[0])||arguments[0],i=arguments.length>1&&void 0!==arguments[1]&&arguments[1],r=arguments.length>2?arguments[2]:void 0,o=null===(e=(0,z.rA)())||void 0===e||null===(e=e.CurrentMarket)||void 0===e?void 0:e.toString();if(o||((0,L.vV)(M.ufo,"current market does not exist"),o="en-us"),!r)return;const n=()=>{};try{T.sendContentReaction({item:D.ll.contents,id:`${null==r?void 0:r.id}_${o}`,reactionType:t?P.hr.upvote:P.hr.downvote,reset:i,localStorageSave:n})}catch(e){(0,L.vV)(M.OUO,"error sending content reaction",`{"error": ${JSON.stringify(e)}}`)}}applyGlobalStyles(){this.styleElement=document.createElement("style"),this.styleElement.textContent=X,window.document.head.appendChild(this.styleElement)}async colorProgressRing(){var e,t,i,r;if(await new Promise(e=>window.setTimeout(e,200)),!this.fluentDialogRef||!this.progressRingRef||null!==(e=this.progressRingRef.shadowRoot)&&void 0!==e&&null!==(t=e.querySelector)&&void 0!==t&&t.call(e,"linearGradient"))return;const o="http://www.w3.org/2000/svg",n=document.createElementNS(o,"linearGradient");n.id="lingra",n.setAttribute("x1","6"),n.setAttribute("y1","1"),n.setAttribute("x2","0"),n.setAttribute("y2","11"),n.setAttribute("gradientUnits","userSpaceOnUse");const a=[{color:"#FFC670",offset:"0%"},{color:"#FF1CDB",offset:"28%"},{color:"#2C28FE",offset:"56%"},{color:"#3DFFE8",offset:"99%"}];for(let e=0,t=a.length;e<t;e++){const t=document.createElementNS(o,"stop");t.setAttribute("offset",a[e].offset),t.setAttribute("stop-color",a[e].color),n.appendChild(t)}null===(i=this.progressRingRef.shadowRoot)||void 0===i||null===(r=i.querySelector)||void 0===r||null===(r=r.call(i,"svg.progress"))||void 0===r||r.appendChild(n)}handleAnimation(){1===this.currArticleCount?this.starImgSrc=C():this.currArticleCount===this.config.maxNumberOfTitles&&window.setTimeout(()=>{this.starImgSrc=I()},500)}revertAnimation(){if(this.currArticleCount--,0===this.currArticleCount)this.starImgSrc=(0,re.ud)()?R():S();else if(this.currArticleCount===this.config.maxNumberOfTitles-1){var e;null===(e=this.starImgRef)||void 0===e||e.classList.remove("checkmark-gif","sparkle-accent"),this.starImgSrc=F()}}initServiceClient(){this.nicheInterestService||(this.nicheInterestService=new O.n(U.MZ.SignalOverlay,this.stopFetchingMoreInterests))}stopFetchingMoreInterests(){this.noMoreInterests=!0}replaceArticle(e,t){const i=this.articleQueue.indexOf(e);return-1===i?-1:(this.articleQueue.splice(i,1),this.articleQueue.splice(i,0,t),i)}onStarLoad(e){var t,i;if(e)if(e.indexOf("neutral-following-star-sparkle")>-1)null===(t=this.starImgRef)||void 0===t||t.classList.remove("sparkle-accent","checkmark-gif"),null===(i=this.progressRingRef)||void 0===i||i.classList.remove("hide");else if(e===C()){var r,o,n;null===(r=this.starImgRef)||void 0===r||r.classList.add("sparkle-accent"),null===(o=this.starImgRef)||void 0===o||o.classList.remove("checkmark-gif"),null===(n=this.progressRingRef)||void 0===n||n.classList.remove("hide")}else if(e===F()){var a,s;null===(a=this.starImgRef)||void 0===a||a.classList.remove("checkmark-gif","sparkle-accent"),null===(s=this.progressRingRef)||void 0===s||s.classList.remove("hide")}else if(e===I()){var d,l,c;null===(d=this.starImgRef)||void 0===d||d.classList.add("checkmark-gif"),null===(l=this.progressRingRef)||void 0===l||l.classList.add("hide"),null===(c=this.starImgRef)||void 0===c||c.classList.remove("sparkle-accent")}}}(0,_.Cg)([G.sH],de.prototype,"isOverlayOpen",void 0),(0,_.Cg)([G.sH],de.prototype,"dialogHeight",void 0),(0,_.Cg)([G.sH],de.prototype,"currArticleCount",void 0),(0,_.Cg)([G.sH],de.prototype,"fetchingData",void 0),(0,_.Cg)([G.sH],de.prototype,"refreshCallback",void 0),(0,_.Cg)([G.sH],de.prototype,"buildingFeed",void 0),(0,_.Cg)([G.sH],de.prototype,"starImgSrc",void 0),(0,_.Cg)([G.sH],de.prototype,"noMoreInterests",void 0),(0,_.Cg)([G.sH],de.prototype,"loadingMulArticle",void 0),(0,_.Cg)([G.sH],de.prototype,"articleQueue",void 0),(0,_.Cg)([G.sH],de.prototype,"showArticlesBelowToast",void 0),(0,_.Cg)([G.sH],de.prototype,"numRelatedArticles",void 0),(0,_.Cg)([G.sH],de.prototype,"progressRingRef",void 0),(0,_.Cg)([G.sH],de.prototype,"scrollRegionRef",void 0),(0,_.Cg)([G.sH],de.prototype,"metadata",void 0),(0,_.Cg)([G.Jg],de.prototype,"titleString",null),(0,_.Cg)([G.Jg],de.prototype,"subTitleString",null),(0,_.Cg)([G.Jg],de.prototype,"feedbackString",null),(0,_.Cg)([G.Jg],de.prototype,"relatedArticlesAddedString",null);var le=i(60402),ce=i(39957),he=i(37097),pe=i.n(he),ge=i(16253),ue=i.n(ge),fe=i(52741),me=i.n(fe);const ve=c.qy`<fluent-button appearance="accent" id="doneButton" class="done-button" @click=${e=>e.onClickDone()} data-t="${e=>e.signalOverlayTelemetry.getTelemetryTag(Y.buildFeed)}" title="${e=>e.strings.doneButtonTitle}" aria-label="${e=>e.strings.doneButtonTitle}" ?disabled="${e=>e.config.maxNumberOfTitles>e.currArticleCount}"><span>${e=>e.strings.doneButtonTitle}</span></fluent-button>`,xe=c.qy`<div class="loading-article"><fluent-progress-ring class="loading-ring"></fluent-progress-ring></div>`,be=c.qy`<div class="close-button-container"><fluent-button class="close-button" appearance="stealth" @click=${(e,t)=>e.closeOverlay(A.R.Dismissed,void 0,!0)} data-t="${e=>e.signalOverlayTelemetry.getTelemetryTag(Y.close)}" id="closeButton" title=${e=>e.strings.closeButtonTooltip||""} aria-label=${e=>e.strings.closeButtonTooltip||""}>${c.qy.partial(ue())}</fluent-button></div>`,ye=c.qy`<div class="mul-card-container"><cs-article-card-fre class="disable-hover mul-article ${(e,t)=>e.loadingArticle?"hide-card":""}" :data=${e=>e}></cs-article-card-fre><fluent-button appearance="neutral" id="likeButton" class="mul-fb feedback-btn ${e=>e&&e.selected?"selected":""}" @click=${(e,t)=>t.parent.onClickLike(e)} data-t=${(e,t)=>e.selected?t.parent.signalOverlayTelemetry.getTelemetryTag(Y.undoLike(e.id||"")):t.parent.signalOverlayTelemetry.getTelemetryTag(Y.like(e.id||""))} title="${(e,t)=>t.parent.strings.likeButtonTitle}" aria-label="${(e,t)=>t.parent.strings.likeButtonTitle}"><span slot="start">${c.qy.partial(pe())}</span><span class="like-btn-title">${(e,t)=>t.parent.strings.likeButtonTitle}</span></fluent-button><div class="card-holder ${(e,t)=>e.loadingArticle?"display-ch":""}"></div></div>`,we=c.qy`<div class="scroll-region" ${(0,le.K)("scrollRegionRef")}><div class="articles">${(0,ce.ux)(e=>e.articleQueue||[],ye)}</div>${(0,h.z)(e=>e.loadingMulArticle&&!e.noMoreInterests,xe)}</div>${(0,h.z)(e=>e.currArticleCount<e.config.maxNumberOfTitles&&e.showArticlesBelowToast,c.qy`<div class="related-tag"><span>${c.qy.partial(me())}</span>${e=>e.relatedArticlesAddedString}</div>`)}<div class="fog">${(0,h.z)(e=>e.currArticleCount>=e.config.maxNumberOfTitles,ve)}</div>`,ke=c.qy`<div class="progress"><img class="header-star-img" ${(0,le.K)("starImgRef")}  src="${e=>e.starImgSrc}" @load=${e=>e.onStarLoad(e.starImgSrc)} /><fluent-progress-ring ${(0,le.K)("progressRingRef")} class="article-progress" value="${e=>Math.min(e.config.maxNumberOfTitles,e.currArticleCount)/e.config.maxNumberOfTitles*100||6}"></fluent-progress-ring></div>`,$e=c.qy`<fluent-dialog trap-focus="true" modal="true" role="dialog" part="dialog" @dismiss="${e=>e.closeOverlay(A.R.Dismissed,B.EG.Click)}" data-t="${e=>e.signalOverlayTelemetry.getTelemetryTag(Y.overlay)}" ${(0,le.K)("fluentDialogRef")} style="${e=>(e=>`--dialog-height:${e.dialogHeight||709}px;`)(e)}"><div class="signal-fre-wrapper mul-article down">${be}<div class="so-header">${(0,h.z)(e=>!e.buildingFeed,ke)} ${(0,h.z)(e=>e.buildingFeed,xe)}<div class="titles"><div class="header-title1">${e=>e.buildingFeed?e.strings.buildingFeedTitle:e.titleString}</div><div class="header-title2">${e=>e.subTitleString}</div></div></div>${we}</div></fluent-dialog>`,_e=c.qy` ${(0,h.z)(e=>e.isOverlayOpen,$e)}
`,ze={experienceConfigSchema:undefined};r.m.define(o.c.registry),n.m.define(o.c.registry),(0,$.J)(),w.define(k.G.registry)},6791(e,t,i){"use strict";i.d(t,{f(){return o}});var r=i(50645);class o{constructor(){this.config={},this.strings={},this.initialized=!1}async initConfig(e){var t,i;this.initialized||(this.config=await this.getConfigFromRef(e)||{},this.strings=(null===(t=this.config)||void 0===t?void 0:t.localizedStrings)||{},this.initialized=!!this.config&&!(null===(i=this.config)||void 0===i||!i.localizedStrings))}getConfig(){return this.config}getLocStrings(){return this.strings}async getConfigFromRef(e){try{const t=(null==e?void 0:e.configRef)||this.configRef,i=await r.L.getConfig(t);return null==i?void 0:i.properties}catch(e){return{}}}}},10809(e,t,i){"use strict";i.d(t,{D(){return s}});var r=i(18272),o=i(2171),n=i(6791);class a extends n.f{constructor(){super(...arguments),this.configRef={experienceType:"SuperComponentData",instanceSrc:"default"}}static getInstance(){return o.vv.get("__SuperComponentDataHelper__",()=>new a)}}const s=(0,r.G)(a)},12928(e,t,i){"use strict";var r;i.d(t,{MZ(){return r}}),function(e){e.SignalOverlay="SignalOverlay",e.ChannelStore="ChannelStore",e.InterestFreCard="InterestFreCard",e.InlineCurationModal="InlineCurationModal"}(r||(r={}))},26831(e,t,i){"use strict";i.d(t,{Hg(){return a}});var r=i(58792),o=i(26220);const n=/[:/?#[\]@!$&'()*+,;=]/g;function a(e,t,i,a){let s=`${r.T3.NavTargetUrlWithLocale}/channel`;if(e&&i){const r="source"===i?"sr":"tp";s+="/"+[i,t?encodeURIComponent(t.replace(n,"")):"",`${r}-${e}`].filter(e=>e).join("/")}const d=new URL(s);return a||(d.search=(0,o.iA)()),(0,o.ou)().includes("localhost.msn.com")&&(d.host=(0,o.ou)()),d.toString()}},28986(e,t,i){"use strict";i.d(t,{DK(){return m},Rg(){return f},v8(){return u}});var r=i(45755),o=i(64183),n=i(95239);function a(e,t){return r.G.create({name:e},t)}const s=a("neutral-fill-secondary-rest-delta",3),d=a("neutral-fill-secondary-hover-delta",2),l=a("neutral-fill-secondary-active-delta",1),c=a("neutral-fill-secondary-focus-delta",3);var h=i(31023);const{create:p}=r.G,g=a("neutral-fill-secondary-recipe",{evaluate(e,t){return(0,o.t)(e(h.r),t||e(n.p),e(s),e(d),e(l),e(c))}}),u=p("neutral-fill-secondary-rest",e=>e(g).evaluate(e).rest),f=p("neutral-fill-secondary-hover",e=>e(g).evaluate(e).hover),m=p("neutral-fill-secondary-active",e=>e(g).evaluate(e).active);p("neutral-fill-secondary-focus",e=>e(g).evaluate(e).focus)},30664(e,t,i){"use strict";i.d(t,{I(){return r}});const r="1"},35444(e,t,i){"use strict";i.d(t,{n(){return l}});var r=i(93552),o=i(78103),n=i(68464),a=i(77367);const s="InterestSkip",d=["freinterestsdefault","interesttopicsdefault"];class l{constructor(e,t){var i=this;this.viewLayout="",this.stopFetchingMoreInterests=()=>{},this.nextPageSkip="",this.getNicheInterests=async function(e){let t=arguments.length>1&&void 0!==arguments[1]&&arguments[1],r=arguments.length>2&&void 0!==arguments[2]&&arguments[2];const o=await i.fetchNicheInterest(e,t,r);return await i.updateFetch(o)},this.serviceConsumer=e,this.stopFetchingMoreInterests=t,this.dataProvider=new n.c(!0)}async fetchNicheInterest(e){var t,i,o;let n=arguments.length>1&&void 0!==arguments[1]&&arguments[1],d=arguments.length>2&&void 0!==arguments[2]&&arguments[2];const l=null==e||null===(t=e.initialRequest)||void 0===t?void 0:t.nextPageUrl,c=l&&""!==l&&new URL(l).searchParams,h=n?null==e||null===(i=e.initialRequest)||void 0===i?void 0:i.start:"16",p=parseInt(this.nextPageSkip||c&&""!==c&&((null==c?void 0:c.get(s))||(null==c?void 0:c.get("$skip")))||h),g={...e&&e.initialRequest,nextPageUrl:void 0,useNextPageUrl:!0,enableWpoAdPlacements:!0,taboolaSessionId:"init",enableRightRailColumnLayout:void 0,useSuperFeed:!0,feedId:void 0,pageScenario:(null==e||null===(o=e.initialRequest)||void 0===o?void 0:o.pageScenario)??"freinterests",start:p,freV2Params:d};try{var u;let e,t=!1;var f;if(e=await this.dataProvider.fetch(g),(null===(u=e.appError)||void 0===u?void 0:u.id)===r.CPX.id&&(t=!0,e=await this.dataProvider.fetch(g)),!this.responseContainsCardsData(e))if(!this.lastResponse)null!==(f=e)&&void 0!==f&&f.userEndError?a.YT.sendAppErrorEvent({...r.zrw,message:"Showing blank niche interests for issue on user's end",pb:{...r.zrw.pb,viewLayout:this.viewLayout,isRetry:t,serviceConsumer:this.serviceConsumer}}):a.YT.sendAppErrorEvent({...r.Hu3,message:"Empty response returned from 1S fetching niche interests.",pb:{...r.Hu3.pb,userImpact:!0,associatedAppError:e&&e.appError,viewLayout:this.viewLayout,isRetry:t,serviceConsumer:this.serviceConsumer}});return this.lastResponse=e,e}catch(e){}}responseContainsCardsData(e){return!(!e||(0,o.I)(e.sections)&&(0,o.I)(e.regions))}async updateFetch(e){if(!e)return[];let t=[];const i=(e,i)=>{var o;if(i&&i.length>0&&i[0].template&&d.includes(null===(o=i[0])||void 0===o||null===(o=o.template)||void 0===o?void 0:o.toLowerCase())){const e=i[0].cards;if(e&&e.length>0){const i=e[0];if(i.url){const e=i.url,t=new URL(e).searchParams;this.nextPageSkip=(null==t?void 0:t.get(s))||this.nextPageSkip}if(i&&i.subCards&&("UserInterestTopicAndProvider"==i.type||"UserInterestTopic"==i.type)){const e=i.subCards;if(e&&e.length>0){const i=e.find(e=>"Topics"==e.type);i&&i.subCards&&i.subCards.length>0?t=i.subCards??[]:a.YT.sendAppErrorEvent({...r.MxK,message:"Empty Topics list from response.",pb:{...r.MxK.pb,userImpact:!0,serviceConsumer:this.serviceConsumer}})}}}}};var o;e.sections&&(null===(o=e.sections)||void 0===o||o.forEach(e=>{e.subSections?i(e.region,e.subSections):e.template&&i(e.region,[e])}));return t.length||e.appError||this.stopFetchingMoreInterests(),t}}},37097(e){e.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10.05 2.3c.34-.98 1.63-1.43 2.43-.6.17.17.33.36.44.52.32.48.45 1.12.5 1.73.05.63.02 1.3-.05 1.91-.06.62-.16 1.18-.24 1.59v.05H14a3 3 0 012.95 3.54l-.69 3.76a4.5 4.5 0 01-5.6 3.53l-5.6-1.52a2.5 2.5 0 01-1.8-1.92l-.35-1.77c-.28-1.39.78-2.56 1.9-3 .33-.13.62-.3.85-.5 1.7-1.5 2.32-2.72 3.38-4.84.36-.71.72-1.68 1-2.49zm1.97 5.58v-.04a13.7 13.7 0 00.13-.58c.08-.4.17-.93.23-1.5.06-.58.09-1.18.04-1.73a2.73 2.73 0 00-.33-1.25 3.26 3.26 0 00-.33-.39c-.2-.2-.63-.16-.76.23-.29.82-.67 1.83-1.05 2.6-1.07 2.14-1.76 3.5-3.62 5.15-.34.3-.74.52-1.13.68-.88.34-1.45 1.14-1.3 1.87l.35 1.77c.11.56.53 1 1.08 1.15l5.6 1.53c1.98.54 4-.73 4.36-2.75l.68-3.76a2 2 0 00-1.96-2.36h-1.5a.5.5 0 01-.5-.62z"></path></svg>'},42792(e,t,i){"use strict";i.d(t,{R7(){return f},e(){return g},kc(){return u},nH(){return p}});var r=i(57416),o=i(55153),n=i(95239),a=i(26920),s=i(48751),d=i(64187),l=i(22131),c=i(74849),h=i(50882);const p=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,g=c.A`
    ${(0,d.V)("flex")} :host {
        background: ${n.p};
        outline: calc(${a.XA} * 1px) solid ${o.cu};
        border-radius: calc((${r.JU} - ${a.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${o.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${a.XA} * 1px) ${o.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${a.XA} * 1px) ${o.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${o.QG} * 1px);
        height: calc(${o.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${o.QG} * 1px);
        height: calc((${o.l8} * 2px) + (${o.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${o.QG} * 2px) + (${o.Sn} * 1px));
        height: calc((${o.l8} * 2px) + (${o.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${o.QG} * 2px) + (${o.Sn} * 1px));
        height: calc(${o.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,l.mr)(c.A`
            :host {
                background: ${h.A.Canvas};
                color: ${h.A.CanvasText};
            }
        `),f=c.A`
    ${g}
    ${p}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},43922(e,t,i){"use strict";i.d(t,{z(){return r}});const r={image:"image",video:"video"}},50866(e,t,i){"use strict";i.d(t,{L9(){return n},NZ(){return o},qJ(){return r}});const r={_1x_1y:"_1x_1y",_1x_2y:"_1x_2y",_2x_2y:"_2x_2y",_2x_1y:"_2x_1y"},o={DarkPlum:"dark-plum",DarkDesert:"dark-desert",DarkDawn:"dark-dawn",DarkSea:"dark-sea",DarkOrange:"dark-orange",DarkTropic:"dark-tropic",DarkMerlot:"dark-merlot",DarkPurple:"dark-purple",DarkGreen:"dark-green"},n={LightBlue:"light-blue",LightPurple:"light-purple",LightSky:"light-sky",LightPink:"light-pink",LightYellow:"light-yellow",LightBluebird:"light-bluebird",LightOrange:"light-orange",LightAqua:"light-aqua",LightGreen:"light-green"}},52741(e){e.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M16.87 10.84a.5.5 0 10-.74-.68l-5.63 6.17V2.5a.5.5 0 00-1 0v13.83l-5.63-6.17a.5.5 0 00-.74.68l6.31 6.91a.75.75 0 001.11 0l6.32-6.91z"></path></svg>'},54994(e,t,i){"use strict";i.d(t,{m(){return y}});var r=i(75261);class o extends r.t{}var n=i(37180),a=i(74849),s=i(64187),d=i(22131),l=i(50882),c=i(74838),h=i(37302),p=i(4283),g=i(64003),u=i(26920);const f=a.A`
    ${(0,s.V)("flex")} :host {
        align-items: center;
        outline: none;
        height: calc(${c.vR} * 1px);
        margin: calc(${c.vR} * 1px) 0;
    }

    .progress {
        background-color: ${h.F7};
        border-radius: calc(${c.vR} * 1px);
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        position: relative;
        overflow: hidden;
    }

    .determinate {
        background-color: ${p.IR};
        border-radius: calc(${c.vR} * 1px);
        height: 100%;
        transition: all 0.2s ease-in-out;
        display: flex;
    }

    ::slotted([slot="indeterminate"]) {
        height: 100%;
        border-radius: calc(${c.vR} * 1px);
        display: flex;
        width: 100%;
        position: relative;
    }

    .indeterminate-indicator-1 {
        position: absolute;
        opacity: 0;
        height: 100%;
        background-color: ${p.IR};
        border-radius: calc(${c.vR} * 1px);
        animation-timing-function: cubic-bezier(0.4, 0, 0.6, 1);
        width: 40%;
        animation: indeterminate-1 2s infinite;
    }

    .indeterminate-indicator-2 {
        position: absolute;
        opacity: 0;
        height: 100%;
        background-color: ${p.IR};
        border-radius: calc(${c.vR} * 1px);
        animation-timing-function: cubic-bezier(0.4, 0, 0.6, 1);
        width: 60%;
        animation: indeterminate-2 2s infinite;
    }

    :host([paused]) .indeterminate-indicator-1,
    :host([paused]) .indeterminate-indicator-2 {
        animation-play-state: paused;
        background-color: ${h.F7};
    }

    :host([paused]) .determinate {
        background-color: ${g.c};
    }

    @keyframes indeterminate-1 {
        0% {
            opacity: 1;
            transform: translateX(-100%);
        }
        70% {
            opacity: 1;
            transform: translateX(300%);
        }
        70.01% {
            opacity: 0;
        }
        100% {
            opacity: 0;
            transform: translateX(300%);
        }
    }

    @keyframes indeterminate-2 {
        0% {
            opacity: 0;
            transform: translateX(-150%);
        }
        29.99% {
            opacity: 0;
        }
        30% {
            opacity: 1;
            transform: translateX(-150%);
        }
        100% {
            transform: translateX(166.66%);
            opacity: 1;
        }
    }
`.withBehaviors((0,d.mr)(a.A`
            .indeterminate-indicator-1,
            .indeterminate-indicator-2,
            .determinate {
                forced-color-adjust: none;
                background-color: ${l.A.FieldText};
            }
            .progress {
                background-color: ${l.A.Field};
                border: calc(${u.XA} * 1px) solid ${l.A.FieldText};
            }
            :host([paused]) .indeterminate-indicator-1,
            .indeterminate-indicator-2 {
                background-color: ${l.A.Field};
            }
            :host([paused]) .determinate {
                background-color: ${l.A.GrayText};
            }
        `));var m=i(96950),v=i(69259),x=i(18893);const b=function(e={}){return m.qy`
        <template
            role="progressbar"
            aria-valuenow="${e=>e.value}"
            aria-valuemin="${e=>e.min}"
            aria-valuemax="${e=>e.max}"
        >
            ${(0,v.z)(e=>"number"==typeof e.value,m.qy`
                    <div class="progress" part="progress" slot="determinate">
                        <div
                            class="determinate"
                            part="determinate"
                            style="width: ${e=>e.percentComplete}%"
                        ></div>
                    </div>
                `,m.qy`
                    <div class="progress" part="progress" slot="indeterminate">
                        <slot name="indeterminate">
                            ${(0,x.R)(e.indeterminateIndicator1)}
                            ${(0,x.R)(e.indeterminateIndicator2)}
                        </slot>
                    </div>
                `)}
        </template>
    `}({indeterminateIndicator1:m.qy`
        <span class="indeterminate-indicator-1" part="indeterminate-indicator-1"></span>
    `,indeterminateIndicator2:m.qy`
        <span class="indeterminate-indicator-2" part="indeterminate-indicator-2"></span>
    `}),y=o.compose({name:`${n.c.prefix}-progress`,template:b,styles:f})},55078(e,t,i){"use strict";i.d(t,{I(){return u}});var r=i(66560),o=i(58792),n=i(61979),a=i(22341),s=i(93552),d=i(2171),l=i(77367),c=i(82545);const h={[c.hr.upvote]:"LikedAd",[c.hr.downvote]:"DislikedAd"},p={[c.hr.upvote]:"adThumbsUp",[c.hr.downvote]:"adThumbsDown"};class g{constructor(){this.reactionCounters=new Map([[c.hr.upvote,0],[c.hr.downvote,0]]),this.reactionAdIdSets=new Map([[c.hr.upvote,new Set],[c.hr.downvote,new Set]])}getTelemetryPropertyName(e){return p[e]}updateReaction(e,t,i){const r=(this.reactionCounters.get(t)??0)+(i?1:-1);this.reactionCounters.set(t,r);const o=this.getTelemetryPropertyName(t);l.YT.addOrUpdateTmplProperty(o,`${r}`);const n=this.reactionAdIdSets.get(t)??new Set;i?n.add(e):n.delete(e),this.reactionAdIdSets.set(t,n)}buildServiceUrl(e,t,i){let a=e;return t||(l.YT.addOrUpdateTmplProperty("adFeedbackMonetizeNoRlink","1"),a=(0,r.Be)(a,"rlink","${RLINK}")),(0,n.b)(e)?(a=(0,r.Re)(a,"${CANVAS}",encodeURIComponent(o.T3.AppType),"canvas"),t&&(a=(0,r.Re)(a,"${RLINK}",encodeURIComponent(t),"rlink")),a=(0,r.Re)(a,"${FEEDBACK}",encodeURIComponent(i),"f"),a=(0,r.Be)(a,"ad","${ADVERTISER_DOMAIN}")):(t&&(a=a.concat(`&rlink=${encodeURIComponent(t)}`)),a=a.concat(`&f=${i}`)),a}getAdReaction(e){for(const[t,i]of this.reactionAdIdSets.entries())if(i.has(e))return t;return""}reportAd(e,t,i,o){if(!(0,r.V1)(i))return void(0,a.vV)(s.C8f,`Cannot send ad thumbs feedback: invalid or empty feedback URL. Value: '${i}'`);const n=(0,r.JQ)(o),d=h[t],l=this.buildServiceUrl(i,n,d);new Image(1,1).src=l,this.updateReaction(e,t,!0)}resetAd(e,t){this.updateReaction(e,t,!1)}}const u=d.vv.get("__AdSocialServiceInstanceKey__",()=>new g)},59836(e,t,i){"use strict";i.d(t,{m(){return m}});var r=i(65614),o=i(92011);class n extends o.L{}var a=i(7896),s=i(61138),d=i(48751),l=i(74838),c=i(74849),h=i(64187),p=i(22131),g=i(50882);const u=c.A`
    ${(0,h.V)("inline-flex")} :host {
        box-sizing: border-box;
        font-family: ${a.O};
        font-size: ${s.k};
        font-weight: 400;
        line-height: ${s.F};
        align-items: center;
        color: ${d.l};
        min-height: 16px;
    }

    .content {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        align-self: baseline;
    }

    ::slotted([slot="image"]) {
        display: flex;
        margin-inline-end: calc(${l.vR} * 2px);
    }
`.withBehaviors((0,p.mr)(c.A`
            :host,
            .content {
                color: ${g.A.ButtonText};
                fill: currentcolor;
            }
        `)),f=i(96950).qy`
    <slot name="image"></slot>
    <span part="content" class="content">
        <slot></slot>
    </span>
`,m=n.compose({name:`${r.G.prefix}-attribution`,styles:u,template:f})},61979(e,t,i){"use strict";i.d(t,{b(){return n}});var r=i(74998),o=i(71737);function n(e){var t;if(!(null!==r.Rb&&void 0!==r.Rb&&null!==(t=r.Rb.CurrentFlightSet)&&void 0!==t&&t.has("prg-ad-mon-feedback")||(0,o.pQ)()))return!1;if(!e)return!1;const i=/\$\{[A-Z_]+\}/.test(e),n=e.includes("${FEEDBACK}")||e.includes("${RLINK}")||e.includes("${CANVAS}")||e.includes("${ADVERTISER_DOMAIN}");return i&&n}},64183(e,t,i){"use strict";i.d(t,{o(){return a},t(){return n}});var r=i(68009),o=i(49399);function n(e,t,i,o,n,a,s){const d=e.closestIndexOf(t);return null==s&&(s=(0,r.F)(t)),{rest:e.get(d+s*i),hover:e.get(d+s*o),active:e.get(d+s*n),focus:e.get(d+s*a)}}function a(e,t,i,r,a,s,d=void 0,l,c,h,p,g=void 0){return(0,o.H)(t)?n(e,t,l,c,h,p,g):n(e,t,i,r,a,s,d)}},68464(e,t,i){"use strict";i.d(t,{c(){return T}});var r,o=i(15938),n=i(93552),a=i(75674),s=i(73371);!function(e){e.basicFeed="BasicFeed",e.desktopFeedStart="DesktopFeedStart",e.discoverCarouselSection="FinanceDiscoverSection_carouselCard",e.discoverFirstSection="FinanceDiscoverSection_first",e.discoverFollowedSection="FinanceDiscoverSection_followedCard",e.discoverSecondSection="FinanceDiscoverSection_second",e.feed="Feed",e.feedBasicRender="FeedBasicRender",e.feedRequest="FeedRequest",e.feedRequestFG="FeedRequest.FG",e.feedSDRender="FeedSDRender",e.isPrerenderedAd="isPrerenderedAd",e.firstSectionRenderStart="FirstSectionRenderStart",e.firstSectionRenderEnd="FirstSectionRenderEnd",e.riverFirstSection="RiverFirstSection",e.sdCards="SDCards",e.searchBox="SearchBox",e.searchBoxToFeed="SearchBoxToFeed",e.secondSectionRenderEnd="SecondSectionRenderEnd",e.secondSectionRenderStart="SecondSectionRenderStart",e.TTPR="TTPR",e.viewCards="ViewCards",e.wpoCallStart="WpoCallStart",e.wpoResponseBack="WpoResponseBack",e.feedCallStart="FeedCallStart",e.feedResponseBack="FeedResponseBack",e.feedParse="FeedParse",e.configEndToFeedStart="ConfigEndToFeedStart",e.feedResponseTo1SSectionProcessed="FeedResponseTo1SSectionProcessed",e.isSSREnabled="isSSREnabled",e.isSSRCompleted="isSSRCompleted",e.isSSRAborted="isSSRAborted",e.complete="Complete",e.sectionRenderStart="sectionRenderStart",e.ssrCpuCost="ssrCpuCost",e.ssrRenderDuration="ssrRenderDuration"}(r||(r={}));const d="WidgetsConfigsEnd";var l=i(80286),c=i(78648),h=i(12284),p=i(26220),g=i(2171),u=i(4350),f=i(58792),m=i(70775),v=i(36297),x=i(74998),b=i(42161),y=i(32306),w=i(15525),k=i(6277),$=i(31756),_=i(34230),z=i(27259),S=i(17917),R=i(10526),C=i(77348),F=i(77367);const I=e=>e&&e.length?"region"in e[0]?e:[{region:"river",subSections:e}]:[];class T{constructor(e){this.fetchCount=0,this.useFeedCardRequestBuilder=e}async prepareUrl(e){let t,i,r=arguments.length>1&&void 0!==arguments[1]&&arguments[1];const{refreshType:o,nextPageUrl:n,duotone:a,gemQspList:d,theme:b,clientLayoutVersion:y,timeoutMs:w,sendFRESeenCount:_,msnup:R}=e||{},I=new URLSearchParams((0,p.iA)()),T=I.get("aver"),D=I.get("usri"),P=I.get("over"),A=I.get("oem"),E=I.get("devicetype"),O=I.get("smode"),U=I.get("timeOut"),N=I.get(u.aS.uniFeatTun),L=U||w||2e3;if(this.useFeedCardRequestBuilder&&!e.fullReqPath){const r={...e,enableRightRailColumn:e.enableRightRailColumnLayout,wpoSchema:e.enableRightRailColumnLayout?"byregion":e.wpoSchema||"",wpoPageId:e.enableRightRailColumnLayout&&!e.wpoPageId?"singlecolwin":e.wpoPageId,requestType:c.Yw.oneService,timeoutMs:L,layout:e.layout,pageOcid:e.pageOcid,weatherSegment:e.weatherSegment,weatherScenario:e.weatherScenario,aver:T,usri:D,over:P,oem:A,devicetype:E,smode:O,oneSvcUni:N,theme:b,msnup:R};t=await h.h.requestInit(r),i=await h.h.buildRequestURLForOneService(r)}else{const{pageScenario:c,ocid:h,wpoPageId:p,additionalHeaders:w,contentType:R,enableWpoAdPlacements:U,taboolaSessionId:q,muidFallback:B,enableRightRailColumnLayout:H,installedWidgets:W,geolocation:j,layout:G,refreshCnt:J,viewportSize:V,isEdgeUninstalled:X,allFeedsDisabled:Q,firstPartyFeedDisabled:K,column:Z,rotationDisabled:Y,badgingDisabled:ee,disable3P:te,defaultWidgets:ie,colstatus:re,interestIds:oe,colwidth:ne,fullReqPath:ae,msnup:se,newsSearchQuery:de,enableRuby:le,clientUtcOffset:ce}=e||{};let he=e&&e.flightData;const pe=e&&e.overwriteFlightData;!r&&(t=await this.getRequestInit({method:"GET",credentials:"include"},w));const ge=(0,z.x5)(),ue=`news/feed/pages/${c}`;i=ae?new URL(ae,s.iw):I.get(s.OJ)?new URL(ue,s.ki):(0,k.J7)(ue),de&&i.searchParams.set("q",de);const{WidgetAttributes:fe={},CurrentMarket:me}=f.T3;if(p&&("wpoads"!==p.toLowerCase()||l.Sd.includes(null==me?void 0:me.toLowerCase())?i.searchParams.set("wpopageid",p):i.searchParams.set("wpopageid","wponoads")),G&&i.searchParams.set("layout",G),T&&i.searchParams.set("aver",T),D&&i.searchParams.set("usri",D),P&&i.searchParams.set("over",P),A&&i.searchParams.set("oem",A),E&&i.searchParams.set("devicetype",E),O&&i.searchParams.set("smode",O),N?i.searchParams.set(u.aS.uniFeatTun,N):"url"===g.vv.get("oneSvcUniTunMode")&&i.searchParams.set(u.aS.uniFeatTun,await $.WR.getUniFeatTunHeader()),b&&i.searchParams.set("theme",b),J&&i.searchParams.set("refreshcnt",J),d)for(const e in d)i.searchParams.set(e,d[e]);if(V&&i.searchParams.set("vpSize",V),Z&&i.searchParams.set("column",Z),!0!==le&&!1!==le||i.searchParams.set("enableRuby",le.toString()),se&&i.searchParams.set("msnup",se),ce&&i.searchParams.set("clientUtcOffset",ce),fe.telemetry&&fe.telemetry.tmpl&&fe.telemetry.tmpl.includes("pwbingads2")){const e="prg-binghplite";he=he?`${he},${e}`:e}if(H&&(i.searchParams.set("wpopageid","singlecolwin"),i.searchParams.set("wposchema","byregion")),W&&W.length&&i.searchParams.set("installedWidgets",W.join(",")),j){const e=j.latitude&&j.longitude,t=j.positionSource&&j.positionSource.length>0,r=j.timestamp&&j.timestamp.length>0;e&&t&&r&&j.accuracy&&(i.searchParams.set("clientLocation",j.latitude+"|"+j.longitude),i.searchParams.set("clientLocationAccuracy",j.accuracy.toString()),i.searchParams.set("clientLocationProvider",j.positionSource),i.searchParams.set("clientLocationTimestamp",j.timestamp))}const ve=m._3.getParamsWithItems(location.search);if(ve){const e=ve.find(e=>"installedWidgetsOverride"===e.key);e&&e.value&&i.searchParams.set("installedWidgets",e.value)}if(n){const e=new v.m(new URL(n).search);ge>0&&e.set(z.ei,ge.toString()),e.set("timeOut",`${L}`),!f.T3.SendFeedCallActivityIdInHeader&&f.T3.ActivityId&&("winWidgets"===f.T3.AppType&&e.get("activityId")||e.set("activityId",f.T3.ActivityId)),i.search=e.toString()}else{const e=[...await this.getCommonParams(h,he,B,pe),{key:"contentType",value:R},{key:"timeOut",value:`${L}`}];(null==oe?void 0:oe.length)>0&&e.push({key:"interestIds",value:oe}),ge>0&&e.push({key:z.ei,value:ge.toString()}),e.forEach(e=>e.value&&i.searchParams.set(e.key,e.value))}if(f.T3.SendFeedCallActivityIdInHeader&&i.searchParams.delete("activityId"),U){const e=x.Rb.ClientSettings.browser&&"true"===x.Rb.ClientSettings.browser.ismobile||"phone"===x.Rb.ClientSettings.deviceFormFactor?"true":"false";i.searchParams.set("mobile",e);const r=(0,C.GR)()||(0,C.Cl)()||(0,C.Od)();i.searchParams.set("cookieWallPresent",r.toString()),t&&(t.headers[u.aS.adsReferer]=location.href,t.headers[u.aS.taboolaSessionId]=q||"init")}const xe=I.get("wpoitems");if(xe&&i.searchParams.set("wpoitems",xe.toString()),o&&i.searchParams.set("caller",o),a&&i.searchParams.set("duotone",a.toString()),y&&i.searchParams.set("clv",y),re&&(i.searchParams.set("colstatus",re),i.searchParams.set("layout",G)),ne&&i.searchParams.set("colwidth",ne.toString()),location.search&&location.search.indexOf("idxContentTypeOverride")>-1){const t=m._3.getParamsWithItems(location.search);if(t){const r=t.find(e=>"idxContentTypeOverride"===e.key);if(r){const t=e.contentType?e.contentType:"article,video,slideshow",o=[...new Set(`${t},${r.value}`.split(","))];i.searchParams.set("contentType",o.join(","))}}}if(_&&this.addRequestParametersForFRE(e,i),X&&i.searchParams.set("appUninstall","1"),Q&&i.searchParams.set("feedsDisabled","1"),K&&i.searchParams.set("disableContent","true"),Y&&i.searchParams.set("aeprd","1"),ee&&i.searchParams.set("aepbd","1"),te&&i.searchParams.set("disable3P","1"),ie&&i.searchParams.set("defaultWidgets","1"),f.T3.WidgetAttributes&&"bingHomepage"===f.T3.AppType){const e=await(0,S.f7)();if(null!=e&&e.muid){var M;const r="m-"+(null==e?void 0:e.muid);i.searchParams.get("User")?i.searchParams.set("User",r):i.searchParams.set("user",r),F.YT.addOrUpdateTmplProperty("bhpmuidqsp","1"),f.T3.SendUserIdInHeader&&null!==(M=t)&&void 0!==M&&M.headers&&t.headers.MUID!==e.muid&&(t.headers.MUID=e.muid,F.YT.addOrUpdateTmplProperty("bhpmuidhdrospp","1"))}}i.searchParams.sort()}return"header"===g.vv.get("oneSvcUniTunMode")&&t&&t.headers&&(t.headers[u.aS.uniFeatTun]=await $.WR.getUniFeatTunHeader()),{url:i,requestParams:t}}async fetch(e,t,i,r){let s=arguments.length>4&&void 0!==arguments[4]&&arguments[4],c=arguments.length>5?arguments[5]:void 0;const{url:h,requestParams:p}=await this.prepareUrl(e),{useSuperFeed:g,nextPageUrl:m,refreshType:v,gemQspList:x,pageScenario:w,newsSearchQuery:k}=e||{},$=v&&v===l.OQ.Bgtask||!1,S=!m,R=(0,o.ZF)(),C=h&&h.href;let T=0;try{m||(R.FeedCallStart=Math.round((0,o.gU)()),"number"==typeof R[d]&&(R.ConfigEndToFeedStart=Math.round((0,o.gU)()-R[d]))),t&&t();const f=i||_.w,v=await f(async e=>{let t=h.href;return T=e,e>0&&(h.searchParams.set("caller",l.OQ.RetryFetch),h.searchParams.sort()),s&&2===e&&S&&(t=t.replace("//assets.msn","//api.msn").replace("/service/","/")),F.YT.addOrUpdateTmplProperty("1sfcnt",""+ ++this.fetchCount),await fetch(decodeURIComponent(t),p)},`OneServicePageProvider.fetch ${this.isFullPageRequest(x,"")}`,r,c),C=v.headers;if(!v||!v.ok){const{status:e,statusText:t}=v||{},i={...n.KxB,message:v?"OneService returned error response":"OneService response was null",pb:{...n.KxB.pb,url:h.href,status:e,statusText:t,requestHeaders:JSON.stringify((0,b.bl)(p&&p.headers)),responseHeaders:this.getResponseHeaders(v),isBackgroundRefresh:$,isInitialRequest:S,isFPRequest:this.isFullPageRequest(x)}};return F.YT.sendAppErrorEvent(i),{responseHeaders:C,sections:null,appError:i}}if(204===v.status){return{responseHeaders:C,sections:[],appError:this.logAndReturnNoContentError(h,p,v.status,$,v,S,x)}}let P,A,E=!1,O="";if(v.headers){E=v.headers.get("X-Statics-Fallback"),E&&((0,z.uw)(E),F.YT.sendAppErrorEvent({...n.OZP,pb:{...n.OZP.pb,isBackgroundRefresh:$,responseHeaders:this.getResponseHeaders(v),url:h.href,isInitialRequest:S,isFPRequest:this.isFullPageRequest(x)},message:"Fell back to static content on the feeds call"}));const t=v.headers.get("ddd-tmpl");t&&F.YT.addOrUpdateTmplString(t),e.locallyStoreRecommendedInterestsTmpl&&this.storeRecommendedInterestsTmpls(t);const i=v.headers.get(u.pc.traceId);P=F.YT.addOrUpdateIdxId(i,!m),O=v.headers.get(u.pc.debugId),O&&(0,z.Ig)(O,!m)}if(!m){const e=R.FeedCallStart;A=R.FeedResponseBack=Math.round((0,o.gU)()),R["FeedRequest.FG"]=A-e,(0,a.Ww)({name:"FeedRequest.FG",startTime:e,endTime:A})}const U=await v.json();if(k&&U.length)return this.getSearchResponse(U,C,v,E);let N;A&&(R.FeedParse=Math.round((0,o.gU)())-A);const L="freinterests"===w&&200===v.status;if(U&&U.sections&&U.sections.length||L||(N=this.logAndReturnNoContentError(h,p,v.status,$,v,S,x)),O&&(U.debugId=O),void 0!==P&&(U.traceIdIndex=P),v&&v.status&&(U.status=v.status),E||(0,y.DZ)(U.authContext),"winfullpage"===w&&U&&U.sections&&U.sections.length>0){const e=U.sections;(e[0].subSections&&e[0].subSections.length>0?e[0].subSections:e).some(e=>!e.layoutTemplate)&&F.YT.sendAppErrorEvent({...n.vD4,pb:{...n.vD4.pb,url:decodeURIComponent(h.href),dataTemplate:U.sections.map(e=>e.dataTemplate).join(","),layoutTemplate:U.sections.map(e=>e.layoutTemplate).join(",")},message:"LayoutTemplate field missing for sections on the feeds call"})}const M=U&&U.serviceContext&&U.serviceContext.debugInfo&&U.serviceContext.debugInfo.includes("layout:oneservice");var D;if(M)F.YT.sendAppErrorEvent({...n.Rvj,message:"1S returned static fallback due to WPO failure.",pb:{...n.Rvj.pb,url:decodeURIComponent(h.href),debugId:null==U||null===(D=U.serviceContext)||void 0===D||null===(D=D.debugInfo)||void 0===D?void 0:D.debugId}});if(g){const e=(e=>{const{sections:t,...i}=e;return{sections:I(t),...i}})(U);return{responseHeaders:C,...e,isStatic:E}}return{responseHeaders:C,...U,appError:N,isStatic:!!E,traceIdIndex:P,isWpoFallback:!!M}}catch(e){var P;const t={...n.CPX,message:"Error while fetching OneService response",pb:{...n.CPX.pb,originalHref:C,url:h.href,endpoint:null===(P=h.href)||void 0===P?void 0:P.split("?")[0],activityId:f.T3.ActivityId,requestHeaders:JSON.stringify((0,b.bl)(p.headers)),customMessage:e&&e.message,retryNum:T,stack:e&&e.stack,isBackgroundRefresh:$,isInitialRequest:S,isFPRequest:this.isFullPageRequest(x)}};F.YT.sendAppErrorEvent(t);let i=!1;this.isUserNetworkConditionError(e.message)&&(i=!0);let r=!1;return this.isUserFailedToFetchError(e.message)&&(r=!0),{sections:null,appError:t,userEndError:i,userEndFailedToFetch:r}}}getSearchResponse(e,t,i,r){const o={responseHeaders:t,status:i.status,isStatic:!!r,sections:null},n={};return e instanceof Array&&e.length&&e.forEach(e=>{var t;if(null!=e&&null!==(t=e.data)&&void 0!==t&&t.length)try{if("MSNNewsResult"==(null==e?void 0:e.id)&&null!=e&&e.additionalNewsContent)n.cards=e.additionalNewsContent,n.template="channeltop",o.sections=[n];else if("NextPageUrlResult"==(null==e?void 0:e.id)){const t=JSON.parse(e.data);o.nextPageUrl=t}}catch(e){o.sections=null,o.userEndError=!0}}),o}async addRequestParametersForFRE(e,t){if("winWidgets"===f.T3.AppType&&e.enableFREOverlayMyFeed){const i=(0,w.Lg)().getItem(l.e$);let r=i||"0";e.doNotTriggerFREInSession&&(r="10"),F.YT.addOrUpdateTmplProperty("freoverlay-ux","1"),F.YT.addOrUpdateTmplProperty("ovrly-qsp",r),g.vv.set("overlayQspSent",r),t.searchParams.set("overlay",r)}}storeRecommendedInterestsTmpls(e){const t=e.match(l.xD),i=e.match(l.Qw);t&&t[0]&&i&&i[0]&&(0,w.Lg)().setItem(l.VE,`${t[0]};${i[0]}`)}async getRequestInit(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{method:"GET"},t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{};const i=2===await(0,R.XK)(),r=(0,x.Th)().CurrentFlights;(null!=r&&r.includes("1s-r-user-qsp")||i)&&(e.credentials="include");const o=await $.WR.getOneServiceFeedCallHeaders();return e.headers={...o,...t},e}async getCommonParams(e,t,i,r){const o=2===await(0,R.XK)();let n=f.T3.UserId;return!n&&i&&(n=`m-${f.T3.ActivityId}`),o?$.WR.getOneServiceParamsWithAuth(n??void 0,e,!1,t,r):$.WR.getOneServiceParamsWithoutAuth(n??void 0,e,!1,t,r)}logAndReturnNoContentError(e,t,i,r,o,a,s){const d={...n.tF9,message:"Service returned no content.",pb:{...n.tF9.pb,activityId:f.T3.ActivityId,requestHeaders:JSON.stringify((0,b.bl)(t.headers)),responseHeaders:this.getResponseHeaders(o),status:i,url:e.href,isBackgroundRefresh:r,isInitialRequest:a,isFPRequest:this.isFullPageRequest(s)}};return F.YT.sendAppErrorEvent(d),d}isFullPageRequest(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"no";return e?`gemQSP: ${JSON.stringify(e)}`:t}isUserNetworkConditionError(e){return e&&"Failed to fetch"==e||"Service Request Timed out!"==e||"Service Request Timed out after 10000 milliseconds!"==e}isUserFailedToFetchError(e){return e&&"Failed to fetch"==e}getResponseHeaders(e){return e&&e.headers?JSON.stringify({"Akamai-Request-ID":e.headers.get("Akamai-Request-ID"),"Akamai-Server-IP":e.headers.get("Akamai-Server-IP"),"X-MSEdge-Ref":e.headers.get("X-MSEdge-Ref"),"Ddd-Debugid":e.headers.get("Ddd-Debugid")}):null}}},68656(e,t,i){"use strict";i.r(t),i.d(t,{sendAdReaction(){return a},sendContentReaction(){return n}});var r=i(93557),o=i(55078);const n=e=>{const{actionPosition:t,reset:i,id:o,localStorageSave:n,reactionType:a,url:s}=e,d=e.item||r.ll.contents;i?r.l.sendResetReaction({actionPosition:t,item:d,id:o,localStorageSave:n,reactionType:null,url:s}):r.l.sendReaction({actionPosition:t,item:d,id:o,reactionType:a,localStorageSave:n,url:s})},a=e=>{const{reset:t,id:i,reactionType:r,url:n,destinationUrl:a}=e;t?o.I.resetAd(i,r):o.I.reportAd(i,r,n,a)}},73893(e,t,i){"use strict";i.d(t,{m(){return s}});var r=i(65614),o=i(71008),n=i(42792);const a=i(96950).qy`
    <slot></slot>
`,s=o.h.compose({name:`${r.G.prefix}-card`,styles:n.R7,template:a})},75261(e,t,i){"use strict";i.d(t,{t(){return s}});var r=i(56911),o=i(60815),n=i(92011),a=i(38493);class s extends n.L{constructor(){super(...arguments),this.percentComplete=0}valueChanged(){this.updatePercentComplete()}minChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}maxChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}connectedCallback(){super.connectedCallback(),this.updatePercentComplete()}updatePercentComplete(){const e="number"==typeof this.min?this.min:0,t="number"==typeof this.max?this.max:100,i="number"==typeof this.value?this.value:0,r=t-e;this.percentComplete=0===r?0:Math.fround((i-e)/r*100)}}(0,r.Cg)([(0,a.CF)({converter:a.R$}),(0,r.Sn)("design:type",Object)],s.prototype,"value",void 0),(0,r.Cg)([(0,a.CF)({converter:a.R$}),(0,r.Sn)("design:type",Number)],s.prototype,"min",void 0),(0,r.Cg)([(0,a.CF)({converter:a.R$}),(0,r.Sn)("design:type",Number)],s.prototype,"max",void 0),(0,r.Cg)([(0,a.CF)({mode:"boolean"}),(0,r.Sn)("design:type",Boolean)],s.prototype,"paused",void 0),(0,r.Cg)([o.sH,(0,r.Sn)("design:type",Number)],s.prototype,"percentComplete",void 0)},78103(e,t,i){"use strict";function r(e){return!(e&&e.length)}i.d(t,{I(){return r}})},80090(e,t,i){"use strict";i.d(t,{m(){return I}});var r=i(65614),o=i(11310),n=i(7896),a=i(48751),s=i(41123),d=i(57416),l=i(62047),c=i(14996),h=i(89580),p=i(99657),g=i(86856),u=i(74849),f=i(73477),m=i(4126),v=i(22131),x=i(50882);const b=u.A`
    .text,
    .media-info,
    .gradient {
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
    }

    .action-tray {
        transition-duration: var(--video-transition-end-duration);
        transition-property: background-color;
    }

    ::slotted([slot="media-overlay"]) {
        color: #ffffff;
        fill: #ffffff;
        height: 40px;
        min-width: 40px;
        display: grid;
        padding: 0px;
        grid-auto-flow: column;
        grid-gap: 8px;
        box-sizing: border-box;
        align-items: center;
        justify-content: center;
        border-radius: 20px;
        border: 1px solid transparent;
        transition-duration: var(--video-transition-end-duration);
        transition-property: opacity;
        opacity: 1;
        background: linear-gradient(
                    135deg,
                    rgba(0, 0, 0, 0.5) 0%,
                    rgba(0, 0, 0, 0.7) 100%
                )
                padding-box,
            linear-gradient(
                    180deg,
                    rgba(255, 255, 255, 0.4) 0%,
                    rgba(255, 255, 255, 0.2) 100%
                )
                border-box;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 22px;
        min-width: 22px;
        padding: 0 6px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) {
        height: 38px;
        min-width: 38px;
        padding: 0 6px;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media-overlay"]) > svg {
        height: 7px;
        width: 8px;
    }

    :host([animate-video]) .media-info,
    :host([immersive-card][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_1x_2y"][animate-video]) ::slotted([slot="media-overlay"]),
    :host([size="_2x_2y"][animate-video]) ::slotted([slot="media-overlay"]) {
        transition-delay: var(--video-transition-delay);
        transition-duration: var(--video-transition-start-duration);
        opacity: 0;
    }
`,y=u.A`
    .preload {
        transition: none !important;
    }

    :host {
        --content-padding: 16px;
        --no-image-action-tray-padding: 20px;
        --action-tray-padding: 10px;
        width: 100%;
        height: 100%;
        font-family: ${n.O};
        --video-transition-delay: 1s;
        --video-transition-start-duration: 1s;
        --video-transition-end-duration: 1s;
    }

    :host([subscibed])::after {
        position: absolute;
        content: "";
        bottom: 0;
        left: 0;
        right: 0;
        height: 4px;
        width: 100%;
        background: linear-gradient(90deg, #ffa03d 0%, #ffdb00 100%);
    }

    :host([size="_1x_2y"]),
    :host([size="_2x_2y"]) {
        --content-card-heading-font-size: 18px;
        --content-card-heading-line-height: 24px;
    }

    :host .content {
        display: grid;
        grid-template-columns: 1fr minmax(auto, 84px);
        grid-template-rows: 1fr auto;
        row-gap: 14px var(--content-padding) var(--content-padding) var(--content-padding);
        column-gap: 12px;
        width: 100%;
        height: 100%;
        box-sizing: border-box;
        color: ${a.l};
        position: relative;
    }

    :host([size="_1x_1y"]) .content {
        row-gap: 0px;
        padding: 14px var(--content-padding) 10px var(--content-padding);
    }

    :host([size="_2x_1y"]) .content {
        row-gap: 0px;
        padding: var(--content-padding) var(--content-padding) 14px var(--content-padding);
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        grid-template-columns: 1fr;
        column-gap: 0;
    }

    :host([size="_1x_2y"]) .content {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]) .content.no-image {
        grid-template-rows: auto 1fr auto;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .content:not(.no-image) .text {
        padding-top: 12px;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .content:not(.no-image) .text {
        padding-top: 0;
    }

    :host([size="_2x_2y"]) .content,
    :host([immersive-card]) .content {
        align-items: end;
        grid-template-rows: 1fr auto auto;
    }

    :host([size="_2x_2y"]) .no-image {
        align-items: unset;
    }

    :host([size="_1x_2y"]) .content,
    :host([size="_2x_2y"]) .content {
        padding: 0;
        row-gap: 0;
    }

    :host([size="_1x_1y"]) .content.no-image,
    :host([size="_2x_1y"]) .content.no-image,
    :host([size="_1x_2y"]) .content.no-image,
    :host([size="_2x_2y"]) .content.no-image {
        grid-template-rows: 1fr auto;
    }

    ::slotted([slot="abstract"]) {
        display: none;
        overflow: hidden;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: var(--abstract-max-lines, 7);
        margin-top: var(--abstract-margin-top, 5px);
    }

    .no-image ::slotted([slot="abstract"]) {
        display: -webkit-box;
        -webkit-line-clamp: var(--abstract-max-lines, 3);
    }

    :host([size="_1x_1y"]) .no-image ::slotted([slot="abstract"]),
    :host([size="_2x_1y"]) .no-image ::slotted([slot="abstract"]) {
        --abstract-max-lines: 1;
    }

    .text {
        grid-area: 1 / 1;
        padding: var(--content-padding) var(--content-padding) 0 var(--content-padding);
        overflow: hidden;
        font-size: ${s.K};
        line-height: ${s.Z};
    }

    :host([size="_1x_1y"]) .text,
    :host([size="_2x_1y"]) .text {
        padding: 0;
    }

    :host([size="_1x_1y"]) .no-image .text,
    :host([size="_2x_1y"]) .no-image .text {
        grid-column: 1 / span 2;
    }

    :host([size="_1x_2y"]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        padding: 14px var(--content-padding) 0 var(--content-padding);
        grid-row: 1;
    }

    :host([size="_2x_2y"]) .text,
    :host([size="_1x_2y"]) .text {
        grid-row: 2;
    }

    :host([immersive-card]) .text,
    :host([size="_2x_2y"]) .text {
        background-color: var(--image-gradient-overlay-end-color);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray,
    :host([size="_1x_2y"]:not([immersive-card])) .action-tray,
    :host .no-image .action-tray {
        background-color: transparent;
    }

    :host([immersive-card]) .no-image .text,
    :host([size="_2x_2y"]) .no-image .text {
        background: unset;
    }

    :host([size="_1x_2y"]) .action-tray,
    :host([size="_2x_2y"]) .action-tray {
        grid-row: 3;
        padding: 4px var(--content-padding) var(--action-tray-padding)
            var(--content-padding);
    }

    :host([immersive-card]) .action-tray,
    :host([size="_2x_2y"]) .content:not(.no-image) .action-tray {
        padding: var(--action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
    }

    .action-tray {
        grid-row: 2;
        grid-column: span 2;
        display: flex;
        position: relative;
        background-color: var(--image-gradient-overlay-end-color);
        padding: var(--action-tray-padding) var(--content-padding) var(--content-padding)
            var(--content-padding);
    }

    :host([size="_1x_1y"]) .action-tray,
    :host([size="_2x_1y"]) .action-tray {
        padding: 0;
    }

    :host([size="_2x_1y"]) .content:not(.no-image) .action-tray {
        grid-area: 2 / 1 / auto / auto;
    }

    :host([size="_1x_1y"]) .no-image .action-tray {
        padding: 4px 0 0 0;
    }

    :host([size="_1x_2y"]) .no-image .action-tray,
    :host([size="_2x_2y"]) .no-image .action-tray {
        padding: var(--no-image-action-tray-padding) var(--content-padding)
            var(--action-tray-padding) var(--content-padding);
        background: none;
        grid-row: 2;
        grid-column: 1;
    }

    .media-info {
        display: grid;
        grid-auto-flow: column;
        width: fit-content;
        grid-gap: 4px;
        fill: white;
        color: white;
        margin-bottom: 8px;
    }

    :host([size="_1x_2y"]:not([immersive-card])) .media-info {
        grid-row: 1;
        grid-column: 1;
        align-self: flex-end;
        margin-bottom: 6px;
        margin-inline-start: 6px;
    }

    :host([size="_2x_1y"]:not([immersive-card])) .media-info {
        grid-area: 1 / 2 / span2 / auto;
        align-self: flex-end;
        margin-bottom: 8px;
        margin-inline-start: 6px;
    }

    ::slotted([slot="media-info"]) {
        display: grid;
        align-items: center;
        grid-auto-flow: column;
        grid-gap: 3px;
        background-color: var(--image-gradient-overlay-end-color);
        border-radius: calc(${d.Pb} * 1px);
        padding: 2px 6px;
        font-size: ${l.t};
        line-height: ${l.e};
    }

    ::slotted([slot="hide-story"]) {
        box-sizing: border-box;
        align-items: center;
        background-color: #ffffff;
        border-radius: 100%;
        border: 1px solid #e5e5e5;
        color: rgba(0, 0, 0 1);
        cursor: pointer;
        display: flex;
        fill: currentcolor;
        font-family: ${n.O};
        font-size: ${s.K};
        height: 28px;
        justify-content: center;
        line-height: ${s.Z};
        margin-inline-start: 4px;
        min-width: 28px;
        outline: none;
        padding: 0;
        position: relative;
    }

    ::slotted([slot="hide-story"]:hover) {
        background-color: #f2f2f2;
    }

    ::slotted([slot="hide-story"]:active) {
        background-color: #f7f7f7;
    }

    :host .hide-story-wrapper {
        position: absolute;
        display: flex;
        flex-direction: row;
        top: var(--content-padding);
    }

    :host .hide-story {
        display: flex;
        justify-content: center;
        align-items: center;
        opacity: 0;
        transition: opacity 0.1s linear;
    }

    :host(:hover) .hide-story,
    :host(:focus-within) .hide-story {
        opacity: 1;
    }

    :host ::slotted([slot="hide-story"]:${f.N}) {
        border-color: ${c.WN};
    }

    ::slotted([slot="media"]) {
        grid-column: 1;
        object-fit: cover;
    }

    :host([size="_1x_1y"]) ::slotted([slot="media"]) {
        height: 84px;
        width: 84px;
        grid-row: 1;
        grid-column: 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_2x_1y"]) ::slotted([slot="media"]) {
        height: 114px;
        width: 216px;
        grid-area: 1 / 2 / span2 / 2;
        border-radius: var(--half-card-image-corner-radius, 8px);
        overflow: hidden;
    }

    :host([size="_1x_2y"]) ::slotted([slot="media"]) {
        grid-row: 1;
        grid-column: 1;
        height: 157px;
        width: 100%;
        display: flex;
    }

    :host([size="_2x_2y"]) ::slotted([slot="media"]),
    :host([immersive-card]) ::slotted([slot="media"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
    }

    ::slotted([slot="attribution"]) {
        display: flex;
        grid-column: 1;
        grid-row: 1;
        margin-bottom: 8px;
    }

    :host([size="_1x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]),
    :host([size="_2x_1y"]) .content:not(.no-image) ::slotted([slot="attribution"]) {
        grid-column-end: 1;
    }

    .heading {
        color: ${a.l};
        fill: currentcolor;
        display: -webkit-box;
        outline: 0;
        overflow: hidden;
        text-decoration: none;
        -webkit-line-clamp: var(--heading-max-lines, 3);
        -webkit-box-orient: vertical;
        font-weight: 600;
        font-size: var(--content-card-heading-font-size, ${h.Y});
        line-height: var(--content-card-heading-line-height, ${h.v});
    }

    .heading:focus-visible {
        text-decoration: underline;
    }

    .heading:after {
        bottom: 0;
        content: "";
        height: 100%;
        left: 0;
        position: absolute;
        right: 0;
        width: 100%;
        z-index: ${p.I};
    }

    :host([size="_2x_2y"][immersive-card]) .heading {
        --heading-max-lines: 2;
    }

    .media-overlay {
        position: absolute;
        display: flex;
        align-items: center;
        justify-content: center;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        pointer-events: none;
    }

    :host([size="_1x_1y"]) .media-overlay {
        grid-column: 2;
        grid-row: 1;
        height: 84px;
        width: 84px;
    }

    :host([size="_1x_2y"]) .media-overlay {
        grid-row-start: 1;
        grid-row-end: 1;
    }

    :host([size="_2x_2y"]) .media-overlay,
    :host([immersive-card]) .media-overlay {
        top: 100px;
        align-items: unset;
    }

    :host([size="_1x_2y"]) .no-image .heading,
    :host([size="_2x_2y"]) .no-image .heading {
        --heading-max-lines: 9;
    }

    :host([size="_2x_1y"]) .media-overlay {
        grid-area: 1 / 2 / span2 / 2;
        height: 114px;
        width: 216px;
    }

    ::slotted(p) {
        font-weight: 400;
        font-size: var(--abstract-font-size, 14px);
        line-height: var(--abstract-line-height, 20px);
        font-kerning: auto;
        margin: 8px 0px 0px;
    }

    ::slotted([slot="footer-start"]),
    ::slotted([slot="footer-end"]),
    ::slotted([slot="hide-story"]) {
        z-index: ${p.D};
    }

    .footer-end,
    .footer-start {
        display: flex;
        align-items: center;
    }

    .footer-end {
        margin-inline-start: auto;
    }

    .gradient {
        background: linear-gradient(
            180deg,
            var(--image-gradient-overlay-start-color) 0%,
            var(--image-gradient-overlay-end-color) 100%
        );
        grid-row: 1;
        height: 100%;
        display: none;
    }

    :host([size="_2x_2y"]) .gradient,
    :host([immersive-card]) .gradient {
        display: block;
        height: 80px;
    }

    :host([size="_2x_2y"]) .no-image .gradient,
    .no-image .gradient {
        display: none;
    }

    :host([size="_2x_1y"]) .content {
        column-gap: 24px;
    }
`.withBehaviors(new m.o("mediaType","video",b),new g.t(u.A`
            :host .hide-story-wrapper {
                right: var(--content-padding);
            }
        `,u.A`
            :host .hide-story-wrapper {
                left: var(--content-padding);
            }
        `),(0,v.mr)(u.A`
            :host {
                forced-color-adjust: auto;
            }
            .gradient {
                display: none;
            }
            :host([size="_1x_2y"]) .content,
            :host([size="_1x_1y"]) .content,
            :host([size="_2x_1y"]) .content {
                background: ${x.A.ButtonFace};
            }
            :host([size="_1x_2y"]) .text,
            :host([size="_1x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .text,
            :host([size="_2x_2y"]) .action-tray,
            :host([size="_2x_2y"]) .content,
            :host([immersive-card]) .content {
                background: transparent;
            }
            ::slotted([slot="hide-story"]) {
                color: ${x.A.ButtonText};
                fill: currentcolor;
            }
        `));var w=i(96950),k=i(82774),$=i(416),_=i(10108),z=i(69259),S=i(1413);const R=w.qy`
    <slot name="media" ${(0,k.e)("mediaSlot")}></slot>
`,C=(F={mediaTemplate:R},w.qy`
        <template
            role="article"
            ${(0,$.Y)({property:"childElements",filter:(0,_.Y)()})}
        >
            <div class="content${e=>e.mediaType?"":" no-image"}" part="content">
                ${F.mediaTemplate}
                ${(0,z.z)(e=>e&&(0,S.P)("media-info",e.childElements)&&!(e.immersiveCard||"_2x_2y"===e.size),(0,S.y)({slotName:"media-info"}))}
                <div class="gradient" part="gradient"></div>
                ${(0,S.y)({slotName:"media-overlay",slottedDefault:F.mediaOverlay})}
                <div class="text" part="text">
                    ${(0,z.z)(e=>e&&(0,S.P)("media-info",e.childElements)&&(e.immersiveCard||"_2x_2y"===e.size),(0,S.y)({slotName:"media-info"}))}
                    <slot name="attribution"></slot>
                    <a
                        id="heading"
                        class="heading"
                        part="heading"
                        href="${e=>e.href?e.href:void 0}"
                        target="${e=>e.target?e.target:void 0}"
                        @click=${(e,t)=>e.handleContentCardLinkClick(t.event)}
                        data-t="${e=>e.anchorTelemetryTag}"
                    >
                        <span role="heading" aria-level="${e=>e.headingLevel}">
                            <slot></slot>
                        </span>
                    </a>
                    ${(0,S.y)({slotName:"abstract"})}
                </div>
                <div
                    class="action-tray ${e=>e.loaded?"":"preload"}"
                    part="action-tray"
                >
                    ${(0,S.y)({slotName:"footer-start",slottedDefault:F.footerStart})}
                    ${(0,S.y)({slotName:"footer-end",slottedDefault:F.footerEnd})}
                </div>
                <div class="hide-story-wrapper" part="hide-story-wrapper">
                    ${(0,S.y)({slotName:"hide-story",slottedDefault:F.hideStory})}
                </div>
            </div>
        </template>
    `);var F;const I=o.W.compose({name:`${r.G.prefix}-content-card`,styles:y,template:C})},80286(e,t,i){"use strict";var r,o;i.d(t,{OQ(){return o},Qw(){return n},Sd(){return d},VE(){return s},e$(){return l},xD(){return a}}),function(e){e.OneService="OneService",e.WindowsShell="WindowsShell"}(r||(r={})),function(e){e.Bgtask="bgTask",e.BgRefresh="bgRefresh",e.Api="api",e.App="appLoad",e.AppErrRefresh="appErrRefresh",e.RetryFetch="retryFetch",e.Scroll="scroll",e.ApiErrorRefresh="apiErrorRefresh",e.Init="init",e.BgInit="bgInit",e.CacheExpired="cacheExpired",e.SettingsChanged="settingsChanged",e.SessionExpired="sessionExpired",e.PrefChange="PrefChange",e.StaleRefresh="staleRefresh",e.WeatherCardTrigger="weatherCardTrigger"}(o||(o={}));const n=/lowT:\d/i,a=/lowC:\d/i,s="rihp",d=["en-us","da-dk","de-at","de-ch","de-de","en-au","en-ca","en-gb","en-in","en-nz","es-es","es-mx","es-us","fr-ch","fr-fr","fr-ca","it-it","ja-jp","pt-br","nb-no","sv-se","ko-kr","pl-pl","nl-nl","nl-be","zh-cn","zh-tw","zh-hk","en-ph","pt-pt","id-id","tr-tr","th-th","ar-ae","es-cl","fi-fi","hu-hu","en-sg","vi-vn","en-my","en-ie","es-ar","ar-eg","en-za","en-xl"],l="seenInterestsFRECount"},84056(e,t,i){"use strict";i.d(t,{J(){return s}});var r=i(59836),o=i(73893),n=i(80090),a=i(65614);function s(){r.m.define(a.G.registry),o.m.define(a.G.registry),n.m.define(a.G.registry)}},93518(e,t,i){"use strict";i.d(t,{X(){return g}});var r=i(56911),o=i(97004),n=i(64183),a=i(95239),s=i(356),d=i(31023),l=i(37302),c=i(96193),h=i(38493),p=i(50866);class g extends c.z{constructor(){super(...arguments),this.size=p.qJ._1x_2y}cardFillColorChanged(e,t){this.isDarkCardGradient()?s.l.setValueFor(this,o.y.DarkMode):this.isLightCardGradient()?s.l.setValueFor(this,o.y.LightMode):s.l.deleteValueFor(this)}isDarkCardGradient(){return Object.values(p.NZ).includes(this.cardFillColor)}isLightCardGradient(){return Object.values(p.L9).includes(this.cardFillColor)}isNamedGradientFillColor(){return this.isLightCardGradient()||this.isDarkCardGradient()}connectedCallback(){super.connectedCallback(),l.jO.setValueFor(this,{evaluate(e,t){return(0,n.o)(e(d.r),t||e(a.p),-1,1,0,0,void 0,2,3,1,2,void 0)}})}}(0,r.Cg)([(0,h.CF)({attribute:"card-fill-color"}),(0,r.Sn)("design:type",Object)],g.prototype,"cardFillColor",void 0),(0,r.Cg)([h.CF,(0,r.Sn)("design:type",String)],g.prototype,"size",void 0)},96193(e,t,i){"use strict";i.d(t,{z(){return o}});var r=i(92011);class o extends r.L{}},99657(e,t,i){"use strict";i.d(t,{D(){return a},I(){return n}});var r=i(45755);const{create:o}=r.G,n=o("sloppy-click-z-index",1),a=o("click-z-index",1)}}]);