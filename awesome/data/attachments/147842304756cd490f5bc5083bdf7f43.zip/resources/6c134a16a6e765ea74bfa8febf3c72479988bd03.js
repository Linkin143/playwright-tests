"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["interest-management-card"],{25717(e,t,r){r.d(t,{T(){return n}});var o=r(96950);function n(){return o.qy`
        <slot></slot>
    `}},37256(e,t,r){r.d(t,{R(){return u}});var o=r(64187),n=r(22131),i=r(74849),a=r(50882),c=r(37998),s=r(57416),l=r(95239),d=r(48751);const u=i.A`
    ${(0,o.V)("block")} :host {
        --elevation: 4;
        display: block;
        contain: content;
        height: var(--card-height, 100%);
        width: var(--card-width, 100%);
        box-sizing: border-box;
        background: ${l.p};
        color: ${d.l};
        border-radius: calc(${s.JU} * 1px);
        ${c.ET}
    }

    :host(:hover) {
        --elevation: 8;
    }

    :host(:focus-within) {
        --elevation: 8;
    }

    :host {
        content-visibility: auto;
    }
`.withBehaviors((0,n.mr)(i.A`
            :host {
                forced-color-adjust: none;
                background: ${a.A.Canvas};
                box-shadow: 0 0 0 1px ${a.A.CanvasText};
            }
        `))},38380(e,t,r){r.d(t,{v(){return o}});const o=(0,r(25717).T)()},55201(e,t,r){r.d(t,{Hv(){return n},Sk(){return i},sm(){return o}});const o="toggleWidgetPicker",n="manageInterestsClosed",i="playPivotCoachMarkEven"},72526(e,t,r){r.d(t,{L(){return p}});var o=r(56911),n=r(96193),i=r(47429),a=r(60815),c=r(22870),s=r(38493),l=r(95239),d=r(31023),u=r(24458),g=r(5291),h=r(57606);class p extends n.z{cardFillColorChanged(e,t){if(t){const e=(0,c.Hs)(t);null!==e&&(this.neutralPaletteSource=t,l.p.setValueFor(this,g.q.create(e.r,e.g,e.b)))}}neutralPaletteSourceChanged(e,t){if(t){const e=(0,c.Hs)(t),r=g.q.create(e.r,e.g,e.b);d.r.setValueFor(this,h.p.create(r))}}handleChange(e,t){this.cardFillColor||l.p.setValueFor(this,e=>e(u.M3).evaluate(e,e(l.p)))}connectedCallback(){super.connectedCallback();const e=(0,i.Zo)(this);if(e){const t=a.cP.getNotifier(e);t.subscribe(this,"fillColor"),t.subscribe(this,"neutralPalette"),this.handleChange(e,"fillColor")}}}(0,o.Cg)([(0,s.CF)({attribute:"card-fill-color",mode:"fromView"}),(0,o.Sn)("design:type",String)],p.prototype,"cardFillColor",void 0),(0,o.Cg)([(0,s.CF)({attribute:"neutral-palette-source",mode:"fromView"}),(0,o.Sn)("design:type",String)],p.prototype,"neutralPaletteSource",void 0)},75003(e,t,r){r.d(t,{m(){return c}});var o=r(37180),n=r(72526),i=r(37256),a=r(38380);const c=n.L.compose({name:`${o.c.prefix}-card`,template:a.v,styles:i.R})},85230(e,t,r){r.r(t),r.d(t,{InterestManagementCard(){return F},InterestManagementCardDarkTheme(){return f},InterestManagementCardStyles(){return w},InterestManagementCardTemplate(){return E},TOGGLE_WIDGET_PICKER(){return C},ToolingInfo(){return y}});var o=r(2958),n=r(37180),i=r(75003),a=r(56911),c=r(66198),s=r(30010),l=r(12680),d=r(39671),u=r(36806),g=r(58792),h=r(77367),p=r(55201),m=r(74849),b=r(50882),v=r(22131),k=r(77078);const x=m.A` :host{--icon-color:${b.A.ButtonText};
        --icon-color-hover: ${b.A.HighlightText}}:host ::part(control):focus-visible,:host fluent-button:focus-visible::part(control),:host :focus-visible::part(control),:host fluent-button::part(control):focus-visible{background-color:${b.A.Highlight};
        color: ${b.A.HighlightText};
    }
`,f=m.A` :host{border-radius:8px;--manager-title-color:white;--manager-description-color:white;--manager-button-background-color:${(0,k.m1)()?"#0078D4":"#405CE8"};
        --manager-button-background-color-hover: #3B4EC3;
        --manager-button-background-color-active: #25295D;
        --manager-container-border-color: black;
        --manager-container-gradient: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
        --icon-color: ${b.A.ButtonText};
        --icon-color-hover: ${b.A.HighlightText};
    }
`,w=m.A` :host{border-radius:8px;--manager-title-color:#1A1A1A;--manager-description-color:#1A1A1A;--manager-button-background-color:${(0,k.m1)()?"#0078D4":"#405CE8"};--manager-button-background-color-hover:#3B4EC3;--manager-button-background-color-active:#25295D;--manager-container-border-color:white;--manager-container-gradient:radial-gradient(100% 193.51% at 100% 0%,#EDF4F8 0%,#EFF2FA 16.92%,#FAEFF6 34.8%,#FAE6F2 48.8%,#FAF0F7 63.79%,#F1F1FB 81.34%,#F0F4F8 100%);--icon-color:white;--icon-color-hover:white}#manager-container{height:304px;border:5px solid var(--manager-container-border-color);background:var(--manager-container-gradient);display:flex;flex-direction:column;align-items:center}#manager-container.clickable{cursor:pointer}.background-icons{height:185px;width:654px;margin-top:-54px}.title{width:520px;text-align:center;color:var(--manager-title-color);font-weight:600;font-size:24px;line-height:32px;margin-top:16px}.description{width:520px;text-align:center;color:var( --manager-description-color);font-weight:400;font-size:14px;line-height:20px;margin-top:4px}.pick-up-interest{background:var(--manager-button-background-color);height:40px;box-shadow:0px 2px 4px rgba(0,0,0,0.1);border-radius:8px;margin-top:12px;color:white}.pick-up-interest:hover{background:var(--manager-button-background-color-hover)}.pick-up-interest:active{background:var(--manager-button-background-color-active)}.icon{display:inline-block;position:relative;height:16px;width:16px;background-color:var(--icon-color);mask-image:url(${(0,g.rA)().StaticsUrl}/latest/interests-manager/PickUpInterestIcon.svg);mask-repeat:no-repeat;mask-size:contain;mask-position:center;margin-right:11px;top:3px}.pick-up-interest:hover .icon{background-color:var(--icon-color-hover)}.auto-width{width:auto;margin:0 2px 0 2px;padding:0 16px 0 16px}`.withBehaviors((0,v.mr)(x));var $=r(60815);const C="toggleWidgetPicker";class F extends d.U{constructor(){super(...arguments),this.pickInterestsClicked=new CustomEvent("pickinterestsclicked",{detail:{name:"pickInterests"}}),this.interestManagerEvent=new CustomEvent("seemoreclickinterests",{detail:{name:"seemore"}}),this.isDarkMode=!1,this.manageClickedHandler=()=>{const e=(0,c.pr)(s.u.myInterests);if(h.YT.addOrUpdateTmplProperty("ChannelStoreLaunched","1"),this.config.useChannelStore)window.dispatchEvent(new CustomEvent("launchChannelStore"));else if(e)e.click();else if(this.config.isMobile?window.dispatchEvent(this.interestManagerEvent):window.dispatchEvent(this.pickInterestsClicked),!this.config.skipRedirectOnClick){const e={noScroll:!0,pageType:"MyInterests"};if(u.QB.getRouteById("personalize"))u.QB.navigate("personalize",e);else if(this.config.enableProng2Experience)this.showWidgetPickerHandler();else{const t=new URL(window.location.href);t.pathname=`/${g.T3.CurrentMarket}/feed/personalize`,window.history.pushState({...e,shouldPush:!0},"",t.toString())}}},this.showWidgetPickerHandler=()=>{window.dispatchEvent(new CustomEvent(p.sm,{detail:{launchWidgetPicker:!0}}))}}getExperienceType(){return l.rh2}shadowDomPopulated(){if(this.config.enableProng2Experience){var e;const t=null===(e=this.shadowRoot)||void 0===e?void 0:e.getElementById("manager-container");t&&t.addEventListener("click",this.showWidgetPickerHandler)}if(this.config.respectDarkTheme&&this.isDarkMode){const e=f;this.shadowRoot&&e.addStylesTo(this.shadowRoot)}}disconnectedCallback(){if(super.disconnectedCallback(),this.config.enableProng2Experience){const e=this.querySelector("#manager-container");e&&e.removeEventListener("click",this.showWidgetPickerHandler)}}}(0,a.Cg)([$.sH],F.prototype,"isDarkMode",void 0);const E=r(96950).qy`<fluent-card id="manager-container" class="clickable" @click=${e=>e.manageClickedHandler()}><img class="background-icons" src=${()=>`${(0,g.rA)().StaticsUrl}/latest/interests-manager/background-icons.png`} role="presentation"/><div class="${e=>e.config.textStyleClassName??""} title">${e=>e.strings.title}</div><div class="${e=>e.config.textStyleClassName??""} description" part="description">${e=>e.strings.description}</div><fluent-button appearance="neutral" class="pick-up-interest" title="${e=>e.strings.pickUpInterest}" aria-label="${e=>`${e.strings.title} ${e.strings.pickUpInterest}`}"><span class="icon" aria-hidden="true"></span>${e=>e.strings.pickUpInterest}</fluent-button></fluent-card>`,y={experienceConfigSchema:undefined};o.m.define(n.c.registry),i.m.define(n.c.registry)},96193(e,t,r){r.d(t,{z(){return n}});var o=r(92011);class n extends o.L{}}}]);