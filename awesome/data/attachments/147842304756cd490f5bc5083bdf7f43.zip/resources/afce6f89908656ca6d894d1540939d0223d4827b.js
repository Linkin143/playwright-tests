"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["cs-core-desktop_card-shared_dist_AdaptiveHeightSharedStyles_js-cs-core-desktop_card-shared_di-d25d69"],{1349(t,e,i){i.d(e,{J(){return l},O(){return a}});var s=i(77367),o=i(85349),n=i(69781),r=i(10809);function a(t,e){const i=r.D.getConfig();null!=i&&i.enableMouseDwellTime&&(0,n.kM)(e,()=>s.YT.sendActionEvent(t,o.EG.Hover,o.MS.Open),null==i?void 0:i.mdtHoverThreshold)}function l(t,e){const i=r.D.getConfig();null!=i&&i.enableMouseDwellTime&&(0,n.pS)(e,()=>s.YT.sendActionEvent(t,o.EG.MouseLeave,o.MS.Open))}},4912(t,e,i){i.d(e,{v(){return a}});var s=i(96950),o=i(69259),n=i(60402),r=i(87656);const a=function(t){const e=s.qy.partial((0,r.g)(t.anchoredRegion));return s.qy`
        ${(0,o.z)(t=>t.tooltipVisible,s.qy`
            <${e}
                fixed-placement="true"
                auto-update-mode="${t=>t.autoUpdateMode}"
                vertical-positioning-mode="${t=>t.verticalPositioningMode}"
                vertical-default-position="${t=>t.verticalDefaultPosition}"
                vertical-inset="${t=>t.verticalInset}"
                vertical-scaling="${t=>t.verticalScaling}"
                horizontal-positioning-mode="${t=>t.horizontalPositioningMode}"
                horizontal-default-position="${t=>t.horizontalDefaultPosition}"
                horizontal-scaling="${t=>t.horizontalScaling}"
                horizontal-inset="${t=>t.horizontalInset}"
                vertical-viewport-lock="${t=>t.horizontalViewportLock}"
                horizontal-viewport-lock="${t=>t.verticalViewportLock}"
                dir="${t=>t.currentDirection}"
                ${(0,n.K)("region")}
            >
                <div class="tooltip" part="tooltip" role="tooltip">
                    <slot></slot>
                </div>
            </${e}>
        `)}
    `}({anchoredRegion:i(7927).m})},5111(t,e,i){i.d(e,{Es(){return a},b$(){return d},gN(){return h},j9(){return o},t3(){return l}});var s=i(74849);const o="1.8135 / 1",n=s.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]) {
        aspect-ratio: 1;
    }

    :host([size="1.5u"]) .media-container {
        aspect-ratio: ${o};
    }
`,r=s.A`
    :host([size="3c"][ux-mode="billboard"]) .media,
    :host([size="4c"][ux-mode="billboard"]) .media {
        width: 100%;
    }
`,a="prg-lg-flex",l=s.A`${n}`,h=(s.A`
${n}
${r}
`,"prg-pr2-lg-flex"),d=s.A`${n}`;s.A`
${n}
${r}
`},14804(t,e,i){i.d(e,{c(){return C}});var s=i(56911),o=i(92011),n=i(23429),r=i(38493),a=i(60815),l=i(31157),h=i(55230),d=i(42938);const u="top",c="right",v="bottom",p="left",m="center",g="start",f="end",b="top-left",y="top-center",w="top-right",$="bottom-left",x="bottom-center",z="bottom-right",k="top-start",P="top-end",T="bottom-start",_="bottom-end";class C extends o.L{constructor(){super(...arguments),this.anchor="",this.delay=300,this.autoUpdateMode="anchor",this.anchorElement=null,this.viewportElement=null,this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.horizontalInset="false",this.verticalInset="false",this.horizontalScaling="content",this.verticalScaling="content",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition=void 0,this.tooltipVisible=!1,this.currentDirection=l.O.ltr,this.showDelayTimer=null,this.hideDelayTimer=null,this.isAnchorHoveredFocused=!1,this.isRegionHovered=!1,this.handlePositionChange=t=>{this.classList.toggle("top","start"===this.region.verticalPosition),this.classList.toggle("bottom","end"===this.region.verticalPosition),this.classList.toggle("inset-top","insetStart"===this.region.verticalPosition),this.classList.toggle("inset-bottom","insetEnd"===this.region.verticalPosition),this.classList.toggle("center-vertical","center"===this.region.verticalPosition),this.classList.toggle("left","start"===this.region.horizontalPosition),this.classList.toggle("right","end"===this.region.horizontalPosition),this.classList.toggle("inset-left","insetStart"===this.region.horizontalPosition),this.classList.toggle("inset-right","insetEnd"===this.region.horizontalPosition),this.classList.toggle("center-horizontal","center"===this.region.horizontalPosition)},this.handleRegionMouseOver=t=>{this.isRegionHovered=!0},this.handleRegionMouseOut=t=>{this.isRegionHovered=!1,this.startHideDelayTimer()},this.handleAnchorMouseOver=t=>{this.tooltipVisible?this.isAnchorHoveredFocused=!0:this.startShowDelayTimer()},this.handleAnchorMouseOut=t=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.handleAnchorFocusIn=t=>{this.startShowDelayTimer()},this.handleAnchorFocusOut=t=>{this.isAnchorHoveredFocused=!1,this.clearShowDelayTimer(),this.startHideDelayTimer()},this.startHideDelayTimer=()=>{this.clearHideDelayTimer(),this.tooltipVisible&&(this.hideDelayTimer=window.setTimeout(()=>{this.updateTooltipVisibility()},60))},this.clearHideDelayTimer=()=>{null!==this.hideDelayTimer&&(clearTimeout(this.hideDelayTimer),this.hideDelayTimer=null)},this.startShowDelayTimer=()=>{this.isAnchorHoveredFocused||(this.delay>1?null===this.showDelayTimer&&(this.showDelayTimer=window.setTimeout(()=>{this.startHover()},this.delay)):this.startHover())},this.startHover=()=>{this.isAnchorHoveredFocused=!0,this.updateTooltipVisibility()},this.clearShowDelayTimer=()=>{null!==this.showDelayTimer&&(clearTimeout(this.showDelayTimer),this.showDelayTimer=null)},this.getAnchor=()=>{const t=this.getRootNode();return t instanceof ShadowRoot?t.getElementById(this.anchor):document.getElementById(this.anchor)},this.handleDocumentKeydown=t=>{if(!t.defaultPrevented&&this.tooltipVisible&&t.key===h.F9)this.isAnchorHoveredFocused=!1,this.updateTooltipVisibility(),this.$emit("dismiss")},this.updateTooltipVisibility=()=>{if(!1===this.visible)this.hideTooltip();else{if(!0===this.visible)return void this.showTooltip();if(this.isAnchorHoveredFocused||this.isRegionHovered)return void this.showTooltip();this.hideTooltip()}},this.showTooltip=()=>{this.tooltipVisible||(this.currentDirection=(0,d.u)(this),this.tooltipVisible=!0,document.addEventListener("keydown",this.handleDocumentKeydown),n.L.enqueue(this.setRegionProps))},this.hideTooltip=()=>{this.tooltipVisible&&(this.clearHideDelayTimer(),null!==this.region&&void 0!==this.region&&(this.region.removeEventListener("positionchange",this.handlePositionChange),this.region.viewportElement=null,this.region.anchorElement=null,this.region.removeEventListener("mouseover",this.handleRegionMouseOver),this.region.removeEventListener("mouseout",this.handleRegionMouseOut)),document.removeEventListener("keydown",this.handleDocumentKeydown),this.tooltipVisible=!1)},this.setRegionProps=()=>{this.tooltipVisible&&(this.region.viewportElement=this.viewportElement,this.region.anchorElement=this.anchorElement,this.region.addEventListener("positionchange",this.handlePositionChange),this.region.addEventListener("mouseover",this.handleRegionMouseOver,{passive:!0}),this.region.addEventListener("mouseout",this.handleRegionMouseOut,{passive:!0}))}}visibleChanged(){this.$fastController.isConnected&&(this.updateTooltipVisibility(),this.updateLayout())}anchorChanged(){this.$fastController.isConnected&&(this.anchorElement=this.getAnchor())}positionChanged(){this.$fastController.isConnected&&this.updateLayout()}anchorElementChanged(t){if(this.$fastController.isConnected){if(null!=t&&(t.removeEventListener("mouseover",this.handleAnchorMouseOver),t.removeEventListener("mouseout",this.handleAnchorMouseOut),t.removeEventListener("focusin",this.handleAnchorFocusIn),t.removeEventListener("focusout",this.handleAnchorFocusOut)),null!==this.anchorElement&&void 0!==this.anchorElement){this.anchorElement.addEventListener("mouseover",this.handleAnchorMouseOver,{passive:!0}),this.anchorElement.addEventListener("mouseout",this.handleAnchorMouseOut,{passive:!0}),this.anchorElement.addEventListener("focusin",this.handleAnchorFocusIn,{passive:!0}),this.anchorElement.addEventListener("focusout",this.handleAnchorFocusOut,{passive:!0});const t=this.anchorElement.id;null!==this.anchorElement.parentElement&&this.anchorElement.parentElement.querySelectorAll(":hover").forEach(e=>{e.id===t&&this.startShowDelayTimer()})}null!==this.region&&void 0!==this.region&&this.tooltipVisible&&(this.region.anchorElement=this.anchorElement),this.updateLayout()}}viewportElementChanged(){null!==this.region&&void 0!==this.region&&(this.region.viewportElement=this.viewportElement),this.updateLayout()}connectedCallback(){super.connectedCallback(),this.anchorElement=this.getAnchor(),this.updateTooltipVisibility()}disconnectedCallback(){this.hideTooltip(),this.clearShowDelayTimer(),this.clearHideDelayTimer(),super.disconnectedCallback()}updateLayout(){switch(this.verticalPositioningMode="locktodefault",this.horizontalPositioningMode="locktodefault",this.position){case u:case v:this.verticalDefaultPosition=this.position,this.horizontalDefaultPosition="center";break;case c:case p:case g:case f:this.verticalDefaultPosition="center",this.horizontalDefaultPosition=this.position;break;case m:this.verticalDefaultPosition="center",this.horizontalDefaultPosition="center";break;case b:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="left";break;case y:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="center";break;case x:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="center";break;case w:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="right";break;case $:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="left";break;case z:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="right";break;case k:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="start";break;case P:this.verticalDefaultPosition="top",this.horizontalDefaultPosition="end";break;case T:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="start";break;case _:this.verticalDefaultPosition="bottom",this.horizontalDefaultPosition="end";break;default:this.verticalPositioningMode="dynamic",this.horizontalPositioningMode="dynamic",this.verticalDefaultPosition=void 0,this.horizontalDefaultPosition="center"}}}(0,s.Cg)([(0,r.CF)({mode:"boolean"}),(0,s.Sn)("design:type",Boolean)],C.prototype,"visible",void 0),(0,s.Cg)([r.CF,(0,s.Sn)("design:type",String)],C.prototype,"anchor",void 0),(0,s.Cg)([(0,r.CF)({attribute:"delay",converter:r.R$}),(0,s.Sn)("design:type",Number)],C.prototype,"delay",void 0),(0,s.Cg)([r.CF,(0,s.Sn)("design:type",String)],C.prototype,"position",void 0),(0,s.Cg)([(0,r.CF)({attribute:"auto-update-mode"}),(0,s.Sn)("design:type",String)],C.prototype,"autoUpdateMode",void 0),(0,s.Cg)([(0,r.CF)({attribute:"horizontal-viewport-lock"}),(0,s.Sn)("design:type",Boolean)],C.prototype,"horizontalViewportLock",void 0),(0,s.Cg)([(0,r.CF)({attribute:"vertical-viewport-lock"}),(0,s.Sn)("design:type",Boolean)],C.prototype,"verticalViewportLock",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",Object)],C.prototype,"anchorElement",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",Object)],C.prototype,"viewportElement",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",String)],C.prototype,"verticalPositioningMode",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",String)],C.prototype,"horizontalPositioningMode",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",String)],C.prototype,"horizontalInset",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",String)],C.prototype,"verticalInset",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",String)],C.prototype,"horizontalScaling",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",String)],C.prototype,"verticalScaling",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",Object)],C.prototype,"verticalDefaultPosition",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",Object)],C.prototype,"horizontalDefaultPosition",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",Boolean)],C.prototype,"tooltipVisible",void 0),(0,s.Cg)([a.sH,(0,s.Sn)("design:type",String)],C.prototype,"currentDirection",void 0)},18270(t,e,i){i.d(e,{E(){return p}});var s=i(90905),o=i(18284),n=i(46417),r=i(36042),a=i(58792),l=i(80895),h=i(22760),d=i(58960),u=i(66345);const c="winWidgets"==a.T3.AppType?"dashboardscroll":"scroll",v="superApp"==a.T3.AppType;class p{get options(){return this._options}static getInstance(t){return p.instance||(p.instance=new p,t&&(p.instance._options={...t})),p.instance}getVideoRect(t){return t?t.getBoundingClientRect():{with:0,height:0,x:0,y:0,top:0,bottom:0,left:0}}constructor(){this.playerPreviewInfoMap=new Map,this.animationEffectCardList=[],this.inViewPortRatio=.1,this.checkActivePlayerInterval=null,this.isEnabled=!0,this.mouseEnterCallbackListeners=new Set,this._options={enableScrollPreview:!1,enableFasterPlayer:!1},this.handleBatteryChargingChange=()=>{this.battery.charging?this.determineActiveVideo():this.pauseAllVideos()},this.handleVisibilityChange=(()=>{const t="winWidgets"==a.T3.AppType;document.hidden||t&&!l.F_.get(2)?this.pauseAllVideos():this.playPreviewController(this.activePreviewController,"scroll")}).bind(this),this.pauseAllVideos=()=>{this.playerPreviewInfoMap.forEach(t=>{t.controller.pause()}),this.previewState=null},this.resetPreviewState=t=>{var e;t===(null===(e=this.previewState)||void 0===e?void 0:e.controller)&&(this.previewState=null)},this.calculateViewportBounds=(0,o.A)(t=>({upperBound:-1*t*this.inViewPortRatio,lowerBound:(window.innerHeight||document.documentElement.clientHeight)+t*this.inViewPortRatio})),this.getInViewportRatio=t=>{const{top:e=0,bottom:i=0,height:s}=t.getBoundingClientRect(),{upperBound:o,lowerBound:n}=this.calculateViewportBounds(s);let r=0;switch(!0){case e<o:r=i/s;break;case i>n:r=(e-window.innerHeight)/s;break;case i<n&&e>o:r=1;break;default:r=0}return r},this.determineActiveVideo=()=>this.options.enableFasterPlayer?(0,r.A)(async()=>{this.getActiveVideoAndPlay()},100)():(0,s.A)(async()=>{this.getActiveVideoAndPlay()},350)(),this.getActiveVideoAndPlay=async()=>{var t,e;const[i,s]=this.getCorrectPlayerPreviewInfos();if(i.forEach(t=>t.controller.pause()),this.options.enableScrollPreview&&!this.isHoverPlaying&&!location.search.includes("reqsrc=vp")&&(0,u.G)()){if(await this.batteryPromise,!(v||null!==(t=this.battery)&&void 0!==t&&t.charging))return!1;s.size&&(this.activePreviewController=null===(e=s.values().next().value)||void 0===e?void 0:e.controller,this.playerPreviewInfoMap.forEach(t=>{(null==t?void 0:t.controller)!==this.activePreviewController&&t.controller.pause()}),this.playPreviewController(this.activePreviewController,"scroll"))}},this.handleAutoPlayPreferenceChange=t=>{t?this.determineAnimationEffectCard():this.pauseAllAnimationEffectCards()},this.videoPlayOnMouseActionDebouncedCallback=(0,s.A)(t=>{var e;t&&t===(null===(e=this.previewState)||void 0===e?void 0:e.controller)&&this.isHoverPlaying&&(this.pauseAllVideos(),this.playPreviewController(t,"hover"))},500),this.handleVideoCardManagerEvents=t=>{switch(t.type){case d.O.PauseAllVideos:this.isEnabled=!1,this.pauseAllVideos();break;case d.O.PlayActiveVideo:this.isEnabled=!0}},this.registerOnMouseEnterListener=t=>{this.mouseEnterCallbackListeners.add(t)},this.unregisterOnMouseEnterListener=t=>{this.mouseEnterCallbackListeners.delete(t)},this.dispatchMouseEnterListeners=()=>{for(const t of this.mouseEnterCallbackListeners)try{t()}catch(t){console.error("dispatchMouseEnterListeners error",t)}},this.unsubscribeAutoPlayPreference=(0,u.Z)(this.handleAutoPlayPreferenceChange),this.addVideoCardManagerEventListeners(),this.batteryPromise||(this.batteryPromise=navigator.getBattery&&navigator.getBattery().then(t=>{var e;this.battery=t,null===(e=this.batteryPromise)||void 0===e||e.then(()=>{this.battery.addEventListener("chargingchange",this.handleBatteryChargingChange)})})),document.addEventListener("visibilitychange",this.handleVisibilityChange,!1),l.F_.subscribe(2,this.handleVisibilityChange),window.addEventListener("views-inline-refresh",()=>this.dispose(),{once:!0})}dispose(){var t;this.removeEventListeners(),null===(t=this.unsubscribeAutoPlayPreference)||void 0===t||t.call(this),p.instance=null}removeEventListeners(){this.battery&&this.battery.removeEventListener("chargingchange",this.handleBatteryChargingChange),document.removeEventListener("visibilitychange",this.handleVisibilityChange,!1),l.F_.unsubscribe(2,this.handleVisibilityChange),this.removeVideoCardManagerEventListeners()}startIntervalCheckActivePlayer(){this.checkActivePlayerInterval=window.setInterval(()=>{this.determineActiveVideo()},100)}stopIntervalCheckActivePlayer(){this.checkActivePlayerInterval&&clearInterval(this.checkActivePlayerInterval)}bindEvents(){this.options.enableScrollPreview&&window.addEventListener(c,this.determineActiveVideo,!1),this.options.enableFasterPlayer&&this.startIntervalCheckActivePlayer()}unbindEvents(){this.options.enableScrollPreview&&window.removeEventListener(c,this.determineActiveVideo,!1),this.options.enableFasterPlayer&&this.stopIntervalCheckActivePlayer()}getCorrectPlayerPreviewInfos(){const t=[],e=[],i=this.isInfopaneVisible();this.playerPreviewInfoMap.forEach(s=>{const o=()=>!(0,h.St)(s.previewElement,1/8);o()||e.push(s);const n=s.triggers.includes("scroll"),r=s.controller.displayVideoPreviewCta,a=this.options.disableIfInfopaneExists&&i,l=s.controller.isNearScrollPreviewCapped;if(n&&!a&&!l&&o()){if(r)return;t.push(s)}else r&&s.controller.disableVideoPreviewCta()});const s=(0,n.A)(t,[t=>{let{previewElement:e}=t;return this.getInViewportRatio(e)},t=>{let{previewElement:e}=t;return this.getVideoRect(e).top},t=>{let{previewElement:e}=t;return this.getVideoRect(e).left}],["desc","asc","asc"]);return[new Set(e),new Set(s??[])]}removePlayer(t){var e;t===(null===(e=this.previewState)||void 0===e?void 0:e.controller)&&(t.pause(),this.previewState=null),this.playerPreviewInfoMap.delete(t.id),this.playerPreviewInfoMap.size||this.unbindEvents()}addPlayer(t,e,i,s){this.playerPreviewInfoMap.size||this.bindEvents(),this.playerPreviewInfoMap.forEach((t,e)=>{t.previewElement!==i||s&&s===t.sharedPreviewElementId||this.playerPreviewInfoMap.delete(e)}),t&&this.playerPreviewInfoMap.set(t.id,{controller:t,triggers:e,previewElement:i,sharedPreviewElementId:s}),this.options.enableVideoPostScroll||this.determineActiveVideo()}addAnimationEffectCard(t){this.animationEffectCardList.includes(t)||(this.animationEffectCardList.push(t),this.determineAnimationEffectCard())}removeAnimationEffectCard(t){this.animationEffectCardList.includes(t)&&(this.animationEffectCardList=this.animationEffectCardList.filter(e=>e!==t),this.determineAnimationEffectCard())}pauseAllAnimationEffectCards(){this.animationEffectCardList.forEach(t=>t.pause())}determineAnimationEffectCard(){var t;if(!(0,u.G)())return void this.pauseAllAnimationEffectCards();let e,i=null;this.animationEffectCardList.forEach(t=>{var s,o;(void 0===e||t.priority>=e)&&null!==(s=t.isActiveCandidate)&&void 0!==s&&s.call(t)?(null===(o=i)||void 0===o||o.pause(),e=t.priority,i=t):t.pause()}),null===(t=i)||void 0===t||t.play()}videoMouseEnterCallback(t){this.previewState={controller:t,trigger:"hover"},this.dispatchMouseEnterListeners(),this.videoPlayOnMouseActionDebouncedCallback(t)}videoMouseClickCallback(t){this.pauseAllVideos(),this.playPreviewController(t,"hover")}videoMouseLeaveCallback(t){this.previewState=null,t.pause()}playPreviewController(t,e){t&&e&&this.isEnabled&&(t.play(),this.previewState={controller:t,trigger:e})}async addVideoCardManagerEventListeners(){window.addEventListener(d.O.PlayActiveVideo,this.handleVideoCardManagerEvents),window.addEventListener(d.O.PauseAllVideos,this.handleVideoCardManagerEvents);const{PreviewEventDispatcher:t}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679));t.dispatchStickyEvent()}removeVideoCardManagerEventListeners(){window.removeEventListener(d.O.PlayActiveVideo,this.handleVideoCardManagerEvents),window.removeEventListener(d.O.PauseAllVideos,this.handleVideoCardManagerEvents)}isInfopaneVisible(){const t=(0,h.Kt)('[data-t*="Infopane"]');return t&&!(0,h.St)(t,.75)}get isPlaying(){return!!this.previewState}get isHoverPlaying(){var t;return"hover"===(null===(t=this.previewState)||void 0===t?void 0:t.trigger)}get isScrollPlaying(){var t;return"scroll"===(null===(t=this.previewState)||void 0===t?void 0:t.trigger)}}},22760(t,e,i){i.d(e,{CT(){return l},Kt(){return d},St(){return n},UV(){return h},h_(){return r},jc(){return a}});var s=i(42938),o=i(87582);const n=(t,e)=>{var i,n;if(!t)return!0;const{height:r,left:a,right:l,top:h}=t.getBoundingClientRect();if(!(r&&a&&l&&h))return!0;const d=function(t){for(;t.parentNode;)if((t=t.parentNode).shadowRoot)return t;return null}(t);if(!d)return h+r/2<0||h+r/2>window.innerHeight;const u=r*e,c=(0,s.u)(window.document.body)===o.OP.ltr?a+u:l-u,v=null==d||null===(i=d.shadowRoot)||void 0===i?void 0:i.elementFromPoint(c,h+u);return!(d.contains(v)||null!==(n=d.shadowRoot)&&void 0!==n&&n.contains(v))},r=()=>{const t=window&&window.navigator;if(!t)return!1;const{hardwareConcurrency:e=-1,deviceMemory:i=-1}=t;return i<=4},a=t=>{if(!t)return"";const e=Math.floor(t/60),i=t-60*e;return`${e>9?e:`0${e}`}:${i>9?i:`0${i}`}`};function l(t,e){return"number"==typeof t&&"number"==typeof e&&t>0&&e>0?t/e:1}async function h(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:100,i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:500,s=0;for(;!t()&&s<i;)await new Promise(t=>window.setTimeout(t,e)),s+=e}function d(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:document;const i=e.querySelector(t);if(i)return i;const s=e.querySelectorAll("*");for(const e of s)if(e instanceof HTMLElement&&e.shadowRoot){const i=d(t,e.shadowRoot);if(i)return i}return null}},26248(t,e,i){i.d(e,{El(){return d},Fh(){return u},Fu(){return P},GO(){return o},U7(){return T},XA(){return k},ap(){return z},cw(){return m},dD(){return b},fc(){return c},gX(){return y},hq(){return p},jJ(){return w},lu(){return f},mU(){return g},n1(){return v},p7(){return a},pp(){return r},ti(){return n},uG(){return x},vJ(){return $},vq(){return l},w_(){return h}});var s=i(74849);s.A`
`;const o=s.A` :host{--smtc-gap-between-content-small:8px;--smtc-padding-card-default:20px}`,n="var(--smtc-background-card-on-primary-alt-rest)",r="var(--smtc-background-card-on-primary-default-rest)",a="var(--smtc-corner-image-on-page, var(--smtc-corner-card-rest))",l="var(--smtc-ctrl-badge-icon-size)",h="var(--smtc-ctrl-badge-size)",d="var(--smtc-foreground-ctrl-neutral-primary-rest)",u="var(--smtc-foreground-ctrl-on-brand-rest)",c="var(--smtc-foreground-ctrl-on-image-rest)",v="var(--smtc-gap-between-content-large)",p="var(--smtc-gap-between-content-small)",m="var(--smtc-gap-between-ctrl-lg-default)",g="var(--smtc-padding-content-medium)",f="var(--smtc-padding-content-none)",b="var(--smtc-stroke-divider-subtle, var(--smtc-stroke-divider-default))",y="var(--smtc-text-global-body1-font-size)",w="var(--smtc-text-global-body1-line-height)",$="var(--smtc-text-global-body2-font-size)",x="var(--smtc-text-global-body2-line-height)",z="var(--smtc-text-global-body3-font-size)",k="var(--smtc-text-global-body3-line-height)",P="var(--smtc-text-style-default-header-weight)",T="var(--smtc-text-style-default-regular-weight)"},29783(t,e,i){i.d(e,{m(){return y}});var s=i(37180),o=i(14804),n=i(45755),r=i(68009),a=i(95239);const{create:l}=n.G,h=l("neutral-fill-inverse-rest-delta",0),d=l("neutral-fill-inverse-hover-delta",-3),u=l("neutral-fill-inverse-active-delta",7),c=l("neutral-fill-inverse-focus-delta",0);var v=i(31023);const{create:p}=n.G,m=p({name:"neutral-fill-inverse-recipe"},{evaluate(t,e){return function(t,e,i,s,o,n){const a=(0,r.F)(e),l=t.closestIndexOf(t.colorContrast(e,14)),h=l+a*Math.abs(i-s);let d,u;return(1===a?i<s:a*i>a*s)?(d=l,u=h):(d=h,u=l),{rest:t.get(d),hover:t.get(u),active:t.get(d+a*o),focus:t.get(d+a*n)}}(t(v.r),e||t(a.p),t(h),t(d),t(u),t(c))}});p("neutral-fill-inverse-rest",t=>t(m).evaluate(t).rest),p("neutral-fill-inverse-hover",t=>t(m).evaluate(t).hover),p("neutral-fill-inverse-active",t=>t(m).evaluate(t).active),p("neutral-fill-inverse-focus",t=>t(m).evaluate(t).focus);class g extends o.c{connectedCallback(){super.connectedCallback();const t=m;a.p.setValueFor(this,e=>e(t).evaluate(e,e(a.p)).rest)}}var f=i(54750),b=i(4912);const y=g.compose({name:`${s.c.prefix}-tooltip`,template:b.v,styles:f.R})},40221(t,e,i){var s,o;i.d(e,{b(){return o},u(){return s}}),function(t){t.MainImage="MainImage",t.Title="Title",t.LogoProvider="LogoProvider",t.AdLabel="AdLabel",t.AdChoice="AdChoice",t.CallToAction="CallToAction",t.PopupDisclaimer="PopupDisclaimer"}(s||(s={})),function(t){t.Row="Row",t.Column="Col"}(o||(o={}))},42495(t,e,i){i.d(e,{c(){return s}});const s=i(74849).A`
    :host {
        transition-property: transform;
        transition-timing-function: cubic-bezier(.4, 0, 1, 1);
        transition-duration: .2s;
    }

    :host(:hover) {
        transform: matrix(1.025, 0, 0, 1.025, 0, 0);
    }

    .media, :host(:hover) .media,
    :host(:hover:not([grouped-item])) .media,
    :host(:not([in-playback-mode]):hover) .image-area {
        transform: none;
    }

    @media (prefers-reduced-motion: reduce) {
        :host {
            transition-duration: 0s;
        }
        :host(:hover) {
            transform: none;
        }
    }
`},43774(t,e,i){i.d(e,{p4(){return m},ls(){return g},vA(){return p},nF(){return v}});var s=i(45755),o=i(68009),n=i(95239);const{create:r}=s.G,a=r("neutral-stroke-strong-hover-delta",40),l=r("neutral-stroke-strong-active-delta",16),h=r("neutral-stroke-strong-focus-delta",25);var d=i(31023);const{create:u}=s.G,c=u({name:"neutral-stroke-strong-recipe"},{evaluate(t){return function(t,e,i,s,n,r){const a=(0,o.F)(e),l=t.colorContrast(e,i),h=t.closestIndexOf(l);return{rest:l,hover:t.get(h+a*s),active:t.get(h+a*n),focus:t.get(h+a*r)}}(t(d.r),t(n.p),3,t(a),t(l),t(h))}}),v=u("neutral-stroke-strong-rest",t=>t(c).evaluate(t).rest),p=u("neutral-stroke-strong-hover",t=>t(c).evaluate(t).hover),m=u("neutral-stroke-strong-active",t=>t(c).evaluate(t).active),g=u("neutral-stroke-strong-focus",t=>t(c).evaluate(t).focus)},45964(t,e,i){i.d(e,{_q(){return a},hU(){return h}});var s,o=i(93552),n=i(22341);function r(t,e){if(t instanceof Error){const i=t.toString();return e&&t.stack?`${i}, Stack: ${t.stack}`:i}return"string"==typeof t?t:function(t){if(void 0===t)return"undefined";try{return JSON.stringify(t)}catch{return"[serialization-error]"}}(t)}!function(t){t.LO="101",t.SD="102",t.HQ="103",t.HD="104",t.FHD="105",t["4K"]="107",t.Source="1001",t.SmoothStreaming="1004",t.HLS="1006",t.DASH="1007"}(s||(s={}));const a=(t,e)=>{try{const i=(t=>t&&Array.isArray(t)?t.filter(t=>{if(!t||"object"!=typeof t)return!1;const e=t.url&&"string"==typeof t.url&&t.url.trim().length>0,i=void 0!==t.fileSize&&"number"==typeof t.fileSize&&!isNaN(t.fileSize)&&isFinite(t.fileSize)&&t.fileSize>0;return e&&i}):[])(t);if(null==i||!i.length)return;const s=(t,e)=>{const i=t.fileSize,s=e.fileSize;return i<s?-1:i>s?1:0},o=i.sort(s);return void 0!==e&&e>=0&&o.length>0?o[Math.min(e,o.length-1)]:o.length>0?o[0]:void 0}catch(t){return void(0,n.vV)(o.A0q,"Error processing video files",r(t))}},l=["hover","scroll"],h=function(t,e,i,s){let r=arguments.length>4&&void 0!==arguments[4]?arguments[4]:"",h=arguments.length>5?arguments[5]:void 0,d=arguments.length>6&&void 0!==arguments[6]&&arguments[6],u=arguments.length>7?arguments[7]:void 0,c=arguments.length>8&&void 0!==arguments[8]?arguments[8]:"msn",v=arguments.length>9?arguments[9]:void 0,p=arguments.length>10&&void 0!==arguments[10]&&arguments[10],m=arguments.length>11&&void 0!==arguments[11]&&arguments[11],g=arguments.length>12?arguments[12]:void 0,f=arguments.length>13?arguments[13]:void 0,b=arguments.length>14?arguments[14]:void 0,y=arguments.length>15?arguments[15]:void 0,w=arguments.length>16?arguments[16]:void 0,$=arguments.length>17?arguments[17]:void 0;const x=Array.isArray(s)?s:[],z=a(x,f);return{cardElement:t,config:{enableVideoCardHover:!0,enableVideoCardScroll:!0,capScrollPreview:d,enableVideoPreview:p,enableUserAutoPlaySettings:m,enablePauseOnComplete:$},logError(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"Generic Error Message";(0,n.vV)(o.fbJ,t,`Video Id: ${i}`)},previewTriggers:w||l,videoElement:e,videoData:{id:i,videoFile:z,title:r,videoDurationMs:h,motionThumbnailUrl:v,closedCaptions:b},overridePreviewElement:u,source:c,enablePreloadOnSetupTime:g,onHoverOtherVideoCallback:y}}},48535(t,e,i){i.d(e,{U(){return u},v(){return a}});var s=i(66591),o=i(96950),n=i(69259),r=i(58792);function a(t){return`dislike-button-${t}`}const l=t=>{var e;return Boolean(null==t||null===(e=t.rubyDislikeController)||void 0===e?void 0:e.showFewerButtonSelected)},h=o.qy`<img alt="" aria-hidden="true" src="${(0,r.rA)().StaticsUrl}/latest/fluent-icons/thumb_dislike_20_filled.svg"></img>`,d=o.qy`<img alt="" aria-hidden="true" src="${(0,r.rA)().StaticsUrl}/latest/fluent-icons/thumb_dislike_20_regular.svg"></img>`,u=t=>{var e;return o.qy`<button class=${null!=t&&t.className?(t=>`${l(t)?"disliked":"not-disliked"}-${null==t?void 0:t.className}`)(t):(t=>(0,s.x)("like-card-button dislike-card-button",["render-bottom-tooltip",Boolean(null==t?void 0:t.renderBottomTooltip)]))(t)} data-t="${(l(t)?null==t?void 0:t.telemetryTagUndo:null==t?void 0:t.telemetryTag)||""}" @click=${(t=>(e,i)=>{var s;const o=i.event,n=0!==o.clientX||0!==o.clientY;null==t||null===(s=t.rubyDislikeController)||void 0===s||s.toggleShowFewer(e,n)})(t)||(()=>{})} ?ruby=${(null==t?void 0:t.ruby)||!1} title=${(null==t?void 0:t.dislikeButtonTooltip)||""} id=${a((null==t?void 0:t.id)||"")} aria-pressed=${e=>l(t)} aria-label=${(null==t?void 0:t.ariaLabel)||(null==t?void 0:t.dislikeButtonTooltip)||(null==t||null===(e=t.getInnerText)||void 0===e?void 0:e.call(t,l(t),null==t?void 0:t.innerText))||""}>${(0,n.z)(l(t),h,d)} ${(0,n.z)(!(null==t||!t.innerText),(t=>{var e;return o.qy`<span>${(null==t||null===(e=t.getInnerText)||void 0===e?void 0:e.call(t,l(t),null==t?void 0:t.innerText))||""}</span>`})(t))} ${(0,n.z)((t=>Boolean((l(t)||Boolean(null==t?void 0:t.dislikeCount))&&(null==t?void 0:t.renderCount)))(t),(t=>{var e,i;return o.qy`<span class="dislike-count" aria-hidden="true">${(null==t||null===(e=t.rubyDislikeController)||void 0===e||null===(i=e.getDownvoteCount)||void 0===i?void 0:i.call(e,null==t?void 0:t.dislikeCount))||""}</span>`})(t))}</button>`}},52380(t,e,i){i.d(e,{i(){return g}});var s=i(56911),o=i(60815),n=i(77367),r=i(97015),a=i(65114),l=i(22760),h=i(18270),d=i(22341),u=i(93552);async function c(t,e){try{const i=await fetch(t);if(!i.ok)return(0,d.vV)(u.gl8,"Error FETCHING VTT caption file",`Video ID: ${e}, VTT URL: ${t}`),null;const s=await i.text(),o=new Blob([s],{type:"text/vtt"});return URL.createObjectURL(o)}catch(i){const s=i instanceof Error?i.message:String(i);return(0,d.vV)(u.gl8,"Error PARSING VTT caption file",`Video ID: ${e}, VTT URL: ${t}`,{errorMessage:s}),null}}function v(t){const e=t.textTracks||[];if(e.length>0&&e[0]){e[0].mode="showing"}}var p=i(66345),m=i(17918);class g{get isScrollPreviewCapped(){return this.scrollLoopCount>=this.maxScrollLoops}get isNearScrollPreviewCapped(){return this.scrollLoopCount>this.maxScrollLoops-1}get videoPlayer(){var t;return null!==(t=this.config)&&void 0!==t&&t.enableVideoTelemetry?this.nativeVideoPlayer:this.videoElement}constructor(t){var e,i,s;if(this.type="video",this.isHoverTriggered=!1,this.isOneTimeVideoPlayedOnScroll=!1,this.isForInlinePlayer=!1,this.eventHandlers={},this.isVideoPlaying=!1,this.hidePreviewBadges=!1,this.shouldRenderPreviewBadges=!1,this.isPreviewable=!1,this.isPortrait=!1,this.displayVideoPreviewCta=!1,this.isVideoLoaded=!1,this.isCompleted=!1,this.hasCompletedOnce=!1,this.scrollLoopCount=0,this.maxScrollLoops=1,this.handleAutoPlayPreferenceChange=t=>{var e;const i=this.filterPreviewTriggers(this.originalPreviewTriggers,t);if(this.arePreviewTriggerSetsEqual(this.activePreviewTriggers,i))return;if(this.activePreviewTriggers=i,!this.videoElement||!this.previewManagerInstance)return;const s=this.overridePreviewElement??this.videoElement;var o,n;(this.previewManagerInstance.removePlayer(this),this.previewManagerInstance.addPlayer(this,this.activePreviewTriggers,s,null===(e=this.config)||void 0===e?void 0:e.sharedPreviewElementId),this.activePreviewTriggers.includes("scroll"))?null===(o=(n=this.previewManagerInstance).determineActiveVideo)||void 0===o||o.call(n):this.pause()},this.onVideoLoaded=()=>{this.isVideoLoaded=!0},!t.useMobile&&(0,l.h_)())return;const{videoElement:o,overridePreviewElement:n,config:a,enablePreloadOnSetupTime:d,hidePreviewBadges:u,isForInlinePlayer:c,onHoverOtherVideoCallback:v}=t;this.cardElement=t.cardElement,this.config=a||{},this.videoData=t.videoData,this.motionThumbnailUrl=t.videoData.motionThumbnailUrl,this.isPreviewable=Boolean(null===(e=t.videoData.videoFile)||void 0===e?void 0:e.url)||this.isCNVideoPreviewable,this.logError=t.logError,this.videoElement=o,this.overridePreviewElement=n,this.videoFile=t.videoData.videoFile,this.id=t.videoData.id,this.isPortrait=this.videoFile&&(0,l.CT)(this.videoFile.width,this.videoFile.height)<1,this.type="video",this.hidePreviewBadges=u,this.originalPreviewTriggers=[...t.previewTriggers];const g=null===(i=this.config)||void 0===i||!i.enableUserAutoPlaySettings||(0,p.G)();this.activePreviewTriggers=this.filterPreviewTriggers(this.originalPreviewTriggers,g),this.isForInlinePlayer=c,this.onHoverOtherVideoCallback=v;const f={enableScrollPreview:null==a?void 0:a.enableVideoCardScroll,enableFasterPlayer:null==a?void 0:a.enableFasterPlayer,enableVideoPostScroll:null==a?void 0:a.enableVideoPostScroll,disableIfInfopaneExists:null==a?void 0:a.disableVideoPreviewATF};if(this.videoElement){var b,y;this.videoElement.addEventListener("loadeddata",this.onVideoLoaded,{once:!0}),d&&this.preload(),(0,m.dT)().then(()=>{this.injectClosedCaptions()}),this.previewManagerInstance=h.E.getInstance(f);const t=this.overridePreviewElement??this.videoElement;null===(b=this.previewManagerInstance)||void 0===b||b.addPlayer(this,this.activePreviewTriggers,t,null===(y=this.config)||void 0===y?void 0:y.sharedPreviewElementId),this.onHoverOtherVideoCallback&&this.previewManagerInstance.registerOnMouseEnterListener(this.onHoverOtherVideoCallback)}this.cardElement&&this.originalPreviewTriggers.includes("hover")&&this.registerHoverHandlers(this.cardElement),null!==(s=this.config)&&void 0!==s&&s.enableVideoTelemetry&&this.videoElement&&this.setupVideoTelemetry(t.videoData.videoDurationMs,t.videoData.title),this.isCNVideoPreviewable&&this.videoPlayer&&(this.videoPreviewUrl=(0,r.x3)(this.motionThumbnailUrl)),this.initializeAutoPlayPreferenceHandling(),this.checkAspectRatio()}initializeAutoPlayPreferenceHandling(){var t,e;this.videoElement&&null!==(t=this.config)&&void 0!==t&&t.enableVideoCardScroll&&null!==(e=this.config)&&void 0!==e&&e.enableUserAutoPlaySettings&&this.originalPreviewTriggers.includes("scroll")&&(this.autoPlayPreferenceUnsubscribe=(0,p.Z)(this.handleAutoPlayPreferenceChange))}async setupVideoTelemetry(t,e){var s;const{NativeVideoPlayer:o,VideoCardManager:n}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679));if(this.videoElement&&null!==(s=this.config)&&void 0!==s&&s.enableVideoTelemetry){const i={video:{id:this.id,durationSec:t,title:e||"",sourceId:"",categories:[],isWebContent:!1,isVideoPreview:!0},isAutoplay:!1,isFirstVideoFromPlaylist:!1,isInline:!0,isLocal:!1};this.nativeVideoPlayer=new o,this.nativeVideoPlayer.initialize({playerInfo:i,videoElement:this.videoElement});const s=n.getInstance();s.enableTelemetry(),s.registerPlayer(this.id,this.nativeVideoPlayer)}}async deregisterTelemetry(){var t;if(null!==(t=this.config)&&void 0!==t&&t.enableVideoTelemetry){const{VideoCardManager:t}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679));t.getInstance().deregisterPlayer(this.id)}}dispose(){var t;this.previewManagerInstance&&this.previewManagerInstance.removePlayer(this),this.onHoverOtherVideoCallback&&this.previewManagerInstance.unregisterOnMouseEnterListener(this.onHoverOtherVideoCallback),this.unregisterHoverHandlers(this.cardElement),this.deregisterTelemetry(),null===(t=this.autoPlayPreferenceUnsubscribe)||void 0===t||t.call(this),this.autoPlayPreferenceUnsubscribe=void 0}play(){var t,e;if(this.isScrollPreviewCapped&&!this.isHoverTriggered)return;const i=!this.isVideoLoaded&&"auto"===(null===(t=this.videoElement)||void 0===t?void 0:t.preload);null===(e=this.videoPlayer)||void 0===e||!e.src||i?(clearTimeout(this.playTimer),this.playTimer=window.setTimeout(()=>{this.play()},150)):this.videoPlayer&&this.videoPlayer.paused&&(this.videoElement.attributes["data-stay-pause"]||this.playVideo())}pause(){var t;clearTimeout(this.playTimer),null===(t=this.previewManagerInstance)||void 0===t||t.resetPreviewState(this),this.videoPlayer&&(this.videoPlayer.pause(),this.isVideoPlaying=!1)}resetCurrentTime(){this.videoPlayer&&(this.videoPlayer.currentTime=0,this.isCompleted=!1)}restartVideo(){this.videoPlayer&&(this.resetCurrentTime(),this.videoPlayer.play())}playVideo(){var t;this.isOneTimeVideoPlayedOnScroll&&(this.isOneTimeVideoPlayedOnScroll=!1,this.videoPlayer.currentTime=0),null===(t=this.videoPlayer)||void 0===t||t.play().then(()=>{this.isVideoPlaying=!0,this.displayVideoPreviewCta=!1}).catch(t=>{var e;"object"==typeof t&&null!==(e=t.message)&&void 0!==e&&e.includes("The play() request was interrupted by a call to pause()")||this.logError(`Error playing video - ${t}`),this.isVideoPlaying=!1})}registerHoverHandlers(t){this.isForInlinePlayer?this.registerHoverHandlerForInlinePlayer(t):(this.eventHandlers={hoverStart:t=>this.hoverStart(t),hoverEnd:t=>this.hoverEnd(t)},t.addEventListener("mouseenter",this.eventHandlers.hoverStart),t.addEventListener("mouseleave",this.eventHandlers.hoverEnd))}unregisterHoverHandlers(t){this.isForInlinePlayer?this.unregisterHoverHandlerForInlinePlayer(t):(null==t||t.removeEventListener("mouseenter",this.eventHandlers.hoverStart),null==t||t.removeEventListener("mouseleave",this.eventHandlers.hoverEnd))}registerHoverHandlerForInlinePlayer(t){this.eventHandlers={hoverStart:t=>this.hoverStartForInlinePlayer(t)},t.addEventListener("mouseenter",this.eventHandlers.hoverStart)}async hoverStartForInlinePlayer(t){const{VideoCardManager:e}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679)),s=null==e?void 0:e.getInstance();if(!s)return;const o=s.getPlayer(this.id);null!=o&&o.isPlaying||(s.pauseAll(),null==o||o.play())}async unregisterHoverHandlerForInlinePlayer(t){null==t||t.removeEventListener("mouseenter",this.eventHandlers.hoverStart);const{VideoCardManager:e}=await Promise.all([i.e("libs_video-manager_dist_VideoCardManager_js"),i.e("libs_video-card-plugin-factory_dist_VideoAdManager_js-libs_views-helpers_dist_EventsDefinitio-69e731")]).then(i.bind(i,56679));(null==e?void 0:e.getInstance()).deregisterPlayer(this.id)}hoverStart(t){var e;this.shouldRenderPreviewBadges=!this.hidePreviewBadges,this.isHoverTriggered=!0,null===n.YT||void 0===n.YT||n.YT.addOrUpdateTmplProperty("VideoHoverView","1"),this.displayVideoPreviewCta||this.isPreviewable&&(null===(e=this.previewManagerInstance)||void 0===e||e.videoMouseEnterCallback(this))}clickStart(){var t,e;let i=!(arguments.length>0&&void 0!==arguments[0])||arguments[0];this.displayVideoPreviewCta||!i&&null!==(t=this.previewManagerInstance)&&void 0!==t&&t.isPlaying||(this.videoPlayer&&(this.videoPlayer.currentTime=0),this.isHoverTriggered=!1,this.isPreviewable&&(null===(e=this.previewManagerInstance)||void 0===e||e.videoMouseClickCallback(this)))}hoverEnd(t){var e;this.isHoverTriggered&&(null===(e=this.previewManagerInstance)||void 0===e||e.videoMouseLeaveCallback(this));this.isHoverTriggered=!1}onTimeUpdate(){if(!this.config||!this.videoPlayer)return;let t=this.videoPlayer.duration?Math.min(this.videoPlayer.duration,10):10;if(this.config.enableOneTimeVideoPlay&&!this.isHoverTriggered&&(t=Math.min(t,this.config.oneTimeVideoPlayLimit)),this.videoPlayer.currentTime>=t){if(this.isCompleted=!0,this.hasCompletedOnce||(this.hasCompletedOnce=!0),this.config.enableVideoPreviewCta&&!this.displayVideoPreviewCta)return void this.enableVideoPreviewCta();if(this.config.enableOneTimeVideoPlay&&!this.isHoverTriggered)return this.isOneTimeVideoPlayedOnScroll=!0,void this.pause();this.config.capScrollPreview&&!this.isHoverTriggered&&this.scrollLoopCount++;this.isScrollPreviewCapped&&!this.isHoverTriggered||this.config.enablePauseOnComplete&&this.isHoverTriggered?this.pause():this.restartVideo(),this.config.enableVideoTelemetry&&this.videoPlayer.duration>=t&&(this.fireVideoEnded(),this.fireVideoPlay())}}enableVideoPreviewCta(){this.displayVideoPreviewCta=!0,this.videoPlayer.currentTime=0,this.previewCtaTimer=window.setTimeout(()=>{this.disableVideoPreviewCta()},1e4),this.pause()}disableVideoPreviewCta(){clearTimeout(this.previewCtaTimer),this.displayVideoPreviewCta=!1}fireVideoEnded(){var t;null===(t=this.videoElement)||void 0===t||t.dispatchEvent(new CustomEvent("ended",{cancelable:!1,bubbles:!1}))}fireVideoPlay(){var t;null===(t=this.videoElement)||void 0===t||t.dispatchEvent(new CustomEvent("play",{cancelable:!1,bubbles:!1}))}checkAspectRatio(){const t=this.videoElement;null==t||t.addEventListener("loadedmetadata",()=>{this.isPortrait=t.videoWidth<t.videoHeight},{once:!0})}get isCNVideoPreviewable(){var t;return!(null===(t=this.config)||void 0===t||!t.enableVideoPreview||!this.getCNVideoProvider())}getCNVideoProvider(){if(!this.motionThumbnailUrl)return"";for(const[t,e]of Object.entries(a.yB)){if(new URL(this.motionThumbnailUrl).origin===e)return t}return""}preload(){var t;this.videoElement&&!this.isVideoLoaded&&"auto"!==this.videoElement.preload&&(this.videoElement.src||null!==(t=this.videoFile)&&void 0!==t&&t.url)&&(this.videoElement.src||(this.videoElement.src=this.videoFile.url),this.videoElement.preload="auto")}filterPreviewTriggers(t,e){var i,s;let o=[...t];return null!==(i=this.config)&&void 0!==i&&i.enableVideoCardScroll?null!==(s=this.config)&&void 0!==s&&s.enableUserAutoPlaySettings&&!e&&(o=o.filter(t=>"scroll"!==t)):o=o.filter(t=>"scroll"!==t),o}arePreviewTriggerSetsEqual(t,e){if(t.length!==e.length)return!1;const i=new Set(e),s=new Set(t);if(s.size!==i.size)return!1;for(const t of s)if(!i.has(t))return!1;return!0}async injectClosedCaptions(){var t;if(!this.videoElement||null===(t=this.videoData.closedCaptions)||void 0===t||!t.length)return;const e=function(t){const e=[];if(null!=t&&t.length)for(const i of t)e.push({kind:"captions",label:"Auto generated",srclang:i.locale||"en",src:(i.href||"")+"&vtt=true"});return e}(this.videoData.closedCaptions);await async function(t,e,i){if(t&&e&&0!==e.length){!function(t){var e;if(!t)return;(null===(e=t.querySelectorAll)||void 0===e?void 0:e.call(t,"track")).forEach(t=>t.remove());const i=t.textTracks||[];for(let t=0;t<i.length;t++)i[t].mode="disabled"}(t);for(let s=0;s<e.length;s++){const o=e[s],n=await c(o.src,i);if(n){const e=document.createElement("track");e.default=0===s,e.kind=o.kind,e.label=o.label,e.srclang=o.srclang,e.src=n,t.appendChild(e)}}}}(this.videoElement,e,this.id),this.videoElement.readyState>=1?v(this.videoElement):this.videoElement.addEventListener("loadedmetadata",()=>{v(this.videoElement)},{once:!0})}resetPreviewable(){var t;this.isPreviewable=Boolean(null===(t=this.videoData.videoFile)||void 0===t?void 0:t.url)||this.isCNVideoPreviewable}}(0,s.Cg)([o.sH],g.prototype,"isVideoPlaying",void 0),(0,s.Cg)([o.sH],g.prototype,"shouldRenderPreviewBadges",void 0),(0,s.Cg)([o.sH],g.prototype,"isPreviewable",void 0),(0,s.Cg)([o.sH],g.prototype,"previewManagerInstance",void 0),(0,s.Cg)([o.sH],g.prototype,"isPortrait",void 0),(0,s.Cg)([o.sH],g.prototype,"displayVideoPreviewCta",void 0),(0,s.Cg)([o.sH],g.prototype,"videoPreviewUrl",void 0),(0,s.Cg)([o.sH],g.prototype,"isVideoLoaded",void 0),(0,s.Cg)([o.sH],g.prototype,"isCompleted",void 0),(0,s.Cg)([o.sH],g.prototype,"hasCompletedOnce",void 0)},54750(t,e,i){i.d(e,{R(){return c}});var s=i(22131),o=i(74849),n=i(37998),r=i(57416),a=i(41123),l=i(95239),h=i(7896),d=i(26920),u=i(48751);const c=o.A`
    :host {
        --elevation: 11;
        position: relative;
        contain: layout;
        overflow: visible;
        height: 0;
        width: 0;
        z-index: 10000;
    }

    .tooltip {
        box-sizing: border-box;
        border-radius: calc(${r.Pb} * 1px);
        border: calc(${d.XA} * 1px) solid transparent;
        background: ${l.p};
        color: ${u.l};
        padding: 4px 12px;
        height: fit-content;
        width: fit-content;
        font-family: ${h.O};
        font-size: ${a.K};
        line-height: ${a.Z};
        white-space: nowrap;
        ${n.ET}
    }

    fluent-anchored-region {
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: visible;
        flex-direction: row;
    }

    fluent-anchored-region.right,
    fluent-anchored-region.left {
        flex-direction: column;
    }

    fluent-anchored-region.top .tooltip::after,
    fluent-anchored-region.bottom .tooltip::after,
    fluent-anchored-region.left .tooltip::after,
    fluent-anchored-region.right .tooltip::after {
        content: "";
        width: 12px;
        height: 12px;
        background: ${l.p};
        border-radius: calc(${r.Pb} * 1px);
        position: absolute;
    }

    fluent-anchored-region.top .tooltip::after {
        transform: rotate(45deg) translateX(-50%);
        bottom: 4px;
        left: 50%;
    }

    fluent-anchored-region.top .tooltip {
        margin-bottom: 12px;
    }

    fluent-anchored-region.bottom .tooltip::after {
        transform: rotate(45deg) translateX(-50%);
        top: 12px;
        left: 50%;
    }

    fluent-anchored-region.bottom .tooltip {
        margin-top: 12px;
    }

    fluent-anchored-region.left .tooltip::after {
        transform: rotate(45deg) translateY(-50%);
        top: 50%;
        right: 12px;
    }

    fluent-anchored-region.left .tooltip {
        margin-right: 12px;
    }

    fluent-anchored-region.right .tooltip::after {
        transform: rotate(45deg) translateY(-50%);
        top: 50%;
        left: 4px;
    }

    fluent-anchored-region.right .tooltip {
        margin-left: 12px;
    }
`.withBehaviors((0,s.mr)(o.A`
            :host([disabled]) {
                opacity: 1;
            }
            fluent-anchored-region.top .tooltip::after,
            fluent-anchored-region.bottom .tooltip::after,
            fluent-anchored-region.left .tooltip::after,
            fluent-anchored-region.right .tooltip::after {
                content: "";
                width: unset;
                height: unset;
            }
        `))},58960(t,e,i){var s;i.d(e,{O(){return s},v(){return o}}),function(t){t.PlayActiveVideo="previewPlayActiveVideo",t.PauseAllVideos="previewPauseAllVideos "}(s||(s={}));const o={[s.PlayActiveVideo]:new CustomEvent(s.PlayActiveVideo,{bubbles:!0}),[s.PauseAllVideos]:new CustomEvent(s.PauseAllVideos,{bubbles:!0})}},61889(t,e,i){i.d(e,{z(){return s}});const s={image:"image",video:"video"}},65114(t,e,i){i.d(e,{yB(){return s}});const s=Object.freeze({Yidianzixun:"https://msn2.go2yd.com",Renmin:"https://jfmicsovideos.peopletech.cn"});Object.freeze({Yidianzixun:"https://doris.yidianzixun.com"})},66345(t,e,i){i.d(e,{G(){return v},Z(){return p}});var s=i(95940),o=i(15525),n=i(94043);const r="auto-play-changed",a="enabled",l=new s.E("AutoPlayPreference"),h=new Set;let d=!1;const u=()=>{l.has(a)||l.set(a,(()=>{if(!(0,n.S)())return!0;const t=(0,o.Lg)().getItem("autoSettings");if(null==t)return!0;try{const e=JSON.parse(t);if("boolean"==typeof e)return e}catch(t){}return"false"!==t.toLocaleLowerCase()})())},c=t=>{const e=t.detail;var i;e&&"boolean"==typeof e.enabled&&(i=e.enabled,u(),l.get(a)!==i&&l.set(a,i))},v=()=>(u(),l.get(a)??!0),p=t=>(0,n.S)()?(u(),h.add(t),(0,n.S)()&&!d&&(window.addEventListener(r,c),d=!0),l.subscribe(a,t,{fireImmediately:!1}),()=>{l.unsubscribe(a,t),h.delete(t),h.size||(0,n.S)()&&d&&(window.removeEventListener(r,c),d=!1)}):()=>{}},67689(t,e,i){i.d(e,{h(){return o}});var s=i(2827);function o(){return(0,s.oh)()}},72930(t,e,i){i.d(e,{Z(){return u},B(){return d}});var s=i(22341),o=i(93552),n=i(2171),r=i(40221);function a(t){let e=0;const i=/[\u4e00-\u9fff\u3040-\u30ff\u1100-\u11ff\u3130-\u318f\uac00-\ud7af]/;for(let s=0;s<t.length;s++){const o=t[s];i.test(o)?e+=2:e+=1}return e}const l=(0,n.$U)({1:{templateId:1,enableDefaultCta:!0,fontSizing:[{componentType:r.u.Title,calculateBreakpoint:a,rules:[{lessThan:24,fontSizePx:32,lineHeightPx:40,maxLines:2},{lessThan:50,fontSizePx:28,lineHeightPx:36,maxLines:3},{lessThan:78,fontSizePx:24,lineHeightPx:32,maxLines:4},{lessThan:9999,fontSizePx:20,lineHeightPx:28,maxLines:4}]}],layout:{layoutType:r.b.Row,children:[{componentType:r.u.MainImage},{className:"ad-text-col",children:[{componentType:r.u.LogoProvider},{componentType:r.u.Title},{componentType:r.u.CallToAction},{className:"ad-footer",children:[{componentType:r.u.PopupDisclaimer},{componentType:r.u.AdLabel},{componentType:r.u.AdChoice}]}]}]},subTemplateTypes:{infopane:{cssVariables:{enableBackgroundImage:!0}},"two-square":{isNonImmersive:!0}}},2:{templateId:2,enableDefaultCta:!0,fontSizing:[{componentType:r.u.Title,calculateBreakpoint:a,rules:[{lessThan:24,fontSizePx:28,lineHeightPx:36,maxLines:3},{lessThan:50,fontSizePx:24,lineHeightPx:32,maxLines:4},{lessThan:74,fontSizePx:20,lineHeightPx:28,maxLines:5},{lessThan:9999,fontSizePx:16,lineHeightPx:22,maxLines:6}]}],layout:{layoutType:r.b.Row,children:[{componentType:r.u.MainImage},{className:"ad-text-col",children:[{componentType:r.u.LogoProvider},{componentType:r.u.Title},{componentType:r.u.CallToAction},{className:"ad-footer",children:[{componentType:r.u.PopupDisclaimer},{componentType:r.u.AdLabel},{componentType:r.u.AdChoice}]}]}]},subTemplateTypes:{infopane:{cssVariables:{enableBackgroundImage:!0}},"two-square":{isNonImmersive:!0}}},3:{templateId:3,enableDefaultCta:!0,fontSizing:[{componentType:r.u.Title,calculateBreakpoint:a,rules:[{lessThan:40,fontSizePx:20,lineHeightPx:28,maxLines:4},{lessThan:9999,fontSizePx:16,lineHeightPx:22,maxLines:6}]}],layout:{layoutType:r.b.Row,children:[{componentType:r.u.MainImage},{className:"ad-text-col",children:[{componentType:r.u.LogoProvider},{componentType:r.u.Title},{componentType:r.u.CallToAction},{className:"ad-footer",children:[{componentType:r.u.PopupDisclaimer},{componentType:r.u.AdLabel},{componentType:r.u.AdChoice}]}]}]},subTemplateTypes:{infopane:{cssVariables:{enableBackgroundImage:!0}},"two-square":{isNonImmersive:!0}}},5:{templateId:5,layout:{},passTemplateStyleOverride:!0}});var h=i(87440);function d(t,e,i){if(!t||t<=0)return null;if(null!=i&&i.some(e=>e.templateId===t))return null;const n=l.current[t.toString()];if(!n)return(0,s.vV)(o.o1l,"MissingAdCardDTSConfig",`Not found templateId ${t}. Available: ${Object.keys(l.current).join(",")}`),null;const{subTemplateTypes:r,...a}=n,d=null==r?void 0:r[e||""];return!e||d||a.passTemplateStyleOverride||(0,s.vV)(o.o1l,"MissingAdCardDTSConfig",`Not found subTemplateType ${e} for templateId ${t}. Available: ${Object.keys(r||{}).join(",")}`),(0,h.A)({styleKey:`${t}_${e}`},a,d)}function u(t,e){const i=e.calculateBreakpoint(t),s=e.rules.find(t=>i<t.lessThan);return s?{fontSizePx:s.fontSizePx,lineHeightPx:s.lineHeightPx,maxLines:s.maxLines}:null}},76736(t,e,i){i.d(e,{c(){return o}});var s=i(66038);class o{constructor(t){this.card=t}getCommentCount(t){var e;return(0,s.t)(!1,t,null===(e=this.card)||void 0===e?void 0:e.locale)}}},78222(t,e,i){i.d(e,{NM(){return d},Y(){return h},uE(){return u},ve(){return l}});var s=i(32257),o=i(29222),n=i(74849);const r=n.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]) {
        aspect-ratio: 0.9518;
    }

    :host([size="1u"][ux-mode="billboard"]:not([variant="immersive"])) .image-attribution-container,
    :host([size="1c"][ux-mode="billboard"]:not([variant="immersive"])) .image-attribution-container,
    :host([size="1u"][ux-mode="billboard"]:not([variant="immersive"])) .media,
    :host([size="1c"][ux-mode="billboard"]:not([variant="immersive"])) .media,
    :host([size="1u"][ruby]) .ruby-image-container,
    :host([size="1u"]) .media-container {
        aspect-ratio: 1.875 / 1;
    }

    :host([size="1u"]:not([ux-mode="billboard"])) .media-container {
        margin-bottom: ${s.LbM};
    }

    :host([size="1.5u"]) .attribution, 
    :host([size="1.5u"]) .heading, 
    :host([size="1.5u"]) .insight,
    :host([size="1u"]:not([ruby])) .attribution, 
    :host([size="1u"]:not([ruby])) .heading, 
    :host([size="1u"]:not([ruby])) .insight {
        padding-inline: ${s.hW$};
    }

    :host([size="1u"][ruby]) .text {
        padding-block-start: ${s.LFA};
    }

    :host([size="1.5u"]:not([ruby]):not([ux-mode="billboard"])) .card-actions-button-container,
    :host([size="1u"]:not([ruby]):not([ux-mode="billboard"])) .card-actions-button-container {
        top: calc(${s.ACF} * 2);
        right: calc(${s.ACF} + ${o.UYK});
    }

    :host([size="1u"][ruby]) .card-actions-button-container {
        inset-block-start: calc(${s.ACF} * 2);
        margin-inline-end:  calc(${s.ACF} + ${o.UYK});
    }

    :host([size="1.5u"]) .ruby-social-bar,
    :host([size="1u"]) .ruby-social-bar {
        padding-inline: ${s.LFA};
    }
`,a=n.A`
    ${r}
    
    :host([size="1u"][ux-mode="billboard"]) .root,
    :host([size="1c"][ux-mode="billboard"]) .root {
        gap: ${s.LbM};
    }

    :host([size="1u"][ux-mode="billboard"]) cx-gem-facets-card::part(header),
    :host([size="1c"][ux-mode="billboard"]) cx-gem-facets-card::part(header) {
        margin-block-end: 0;
    }

    :host([size="1u"][ux-mode="billboard"]) cx-gem-facets-card::part(title-container),
    :host([size="1c"][ux-mode="billboard"]) cx-gem-facets-card::part(title-container) {
        gap: 0;
    }

    :host([ux-mode="billboard"]) .card-actions-button-container {
        inset-block-start: calc(${s.ACF} * 2);
        inset-inline-end:  calc(${s.ACF} * 2);
    }
`,l="prg-sm-flex",h=n.A`${r}`,d=(n.A`${a}`,"prg-pr2-sm-flex"),u=n.A`${r}`;n.A`${a}`},79119(t,e,i){i.d(e,{g(){return l}});var s=i(96950),o=i(69259),n=i(58792),r=i(42161);const a=s.qy`<img alt="" aria-hidden="true" src="${(0,n.rA)().StaticsUrl}/latest/fluent-icons/comment_20_regular.svg"></img>`,l=t=>{return s.qy`<button class="comment-button like-card-button" data-t="${(null==t?void 0:t.telemetryTag)||""}" title=${(null==t?void 0:t.commentButtonTooltip)||""} id=${e=(null==t?void 0:t.id)||"",`comment-button-${e}`} @click=${()=>(t=>{if(null==t||!t.destinationUrl)return;const e=(0,r.cc)(t.destinationUrl);window.open(e,"_blank")})(t)}>${a} ${(0,o.z)(Boolean((null==t?void 0:t.commentCount)&&t.renderCount),(t=>{var e,i;return s.qy`<span class="comment-count">${(null==t||null===(e=t.rubyCommentController)||void 0===e||null===(i=e.getCommentCount)||void 0===i?void 0:i.call(e,t.commentCount))||""}</span>`})(t))}</button>`;var e}},87582(t,e,i){var s;function o(t,e,i){return i===s.ltr?t:e}i.d(e,{OP(){return s},jt(){return o}}),function(t){t.ltr="ltr",t.rtl="rtl"}(s||(s={}))},87656(t,e,i){i.d(e,{g(){return o}});var s=i(7813);function o(t){if("string"==typeof t)return t;if("function"==typeof t&&!(t=s.I.getByType(t)))throw new Error("Missing FASTElement definition.");return t.name}},97015(t,e,i){i.d(e,{_Z(){return l},we(){return n},x3(){return a},z7(){return r}});var s=i(6205),o=i(65114);function n(t){const e="An unknown error";if("string"==typeof t)return{value:t};if(!t||"object"!=typeof t)return{value:e};if(!function(t){return Boolean(t&&"object"==typeof t&&"code"in t&&"message"in t)}(t))return{value:e,message:(0,s.M5)(t)};const{value:i,...o}=t;return"object"==typeof i?{value:(0,s.M5)(i),...o}:{value:"string"==typeof i?i:o.message,...o}}const r=(t,e,i)=>{let s=t+i;return s<0?s=0:s>e&&(s=e),s};function a(t){if(!t)return"";const e=new URL(t);return e.searchParams.set("_t",Date.now().toString()),e.searchParams.has("start")||e.searchParams.set("start","0"),e.searchParams.has("end")||e.searchParams.set("end","15"),e.href}function l(t){return t&&Object.values(o.yB).includes(new URL(t).origin)}},97062(t,e,i){i.d(e,{v9(){return f}});var s=i(32257),o=i(35279),n=i(77345),r=i(74849);const a=r.A`
    :host([size="1.5u"]) cx-gem-facets-card[styling-mode="minimal"]::part(title-container),
    :host([size="1u"]) cx-gem-facets-card[styling-mode="minimal"]::part(title-container),
    :host([size="1c"]) cx-gem-facets-card[styling-mode="minimal"]::part(title-container) {
        gap: 0;
    }

    :host([size="1.5u"]) cx-gem-facets-card::part(header),
    :host([size="1c"]) cx-gem-facets-card::part(header),
    :host([size="1u"]) cx-gem-facets-card::part(header) {
        margin-block-end: 0px;
    }

    :host([size="1u"][ux-mode="billboard"]) .root,
    :host([size="1c"][ux-mode="billboard"]) .root {
        gap: ${s.LFA};
    }
`,l=r.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]),
    :host([size="1.5u"]) {
        aspect-ratio: ${o.du.toString()} / ${o.iB.toString()};
    }

    :host([size="2c"][ux-mode="billboard"]),
    :host([size="2c"][ruby]),
    :host([size="2c"]) {
        aspect-ratio: ${o.Mq.toString()} / ${o.iB.toString()};
    }

    :host([size="3c"][ux-mode="billboard"]) {
        aspect-ratio: ${o.Lj.toString()} / ${o.iB.toString()};
    }

    ${a}
`,h=r.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]),
    :host([size="1.5u"]) {
        aspect-ratio: ${o.du.toString()} / ${o.LX.toString()};
    }

    :host([size="2c"][ux-mode="billboard"]),
    :host([size="2c"][ruby]),
    :host([size="2c"]) {
        aspect-ratio: ${o.Mq.toString()} / ${o.LX.toString()};
    }

    :host([size="3c"][ux-mode="billboard"]) {
        aspect-ratio: ${o.Lj.toString()} / ${o.LX.toString()};
    }

    :host([size="1u"]:not([ruby])) .attribution {
        margin-block: calc(${s.fFM} + 2px);
    }

    :host([size="1u"][ruby]) .attribution {
        margin-block: 2px calc(${s.fFM} + 2px);
    }

    .heading {
        padding-block-start: 2px;
    }

    ${a}
`,d=r.A`
    :host([size="1u"][ux-mode="billboard"]),
    :host([size="1c"][ux-mode="billboard"]),
    :host([size="1u"][ruby]),
    :host([size="1u"]),
    :host([size="1.5u"]) {
        aspect-ratio: ${o.du.toString()} / ${o.Gm.toString()};
    }

    :host([size="2c"][ux-mode="billboard"]),
    :host([size="2c"][ruby]),
    :host([size="2c"]) {
        aspect-ratio: ${o.Mq.toString()} / ${o.Gm.toString()};
    }

    :host([size="3c"][ux-mode="billboard"]) {
        aspect-ratio: ${o.Lj.toString()} / ${o.Gm.toString()};
    }
        
    ${a}
`,u=r.A`${l}`,c=r.A`${h}`,v=r.A`${d}`,p=r.A`${l}`,m=r.A`${h}`,g=r.A`${d}`,f=r.A`
`.withBehaviors(new n.P("prg-dense-t1",u),new n.P("prg-dense-t2",c),new n.P("prg-dense-t3",v),new n.P("prg-pr2-dense-t1",p),new n.P("prg-pr2-dense-t2",m),new n.P("prg-pr2-dense-t3",g))},99691(t,e,i){i.d(e,{C(){return c},t(){return u}});var s=i(56911),o=i(60815),n=i(57702),r=i(17857),a=i(48535),l=i(58792),h=i(15525),d=i(66038);const u="dislikeButtonClicked";class c{get showMoreFewerCardMetadata(){return this.card.previewType&&this.card.locale?{useVoteActions:!0,useCommunityReactions:!0,...this.card.previewType&&{previewType:this.card.previewType},locale:this.card.locale}:this.card.useVoteActions?{useVoteActions:!0,...this.card.previewType&&{previewType:this.card.previewType}}:{useCommunityReactions:!0,locale:this.card.locale}}constructor(t){var e,i;this.showFewerButtonSelected=!1,this.disableShowTooltip=!1,this.card=t;const{id:s="",disableShowTooltip:o}=t;this.disableShowTooltip=!!o;const a=`myReaction_${null===l.T3||void 0===l.T3?void 0:l.T3.UserId}_${s}_${null===l.T3||void 0===l.T3?void 0:l.T3.CurrentMarket}`;this.showFewerButtonSelected="dislike"===(null===h.Lg||void 0===h.Lg||null===(e=(0,h.Lg)())||void 0===e||null===(i=e.getItem)||void 0===i?void 0:i.call(e,a)),this.removeShowMoreFewerStatusListener=n.Pi.registerShowMoreFewerStatusListener(t=>{let{contentId:e,value:i}=t;e===this.card.id&&(this.showFewerButtonSelected=!!(i&&(i&r.J.showFewer)>0))})}dispose(){var t;null===(t=this.removeShowMoreFewerStatusListener)||void 0===t||t.call(this)}toggleShowFewer(t,e){var i;const s=null===(i=this.card)||void 0===i?void 0:i.id;if(!s)return;const o={targetId:s,metadata:this.showMoreFewerCardMetadata,targetType:this.card.targetType,getTargetElement(){var e;return null===(e=t.shadowRoot)||void 0===e?void 0:e.querySelector(`#${(0,a.v)(s)}`)},isDisliked:!this.showFewerButtonSelected,isMouseClick:e,disableShowTooltip:this.disableShowTooltip};document.dispatchEvent(new CustomEvent(u,{bubbles:!0,detail:o}))}getDownvoteCount(t){var e;return(0,d.t)(this.showFewerButtonSelected,t,null===(e=this.card)||void 0===e?void 0:e.locale)}}(0,s.Cg)([o.sH],c.prototype,"showFewerButtonSelected",void 0)}}]);