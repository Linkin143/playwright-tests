"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-marchmadness"],{4968(e,t,i){i.d(t,{f(){return l}});var a=i(64187),n=i(74849),o=i(42792),r=i(99657),s=i(36452);const l=n.A.partial`position: relative; z-index: ${r.D};`;n.A`
    ${o.e}
    ${o.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},10500(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},36516(e,t){t.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},42792(e,t,i){i.d(t,{R7(){return u},e(){return g},kc(){return v},nH(){return h}});var a=i(57416),n=i(55153),o=i(95239),r=i(26920),s=i(48751),l=i(64187),d=i(22131),c=i(74849),p=i(50882);const h=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,g=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${r.XA} * 1px) solid ${n.cu};
        border-radius: calc((${a.JU} - ${r.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${r.XA} * 1px) ${n.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${r.XA} * 1px) ${n.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${r.XA} * 1px) ${n.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${n.QG} * 1px);
        height: calc(${n.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${n.QG} * 1px);
        height: calc((${n.l8} * 2px) + (${n.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${n.QG} * 2px) + (${n.Sn} * 1px));
        height: calc((${n.l8} * 2px) + (${n.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${n.QG} * 2px) + (${n.Sn} * 1px));
        height: calc(${n.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,v=(0,d.mr)(c.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),u=c.A`
    ${g}
    ${h}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(v)},58911(e,t,i){i.r(t),i.d(t,{SportsMarchmadnessTransformer(){return v},SportsMatchTransformer(){return u.SportsMatchTransformer}});var a=i(49150),n=i(23587),o=i(50180);const r="Match",s="Quarterfinal",l="SemiFinal",d="Championship",c="Champion",p=e=>{const t=e?"AA1dH5oj":"AA1dH0n8";return(0,o.GP)("https://img-s-msn-com.akamaized.net/tenant/amp/entityid/{0}.img?w={1}&h={2}&q=60&m=6&f=png&u=t",t,"28","30")};var h=i(79811),g=i(96950);class v extends n.Bc{constructor(){super(...arguments),this.getMediumCardMatchCount=()=>{switch(this.uxType){case d:case c:return 1;case l:case s:return 2;default:return 3}},this.getBigCardMatchCount=()=>{switch(this.uxType){case d:case c:return 1;case l:return 2;case s:return 4;default:return 5}},this.getShowMatchCount=()=>{switch(this.cardSize){case a.uE._1x_2y:return this.getMediumCardMatchCount();case a.uE._1x_3y:return this.getBigCardMatchCount();default:return 1}}}async transform(e){const t=await this.getViewModel(e);return{viewTemplate:g.qy`
                <sports-marchmadness
                    :viewModel="${t}"
                ></sports-marchmadness>`}}async getViewModel(e){this.cardSize=e.cardSize;const t=e.matchData[0].sportsMatchData;"string"!=typeof t.gameState&&(t.gameStateCatetory=(0,h.m5)(t.gameState.state));const i=t.gameStateCatetory,a=i===n.Xp.postGame,{bracketPhase:o,league:g}=e.tabContent||{};this.uxType=((e,t)=>{const{league:i}=t||{};return i&&i.contentHeaderLine1&&i.shouldShowContentHeaderImage?i.headerImage?l:s:i&&i.contentHeaderLine1?e===n.Xp.postGame?c:d:r})(i,e.tabContent);const v=(0,h.jJ)(),u=this.getHeaderImage(g.headerImage,a),m=await this.getMatchViews(e);return{bracketIconUrl:p(v),bracketPhase:o,cardSize:this.cardSize,headerImage:u,isPostGame:a,matchClickthroughUrl:this.getMatchClickthroughUrl(t,g),headerLine1:g.contentHeaderLine1,headerLine2:g.contentHeaderLine2,matchViews:m,uxType:this.uxType,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:n.BP.MarchMadnessCard})}}async getMatchViews(e){var t;if(!e.matchData)return;const i=e.followedSports||new Map,a=this.getShowMatchCount(),o=e.matchData.slice(0,a),r=(0,h.Yo)(o),s=this.uxType===d||this.uxType===c,l=null===(t=e.tabContent)||void 0===t||null===(t=t.league)||void 0===t?void 0:t.clickThroughUrl,p=o.map(async t=>{const a=t.sportsMatchData;s&&l&&(a.gameCenterUrl=l);const o=(0,h.gK)(a.participantOne,i),d=(0,h.gK)(a.participantTwo,i),c={matchData:t,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants,participantOneFollowed:o,participantTwoFollowed:d,topDetailText:a.matchHeader,isContainLiveMatch:r,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores};return this.transformerProvider.generateView(c,n.hi.SportsMatch)});return(await Promise.all(p)).filter(h.z2)}getIconInfo(e){const t=this.cardSize===a.uE._1x_3y;return e?{width:t?108:70,height:t?108:70}:t?{height:108,width:153}:{height:80,width:114}}getHeaderImage(e,t){if(!e)return"";const i=this.getIconInfo(t);return(0,h.iK)(e,!1,i)}getMatchClickthroughUrl(e,t){return(this.uxType===d||this.uxType===c)&&null!=t&&t.clickThroughUrl?(0,h.Ot)(t.clickThroughUrl):e.matchClickthroughUrl||""}}var u=i(82724);Promise.resolve().then(i.bind(i,83549)),Promise.resolve().then(i.bind(i,76435))},76435(e,t,i){i.r(t),i.d(t,{SportsMatch(){return re}});var a=i(56911),n=i(54229),o=i(84564);class r extends o.z{constructor(){super(...arguments),this.getMatchData=()=>this.viewModel.matchData.sportsMatchData,this.isVertical=()=>null!=this.viewModel&&this.viewModel.isVertical,this.isCopilotTheme=()=>null!=this.viewModel&&this.viewModel.isCopilotTheme}get isWindowsCopilot(){return null!=this.viewModel&&this.viewModel.isWindows&&this.viewModel.isCopilotTheme}handleClickFollowIcon(e,t,i,a){if(e&&e.currentTarget){e.preventDefault(),e.stopPropagation();const o="keydown"===e.type||"keypress"===e.type||"keyup"===e.type;(0,n.LE)(e.currentTarget,o,t),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,t,a)}}}var s=i(92011),l=i(48751),d=i(62047),c=i(61138),p=i(41123),h=i(71157),g=i(62198),v=i(4283),u=i(4968),m=i(12640),x=i(50882),f=i(74849),$=i(4126),w=i(22131);const b="#CD3800",y="#E98F6D",k=f.A` .date,.nodate{width:auto}`,z=f.A` :host{--line-color:rgba(61,61,61,1);--header-color-live:rgba(255,153,164,1);--ruby-live-text-bg:rgba(9,102,32,0.2);--ruby-live-text-color:rgba(108,197,123,1)}.winner-tag path{fill:#FFFFFF}.detail-live-animation{background:${y}}.game-in-progress-text{color:${y}}.side-by-side-hover-canvas:hover{background:rgba(0,0,0,0.6)}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#1A1A1A}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.live-line{border-top:1px solid ${y};
        background-color: ${y}}.standings-style{color:${l.l}}:host-context([is-ruby-feed-card]) .matchup-neutral-background{border:1px solid #5A5E63}.kcntr .post-game .kscr:not(.winner-team){color:var(--smtc-foreground-ctrl-neutral-primary-pressed,#A4ADC8)}`,F=f.A` :host{--header-color-live:#C42B1C;--standings-color:#707070;--line-color:#F2F2F2;--kumo-live-bg:rgba(171,47,64,1);--kumo-live-text:rgba(255,255,255,1);--ruby-live-text-bg:#94DC7F33;--ruby-live-text-color:rgba(0,127,48,1)}.sports-match{padding:4px 0;text-decoration:none;display:grid;row-gap:14px;border-radius:6px;height:58px;${u.f}}.sports-match.reason{padding:1px 0}.sports-match.superbowl-half-u{padding:6px 16px;height:auto}.sports-match:focus-visible{outline:${l.l} solid 2px;outline-offset:-2px}.side-by-side-matchup-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;border-radius:6px}.superbowl-half-u .side-by-side-matchup-content{padding:0}.matchup-neutral-background{border-radius:6px;background:var(--sports-item-background)}.matchup-neutral-background.no-bg{background:rgba(0,0,0,0)}.matchup-neutral-background:hover,.matchup-neutral-background:focus-visible{background:var(--sports-item-hover-background)}.matchup-neutral-background:active{background:var(--sports-item-active-background)}.side-by-side-gradient-container{height:45px;width:100%;border-radius:6px 6px 0px 0px;position:absolute}.reason .side-by-side-gradient-container{height:40px}.side-by-side-hover-canvas{display:flex;justify-content:center;align-items:center;position:absolute;width:100%;height:100%;z-index:3;font-size:14px;font-weight:bolder;background:rgba(255,255,255,0);color:rgba(0,0,0,0);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.side-by-side-hover-canvas:hover{border-radius:6px;border:1.6px solid #6581CA;background:rgba(255,255,255,0.85);color:${l.l}}.video-indicator{display:none}.middle-game-detail{display:flex;flex-direction:row;justify-content:space-around;color:${l.l};font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center}.middle-notification-game-detail{align-items:center}.bottom-game-detail{color:${l.l};
        font-size: ${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:100px}.bottom-notification-container{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;max-height:28px;text-align:center;max-width:108px}.bottom-notification-container.pregame{white-space:normal}.notification-message{display:block;max-width:108px;font-weight:400;color:${l.l}}.underline-text{text-decoration:underline}.superbowl-1-u .bottom-game-detail,.superbowl-half-u .bottom-game-detail{color:${l.l}}.foreground-rest-text-color{color:${l.l}}.top-game-detail{color:${l.l};
        font-size: ${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:140px}.finals-match .top-game-detail,.finals-match .bottom-game-detail{color:${l.l}}.super-bowl{font-weight:700;text-transform:uppercase;color:${l.l}}.game-details{display:flex;flex-direction:column;align-items:center;width:100px;overflow:hidden}.side-by-side-matchup-content:hover .game-details-wrapper .game-details{display:none}.side-by-side-matchup-content:hover .game-details-wrapper .game-details-additional-info{display:flex}.game-details-additional-info{display:none;flex-direction:column;align-items:center;justify-content:center;width:100px}.game-details-additional-info .round-info,.game-details-additional-info .round-scores-info{font-size:${c.k};
        line-height: ${c.F};
        color: ${l.l};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-details-additional-info .round-summary-info{font-size:${p.K};
        line-height: ${p.Z};
        font-weight: 600;
        color: ${l.l};max-width:110px;white-space:nowrap;overflow:hidden}.participant-container{display:flex;align-items:center;flex-direction:column;width:84px;color:${l.l};z-index:0}.spotlight-two .participant-container{width:64px}.participant-container img{width:36px;height:36px}.participant-icon{display:flex;border:none;cursor:pointer;width:36px;height:36px;border-radius:8px;align-items:center;justify-content:center;background:transparent}.participant-icon.participant-icon-large{width:70px;height:50px}.participant-container .logo-backplate.participant-icon-large img{width:40px;height:40px}.participant-icon.logo-backplate{border-radius:8px;width:40px;height:40px;img{width:28px;height:28px}}.side-by-side-matchup-content .follow-icon{opacity:0;pointer-events:none;margin-right:-20px;margin-top:-16px}.side-by-side-matchup-content:hover .follow-icon{opacity:1;pointer-events:all}.follow-icon:focus-visible,.sports-match:focus-visible .follow-icon{opacity:1;pointer-events:all}.spotlight-two .right-participant .follow-icon{position:relative;left:-18px}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.game-in-progress-text{color:${b};
        font-size: ${c.k};
        line-height: ${c.F};font-weight:400}.live-scores-detail .game-in-progress-text{border-top:1px solid ${b};
        font-size: ${d.t}}.participant-name-style{font-size:${c.k};
        line-height: ${c.F};max-width:64px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:600}.game-time-text-style{font-size:${h.T};
        line-height: ${h.O};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-time-notification-text-style{font-size:${c.k};
        line-height: ${c.F};max-width:100px}.game-score-notification-text-style{font-size:${h.T};
        line-height: ${h.O}}.game-score-text-style{color:${l.l};
        line-height: ${h.O};
        font-size: ${g.a};margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;font-weight:600}.long-score{font-size:var(--type-ramp-minus-1-font-size,12px)}.long-score .game-score-text-style{font-size:var(--type-ramp-minus-1-font-size,12px);margin:0px 2px}.detail-live-animation{height:2px;background:${b};transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate}@keyframes liveAnimation{0%{width:50px}100%{width:2px}}.video-detail,.top-detail{display:flex;align-items:center;height:14px;margin-bottom:-4px}.top-detail{max-height:40px}.video-detail > span{height:14px;color:${l.l};
        font-size: ${d.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:64px}.top-detail > span{font-size:${d.t};
        line-height: ${d.e};
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        color: ${l.l}}.game-winner-team,.game-winner-description{text-align:center;font-size:${p.K};
        line-height: ${p.Z};
        font-weight: 900;
        color: ${l.l};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-family:Arial,Segoe,sans-serif}.game-winner-description{margin-top:-4px}.click-for-detail{display:inline-block;background:rgb(196 43 28);color:rgb(255,255,255);font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-font-size);height:15px;padding:2px 5px;margin:3px;border-radius:4px;font-weight:600;animation:3s ease 0s infinite normal none running gradbg;-webkit-animation:3s ease 0s infinite normal none running gradbg;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}@keyframes gradbg{0%{background-position:10% 0%}50%{background-position:91% 100%}100%{background-position:10% 0%}}.detail-live-score{font-size:${c.k};
        line-height: ${c.F};
        font-weight: 600;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        color: ${v.IR};text-decoration:none}.detail-live-score:hover,.detail-live-score:focus-visible{text-decoration:underline;cursor:pointer}.winner-tag > svg{fill:currentColor;display:block;margin:0 auto}.rtl.winner-tag > svg{transform:scaleX(-1)}.winner-tag.scale-x{transform:scaleX(-1)}.game-time-dot-seperator{margin:0 4px}.live-line{border:none;border-top:1px solid ${b};
        width: 16px;
        height: 0;
        left: 126px;
        top: 20px;
        position: absolute;
        background-color: ${b}}.vert-header,.line-part div:nth-of-type(2),.in-prog-vert,.game-date{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal}.vert-noline,.matchup-vert{display:flex;flex-direction:column;align-items:flex-start}.vert-noline{gap:8px;align-self:stretch;border-radius:8px}.vert-header{font-weight:600;color:${l.l}}.matchup-vert{gap:12px;align-self:stretch}.part-vert,.part-info{display:flex;align-items:center}.part-vert{justify-content:space-between;align-self:stretch}.part-info{width:90%;gap:10px}.icon-vert{width:32px;height:32px;flex-shrink:0}.icon-vert img{max-width:100%;max-height:100%;width:auto;height:auto}.name,.score,.line-part div:nth-of-type(2),.game-date > div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.name,.score{font-size:var(--type-ramp-plus-2-font-size,20px);font-style:normal;font-weight:600;line-height:var(--type-ramp-plus-2-line-height,28px);color:${l.l}}.in-prog-vert{color:var(--header-color-live);font-weight:600}.standings-style{color:var(--standings-color);text-align:right;font-size:var(--type-ramp-base-font-size,14px);font-style:normal;font-weight:400;line-height:var(--type-ramp-base-line-height,20px)}.line-match{display:flex;flex-direction:row;align-items:center;padding:0px;gap:12px;width:100%;height:auto}.line-match > div:first-child{display:flex;flex-direction:row;align-items:flex-start;padding:0px;gap:4px;width:168px}.line-wrap{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;padding:0px;gap:8px;width:168px;height:auto}.line-part{display:flex;flex-direction:row;align-items:center;padding:0px;gap:6px;width:100%}.line-part div:nth-of-type(2){font-weight:400}.line-icon{width:24px;height:24px;flex-shrink:0}.line-icon img{max-width:100%;max-height:100%;width:auto;height:auto}.game-date{font-weight:400;text-align:center;width:68px}.vert-line{width:0px;height:50px;border:1px solid var(--line-color)}.kpart{width:48px;height:74px;gap:4px;align-items:center}.kmtch,.kscr-cntr,.kscr{display:flex;flex-direction:row}.nodate,.date,.kpart{display:flex;flex-direction:column}.kmtch{width:260px;height:74px;gap:0;justify-content:space-between;align-items:center;color:${l.l}}.kicon{width:40px;height:40px;img{width:40px;height:40px}}.kname,.pghdr,.prehdr{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.kname{max-height:24px;max-width:65px;font-weight:600;line-height:24px;font-size:var(--type-ramp-plus-1-font-size,16px);text-align:left}.long-name{max-width:72px;font-size:var(--type-ramp-base-font-size,14px)}.kscr-cntr{justify-content:space-around;font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center;gap:6px;margin-bottom:8px}.kscr{font-weight:600;text-align:center;line-height:var(--type-ramp-plus-4-line-height);font-size:var(--type-ramp-plus-5-font-size);margin:0px 4px;align-items:center;column-gap:4px;gap:6px;font-variant-ligatures:none}.ktime{font-weight:600;text-align:center;font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px);margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;margin-bottom:8px}.nodate{align-items:center;gap:4px;width:148px}.date{align-items:center;gap:4px;width:148px}.pghdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.prehdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.kcntr{text-decoration:none;${u.f}}.kcntr:focus-visible{outline-offset:-1px}.kmtch{padding:12px 0}:host(:first-of-type) :not(.kcntr) .kmtch{padding-top:0}:host(:last-of-type) :not(.kcntr) .kmtch{padding-bottom:0}.g-dtl{display:flex;flex-direction:column;gap:2px;align-items:center}:host-context(.sports-match-list) .kscr{font-size:var(--type-ramp-plus-3-font-size)}:host-context(.sports-match-list) .kcntr .kscr{font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px)}._05u .nodate,._05u .date,._05u .kpart{gap:8px}._05u.kcntr .kmtch{height:98px}.kmtch{padding:7px 0px;width:100%;height:78px;box-sizing:border-box;color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.kname{font-size:var(--smtc-text-global-body2-font-size,15px);line-height:var(--smtc-text-global-body2-line-height,20px)}.r-live-text{font-weight:400;font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);color:var(--ruby-live-text-color,rgba(0,127,48,1));font-weight:600;text-transform:uppercase}.post-game .kscr:not(.winner-team){color:var(--smtc-theme-color-foreground-secondary-650,#4c4642)}.kscr-cntr{display:grid;grid-template-columns:1fr min-content 1fr}.kscr-cntr .part-left{justify-content:end}.kpart{height:auto}.r-live-tag{background:var(--ruby-live-text-bg,rgba(237,246,232,1));border-radius:8px;padding:6px;display:grid;grid-template-columns:auto auto;gap:4px}.r-live-icon{width:20px;height:20px;margin:-2px}.kcntr .winner-tag > svg{width:10px;height:10px}.kcntr .winner-tag svg path{fill:currentColor}`.withBehaviors(new m.N(null,z),(0,w.mr)(f.A` :host{forced-color-adjust:auto}@media screen and (-ms-high-contrast:active){.super-bowl,.participant-container,.top-game-detail,.middle-game-detail,.bottom-game-detail,.top-detail > span,.game-score-text-style,.game-in-progress-text,.video-detail,.game-winner-description{color:${x.A.CanvasText}}.icon-add > svg > g > path,.icon-selected > svg > path{fill:${x.A.LinkText}}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#000000;stroke:${x.A.LinkText}}.click-for-detail{border:1px solid;background-color:${x.A.LinkText}}.detail-live-animation{background-color:${x.A.LinkText}}.scores-line{overflow:hidden}}`),new $.o("isWindowsCopilot",!0,k));var T=i(23587),C=i(50180),_=i(96950),S=i(69259),M=i(36516),I=i(10500),j='<svg width="6" height="7" viewBox="0 0 6 7" fill="none"><path d="M.38 2.82a.8.8 0 0 0 0 1.36l4.5 2.71c.5.3 1.12-.07 1.12-.67V.78c0-.6-.63-.98-1.13-.67L.38 2.82Z" fill="#1A1A1A"/></svg>';const A=(e,t)=>_.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${i=>(0,C.GP)(t?i.viewModel.strings.followSports||"":i.viewModel.strings.haveFollowed||"",e.name||"")}"
        @click="${(i,a)=>i.handleClickFollowIcon(a.event,t,{id:e.satoriId||"",name:e.name,yId:e.yId||"",type:T.XR.Team,imageUrl:e.imageUrl},e.scheduleUrl||"")}"
        @keyup="${(i,a)=>a&&a.event&&"Enter"===a.event.key?i.handleClickFollowIcon(a.event,t,{id:e.satoriId||"",name:e.name,yId:e.yId||"",type:T.XR.Team,imageUrl:e.imageUrl},e.scheduleUrl||""):null}"
        data-t="${e=>{var t;return null===(t=e.viewModel)||void 0===t?void 0:t.followTelemetryTag}}"
    >
        <div class="${e=>t?"icon-add":"icon-selected"}"> ${_.qy.partial(t?M.A:I.A)}</div>
    </div>
`,D=_.qy`
    <div class="game-details">
        ${_.qy`<div class="top-game-detail">${e=>e.viewModel.topDetailText}</div>`}
        ${e=>function(e,t){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,a=arguments.length>3&&void 0!==arguments[3]?arguments[3]:null;switch(e.getMatchData().gameStateCatetory){case T.Xp.preGame:return null==i?J():K(i);case T.Xp.inprogressGame:return ae();case T.Xp.postGame:return t?ie():(0,C.oT)(e.viewModel.topDetailText)?ee(a||""):te();default:return J()}}(e,e.viewModel.shouldShowChampionPostGame,e.viewModel.preGameNotificationMessage,e.viewModel.postGameNotificationMessage)}
    </div>
`,L=_.qy`
    <div class="${e=>e.getMatchData().additionalInfo?"game-details-wrapper":""}">
        ${D}
        ${e=>O(e.getMatchData().additionalInfo)}
    </div>
`,V=()=>_.qy`
    <div class="g-dtl ${e=>e.getMatchData().gameStateCatetory}">
        <div class="nodate">
            ${e=>e.getMatchData().gameStateCatetory===T.Xp.inprogressGame?P:""}
            ${e=>e.getMatchData().gameStateCatetory===T.Xp.postGame?B:""}
            <div class="kscr-cntr">
                <span class="kscr ${e=>{var t;return null!==(t=e.getMatchData().participantOne)&&void 0!==t&&t.isWinner?"winner-team":""}} part-left">
                    ${(0,S.z)(e=>{var t;return null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.isWinner},_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${_.qy.partial(j)}</span>`)}
                    ${e=>{var t;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.score)??""}}
                </span>
                ${e=>{var t,i;return(0,C.oT)((null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.score)||"")||(0,C.oT)((null===(i=e.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":U}}
                <span class="kscr ${e=>{var t;return null!==(t=e.getMatchData().participantTwo)&&void 0!==t&&t.isWinner?"winner-team":""}}">
                    ${e=>{var t;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.score)??""}}
                    ${(0,S.z)(e=>{var t;return null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.isWinner},_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${_.qy.partial(j)}</span>`)}
                </span>
            </div>
        </div>
    </div>
`,H=()=>_.qy`
    <div class="date">
        <div class="prehdr">${e=>{var t;return null===(t=e.viewModel.headerText)||void 0===t?void 0:t.rightHeaderText}}</div>
        <div class="ktime">${e=>e.getMatchData().gameStartTime}</div>
    </div>
`,O=e=>e?_.qy`
            <div class="game-details-additional-info">
                <div class="round-info">
                    ${e.round||""}
                </div>
                <div class="round-summary-info">
                    ${e.roundSummary||""}
                </div>
                <div class="round-scores-info">
                    ${e.scores}
                </div>
            </div>
        `:null,U=_.qy`
    <span class="scores-line">${_.qy.partial(T.Z5)}</span>
`,q=_.qy`
    <span>${_.qy.partial("·")}</span>
`,P=_.qy`
    <div class="r-live-tag">
        <img class= "r-live-icon" src="${e=>e.viewModel.liveIconUrl}" />
        <span class="r-live-text">${T.T0.Live}</span>
    </div>
`,B=_.qy`
    <div class="pghdr">
        <span>${T.T0.Final}</span>
        ${e=>e.getMatchData().gameDate?q:""}
        <span>${e=>e.getMatchData().gameDate}</span>
    </div>
`,G=_.qy`
    <div class="vert-noline">
        <div class="vert-header ${e=>e.getMatchData().gameStateCatetory===T.Xp.inprogressGame?"in-prog-vert":""}">
            ${e=>{var t;return null===(t=e.viewModel.headerText)||void 0===t?void 0:t.header}}
        </div>
        <div class="matchup-vert">
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${e=>{var t;return null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.name}}">
                        ${e=>{var t;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.name)||""}}
                    </div>
                </div>
                <div class="score ${e=>e.getMatchData().gameStateCatetory===T.Xp.preGame?"standings-style":""}">${e=>{var t;return null===(t=e.viewModel.headerText)||void 0===t?void 0:t.topScoreText}}</div>
            </div>
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${e=>{var t;return null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.name}}">
                        ${e=>{var t;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.name)||""}}
                    </div>
                </div>
                <div class="score ${e=>e.getMatchData().gameStateCatetory===T.Xp.preGame?"standings-style":""}">${e=>{var t;return null===(t=e.viewModel.headerText)||void 0===t?void 0:t.bottomScoreText}}</div>
            </div>
        </div>
    </div>
`,N=_.qy`
    <div class="line-match">
        <div>
            <div class="line-wrap">
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${e=>{var t;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.name)||""}}
                    </div>
                </div>
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${e=>e.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${e=>{var t;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.name)||""}}
                    </div>
                </div>
            </div>
            <div class="vert-line"></div>
        </div>
        <div class="game-date">
            <div>${e=>{var t;return null===(t=e.viewModel.headerText)||void 0===t?void 0:t.leftHeaderText}}</div>
            <div>${e=>{var t;return null===(t=e.viewModel.headerText)||void 0===t?void 0:t.rightHeaderText}}</div>
        </div>
    </div>
`,E=_.qy`
    ${e=>e.viewModel.isSpotlightCard?W:Z}
`,X=_.qy`
    <div class="kmtch">
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${e=>e.viewModel.participantOneImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${e=>{var t;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.name)||""}}"
                />
            </div>
            <div class="kname ${e=>{var t,i;return null!==(t=e.getMatchData().participantOne)&&void 0!==t&&t.shortName||null===(i=e.getMatchData().participantOne)||void 0===i||!i.name?"":"long-name"}}" title="${e=>{var t;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.name)||""}}">
                ${e=>{var t,i;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.shortName)||(null===(i=e.getMatchData().participantOne)||void 0===i?void 0:i.name)||""}}
            </div>
        </div>
        ${e=>(e=>e.getMatchData().gameStateCatetory===T.Xp.inprogressGame||e.getMatchData().gameStateCatetory===T.Xp.postGame?V():H())(e)}
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${e=>e.viewModel.participantTwoImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${e=>{var t;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.name)||""}}"
                />
            </div>
            <div class="kname ${e=>{var t,i;return null!==(t=e.getMatchData().participantTwo)&&void 0!==t&&t.shortName||null===(i=e.getMatchData().participantTwo)||void 0===i||!i.name?"":"long-name"}}" title="${e=>{var t;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.name)||""}}">
                ${e=>{var t,i;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.shortName)||(null===(i=e.getMatchData().participantTwo)||void 0===i?void 0:i.name)||""}}
            </div>
        </div>
    </div>
`,Z=_.qy`
    <a class="kcntr ${e=>"0.5u"===e.viewModel.cardSize?"_05u":""}"
        tabindex="${e=>e.viewModel.tabIndex}"
        href="${e=>e.getMatchData().matchClickthroughUrl?e.getMatchData().matchClickthroughUrl:void 0}"
        target="${e=>e.viewModel.linkTarget}"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        ${X}
    </a>
`,W=_.qy`
    <div class="kcntr ${e=>"0.5u"===e.viewModel.cardSize?"_05u":""}">
        ${X}
    </div>
`,Q=_.qy`
    ${e=>e.viewModel.needsVerticalLine?N:G}
`,R=_.qy`
    <a class="
        sports-match matchup-neutral-background
        ${e=>e.viewModel.noBackgrounds?"no-bg":""}
        ${e=>e.viewModel.reason.length>0?"reason":""}
        ${e=>e.viewModel.isSpotlight2Card?"spotlight-two":""}
    "
        tabindex="${e=>e.viewModel.tabIndex}"
        href="${e=>e.getMatchData().matchClickthroughUrl?e.getMatchData().matchClickthroughUrl:void 0}"
        target="${e=>e.viewModel.linkTarget}"
        data-t="${e=>e.viewModel.telemetryTag}"
    >
        <div role="presentation" class="side-by-side-gradient-container" style="${e=>`background-image: ${e.viewModel.backgroundGradient};`}"></div>
        <div class="side-by-side-matchup-content" style="${e=>e.viewModel.overrideStyleForMatch} ${e=>e.viewModel.matchupContentNotificationStyleIfNecessary}">
            <div class="participant-container ${e=>e.viewModel.shouldDisplayT4?"":" participant-one-alignment"}">
                <div class="participant-icon ${e=>e.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${e=>e.viewModel.showMatchUXV2?"logo-backplate":""}" style="${e=>`background-color: ${e.viewModel.participantOneColor};`}">
                    <img
                        role="presentation"
                        src="${e=>e.viewModel.participantOneImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${e=>A(e.getMatchData().participantOne||{},!e.viewModel.participantOneFollowed)}
                </div>
                <div class="participant-name-style" title="${e=>{var t;return null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.name}}">
                    ${e=>{var t;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.name)||""}}
                </div>
            </div>
            ${L}
            <div class="participant-container right-participant ${e=>e.viewModel.shouldDisplayT4?"":" participant-two-alignment"}">
                <div class="participant-icon ${e=>e.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${e=>e.viewModel.showMatchUXV2?"logo-backplate":""}" style="${e=>`background-color: ${e.viewModel.participantTwoColor};`}">
                    ${(0,S.z)(e=>e.viewModel.isSpotlight2Card,_.qy`${e=>A(e.getMatchData().participantTwo||{},!e.viewModel.participantTwoFollowed)}`)}
                    <img
                        role="presentation"
                        src="${e=>e.viewModel.participantTwoImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${(0,S.z)(e=>!e.viewModel.isSpotlight2Card,_.qy`${e=>A(e.getMatchData().participantTwo||{},!e.viewModel.participantTwoFollowed)}`)}
                </div>
                <div class="participant-name-style" title="${e=>{var t;return null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.name}}">
                    ${e=>{var t;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.name)||""}}
                </div>
            </div>
        </div>
    </a>
`,J=()=>_.qy`
    <div class="middle-game-detail" title="${e=>e.getMatchData().gameStartTime}">
        <span class="game-time-text-style" >
            ${e=>e.getMatchData().gameStartTime||""}
        </span>
    </div>
    <div class="bottom-game-detail ${e=>e.viewModel.shouldDisplayT4?"":"foreground-rest-text-color"}" title="${e=>e.getMatchData().tvChannel?`${e.getMatchData().gameDate} - ${e.getMatchData().tvChannel}`:e.getMatchData().gameDate}">
        <span>${e=>e.getMatchData().gameDate||""}</span>
            ${e=>e.getMatchData().tvChannel&&e.getMatchData().gameDate?U:""}
        <span>${e=>e.getMatchData().tvChannel||""}</span>
    </div>
`,K=e=>_.qy`
    <div class="middle-game-detail" title="${e=>e.getMatchData().gameStartTime+"-"+e.getMatchData().gameDate}">
        <span class="game-time-text-style game-time-notification-text-style">
            ${e=>`${e.getMatchData().gameStartTime||""}`}
        </span>
        <span class="game-time-text-style game-time-notification-text-style game-time-dot-seperator">
            ${e=>""+(e.getMatchData().gameStartTime?"·":"")}
        </span>
        <span class="game-time-text-style game-time-notification-text-style">
            ${e=>`${e.getMatchData().gameDate}`}
        </span>
    </div>
    <div class="${"bottom-game-detail bottom-notification-container pregame"}" title="${e}">
        <span class=${e=>e.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
            ${e}
        </span>
    </div>
`,Y=()=>_.qy`
    <div class="middle-game-detail ${e=>e.viewModel.hasLongScore?"long-score":""}">
        <span class="game-score-text-style">
            ${(0,S.z)(e=>{var t;return null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.isWinner},_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${_.qy.partial(j)}</span>`)}
            ${e=>{var t;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.score)??""}}
        </span>
        ${e=>{var t,i;return(0,C.oT)((null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.score)||"")||(0,C.oT)((null===(i=e.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":U}}
        <span class="game-score-text-style">
            ${e=>{var t;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.score)??""}}
            ${(0,S.z)(e=>{var t;return null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.isWinner},_.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${_.qy.partial(j)}</span>`)}
        </span>
    </div>
`,ee=e=>_.qy`
    <div class="top-game-detail"
        title="${e=>e.getMatchData().gameState?`${e.getMatchData().gameDate} - ${e.getMatchData().gameState}`:e.getMatchData().gameDate}">
        <span>${e=>e.getMatchData().gameState||""}</span>
        ${e=>e.getMatchData().gameDate&&e.getMatchData().gameState?q:""}
        <span>${e=>e.getMatchData().gameDate||""}</span>
    </div>
    ${Y()}
    ${(0,S.z)(!(0,C.oT)(e),_.qy`
        <div class="${"bottom-game-detail bottom-notification-container"}" title="${e}">
            <span class=${e=>e.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
                ${e}
            </span>
        </div>
    `)}
`,te=()=>_.qy`
    ${Y()}
    <div class="bottom-game-detail"
        title="${e=>e.getMatchData().gameState?`${e.getMatchData().gameDate} - ${e.getMatchData().gameState}`:e.getMatchData().gameDate}">
        <span>${e=>e.getMatchData().gameState||""}</span>
        ${e=>e.getMatchData().gameDate&&e.getMatchData().gameState?q:""}
        <span>${e=>e.getMatchData().gameDate||""}</span>
    </div>
`,ie=()=>_.qy`
    <div class="top-game-detail superbowl-top">
        <div class="game-winner-team">
            ${e=>ne(e)}
        </div>
        <div class="game-winner-description" title="${e=>e.viewModel.strings.champions||""}">
            ${e=>e.viewModel.strings.championsFormatted}
        </div>
    </div>
    <div class="middle-game-detail">
        <span class="game-score-text-style">
            ${e=>{var t;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.score)??""}}
        </span>
        ${e=>{var t,i;return(0,C.oT)((null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.score)||"")||(0,C.oT)((null===(i=e.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":U}}
        <span class="game-score-text-style">
            ${e=>{var t;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.score)??""}}
        </span>
    </div>
`,ae=()=>_.qy`
    <div class="middle-game-detail">
        ${e=>e.viewModel.enableLiveScores?_.qy`
    <span class="game-score-text-style">
        ${e=>{var t;return(null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.score)??""}}
    </span>
    ${e=>{var t,i;return(0,C.oT)((null===(t=e.getMatchData().participantOne)||void 0===t?void 0:t.score)||"")||(0,C.oT)((null===(i=e.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":U}}
    <span class="game-score-text-style">
        ${e=>{var t;return(null===(t=e.getMatchData().participantTwo)||void 0===t?void 0:t.score)??""}}
    </span>
`:_.qy`
    <span class="click-for-detail" title="click to see score and details">
        ${e=>(e.viewModel.strings.sportsLive||"LIVE").toLocaleUpperCase()}
    </span>
`}
    </div>
    <div class="bottom-game-detail ${e=>e.viewModel.enableLiveScores?"live-scores-detail":""}" title="${e=>e.getMatchData().tvChannel?`${e.getMatchData().gamePeriodAndClock} - ${e.getMatchData().tvChannel}`:e.getMatchData().gamePeriodAndClock}">
        <span class="game-in-progress-text" title="${e=>e.getMatchData().gamePeriodAndClock}">
            ${e=>e.getMatchData().gamePeriodAndClock||""}
        </span>
        ${e=>e.getMatchData().gamePeriodAndClock&&e.getMatchData().tvChannel?U:""}
        <span title="${e=>e.getMatchData().tvChannel}">${e=>e.getMatchData().tvChannel||""}</span>
    </div>
`,ne=e=>{const t=e.getMatchData();if(t&&t.gameStateCatetory==T.Xp.postGame){var i,a;let e=null!==(i=t.participantOne)&&void 0!==i&&i.isWinner?null===(a=t.participantOne)||void 0===a||null===(a=a.name)||void 0===a?void 0:a.toUpperCase():null;var n,o;if(!e)e=null!==(n=t.participantTwo)&&void 0!==n&&n.isWinner?null===(o=t.participantTwo)||void 0===o||null===(o=o.name)||void 0===o?void 0:o.toUpperCase():null;return e||""}return""},oe=_.qy`
    ${e=>e.isVertical()?_.qy` ${Q} `:e.isCopilotTheme()?_.qy` ${E} `:e.viewModel?_.qy` ${R} `:void 0}
`;let re=class extends r{};re=(0,a.Cg)([(0,s.E)({name:"sports-match",template:oe,styles:F,shadowOptions:{delegatesFocus:!0}})],re)},82724(e,t,i){i.r(t),i.d(t,{SportsMatchTransformer(){return l}});var a=i(23587),n=i(79811),o=i(31157),r=i(58792),s=i(94016);class l extends a.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.getPreGameNotificationMessage=e=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==e&&e.gameStateCatetory===a.Xp.preGame?e.preGameNotificationMessage:null,this.getPostGameNotificationMessage=e=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==e&&e.gameStateCatetory===a.Xp.postGame?e.postGameNotificationMessage:null,this.getMatchupContentNotificationStyleIfNecessary=e=>this.isNotificationEnabledAndAvailable(e)?"side-by-side-matchup-content-notification":"",this.isNotificationEnabledAndAvailable=e=>null!=this.getPreGameNotificationMessage(e)||null!=this.getPostGameNotificationMessage(e),this.getTeamColor=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"";return null!=e&&e.primaryColor?(0,n.gS)(e.primaryColor):null!=e&&e.primaryColorHex?(0,n.gS)(e.primaryColorHex):t},this.getTeamImageUrl=e=>{if(null!=e&&e.imageUrl)return(0,n.Hv)(null==e?void 0:e.imageUrl);const t=(0,n.iK)(null==e?void 0:e.imageId,!(null!=e&&e.imageId),this.transformerProvider.config.teamImageInfoEnhanced);return(0,n.Hv)(t)},this.getBackgroundGradient=e=>{if(!e)return"";const t=this.getTeamColor(e.participantOne),i=this.getTeamColor(e.participantTwo);if(!t||!i||t===i&&"#ffffff"===t.toLowerCase())return"";const a=this.hexToRgba(t,1),n=this.hexToRgba(t,.35),o=this.hexToRgba(i,1),r=this.hexToRgba(i,.35);return`linear-gradient(\n                        ${this.isRTLDirection()?"-120deg":"120deg"},\n                        ${a} 0%,\n                        ${a} 10.75%,\n                        ${n} 11%,\n                        ${n} 14.75%,\n                        transparent 15%,\n                        transparent 85%,\n                        ${r} 85.25%,\n                        ${r} 89%,\n                        ${o} 89.25%,\n                        ${o} 100%)`},this.isRTLDirection=()=>document.dir===o.O.rtl,this.getGameDate=e=>{const{gameStartDateTime:t,gameStateCatetory:i}=e||{};if(this.isCopilotTheme){const e=(0,n.yn)(t),o=i===a.Xp.postGame?{month:"short",day:"numeric"}:{weekday:"short",day:"numeric",month:"long"};return e.toLocaleDateString(r.T3.CurrentMarket,o)}{const e=(0,n.yn)(t);return(0,n.AL)(e,r.T3.CurrentMarket)}}}async transform(e){return{viewModel:await this.getViewModel(e)}}updateAdditionalInfo(e){const{sportsMatchData:t}=e;if(t&&t.additionalInfo){if(!t.additionalInfo.round&&t.additionalInfo.roundLocKey){var i;let e=this.transformerProvider.strings[t.additionalInfo.roundLocKey];null===(i=t.additionalInfo.roundParams)||void 0===i||i.forEach((t,i)=>{var a;e=null===(a=e)||void 0===a?void 0:a.replace(`{${i}}`,t)}),t.additionalInfo.round=e}if(!t.additionalInfo.roundSummary&&t.additionalInfo.roundLocKey){var a;let e=this.transformerProvider.strings[t.additionalInfo.roundSummaryLocKey];null===(a=t.additionalInfo.roundSummaryParams)||void 0===a||a.forEach((t,i)=>{var a;e=null===(a=e)||void 0===a?void 0:a.replace(`{${i}}`,t)}),t.additionalInfo.roundSummary=e}}}getGroupInfo(e){const t=e.matchData.sportsMatchData;var i;if(t.groupInfo)return null===(i=this.transformerProvider.strings.groupText)||void 0===i?void 0:i.replace("${0}",t.groupInfo)}hexToRgba(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:1;const i=e.match(/\w\w/g);if(!i)return"";const[a,n,o]=i.map(e=>parseInt(e,16));return`rgba(${a},${n},${o},${t})`}hasLongScore(e){var t,i;const a=(null===(t=e.participantOne)||void 0===t?void 0:t.score)||"",n=(null===(i=e.participantTwo)||void 0===i?void 0:i.score)||"";return a.length+n.length>6}getHeaderText(e){var t,i,n,o;if(!e||0===Object.keys(e).length)return{header:"",topScoreText:"",bottomScoreText:"",leftHeaderText:"",rightHeaderText:""};const{gameStartDateTime:r,gameDate:s,gamePeriodAndClock:l,gameStateCatetory:d}=e,c=null===(t=e.participantOne)||void 0===t?void 0:t.score,p=null===(i=e.participantTwo)||void 0===i?void 0:i.score,h=null===(n=e.participantOne)||void 0===n?void 0:n.standings,g=null===(o=e.participantTwo)||void 0===o?void 0:o.standings,v=new Date(r).getFullYear(),u=e.gameStartTime?e.gameStartTime.toLocaleLowerCase():"";let m,x,f,$,w;switch(d){case a.Xp.preGame:m=u,x=this.isCopilotTheme?s:`${s}, ${v}`,f=h,$=g;break;case a.Xp.inprogressGame:m=this.transformerProvider.strings.sportsLive.toLocaleUpperCase(),x=l,f=c,$=p;break;case a.Xp.postGame:m=this.transformerProvider.strings.sportsStateFinal,x=`${s}, ${v}`,f=c,$=p;break;default:m=u,x=s,f=h,$=g}switch(!0){case!!m&&!!x:w=`${m} • ${x}`;break;case!!m:w=m;break;case!!x:w=x;break;default:w=""}return{header:w,topScoreText:f,bottomScoreText:$,leftHeaderText:m,rightHeaderText:x}}async getViewModel(e){const{matchData:t,isVertical:i,telemetryConstants:o,showMatchUXV2:l,noBackgrounds:d,participantOneFollowed:c,participantTwoFollowed:p,reason:h,isContainLiveMatch:g,parentTelemetryObject:v,topDetailText:u,useLargeTeamIcon:m,hasVerticalLine:x,isSpotlight2Card:f,isSpotlightCard:$}=e||{},w=t.sportsMatchData;this.isCopilotTheme=e.isCopilotTheme||!1,this.updateAdditionalInfo(t),"string"!=typeof w.gameState&&(w.gameStateCatetory=(0,n.m5)(w.gameState.state));const b=(0,n.yn)(w.gameStartDateTime);w.gameDate=this.getGameDate(w),w.gameStartTime=(w.gameStartDateTimeIsToBeAnnounced?null:(0,n.ry)(b,r.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,"string"!=typeof w.gameState&&(w.gamePeriodAndClock=(0,n.PH)(w.gameState)),"string"!=typeof w.gameState&&(w.gamePeriod=w.gameState.gamePeriod),w.participantOne&&(w.participantOne.scheduleUrl=(0,n.Ot)(w.participantOne.gameCenterUrl)),w.participantTwo&&(w.participantTwo.scheduleUrl=(0,n.Ot)(w.participantTwo.gameCenterUrl)),w.gameCenterUrl&&(w.matchClickthroughUrl=(0,n.Ot)(w.gameCenterUrl)),w.participantOne.imageUrl=(0,n.iK)(w.participantOne.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),w.participantTwo.imageUrl=(0,n.iK)(w.participantTwo.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),w.gameState=w.gameStateCatetory===a.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:w.gameStateCatetory;const y={...o,name:a.BP.Game},k=i||e.isCopilotTheme,z=this.transformerProvider.config.enableLiveScores,F=l&&!d&&!z,T=(0,n.jJ)()?`${r.T3.StaticsUrl}/pr-5772998/icons-wc/icons/sports/LiveIconDark.svg`:`${r.T3.StaticsUrl}/latest/icons-wc/icons/sports/LiveIcon.svg`;return{backgroundGradient:z||l?"":this.getBackgroundGradient(w),followClickHandler:this.transformerProvider.followClickEntityHandler,followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(v,{...y,name:a.BP.FollowTeam},!0),hasLongScore:this.hasLongScore(w),gameNumber:"number",linkTarget:"_blank",matchData:t,matchupContentNotificationStyleIfNecessary:this.getMatchupContentNotificationStyleIfNecessary(w),overrideStyleForMatch:"",participantOneColor:F?this.getTeamColor(w.participantOne):"",participantOneFollowed:c,participantOneImgIcon:this.getTeamImageUrl(w.participantOne),participantTwoColor:F?this.getTeamColor(w.participantTwo):"",participantTwoFollowed:p,participantTwoImgIcon:this.getTeamImageUrl(w.participantTwo),postGameNotificationMessage:this.getPostGameNotificationMessage(w),preGameNotificationMessage:this.getPreGameNotificationMessage(w),reason:h,shouldDisplayT4:!g,shouldShowChampionPostGame:!1,shouldShowFollowIcon:!1,shouldUnderlineNotificationMessage:!1,showLiveDetail:!1,strings:{...this.transformerProvider.strings,championsFormatted:this.transformerProvider.strings.champions&&this.transformerProvider.strings.champions.toUpperCase()||a.kt},tabIndex:0,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(v,y),cardSize:e.cardSize,topDetailText:this.getGroupInfo(e)||u||"",useLargeTeamIcon:z||m,enableLiveScores:z||l,showMatchUXV2:z||l,noBackgrounds:d,isVertical:i,headerText:k?this.getHeaderText(w):void 0,needsVerticalLine:x,liveIconUrl:T,isSpotlight2Card:f,isSpotlightCard:$,isCopilotTheme:this.isCopilotTheme,isWindows:r.T3.AppType===s.u.WindowsNewsWidgets}}}},83549(e,t,i){i.r(t),i.d(t,{SportsMarchmadness(){return T}});var a=i(56911),n=i(84564);class o extends n.z{}var r=i(92011),s=i(48751),l=i(41123),d=i(61138),c=i(4968),p=i(12640),h=i(74849),g=i(22131);const v=h.A` .semifinal-name{color:#FFFFFF}`,u=h.A` .match-data{text-decoration:none;${c.f};display:flex;flex-direction:column;justify-content:space-around}._1x_3y .match-data{justify-content:normal}.match-list{display:flex;flex-direction:column;row-gap:12px}.content{display:grid;gap:12px;height:100%;position:relative}.tournament{display:flex;flex-direction:column;row-gap:40px;justify-content:center}._1x_2y .tournament{row-gap:20px}.header,.semifinal-top-icon,.champ-head{display:flex;align-items:center;justify-content:center;color:${s.l}}._1x_2y .semifinal-top-icon{display:none}.semifinal-top-icon img{height:82px}._1x_2y .header-image{display:none}._1x_3y .header-image{display:flex;justify-content:center}._1x_3y .header-image img{height:82px}.tournament-name{font-size:${l.K};
        line-height: ${l.Z};font-weight:700}.tournament-icon{width:22px;height:18px}.tournament-phase{font-size:${d.k};
        line-height: ${d.F}}.semifinal-icon,.quarterfinal-icon{height:24px}.semifinal-icon img,.quarterfinal-icon img{height:24px}.semifinal-name,.quarterfinal-name{font-size:16px;font-weight:900;line-height:24px;letter-spacing:0px;text-align:center;text-transform:uppercase;margin:0 2px}.icon-right{transform:scale(-1)}.final-header{height:36px}.champ-head{flex-direction:column;text-align:center;row-gap:6px}._1x_3y .champ-head{row-gap:16px;margin-bottom:28px;margin-top:24px}.desc{line-height:var(--type-ramp-base-line-height,20px);font-size:var(--type-ramp-base-font-size,14px);color:${s.l};overflow:hidden;white-space:nowrap;text-overflow:ellipsis;max-width:268px}.top-text{text-align:center;font-size:24px;text-transform:uppercase;font-weight:900;line-height:24px;max-width:268px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.top-text.one-line{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.champ-head.post-game{row-gap:0px}.post-game .desc{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);text-transform:uppercase;font-weight:600}`.withBehaviors(new p.N(null,v),(0,g.mr)(h.A` :host{forced-color-adjust:auto}`));var m=i(96950),x=i(39957),f=i(69259);const $=m.qy`
    <div class="match-list">
        ${(0,x.ux)(e=>e.viewModel.matchViews,m.qy`<sports-match
            :viewModel="${e=>e.viewModel}"
        ></sports-match>`,{positioning:!0})}
    </div>
`,w=m.qy`
    ${(0,f.z)(e=>e.viewModel.headerImage,m.qy`
        <div class="header-image">
            <img role="presentation" src="${e=>e.viewModel.headerImage}" />
        </div>`)}
`,b=m.qy`
    <div class="tournament">
        <div>
            ${w}
            <div class="header final-header">
                <div class="quarterfinal-icon">
                    <img role="presentation" src="${e=>e.viewModel.bracketIconUrl}" />
                </div>
                <div class="quarterfinal-name">
                    ${e=>{var t;return null===(t=e.viewModel.headerLine1)||void 0===t?void 0:t.toLowerCase()}}
                </div>
                <div class="quarterfinal-icon icon-right">
                    <img role="presentation" src="${e=>e.viewModel.bracketIconUrl}" />
                </div>
            </div>
        </div>
        ${$}
    </div>
`,y=m.qy`
    <div class="desc" title="${e=>e.viewModel.headerLine2}">${e=>e.viewModel.headerLine2}</div>
`,k=m.qy`
    <a class="match-data"
        href="${e=>e.viewModel.matchClickthroughUrl}"
        data-t="${e=>e.viewModel.telemetryTag}"
        target="_blank"
    >
        <div class="champ-head${e=>e.viewModel.isPostGame?" post-game":""}">
            <img role="presentation" src="${e=>e.viewModel.headerImage}" />

            <div>
                <div class="top-text${e=>e.viewModel.headerLine2?" one-line":""}" title="${e=>e.viewModel.headerLine1}">${e=>e.viewModel.headerLine1}</div>
                ${(0,f.z)(e=>e.viewModel.headerLine2,y)}
            </div>
        </div>
        ${$}
    </a>
`,z=m.qy`
    <div class="content ${e=>e.viewModel.cardSize}">
        ${e=>((e,t)=>{if("_1x_1y"===t)return $;switch(e){case"Match":default:return $;case"SemiFinal":case"Quarterfinal":return b;case"Champion":case"Championship":return k}})(e.viewModel.uxType,e.viewModel.cardSize)}
    </div>
`,F=m.qy`
    ${(0,f.z)(e=>null!=e.viewModel,z)}
`;let T=class extends o{};T=(0,a.Cg)([(0,r.E)({name:"sports-marchmadness",template:F,styles:u,shadowOptions:{delegatesFocus:!0}})],T)},84564(e,t,i){i.d(t,{z(){return r}});var a=i(56911),n=i(60815),o=i(92011);class r extends o.L{}(0,a.Cg)([n.sH],r.prototype,"viewModel",void 0)},99657(e,t,i){i.d(t,{D(){return r},I(){return o}});var a=i(45755);const{create:n}=a.G,o=n("sloppy-click-z-index",1),r=n("click-z-index",1)}}]);