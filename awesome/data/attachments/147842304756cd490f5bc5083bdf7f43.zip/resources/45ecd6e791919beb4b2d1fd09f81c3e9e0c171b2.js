"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["na-call-to-action"],{30783(t,a,o){o.r(a),o.d(a,{CallToActionTemplate(){return n.c},MsnNativeAdCallToAction(){return i.w}});var i=o(61289),n=o(61447)},61289(t,a,o){o.d(a,{w(){return C}});var i=o(56911),n=o(38493),e=o(60815),l=o(87259),r=o(93552),c=o(91454);let s=class extends l.t{themeChangeListener(t){this.darkMode=!(null==t||!t.matches)}constructor(){super(),this.text="",this.forInfopane=!0,this.backgroundColor="",this.defaultBackgroundColor="#FFFFFF",this.color="#2065C1",this.isHovered=!1,this.ctaMode="default",this.destinationUrl="",this.telemetryMetadata=void 0,this.darkModeQuery=window.matchMedia("(prefers-color-scheme:dark)"),this.darkMode=!!this.darkModeQuery.matches}connectedCallback(){super.connectedCallback(),this.darkModeQuery.addEventListener("change",this.themeChangeListener.bind(this))}disconnectedCallback(){super.disconnectedCallback(),this.darkModeQuery.removeEventListener("change",this.themeChangeListener.bind(this))}};(0,i.Cg)([n.CF],s.prototype,"text",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean",attribute:"for-infopane"})],s.prototype,"forInfopane",void 0),(0,i.Cg)([(0,n.CF)({attribute:"background-color"})],s.prototype,"backgroundColor",void 0),(0,i.Cg)([(0,n.CF)({attribute:"default-background-color"})],s.prototype,"defaultBackgroundColor",void 0),(0,i.Cg)([n.CF],s.prototype,"color",void 0),(0,i.Cg)([(0,n.CF)({mode:"boolean",attribute:"is-hovered"})],s.prototype,"isHovered",void 0),(0,i.Cg)([(0,n.CF)({attribute:"cta-mode"})],s.prototype,"ctaMode",void 0),(0,i.Cg)([(0,n.CF)({attribute:"destination-url"})],s.prototype,"destinationUrl",void 0),(0,i.Cg)([(0,n.CF)({attribute:"tel-metadata"})],s.prototype,"telemetryMetadata",void 0),(0,i.Cg)([e.sH],s.prototype,"darkMode",void 0),s=(0,i.Cg)([(0,c.TA)(r.PDj,"msn-native-ad-call-to-action")],s);var d=o(92011),p=o(74849),b=o(78862),g=o(37635);const h=p.A`
.call-to-action {
    background-color: #FFFFFF;
    color: #2065C1;
    font-size: 14px; 
    font-weight: 600;
    height: 32px;
    line-height: 32px;
    display: inline-block;
    border-radius: 20px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    position: relative;
}

.call-to-action-bg {
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 20px;
    opacity: 0.3;
}

.call-to-action-txt {
    position: relative;
    border-radius: 20px;
    padding-left: 12px;
    padding-right: 12px;
}

.call-to-action-icon-container {
    background-color: #C6C0BA;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    position: relative;
}

.call-to-action-icon-bg {
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    opacity: 0.3;
}

.call-to-action-icon {
    width: 9px;
    height: 15px;
    left: 12px;
    top: 8px;
    position: absolute;
    display: flex;
}

.call-to-action-mask-container {
    background: linear-gradient(180deg, rgba(43, 43, 43, 0.9) 0%, rgba(43, 43, 43, 0.35) 100%);
    position: absolute;
    width: 100%;
    height: 304px;
    bottom: 0;
    left: 0;
    animation: fadeIn 0.1s forwards;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}

.call-to-action-mask-wrapper {
    width: fit-content;
    position: absolute;
    top: 113px;
    left: 50%;
    transform: translate(-50%, 0);
    display: flex;
    align-items: center;
}

.call-to-action-mask-text {
    font-size: 19px;
    font-weight: 600;
    display: inline-block;
}

.call-to-action-mask-icon{
    display: inline-block;
    width: 16px;
    height: 14px;
    margin-inline: 5px;
}

.txt-button-wrapper {
    display: inline-block;
    position: relative;
    padding: 4px 12px;
    line-height: 16px;
    font-size: 12px;
    border-radius: 100px;
    font-weight: 400;
    text-decoration: none;
}

.txt-button-wrapper::before {
    content: "";
    position: absolute;
    inset: 0px;
    border-radius: 50px;
    padding: 1px;
    -webkit-mask: linear-gradient(rgb(255, 255, 255) 0px, rgb(255, 255, 255) 0px) content-box content-box, linear-gradient(rgb(255, 255, 255) 0px, rgb(255, 255, 255) 0px);
    -webkit-mask-composite: xor;
    pointer-events: none;
}
`.withBehaviors(new b.e("layoutStyle"),new g.X(["defaultBackgroundColor","backgroundColor","color","forInfopane","darkMode"],t=>{let a=`\n                .call-to-action.dynamic-styles {\n                    background: ${t.defaultBackgroundColor};\n                }\n                .call-to-action-txt.dynamic-styles {\n                    color: ${t.color};\n                }\n                .call-to-action-bg.dynamic-styles {\n                    background: ${t.backgroundColor};\n                }\n                .call-to-action-icon-bg.dynamic-styles {\n                    background: ${t.backgroundColor};\n                }\n            `;return t.forInfopane||(a+="\n                    .txt-button-wrapper::before {\n                        background: linear-gradient(180deg, #EFEFEF 90%, #D6D6D6 100%);\n                    }\n                "),t.darkMode?a+="\n                    .txt-button-wrapper {\n                        background: linear-gradient(0deg, rgba(255, 255, 255, 0.0605), rgba(255, 255, 255, 0.0605));\n                        color: #FFFFFF;\n                    }\n                    .txt-button-wrapper::before {\n                        background: linear-gradient(180deg, rgba(255, 255, 255, 0.093) 0%, rgba(255, 255, 255, 0.0698) 9.57%);\n                    }\n                ":a+="\n                    .txt-button-wrapper {\n                        color: #1a1a1a;\n                        background: linear-gradient(0deg, #FFFFFF, #FFFFFF);\n                    }\n                    .txt-button-wrapper::before {\n                        background: linear-gradient(rgba(239, 239, 239, 0.7) 90%, rgba(214, 214, 214, 0.7) 100%);\n                    }\n                ",p.A`${a}`}));var u=o(96950),x=o(69259);const v=u.qy`
<svg width="11" height="17" viewBox="0 0 11 17" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M2.09854 16.6761L10.6426 9.25004C10.8715 9.05109 11 8.78131 11 8.5C11 8.2187 10.8715 7.94891 10.6426 7.74997L2.09854 0.323871C1.98594 0.222547 1.85126 0.141728 1.70234 0.0861287C1.55342 0.0305295 1.39326 0.0012641 1.23119 4.0055e-05C1.06912 -0.00118399 0.908396 0.0256578 0.758391 0.0789993C0.608386 0.132341 0.472105 0.211114 0.357501 0.310722C0.242897 0.41033 0.152265 0.528778 0.0908924 0.659155C0.0295204 0.789532 -0.00136224 0.929227 4.60857e-05 1.07009C0.00145442 1.21095 0.0351258 1.35016 0.0990954 1.47959C0.163065 1.60902 0.256052 1.72608 0.37263 1.82394L8.05377 8.5L0.37263 15.1761C0.256052 15.2739 0.163065 15.391 0.0990954 15.5204C0.0351258 15.6498 0.00145442 15.7891 4.60857e-05 15.9299C-0.00136224 16.0708 0.0295204 16.2105 0.0908924 16.3408C0.152265 16.4712 0.242897 16.5897 0.357501 16.6893C0.472105 16.7889 0.608386 16.8677 0.758391 16.921C0.908396 16.9743 1.06912 17.0012 1.23119 17C1.39326 16.9987 1.55342 16.9695 1.70234 16.9139C1.85126 16.8583 1.98594 16.7775 2.09854 16.6761Z" fill="black"/>
</svg>
`,f=u.qy`
<svg width="16" height="14" viewBox="0 0 16 14" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M6.5 14C6.22386 14 6 13.7761 6 13.5C6 13.2239 6.22386 13 6.5 13H13C14.1046 13 15 12.1046 15 11V3C15 1.89543 14.1046 1 13 1H6.5C6.22386 1 6 0.776142 6 0.5C6 0.223858 6.22386 0 6.5 0H13C14.6569 0 16 1.34315 16 3V11C16 12.6569 14.6569 14 13 14H6.5ZM6.64645 3.14645C6.84171 2.95118 7.15829 2.95118 7.35355 3.14645L10.8536 6.64645C11.0488 6.84171 11.0488 7.15829 10.8536 7.35355L7.35355 10.8536C7.15829 11.0488 6.84171 11.0488 6.64645 10.8536C6.45118 10.6583 6.45118 10.3417 6.64645 10.1464L9.29289 7.5H0.5C0.223858 7.5 0 7.27614 0 7C0 6.72386 0.223858 6.5 0.5 6.5H9.29289L6.64645 3.85355C6.45118 3.65829 6.45118 3.34171 6.64645 3.14645Z" fill="white"/>
</svg>
`,w=u.qy` ${(0,x.z)(t=>"arrow"===t.ctaMode,u.qy`<a class="call-to-action-click-wrapper" target = "_blank" href = ${t=>t.destinationUrl} data-t="${t=>t.telemetryMetadata}" aria-label=${t=>t.text}><div class="call-to-action-icon-container" title="${t=>t.text}"><div class="call-to-action-icon-bg dynamic-styles"></div><div class="call-to-action-icon dynamic-styles">${v}</div></div></a>`)} ${(0,x.z)(t=>"mask"===t.ctaMode,u.qy` ${(0,x.z)(t=>t.isHovered,u.qy`<div class="call-to-action-mask-container"><div class="call-to-action-mask-wrapper"><div class="call-to-action-mask-text">${t=>t.text}</div><div class="call-to-action-mask-icon">${f}</div></div></div>`)} `)} ${(0,x.z)(t=>"default"===t.ctaMode||"button"===t.ctaMode,u.qy`<a class="txt-button-wrapper" target = "_blank" href = ${t=>t.destinationUrl} data-t="${t=>t.telemetryMetadata}">${t=>t.text}</a>`)} ${(0,x.z)(t=>"text"===t.ctaMode,u.qy` ${t=>t.text} `)} `;let C=class extends s{};C=(0,i.Cg)([(0,d.E)({name:"msn-native-ad-call-to-action",template:w,styles:h})],C)},61447(t,a,o){o.d(a,{c(){return s}});var i=o(96950),n=o(69259),e=o(14475),l=o(24277),r=o(77793);const c=i.qy`<div class="${t=>(0,l.s4)(t.enableSafeAds,"ad-footer")} ${t=>t.enableCTAVariant?"call-to-action-variant":""} call-to-action" slot="footer-end"><a class="call-to-action-text" href="${t=>t.destinationUrl}" target="${e.z._blank}" title="${t=>t.callToAction}" ${(0,r.Ib)(!0,!1)} data-t="${t=>{var a;return t.telemetryMetadata||(null===(a=t.adTelemetryContext)||void 0===a||null===(a=a.callToAction)||void 0===a?void 0:a.getMetadataTag())}}">${t=>t.callToAction}</a></div>`,s=i.qy`${(0,n.z)(t=>t.callToAction,c)}`}}]);