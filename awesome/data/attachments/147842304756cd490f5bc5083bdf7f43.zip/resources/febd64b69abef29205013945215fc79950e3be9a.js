"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-info-spotlight-earnings"],{4968(e,t,i){i.d(t,{f(){return l}});var r=i(64187),a=i(74849),n=i(42792),o=i(99657),s=i(36452);const l=a.A.partial`position: relative; z-index: ${o.D};`;a.A`
    ${n.e}
    ${n.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(n.kc)},9768(e,t,i){i.r(t),i.d(t,{SpotlightEarningsTransformer(){return s}});var r=i(27208),a=i(86449),n=i(30236),o=i(96950);class s extends r.IB{async transform(e){const t=await this.getCurrentViewModel(e);return{viewTemplate:o.qy`
                <spotlight-earnings
                    :viewModel="${t}"
                ></spotlight-earnings>`}}async getCurrentViewModel(e){return this.quote=e.quote,this.cardSize=e.cardSize,this.updateCurrentQuoteNotification(e.feedData),this.isDarkModeTheme=!0,{telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.telemetryObject,{name:r.CD.quoteItemClick,signature:e.signature,headline:e.destinationUrl}),strings:{...this.transformerProvider.strings},experienceName:e.experienceName,openLinksInNewTab:this.transformerProvider.config.openLinksInNewTab,chartStyles:this.calculateBarChartHeights,cardSize:this.cardSize,currentQuoteNotification:this.currentQuoteNotification,destinationUrl:e.destinationUrl,quote:this.quote,notificationText:this.notificationText,notificationIconUrl:this.getNotfIconUrl(),epsForecast:this.earningsForecastText,epsReported:this.earningsReportedText,quoteNotificationClass:this.quoteChangeNotfClass,quoteChangeClass:this.quoteChangeClass,quoteChangeAriaLabel:this.quoteChangeAriaLabel,quoteRowAriaLabel:this.quoteRowAriaLabel}}getNotfIconUrl(){var e,t,i;return(0,n.kX)(this.transformerProvider.config.urls,(null===(e=this.quote)||void 0===e?void 0:e.changePcntNumber)||0,null===(t=this.currentQuoteNotification)||void 0===t?void 0:t.notificationType,this.transformerProvider.config.swapGainLossColor,null===(i=this.currentQuoteNotification)||void 0===i||null===(i=i.notification)||void 0===i?void 0:i.signal)}updateCurrentQuoteNotification(e){var t;const i=(0,a.EL)(this.quote),n=null==e||null===(t=e.quoteNotificationDetails)||void 0===t?void 0:t[i],o=null==n?void 0:n.filter(e=>e.notificationType===r.Ex.EarningRelease);this.isEarningsReported(null==o?void 0:o[0])&&(this.currentQuoteNotification=null==o?void 0:o[0])}isEarningsReported(e){if(!e)return!1;const{notification:t}=e;if(!t)return!1;const{EpsForecast:i,EpsReported:r}=t;return!!i&&!!r&&(null==i?void 0:i.length)>0&&(null==r?void 0:r.length)>0}get earningsReportedText(){var e;const t=(null===(e=this.currentQuoteNotification)||void 0===e||null===(e=e.notification)||void 0===e?void 0:e.EpsReported)||"";return(0,a.V5)(()=>(0,a.T$)(t,3),t)||""}get earningsForecastText(){var e;const t=(null===(e=this.currentQuoteNotification)||void 0===e||null===(e=e.notification)||void 0===e?void 0:e.EpsForecast)||"";return(0,a.V5)(()=>(0,a.T$)(t,3),t)||""}get currentNotificationType(){var e;return null===(e=this.currentQuoteNotification)||void 0===e?void 0:e.notificationType}get currentNotificationSignal(){var e;return null===(e=this.currentQuoteNotification)||void 0===e||null===(e=e.notification)||void 0===e?void 0:e.signal}get calculateBarChartHeights(){try{var e,t;const i=`--earnings-chart-padding-bottom:${10}px`,r=36,a={_1x_2y:72,_1x_3y:176}[this.cardSize],n=Number(null===(e=this.currentQuoteNotification)||void 0===e||null===(e=e.notification)||void 0===e?void 0:e.EpsForecast),o=Number(null===(t=this.currentQuoteNotification)||void 0===t||null===(t=t.notification)||void 0===t?void 0:t.EpsReported);let s,l;if(n===o)s=`--earnings-forecast-height:${a}px`,l=`--earnings-reported-height:${a}px`;else{const e=Math.max(n,o),t=Math.min(n,o);let i=Math.round(1e3*(a-Math.abs((e-t)/e*a)))/1e3;i<r&&(i=r),s=`--earnings-forecast-height:${n>o?a:i}px`,l=`--earnings-reported-height:${o>n?a:i}px`}return`${i};${s};${l};`}catch{return""}}get notificationText(){var e;return(null===(e=this.currentQuoteNotification)||void 0===e?void 0:e.shortHeadline)||""}get quoteChangeNotfClass(){var e;let t="";return null!==(e=this.currentQuoteNotification)&&void 0!==e&&e.notificationType&&(t=this.currentNotificationType===r.Ex.PriceDrop||this.currentNotificationType===r.Ex.PriceSpike?(0,a.J6)(this.isDarkModeTheme,this.quote.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor,!1):this.getEventNotificationFillColor(this.currentNotificationType)),t}getEventNotificationFillColor(e){if((0,a.i1)(e)&&this.currentNotificationSignal){if(this.currentNotificationSignal===r.KH.Gainer)return this.transformerProvider.config.swapGainLossColor?"quote-red":"quote-green";if(this.currentNotificationSignal===r.KH.Loser)return this.transformerProvider.config.swapGainLossColor?"quote-green":"quote-red"}return"quote-blue"}get quoteChangeClass(){return(0,a.J6)(this.isDarkModeTheme,this.quote.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor,!1)}get quoteChangeAriaLabel(){return`${this.quote.changePcnt} ${this.quote.displayName} ${this.quote.changeValue}`}get quoteRowAriaLabel(){let e="";return e=this.quote.gain||this.quote.unchanged?this.transformerProvider.strings.increasedByText:this.transformerProvider.strings.decreasedByText,`${this.quote.symbol}, ${this.quote.displayName}. ${this.transformerProvider.strings.priceIsText} ${this.quote.price}. ${e} ${this.quote.changePcnt}`}}Promise.resolve().then(i.bind(i,28372))},28372(e,t,i){i.r(t),i.d(t,{SpotlightEarnings(){return E}});var r=i(56911),a=i(92707);class n extends a.z{onSizeChange(e){}onChartDictChange(e){}stockNames(e){const{quote:{shortName:t,displayName:i,symbol:r}}=this.viewModel;return[t||i||"",r||""][e]}}var o=i(92011),s=i(48751),l=i(64003),d=i(61138),c=i(41123),h=i(62047),g=i(4968),p=i(12640),u=i(74849);const f=u.A` .emb{background:rgba(255,255,255,0.06) !important}.ch-cols:nth-of-type(1),.general.ch-cols{background:rgba(255,255,255,0.1) !important;color:${s.l} !important}.negative.ch-cols{background:rgba(255,171,140,0.2) !important}.positive.ch-cols{background:rgba(2,225,118,0.2) !important}:host{--standard-green:#02E176 !important;--standard-red:#FFAB8C !important;--standard-blue:#0078D4 !important;--standard-grey:rgba(255,255,255,0.54) !important}`,x=u.A` :host{--standard-green:#0B7B24;--standard-red:#BF3401;--standard-blue:#0078D4;--standard-grey:rgba(0,0,0,0.54)}.emb{background:rgba(255,255,255,0.5);height:100%;border-radius:8px;${g.f}}.notf-ic{height:16px;padding-left:4px;padding-right:4px}.notf-ic svg{height:16px;width:16px}.sec-title-str{color:${l.c};
        margin: 0;
        font-size: ${d.k};
        line-height: ${d.F}}.price{align-items:center;justify-content:flex-end;display:flex}.price-str{color:${s.l};
        font-weight: 600;
        font-size: ${c.K};
        line-height: ${c.Z};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.change-button-area{display:flex;justify-content:flex-end;align-items:center}.change-values-percentage-gradient{display:flex;font-size:${c.K};
        line-height: ${d.F};font-weight:600;text-align:end;height:20px;justify-content:flex-end;align-items:center}.sl-quote{display:flex;flex-direction:column;justify-content:space-between;text-decoration:none;align-items:flex-start;height:100%;padding:12px 12px 0 12px;box-sizing:border-box;border-radius:6px}.sl-quote._1x_1y{display:grid;grid-column-gap:8px;grid-template-columns:1fr min-content;padding:9px 12px !important;align-items:center}.sl-sm-left{min-width:0px}.sl-title{display:flex;align-items:baseline;max-width:244px;font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);font-weight:600;margin:0;color:${s.l}}.ellipsis{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}._1x_3y .sl-title{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px)}.sl-quote .sec-title-str{font-weight:400;color:var(--standard-grey)}.emb:not(._1x_1y) .sec-title-str{margin-left:5px}.sl-quote._1x_1y .sec-title-str{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);color:${s.l}}.sl-quote .price-str{font-size:var(--type-ramp-plus-4-font-size,28px);line-height:var(--type-ramp-plus-4-line-height,36px)}.sl-quote._1x_2y .change-button-area,.sl-quote._1x_3y .change-button-area{margin:0 -2px;bottom:-6px;position:relative}.sl-quote._1x_1y .price-str{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.sl-quote._1x_3y .price-str{font-weight:600;font-size:var(--type-ramp-plus-5-font-size,32px);line-height:var(--type-ramp-plus-5-line-height,40px)}.sl-quote._1x_3y .change-values-percentage,.sl-quote._1x_3y .change-values-percentage-gradient{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px)}.sl-price-row{display:grid;grid-template-columns:repeat(3,min-content);grid-gap:8px;align-items:center;margin-bottom:2px}.sl-quote .notf-tx{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);padding:0px 6px;display:-webkit-box;overflow:hidden;-webkit-line-clamp:2;-webkit-box-orient:vertical;text-overflow:ellipsis}.sl-quote._1x_1y .notf-tx{-webkit-line-clamp:1}.sl-quote._1x_3y .notf-tx{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px)}.sl-quote .glcn{display:flex;align-items:center}.sl-quote .glcn .notf-ic{line-height:16px;padding:0px}.sl-quote .glcn .notf-ic svg{width:16px;height:16px}.sl-quote._1x_3y .glcn .notf-ic{height:20px}.sl-quote._1x_3y .glcn .notf-ic svg{width:20px;height:20px}.icn{display:flex}.icn,.icn img{width:28px;height:28px}.icn img{object-fit:contain}.emb-chart{width:244px;display:flex;align-items:end}.ch-cols{display:flex;flex-direction:column;justify-content:end;align-items:center;flex:1;margin:8px 8px 0 8px;border-top-left-radius:6px;border-top-right-radius:6px;padding-bottom:var(--earnings-chart-padding-bottom)}.ch-cols:nth-of-type(1){background:rgba(171,171,171,0.2);color:var(--standard-grey);height:var(--earnings-forecast-height)}.ch-cols:nth-of-type(2){height:var(--earnings-reported-height)}.negative.ch-cols{background:rgba(196,43,28,0.1);color:var(--standard-red)}.positive.ch-cols{background:rgba(15,123,15,0.1);color:var(--standard-green)}.general.ch-cols{background:rgba(171,171,171,0.2);color:var(--standard-grey)}.ch-cols div{font-size:${h.t};
        line-height: ${c.Z}}.ch-cols span{font-size:${c.K};
        font-weight: 600;
        line-height: ${d.F}}.quote-red{color:var(--standard-red);fill:var(--standard-red)}.quote-green{color:var(--standard-green);fill:var(--standard-green)}.quote-blue{color:var(--standard-blue);fill:var(--standard-blue)}`.withBehaviors(new p.N(null,f));var v=i(96950),b=i(69259);const m=v.qy`<img src="${e=>e.viewModel.notificationIconUrl}" class="notf-ic" alt="">`,$=v.qy`<span class="notf-tx ${(e,t)=>e.viewModel.quoteNotificationClass}">${e=>e.viewModel.notificationText}</span>`,y=v.qy`<div class="sl-title"><div class="ellipsis">${e=>e.stockNames(0)}</div><div class="sec-title-str">${e=>e.stockNames(1)}</div></div>`,w=v.qy`<span class="${(e,t)=>e.viewModel.quoteChangeClass}" aria-label="${(e,t)=>e.viewModel.quoteChangeAriaLabel}"><span class="change-button-area"><span class="change-values-percentage-gradient">&lrm;${e=>e.viewModel.quote.changePcnt}&lrm;</span></span></span>`,k=v.qy`<div class="price"><span class="price-str">${e=>e.viewModel.quote.price}</span></div>`,z=v.qy`<div class="emb-chart" style="${e=>e.viewModel.chartStyles}"><div class="ch-cols"><div>${e=>e.viewModel.strings.epsForecast||""}</div><span>${e=>e.viewModel.epsForecast}</span></div><div class="ch-cols ${e=>{var t;return null===(t=e.viewModel.currentQuoteNotification)||void 0===t||null===(t=t.notification)||void 0===t?void 0:t.signal}}"><div>${e=>e.viewModel.strings.epsReported||""}</div><span>${e=>e.viewModel.epsReported}</span></div></div>`,_=v.qy`<div class="sl-price-row">${k} ${w}</div>`,q=v.qy`<div class="glcn">${m} ${$}</div>`,C=v.qy`<div>${y} ${()=>_} ${(0,b.z)(e=>e.viewModel.currentQuoteNotification,q)}</div>${z}
`,N=v.qy`<div class="ellipsis">${(0,b.z)(e=>!e.viewModel.currentQuoteNotification,v.qy`${e=>e.viewModel.quote.symbol}`)}</div>`,S=v.qy`<div class="sl-sm-left"><div class="sec-title-str">${e=>e.viewModel.quote.displayName}</div><div>${(0,b.z)(e=>e.viewModel.currentQuoteNotification,q)} ${(0,b.z)(e=>!e.viewModel.currentQuoteNotification,N)}</div></div><div class="sl-sm-right">${k} ${w}</div>`,T=v.qy`<a class="sl-quote emb ${e=>e.viewModel.cardSize}" role="link" href="${e=>e.viewModel.destinationUrl}" target="${e=>e.viewModel.openLinksInNewTab?"_blank":"_self"}" data-t="${e=>e.viewModel.telemetryTag}" tabindex="-1" aria-label="${e=>e.viewModel.quoteRowAriaLabel}" title="${e=>e.viewModel.quote.tooltipText}">${(0,b.z)(e=>"_1x_1y"===e.viewModel.cardSize,S)} ${(0,b.z)(e=>"_1x_1y"!==e.viewModel.cardSize,C)}</a>`;let E=class extends n{};E=(0,r.Cg)([(0,o.E)({name:"spotlight-earnings",template:T,styles:x,shadowOptions:{delegatesFocus:!0}})],E)},42792(e,t,i){i.d(t,{R7(){return f},e(){return p},kc(){return u},nH(){return g}});var r=i(57416),a=i(55153),n=i(95239),o=i(26920),s=i(48751),l=i(64187),d=i(22131),c=i(74849),h=i(50882);const g=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,p=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${n.p};
        outline: calc(${o.XA} * 1px) solid ${a.cu};
        border-radius: calc((${r.JU} - ${o.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${o.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${o.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${o.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,d.mr)(c.A`
            :host {
                background: ${h.A.Canvas};
                color: ${h.A.CanvasText};
            }
        `),f=c.A`
    ${p}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},92707(e,t,i){i.d(t,{z(){return l}});var r=i(56911),a=i(27208),n=i(60815),o=i(92011),s=i(31525);let l=class extends o.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return a.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const e=this.getState();e&&(e.subscribe(a.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),e.subscribe(a.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(e){}onChartDictChange(e){}onShowNotificationTextChange(e){}onQuoteItemDictChange(e){}onCardWidthChanged(e){}};(0,r.Cg)([n.sH],l.prototype,"viewModel",void 0),l=(0,r.Cg)([s.x],l)},99657(e,t,i){i.d(t,{D(){return o},I(){return n}});var r=i(45755);const{create:a}=r.G,n=a("sloppy-click-z-index",1),o=a("click-z-index",1)}}]);