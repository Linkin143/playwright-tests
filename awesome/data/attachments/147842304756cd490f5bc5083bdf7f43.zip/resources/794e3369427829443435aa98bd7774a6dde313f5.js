// © Microsoft Corporation. All rights reserved.
import { resolver } from "@msnews/core";
const EntryPointHpWCConfig = {
    childExperienceConfigInfo: {
        homepageHeaderConfigInfo: {
            instanceId: "HomepageHeader",
            configRef: {
                experienceType: "HomepageHeader",
                instanceSrc: "default"
            }
        },
        meStripeConfigInfo: {
            instanceId: "MeStripeWC",
            configRef: {
                experienceType: "MeStripeWC",
                instanceSrc: "default"
            }
        },
        bannerDisplayAdsConfigInfo: {
            instanceId: "banner1",
            configRef: {
                experienceType: "DisplayAdsWC",
                instanceSrc: "default"
            }
        },
        weatherTodayMiniConfigInfo: {
            instanceId: "WeatherTodayMiniWC",
            configRef: {
                experienceType: "WeatherTodayMiniWC",
                instanceSrc: "default"
            }
        },
        promoFeedNavigationHpConfigInfo: {
            instanceId: "FeedNavigationHp",
            configRef: {
                experienceType: "FeedNavigationHp",
                instanceSrc: "promo"
            }
        },
        feedNavigationHpConfigInfo: {
            instanceId: "FeedNavigationHp",
            configRef: {
                experienceType: "FeedNavigationHp",
                instanceSrc: "default"
            }
        },
        stripeWCConfigInfo: {
            instanceId: "StripeWC",
            configRef: {
                experienceType: "StripeWC",
                instanceSrc: "default"
            }
        },
        homepageFooterConfigInfo: {
            instanceId: "HomepageFooter",
            configRef: {
                experienceType: "HomepageFooter",
                instanceSrc: "default"
            }
        }
    },
    dataConnectors: [
        {
            screenWidth: "Any",
            children: [
                {
                    experienceType: "LayoutPreferenceData",
                    instanceId: "",
                    href: "cms/api/amp/experienceConfigIndex/BB161SZL"
                },
                {
                    experienceType: "TelemetryData",
                    instanceId: "",
                    href: "cms/api/amp/experienceConfigIndex/BB1500Om"
                },
                {
                    experienceType: "IrisData",
                    instanceId: "",
                    href: "cms/api/amp/experienceConfigIndex/BB176t51"
                }
            ]
        }
    ],
    serviceWorker: {
        enabled: "true",
        registrationEnabled: "false",
        unregistrationEnabled: "true"
    },
    verticalKey: "homepage",
    categoryKey: "",
    track: {
        canvas: "Browser",
        channel: "",
        msnocid: "",
        department: "",
        pageName: "homepage",
        pageVersion: "",
        pageType: "hp",
        storeocid: "",
        pageConfiguration: 11,
        pageProduct: "prime",
        vertical: "homepage"
    },
    initialPageTitle: "MSN | Outlook, Office, Skype, Bing, Breaking News, and Latest Videos",
    description: "Test Description"
};
const todayStripeConfig = {
    childExperienceMap: {
        Infopane: {
            instanceId: "Infopane",
            experienceType: "Infopane",
            href: "cms/api/amp/experienceConfigIndex/BB15YhFt"
        },
        ContentPreview: {
            instanceId: "ContentPreview",
            experienceType: "ContentPreview",
            href: "cms/api/amp/experienceConfigIndex/BB15YaEO"
        },
        ExternalContentPreview: {
            instanceId: "ExternalContentPreview",
            experienceType: "ExternalContentPreview",
            href: "cms/api/amp/experienceConfigIndex/BB15Y3lr"
        },
        DisplayAdsWithContentFallback: {
            instanceId: "displayAds",
            experienceType: "DisplayAdsWithContentFallback",
            href: "cms/api/amp/experienceConfigIndex/BB19bE1g"
        }
    },
    cardProviderConfig: {
        initialRequest: {
            complexInfopaneEnabled: true,
            count: 40,
            feedName: "default",
            ocid: "hponeservicefeed",
            start: 0,
            timeoutMs: 1000,
            infopaneItemCount: 23,
            contentType: "article,video,slideshow,webcontent,content360",
            useDelta: true,
            disableFlatViewResponse: true,
            postRequestGrouping: {
                start: 5,
                count: 3,
                type: "BackfillContent"
            },
            reorderCardSetting: {
                experienceType: "DisplayAdsWithContentFallback",
                positions: {
                    c4: 2,
                    c3: 1,
                    c2: 2
                }
            }
        }
    },
    cardProviderConfigColumnOverrides: {
        c1: {
            initialRequest: {
                complexInfopaneEnabled: false,
                infopaneItemCount: 0
            }
        }
    },
    riverTemplateConfig: {
        templateScreenConfigs: [
            {
                screenWidth: "Any",
                templateTypes: [
                    "HomepageRiverSections"
                ],
                gutterSize: 20
            }
        ]
    },
    cardProviderName: "OneService",
    useMediaBreakpointManager: false,
    disableAbstractCards: false,
    disableBreakpointTracking: false,
    gutterSize: 20,
    manualPaginationEnabled: true,
    disablePagination: true,
    visualReadinessCounter: 1,
    onVisuallyReadyTimeoutMs: 20000,
    singleColumnRiverTemplatesEnabled: true,
    riverGridChildren: [
        {
            screenWidth: "FourColumn",
            children: [
                {
                    childExperienceConfigInfo: {
                        experienceType: "RiverPlaceholder",
                        instanceId: "trendingnow",
                        href: "cms/api/amp/experienceConfigIndex/BB19bNIZ"
                    },
                    arrangement: {
                        column: 3,
                        row: 5
                    }
                }
            ]
        }
    ],
    dataConnectors: [
        {
            screenWidth: "Any",
            children: [
                {
                    experienceType: "PlacementManager",
                    instanceId: "",
                    href: "cms/api/amp/experienceConfigIndex/BB15YcV1"
                }
            ]
        }
    ]
};
// In production, webpack will remove entire block of developmental inline script in the bundle.
if (process.env.NODE_ENV !== "production") {
    /**
     *  use the mocked configs when loading the pages.
     *  it is only effective for local development.
     */
    (() => {
        // double check it's localhost otherwise just return
        if (window && window.location && window.location.host.startsWith("localhost")) {
            alert("You are using mock configurations. Comment the import in page.ts to disable the mock");
            // resolver override will override the real config with the local mocked one
            // usage:
            //      resolver.overrideConfig(
            //         "the index of the config you want to override",
            //         "Experience Type",
            //         mockConfig
            //       );
            // override the entry point config
            resolver.overrideConfig("cms/api/amp/experienceConfigIndex/BB15YaRZ", "EntryPoint", EntryPointHpWCConfig);
            resolver.overrideConfig("cms/api/amp/experienceConfigIndex/BB15YmCY", "River", todayStripeConfig);
        }
    })();
}
//# sourceMappingURL=mockConfigs.js.map