"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-info-radar-graph"],{4968(t,r,e){e.d(r,{f(){return h}});var n=e(64187),i=e(74849),a=e(42792),s=e(99657),o=e(36452);const h=i.A.partial`position: relative; z-index: ${s.D};`;i.A`
    ${a.e}
    ${a.nH}

    ${(0,n.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${h}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${o.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${o.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${o.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(a.kc)},8698(t,r,e){function n(t){return t.ownerDocument&&t.ownerDocument.defaultView||t.document&&t||t.defaultView}e.d(r,{A(){return n}})},25098(t,r,e){e.d(r,{A(){return i}});var n=e(83037);function i(t){return"string"==typeof t?new n.LN([[document.querySelector(t)]],[document.documentElement]):new n.LN([[t]],n.zr)}},27616(t,r,e){e.d(r,{Ay(){return l},f0(){return i}});var n={},i=null;function a(t,r,e){return t=s(t,r,e),function(r){var e=r.relatedTarget;e&&(e===this||8&e.compareDocumentPosition(this))||t.call(this,r)}}function s(t,r,e){return function(n){var a=i;i=n;try{t.call(this,this.__data__,r,e)}finally{i=a}}}function o(t){return function(){var r=this.__on;if(r){for(var e,n=0,i=-1,a=r.length;n<a;++n)e=r[n],t.type&&e.type!==t.type||e.name!==t.name?r[++i]=e:this.removeEventListener(e.type,e.listener,e.capture);++i?r.length=i:delete this.__on}}}function h(t,r,e){var i=n.hasOwnProperty(t.type)?a:s;return function(n,a,s){var o,h=this.__on,l=i(r,a,s);if(h)for(var c=0,u=h.length;c<u;++c)if((o=h[c]).type===t.type&&o.name===t.name)return this.removeEventListener(o.type,o.listener,o.capture),this.addEventListener(o.type,o.listener=l,o.capture=e),void(o.value=r);this.addEventListener(t.type,l,e),o={type:t.type,name:t.name,value:r,listener:l,capture:e},h?h.push(o):this.__on=[o]}}function l(t,r,e){var n,i,a=function(t){return t.trim().split(/^|\s+/).map(function(t){var r="",e=t.indexOf(".");return e>=0&&(r=t.slice(e+1),t=t.slice(0,e)),{type:t,name:r}})}(t+""),s=a.length;if(!(arguments.length<2)){for(l=r?h:o,null==e&&(e=!1),n=0;n<s;++n)this.each(l(a[n],r,e));return this}var l=this.node().__on;if(l)for(var c,u=0,d=l.length;u<d;++u)for(n=0,c=l[u];n<s;++n)if((i=a[n]).type===c.type&&i.name===c.name)return c.value}"undefined"!=typeof document&&("onmouseenter"in document.documentElement||(n={mouseenter:"mouseover",mouseleave:"mouseout"}))},32598(t,r,e){function n(t){return function(){return this.matches(t)}}e.d(r,{A(){return n}})},34271(t,r,e){function n(){}function i(t){return null==t?n:function(){return this.querySelector(t)}}e.d(r,{A(){return i}})},39006(t,r,e){e.d(r,{g(){return n}});var n="http://www.w3.org/1999/xhtml";r.A={svg:"http://www.w3.org/2000/svg",xhtml:n,xlink:"http://www.w3.org/1999/xlink",xml:"http://www.w3.org/XML/1998/namespace",xmlns:"http://www.w3.org/2000/xmlns/"}},39111(t,r,e){e.d(r,{A(){return o},j(){return h}});var n=e(8698);function i(t){return function(){this.style.removeProperty(t)}}function a(t,r,e){return function(){this.style.setProperty(t,r,e)}}function s(t,r,e){return function(){var n=r.apply(this,arguments);null==n?this.style.removeProperty(t):this.style.setProperty(t,n,e)}}function o(t,r,e){return arguments.length>1?this.each((null==r?i:"function"==typeof r?s:a)(t,r,null==e?"":e)):h(this.node(),t)}function h(t,r){return t.style.getPropertyValue(r)||(0,n.A)(t).getComputedStyle(t,null).getPropertyValue(r)}},39435(t,r,e){e.d(r,{A(){return i}});var n=e(39006);function i(t){var r=t+="",e=r.indexOf(":");return e>=0&&"xmlns"!==(r=t.slice(0,e))&&(t=t.slice(e+1)),n.A.hasOwnProperty(r)?{space:n.A[r],local:t}:t}},42792(t,r,e){e.d(r,{R7(){return p},e(){return f},kc(){return g},nH(){return d}});var n=e(57416),i=e(55153),a=e(95239),s=e(26920),o=e(48751),h=e(64187),l=e(22131),c=e(74849),u=e(50882);const d=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,f=c.A`
    ${(0,h.V)("flex")} :host {
        background: ${a.p};
        outline: calc(${s.XA} * 1px) solid ${i.cu};
        border-radius: calc((${n.JU} - ${s.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${o.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${i.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${i.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${s.XA} * 1px) ${i.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${i.QG} * 1px);
        height: calc(${i.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${i.QG} * 1px);
        height: calc((${i.l8} * 2px) + (${i.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${i.QG} * 2px) + (${i.Sn} * 1px));
        height: calc((${i.l8} * 2px) + (${i.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${i.QG} * 2px) + (${i.Sn} * 1px));
        height: calc(${i.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,g=(0,l.mr)(c.A`
            :host {
                background: ${u.A.Canvas};
                color: ${u.A.CanvasText};
            }
        `),p=c.A`
    ${f}
    ${d}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(g)},53548(t,r,e){e.r(r),e.d(r,{RadarGraph(){return N}});var n=e(56911),i=e(27208),a=e(58792),s=e(25098),o=e(96124),h=e(92707),l=e(60815);const c="bad",u="good",d="neutral",f="NA",g=`${(0,a.rA)().StaticsUrl}latest/fluent-icons/chevron_right_16_regular.svg`;class p extends h.z{constructor(){super(...arguments),this.insightIcons=[],this.insightStatement="",this.isHovering=!1,this.categoryText="",this.categoryScore="",this.chevronIcon={src:g},this.lastActiveCategory=i.vh.valuation}connectedCallback(){super.connectedCallback(),this.drawGraph()}drawGraph(){if(!this.viewModel||!this.graphContainer)return;const{width:t,height:r,polygonPoints:e,pointsOnCircumference:n,radiusArray:i,radius:a}=this.viewModel,o=(0,s.A)(this.graphContainer).attr("width",t).attr("height",r),h=[t/2,r/2];this.drawRings(o,h,i),this.drawConnectedLines(o,h,n),o.append("polygon").attr("points",e.map(t=>t.join(",")).join(" ")).attr("class","polygon"),e.forEach((t,r)=>{const e=Array.from(this.viewModel.labelsMap.values())[r].key;o.append("circle").attr("cx",t[0]).attr("cy",t[1]).attr("r",3).attr("class","points-active").attr("data-key",e)}),this.drawScoreLabels(o,n),this.drawHoverableSegment(o,h,a),this.updateInsightStatement()}updateInsightStatement(){const t=this.activeSegment||this.lastActiveCategory,r=this.viewModel.labelsMap.get(t);if(null!=r&&r.insightStatement)this.insightStatement=r.insightStatement;else{const t=this.viewModel.strings.dataIsNotAvailable;this.insightStatement=t}this.updateCategoryIcons(r)}updateCategoryIcons(t){if(!t)return;this.categoryText=t.majorText,this.categoryScore=t.minorText,this.currentCategory=t;const r=this.generateInsightIcons(t);this.insightIcons=r.map(t=>({src:t}))}drawRings(t,r,e){e.forEach((e,n)=>{t.append("circle").attr("cx",r[0]).attr("cy",r[1]).attr("r",e).attr("class","rings")})}drawConnectedLines(t,r,e){e.forEach(e=>{t.append("line").attr("x1",r[0]).attr("y1",r[1]).attr("x2",e[0]).attr("y2",e[1]).attr("class","radar-lines")})}renderDefaultScoreLabelContainer(t){return`\n            <div class="score-label-container" style="transform: translate(${`${t.translateInX}%`}, ${`${t.translateInY}%`});">\n                ${this.renderScoreLabel(t)}\n            </div>\n        `}renderScoreLabel(t){const{majorText:r,minorText:e}=t;return t.key==i.vh.valuation?`\n                <div class="score-label-top label-${t.key}">\n                    <div>${r}</div>\n                    <div>${e}</div>\n                </div>\n            `:`\n            <div class="score-label label-${t.key}">\n                <div>${r}</div>\n                <div>${e}</div>\n            </div>\n        `}drawScoreLabels(t,r){const{labelsMap:e,width:n,height:i}=this.viewModel,a=Array.from(e.values());r.forEach((r,e)=>{const s=a[e],o=this.renderDefaultScoreLabelContainer(s),h=t.append("foreignObject").attr("x",r[0]).attr("y",r[1]).attr("width",n).attr("height",i).attr("class","score-labels").html(o),l=`${s.majorText} ${s.minorText}`;h.attr("aria-label",l),h.append("title").text(l)})}generateInsightIcons(t){if(!t)return[];const{goodEvaluationCount:r,badEvaluationCount:e,neutralEvaluationCount:n,noDataEvaluationCount:i}=t,a=this.getStockInsightRatingIcon(u),s=this.getStockInsightRatingIcon(c),o=this.getStockInsightRatingIcon(d),h=this.getStockInsightRatingIcon(f),l=Array.from({length:r},()=>a),g=Array.from({length:e},()=>s);return[...l,...Array.from({length:n},()=>o),...g,...Array.from({length:i},()=>h)]}getStockInsightRatingIcon(t){const r=`${(0,a.rA)().StaticsUrl}latest/finance/icon/${this.viewModel.isDarkModeTheme?"dark":"light"}/`,e="Due";switch(t){case u:return`${r}${e}Positive.svg`;case c:return`${r}${e}Negative.svg`;case d:return`${r}${e}Unchange.svg`}return`${r}${e}Nodata.svg`}drawHoverableSegment(t,r,e){const{labelsMap:n}=this.viewModel,i=Array.from(n.values());i.forEach((n,a)=>{const s=2*Math.PI/i.length,h=s*a,l=-.5*s-.5*Math.PI-h,c=.5*s-.5*Math.PI-h,u=(0,o.A)();u.moveTo(r[0],r[1]),u.arc(r[0],r[1],e,l,c),u.closePath(),t.append("path").attr("class","segment-path").attr("data-key",n.key).attr("data-index",a).attr("d",u.toString()).on("mouseover",()=>{this.isHovering=!0,this.activeSegment=n.key,this.updateSegmentStyles()}).on("mouseout",()=>{this.isHovering=!1,this.isHovering||(this.activeSegment=void 0,this.updateSegmentStyles())})})}updateSegmentStyles(){const t=(0,s.A)(this.graphContainer).selectAll(".segment-path"),r=(0,s.A)(this.graphContainer).selectAll(".score-label, .score-label-top"),e=(0,s.A)(this.graphContainer).selectAll(".points-active, .points-inactive");this.activeSegment&&(this.lastActiveCategory=this.activeSegment),t.each((t,r,e)=>{const n=(0,s.A)(e[r]),i=n.attr("data-key");void 0===this.activeSegment?(n.classed("segment-path-active",!1),n.classed("segment-path-inactive",!1)):this.activeSegment===i?(n.classed("segment-path-active",!0),n.classed("segment-path-inactive",!1),n.raise()):(n.classed("segment-path-active",!1),n.classed("segment-path-inactive",!0))}),e.each((t,r,e)=>{const n=(0,s.A)(e[r]),i=n.attr("data-key");n.raise(),void 0===this.activeSegment||this.activeSegment===i?(n.classed("points-active",!0),n.classed("points-inactive",!1)):(n.classed("points-active",!1),n.classed("points-inactive",!0))}),r.each((t,r,e)=>{const n=(0,s.A)(e[r]),i=e[r],a=((null==i?void 0:i.getAttribute("class"))||"").includes(`label-${this.activeSegment}`);n.style("opacity",a||void 0===this.activeSegment?1:.5)}),this.updateInsightStatement()}}(0,n.Cg)([l.sH],p.prototype,"currentCategory",void 0),(0,n.Cg)([l.sH],p.prototype,"insightIcons",void 0),(0,n.Cg)([l.sH],p.prototype,"insightStatement",void 0),(0,n.Cg)([l.sH],p.prototype,"isHovering",void 0),(0,n.Cg)([l.sH],p.prototype,"activeSegment",void 0),(0,n.Cg)([l.sH],p.prototype,"categoryText",void 0),(0,n.Cg)([l.sH],p.prototype,"categoryScore",void 0);var v=e(92011),b=e(74849),w=e(22131),x=e(4968);const y="rgba(33, 105, 235, 0.20)",m="#2169EB",$="#D5E3FB",k="rgba(50, 117, 240, 0.50)",A=b.A` .score-labels,score-label-top,.category-text-label,.category-score-label,.insight-statement{color:#FFFFFF}.rings{fill:${"rgb(161, 191, 240)"};stroke-width:1px}.polygon{fill:${k};
        stroke: ${"#235CCF"}}.card-container{background:#292929;box-shadow:0px 2px 4px 0px rgba(0,0,0,0.28),0px 0px 2px 0px rgba(0,0,0,0.24)}`,z=b.A`
:host{border-radius:6px}.wrapper{${x.f};cursor:pointer;display:flex;justify-content:center;align-items:center;flex-direction:column}a{text-decoration:none}.graph-container{overflow:initial}.radar-lines{stroke-width:var(--stroke-width,1px);stroke:${y}}.rings{fill:${"#E7F0FF"};
    stroke-width: var(--stroke-width, 1px);
    stroke: ${y}}.polygon{fill:${k};
    stroke-width: var(--stroke-width, 1px);
    stroke: ${"#3275F0"}}.points-active,.points-inactive{border-radius:23px;background:${m};
    fill: ${m}}.points-inactive{fill:${$};
    background: ${$}}.score-labels,score-label-top{color:rgba(0,0,0,0.86);font-size:var(--type-ramp-minus-2-font-size,10px);font-weight:600;max-width:60px;text-align:center;padding:4px;width:fit-content;overflow:visible}.score-label-top{display:flex;gap:8px}.score-label-container{position:relative;width:fit-content}.insights-container{flex-direction:column;justify-content:center;width:100%;align-self:stretch;max-width:250px}.category-insights-row{flex-direction:row;width:100%}.icons-container,.category-insights-row,.insights-container{display:flex;align-items:center;gap:6px}.insight-icon{width:16px;height:16px;display:block}.category-score-label{color:rgba(0,0,0,0.56);font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-plus-1-line-height,22px)}.insight-statement{overflow:hidden;color:rgba(0,0,0,0.86);text-overflow:ellipsis;font-size:var(--type-ramp-minus-1-font-size,12px);;font-weight:600;width:100%;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.segment-path{fill:transparent;stroke:transparent;stroke-width:var(--stroke-width,1px);cursor:pointer;transition:all 0.2s ease}.segment-path-active{stroke-width:var(--focus-stroke-width,2px);stroke:${m};fill:transparent}.segment-path-inactive{fill:${"rgba(255, 255, 255, 0.81)"};stroke:transparent;stroke-width:var(--stroke-width,1px)}.category-text-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#000;font-size:var(--type-ramp-base-font-size,14px);font-weight:700;line-height:var(--type-ramp-plus-1-line-height,22px)}.chevron-icon{filter:invert(var(--iconInvert,0))}`.withBehaviors((0,w.G2)(A));var C=e(96950),M=e(60402),I=e(39957),S=e(69259);const T=C.qy`<div class="wrapper"><svg class="graph-container" ${(0,M.K)("graphContainer")}></svg><div class="insights-container"><div class="category-insights-row"><span class="category-text-label" title="${t=>t.categoryText}" aria-label="${t=>t.categoryText}">${t=>t.categoryText}</span><span class="category-score-label" title="${t=>t.categoryScore}" aria-label="${t=>t.categoryScore}">${t=>t.categoryScore}</span><div class="icons-container">${(0,I.ux)(t=>t.insightIcons,C.qy`<img src="${t=>t.src}" class="insight-icon"> `)}<img src="${t=>t.chevronIcon.src}" class="chevron-icon"></div></div><div class="insight-statement" title="${t=>t.insightStatement}" aria-label="${t=>t.insightStatement}">${t=>t.insightStatement}</div></div></div>`,_=C.qy`<a href="${t=>{var r;return null===(r=t.viewModel)||void 0===r?void 0:r.destinationUrl}}" target="_blank" data-t="${t=>{var r;return null===(r=t.viewModel)||void 0===r?void 0:r.telemetryTag}}">${T}</a>`,E=C.qy` ${(0,S.z)(t=>t&&t.viewModel,_)}
`;let N=class extends p{};N=(0,n.Cg)([(0,v.E)({name:"radar-graph",template:E,styles:z,shadowOptions:{delegatesFocus:!0}})],N)},62240(t,r,e){function n(){return[]}function i(t){return null==t?n:function(){return this.querySelectorAll(t)}}e.d(r,{A(){return i}})},83037(t,r,e){e.d(r,{LN(){return J},Ay(){return tt},zr(){return W}});var n=e(34271),i=e(62240),a=e(32598);function s(t){return new Array(t.length)}function o(t,r){this.ownerDocument=t.ownerDocument,this.namespaceURI=t.namespaceURI,this._next=null,this._parent=t,this.__data__=r}function h(t,r,e,n,i,a){for(var s,h=0,l=r.length,c=a.length;h<c;++h)(s=r[h])?(s.__data__=a[h],n[h]=s):e[h]=new o(t,a[h]);for(;h<l;++h)(s=r[h])&&(i[h]=s)}function l(t,r,e,n,i,a,s){var h,l,c,u={},d=r.length,f=a.length,g=new Array(d);for(h=0;h<d;++h)(l=r[h])&&(g[h]=c="$"+s.call(l,l.__data__,h,r),c in u?i[h]=l:u[c]=l);for(h=0;h<f;++h)(l=u[c="$"+s.call(t,a[h],h,a)])?(n[h]=l,l.__data__=a[h],u[c]=null):e[h]=new o(t,a[h]);for(h=0;h<d;++h)(l=r[h])&&u[g[h]]===l&&(i[h]=l)}function c(t,r){return t<r?-1:t>r?1:t>=r?0:NaN}o.prototype={constructor:o,appendChild(t){return this._parent.insertBefore(t,this._next)},insertBefore(t,r){return this._parent.insertBefore(t,r)},querySelector(t){return this._parent.querySelector(t)},querySelectorAll(t){return this._parent.querySelectorAll(t)}};var u=e(39435);function d(t){return function(){this.removeAttribute(t)}}function f(t){return function(){this.removeAttributeNS(t.space,t.local)}}function g(t,r){return function(){this.setAttribute(t,r)}}function p(t,r){return function(){this.setAttributeNS(t.space,t.local,r)}}function v(t,r){return function(){var e=r.apply(this,arguments);null==e?this.removeAttribute(t):this.setAttribute(t,e)}}function b(t,r){return function(){var e=r.apply(this,arguments);null==e?this.removeAttributeNS(t.space,t.local):this.setAttributeNS(t.space,t.local,e)}}var w=e(39111);function x(t){return function(){delete this[t]}}function y(t,r){return function(){this[t]=r}}function m(t,r){return function(){var e=r.apply(this,arguments);null==e?delete this[t]:this[t]=e}}function $(t){return t.trim().split(/^|\s+/)}function k(t){return t.classList||new A(t)}function A(t){this._node=t,this._names=$(t.getAttribute("class")||"")}function z(t,r){for(var e=k(t),n=-1,i=r.length;++n<i;)e.add(r[n])}function C(t,r){for(var e=k(t),n=-1,i=r.length;++n<i;)e.remove(r[n])}function M(t){return function(){z(this,t)}}function I(t){return function(){C(this,t)}}function S(t,r){return function(){(r.apply(this,arguments)?z:C)(this,t)}}function T(){this.textContent=""}function _(t){return function(){this.textContent=t}}function E(t){return function(){var r=t.apply(this,arguments);this.textContent=null==r?"":r}}function N(){this.innerHTML=""}function L(t){return function(){this.innerHTML=t}}function F(t){return function(){var r=t.apply(this,arguments);this.innerHTML=null==r?"":r}}function O(){this.nextSibling&&this.parentNode.appendChild(this)}function D(){this.previousSibling&&this.parentNode.insertBefore(this,this.parentNode.firstChild)}A.prototype={add(t){this._names.indexOf(t)<0&&(this._names.push(t),this._node.setAttribute("class",this._names.join(" ")))},remove(t){var r=this._names.indexOf(t);r>=0&&(this._names.splice(r,1),this._node.setAttribute("class",this._names.join(" ")))},contains(t){return this._names.indexOf(t)>=0}};var R=e(39006);function j(t){return function(){var r=this.ownerDocument,e=this.namespaceURI;return e===R.g&&r.documentElement.namespaceURI===R.g?r.createElement(t):r.createElementNS(e,t)}}function P(t){return function(){return this.ownerDocument.createElementNS(t.space,t.local)}}function X(t){var r=(0,u.A)(t);return(r.local?P:j)(r)}function Y(){return null}function q(){var t=this.parentNode;t&&t.removeChild(this)}function B(){var t=this.cloneNode(!1),r=this.parentNode;return r?r.insertBefore(t,this.nextSibling):t}function G(){var t=this.cloneNode(!0),r=this.parentNode;return r?r.insertBefore(t,this.nextSibling):t}var H=e(27616),U=e(8698);function Q(t,r,e){var n=(0,U.A)(t),i=n.CustomEvent;"function"==typeof i?i=new i(r,e):(i=n.document.createEvent("Event"),e?(i.initEvent(r,e.bubbles,e.cancelable),i.detail=e.detail):i.initEvent(r,!1,!1)),t.dispatchEvent(i)}function Z(t,r){return function(){return Q(this,t,r)}}function V(t,r){return function(){return Q(this,t,r.apply(this,arguments))}}var W=[null];function J(t,r){this._groups=t,this._parents=r}function K(){return new J([[document.documentElement]],W)}J.prototype=K.prototype={constructor:J,select(t){"function"!=typeof t&&(t=(0,n.A)(t));for(var r=this._groups,e=r.length,i=new Array(e),a=0;a<e;++a)for(var s,o,h=r[a],l=h.length,c=i[a]=new Array(l),u=0;u<l;++u)(s=h[u])&&(o=t.call(s,s.__data__,u,h))&&("__data__"in s&&(o.__data__=s.__data__),c[u]=o);return new J(i,this._parents)},selectAll(t){"function"!=typeof t&&(t=(0,i.A)(t));for(var r=this._groups,e=r.length,n=[],a=[],s=0;s<e;++s)for(var o,h=r[s],l=h.length,c=0;c<l;++c)(o=h[c])&&(n.push(t.call(o,o.__data__,c,h)),a.push(o));return new J(n,a)},filter(t){"function"!=typeof t&&(t=(0,a.A)(t));for(var r=this._groups,e=r.length,n=new Array(e),i=0;i<e;++i)for(var s,o=r[i],h=o.length,l=n[i]=[],c=0;c<h;++c)(s=o[c])&&t.call(s,s.__data__,c,o)&&l.push(s);return new J(n,this._parents)},data(t,r){if(!t)return v=new Array(this.size()),d=-1,this.each(function(t){v[++d]=t}),v;var e,n=r?l:h,i=this._parents,a=this._groups;"function"!=typeof t&&(e=t,t=function(){return e});for(var s=a.length,o=new Array(s),c=new Array(s),u=new Array(s),d=0;d<s;++d){var f=i[d],g=a[d],p=g.length,v=t.call(f,f&&f.__data__,d,i),b=v.length,w=c[d]=new Array(b),x=o[d]=new Array(b);n(f,g,w,x,u[d]=new Array(p),v,r);for(var y,m,$=0,k=0;$<b;++$)if(y=w[$]){for($>=k&&(k=$+1);!(m=x[k])&&++k<b;);y._next=m||null}}return(o=new J(o,i))._enter=c,o._exit=u,o},enter(){return new J(this._enter||this._groups.map(s),this._parents)},exit(){return new J(this._exit||this._groups.map(s),this._parents)},join(t,r,e){var n=this.enter(),i=this,a=this.exit();return n="function"==typeof t?t(n):n.append(t+""),null!=r&&(i=r(i)),null==e?a.remove():e(a),n&&i?n.merge(i).order():i},merge(t){for(var r=this._groups,e=t._groups,n=r.length,i=e.length,a=Math.min(n,i),s=new Array(n),o=0;o<a;++o)for(var h,l=r[o],c=e[o],u=l.length,d=s[o]=new Array(u),f=0;f<u;++f)(h=l[f]||c[f])&&(d[f]=h);for(;o<n;++o)s[o]=r[o];return new J(s,this._parents)},order(){for(var t=this._groups,r=-1,e=t.length;++r<e;)for(var n,i=t[r],a=i.length-1,s=i[a];--a>=0;)(n=i[a])&&(s&&4^n.compareDocumentPosition(s)&&s.parentNode.insertBefore(n,s),s=n);return this},sort(t){function r(r,e){return r&&e?t(r.__data__,e.__data__):!r-!e}t||(t=c);for(var e=this._groups,n=e.length,i=new Array(n),a=0;a<n;++a){for(var s,o=e[a],h=o.length,l=i[a]=new Array(h),u=0;u<h;++u)(s=o[u])&&(l[u]=s);l.sort(r)}return new J(i,this._parents).order()},call(){var t=arguments[0];return arguments[0]=this,t.apply(null,arguments),this},nodes(){var t=new Array(this.size()),r=-1;return this.each(function(){t[++r]=this}),t},node(){for(var t=this._groups,r=0,e=t.length;r<e;++r)for(var n=t[r],i=0,a=n.length;i<a;++i){var s=n[i];if(s)return s}return null},size(){var t=0;return this.each(function(){++t}),t},empty(){return!this.node()},each(t){for(var r=this._groups,e=0,n=r.length;e<n;++e)for(var i,a=r[e],s=0,o=a.length;s<o;++s)(i=a[s])&&t.call(i,i.__data__,s,a);return this},attr(t,r){var e=(0,u.A)(t);if(arguments.length<2){var n=this.node();return e.local?n.getAttributeNS(e.space,e.local):n.getAttribute(e)}return this.each((null==r?e.local?f:d:"function"==typeof r?e.local?b:v:e.local?p:g)(e,r))},style:w.A,property(t,r){return arguments.length>1?this.each((null==r?x:"function"==typeof r?m:y)(t,r)):this.node()[t]},classed(t,r){var e=$(t+"");if(arguments.length<2){for(var n=k(this.node()),i=-1,a=e.length;++i<a;)if(!n.contains(e[i]))return!1;return!0}return this.each(("function"==typeof r?S:r?M:I)(e,r))},text(t){return arguments.length?this.each(null==t?T:("function"==typeof t?E:_)(t)):this.node().textContent},html(t){return arguments.length?this.each(null==t?N:("function"==typeof t?F:L)(t)):this.node().innerHTML},raise(){return this.each(O)},lower(){return this.each(D)},append(t){var r="function"==typeof t?t:X(t);return this.select(function(){return this.appendChild(r.apply(this,arguments))})},insert(t,r){var e="function"==typeof t?t:X(t),i=null==r?Y:"function"==typeof r?r:(0,n.A)(r);return this.select(function(){return this.insertBefore(e.apply(this,arguments),i.apply(this,arguments)||null)})},remove(){return this.each(q)},clone(t){return this.select(t?G:B)},datum(t){return arguments.length?this.property("__data__",t):this.node().__data__},on:H.Ay,dispatch(t,r){return this.each(("function"==typeof r?V:Z)(t,r))}};var tt=K},84478(t,r,e){e.r(r),e.d(r,{RadarGraphTransformer(){return c}});var n=e(27208),i=e(96950),a=e(31157),s=e(22341),o=e(93552),h=e(86449);const l={width:248,height:150,radius:55,ringCount:7,SCORE_LABEL_TRANSITIONS:{valuation:{translateInX:-50,translateInY:-150},performance:{translateInX:-130,translateInY:-40},health:{translateInX:-140,translateInY:-70},growth:{translateInX:40,translateInY:-40},earnings:{translateInX:10,translateInY:-70}},rtlOffset:100,categoryOrder:[n.vh.valuation,n.vh.health,n.vh.performance,n.vh.growth,n.vh.earnings]};class c extends n.IB{constructor(){super(...arguments),this.getCircleRadiusArray=(t,r,e)=>{const n=(r-t)/e;return Array.from({length:e},(r,e)=>t+e*n)}}async transform(t){this.id=t.quoteId,this.isDarkModeTheme=(0,h.jJ)();const r=await this.getCurrentViewModel(t);return{viewTemplate:i.qy`
                <radar-graph
                    :viewModel="${r}"
                ></radar-graph>`}}rotatePoint(t,r,e,n,i){const a=Math.PI/180*e,s=Math.cos(a),o=Math.sin(a);return[s*(t-n)+o*(r-i)+n,s*(r-i)-o*(t-n)+i]}getPoints(t,r,e,n,i,a){const s=[];for(let o=0;o<e.length;o++){const h=360/e.length*o,[l,c]=this.rotatePoint(i,a-n*e[o],h,t/2,r/2);s.push([l,c])}return s}getCurrentViewModel(t){const{width:r,height:e,radius:i,rtlOffset:h,SCORE_LABEL_TRANSITIONS:c}=l,{quoteId:u,experienceName:d,destinationUrl:f}=t;if(!t.attributeScores||0===t.attributeScores.length)return(0,s.vV)(o.pV8,`RadarGraphTransformer: graph insight data is not provided for ${t.quoteId}`),{id:"",experienceName:"",width:0,height:0,radius:0,labelsMap:new Map,polygonPoints:[],pointsOnCircumference:[],radiusArray:[],destinationUrl:"",rtl:!1,telemetryTag:"",isDarkModeTheme:this.isDarkModeTheme,strings:{dataIsNotAvailable:this.transformerProvider.strings.dataIsNotAvailable}};const g=l.categoryOrder.flatMap(r=>t.attributeScores.filter(t=>t.key===r)),p=g.map(t=>t.score),v=new Array(t.attributeScores.length).fill(1),b=this.getPoints(r,e,p,i,r/2,e/2),w=this.getPoints(r,e,v,i,r/2,e/2),x=document.dir===a.O.rtl;let y=this.getCircleRadiusArray(0,i,l.ringCount);y.push(i),y=y.reverse();const m=g.map(t=>{const{key:r,majorText:e,minorText:n,insightStatement:i,goodEvaluationCount:a,badEvaluationCount:s,neutralEvaluationCount:o,noDataEvaluationCount:l}=t;return{key:r,majorText:e,minorText:n,translateInX:c[r].translateInX+(x?h:0),translateInY:c[r].translateInY,insightStatement:i,goodEvaluationCount:a,badEvaluationCount:s,neutralEvaluationCount:o,noDataEvaluationCount:l}});return{id:u,experienceName:d,width:r,height:e,radius:i,labelsMap:new Map(m.map(t=>[t.key,t])),polygonPoints:b,pointsOnCircumference:w,radiusArray:y,destinationUrl:f,rtl:x,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{name:n.CD.radarGraphClick,signature:t.signature,headline:t.destinationUrl}),isDarkModeTheme:this.isDarkModeTheme,strings:{dataIsNotAvailable:this.transformerProvider.strings.dataIsNotAvailable}}}}Promise.resolve().then(e.bind(e,53548))},92707(t,r,e){e.d(r,{z(){return h}});var n=e(56911),i=e(27208),a=e(60815),s=e(92011),o=e(31525);let h=class extends s.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return i.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const t=this.getState();t&&(t.subscribe(i.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),t.subscribe(i.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(i.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(i.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(i.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(t){}onChartDictChange(t){}onShowNotificationTextChange(t){}onQuoteItemDictChange(t){}onCardWidthChanged(t){}};(0,n.Cg)([a.sH],h.prototype,"viewModel",void 0),h=(0,n.Cg)([o.x],h)},96124(t,r){var e=Math.PI,n=2*e,i=1e-6,a=n-i;function s(){this._x0=this._y0=this._x1=this._y1=null,this._=""}function o(){return new s}s.prototype=o.prototype={constructor:s,moveTo(t,r){this._+="M"+(this._x0=this._x1=+t)+","+(this._y0=this._y1=+r)},closePath(){null!==this._x1&&(this._x1=this._x0,this._y1=this._y0,this._+="Z")},lineTo(t,r){this._+="L"+(this._x1=+t)+","+(this._y1=+r)},quadraticCurveTo(t,r,e,n){this._+="Q"+ +t+","+ +r+","+(this._x1=+e)+","+(this._y1=+n)},bezierCurveTo(t,r,e,n,i,a){this._+="C"+ +t+","+ +r+","+ +e+","+ +n+","+(this._x1=+i)+","+(this._y1=+a)},arcTo(t,r,n,a,s){t=+t,r=+r,n=+n,a=+a,s=+s;var o=this._x1,h=this._y1,l=n-t,c=a-r,u=o-t,d=h-r,f=u*u+d*d;if(s<0)throw new Error("negative radius: "+s);if(null===this._x1)this._+="M"+(this._x1=t)+","+(this._y1=r);else if(f>i)if(Math.abs(d*l-c*u)>i&&s){var g=n-o,p=a-h,v=l*l+c*c,b=g*g+p*p,w=Math.sqrt(v),x=Math.sqrt(f),y=s*Math.tan((e-Math.acos((v+f-b)/(2*w*x)))/2),m=y/x,$=y/w;Math.abs(m-1)>i&&(this._+="L"+(t+m*u)+","+(r+m*d)),this._+="A"+s+","+s+",0,0,"+ +(d*g>u*p)+","+(this._x1=t+$*l)+","+(this._y1=r+$*c)}else this._+="L"+(this._x1=t)+","+(this._y1=r);else;},arc(t,r,s,o,h,l){t=+t,r=+r,l=!!l;var c=(s=+s)*Math.cos(o),u=s*Math.sin(o),d=t+c,f=r+u,g=1^l,p=l?o-h:h-o;if(s<0)throw new Error("negative radius: "+s);null===this._x1?this._+="M"+d+","+f:(Math.abs(this._x1-d)>i||Math.abs(this._y1-f)>i)&&(this._+="L"+d+","+f),s&&(p<0&&(p=p%n+n),p>a?this._+="A"+s+","+s+",0,1,"+g+","+(t-c)+","+(r-u)+"A"+s+","+s+",0,1,"+g+","+(this._x1=d)+","+(this._y1=f):p>i&&(this._+="A"+s+","+s+",0,"+ +(p>=e)+","+g+","+(this._x1=t+s*Math.cos(h))+","+(this._y1=r+s*Math.sin(h))))},rect(t,r,e,n){this._+="M"+(this._x0=this._x1=+t)+","+(this._y0=this._y1=+r)+"h"+ +e+"v"+ +n+"h"+-e+"Z"},toString(){return this._}},r.A=o},99657(t,r,e){e.d(r,{D(){return s},I(){return a}});var n=e(45755);const{create:i}=n.G,a=i("sloppy-click-z-index",1),s=i("click-z-index",1)}}]);