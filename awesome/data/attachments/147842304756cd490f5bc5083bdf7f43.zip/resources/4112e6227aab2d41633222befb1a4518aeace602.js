"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["pill-wc"],{75261(t,i,o){o.d(i,{t(){return l}});var e=o(56911),r=o(60815),n=o(92011),s=o(38493);class l extends n.L{constructor(){super(...arguments),this.percentComplete=0}valueChanged(){this.updatePercentComplete()}minChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}maxChanged(){this.$fastController.isConnected&&this.updatePercentComplete()}connectedCallback(){super.connectedCallback(),this.updatePercentComplete()}updatePercentComplete(){const t="number"==typeof this.min?this.min:0,i="number"==typeof this.max?this.max:100,o="number"==typeof this.value?this.value:0,e=i-t;this.percentComplete=0===e?0:Math.fround((o-t)/e*100)}}(0,e.Cg)([(0,s.CF)({converter:s.R$}),(0,e.Sn)("design:type",Object)],l.prototype,"value",void 0),(0,e.Cg)([(0,s.CF)({converter:s.R$}),(0,e.Sn)("design:type",Number)],l.prototype,"min",void 0),(0,e.Cg)([(0,s.CF)({converter:s.R$}),(0,e.Sn)("design:type",Number)],l.prototype,"max",void 0),(0,e.Cg)([(0,s.CF)({mode:"boolean"}),(0,e.Sn)("design:type",Boolean)],l.prototype,"paused",void 0),(0,e.Cg)([r.sH,(0,e.Sn)("design:type",Number)],l.prototype,"percentComplete",void 0)},78340(t,i,o){o.d(i,{rh(){return n},z_(){return s}});let e=!0;const r=[];function n(t){e=t;for(const t of r)t(e)}function s(t){r.push(t)}},83079(t,i,o){o.d(i,{$L(){return r},e4(){return e},gH(){return n},kJ(){return l}});const e=78,r=50;let n;const s=[];function l(t){s.push(t)}},91677(t,i,o){o.r(i),o.d(i,{PillDesignProps(){return p},PillWC(){return B},PillWCStyles(){return lt},PillWCTemplate(){return L},Placement(){return r},ToolingInfo(){return at}});var e,r,n=o(99564),s=o(37180),l=o(56911),a=o(83079);!function(t){t.Refresh="Refresh"}(e||(e={})),function(t){t.top="top",t.inline="inline",t.topOfFeed="topOfFeed",t.bottom="bottom",t.aboveFeed="above"}(r||(r={}));const p={top:16,bottom:32,height:32,largeHeight:38,width:150,largeWidth:168,widthWithCloseButton:165,blackFill:"#212121",whiteFill:"#FFFFFF",hoverColorWithCloseButton:"#0481E0",closeButtonHoverColor:"#036AC4"};var h=o(50196),d=o(74998),c=o(58792),u=o(66198),g=o(30010),b=o(60815),f=o(12680),m=o(77367),v=o(39671),w=o(63124),x=o(78340),$=o(96900),k=o(17918),y=o(21297),C=o(26220),F=o(94043);class B extends v.U{constructor(){super(...arguments),this._placementInitialized=!1,this.lastScrollY=0,this.scrollDismissPix=600,this._placementHandler=(0,h.P)(this.placementHandler.bind(this),0),this._scrollDismissHandler=(0,h.P)(this.scrollDismissHandler.bind(this),0),this._showFeedRefreshingHandler=this.renderPillAndClick.bind(this),this._windowResizeHandler=this.onWindowResize.bind(this),this._feedRefreshEdHandler=this.feedRefreshEd.bind(this),this.RESIZE_EVENT_NAME="resize",this.REFRESH_FEED_EVENT_NAME="refreshfeed",this.isRuby=y.gR.isRuby,this.showOnFirstRender=!0,this.resetAbsoluteTimer=()=>{this.activityTimer&&window.clearTimeout(this.activityTimer),this.autoDismissTimer&&window.clearTimeout(this.autoDismissTimer),this.setAbsoluteTimer(),this.pillDataProps=null,window.removeEventListener("scroll",this._placementHandler),window.removeEventListener("dashboardscroll",this._scrollDismissHandler),window.removeEventListener("scroll",this._scrollDismissHandler),this.config.placement===r.bottom&&(this.isShow=!1)},this.handleStickeyHeaderChange=t=>{const{detail:i}=t,[o]=null==i?void 0:i.rootMargin.split(" ");this.controlStickyHeight=Number(null==o?void 0:o.slice(1,(null==o?void 0:o.length)-2)),this.placementHandler()},this.triggerRenderRefreshPill=()=>{this.config.controlStickyTop&&document.addEventListener("pageContentViewportUpdated",this.handleStickeyHeaderChange),(this.isProng2||this.config.forceRefreshForStalePrerender||null===d.Rb||void 0===d.Rb||!d.Rb.IsPrerender)&&this.setAbsoluteTimer(),this.initPlacement(),(0,a.kJ)(t=>{this.topStickyBreakpoint=t,this.placementHandler()})},this.setActivityTimer=t=>{if(!this.absoluteTimerDone)return;this.activityTimer&&window.clearTimeout(this.activityTimer);const i=()=>{var t,i;this.setActivityListener(!1),this.renderPill({...this.config,id:"1",pillType:e.Refresh,onClick:(t,i)=>this.clickHandler(t,i)}),this.absoluteTimerDone=!1,this.lastScrollY=window.scrollY,this.isProng2&&(null!==(t=this.config.refreshTime)&&void 0!==t&&t.autoDismissTimeInMs||this.config.onlyScrollDismiss)?(this.scrollDismissPix=-1,window.addEventListener("dashboardscroll",this._scrollDismissHandler)):window.addEventListener("scroll",this._scrollDismissHandler),window.addEventListener("scroll",this._placementHandler),null!==(i=this.config.refreshTime)&&void 0!==i&&i.autoDismissTimeInMs&&(this.autoDismissTimer=window.setTimeout(()=>{this.resetAbsoluteTimer()},this.config.refreshTime.autoDismissTimeInMs))};if(t)i();else{const t=this.activityTimeInMsOverride??(this.config.refreshTime&&this.config.refreshTime.activityTimeInMs);this.activityTimer=window.setTimeout(i,t||15e3)}},this.setActivityListener=t=>{const i=["click","scroll"],o=()=>this.setActivityTimer(!1);t?i.forEach(t=>window.addEventListener(t,o)):i.forEach(t=>window.removeEventListener(t,o))}}get bottomShowBreakpoint(){return this.pageHeight-this.topStickyBreakpoint}get showFadeBgForProng(){var t;return this.isProng2&&this.isRuby&&!(null!==(t=this.config)&&void 0!==t&&t.showAtBottom)}get disableScrollDismiss(){return!!this.isRuby&&(this.config.disableScrollDismiss||this.config.placement===r.inline)}get pillText(){return this.isRuby&&this.config.useNewPostsStr?this.strings.newPostsText:this.strings.refreshStoriesText}experienceConnected(){this.setRenderPillCallback(t=>{this.pillDataProps=t,this.placementHandler(),this.config.placement===r.bottom&&(0,x.rh)(this.isShow),this.updateTmplAndSendClientLog(t.pillType)}),(0,C.$N)().includes("citem=showRefPill")&&(this.absoluteTimeInMsOverride=1,this.activityTimeInMsOverride=1),this.isProng2="winWidgets"===c.T3.AppType,this.isProng1V2="windowsShellV2"===c.T3.AppType,this.showOnFirstRender=this.config.showOnFirstRender??!0,this.isEnterpriseAudience=this.getIsEnterprise(),this.isRuby&&this.config.useContrastColor&&(this.useContrastColor=!0),(this.isProng2?k.dT:$.e1)().then(()=>{this.triggerRenderRefreshPill()}),window.addEventListener("RefreshPillResetAbsoluteTimer",this.resetAbsoluteTimer)}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener(this.RESIZE_EVENT_NAME,this._windowResizeHandler),window.removeEventListener(this.REFRESH_FEED_EVENT_NAME,this._showFeedRefreshingHandler),window.removeEventListener("RefreshPillResetAbsoluteTimer",this.resetAbsoluteTimer),window.removeEventListener("scroll",this._scrollDismissHandler),window.removeEventListener("dashboardscroll",this._scrollDismissHandler),window.removeEventListener("scroll",this._placementHandler),this.isProng2&&window.removeEventListener("refreshFeedEd",this._feedRefreshEdHandler),this.config.controlStickyTop&&document.removeEventListener("pageContentViewportUpdated",this.handleStickeyHeaderChange)}shadowDomPopulated(){(0,u.KO)(g.u.pillWC,this.shadowRoot),window.addEventListener(this.REFRESH_FEED_EVENT_NAME,this._showFeedRefreshingHandler),this.isProng2&&window.addEventListener("refreshFeedEd",this._feedRefreshEdHandler),this.refreshButtonRef&&this.refreshButtonRef.focus()}initPlacement(){this.topStickyBreakpoint=this.getTopBreakpoint(),this.pageHeight=document.documentElement.clientHeight,this._placementInitialized||(this._placementInitialized=!0,window.addEventListener(this.RESIZE_EVENT_NAME,this._windowResizeHandler))}renderPill(t){this.renderPillCallback&&this.renderPillCallback(t)}renderPillAndClick(){this.renderPill({...this.config,id:"1",pillType:e.Refresh,onClick:(t,i)=>this.clickHandler(t,i)}),this.clickHandler(this,new MouseEvent("click"))}onWindowResize(){this.pageHeight=document.documentElement.clientHeight}feedRefreshEd(){this.pillDataProps||this.renderPill({...this.config,id:"1",pillType:e.Refresh,onClick:(t,i)=>this.clickHandler(t,i)})}setRenderPillCallback(t){this.renderPillCallback=t}placementHandler(){switch(this.topStickyBreakpoint||this.initPlacement(),this.config.placement){case r.top:if(0===this.topStickyBreakpoint||this.config.forcePageTopSticky)this.isSticky=!0;else{const t=this.config.controlStickyTop?this.controlStickyHeight:a.e4+a.$L;this.isSticky=scrollY>this.topStickyBreakpoint&&this.getDesktopFeedRect().top<=t}return;case r.bottom:return void(this.isShow=scrollY+this.bottomShowBreakpoint>p.bottom+p.height+a.e4+a.$L);case r.aboveFeed:case r.inline:default:return}}setAbsoluteTimer(){let t=arguments.length>0&&void 0!==arguments[0]&&arguments[0],i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0;this.absoluteTimerDone=!1,this.absoluteTimer&&window.clearTimeout(this.absoluteTimer);const o=t=>{this.absoluteTimerDone=!0,this.setActivityTimer(t),this.setActivityListener(!0)};if(t)o(!0);else{const t=this.absoluteTimeInMsOverride??(this.config.refreshTime&&this.config.refreshTime.absoluteTimeInMs),e=i||t||3e5;this.absoluteTimer=window.setTimeout(()=>o(!1),e)}}async clickHandler(t,i){i&&t&&(this.scrollToShowFeed(),this.$emit("refresh-button-clicked"),this.showSpinner=!0,await t.refreshCallback(),this.resetAbsoluteTimer(),this.showSpinner=!1,this.refreshButtonRef&&m.YT.sendActionEvent(this.refreshButtonRef),this.isProng2||this.isProng1V2?m.YT.sendPageView({page:{isAutoRefresh:!1}}):m.YT.sendPageView({page:{name:"IAR",isAutoRefresh:!1}}))}scrollDismissHandler(){this.config.disableReShowAfterDismiss||this.disableScrollDismiss||Math.abs(window.scrollY-this.lastScrollY)>this.scrollDismissPix&&this.resetAbsoluteTimer()}clickButtonDismissHandler(t){this.config.disableReShowAfterDismiss?this.pillDataProps=null:(this.resetAbsoluteTimer(),t.preventDefault())}isStickyChanged(t,i){this.isEnterpriseAudience&&this.config.placement===r.top&&this.enterpriseResizeHandler(i)}isShowChanged(t,i){this.config.placement===r.bottom&&((0,x.rh)(i),this.isEnterpriseAudience&&this.config.placement===r.bottom&&this.enterpriseResizeHandler(i))}enterpriseResizeHandler(t){const i=()=>{const t=this.getDesktopFeedRect();this.layoutProp={layoutLeft:t.left,layoutWidth:t.width}};t?(i(),window.addEventListener("resize",i)):window.removeEventListener("resize",i)}scrollToShowFeed(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:0;const i=this.getTopBreakpoint(),o=this.config.scrollTopPadding||0;if(i||0===i){const e=this.config.enableScrollToTop?0:i+t-o;window.scrollTo({top:e,behavior:"smooth"})}}getIsEnterprise(){return c.T3.CurrentRequestTargetScope&&"enterprise"===c.T3.CurrentRequestTargetScope.audienceMode}getExperienceType(){return f.P4y}getTopBreakpoint(){return this.config.enableDefaultTopStickyBp?this.getDesktopFeedRect().top+((0,F.S)()?window.scrollY:0):(0,w.lB)("top")||0}updateTmplAndSendClientLog(t){if(t===e.Refresh)m.YT.addOrUpdateTmplProperty("RefreshPillRender","1")}getStickyTopDistance(){return this.isSticky&&(this.config.customStickyOffsetTop||0===this.config.customStickyOffsetTop)?`top:${this.config.customStickyOffsetTop}px;`:""+(this.isSticky&&this.config.controlStickyTop?`top:${this.controlStickyHeight+16}px;`:"")}}(0,l.Cg)([b.sH],B.prototype,"useContrastColor",void 0),(0,l.Cg)([b.sH],B.prototype,"pillDataProps",void 0),(0,l.Cg)([b.sH],B.prototype,"isSticky",void 0),(0,l.Cg)([b.sH],B.prototype,"controlStickyHeight",void 0),(0,l.Cg)([b.sH],B.prototype,"isShow",void 0),(0,l.Cg)([b.sH],B.prototype,"layoutProp",void 0),(0,l.Cg)([b.sH],B.prototype,"pageHeight",void 0),(0,l.Cg)([b.sH],B.prototype,"topStickyBreakpoint",void 0),(0,l.Cg)([b.sH],B.prototype,"showSpinner",void 0),(0,l.Cg)([b.sH],B.prototype,"isProng2",void 0),(0,l.Cg)([b.sH],B.prototype,"isProng1V2",void 0),(0,l.Cg)([b.sH],B.prototype,"isRuby",void 0),(0,l.Cg)([b.sH],B.prototype,"showOnFirstRender",void 0),(0,l.Cg)([b.Jg],B.prototype,"bottomShowBreakpoint",null),(0,l.Cg)([b.Jg],B.prototype,"showFadeBgForProng",null);var _=o(96950),S=o(69259),P=o(60402),H=o(66591),R=o(63250),T=o(85349),z=o(41065);o(19359);const E=()=>(0,z.N)("RefreshStoriesPill",T.MS.Refresh).getMetadataTag(),A=()=>(0,z.N)("closePillButton",T.MS.Close).getMetadataTag(),D=_.qy`<img src="${(0,c.rA)().StaticsUrl}latest/fluent-icons/arrow_clockwise_20_filled.svg"></img>`,W=t=>_.qy`
${(0,S.z)(t=>t.isRuby,D,(t=>{return _.qy`
${_.qy.partial((i="12",o="white"===t.config.color?p.blackFill:p.whiteFill,`<svg width="${i}" height="${i}" viewBox="0 0 12 12" fill="${o}" xmlns="http://www.w3.org/2000/svg"><path d="M7.59962 0.222652C8.24805 0.398433 8.8418 0.672847 9.38086 1.0459C9.91992 1.41894 10.3838 1.86035 10.7725 2.37011C11.1611 2.87988 11.4629 3.44433 11.6777 4.06347C11.8926 4.68261 12 5.32812 12 6C12 6.55078 11.9287 7.08203 11.7861 7.59375C11.6436 8.10547 11.4424 8.58398 11.1826 9.02929C10.9229 9.4746 10.6104 9.87988 10.2451 10.2451C9.87988 10.6103 9.47461 10.9228 9.0293 11.1826C8.58399 11.4424 8.10547 11.6435 7.59375 11.7861C7.08203 11.9287 6.55078 12 6 12C5.44922 12 4.91797 11.9287 4.40625 11.7861C3.89453 11.6435 3.41601 11.4424 2.9707 11.1826C2.52539 10.9228 2.12012 10.6103 1.75488 10.2451C1.38965 9.87988 1.07715 9.4746 0.817383 9.02929C0.557617 8.58398 0.356447 8.10644 0.213867 7.59668C0.0712892 7.08691 0 6.55469 0 6C0 5.45312 0.0722656 4.92188 0.216797 4.40625C0.361328 3.89063 0.567383 3.40527 0.83496 2.95019C1.10254 2.49512 1.42773 2.08105 1.81054 1.70801C2.19336 1.33496 2.625 1.01562 3.10546 0.75H1.5V0H4.49999V3H3.74999V1.25976C3.29296 1.47851 2.87988 1.75293 2.51074 2.08301C2.1416 2.41308 1.82617 2.78418 1.56445 3.19629C1.30273 3.60839 1.10156 4.05273 0.960936 4.52929C0.820311 5.00586 0.749999 5.49609 0.749999 6C0.749999 6.48046 0.812499 6.94433 0.937499 7.39159C1.0625 7.83886 1.23926 8.25683 1.46777 8.6455C1.69629 9.03417 1.9707 9.38867 2.29101 9.70898C2.61133 10.0293 2.96582 10.3037 3.35449 10.5322C3.74316 10.7607 4.16015 10.9375 4.60546 11.0625C5.05078 11.1875 5.51562 11.25 6 11.25C6.48046 11.25 6.94433 11.1875 7.39159 11.0625C7.83886 10.9375 8.25683 10.7607 8.6455 10.5322C9.03417 10.3037 9.38867 10.0293 9.70898 9.70898C10.0293 9.38867 10.3037 9.03417 10.5322 8.6455C10.7607 8.25683 10.9375 7.83984 11.0625 7.39453C11.1875 6.94922 11.25 6.48437 11.25 6C11.25 5.41406 11.1553 4.8496 10.9658 4.30664C10.7764 3.76367 10.5117 3.26953 10.1719 2.82422C9.83203 2.37891 9.42675 1.99316 8.95605 1.66699C8.48535 1.34082 7.96679 1.09961 7.40039 0.943359L7.59962 0.222652Z"/></svg>`))}
`;var i,o})(t))}<span class="text" aria-hidden="true">${t.pillText}</span>`,V=t=>_.qy`<fluent-button class="close" tabindex="0" title="${t.strings.clickToCloseTooltip}" data-t="${()=>A()}" @click="${(t,i)=>t.clickButtonDismissHandler(i.event)}" aria-label="${t.strings.clickToCloseTooltip}">${_.qy.partial(R.A)}</fluent-button>`,M=_.qy`<div class="pill-ruby-fade-bg"><div class="fade-bg"></div></div>`,j=t=>_.qy`<div class="pill-root-wrapper ${t=>`${t.config.placement||""} ${t.config.color||""} ${t.config.placement===r.top&&t.isSticky?"pill_sticky":""} ${t.config.placement===r.topOfFeed?" pill_top_of_feed pill_sticky top":""} ${t.config.placement!==r.bottom||t.isShow?"":"hide"} ${t.config.usingLayouts?"layouts":""} ${t.config.stickyHeaderDisabled?"no_header":""} ${t.isProng2?"pr2":""} ${t.hasRailSectionProng2?"pr2rail":""} ${t.isProng2&&t.isRuby?"pr2ruby":""} ${t.config.showAtBottom?"show_bottom":""} `}" tabindex="${t=>t.isRuby?"-1":"0"}" style="${t.getStickyTopDistance()} ${t.showOnFirstRender?"":"display: none;"}"><output role="alert" aria-label="${t.strings.refreshButtonAriaLabel}">${(t=>_.qy`<fluent-button class="pill-root" part="pill-root" title="${t.strings.clickToRefreshTooltip}" data-t="${()=>E()}" ?data-nopartialcontentview="${t=>t.config.noPartialContentView}" @click="${(i,o)=>{var e;let{event:r}=o;return null===(e=t.pillDataProps)||void 0===e?void 0:e.onClick(i,r)}}" data-customhandled="true" ${(0,P.K)("refreshButtonRef")}><div class="pill-content">${(0,S.z)(t=>t.showSpinner,_.qy`<fluent-progress-ring class="spinner"></fluent-progress-ring><span class="text">${t.strings.spinnerText}</span>`)} ${(0,S.z)(t=>!t.showSpinner,W(t))}</div></fluent-button>`)(t)}</output>${(0,S.z)(t=>!t.isRuby,V)}</div>`,I=t=>_.qy` ${t=>t.showFadeBgForProng?_.qy`<div class="${t=>{var i,o;return(0,H.x)("pill-root-with-fade-bg",["top-pr2ruby",!(null===(i=t.config)||void 0===i||!i.enableWidgetsBelowHeader)],["offset-header",!(null===(o=t.config)||void 0===o||!o.enableWidgetsOffsetHeader)])}}">${M} ${t=>j(t)}</div>`:j(t)}
`,L=_.qy`${t=>{var i;return(null==t||null===(i=t.pillDataProps)||void 0===i?void 0:i.pillType)===e.Refresh?I():""}}`;var N=o(86856),O=o(50882),X=o(22131),Y=o(4126),U=o(77558),J=o(74849),Z=o(32257),q=o(29222),G=o(87204);const K=()=>a.e4+a.$L+p.top+"px",Q=J.A` .close{right:0}`,tt=J.A` .close{left:0}.pill-content-see-more > svg{transform:rotateY(180deg)}div.pill_sticky.layouts.pr2.pr2rail{left:calc((100% - 340px) / 2)}`,it=J.A` .scroll-for-more-pill-root{background:#0F6CBD}.scroll-for-more-pill-root:hover{background:#115EA3}.scroll-more-button:active{background:#0C3B5E}`,ot=J.A` .scroll-for-more-pill-root{background:#115EA3}.scroll-for-more-pill-root:hover{background:#0F6CBD}.scroll-more-button:active{background:#0C3B5E}`,et=J.A` :host{--focus-inner-ring:#000000;--focus-outer-ring:#FFFFFF}fluent-button img{filter:invert(1)}.pill-root-with-fade-bg .fade-bg{background:#000000;mask-image:linear-gradient(180deg,rgba(0,0,0,0.8) 0%,rgba(0,0,0,0) 100%)}.pill-root-with-fade-bg.top-pr2ruby .fade-bg{background:#0E111B;mask-image:linear-gradient(180deg,#000000 0%,rgba(0,0,0,0) 100%)}`,rt=J.A` output fluent-button::part(control){border:none;outline:1px solid ${O.A.ButtonText}}output fluent-button::part(control):focus-visible{outline:3px solid ${O.A.Highlight};outline-offset:2px;box-shadow:none}@media (prefers-color-scheme:light){fluent-button img{filter:invert(0)}}`,nt=J.A`
@media (prefers-color-scheme:light){.pill-root-wrapper,.pill-root-wrapper:hover{background:${Z.B96}}.pill-root-wrapper:active{background:${Z.ZOj}}fluent-button,fluent-button:hover{color:${q.zrv}}fluent-button:active{color:${Z.Sl}}.pill-root-wrapper:active fluent-button.pill-root img,fluent-button:active.pill-root img{filter:invert(0.65)}fluent-button.pill-root img,fluent-button:hover.pill-root img{filter:invert(1)}}@media (prefers-color-scheme:dark){.pill-root-wrapper,.pill-root-wrapper:hover{background:${Z.C6c}}.pill-root-wrapper:active{background:${q.O7O}}fluent-button,fluent-button:hover{color:${Z.Hlm}}fluent-button:active{color:${Z.bp5}}.pill-root-wrapper:active fluent-button.pill-root img,fluent-button:active.pill-root img{filter:invert(0.2)}fluent-button.pill-root img,fluent-button:hover.pill-root img{filter:invert(0)}}`,st=J.A` .pill-root-wrapper{background:${Z.xX5};
        box-shadow: ${G.iN};
        border-radius: ${q.y8E};height:auto;width:auto;border:none}.pill-root-wrapper:hover{background:${Z.T7I}}.pill-root-wrapper:active{background:${Z.TN7}}.pill-root{min-height:${Z.xo8};min-width:162px}.pill-content{gap:${Z.jiC}}fluent-button{color:${Z.C6c};text-align:center;background-color:unset}fluent-button:active{color:${Z.otP}}fluent-button .text{font-size:${Z.N0T};
        line-height: ${Z.Q7d};
        padding: ${Z.ymw} ${q.mdD} ${Z.E6_} ${q.mdD};max-width:70%;overflow:hidden;text-overflow:ellipsis;margin:0px}fluent-button svg{width:20px;height:20px;vertical-align:middle}output{display:flex}output fluent-button::part(control){height:auto;padding:0px;border:none;border-radius:${q.y8E}}output fluent-button::part(control):focus-visible{outline:none;box-shadow:0 0 0 2px var(--focus-inner-ring,#FFFFFF),0 0 0 4px var(--focus-outer-ring,#000000)}fluent-button::part(content){margin-bottom:0px}fluent-button.close img{vertical-align:middle}fluent-button.pill-root img{filter:${G.a1}}fluent-button.pill-root:active img{filter:${G.M}}.inline{--position:relative;--top:0px;max-width:100%}.pill-root-with-fade-bg{position:fixed;width:var(--pill-fade-bg-width,100vw);height:240px;top:92px;left:50%;transform:translateX(-50%);border-radius:36px;z-index:${(U.P.Nav+1).toString()};pointer-events:none;overflow:hidden;margin-left:-3px}.pill-root-with-fade-bg .pill-root-wrapper{position:absolute;left:50%;transform:translateX(-50%);pointer-events:auto}.pill-root-with-fade-bg .pill-ruby-fade-bg{width:100%;height:100%;position:absolute;top:-1px}.pill-root-with-fade-bg .fade-bg{position:absolute;left:0px;top:0px;height:100%;width:100%;background:#FFFFFF;mask-image:linear-gradient(180deg,rgba(0,0,0,0.8) 0%,rgba(0,0,0,0) 100%);mask-repeat:no-repeat;mask-size:contain;mask-position:center;mask-mode:alpha}.pill-root-with-fade-bg .pill-root{min-width:140px;min-height:40px}.pill-root-with-fade-bg .pill-content .text{font-size:${Z.e1r};line-height:100%}.pill-root-with-fade-bg div.pill_sticky.layouts.pr2.pr2ruby{top:24px;margin-top:0}.pill-root-with-fade-bg.top-pr2ruby{top:0;width:100vw;height:160px;border-radius:0}.pill-root-with-fade-bg.top-pr2ruby .fade-bg{background:#FFFBF8;mask-image:linear-gradient(180deg,#000000 0%,rgba(0,0,0,0) 100%)}.pill-root-with-fade-bg.top-pr2ruby div.pill_sticky.layouts.pr2.pr2ruby{top:26px;margin-top:0}.pill-root-with-fade-bg.offset-header{top:67px}.pill-root-with-fade-bg.top-pr2ruby.offset-header{top:0}.pill-root-with-fade-bg.top-pr2ruby.offset-header div.pill_sticky.layouts.pr2.pr2ruby{top:10px}`.withBehaviors((0,X.G2)(et),(0,X.mr)(rt)),lt=J.A` :host{--commonHeaderTop:146px;--commonHeaderStackedTop:199px}.pill-root-wrapper{box-sizing:border-box;z-index:${(U.P.Nav+1).toString()};
        max-width: 95%;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        border-radius: 20px;

        position: var(--position);
        top: var(--top);
        left: var(--left, 50%);
        bottom: var(--bottom);
        height: var(--height, ${p.height+"px"});transform:var(--transform,translate(-50%,0));margin:var(--margin);border:var(--border,1px solid #000000);box-shadow:var(--boxShadow,0px 6px 4px rgba(0,0,0,0.25));background:var(--bgColor);color:var(--color,#000000)}.pill-root-wrapper:hover{background:var(--hoverBgColor,#F2f2F2)}div.pill_sticky{position:fixed}div.pill_top_of_feed.layouts{top:40px !important}div.pill_sticky.layouts.pr2{top:auto;margin-top:${p.top+"px"}}div.pill_sticky.layouts.pr2.pr2rail{left:calc((100% + 340px) / 2)}div.pill_sticky.layouts.pr2.pr2ruby{width:fit-content;margin-inline-start:auto;margin-inline-end:auto;top:${p.top+"px"};transform:translateX(-50%)}div.pill_sticky.layouts.pr2.pr2ruby.show_bottom{bottom:12px;top:unset;box-shadow:0px 4px 6px rgba(0,0,0,0.08),0px 1px 3px rgba(0,0,0,0.08)}div.pill_sticky.layouts.show_bottom{bottom:12px;top:unset}div.pill_sticky.layouts{top:${K()}}div.pill_sticky.layouts.no_header{top:16px}div.hide{display:none}.top{--position:absolute;--top:${p.top+"px"}}.bottom{--position:fixed;--top:auto;--bottom:${p.bottom+"px"}}.above{--position:sticky;--left:auto;--margin:8px auto 12px auto;--transform:none}.above.layouts{--top:${K()}}.white{--bgColor:#FFFFFF}.blue{--bgColor:#0078D4;--color:#FFFFFF;--border:none;--boxShadow:0px 4px 4px rgba(0,0,0,0.25);--hoverBgColor:#006CBE}.channel-theme-color{--bgColor:var(--channelBtnBgColor,#0078D4);--color:#FFFFFF;--border:none;--boxShadow:0px 4px 4px rgba(0,0,0,0.25);--hoverBgColor:var(--channelBtnBgColor,#006CBE)}.large{--width:${p.largeWidth+"px"};
        --height: ${p.largeHeight+"px"};--border:1px solid rgba(0,0,0,0.49);--boxShadow:0px 4px 4px rgba(0,0,0,0.25);--fontSize:16px;--lineHeight:22px;--hoverBgColor:#F7F7F7;--contentMarginBottom:6px}output{width:100%}fluent-button{font-size:var(--fontSize,12px);line-height:var(--lineHeight,16px);color:var(--color,#000000);background-color:unset}.pill-root{min-width:var(--width,${p.width+"px"})}.pill-content,.pill-content-see-more{display:flex;justify-content:center;align-items:center;vertical-align:middle}fluent-button .text{vertical-align:middle;margin-inline-start:4px}fluent-button svg{width:unset;height:unset;vertical-align:middle}fluent-button::part(control){display:inline-block;padding:0px 2px;width:100%}fluent-button::part(content){margin-bottom:var(--contentMarginBottom,3px)}@media (max-width:956px){div.pill_sticky{top:var(--commonHeaderStackedTop)}.above{--top:var(--commonHeaderStackedTop)}}@media (min-width:956px){div.pill_sticky{top:var(--commonHeaderTop)}.above{--top:var(--commonHeaderTop)}}.spinner{display:inline-block;width:14px;margin:0px;vertical-align:middle;position:relative;top:1px}.large .spinner{width:18px}.pill-root-wrapper{--width:${p.widthWithCloseButton+"px"}}.pill-root-wrapper:hover{background:${p.hoverColorWithCloseButton}}output fluent-button::part(control){padding:0 34px 0 32px}.close{display:none;width:32px;height:100%;text-align:center;border-radius:50%;position:absolute}:host(:hover) .close,:host(:focus-within) .close{display:inline-block;background:${p.closeButtonHoverColor}}.close svg{vertical-align:middle}.white:hover{background:#F2f2F2}.white:hover .close{background:rgba(16,16,16,0.2)}.channel-theme-color:hover{background:var(--hoverBgColor,#006CBE)}.channel-theme-color:hover .close{background:var(--hoverBgColor,#006CBE)}.scroll-for-more-pill-root{z-index:${(U.P.Nav+1).toString()};
        max-width: 95%;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
        border-radius: 100px;
        gap: 4px;

        position: var(--position);
        top: var(--top);
        left: var(--left, 50%);
        bottom: var(--bottom);
        height: var(--height, ${p.height+"px"});transform:var(--transform,translate(-50%,0));color:#FFFFFF}.scrollmore-pos{position:fixed;bottom:16px}.scroll-more-button{font-size:14px;line-height:20px;background-color:unset;color:#FFFFFF;border-radius:100px}output.scroll-more-output fluent-button::part(control){padding:5px 15px}.scroll-text{margin-inline-start:9px;font-weight:600}.see-more-text{font-weight:600;margin-inline-end:6px}`.withBehaviors(new N.t(Q,tt),new Y.o("isRuby",!0,st),(0,X.G2)(ot),(0,X.C7)(it),new Y.o("useContrastColor",!0,nt)),at={experienceConfigSchema:undefined};n.m.define(s.c.registry)},99564(t,i,o){o.d(i,{m(){return w}});var e=o(75261);class r extends e.t{}var n=o(37180),s=o(74849),l=o(64187),a=o(22131),p=o(50882),h=o(48196),d=o(37302),c=o(4283),u=o(64003);const g=s.A`
    ${(0,l.V)("flex")} :host {
        align-items: center;
        outline: none;
        height: calc(${h.D} * 1px);
        width: calc(${h.D} * 1px);
        margin: calc(${h.D} * 1px) 0;
    }

    .progress {
        height: 100%;
        width: 100%;
    }

    .background {
        stroke: ${d.F7};
        fill: none;
        stroke-width: 2px;
    }

    .determinate {
        stroke: ${c.IR};
        fill: none;
        stroke-width: 2px;
        stroke-linecap: round;
        transform-origin: 50% 50%;
        transform: rotate(-90deg);
        transition: all 0.2s ease-in-out;
    }

    .indeterminate-indicator-1 {
        stroke: ${c.IR};
        fill: none;
        stroke-width: 2px;
        stroke-linecap: round;
        transform-origin: 50% 50%;
        transform: rotate(-90deg);
        transition: all 0.2s ease-in-out;
        animation: spin-infinite 2s linear infinite;
    }

    :host([paused]) .indeterminate-indicator-1 {
        animation-play-state: paused;
        stroke: ${d.F7};
    }

    :host([paused]) .determinate {
        stroke: ${u.c};
    }

    @keyframes spin-infinite {
        0% {
            stroke-dasharray: 0.01px 43.97px;
            transform: rotate(0deg);
        }
        50% {
            stroke-dasharray: 21.99px 21.99px;
            transform: rotate(450deg);
        }
        100% {
            stroke-dasharray: 0.01px 43.97px;
            transform: rotate(1080deg);
        }
    }
`.withBehaviors((0,a.mr)(s.A`
            .indeterminate-indicator-1,
            .determinate {
                stroke: ${p.A.FieldText};
            }
            .background {
                stroke: ${p.A.Field};
            }
            :host([paused]) .indeterminate-indicator-1 {
                stroke: ${p.A.Field};
            }
            :host([paused]) .determinate {
                stroke: ${p.A.GrayText};
            }
        `));var b=o(96950),f=o(69259),m=o(18893);const v=function(t={}){return b.qy`
        <template
            role="progressbar"
            aria-valuenow="${t=>t.value}"
            aria-valuemin="${t=>t.min}"
            aria-valuemax="${t=>t.max}"
        >
            ${(0,f.z)(t=>"number"==typeof t.value,b.qy`
                    <svg
                        class="progress"
                        part="progress"
                        viewBox="0 0 16 16"
                        slot="determinate"
                    >
                        <circle
                            class="background"
                            part="background"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                        <circle
                            class="determinate"
                            part="determinate"
                            style="stroke-dasharray: ${t=>44*t.percentComplete/100+"px 44px"}"
                            cx="8px"
                            cy="8px"
                            r="7px"
                        ></circle>
                    </svg>
                `,b.qy`
                    <slot name="indeterminate">
                        ${(0,m.R)(t.indeterminateIndicator)}
                    </slot>
                `)}
        </template>
    `}({indeterminateIndicator:b.qy`
        <svg class="progress" part="progress" viewBox="0 0 16 16">
            <circle
                class="background"
                part="background"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
            <circle
                class="indeterminate-indicator-1"
                part="indeterminate-indicator-1"
                cx="8px"
                cy="8px"
                r="7px"
            ></circle>
        </svg>
    `}),w=r.compose({name:`${n.c.prefix}-progress-ring`,template:v,styles:g})}}]);