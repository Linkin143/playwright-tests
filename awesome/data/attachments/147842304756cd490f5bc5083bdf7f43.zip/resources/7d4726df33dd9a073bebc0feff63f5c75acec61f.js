"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["experiences_travel-sd-carrentals-card_dist_index_js","travel-sd-flights-card"],{4968(r,e,i){i.d(e,{f(){return d}});var a=i(64187),t=i(74849),l=i(42792),n=i(99657),o=i(36452);const d=t.A.partial`position: relative; z-index: ${n.D};`;t.A`
    ${l.e}
    ${l.nH}

    ${(0,a.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${d}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${o.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${o.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${o.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(l.kc)},29709(r,e,i){i.d(e,{d(){return n},w(){return l}});var a=i(85349),t=i(69242);const l={Root:(0,t.Yz)("TravelDestinationCard",void 0,void 0,a.MJ.Module),Card:{...(0,t.Yz)("TravelItem"),triggerPageView:!0},CarRentalBase:(0,t.Yz)("TravelSdCarrentalsCard",void 0,void 0,a.MJ.Module),ThemesCard:(0,t.Yz)("ThemesCard"),DestinationsCard:(0,t.Yz)("DestinationsCard"),FlightsCard:(0,t.Yz)("FlightsCard"),FlightsCardList:(0,t.Yz)("FlightsCardList"),CarrentalsCard:(0,t.Yz)("CarrentalsCard"),CarrentalsCardList:(0,t.Yz)("CarrentalsCardList"),HotelsCard:(0,t.Yz)("HotelsCard"),SurpriseMeCard:(0,t.Yz)("SurpriseMeCard"),Options:(0,t.Yz)("CardActionEllipsis",a.MS.More),MoreSettings:(0,t.Yz)("MoreSettings"),HideCard:(0,t.Yz)("TravelDestinationCard_Options_HideCard",a.MS.Hide),Header:(0,t.Yz)("Header"),PrevSlide:(0,t.Yz)("PrevSlide",a.MS.More),NextSlide:(0,t.Yz)("NextSlide",a.MS.More),CtaButton:(0,t.Yz)("CtaButton",a.MS.Navigate)},n={Root:(0,t.Yz)("TravelDestinationCarousel",void 0,void 0,a.MJ.Module),Card:{...(0,t.Yz)("TravelDestinationCarouselItem"),triggerPageView:!0},FlightsCarouselCard:(0,t.Yz)("FlightsCarouselCard"),HotelListCarousel:(0,t.Yz)("HotelListCarousel")}},32657(r,e,i){i.d(e,{H(){return d},U(){return o}});var a=i(85349),t=i(29709),l=i(19359);const n=(r,e)=>{if(null==r||!r.telemetryObject)return null;const i=((r,e)=>{const i=null==r?void 0:r.telemetryFields,t=Object.assign({},null==e?void 0:e.config);return t.content={id:t.name,vertical:"Travel",type:a.b5.StructuredData},i&&"object"==typeof i&&Object.keys(i).forEach(r=>{null!=i[r]&&null!=i[r]&&(t.content.id+=`|${r}:${i[r]}`)}),t.ext=r.ext,null!=e&&e.headline&&(t.content.headline=e.headline),null!=e&&e.url&&(t.destinationUrl=e.url),t})(r,e);return(0,l.l)(i.name,i.content,i.behavior,a.EG.Click,i.type,i.destinationUrl,i.ext)},o=(r,e,i,a,t,l)=>{return d={config:a,headline:t,url:l},null!=(o={telemetryFields:e,ext:i,telemetryObject:r})&&o.telemetryObject?n(o,d).getMetadataTag():null;var o,d},d=(r,e,i,a)=>n({telemetryFields:e,ext:i,telemetryObject:r},{config:a??t.w.Root})},46718(r,e,i){i.d(e,{Y(){return s},y(){return d}});var a=i(93552),t=i(22341),l=i(29658),n=i(71398);const o=async r=>{let e=!1;const i=[{cardType:l.s.TravelCard,enabled:!1}];try{e=await n.d.updateSegmentCardsEnableStatus(i)}catch(r){(0,t.c_)(r,a.N2u,`Fail to hide ${l.s.TravelCard} Card .`,`Failed with exception : ${r}`),e=!1}return e&&r&&r(),e};function d(r){var e,i,a,t,l,n;if(!r)return;return{actionMenuData:{items:null==r||null===(e=r.ActionMenuData)||void 0===e?void 0:e.Items,horizontalPosition:"end",followInterestsCallback:null===(i=r.ActionMenuData)||void 0===i?void 0:i.followInterestsCallback,hideCardCallback(){var e;return o(null===(e=r.ActionMenuData)||void 0===e?void 0:e.hideCardCallback)},manageInterestsCallback:null===(a=r.ActionMenuData)||void 0===a?void 0:a.manageInterestsCallback,moreSettingsPersonalizeCallback:null===(t=r.ActionMenuData)||void 0===t?void 0:t.moreSettingsPersonalizeCallback,strings:{followInterestsTitle:null===(l=r.ActionMenuData)||void 0===l||null===(l=l.strings)||void 0===l?void 0:l.followInterestsTitle,manageInterestsTitle:null===(n=r.ActionMenuData)||void 0===n||null===(n=n.strings)||void 0===n?void 0:n.manageInterestsTitle}},isActionMenuAvailable:r.IsActionMenuAvailable,headerLogo:r.Icon,telemetryHeadlines:{title:r.Text,logo:r.Text},telemetryDestinationUrl:{title:r.Link,logo:r.Link},title:r.Text,titleNavigationLink:r.Link,strings:{}}}function s(r,e,i,a){var t,l,n,o,s,c;if(!r)return;const v=d(null==r?void 0:r.Header),u=function(r,e,i,a){var t;if(null==r||!r.Footer)return;let l={};return r.Footer.CtaButton&&(l={...l,telemetryHeadlines:{footerLink:r.Footer.CtaButton.Text,footerButton:r.Footer.CtaButton.Text},footerLink:{text:r.Footer.CtaButton.Text,navigationUrl:r.Footer.CtaButton.Link,onClick:r.Footer.CtaButton.onClick}}),null!=r&&r.IsCarousel&&((null==r||null===(t=r.Slide)||void 0===t?void 0:t.Count)??0)>1&&(l.paginationData={currentPageIndex:e+1,onFlipperClick:a,pageCount:i}),l}(r,e,i,a),p=null==r?void 0:r.Card.TelemetryObject;return{id:"travel-card-carousel",childTemplateType:"travel-destination",cardSize:null===(t=r.Card)||void 0===t?void 0:t.Size,gridArea:"",headerData:v,footerData:u,parentTelemetryObject:p,imageData:{altText:null===(l=r.Card)||void 0===l||null===(l=l.FullBleed)||void 0===l?void 0:l.ImageAltText,source:null===(n=r.Card)||void 0===n||null===(n=n.FullBleed)||void 0===n?void 0:n.ImageSource},contextualFeedbackData:null!==(o=r.Card)&&void 0!==o&&null!==(o=o.WpoMetadata)&&void 0!==o&&o.isGA?{cFId:null===(s=r.Card)||void 0===s||null===(s=s.WpoMetadata)||void 0===s?void 0:s.cfId,cFMetadataType:null===(c=r.Card)||void 0===c||null===(c=c.WpoMetadata)||void 0===c?void 0:c.cFMetadataType}:null}}},68796(r,e,i){i.d(e,{Q(){return a}});const a={SlideHeight:"--slideHeight",SlideWidth:"--slideWidth",SlideGap:"--slideGap",ItemCount:"--itemCount",AnimationTime:"--animationTime",ContentWidth:"--contentWidth",CardBackground:"--card-background",CardBorderRadius:"--card-border-radius",CsSdCardHeight:"--csSdCardHeight",ForegroundColor:"--foreground-color"}},93752(r,e,i){i.d(e,{cF(){return C}});var a=i(56911),t=i(7574),l=i(92011),n=i(60815),o=i(46718),d=i(77367),s=i(31525);let c=class extends l.L{constructor(){super(...arguments),this._slideIndex=0,this.slideTransitionDisabled=!1}get _useDarkModeAlways(){var r,e;return((null===(r=this.data)||void 0===r||null===(r=r.Card)||void 0===r||null===(r=r.FullBleed)||void 0===r?void 0:r.UseDarkCardAlways)??!1)||((null===(e=this.data)||void 0===e||null===(e=e.Card)||void 0===e||null===(e=e.FullBleedGradient)||void 0===e?void 0:e.UseDarkCardAlways)??!1)}get _isImmersiveCard(){var r;return(null===(r=this.data)||void 0===r||null===(r=r.Card)||void 0===r||null===(r=r.FullBleedGradient)||void 0===r?void 0:r.IsImmersiveCard)??!1}get _overrideCsSdCardHeight(){var r;return(null===(r=this.data)||void 0===r||null===(r=r.Card)||void 0===r?void 0:r.OverrideCsSdCardHeight)??!1}connected(){this.getbackground()}dataChanged(){this.getbackground()}get superCardData(){return(0,o.Y)(this.data,this._slideIndex,this._slideCount,r=>this.changeSlide(r))}changeSlide(r){var e,i,a,t;const l=r?1:-1;if(null===(e=this.data)||void 0===e||!e.IsCarousel||this.slideTransitionDisabled)return;this.slideTransitionDisabled=!0;const n=(this._slideIndex+l+this._slideCount)%this._slideCount;null!==(i=this._slidesElement)&&void 0!==i&&i.style&&(this._slidesElement.style.marginInlineStart=this.getSlideMarginLeftForIndex(n)+"px"),window.setTimeout(()=>{this.slideTransitionDisabled=!1,d.YT.sendContentViewEvent(this._carouselElement)},null===(a=this.data)||void 0===a||null===(a=a.Slide)||void 0===a?void 0:a.AnimationTimeInMs),this._slideIndex=n,null!==(t=this.data)&&void 0!==t&&null!==(t=t.Footer)&&void 0!==t&&t.onSlideChange&&this.data.Footer.onSlideChange(this._slideIndex)}get _slideViewAreaWidth(){var r,e;return null!==(r=this.data)&&void 0!==r&&null!==(r=r.Card)&&void 0!==r&&null!==(r=r.FullBleed)&&void 0!==r&&r.UseFullWidthForContent||null!==(e=this.data)&&void 0!==e&&null!==(e=e.Card)&&void 0!==e&&null!==(e=e.FullBleedGradient)&&void 0!==e&&e.UseFullWidthForContent?300:268}get _totalSlideContentWidth(){var r,e,i,a;if(null===(r=this.data)||void 0===r||!r.IsCarousel)return this._slideViewAreaWidth;const t=null===(e=this.data)||void 0===e||null===(e=e.Slide)||void 0===e?void 0:e.Width,l=null===(i=this.data)||void 0===i||null===(i=i.Slide)||void 0===i?void 0:i.Gap,n=null===(a=this.data)||void 0===a||null===(a=a.Slide)||void 0===a?void 0:a.Count;return t*n+(n-1)*l}get _slideCount(){var r,e,i,a;if(null!==(r=this.data)&&void 0!==r&&r.IsCarousel&&null!==(e=this.data)&&void 0!==e&&null!==(e=e.Slide)&&void 0!==e&&e.Count&&null!==(i=this.data)&&void 0!==i&&null!==(i=i.Slide)&&void 0!==i&&i.ScrollByWidth)return null===(a=this.data)||void 0===a||null===(a=a.Slide)||void 0===a?void 0:a.Count;return Math.ceil(this._totalSlideContentWidth/this._slideViewAreaWidth)}getSlideMarginLeftForIndex(r){var e,i,a,t;if(this._totalSlideContentWidth<=this._slideViewAreaWidth)return 0;let l=r*this._slideViewAreaWidth;const n=(null===(e=this.data)||void 0===e||null===(e=e.Slide)||void 0===e?void 0:e.Width)??0,o=(null===(i=this.data)||void 0===i||null===(i=i.Slide)||void 0===i?void 0:i.Gap)??0;var d;this._slideViewAreaWidth>2*n&&(l=Math.max(l-(null===(d=this.data)||void 0===d||null===(d=d.Slide)||void 0===d?void 0:d.Width),0));let s;return s=null!==(a=this.data)&&void 0!==a&&a.IsCarousel&&null!==(t=this.data)&&void 0!==t&&null!==(t=t.Slide)&&void 0!==t&&t.ScrollByWidth?Math.min(r*(n+o),this._totalSlideContentWidth-this._slideViewAreaWidth):Math.min(l,this._totalSlideContentWidth-this._slideViewAreaWidth),-1*s}getbackground(){var r;if(null!==(r=this.data)&&void 0!==r&&null!==(r=r.Header)&&void 0!==r&&r.ShowFloatingHeaderWithOnlyActionMenu){var e,i,a,t,l,n;const r=null===(e=this.shadowRoot)||void 0===e||null===(i=e.querySelector)||void 0===i?void 0:i.call(e,"responsive-sd-card"),s=null==r||null===(a=r.shadowRoot)||void 0===a||null===(t=a.querySelector)||void 0===t?void 0:t.call(a,".cs-sd-card"),c=null==s?void 0:s.querySelector("responsive-header"),v=null==c||null===(l=c.shadowRoot)||void 0===l||null===(n=l.querySelector)||void 0===n?void 0:n.call(l,".sd-card-header");if(v){var o,d;c.style.position="absolute",c.style.top="var(--action-menu-top)",c.style.left="var(--action-menu-left)",c.style.right="var(--action-menu-right)",c.style.setProperty("z-index","100"),v.style.height="fit-content",v.style.width="fit-content",v.style.margin="0",v.style.padding="0",s.style.setProperty("grid-template","auto");const r=null===(o=s.shadowRoot)||void 0===o||null===(d=o.querySelector)||void 0===d?void 0:d.call(o,".content");r&&(r.style.padding="0",r.style.height="var(--contentHeight)",r.style.width="var(--contentWidth)")}}}};(0,a.Cg)([n.sH],c.prototype,"data",void 0),(0,a.Cg)([n.Jg],c.prototype,"_useDarkModeAlways",null),(0,a.Cg)([n.Jg],c.prototype,"_isImmersiveCard",null),(0,a.Cg)([n.Jg],c.prototype,"_overrideCsSdCardHeight",null),(0,a.Cg)([n.Jg],c.prototype,"superCardData",null),(0,a.Cg)([n.sH],c.prototype,"_slideIndex",void 0),(0,a.Cg)([n.Jg],c.prototype,"_slideViewAreaWidth",null),(0,a.Cg)([n.Jg],c.prototype,"_totalSlideContentWidth",null),(0,a.Cg)([n.Jg],c.prototype,"_slideCount",null),c=(0,a.Cg)([s.x],c);var v=i(68796),u=i(74849),p=i(22131),g=i(4968);const h=u.A`
.dark-card responsive-sd-card::part(cs-sd-card){--sd-card-chevron-svg-fill:rgb(255,255,255);--sd-card-chevron-background-hover:rgb(59,59,59);--sd-card-chevron-background-active:rgb(59,59,59)}`,m=u.A`
a,button,.card-content{${g.f}}.card-content{width:var(${v.Q.ContentWidth},268px);overflow:hidden;display:flex;flex-direction:column;justify-content:space-around}.slides-container{height:var(${v.Q.SlideHeight},224px);overflow:hidden}.slides{height:100%;gap:var(${v.Q.SlideGap});
    margin-left: 0px;
    transition-duration: var(${v.Q.AnimationTime});
    display: grid;
    grid-template-columns: repeat(var(${v.Q.ItemCount}), var(${v.Q.SlideWidth}));flex-direction:row}.dark-card responsive-sd-card::part(cs-sd-card){${v.Q.ForegroundColor}: white;
    --neutral-fill-rest:#383838;
    --neutral-fill-hover:#3b3b3b;
    --sd-card-pagination-dot-color: rgb(255 255 255 / 0.5442);
    border-radius: var(${v.Q.CardBorderRadius})}.dark-card responsive-sd-card::part(cs-sd-card),.tr-immersive-card responsive-sd-card::part(cs-sd-card){--neutral-foreground-rest:var(${v.Q.ForegroundColor});
    --sd-card-header-color: var(${v.Q.ForegroundColor});
    --iconInvert: 100%;
    color: var(${v.Q.ForegroundColor});
    background: var(${v.Q.CardBackground});
    background-repeat: no-repeat;
    background-size: cover;
    border-radius: var(${v.Q.CardBorderRadius});--sd-card-chevron-svg-fill:rgb(38,38,38);--sd-card-chevron-background-hover:rgb(255,255,255);--sd-card-chevron-background-active:rgb(239,239,239)}.cs-sd-card-override responsive-sd-card{height:var(${v.Q.CsSdCardHeight})}:host{height:100%}`.withBehaviors((0,p.G2)(h));var b=i(96950),x=i(60402),$=i(69259);const f=b.qy`<div class="slides-container"><div class="slides" ${(0,x.K)("_slidesElement")}><slot></slot></div></div>`,y=b.qy`
${(0,$.z)(r=>null==r?void 0:r.superCardData,b.qy`<div class="${r=>r._useDarkModeAlways?"dark-card":""} ${r=>r._overrideCsSdCardHeight?"cs-sd-card-override":""} ${r=>r._isImmersiveCard?"tr-immersive-card":""} ${r=>r.useFeeds3Design?"feeds3":""}" style="${r=>function(r){var e,i;if(null==r||!r.data)return"";let a="";const t=(null===(e=r.data)||void 0===e||null===(e=e.Card)||void 0===e||null===(e=e.FullBleedGradient)||void 0===e?void 0:e.Gradient)??"",l=(null===(i=r.data)||void 0===i||null===(i=i.Card)||void 0===i||null===(i=i.FullBleedGradient)||void 0===i?void 0:i.ImageSource)??"";return l&&(a=` ${v.Q.CardBackground}: ${t}, url(${l}); ${v.Q.CardBorderRadius}: 8px; `),a}(r)}"><responsive-sd-card ?feeds3-design="${r=>r.useFeeds3Design}" exportparts="sd-card-footer, footer-button, footer-link, sd-card-header" size="${r=>{var e;return null===(e=r.superCardData)||void 0===e?void 0:e.cardSize}}" :data="${r=>r.superCardData}" style=${r=>(r=>{var e,i,a;let t=(null==r||null===(e=r.Card)||void 0===e?void 0:e.Styles)??"";return(null!=r&&null!==(i=r.Card)&&void 0!==i&&null!==(i=i.FullBleed)&&void 0!==i&&i.UseFullWidthForContent||null!=r&&null!==(a=r.Card)&&void 0!==a&&null!==(a=a.FullBleedGradient)&&void 0!==a&&a.UseFullWidthForContent)&&(t+="--sd-card-content-padding-inline: 0;",t+=`${v.Q.ContentWidth}: 300px;`),t})(r.data)} use-custom-background=${r=>{var e;return void 0!==(null===(e=r.data)||void 0===e||null===(e=e.Card)||void 0===e||null===(e=e.FullBleedGradient)||void 0===e?void 0:e.ImageSource)}} ${(0,x.K)("_carouselElement")}><div style="${r=>function(r){var e,i;if(null==r||null===(e=r.data)||void 0===e||!e.Slide)return"";const a=` ${v.Q.SlideHeight}:${r.data.Slide.Height}px; ${v.Q.SlideWidth}:${r.data.Slide.Width}px; ${v.Q.SlideGap}:${r.data.Slide.Gap}px; `;let t="";var l;return null!==(i=r.data)&&void 0!==i&&i.IsCarousel&&(t=` ${v.Q.ItemCount}:${r.data.Slide.Count}; ${v.Q.AnimationTime}:${null===(l=r.data.Slide)||void 0===l?void 0:l.AnimationTimeInMs}ms; `),a+t}(r)}" slot="card-content" class="card-content"><slot name="static-content"></slot>${r=>{var e;return null!==(e=r.data)&&void 0!==e&&e.IsCarousel?f:b.qy`<slot></slot>`}}</div></responsive-sd-card></div>`)}
`;(0,t.d)();let C=class extends c{};C=(0,a.Cg)([(0,l.E)({name:"msn-travel-sd-card",template:y,styles:m})],C)},95423(r,e,i){i.r(e),i.d(e,{CardScenario(){return a},ToolingInfo(){return Mr},TravelSdCarrentalsCard(){return h},TravelSdCarrentalsCardStyles(){return Lr},TravelSdCarrentalsCardTemplate(){return Tr}});var a,t=i(56911),l=i(60815),n=i(12680),o=i(39671),d=i(33477),s=i(32657),c=i(29709),v=i(69242),u=i(22341),p=i(93552),g=i(17918);!function(r){r.CarRentalList="CarRentalList",r.Error="Error"}(a||(a={}));class h extends o.U{constructor(){super(...arguments),this.extractFeedData=()=>{try{this.mapperArgs&&(this.data=v.ov.parseDestinationDataString(this.mapperArgs.cardMetadata))}catch(r){(0,u.vV)(p.OV,`${n.gIA} - Error in transforming data = ${JSON.stringify(this.mapperArgs)}`,void 0,{...p.OV.pb,userImpacting:!0})}}}connected(){this.experienceConnected()}experienceConnected(){this.extractFeedData()}mapperArgsChanged(r,e){this.extractFeedData()}shadowDomPopulated(){this.markTtvr()}markTtvr(){var r,e;const i=new Image,a=null===(r=this.data)||void 0===r||null===(r=r.V2Data)||void 0===r?void 0:r.Data,t=null==a?void 0:a.Cars;t&&0!=t.length&&(i.src=(0,v.b7)((null==t||null===(e=t[0])||void 0===e||null===(e=e.Image)||void 0===e?void 0:e.ThumbnailId)??"",new Set(["width","height"])),i.onload=r=>{(0,g.pE)("TravelDestination")})}getExperienceType(){return n.gIA}get _cardScenario(){var r,e,i;return(null===(r=this.data)||void 0===r||null===(r=r.V2Data)||void 0===r?void 0:r.DataType)===v.ac.CarRentalList?a.CarRentalList:((0,u.vV)(p.kzh,`${n.gIA} - Unsupported card data type - ${null===(e=this.data)||void 0===e||null===(e=e.V2Data)||void 0===e?void 0:e.DataType}`,JSON.stringify(null===(i=this.mapperArgs)||void 0===i?void 0:i.cardMetadata),{...p.kzh.pb,userImpacting:!0}),a.Error)}get _cardScenarioComponent(){return this._cardScenario,a.CarRentalList,"carrentals-list-card"}get _cardScenarioTelemetry(){return this._cardScenario===a.CarRentalList?this._carRentalsCardListTelemetryTag:""}get isHalfCard(){return this.cardSize==d.uE._1x_1y||this.cardSize==d.uE._05u}get telemetryFields(){var r;return{...null===(r=this.data)||void 0===r?void 0:r.Telemetry}}getTelemetryTag(r){var e;return(0,s.U)(this.telemetryObject,this.telemetryFields,null===(e=this.parentTelemetry)||void 0===e||null===(e=e.contract)||void 0===e?void 0:e.ext,r)}get _rootTelemetry(){return this.getTelemetryTag(c.w.Root)}get _rootCarRentalTelemetry(){return this.getTelemetryTag(c.w.CarRentalBase)}get _travelItemTelemetry(){return this.getTelemetryTag(c.w.Card)}get _carRentalsCardTelemetryTag(){return this.getTelemetryTag(c.w.CarrentalsCard)}get _carRentalsCardListTelemetryTag(){return this.getTelemetryTag(c.w.CarrentalsCardList)}}(0,t.Cg)([l.sH],h.prototype,"data",void 0),(0,t.Cg)([l.sH],h.prototype,"cardSize",void 0),(0,t.Cg)([l.Jg],h.prototype,"telemetryFields",null),(0,t.Cg)([l.Jg],h.prototype,"_rootTelemetry",null),(0,t.Cg)([l.Jg],h.prototype,"_rootCarRentalTelemetry",null),(0,t.Cg)([l.Jg],h.prototype,"_travelItemTelemetry",null),(0,t.Cg)([l.Jg],h.prototype,"_carRentalsCardTelemetryTag",null),(0,t.Cg)([l.Jg],h.prototype,"_carRentalsCardListTelemetryTag",null);var m=i(96950),b=i(69259),x=i(50866),$=i(92011),f=i(31525);let y=class extends $.L{constructor(){super(...arguments),this.renderHeaderIcon=r=>`<img style="width: 16px; height: 16px;" src=${r} alt="flights-header-icon">`}get _isActionMenuAvailable(){return!0}get _actionMenuItems(){var r,e;return{Items:[],strings:{hideCardTitle:(null===(r=this.strings)||void 0===r?void 0:r.hideCardText)??"Hide travel card",moreSettingsTitle:(null===(e=this.strings)||void 0===e?void 0:e.moreSettingsText)??"More settings"},hideCardCallback:this.refreshSDCardSection,moreSettingsPersonalizeCallback:this.goToPersonalizeSettingsCallback}}};(0,t.Cg)([l.sH],y.prototype,"data",void 0),(0,t.Cg)([l.sH],y.prototype,"config",void 0),(0,t.Cg)([l.sH],y.prototype,"strings",void 0),(0,t.Cg)([l.sH],y.prototype,"telemetryObject",void 0),(0,t.Cg)([l.sH],y.prototype,"isHalfCard",void 0),(0,t.Cg)([l.sH],y.prototype,"parentTelemetry",void 0),(0,t.Cg)([l.sH],y.prototype,"refreshSDCardSection",void 0),(0,t.Cg)([l.sH],y.prototype,"goToPersonalizeSettingsCallback",void 0),(0,t.Cg)([l.Jg],y.prototype,"_isActionMenuAvailable",null),(0,t.Cg)([l.Jg],y.prototype,"_actionMenuItems",null),y=(0,t.Cg)([f.x],y);const C={CarrentalCardLink:(0,v.Yz)("CarrentalCardLink"),SeeAllSlide:(0,v.Yz)("SeeAllSlide")},w=Object.freeze({MultipleCarsPerDayPrice:"MultipleCarsPerDayPrice",SingleCarSortedPrice:"SingleCarSortedPrice",LargeCarsImgPrices:"LargeCarsImgPrices",CarAgencyTripleListPrices:"CarAgencyTripleListPrices",MultipleCarsViewDeals:"MultipleCarsViewDeals",CarsTripleListPrices:"CarsTripleListPrices"});let k=class extends y{constructor(){super(...arguments),this._slideIndex=0}get _scenario(){var r,e;return Object.values(w).includes(null===(r=this.data)||void 0===r||null===(r=r.Telemetry)||void 0===r?void 0:r.scenario)?null===(e=this.data)||void 0===e||null===(e=e.Telemetry)||void 0===e?void 0:e.scenario:w.MultipleCarsPerDayPrice}get telemetryFields(){var r;return null===(r=this.data)||void 0===r?void 0:r.Telemetry}get _ext(){var r;return null===(r=this.parentTelemetry)||void 0===r||null===(r=r.contract)||void 0===r?void 0:r.ext}get _updateTelemetryObject(){return(0,s.H)(this.telemetryObject,this.telemetryFields,this._ext)}getTelemetryTag(r,e){return(0,s.U)(this.telemetryObject,this.telemetryFields,this._ext,r,"TravelItem:CarrentalsListCard",e??this._clickUrl)}get isEstimatedPrice(){var r;return"true"==(null===(r=this.data)||void 0===r||null===(r=r.MetaData)||void 0===r||null===(r=r.EstimatedPriceAvailable)||void 0===r?void 0:r.toLowerCase())}get firstCar(){var r;return null===(r=this.data)||void 0===r||null===(r=r.Cars)||void 0===r?void 0:r[0]}get _isLastSlide(){var r;let e=(null===(r=this.data)||void 0===r||null===(r=r.Cars)||void 0===r?void 0:r.length)??0;return e+=1,this._slideIndex===e-1}get _slideAspect(){var r;let e=(null===(r=this.data)||void 0===r||null===(r=r.Cars)||void 0===r?void 0:r.length)??0;this._scenario==w.MultipleCarsPerDayPrice&&(e+=1);return{AnimationTimeInMs:300,Count:e,Width:268,Height:224,Gap:0}}get _superCardData(){var r,e,i,a;const t={CtaButton:{Text:this.cardFooterCtaButtonText(),Link:this._clickUrl}},l=v.V,n={Header:{Text:this.cardHeaderText(),Icon:this.renderHeaderIcon(l),IsActionMenuAvailable:this._isActionMenuAvailable,Link:this._clickUrl,ActionMenuData:this._actionMenuItems},Card:{Link:this._clickUrl,Size:this.isHalfCard?d.uE._1x_1y:d.uE._1x_2y,CardFillColor:this.cardFillColor(),TelemetryObject:this._updateTelemetryObject,FullBleedGradient:undefined,WpoMetadata:this.wpoMetadata,CFOptions:{CFOption1:null===(r=this.strings)||void 0===r?void 0:r.feedbackOption1,CFOption2:null===(e=this.strings)||void 0===e?void 0:e.feedbackOption2}},Slide:this._slideAspect};return this._scenario==w.SingleCarSortedPrice||this._scenario==w.CarAgencyTripleListPrices||this._scenario==w.CarsTripleListPrices?{...n,IsCarousel:!1,Footer:{...t}}:{...n,IsCarousel:!0,Footer:{...t,NextChevron:{Title:(null===(i=this.strings)||void 0===i?void 0:i.nextSlideButtonLabel)??"Next"},PreviousChevron:{Title:(null===(a=this.strings)||void 0===a?void 0:a.prevSlideButtonLabel)??"Previous"},onSlideChange:r=>{this.onSlideChange(r)}}}}onSlideChange(r){this._slideIndex=r}cardTitle(r){var e,i;return this._scenario==w.SingleCarSortedPrice||this._scenario==w.LargeCarsImgPrices||this._scenario==w.CarAgencyTripleListPrices||this._scenario==w.CarsTripleListPrices||this._scenario==w.MultipleCarsViewDeals?(null===(i=this.strings)||void 0===i||null===(i=i.rentcar)||void 0===i?void 0:i.replace("{0}",(null==r?void 0:r.City)??""))??"":(null===(e=this.strings)||void 0===e||null===(e=e.rentcartype)||void 0===e?void 0:e.replace("{1}",(null==r?void 0:r.City)??"").replace("{0}",this.carCategoryToString(r)))??""}carSimilarText(r){var e;return(null===(e=this.strings)||void 0===e||null===(e=e.carSimilar)||void 0===e?void 0:e.replace("{0}",null==r?void 0:r.Name))??""}cardFillColor(){return this._scenario==w.LargeCarsImgPrices||this._scenario==w.CarAgencyTripleListPrices||this._scenario==w.CarsTripleListPrices||this._scenario==w.MultipleCarsViewDeals?{DarkThemeColor:"#00000",LightThemeColor:"#FFFFF"}:{DarkThemeColor:x.NZ.DarkPlum,LightThemeColor:x.L9.LightBlue}}cardHeaderText(){var r;return(null===(r=this.strings)||void 0===r?void 0:r.carrentals)??""}cardFooterCtaButtonText(){var r;return(null===(r=this.strings)||void 0===r?void 0:r.seeAllOpt)??""}get _clickUrl(){var r;return this._scenario==w.SingleCarSortedPrice?this.getClickUrl(this.firstCar):(null===(r=this.data)||void 0===r?void 0:r.SeeAllUrl)??""}_carImageUrl(r){var e,i;return this._scenario==w.LargeCarsImgPrices||this._scenario==w.MultipleCarsViewDeals?(0,v.b7)((null==r||null===(i=r.Image)||void 0===i?void 0:i.ThumbnailId)??"",new Set(["width","height"])):(null==r||null===(e=r.Image)||void 0===e?void 0:e.ThumbnailId)??""}getTop3CarInfo(){const r=[];for(let i=0;i<3;i++){var e;r.push(null===(e=this.data)||void 0===e||null===(e=e.Cars)||void 0===e?void 0:e[i])}return r}isTagAvailable(r){return!1}getTag(r){var e,i;return"true"==(null==r||null===(e=r.MetaData)||void 0===e?void 0:e.RecommendedCar.toLowerCase())?(null===(i=this.strings)||void 0===i?void 0:i.recom)??"":""}getClickUrl(r){return(null==r?void 0:r.ClickUrl)??""}getSeeAllUrl(){var r;return(null===(r=this.data)||void 0===r?void 0:r.SeeAllUrl)??""}getTransmissionType(r){var e,i;return(null==r?void 0:r.Transmission)==v.hW.Manual?(null===(e=this.strings)||void 0===e?void 0:e.mancar)??"":(null===(i=this.strings)||void 0===i?void 0:i.autocar)??""}getPerDayString(r){var e;const i=null==r?void 0:r.DropDateTime;if(i){var a;const e=(0,v.kt)(null==r?void 0:r.PickupDateTime,i);var t;return this.isHalfCard||this._scenario==w.LargeCarsImgPrices||this._scenario==w.CarAgencyTripleListPrices?e.toString()+" "+((null===(t=this.strings)||void 0===t?void 0:t.days)??""):(null===(a=this.strings)||void 0===a||null===(a=a.fordays)||void 0===a?void 0:a.replace("{0}",e.toString()))??""}var l;return this._scenario==w.LargeCarsImgPrices?(null===(l=this.strings)||void 0===l?void 0:l.day)??"":(null===(e=this.strings)||void 0===e?void 0:e.perday)??""}_carAgencyImageUrl(r){var e,i;return null!=r&&null!==(e=r.AgencyLogo)&&void 0!==e&&null!==(e=e.ThumbnailId)&&void 0!==e&&e.includes("opaquecar")?"":(null==r||null===(i=r.AgencyLogo)||void 0===i?void 0:i.ThumbnailId)??""}carCategoryToString(r){var e,i,a,t,l,n,o,d,s;switch(null==r?void 0:r.Type){case v.hO.Economy:return(null===(e=this.strings)||void 0===e?void 0:e.economy)??"";case v.hO.Intermediate:return(null===(i=this.strings)||void 0===i?void 0:i.intermediate)??"";case v.hO.FullSize:return(null===(a=this.strings)||void 0===a?void 0:a.fullsize)??"";case v.hO.SUV:return(null===(t=this.strings)||void 0===t?void 0:t.suv)??"";case v.hO.PickupTruck:return(null===(l=this.strings)||void 0===l?void 0:l.pickupTruck)??"";case v.hO.Luxury:return(null===(n=this.strings)||void 0===n?void 0:n.luxury)??"";case v.hO.Coupe:return(null===(o=this.strings)||void 0===o?void 0:o.coupe)??"";case v.hO.Van:return(null===(d=this.strings)||void 0===d?void 0:d.van)??"";case v.hO.Convertible:return(null===(s=this.strings)||void 0===s?void 0:s.convertible)??"";case v.hO.UNKNOWN:default:return""}}get _carRentalScenarioTelemetryTag(){return this.getTelemetryTag((0,v.Yz)(this._scenario))}get _carRentalsCardLinkTelemetryTag(){return this.getTelemetryTag(C.CarrentalCardLink,this._clickUrl)}get _seeAllSlideTelemetryTag(){return this.getTelemetryTag(C.SeeAllSlide)}};(0,t.Cg)([l.sH],k.prototype,"_slideIndex",void 0),(0,t.Cg)([l.Jg],k.prototype,"telemetryFields",null),(0,t.Cg)([l.Jg],k.prototype,"_ext",null),(0,t.Cg)([l.Jg],k.prototype,"_updateTelemetryObject",null),(0,t.Cg)([l.Jg],k.prototype,"_isLastSlide",null),(0,t.Cg)([l.Jg],k.prototype,"_slideAspect",null),(0,t.Cg)([l.Jg],k.prototype,"_superCardData",null),k=(0,t.Cg)([f.x],k);var T=i(74849),_=i(12640);const S="\n        display: flex;\n        flex-direction: row;\n    ",F="\n        display: flex;\n        flex-direction: column;\n    ",D="\n        justify-content: center;\n        align-items: center;\n    ",z="\n        font-size: 10px;\n        line-height: 14px;\n        font-weight: 400;\n    ",I="\n        font-size: 12px;\n        line-height: 16px;\n    ",L="\n        font-size: 12px;\n        line-height: 16px;\n        font-weight: 400;\n    ",M="\n        font-weight: 600;\n        font-size: 14px;\n        line-height: 20px;\n    ",A="\n        font-size: 16px;\n        line-height: 22px;\n        font-weight: 600;\n    ",P="\n        font-size: 16px;\n        line-height: 22px;\n        font-weight: 700;\n    ",H="\n        font-size: 20px;\n        line-height: 28px;\n        font-weight: 400;\n    ",j="\n        font-size: 20px;\n        line-height: 28px;\n        font-weight: 600;\n    ",O="\n        font-size: 24px;\n        line-height: 32px;\n        font-weight: 600;\n    ",R=r=>`\n            overflow: hidden;\n            display: -webkit-box;\n            -webkit-box-orient: vertical;\n            -webkit-line-clamp: ${r};\n        `,E=T.A` .card-container{--mcpdp-car-card-background:rgba(255,255,255,0.13);--mcpdp-car-pill-background:rgba(40,134,222,1);--mcpdp-car-pill-font-color:rgba(255,255,255,1);--mcpdp-car-platform-backgroud:rgba(255,255,255,0.1);--mcpdp-see-all-background:rgba(17,94,163,1);--mcpdp-see-all-font-color:rgba(255,255,255,1);--mcpdp-secondary-font-color:#D4D8EE;--mcpdp-icon-color:invert(87%) sepia(22%) saturate(200%) hue-rotate(195deg) brightness(97%) contrast(92%);--mcpdp-border-color:rgba(255,255,255,0.2)}`,W=T.A` .card-container{--mcpdp-car-card-background:rgba(255,255,255,0.46);--mcpdp-car-pill-background:rgba(12,59,94,1);--mcpdp-car-pill-font-color:rgba(255,255,255,1);--mcpdp-car-platform-backgroud:rgba(255,255,255,0.4);--mcpdp-see-all-background:rgba(33,105,235,1);--mcpdp-see-all-font-color:rgba(255,255,255,1);--mcpdp-secondary-font-color:#767676;--mcpdp-icon-color:invert(50%) sepia(0%) saturate(1736%) hue-rotate(144deg) brightness(91%) contrast(82%);--mcpdp-border-color:rgba(0,0,0,0.05)}.rent-city{margin-bottom:46px;${O} text-align:center;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis}.rent-city.v2{margin-bottom:16px}.rent-city:hover{text-decoration:underline}.expl-city{${H} margin-bottom:31px}.expl-city:hover{text-decoration:underline}.car-platform-images{${S} justify-content:space-evenly;align-items:center;width:100%;position:absolute;top:-24px}.car-platform-image{height:52px;transform:scaleX(-1)}.car-summary{${F}
        gap: 9px;
        background: var(--mcpdp-car-card-background);
        border-radius: 8px;
        box-sizing: border-box;
        position: relative;
        margin-top: 8px;
        margin: auto;
        padding: 8px 11px 8px 12px;
        max-width: max-content;
    }
    .car-price-row{
        ${S}
        gap: 20px;
    }
    
    .car-image{
        height: 90px;
        transform: scaleX(-1);
        position: absolute;
        top: -35px;
        left: 0px;
        right: 0px;
        margin-left: auto;
        margin-right: auto;
    }
    
    .car-image-v2{
        display: block;
        height: 90px;
        transform: scaleX(-1);
        margin:auto;
    }

    .car-agency-image{
        display: flex;
        width: 100%;
        height: 100%;
    }
    .car-agency{
        background: rgba(245, 245, 245, 1);
        border-radius: 4px;
        border: 1.29px solid rgba(221, 221, 221, 1);
        padding: 2px 4px 2px 4px;
        max-height: 22px;
        box-sizing: border-box;
        max-width: 43px;
        align-self: flex-end;
    }
    
    .car-price{
        ${S}
        gap: 8px;
        align-items: baseline;
    }
    .car-price-from{
        ${P}
    }
    
    .car-price-perday{
        color: var(--mcpdp-secondary-font-color);
        ${L}
    }
    .estimated{
        color: var(--mcpdp-secondary-font-color);
        ${I}}.breakline{border:1px solid var(--mcpdp-border-color);margin-top:45px}.see-all{display:flex;flex-direction:column;${D}
        position: relative;
    }
    .car-platform{
        display: flex;
        height: 82px;
        flex-direction: column-reverse;
        background: var(--mcpdp-car-platform-backgroud);
        border-radius: 8px;
        width: 100%;
        position: relative;
    }
    .see-all-btn{
        display: flex;
        ${D}
        ${A}
        padding: 5px 0px 7px 0px;
        background: var(--mcpdp-see-all-background);
        color: var(--mcpdp-see-all-font-color);
        border-radius: 4px;
        width: -webkit-fill-available;
        height: 32px;
        box-sizing: border-box;
    }

`.withBehaviors(new _.N(null,E)),B=T.A` .card-container{--car-card-background:rgba(255,255,255,0.13);--car-pill-background:rgba(40,134,222,1);--car-pill-font-color:rgba(255,255,255,1);--car-platform-backgroud:rgba(255,255,255,0.1);--see-all-background:rgba(17,94,163,1);--see-all-font-color:rgba(255,255,255,1);--secondary-font-color:#D4D8EE;--icon-color:invert(87%) sepia(22%) saturate(200%) hue-rotate(195deg) brightness(97%) contrast(92%);--border-color:rgba(255,255,255,0.2)}`,U=T.A` .card-container{--car-card-background:rgba(255,255,255,0.46);--car-pill-background:rgba(12,59,94,1);--car-pill-font-color:rgba(255,255,255,1);--car-platform-backgroud:rgba(255,255,255,0.4);--see-all-background:rgba(33,105,235,1);--see-all-font-color:rgba(255,255,255,1);--secondary-font-color:#767676;--icon-color:invert(50%) sepia(0%) saturate(1736%) hue-rotate(144deg) brightness(91%) contrast(82%);--border-color:rgba(0,0,0,0.05)}.rent-city{margin-bottom:62px;${O} text-align:center;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis}.car-platform-images{${S} justify-content:space-evenly;align-items:center;width:100%;position:absolute;top:-24px}.car-platform-image{height:52px;transform:scaleX(-1)}.car-summary{${F}
        gap: 9px;
        background: var(--car-card-background);
        border-radius: 8px;
        box-sizing: border-box;
        position: relative;
        margin-top: 8px;
        margin: auto;
        padding: 8px 11px 8px 12px;
        max-width: max-content;
    }
    .car-price-row{
        ${S}
        gap: 20px;
    }
    
    .car-image{
        height: 130px;
        transform: scaleX(-1);
        position: absolute;
        top: -70px;
        left: 0px;
        right: 0px;
        margin-left: auto;
        margin-right: auto;
    }
    .car-agency-image{
        object-fit: cover;
        width: 100%;
        height: 100%;
    }
    .car-agency{
        background: rgba(245, 245, 245, 1);
        border-radius: 4px;
        border: 1.29px solid rgba(221, 221, 221, 1);
        padding: 2px 5px 2px 5px;
        max-height: 22px;
        box-sizing: border-box;
        max-width: 43px;
        align-self: flex-end;
    }
    
    .car-price{
        ${S}
        gap: 8px;
        align-items: baseline;
    }
    .car-price-from{
        ${P}
    }
    
    .car-price-perday{
        color: var(--secondary-font-color);
        ${L}
    }
    .estimated{
        color: var(--secondary-font-color);
        ${I}
    }
    .breakline{
        border: 1px solid var(--border-color);
        margin-top: 45px;
    }
    .car-platform{
        display: flex;
        height: 82px;
        flex-direction: column-reverse;
        background: var(--car-platform-backgroud);
        border-radius: 8px;
        width: 100%;
        position: relative;
    }

`.withBehaviors(new _.N(null,B)),N=T.A` .card-container{--car-price-pill-font-color:black;--car-price-pill-color:rgba(159,216,159,1)}`,V=T.A` .card-container{--car-price-pill-font-color:white;--car-price-pill-color:rgba(16,124,16,1)}.rent-city{${O}
        ${R(1)}}.rent-city-wrapper:hover{text-decoration:underline}.rent-city-wrapper{position:relative}.car-image{display:block;width:237px;height:158px;margin-left:auto;margin-right:auto}.car-agency-image{display:flex;width:100%;height:100%}.car-agency{position:absolute;left:0px;background:rgba(245,245,245,1);border-radius:6px;border:1.29px solid rgba(221,221,221,1);padding:2px 4px 2px 4px;max-height:27px;box-sizing:border-box;max-width:54px;align-self:flex-end}.car-similar-text{margin-bottom:8px;${R(1)}
    }
    
    .car-price{
        position: absolute;
        right: 5px;
        padding: 6px 6px 6px 8px;
        border-radius: 4px;
        ${F}
        align-items: center;
        width: fit-content;
        background-color: var(--car-price-pill-color);
        color: var(--car-price-pill-font-color);
    }
    .car-price-starting{
        ${z}}.car-price-perday{${z}
    }
    .car-price-currency{
        ${O}
    }

`.withBehaviors(new _.N(null,N)),X=T.A` .card-container{--car-agency-background:rgba(31,31,31,1);--car-agency-text-color:rgba(173,173,173,1)}`,G=T.A` .card-container{--car-agency-background:rgba(245,245,245,1);--car-agency-text-color:rgba(97,97,97,1)}.rent-city{${j}
        ${R(1)} margin-bottom:8px}.rent-city:hover{text-decoration:underline}.car-image{height:158px;margin-left:auto;margin-right:auto}.car-agency-image{display:flex;width:100%;height:100%}.car-agency{background:rgba(255,255,255,1);border-radius:6px;padding:2px 4px 2px 4px;max-height:40px;box-sizing:border-box;max-width:60px}.car-agency-wrapper{${S} gap:8px;height:57px;background-color:var(--car-agency-background);align-items:center;margin-bottom:8px;padding:8px;box-sizing:border-box;border-radius:6px}.car-chevron{width:13px;height:24px}.car-similar-text{margin-bottom:8px;${R(1)}
    }
    .car-price-starting{
        ${L} color:var(--car-agency-text-color);margin-inline-end:4px}.car-price-perday{${L} color:var(--car-agency-text-color);margin-inline-end:4px}.estimated{${L}
        color: var(--car-agency-text-color);
    }
    .car-price-currency{
        ${j}}.car-price-currency-wrapper{${R(1)}
    }

`.withBehaviors(new _.N(null,X)),J=T.A` .card-container{--car-box-background:rgba(31,31,31,1);--car-box-text-color:rgba(173,173,173,1)}`,q=T.A` .card-container{--car-box-background:rgba(245,245,245,1);--car-box-text-color:rgba(97,97,97,1)}.rent-city{${j}
        ${R(1)} margin-bottom:8px}.rent-city:hover{text-decoration:underline}.car-image{width:74px;height:50px}.car-wrapper{${S} gap:8px;align-items:baseline;height:57px;background-color:var(--car-box-background);align-items:center;margin-bottom:8px;padding:8px;box-sizing:border-box;border-radius:6px}.car-chevron{width:13px;height:24px}.car-similar-text{margin-bottom:8px;${R(1)}
    }
    .car-price-starting{
        ${z} color:var(--car-box-text-color);margin-inline-end:4px}.car-price-perday{${z} color:var(--car-box-text-color);margin-inline-end:4px}.estimated{${z}
        color: var(--car-box-text-color);
    }
    .car-price-currency{
        ${M}
    }
    .car-type{
        ${M}}.car-details-wrapper{${F} align-items:baseline;flex-grow:1}.car-price-wrapper{${R(1)}
        height: 20px;
    }

`.withBehaviors(new _.N(null,J)),Q=T.A` .card-container{--car-secondary-text-color:rgba(173,173,173,1);--car-deals-button-color:rgba(17,94,163,1)}`,Y=T.A` .card-container{--car-secondary-text-color:rgba(97,97,97,1);--car-deals-button-color:rgba(15,108,189,1)}.rent-city{${O}
        ${R(1)} margin-bottom:8px}.rent-city:hover{text-decoration:underline}.rent-city-wrapper{position:relative}.car-image{display:block;width:217px;height:134px;margin-left:auto;margin-right:auto}.car-agency-image{display:flex;width:100%;height:100%}.car-agency{position:absolute;left:0px;background:rgba(245,245,245,1);border-radius:6px;border:1.29px solid rgba(221,221,221,1);padding:2px 4px 2px 4px;max-height:27px;box-sizing:border-box;max-width:54px;align-self:flex-end}.car-similar-text{color:var(--car-secondary-text-color);${R(1)}}.car-view-deals{${M} width:92px;height:32px;border-radius:4px;background-color:var(--car-deals-button-color);color:white;border:none}.car-view-deals-text{${R(1)}
    }
    .car-price{
        ${L}
        ${R(1)}}.car-details-wrapper{${S} gap:34px}.car-price-wrapper{width:150px;${F}}.car-price-from{${A} margin-inline-end:4px}.car-price-perday{${L} color:var(--car-secondary-text-color)}.estimated{${L}
    }

`.withBehaviors(new _.N(null,Q)),K=T.A` a{text-decoration:none;color:inherit}.card-container{display:block;width:300px}${r=>{switch(r._scenario){case w.MultipleCarsPerDayPrice:null==r||r.$fastController.addStyles(W);break;case w.SingleCarSortedPrice:null==r||r.$fastController.addStyles(U);break;case w.LargeCarsImgPrices:null==r||r.$fastController.addStyles(V);break;case w.CarAgencyTripleListPrices:null==r||r.$fastController.addStyles(G);break;case w.CarsTripleListPrices:null==r||r.$fastController.addStyles(q);break;case w.MultipleCarsViewDeals:null==r||r.$fastController.addStyles(Y);break;default:null==r||r.$fastController.addStyles(W)}}}
`;var Z=i(39957);const rr=m.qy`<a class="see-all" data-t=${r=>null==r?void 0:r._seeAllSlideTelemetryTag} href="${r=>null==r?void 0:r.getSeeAllUrl()}" target="_blank" aria-live="polite"><div class="expl-city">${r=>{var e;return(null==r||null===(e=r.strings)||void 0===e?void 0:e.explchoose3)??""}}</div><div class="car-platform"><div class="car-platform-images">${(0,Z.ux)(r=>(null==r?void 0:r.getTop3CarInfo())??[],m.qy`<img class="car-platform-image" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carImageUrl(r)}}" alt="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.carCategoryToString(r)}}"/>`)}</div><div class="see-all-btn"><span>${r=>{var e;return(null==r||null===(e=r.strings)||void 0===e?void 0:e.explall)??""}}</span></div></div></a>`,er=m.qy`<a href="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getClickUrl(r)}}" target="_blank" data-t=${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carRentalsCardLinkTelemetryTag}} aria-live="polite" title="${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i?void 0:i.carCategoryToString(r))??""}}">${(0,b.z)((r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i||null===(i=i.config)||void 0===i?void 0:i.enableMcpdV2},m.qy`<img class="car-image-v2" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carImageUrl(r)}}" alt=${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i?void 0:i.carCategoryToString(r))??""}} />`)}<div class="rent-city ${(r,e)=>{var i;return null!=e&&null!==(i=e.parent)&&void 0!==i&&null!==(i=i.config)&&void 0!==i&&i.enableMcpdV2?"v2":""}}">${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.cardTitle(r)}}</div><div class="car-summary">${(0,b.z)((r,e)=>{var i;return!(null!=e&&null!==(i=e.parent)&&void 0!==i&&null!==(i=i.config)&&void 0!==i&&i.enableMcpdV2)},m.qy`<img class="car-image" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carImageUrl(r)}}" alt=${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i?void 0:i.carCategoryToString(r))??""}} /><div class="breakline"></div>`)}<div class="car-price-row"><div class="car-price"><span class="car-price-from">${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i||null===(i=i.strings)||void 0===i||null===(i=i.fromcost)||void 0===i?void 0:i.replace("{0}",(0,v.TI)(r.Price)))??""}} ${(0,b.z)((r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.isEstimatedPrice},m.qy`<span class="estimated">est.</span>`)}</span><span class="car-price-perday">${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getPerDayString(r)}}</span></div>${(0,b.z)((r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carAgencyImageUrl(r)},m.qy`<div class="car-agency"><img class="car-agency-image" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carAgencyImageUrl(r)}}" /></div>`)}</div></div></a>`,ir=m.qy` ${(0,Z.ux)((r,e)=>{var i;return(null===(i=r.data)||void 0===i?void 0:i.Cars)??[]},m.qy` ${er} `)} ${rr}
`,ar=m.qy`
${ir}
`,tr=m.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var e;return null===(e=r.config)||void 0===e?void 0:e.useFeeds3Design}}">${ar}</msn-travel-sd-card>`,lr=m.qy`<a href="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getClickUrl(r)}}" target="_blank" data-t=${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carRentalsCardLinkTelemetryTag}} aria-live="polite" title="${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i?void 0:i.carCategoryToString(r))??""}}"><div class="rent-city-wrapper"><div class="car-similar-text">${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.carSimilarText(r)}}</div><div class="car-price"><span class="car-price-starting">${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i||null===(i=i.strings)||void 0===i?void 0:i.startingFrom)??""}}</span><div class="car-price-currency-wrapper"><span class="car-price-currency">${(r,e)=>(0,v.TI)(r.Price)}</span><span class="car-price-perday">/ ${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getPerDayString(r)}}</span></div></div>${(0,b.z)((r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carAgencyImageUrl(r)},m.qy`<div class="car-agency"><img class="car-agency-image" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carAgencyImageUrl(r)}}" /></div>`)}</div><img class="car-image" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carImageUrl(r)}}" alt=${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i?void 0:i.carCategoryToString(r))??""}} /></a>`,nr=m.qy` ${(0,Z.ux)((r,e)=>{var i;return(null===(i=r.data)||void 0===i?void 0:i.Cars)??[]},m.qy` ${lr} `)}
`,or=m.qy`<div slot="static-content"><a class="car-static" href="${r=>null==r?void 0:r.getSeeAllUrl()}" target="_blank" aria-live="polite" data-t=${r=>r._carRentalsCardLinkTelemetryTag}><div class="rent-city">${r=>null==r?void 0:r.cardTitle(null==r?void 0:r.firstCar)}</div></a></div>${nr}
`,dr=m.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var e;return null===(e=r.config)||void 0===e?void 0:e.useFeeds3Design}}">${or}</msn-travel-sd-card>`,sr=m.qy`<a href="${r=>null==r?void 0:r.getClickUrl(null==r?void 0:r.firstCar)}" target="_blank" data-t=${r=>null==r?void 0:r._carRentalsCardLinkTelemetryTag} aria-live="polite" title="${r=>{var e;return(null==r||null===(e=r.firstCar)||void 0===e?void 0:e.Name)??""}}"><div class="rent-city">${r=>null==r?void 0:r.cardTitle(null==r?void 0:r.firstCar)}</div><div class="car-summary"><img class="car-image" src="${r=>null==r?void 0:r._carImageUrl(null==r?void 0:r.firstCar)}" alt=${r=>{var e;return(null==r||null===(e=r.firstCar)||void 0===e?void 0:e.Name)??""}} /><div class="breakline"></div><div class="car-price-row"><div class="car-price"><span class="car-price-from">${r=>{var e,i;return(null==r||null===(e=r.strings)||void 0===e||null===(e=e.fromcost)||void 0===e?void 0:e.replace("{0}",(0,v.TI)(null==r||null===(i=r.firstCar)||void 0===i?void 0:i.Price)))??""}} ${(0,b.z)(r=>null==r?void 0:r.isEstimatedPrice,m.qy`<span class="estimated">est.</span>`)}</span><span class="car-price-perday">${r=>null==r?void 0:r.getPerDayString(null==r?void 0:r.firstCar)}</span></div>${(0,b.z)(r=>null==r?void 0:r._carAgencyImageUrl(null==r?void 0:r.firstCar),m.qy`<div class="car-agency"><img class="car-agency-image" src="${r=>null==r?void 0:r._carAgencyImageUrl(null==r?void 0:r.firstCar)}" /></div>`)}</div></div></a>`,cr=m.qy`
${sr}
`,vr=m.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var e;return null===(e=r.config)||void 0===e?void 0:e.useFeeds3Design}}">${cr}</msn-travel-sd-card>`;var ur=i(52356);const pr=m.qy`<a href="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getClickUrl(r)}}" class="car-agency-wrapper" target="_blank" aria-live="polite"><div class="car-agency"><img class="car-agency-image" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carAgencyImageUrl(r)}}" /></div><div class="car-price-currency-wrapper"><span class="car-price-starting">${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i||null===(i=i.strings)||void 0===i?void 0:i.startingFrom)??""}}</span><span class="car-price-wrapper"><span class="car-price-currency">${(r,e)=>(0,v.TI)(r.Price)}</span><span class="car-price-perday">/${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getPerDayString(r)}}</span>${(0,b.z)((r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.isEstimatedPrice},m.qy`<span class="estimated">est.</span>`)}</span></div><span class="car-chevron" style="background: url(${ur.y.appInDarkMode()?v.H1:v.c_}) no-repeat center"></span></a>`,gr=m.qy`<a href="${r=>null==r?void 0:r._clickUrl}" target="_blank" data-t=${r=>null==r?void 0:r._carRentalsCardLinkTelemetryTag} aria-live="polite"><div class="rent-city">${r=>r.cardTitle(r.firstCar)}</div>${(0,Z.ux)(r=>{var e;return(null===(e=r.data)||void 0===e||null===(e=e.Cars)||void 0===e?void 0:e.slice(0,3))??[]},m.qy` ${pr} `)}</a>`,hr=m.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var e;return null===(e=r.config)||void 0===e?void 0:e.useFeeds3Design}}">${gr}</msn-travel-sd-card>`,mr=m.qy`<a href="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getClickUrl(r)}}" class="car-wrapper" target="_blank" aria-live="polite"><div class="car"><img class="car-image" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carImageUrl(r)}}" /></div><div class="car-details-wrapper"><span class="car-type">${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.carCategoryToString(r)}}</span><div class="car-price-wrapper"><span class="car-price-starting">${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i||null===(i=i.strings)||void 0===i?void 0:i.startingFrom)??""}}</span><span class="car-price-currency">${(r,e)=>(0,v.TI)(r.Price)}</span><span class="car-price-perday">/${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getPerDayString(r)}}</span>${(0,b.z)((r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.isEstimatedPrice},m.qy`<span class="estimated">est.</span>`)}</div></div><span class="car-chevron" style="background: url(${ur.y.appInDarkMode()?v.H1:v.c_}) no-repeat center"></span></a>`,br=m.qy`<a href="${r=>null==r?void 0:r._clickUrl}" target="_blank" data-t=${r=>null==r?void 0:r._carRentalsCardLinkTelemetryTag} aria-live="polite"><div class="rent-city">${r=>r.cardTitle(r.firstCar)}</div>${(0,Z.ux)(r=>{var e;return(null===(e=r.data)||void 0===e||null===(e=e.Cars)||void 0===e?void 0:e.slice(0,3))??[]},m.qy` ${mr} `)}</a>`,xr=m.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var e;return null===(e=r.config)||void 0===e?void 0:e.useFeeds3Design}}">${br}</msn-travel-sd-card>`,$r=m.qy`<a href="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getClickUrl(r)}}" target="_blank" data-t=${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carRentalsCardLinkTelemetryTag}} aria-live="polite" title="${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i?void 0:i.carCategoryToString(r))??""}}"><div class="rent-city-wrapper">${(0,b.z)((r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carAgencyImageUrl(r)},m.qy`<div class="car-agency"><img class="car-agency-image" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carAgencyImageUrl(r)}}" /></div>`)}</div><img class="car-image" src="${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i._carImageUrl(r)}}" alt=${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i?void 0:i.carCategoryToString(r))??""}} /><div class="car-details-wrapper"><div class="car-price-wrapper"><div class="car-price"><span class="car-price-from">${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i||null===(i=i.strings)||void 0===i||null===(i=i.fromcost)||void 0===i?void 0:i.replace("{0}",(0,v.TI)(r.Price)))??""}}</span><span class="car-price-perday">${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.getPerDayString(r)}}</span>${(0,b.z)((r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.isEstimatedPrice},m.qy`<span class="estimated">est.</span>`)}</div><div class="car-similar-text">${(r,e)=>{var i;return null==e||null===(i=e.parent)||void 0===i?void 0:i.carSimilarText(r)}}</div></div><button class="car-view-deals"><span class="car-view-deals-text">${(r,e)=>{var i;return(null==e||null===(i=e.parent)||void 0===i||null===(i=i.strings)||void 0===i?void 0:i.viewDeals)??""}}</span></button></div></a>`,fr=m.qy` ${(0,Z.ux)((r,e)=>{var i;return(null===(i=r.data)||void 0===i?void 0:i.Cars)??[]},m.qy` ${$r} `)}
`,yr=m.qy`<div slot="static-content"><a class="car-static" href="${r=>null==r?void 0:r.getSeeAllUrl()}" target="_blank" aria-live="polite" data-t=${r=>r._carRentalsCardLinkTelemetryTag}><div class="rent-city">${r=>null==r?void 0:r.cardTitle(null==r?void 0:r.firstCar)}</div></a></div>${fr}
`,Cr=m.qy`<msn-travel-sd-card :data=${r=>r._superCardData} :useFeeds3Design="${r=>{var e;return null===(e=r.config)||void 0===e?void 0:e.useFeeds3Design}}">${yr}</msn-travel-sd-card>`,wr=m.qy`<div class="card-container ${r=>{var e;return null!==(e=r.config)&&void 0!==e&&e.useFeeds3Design?"feeds3":""}}" data-t=${r=>r._carRentalScenarioTelemetryTag}>${r=>{switch(r._scenario){case w.MultipleCarsPerDayPrice:return tr;case w.SingleCarSortedPrice:return vr;case w.LargeCarsImgPrices:return dr;case w.CarAgencyTripleListPrices:return hr;case w.CarsTripleListPrices:return xr;case w.MultipleCarsViewDeals:return Cr;default:return tr}}}</div>`;let kr=class extends k{};kr=(0,t.Cg)([(0,$.E)({name:"carrentals-list-card",template:wr,styles:K,shadowOptions:{delegatesFocus:!0}})],kr),i(93752).cF;const Tr=m.qy`<div class="travel-container ${r=>r.config.useFeeds3Design?"feeds3":""}"  style="${r=>r.config.travelContainerStyles}" data-t="${r=>r._rootTelemetry}"><div class="travel-telemetry" data-t="${r=>r._travelItemTelemetry}"><div class="carrentals-card" id="travel-destination-card" data-t="${r=>r._rootCarRentalTelemetry}">${(0,b.z)(r=>r._cardScenarioComponent,m.qy`${r=>(r=>{const e=r._cardScenarioComponent,i=m.qy.partial(e);return m.qy`<${i} class="travel-card" data-t=${r=>r._cardScenarioTelemetry} :data=${r=>{var e;return null===(e=r.data)||void 0===e||null===(e=e.V2Data)||void 0===e?void 0:e.Data}} :config=${r=>r.config} :strings=${r=>r.strings} :isHalfCard=${r=>r.isHalfCard} :parentTelemetry=${r=>r.parentTelemetry} :telemetryObject=${r=>r.telemetryObject} :wpoMetadata=${r=>r.wpoMetadata} :refreshSDCardSection=${r=>null==r?void 0:r.refreshSDCardSection} :goToPersonalizeSettingsCallback=${r=>null==r?void 0:r.goToPersonalizeSettingsCallback}></${i}>`})(r)}`)}</div></div></div>`;var _r=i(7896),Sr=i(64003),Fr=i(86856);const Dr=T.A` .container{background:linear-gradient(323.98deg,#341F23 10.67%,#2F1C20 100%)}.body{background:rgba(255,255,255,0.07);border-radius:4px}`,zr=T.A`
`,Ir=T.A`
`,Lr=T.A`
:host{width:auto;height:100%;box-sizing:border-box;font-family:${_r.O};
    outline: none;
    font-size: 12px;
    line-height: 16px;
    color: ${Sr.c}}a{text-decoration:none;color:inherit}.travel-container{position:relative}.travel-card{display:block;width:300px;border-radius:8px;box-sizing:border-box}.feeds3,.feeds3 .travel-destination-card,.feeds3 .travel-telemetry,.feeds3 .travel-card{height:100%}`.withBehaviors(new _.N(null,Dr),new Fr.t(zr,Ir)),Mr={experienceConfigSchema:undefined}}}]);