"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-team-exploration"],{3905(e,r,o){o.r(r),o.d(r,{SportsExplorationHeadTransformer(){return t.K},SportsTeamExplorationMatchTransformer(){return l},SportsTeamExplorationTransformer(){return c}});var t=o(81714),a=o(23587),i=o(79811),s=o(58792);class l extends a.Bc{async transform(e){return{viewModel:await this.getViewModel(e)}}async getViewModel(e){const r={...e.telemetryConstants,name:a.BP.Game},o="string"==typeof e.matchData.gameState?e.matchData.gameState:(0,i.m5)(e.matchData.gameState.state),t="string"==typeof e.matchData.gameStartDateTime?(0,i.yn)(e.matchData.gameStartDateTime):void 0,l=o===a.Xp.preGame;return{hoverTelemetryTag:this.transformerProvider.telemetryBuilder.createHoverShowTelemetryTag(e.parentTelemetryObject,r),mouseLeaveTelemetryTag:this.transformerProvider.telemetryBuilder.createMouseLeaveCloseTelemetryTag(e.parentTelemetryObject,r),telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(e.parentTelemetryObject,r),linkTarget:(0,i.EZ)((0,i.Ot)(e.matchData.gameCenterUrl),{src:"fre"}),isDarkMode:(0,i.jJ)(),gameStartTime:e.matchData.gameStartDateTimeIsToBeAnnounced&&l?null:(0,i.ry)(t,s.T3.CurrentMarket)||this.transformerProvider.strings.sportsTBA,gameDate:(0,i.AL)(t,s.T3.CurrentMarket),gamePeriodAndClock:(0,i.PH)(e.matchData.gameState),matchData:e.matchData,gameState:o,participantOneImgIcon:(0,i.iK)(e.matchData.participantOne.imageId,!e.matchData.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),participantTwoImgIcon:(0,i.iK)(e.matchData.participantTwo.imageId,!e.matchData.participantTwo.imageId,this.transformerProvider.config.teamImageInfoEnhanced),participantOneName:e.matchData.participantOne.name||"",participantTwoName:e.matchData.participantTwo.name||"",participantOneScore:l?"":e.matchData.participantOne.score,participantTwoScore:l?"":e.matchData.participantTwo.score,isParticipantOneWinning:Boolean(e.matchData.participantOne.isWinner),isParticipantTwoWinning:Boolean(e.matchData.participantTwo.isWinner),participantOneLogoBg:`#${e.matchData.participantOne.primaryColorHex||"ffffff"}`,participantTwoLogoBg:`#${e.matchData.participantTwo.primaryColorHex||"ffffff"}`,strings:{live:this.transformerProvider.strings.sportsLive||"LIVE",final:this.transformerProvider.strings.sportsStateFinal}}}}var n=o(49150),d=o(96950);class c extends a.Bc{async transform(e){const r=await this.getCurrentViewModel(e);return{viewTemplate:d.qy`
                <sports-team-exploration
                    :viewModel="${r}"
                ></sports-team-exploration>`}}async getCurrentViewModel(e){return{telemetryConstants:e.telemetryConstants,head:await this.getExplorationHeadView(e),cardSize:e.cardSize,matchList:await this.getMatchViews(e),strings:{featuredGames:this.transformerProvider.strings.featuredGames},telemetryObject:e.telemetryObject,telemetryTag:""}}async getExplorationHeadView(e){const r={followedSports:e.followedSports,reasonText:e.reasonText,secondaryText:e.secondaryText,cardSize:e.cardSize,isDisliked:e.isDisliked,logoPrimaryColor:e.logoPrimaryColor,league:e.league,telemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants};return await this.transformerProvider.generateView(r,a.hi.ExplorationHead)}getMaxMatchesCount(e){switch(e.cardSize){case n.uE._1x_2y:return 2;case n.uE._1x_3y:return 6;default:return 0}}async getMatchViews(e){const r=e.matchList.slice(0,this.getMaxMatchesCount(e)).map(async r=>{const o={matchData:r.sportsMatchData,parentTelemetryObject:e.telemetryObject,telemetryConstants:e.telemetryConstants};return this.transformerProvider.generateView(o,a.hi.TeamExplorationMatch)});return(await Promise.all(r)).filter(i.z2)}}Promise.resolve().then(o.bind(o,76249)),Promise.resolve().then(o.bind(o,92398)),Promise.resolve().then(o.bind(o,23656))},4968(e,r,o){o.d(r,{f(){return n}});var t=o(64187),a=o(74849),i=o(42792),s=o(99657),l=o(36452);const n=a.A.partial`position: relative; z-index: ${s.D};`;a.A`
    ${i.e}
    ${i.nH}

    ${(0,t.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${n}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${l.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${l.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${l.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(i.kc)},23656(e,r,o){o.r(r),o.d(r,{SportsTeamExplorationMatch(){return T}});var t=o(56911),a=o(23587),i=o(54229),s=o(92079);class l extends s.a{focusHandler(e,r){if(!e)return;const o=e.currentTarget;r?(0,i.Eh)(o):(0,i.Ai)(o)}renderGameDetails(e,r,o){switch(this.viewModel.gameState){case a.Xp.preGame:return e;case a.Xp.inprogressGame:return r;case a.Xp.postGame:return o;default:return e}}}var n=o(92011),d=o(4968),c=o(12640),p=o(74849),g=o(48751);const h=p.A` :host{--live-color:#E98F6D}`,x=p.A` :host{--live-color:#D92C2C}.wrap{display:block;padding:4px 6px 6px 6px;background:var(--sports-item-background);text-decoration:none;border-radius:6px;width:131px;height:66px;box-sizing:border-box;${d.f}}.wrap:hover{background:var(--sports-item-hover-background)}.prt-one,.prt-two{display:grid;grid-template-columns:18px 1fr 22px;gap:4px;align-items:center;position:relative}.prt-one.no-score,.prt-two.no-score{grid-template-columns:18px 1fr}.prt-one{margin-bottom:4px}.logo-wrap{width:18px;height:18px;border-radius:4px;display:flex;align-items:center;justify-content:center;box-sizing:border-box}.logo{width:14px;height:14px}.name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.name,.score{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:${g.l}}.score{text-align:end}.win{position:absolute;right:-4px;top:6px;width:3px;height:7px}.game-detail{margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}.ingame{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-1-font-size,12px);font-weight:600;color:var(--live-color)}.postgame,.pregame{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-1-font-size,12px);color:${g.l};
    }
`.withBehaviors(new c.N(null,h));var u=o(96950),v=o(69259),b=o(58792);const f=`${(0,b.rA)().StaticsUrl}latest/sports/icons/SportsTeamLogoPlaceholder.svg`,m=u.qy`
    <div class="pregame" title="${e=>`${e.viewModel.gameStartTime} - ${e.viewModel.gameDate}`}">
        <span>${e=>e.viewModel.gameStartTime}</span>
        <span>${e=>e.viewModel.gameStartTime?"·":""}</span>
        <span>${e=>e.viewModel.gameDate}</span>
    </div>
`,w=u.qy`
    <div class="ingame">
        ${e=>e.viewModel.strings.live.toLocaleUpperCase()}
        <span title="${e=>e.viewModel.gamePeriodAndClock}">
            ${e=>e.viewModel.gamePeriodAndClock}
        </span>
    </div>
`,$=u.qy`
    <div class="postgame"
        title="${e=>e.viewModel.gameDate?`${e.viewModel.strings.final} - ${e.viewModel.gameDate}`:e.viewModel.gameDate}">
        <span>${e=>e.viewModel.strings.final||""}</span>
        ${e=>e.viewModel.gameDate?"·":""}
        <span>${e=>e.viewModel.gameDate||""}</span>
    </div>
`,k=u.qy`
    <div class="game-detail">
        ${e=>e.renderGameDetails(m,w,$)}
    </div>
`,y=u.qy`
    <img
        src="${(0,b.rA)().StaticsUrl}latest/sports/icons/SportsWinnerTag${e=>e.viewModel.isDarkMode?"Light":"Dark"}.svg"
        class="win"
    >
`,z=u.qy`
    <a
        class="wrap"
        href="${e=>e.viewModel.linkTarget}"
        target="_blank"
        data-t="${e=>e.viewModel.telemetryTag}"
        @mouseenter=${(e,r)=>e.focusHandler(r.event,!0)}
        @mouseleave=${(e,r)=>e.focusHandler(r.event,!1)}
    >
        ${k}
        <div class="prt-one ${e=>e.viewModel.participantOneScore?"":"no-score"}">
            <div
                class="logo-wrap"
                style="background-color: ${e=>e.viewModel.participantOneLogoBg}"
            >
                <img
                    role="presentation"
                    src="${e=>e.viewModel.participantOneImgIcon||f}"
                    class="logo"
                />
            </div>
            <div class="name" title="${e=>e.viewModel.participantOneName}">
                ${e=>e.viewModel.participantOneName}
            </div>

            ${(0,v.z)(e=>e.viewModel.participantOneScore,u.qy`<div class="score">
                ${e=>e.viewModel.participantOneScore}
            </div>`)}
            ${(0,v.z)(e=>e.viewModel.isParticipantOneWinning,y)}
        </div>
        <div class="prt-two ${e=>e.viewModel.participantTwoScore?"":"no-score"}">
            <div
                class="logo-wrap"
                style="background-color: ${e=>e.viewModel.participantTwoLogoBg}"
            >
                <img
                    role="presentation"
                    src="${e=>e.viewModel.participantTwoImgIcon||f}"
                    class="logo"
                />
            </div>
            <div class="name" title="${e=>e.viewModel.participantTwoName}">
                ${e=>e.viewModel.participantTwoName}
            </div>

            ${(0,v.z)(e=>e.viewModel.participantTwoScore,u.qy`<div class="score">
                ${e=>e.viewModel.participantTwoScore}
            </div>`)}
            ${(0,v.z)(e=>e.viewModel.isParticipantTwoWinning,y)}
        </div>
    </a>
`,F=u.qy`
    ${(0,v.z)(e=>void 0!==e.viewModel,z)}
`;let T=class extends l{};T=(0,t.Cg)([(0,n.E)({name:"sports-team-exploration-match",template:F,styles:x,shadowOptions:{delegatesFocus:!0}})],T)},42792(e,r,o){o.d(r,{R7(){return u},e(){return h},kc(){return x},nH(){return g}});var t=o(57416),a=o(55153),i=o(95239),s=o(26920),l=o(48751),n=o(64187),d=o(22131),c=o(74849),p=o(50882);const g=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=c.A`
    ${(0,n.V)("flex")} :host {
        background: ${i.p};
        outline: calc(${s.XA} * 1px) solid ${a.cu};
        border-radius: calc((${t.JU} - ${s.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${l.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${s.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,x=(0,d.mr)(c.A`
            :host {
                background: ${p.A.Canvas};
                color: ${p.A.CanvasText};
            }
        `),u=c.A`
    ${h}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(x)},76249(e,r,o){o.r(r),o.d(r,{SportsTeamExploration(){return w}});var t=o(56911),a=o(92079);class i extends a.a{}var s=o(92011),l=o(4968),n=o(12640),d=o(74849),c=o(48751);const p=d.A` :host{--divider-color:rgba(255,255,255,0.06)}`,g=d.A` :host{--divider-color:rgba(0,0,0,0.06)}.divider{width:100%;height:1px;background-color:var(--divider-color);margin-bottom:8px;${l.f};pointer-events:none}.matches-wrap{margin-top:12px}.matches{display:grid;grid-template-columns:131px 131px;gap:6px}.feat-games{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);font-weight:600;margin-bottom:4px;color:${c.l};
        ${l.f};
        pointer-events: none;
    }
    `.withBehaviors(new n.N(null,p));var h=o(96950),x=o(69259),u=o(39957);const v=h.qy`
    <sports-exploration-head
        :viewModel="${e=>e.viewModel.head.viewModel}"
    ></sports-exploration-head>
`,b=h.qy`
    ${(0,x.z)(e=>"_1x_1y"!==e.viewModel.cardSize,h.qy`
        <div class="matches-wrap">
            <div class="divider"></div>
            <div class="feat-games">${e=>e.viewModel.strings.featuredGames}</div>
            <div class="matches">
                ${(0,u.ux)(e=>e.viewModel.matchList,h.qy`
                    <sports-team-exploration-match
                        :viewModel="${e=>e.viewModel}"
                    ></sports-team-exploration-match>
                `)}
            </div>
        </div>
    `)}
`,f=h.qy`
    <div class="wrap ${e=>e.viewModel.cardSize}">
        ${v}
        ${b}
     </div>
`,m=h.qy`
    ${(0,x.z)(e=>void 0!==e.viewModel,f)}
`;let w=class extends i{};w=(0,t.Cg)([(0,s.E)({name:"sports-team-exploration",template:m,styles:g,shadowOptions:{delegatesFocus:!0}})],w)},81714(e,r,o){o.d(r,{K(){return l}});var t=o(49150),a=o(23587),i=o(54229),s=o(79811);class l extends a.Bc{async transform(e){return{viewModel:await this.getViewModel(e)}}getShouldShowSecondaryText(e){return e.cardSize!==t.uE._1x_1y&&!e.shouldHideSecondaryText}async getViewModel(e){const r=this.transformerProvider.config.skipFeedRefreshExploration,o=(0,s.iK)(e.league.imageId,!e.league.imageId,this.transformerProvider.config.teamImageInfoEnhanced);return{followLeagueClickHandler:r=>{this.transformerProvider.followClickEntityHandler({id:e.league.satoriId,yId:e.league.yId,name:e.league.name,type:a.XR.League,imageUrl:o},r,"",!0)},dislikeLeagueClickHandler:()=>{var o,t;null===(o=(t=this.transformerProvider).hideClickHandler)||void 0===o||o.call(t,e.league.id||"",r),this.transformerProvider.config.goToNextTabDelay&&r&&this.transformerProvider.goToNextTabIfExists()},shouldShowDislikeMessage:r,shouldShowSecondaryText:this.getShouldShowSecondaryText(e),followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:a.BP.FollowSports},!0),dislikeTelemetryTag:this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(e.telemetryObject,{...e.telemetryConstants,name:a.BP.ExplorationDislike},i.YJ.Customize),isFollowed:this.isFollowed(e),telemetryConstants:e.telemetryConstants,reasonText:e.reasonText,secondaryText:e.secondaryText,logoUrl:(0,s.iK)(e.league.imageId,!e.league.imageId,this.transformerProvider.config.teamImageInfoEnhanced),cardSize:e.cardSize,logoPrimaryColor:e.logoPrimaryColor,isDisliked:e.isDisliked,leagueName:e.league.name,strings:{follow:this.transformerProvider.strings.follow,notInterested:this.transformerProvider.strings.iAmNotInterested,youFollowed:this.transformerProvider.strings.youAreNowFollowing,youDisliked:this.transformerProvider.strings.youWillSeeLessContent},telemetryObject:e.telemetryObject,telemetryTag:""}}isFollowed(e){return e.followedSports.get(e.league.satoriId||"")}}},92079(e,r,o){o.d(r,{a(){return s}});var t=o(56911),a=o(92011),i=o(31525);let s=class extends a.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};s=(0,t.Cg)([i.x],s)},92398(e,r,o){o.r(r),o.d(r,{SportsExplorationHead(){return M}});var t,a=o(56911),i=o(50180),s=o(60815),l=o(92079),n=o(31525);!function(e){e[e.Initial=0]="Initial",e[e.Followed=1]="Followed",e[e.Disliked=2]="Disliked"}(t||(t={}));let d=class extends l.a{constructor(){super(...arguments),this.followState=t.Initial}onFollowClick(e){this.viewModel.followLeagueClickHandler(e),this.followState=t.Followed}onDislikeClick(){this.viewModel.dislikeLeagueClickHandler(),this.viewModel.shouldShowDislikeMessage&&(this.followState=t.Disliked)}connected(){super.connected(),this.viewModel.isFollowed?this.followState=t.Followed:this.viewModel.isDisliked&&this.viewModel.shouldShowDislikeMessage&&(this.followState=t.Disliked)}getFollowElements(e,r,o){switch(this.followState){case t.Initial:return e;case t.Followed:return r;case t.Disliked:return o}}get youDislikedInnerHtml(){return(0,i.GP)(this.viewModel.strings.youDisliked,`<span class="league-name">${this.viewModel.leagueName}</span>`)}get youFollowedInnerHtml(){return(0,i.GP)(this.viewModel.strings.youFollowed,`<span class="league-name">${this.viewModel.leagueName}</span>`)}};(0,a.Cg)([s.sH],d.prototype,"followState",void 0),d=(0,a.Cg)([n.x],d);var c=o(92011),p=o(48751),g=o(37302),h=o(86856),x=o(4968),u=o(12640),v=o(74849);const b=v.A` :host{--sec-text-color:rgba(255,255,255,0.78);--dislike-bg-color:#292929;--dislike-border-color:#757575;--dislike-color:#FFFFFF;--dislike-bg-hover:#3D3D3D;--dislike-border-color-hover:rgba(255,255,255,0.06);--result-bg-color:#FFFFFF;--result-color:#2b2b2b}`,f=v.A`
`,m=v.A` :host{--sec-text-color:rgba(0,0,0,0.6);--follow-color:#FFFFFF;--follow-bg-color:#036AC4;--follow-bg-color-hover:#0473CE;--dislike-bg-color:rgba(255,255,255,0.46);--dislike-border-color:#D6D6D6;--dislike-border-color-hover:rgba(0,0,0,0.06);--result-bg-color:#292929;--result-color:#FFFFFF;--logo-wrap-border-color:#D6D6D6;--dislike-color:${p.l};
        --dislike-bg-hover: ${g.Xt}}.reason-wrap{display:grid;grid-template-columns:50px 1fr;gap:6px;align-items:center;${x.f};pointer-events:none}.logo-wrap{margin:3px;border-radius:4px;display:flex;align-items:center;justify-content:center;width:44px;height:44px;box-sizing:border-box;border:1px solid var(--logo-wrap-border-color)}.logo{width:32px;height:32px}.reason-text,.sec-text{${x.f};pointer-events:none;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}.reason-text{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);font-weight:600;padding:3px 0px;color:${p.l}}.sec-text{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);color:var(--sec-text-color);height:32px}.follow-wrap{display:flex;justify-content:space-between;margin-top:8px}.follow-btn,.dislike-btn{font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);width:132px;border-radius:4px;height:22px;box-sizing:border-box;${x.f}}.btn-content{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600;max-width:110px;padding:2px 0px 4px}.league-name{font-weight:600}.follow-btn{background-color:var(--follow-bg-color);color:var(--follow-color);border:0px;border:1px solid rgba(0,0,0,0)}.follow-btn:hover{background-color:var(--follow-bg-color-hover)}.plus{width:9px;height:9px}.dislike-btn{background-color:var(--dislike-bg-color);border:1px solid var(--dislike-border-color);color:var(--dislike-color)}.dislike-btn:hover{border-color:var(--dislike-border-color-hover) var(--dislike-border-color-hover) rgba(0,0,0,0.16) var(--dislike-border-color-hover);background-color:var(--dislike-bg-hover)}.disliked,.followed{background-color:var(--result-bg-color);color:var(--result-color);border-radius:4px;padding:3px 10px;width:268px;box-sizing:border-box;font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;${x.f};pointer-events:none}._1x_1y .reason-wrap{grid-template-columns:40px 1fr;height:40px}._1x_1y .logo{width:27px;height:27px}._1x_1y .logo-wrap{width:35px;height:35px}._1x_1y .reason-text{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);padding:0px;color:${p.l}}._1x_1y .follow-wrap{margin-top:4px}`.withBehaviors(new h.t(null,f),new u.N(null,b));var w=o(96950),$=o(69259),k=o(58792);const y=w.qy`
    <div class="reason-wrap">
        <div class="logo-wrap" style="background-color: #${e=>e.viewModel.logoPrimaryColor}">
            <img src="${e=>e.viewModel.logoUrl}" class="logo">
        </div>
        <div class="reason-text">${e=>e.viewModel.reasonText}</div>
    </div>
`,z=w.qy`
    ${(0,$.z)(e=>e.viewModel.shouldShowSecondaryText,w.qy`
        <div class="sec-text">
            ${e=>e.viewModel.secondaryText}
        </div>
    `)}
`,F=w.qy`
    <fluent-button
        class="follow-btn"
        appearance="stealth"
        title="${e=>e.viewModel.strings.follow}"
        aria-label="${e=>e.viewModel.strings.follow}"
        role="button"
        data-t="${e=>e.viewModel.followTelemetryTag}"
        @click="${e=>e.onFollowClick(!0)}"
    >
        <div class="btn-content">
            <img src="${(0,k.rA)().StaticsUrl}latest/shopping/plusw.svg" class="plus">
            ${e=>e.viewModel.strings.follow}
        </div>
    </fluent-button>
    <fluent-button
        class="dislike-btn"
        appearance="stealth"
        title="${e=>e.viewModel.strings.notInterested}"
        aria-label="${e=>e.viewModel.strings.notInterested}"
        role="button"
        data-t="${e=>e.viewModel.dislikeTelemetryTag}"
        @click="${e=>e.onDislikeClick()}"
    >
        <div class="btn-content">
            ${e=>e.viewModel.strings.notInterested}
        </div>
    </fluent-button>
`,T=w.qy`
    ${e=>w.qy`
        <div class="followed">${w.qy.partial(e.youFollowedInnerHtml)}</div>
    `}
`,S=w.qy`
    ${e=>w.qy`
        <div class="disliked">${w.qy.partial(e.youDislikedInnerHtml)}</div>
    `}
`,D=w.qy`
    <div class="follow-wrap">
        ${e=>e.getFollowElements(F,T,S)}
    </div>
`,_=w.qy`
    <div class="wrap ${e=>e.viewModel.cardSize}">
        ${y}
        ${z}
        ${D}
    </div>
`,C=w.qy`
    ${(0,$.z)(e=>void 0!==e.viewModel,_)}
`;let M=class extends d{};M=(0,a.Cg)([(0,c.E)({name:"sports-exploration-head",template:C,styles:m,shadowOptions:{delegatesFocus:!0}})],M)},99657(e,r,o){o.d(r,{D(){return s},I(){return i}});var t=o(45755);const{create:a}=t.G,i=a("sloppy-click-z-index",1),s=a("click-z-index",1)}}]);