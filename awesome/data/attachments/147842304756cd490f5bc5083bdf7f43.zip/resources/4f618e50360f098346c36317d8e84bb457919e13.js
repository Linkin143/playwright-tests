"use strict";(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["sports-spotlight"],{4968(t,e,i){i.d(e,{f(){return l}});var r=i(64187),a=i(74849),o=i(42792),n=i(99657),s=i(36452);const l=a.A.partial`position: relative; z-index: ${n.D};`;a.A`
    ${o.e}
    ${o.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${s.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${s.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${s.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},10500(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect width="20" height="20" rx="10"/><path d="M13.77 7.2c.3.29.31.76.03 1.06l-4.25 4.5a.75.75 0 0 1-1.08.02l-2.25-2.25a.75.75 0 1 1 1.06-1.06l1.7 1.7 3.72-3.93a.75.75 0 0 1 1.07-.04Z"/></svg>'},23587(t,e,i){var r,a,o,n,s;i.d(e,{X2(){return f},qz(){return S},pA(){return k},S_(){return C},VO(){return n},oL(){return s},GC(){return w},IG(){return x},D7(){return l},bo(){return p},ci(){return L},Bc(){return I},hi(){return P},XR(){return y},rq(){return v},Xp(){return g},kA(){return E},JC(){return D},tX(){return B},mx(){return R},aB(){return b},jx(){return u},t9(){return z},sQ(){return m},T0(){return h},Z5(){return c},pC(){return j},JH(){return H},v1(){return r},BP(){return O},kt(){return d},Qy(){return _}}),function(t){t.Standings="Standings",t.Articles="Articles",t.TeamVsTeam="TeamVsTeam",t.TeamVsTeamWithBracket="TeamVsTeamWithBracket",t.Tennis="Tennis",t.MotorSportsSingleRace="MotorSportsSingleRace",t.MotorSportsRaceList="MotorSportsRaceList",t.GolfSchedule="GolfSchedule",t.GolfLeaderBoard="GolfLeaderBoard",t.Cricket="Cricket",t.TeamVsTeamExploration="TeamVsTeamExploration",t.LeagueEventResultOneVsOne="OneVsOneEventResult",t.LeagueEventResultOneVsMany="OneVsManyEventResult",t.LeagueEventResultTeamVsTeam="TeamVsTeamEventResult",t.CricketExploration="CricketExploration",t.TennisExploration="TennisExploration",t.EventBrief="EventBrief",t.SeasonStatistics="SeasonStatistics",t.Video="Video",t.Countdown="Countdown",t.Fre="FRE",t.Spotlight="Spotlight",t.SpotlightRace="SpotlightRace",t.SpotlightTennis="SpotlightTennis",t.SpotlightGolf="SpotlightGolf",t.SpotlightFRE="SpotlightFRE",t.StandingsRankings="StandingsRankings",t.SportsMedal="TeamStandings",t.LeagueEvents="LeagueTodaysEvents",t.TeamStandingWithMedals="TeamStandingWithMedals",t.TeamStandingWithEvents="TeamStandingWithEvents",t.SpotlightCricket="SpotlightCricket",t.TournamentsList="TournamentsList",t.Spotlight2c="Spotlight2c",t.AgentSpotlight="AgentSpotlight"}(r||(r={})),function(t){t.SportsInfo="SportsInfo",t.SportsInfoSpan="SportsInfoSpan",t.SportsMatchList="SportsMatchList",t.SportsMatch="SportsMatch",t.SportsSpanMatch="SportsSpanMatch",t.SportsArticle="SportsArticle",t.SportsTeamExploration="SportsTeamExploration",t.SportsTeamExplorationMatch="SportsTeamExplorationMatch",t.SportsCricketExploration="SportsCricketExploration",t.SportsTennisExploration="SportsTennisExploration",t.SportsExplorationHead="SportsExplorationHead",t.SportsLeaderboard="SportsLeaderboard",t.SportsCricket="SportsCricket",t.SportsCricketV2="SportsCricketV2",t.SportsTennis="SportsTennis",t.SportsMarchmadness="SportsMarchmadness",t.SportsEventBrief="SportsEventBrief",t.SportsEventCountry="SportsEventCountry",t.SportsEventResults="SportsEventResults",t.FeedsNotificationToast="FeedsNotificationToast",t.SportsHidePopup="SportsHidePopup",t.SportsFre="SportsFre",t.SportsSpotlight="SportsSpotlight",t.AgentSpotlight="AgentSpotlight",t.SportsSpotlight2c="SportsSpotlight2c",t.SportsGameStats="SportsGameStats",t.SportsCountdown="SportsCountdown",t.SportsAugmentCard="SportsAugmentCard",t.SportsSpotlightRace="SportsSpotlightRace",t.SportsSpotlightTennis="SportsSpotlightTennis",t.SportsTennisMatch="SportsTennisMatch",t.SportsSpotlightGolf="SportsSpotlightGolf",t.SharedHeroNewsCard="SharedHeroNewsCard",t.SportsSimpleMatch="SportsSimpleMatch",t.SportsStandingsRankings="SportsStandingsRankings",t.SportsEventSchedule="SportsEventSchedule",t.SportsMedal="SportsMedal",t.SportsMedalV2="SportsMedalV2",t.SportsInfoList="SportsInfoList",t.SportsRecentMedal="SportsRecentMedal",t.SportsRubyPill="SportsRubyPill",t.SportsSpotlightCricket="SportsSpotlightCricket",t.SportsSpotlightCricketV2="SportsSpotlightCricketV2",t.SportsTournamentsList="SportsTournamentsList",t.SportsTournamentStatusRow="SportsTournamentStatusRow"}(a||(a={})),function(t){t.Initial="initial",t.Default="default",t.Settings="settings",t.ColdStart="coldstart"}(o||(o={})),function(t){t.scheduledTournaments="GolfSchedule",t.leaderboard="GolfLeaderBoard"}(n||(n={})),function(t){t.singleRace="MotorSportsSingleRace",t.raceList="MotorSportsRaceList"}(s||(s={}));const l=Object.freeze({unknown:"Unknown",football:"Football",baseball:"Baseball",basketball:"Basketball",basketball3x3:"Basketball3x3",cricket:"Cricket",icehockey:"IceHockey",fieldhockey:"FieldHockey","auto racing":"Racing",racing:"Racing",tennis:"Tennis",soccer:"Soccer",golf:"Golf",australianrules:"AustralianRules",rugbyunion:"RugbyUnion",rugbyleague:"RugbyLeague",archery:"Archery",athletics:"Athletics",badminton:"Badminton",cycling:"Cycling",boxing:"Boxing",canoeing:"Canoeing",climbing:"Climbing",equestrianism:"Equestrianism",fencing:"Fencing",gymnasticsartistic:"GymnasticsArtistic",gymnasticsrhytmic:"GymnasticsRhytmic",gymnasticstrampoline:"GymnasticsTrampoline",handball:"Handball",judo:"Judo",karate:"Karate",summerolympics:"SummerOlympics",paralympics:"Paralympics",pentathlon:"Pentathlon",swimmingartistic:"SwimmingArtistic",swimming:"Swimming",diving:"Diving",waterpolo:"WaterPolo",rowing:"Rowing",sailing:"Sailing",shooting:"Shooting",skateboarding:"Skateboarding",surfing:"Surfing",taekwondo:"Taekwondo",triathlon:"Triathlon",tabletennis:"TableTennis",volleyballteam:"VolleyballTeam",volleyballbeach:"VolleyballBeach",weightlifting:"Weightlifting",wrestling:"Wrestling",softball:"Softball",trackandfield:"TrackAndField",mma:"MMA",netball:"Netball",boccia:"Boccia"});var p;!function(t){t.Mentioned="Mentioned",t.Related="Related"}(p||(p={}));const d="CHAMPIONS",c=" - ";var g,h;!function(t){t.preGame="pre-game",t.inprogressGame="inprogress-game",t.postGame="post-game",t.nonlive="non-live",t.toss="Toss",t.dinner="Dinner",t.drinks="Drinks",t.fog="Fog",t.innings="Innings",t.lunch="Lunch",t.stumps="Stumps",t.tea="Tea",t.break="Break",t.superover="SuperOver",t.abandoned="Abandoned",t.postponed="Postponed",t.BadWeatherCondition="BadWeatherCondition",t.delayed="Delayed"}(g||(g={})),function(t){t.PreGame="PreGame",t.InProgressGame="InProgressGame",t.InProgress="InProgress",t.Final="Final",t.PostGame="PostGame",t.Live="Live",t.Unknown="Unknown"}(h||(h={}));const u={Badge:"Badge",Preview:"PreviewCard"},m="Sports",v="SportsFre",y={League:"League",Team:"Team"},f={Dislike:"Dislike",Follow:"Follow"};var b;!function(t){t.Leaderboard="Leaderboard",t.FRE="Fre",t.Tennis="Tennis",t.Cricket="Cricket",t.SportsSpotlight="SportsSpotlight",t.SideBySide="SideBySide",t.Countdown="Countdown"}(b||(b={}));const x={0:"recommendationNone",1:"recommendationExplicit",2:"recommendationImplicit",3:"recommendationPopular",4:"recommendationLive",5:"recommendationMIT",6:"recommendationLocalPopular",7:"recommendationRecentSelect"},w="EntityId~";var $,S,k,T,C,z;!function(t){t.Gold="Gold",t.Silver="Silver",t.Bronze="Bronze",t.Total="Total"}($||($={})),function(t){t.Won="Won",t.Lost="Lost",t.Tied="Tied"}(S||(S={})),function(t){t.none="None",t.unknown="Unknown",t.captain="Captain",t.batter="Batter",t.bowler="Bowler",t.wicketKeeper="WicketKeeper",t.allRounder="AllRounder"}(k||(k={})),function(t){t.one="1",t.two="2"}(T||(T={})),function(t){t.test="Test",t.odi="Odi",t.t20="T20"}(C||(C={})),function(t){t.PickTheWinner="PickTheWinner",t.PickWinner="PickWinner",t.PlayerOfMatch="PlayerOfMatch"}(z||(z={}));var F=i(18272),M=i(2171);const D="sportsInfoAppState";var E;!function(t){t[t.sportsInfoApiData=1]="sportsInfoApiData",t[t.sportsData=2]="sportsData",t[t.sportsSDCardView=3]="sportsSDCardView",t[t.sportsViewMode=4]="sportsViewMode",t[t.tabCurrentPageIndex=5]="tabCurrentPageIndex",t[t.currentTabEntityId=6]="currentTabEntityId",t[t.cardSize=7]="cardSize",t[t.cardType=8]="cardType",t[t.experienceName=9]="experienceName",t[t.entityDataMap=10]="entityDataMap",t[t.entityViewMap=11]="entityViewMap",t[t.sportsSuggestIDMap=12]="sportsSuggestIDMap",t[t.interestOptions=13]="interestOptions",t[t.allRecommendations=14]="allRecommendations",t[t.dislikedEntities=15]="dislikedEntities",t[t.followedSports=16]="followedSports",t[t.sportsConfig=17]="sportsConfig",t[t.sportsStrings=18]="sportsStrings",t[t.rootTelemetryObject=19]="rootTelemetryObject",t[t.telemetryExt=20]="telemetryExt",t[t.isPinned=21]="isPinned",t[t.isExplorationCard=22]="isExplorationCard",t[t.isHidePopupOpen=23]="isHidePopupOpen",t[t.widgetDimension=24]="widgetDimension",t[t.searchSuggestions=25]="searchSuggestions",t[t.toggleInterestManager=26]="toggleInterestManager",t[t.sportsFeedDataParsed=27]="sportsFeedDataParsed",t[t.feedDataTimestamp=28]="feedDataTimestamp",t[t.wpoMetadata=29]="wpoMetadata",t[t.currentSpotlightEntityId=30]="currentSpotlightEntityId",t[t.previewTypeInfo=31]="previewTypeInfo",t[t.isInit=32]="isInit",t[t.isV2Data=33]="isV2Data",t[t.skinnyDataConsumed=34]="skinnyDataConsumed",t[t.isCopilotTheme=35]="isCopilotTheme",t[t.IsRubyPill=36]="IsRubyPill",t[t.pollOptionId=37]="pollOptionId",t[t.isRubyMiniWidget=38]="isRubyMiniWidget"}(E||(E={})),(0,F.G)({getInstance(){return M.vv.get("sportsStates",()=>new Map)}});const P={SportsInfo:"sports-sd-container",SportsInfoSpan:"sports-info-span",SportsMatchList:"sports-match-list",SportsMatch:"sports-match",Articles:"sports-articles",TeamExploration:"sports-team-exploration",TeamExplorationMatch:"sports-team-exploration-match",CricketExploration:"sports-cricket-exploration",TennisExploration:"sports-tennis-exploration",ExplorationHead:"sports-exploration-head",Standings:"sports-standings",Leaderboard:"sports-leaderboard",SportsCricket:"sports-cricket",SportsCricketV2:"sports-cricket-v2",SportsTennis:"sports-tennis",SportsMarchmadness:"sports-marchmadness",FeedsNotificationToast:"feeds-notification-toast",SportsHidePopup:"sports-hidepopup",SportsFre:"sports-fre",SportsEventBrief:"sports-event-brief",SportsEventCountry:"sports-event-country",SportsEventResults:"sports-event-results",SportsSpanMatch:"sports-span-match",SportsSpotlight:"sports-spotlight",AgentSpotlight:"agent-spotlight",SportsGameStats:"sports-game-stats",SportsGameLeaders:"sports-game-leaders",SportsCountdown:"sports-countdown",SportsAugmentCard:"sports-augment-card",SportsSpotlightRace:"sports-spotlight-race",SportsSpotlightTennis:"sports-spotlight-tennis",SportsTennisMatch:"sports-tennis-match",SportsSpotlightGolf:"sports-spotlight-golf",SharedHeroNewsCard:"shared-hero-news-card",SportsSimpleMatch:"sports-simple-match",SportsStandingsRankings:"sports-standings-rankings",SportsMedal:"sports-medal",SportsMedalV2:"sports-medal-v2",SportsEventSchedule:"sports-event-schedule",SportsRecentMedal:"sports-recent-medal",SportsRubyPill:"sports-ruby-pill",SportsInfoList:"sports-info-list",SportsSpotlightCricket:"sports-spotlight-cricket",SportsSpotlightCricketV2:"sports-spotlight-cricket-v2",SportsPickWinner:"sports-pick-winner-wc",SportsMatchWithScores:"sports-match-with-scores",SportsSpotlight2c:"sports-spotlight-2c",SportsUpcomingMatches:"sports-upcoming-matches",SportsTournamentsList:"sports-tournaments-list",SportsTournamentStatusRow:"tournament-status-row"},_={TeamVsTeam:P.SportsMatchList,TeamVsTeamWithBracket:P.SportsMarchmadness,Standings:P.Standings,Articles:P.Articles,TeamVsTeamExploration:P.TeamExploration,EventBrief:P.SportsEventBrief,OneVsOneEventResult:P.SportsEventResults,OneVsManyEventResult:P.SportsEventResults,TeamVsTeamEventResult:P.SportsEventResults,TeamStandingWithEvents:P.SportsEventCountry,TeamStandingWithMedals:P.SportsEventCountry,CricketExploration:P.CricketExploration,TennisExploration:P.TennisExploration,Spotlight:P.SportsSpotlight,SpotlightFRE:P.SportsSpotlight,SpotlightRace:P.SportsSpotlightRace,SpotlightTennis:P.SportsSpotlightTennis,SpotlightGolf:P.SportsSpotlightGolf,StandingsRankings:P.SportsStandingsRankings,LeagueTodaysEvents:P.SportsEventSchedule,TeamStandings:P.SportsMedal,SpotlightCricket:P.SportsSpotlightCricket,TournamentsList:P.SportsTournamentsList,Spotlight2c:P.SportsSpotlight2c,AgentSpotlight:"AgentSpotlight"},B={SportsMatch:"SportsMatch",SportsTournamentStatusRow:"SportsTournamentStatusRow",EventSDCardSportsMIT1:"EventSDCardSportsMIT1",EventSDCardSportsMIT2:"EventSDCardSportsMIT2",EventSDCardSportsMIT3:"EventSDCardSportsMIT3",SportsSpans:"SportsSpans",SportsAugment:"SportsAugment",SportsHeroFre:"SportsHeroFre",SportsHeroLeagueTodaysEvents:"SportsHeroLeagueTodaysEvents",SportsHeroMatch1SeasonStats:"SportsHeroMatch1SeasonStats",SportsHeroMatch1Stats:"SportsHeroMatch1Stats",SportsHeroMatch2SeasonStats:"SportsHeroMatch2SeasonStats",SportsHeroMatch2Stats:"SportsHeroMatch2Stats",SportsHeroMatch3SeasonStats:"SportsHeroMatch3SeasonStats",SportsHeroMatch3Stats:"SportsHeroMatch3Stats",SportsHeroMatchStatistics:"SportsHeroMatchStatistics",SportsSpotlight2Match1:"SportsSpotlight2Match1",SportsSpotlight2Match2:"SportsSpotlight2Match2",SportsHeroNews:"SportsHeroNews",SportsHeroOneVsManyEventResult:"SportsHeroOneVsManyEventResult",SportsHeroOneVsOneEventResult:"SportsHeroOneVsOneEventResult",SportsMatchMiniWidget:"SportsMatchMiniWidget",SportsHeroSeasonStatistics:"SportsHeroSeasonStatistics",SportsHeroStandingsRankings:"SportsHeroStandingsRankings",SportsHeroTeamStandings:"SportsHeroTeamStandings",SportsHeroTeamStandingWithEvents:"SportsHeroTeamStandingWithEvents",SportsHeroTeamStandingWithMedals:"SportsHeroTeamStandingWithMedals",SportsHeroTeamVsTeam:"SportsHeroTeamVsTeam",SportsHeroTeamVsTeamEventResult:"SportsHeroTeamVsTeamEventResult",SportsHeroVideo:"SportsHeroVideo",SportsHeroMatchCard:"SportsHeroMatchCard"};var R;B.SportsMatch,B.EventSDCardSportsMIT1,B.EventSDCardSportsMIT2,B.EventSDCardSportsMIT3,B.SportsSpans,B.SportsAugment,function(t){t[t.entityViewMap=0]="entityViewMap",t[t.sportsConfig=1]="sportsConfig",t[t.sportsStrings=2]="sportsStrings",t[t.rootTelemetryObject=3]="rootTelemetryObject",t[t.sportsFeedDataParsed=4]="sportsFeedDataParsed"}(R||(R={})),(0,F.G)({getInstance(){return M.vv.get("sportsSpanStates",()=>new Map)}});var A=i(49150);class I extends A.GH{}class j extends A.GH{}class L extends A.GH{}const O=Object.freeze({SportsCard:"SportsCard",Game:"sports_game",Team:"sports_team",Vertical:"sports",DislikeSports:"HideSport",SportsSuggest:"suggestresult",SportsSuggestUrl:"suggesturl",FollowSports:"Follow",SportsFRE:"freexperience",FollowTeam:"follow_team",HeroGem:"HeroGem",SportsInfoSpotlight:"SportsInfoSpotlight",SportsDiscoverMore:"SportsDiscoverMore",ChangeLeagueTeam:"ChangeLeagueTeam",Feedback:"Feedback",PopupHideSport:"PopupHideSport",PopupHide:"popup_hide",PopupCancel:"popup_cancel",PopupClose:"popup_close",EventBriefClick:"event_brief",EventBriefContentClick:"EventBriefContent",MarchMadnessCard:"MarchMadnessCard",SportsArticle:"sports_article",SportsCarousel:"SportsCarousel",TeamVsTeam:"TeamVsTeam",ExplorationDislike:"ExplorationDislike",SportsTopSpan:"SportsTopSpan",SportsStickySpan:"SportsStickySpan",SportsTopSpanOverlay:"SportsTopSpanOverlay",SportsStickySpanOverlay:"SportsStickySpanOverlay",SeeDetails:"seedetails",SportsNotificationToast:"SportsNotificationToast",SportsNotificationToastLink:"SportsNotificationToastLink",SportsNotificationToastDismiss:"SportsNotificationToastDismiss",SportsNotificationToastYes:"SportsNotificationToastYes",SportsNotificationToastNo:"SportsNotificationToastNo",SportsAfterFollowDismiss:"SportsAfterFollowDismiss",SportsSpotlightVideo:"SpotlightVideo",Countdown:"Countdown",PinToDesk:"PinToDesk",Destination:"destination",Augment:"augment",SportsRubyClick:"SportsRubyClick",SportsSpotlightTennisCard:"SportsSpotlightTennisCard",SportsSpotlightRaceCard:"SportsSpotlightRaceCard",SportsSpotlightGolfCard:"SportsSpotlightGolfCard",SportsStandingsRankingsCard:"SportsStandingsRankingsCard",SportsStandingsRankingsTable:"SportsStandingsRankingsTable",SportsMedalCard:"SportsMedalCard",SportsAgentSpotlight:"SportsAgentSpotlight",SportsEventResults:"SportsEventResults",SportsEventScheduleCard:"SportsEventScheduleCard",SportsEventCountryCard:"SportsEventCountryCard",SportsSpotlightCricketCard:"SportsSpotlightCricketCard",SportsPickWinner:"SportsPickWinner",SportsSpotlightMatchCard2c:"SportsSpotlightMatchCard2c",SportsSpotlightScores2c:"SportsSpotlightScores2c",SportsUpcomingMatches2c:"SportsUpcomingMatches2c",SportsTournamentsListCard:"SportsTournamentsListCard",SportsInfoMiniWidget:"SportsInfoMiniWidget",SportsTournamentStatusRow:"SportsTournamentStatusRow"}),H=Object.freeze({ChannelStoreLaunched:"ChannelStoreLaunched",Badge:"SportsBadge",TaskbarRotation:"SportsTBR",SportsFrePresent:"SportsFrePresent",SportsTabType:"SportsTabType",SportsLeagueName:"SportsLeagueName",SportsDefaultLeagueShown:"SportsDefaultLeagueShown",SportsUserFollowsDefaultLeague:"SportsUserFollowsDefaultLeague",SportsUserFollowsOtherteams:"SportsUserFollowsOtherteams",SportsDropdownChangedLeague:"SportsDropdownChangedLeague",SportsUserFollowsDropdownChangedLeague:"SportsUserFollowsDropdownChangedLeague",SportsUserGroup:"SportsUserGroup",SportsExplorationReason:"SportsExplorationReason",SportsDropdownChangedViewShown:"SportsDropdownChangedViewShown",SportsCardeSize:"SportsCardeSize",SportsReasonShown:"SportsReasonShown",SportsRecommendationPopupShown:"SportsRecommendationPopupShown",SportsDfltRecoPopupShown:"SportsDefaultRecommendationPopupShown",SportsExplorationPopupShown:"SportsExplorationPopupShown",SportsUsabilityPopupShown:"SportsUsabilityPopupShown",SportsExplorationCardShown:"SportsExplorationCardShown",SportsEventBriefShown:"SportsEventBriefShown",SpotlightCardPreviewType:"SpotlightCardPreviewType",SpotlightCardEntityId:"SpotlightCardEntityId",SportsNewSpotlightCard:"SportsNewSpotlightCard",SportsCardType:"SportsCardType",SportsVideoSpotlightShown:"SportsVideoSpotlightShown",SportsNewSpotlightCountdown:"SportsNewSpotlightCountdown",SportsPinToDeskShown:"SportsPinToDeskShown",SportsDataV2:"SportsDataV2",SportsPinToDeskEdgeFeatureEnabled:"SportsPinToDeskEdgeFeatureEnabled",SportsNewSpotlightExploration:"SportsNewSpotlightExploration",SportsNewSpotlightTennis:"SportsNewSpotlightTennis",SportsNewSpotlightRace:"SportsNewSpotlightRace",SportsNewSpotlightGolf:"SportsNewSpotlightGolf",SportsCardCurrentTabId:"SportsCardCurrentTabId",SportsCardCopilotCurrentTabId:"SportsCardCopilotCurrentTabId",SportsStandingsRankings:"SportsStandingsRankings",SportsCardIsInViewPort:"SportsCardIsInViewPort",SportsNewSpotlightCricket:"SportsSpotlightCricket",SportsCardFirstTagName:"SportsCardFirstTagName",SportsRubyPillShown:"SportsRubyPillShown",SportsTournamentsList:"SportsTournamentsList"})},27666(t,e,i){i.r(e),i.d(e,{SportsSpotlight(){return A}});var r=i(56911),a=i(84564),o=i(67689);class n extends a.z{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,o.h)()}}var s=i(92011),l=i(86856),p=i(74849),d=i(4126),c=i(22131),g=i(48751),h=i(12640),u=i(4968);const m=p.A` @container (min-width:180px) and (max-width:273px){.cop-video{.match-wrap{padding:40px 0 0px}}}`,v=p.A` .spotlight-video-tagtitle{right:16px}.spotlight-video-tagtitle{right:16px}._1x_3y.spotlight-video-img{margin-right:-50%}`,y=p.A`
`,f=p.A` .spotlight-video{display:block;position:relative;margin-top:8px;border-radius:8px;overflow:hidden;z-index:1}._1x_1y.spotlight-video{height:56px;width:56px;margin-top:0px}._1x_3y.spotlight-video{height:308px}.spotlight-video-img{max-width:100%;object-fit:scale-down;overflow:hidden;border-radius:8px;display:block}._1x_1y.spotlight-video-img{width:100%;height:100%;object-fit:cover}._1x_3y.spotlight-video-img{max-height:100%;max-width:none;margin-left:-50%}.spotlight-video-tagtitle{position:absolute;left:16px;top:9px;width:fit-content;height:16px;line-height:16px;border-radius:6px;border:1px solid rgba(255,255,255,0.20);background:rgba(255,255,255,0.10);backdrop-filter:blur(12.5px);padding:0 8px;font-weight:400;font-size:12px;color:#FFFFFF}.spotlight-video-title{position:absolute;left:16px;bottom:16px;height:44px;line-height:22px;font-weight:600;font-size:16px;color:#FFFFFF;display:-webkit-box;max-width:236px;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;white-space:normal}.spotlight-video-icon{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%)}._1x_1y.spotlight-video-icon > img{width:24px;height:24px}.spotlight-video-overlay{position:absolute;width:100%;height:100%;left:0;bottom:0;transition:background 0.1s;background-image:linear-gradient(180deg,rgba(0,0,0,0.00) 0,rgba(0,0,0,0.50) 59px,rgba(0,0,0,0.50) 100%)}.spotlight-fre-container{position:relative;z-index:var(--click-z-index);margin-bottom:16px;display:flex;flex-direction:row;align-items:start;max-width:fit-content}.spotlight-video-overlay:hover{background:rgba(0,0,0,0.25)}.spotlight-fre-text{overflow:hidden;white-space:nowrap;color:${g.l};text-decoration:none;padding-right:6px}._1x_1y.spotlight-fre-text{width:206px}.fre-header{font-weight:600;font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px);overflow:hidden;text-overflow:ellipsis}._1x_1y > .fre-header{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);margin-bottom:4px}.fre-content{font-weight:400;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);overflow:hidden;text-overflow:ellipsis}._1x_1y > .fre-content{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);white-space:normal;max-height:32px;-webkit-line-clamp:2;-webkit-box-orient:vertical;display:-webkit-box}.v2cntr{width:100%;height:266px;display:flex;flex-direction:column;gap:16px;margin-top:12px;sports-game-stats{margin-top:5px}}.cop-video{container-type:inline-size;.vidv3{height:196px;width:100%;display:block;position:relative;overflow:hidden;border-radius:var(--cstm-corner-media-in-card);corner-shape:squircle}.vidv3:focus-visible{outline-offset:-1px}.thumbnail{height:196px;width:100%;object-fit:cover;transition:transform 0.4s ease-out}.vidv3:hover .thumbnail{transform:scale(1.05)}.play-icon{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:48px;height:48px}.match-wrap{padding:40px 20px 0px}}.wrap{text-decoration:none;${u.f}
    }
`.withBehaviors(new l.t(null,v),new h.N(null,y),new d.o("isAdaptiveThemeEnabled",!0,m),(0,c.mr)(p.A` :host{forced-color-adjust:auto}`));var b=i(96950),x=i(39957),w=i(69259),$=i(58792);const S=`${(0,$.rA)().StaticsUrl}latest/icons-wc/icons/PlayIconLarge.svg`,k=`${(0,$.rA)().StaticsUrl}latest/sports/icons/PlayIconCopilot.svg`,T=b.qy`
    <div>
        ${(0,x.ux)(t=>t.viewModel.matches,b.qy`<sports-match
            :viewModel="${t=>t.viewModel}"
        ></sports-match>`,{positioning:!0})}
    </div>
`,C=b.qy`
    ${(0,w.z)(t=>null!=t.viewModel.headerData,b.qy`
        <div class="spotlight-fre-container">
            <a class="spotlight-fre-text ${t=>t.viewModel.cardSize}"
                data-t="${t=>t.viewModel.spotsVideoTelemetry}"
                href="${t=>{var e;return null===(e=t.viewModel.headerData)||void 0===e?void 0:e.clickThroughUrl}}"
                target="_blank"
            >
                <div class="fre-header" title="${t=>{var e;return null===(e=t.viewModel.headerData)||void 0===e?void 0:e.headerTextLine1}}">
                    ${t=>{var e;return null===(e=t.viewModel.headerData)||void 0===e?void 0:e.headerTextLine1}}
                </div>
                <div class="fre-content" title="${t=>{var e;return null===(e=t.viewModel.headerData)||void 0===e?void 0:e.headerTextLine2}}">
                    ${t=>{var e;return null===(e=t.viewModel.headerData)||void 0===e?void 0:e.headerTextLine2}}
                </div>
            </a>
            ${(0,w.z)(t=>{var e;return"_1x_1y"===t.viewModel.cardSize&&(null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.msnVideoEmbedLink)},b.qy`
                <a
                    class="spotlight-video ${t=>t.viewModel.cardSize}"
                    data-t="${t=>t.viewModel.spotsVideoTelemetry}"
                    href="${t=>{var e;return null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.msnVideoEmbedLink}}"
                    target="_blank"
                >
                    <img
                        class="spotlight-video-img ${t=>t.viewModel.cardSize}"
                        role="presentation"
                        src="${t=>{var e;return null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.videoThumbnailUrl}}"
                    />
                    <div class="spotlight-video-overlay">
                        <div class="spotlight-video-icon ${t=>t.viewModel.cardSize}">
                            <img role="presentation" src=${S} alt="" />
                        </div>
                    </div>
                </a>
            `)}
        </div>
    `)}
`,z=b.qy`
    <sports-game-stats
        :viewModel="${t=>{var e;return null===(e=t.viewModel.sportsGameStatsCard)||void 0===e?void 0:e.viewModel}}"
    >
    </sports-game-stats>
`,F=b.qy`
    <sports-game-leaders
        :viewModel="${t=>{var e;return null===(e=t.viewModel.sportsGameLeadersCard)||void 0===e?void 0:e.viewModel}}"
    >
    </sports-game-leaders>
`,M=b.qy`
    <sports-pick-winner-wc
        :viewModel="${t=>{var e;return null===(e=t.viewModel.sportsPickWinnerCard)||void 0===e?void 0:e.viewModel}}"
    >
    </sports-pick-winner-wc>
`,D=b.qy`
    ${(0,w.z)(t=>"_1x_1y"!==t.viewModel.cardSize,b.qy`
        <a
            class="spotlight-video ${t=>t.viewModel.cardSize}"
            data-t="${t=>t.viewModel.spotsVideoTelemetry}"
            href="${t=>{var e;return null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.msnVideoEmbedLink}}"
            target="_blank"
        >
            <img
                class="spotlight-video-img ${t=>t.viewModel.cardSize}"
                role="presentation"
                src="${t=>{var e;return null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.videoThumbnailUrl}}"
            />
            <div class="spotlight-video-overlay">
                ${(0,w.z)(t=>{var e;return null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.videoTagTitle},b.qy`
                    <div class="spotlight-video-tagtitle">
                        ${t=>{var e;return null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.videoTagTitle}}
                    </div>
                `)}
                <div class="spotlight-video-title" title="${t=>{var e;return(null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.videoTitle)||""}}">
                    ${t=>{var e;return(null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.videoTitle)||""}}
                </div>
                <div class="spotlight-video-icon">
                    <img role="presentation" src=${S} alt="" />
                </div>
            </div>
        </a>
    `)}
`,E=b.qy`
    ${(0,w.z)(t=>{var e;return null===(e=t.viewModel.sportsGameStatsCard)||void 0===e||null===(e=e.viewModel)||void 0===e?void 0:e.isFullCard},z,b.qy`
        ${(0,w.z)(t=>t.viewModel.matches.length,T,C)}
        ${(0,w.z)(t=>null!=t.viewModel.sportsPickWinnerCard,M)}
        ${(0,w.z)(t=>null!=t.viewModel.sportsGameStatsCard,z)}
        ${(0,w.z)(t=>null!=t.viewModel.sportsVideo,D)}
    `)}
`,P=b.qy`
    <a
        class="wrap"
        data-t="${t=>t.viewModel.telemetryTag}"
        href="${t=>t.viewModel.tabClickThroughUrl}"
        target="_blank"
    >
        <div class="v2cntr">
            ${(0,w.z)(t=>t.viewModel.matches.length,T,C)}
            ${(0,w.z)(t=>t.viewModel.sportsGameStatsCard,z)}
        </div>
    </a>
`,_=b.qy`
    <a
        class="vidv3"
        data-t="${t=>t.viewModel.spotsVideoTelemetry}"
        href="${t=>{var e;return null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.msnVideoEmbedLink}}"
        target="_blank"
    >
        <img
            class="thumbnail"
            role="presentation"
            src="${t=>{var e;return null===(e=t.viewModel.sportsVideo)||void 0===e?void 0:e.videoThumbnailUrl}}"
        />
        <img role="presentation" src=${k} alt="" class="play-icon"/>
    </a>
`,B=b.qy`
    <div class="cop-video">
        ${_}
        <div class="match-wrap">
            ${T}
        </div>
    </div>
`,R=b.qy`
    ${(0,w.z)(t=>null!=t.viewModel,b.qy`${t=>{return(e=t.viewModel).sportsGameLeadersCard?F:e.isCopilotTheme&&e.sportsVideo?B:e.isCopilotTheme?P:E;var e}}`)}
`;let A=class extends n{};A=(0,r.Cg)([(0,s.E)({name:"sports-spotlight",template:R,styles:f,shadowOptions:{delegatesFocus:!0}})],A)},30439(t,e,i){let r;i.d(e,{Nx(){return r}})},34386(t,e,i){i.r(e),i.d(e,{SportsPickWinnerWC(){return I}});var r=i(56911),a=i(23587),o=i(60815),n=i(66591),s=i(92079),l=i(48566);class p extends s.a{constructor(){super(...arguments),this.handlePollOptionOnClick=t=>{this.viewModel.userVote||(this.viewModel.recordUserVote(t),this.viewModel.userVote=t,this.handleVoteDataBuffer(t),o.cP.notify(this,"viewModel"))},this.handleVoteDataBuffer=t=>{if(""!==t){this.viewModel.teamsVoteData.forEach((e,i)=>this.viewModel.teamsVoteData[i]=e.id===t?{...e,voteCount:(e.voteCount||0)+1}:e);const e=(this.viewModel.teamsVoteData[0].voteCount||0)+(this.viewModel.teamsVoteData[1].voteCount||0);this.viewModel.teamsVoteData.forEach((t,i)=>this.viewModel.teamsVoteData[i].votePercentage=this.getTeamPercent(t.voteCount||0,e))}}}connected(){var t,e;super.connected(),this.viewModel.userVote&&this.handleVoteDataBuffer(this.viewModel.userVote),this.commentsButton=null===(t=this.shadowRoot)||void 0===t||null===(e=t.querySelector)||void 0===e?void 0:e.call(t,".comments-button"),this.commentsButton&&this.viewModel.handleCommentsClick&&this.commentsButton.addEventListener("click",this.viewModel.handleCommentsClick)}disconnected(){this.commentsButton&&this.viewModel.handleCommentsClick&&this.commentsButton.removeEventListener("click",this.viewModel.handleCommentsClick)}getPollResultText(t){return this.viewModel.gameState===a.T0.Final?null!=t&&t.hasWon?this.viewModel.strings.winnerText:"":(this.viewModel.disableVoting||this.viewModel.userVote)&&void 0!==t.votePercentage?`${t.votePercentage}%`:""}getComponentString(t){var e,i;const{gameState:r,strings:o}=this.viewModel;let n="";if(this.viewModel.userVote){if(r===a.T0.PreGame||r===a.Xp.preGame)n=t?o.postselPrimary:o.postselSecondaryPre;else if(r===a.T0.InProgress||r===a.Xp.inprogressGame)n=t?o.postselPrimary:o.postselSecondaryLive;else if(r===a.T0.Final){var s;n=null!==(s=this.viewModel.teamsVoteData.find(t=>t.id===this.viewModel.userVote))&&void 0!==s&&s.hasWon?t?o.postselPrimaryWon:o.postselSecondaryPost:t?o.postselPrimaryLost:o.postselSecondaryPost}}else r===a.T0.PreGame||r===a.Xp.preGame?n=t?o.preselPrimary:o.preselSecondary:r===a.T0.InProgress||r===a.Xp.inprogressGame?n=t?o.preselPrimaryLive:o.preselSecondaryLive:r===a.T0.Final&&(n=t?o.preselPrimaryLive:o.postselSecondaryPost);const p=null===(e=this.viewModel.teamsVoteData.find(t=>t.id===this.viewModel.userVote))||void 0===e?void 0:e.shortName;return null!==(i=n)&&void 0!==i&&i.includes("{teamName}")&&(n=p?l.Qf.Format(n,{teamName:p}):""),n}getTeamPercent(t,e){return Math.round(t/e*100)||0}getCanUserVote(){return!this.viewModel.userVote&&!this.viewModel.disableVoting}getTeamName(t){return this.viewModel.isRuby&&t.name&&(3===this.viewModel.columnLayout||4===this.viewModel.columnLayout)?t.name:t.shortName||""}get teamButtonClassNames(){return(0,n.x)("pick-winner-option",["voted",!!this.viewModel.userVote],["disabled",!!this.viewModel.disableVoting],["entrypoint",!!this.viewModel.isEntrypoint])}getTeamButtonStyles(t){return!this.getCanUserVote()&&this.viewModel.isRuby&&t.teamColor?`background: ${t.teamColor}0D;`:""}getTeamButtonAriaLabel(t){const e=this.getTeamName(t),i=e&&this.viewModel.userVote===t.id?this.viewModel.strings.selectedText.replace("{0}",e||""):e;return this.getCanUserVote()||void 0===t.votePercentage?i:`${i} ${t.votePercentage}%`}isTeamWinningPoll(t,e){return e.reduce((t,e)=>t.votePercentage&&e.votePercentage&&t.votePercentage>e.votePercentage?t:e).id===t}getTeamButtonPercentageBarClassNames(t){return(0,n.x)("option-item-bar",["selected",!!this.viewModel.userVote&&this.viewModel.userVote===t||!!this.viewModel.disableVoting&&this.isTeamWinningPoll(t,this.viewModel.teamsVoteData)])}getTeamButtonPercentageBarStyles(t){if(!this.getCanUserVote()&&void 0!==t.votePercentage){let e=`width: ${t.votePercentage}%;`;return this.viewModel.isRuby&&t.teamColor&&(e+=` background: ${t.teamColor}33`),e}return"width: 0%;"}getOptionItemContentClassNames(t){return(0,n.x)("option-item-content",["entrypoint",!!this.viewModel.isEntrypoint],["selected",this.viewModel.userVote===t])}}(0,r.Cg)([o.sH],p.prototype,"viewModel",void 0),(0,r.Cg)([o.sH],p.prototype,"commentsButton",void 0);var d=i(92011),c=i(22683),g=i(45476),h=i(37302),u=i(61138),m=i(71157),v=i(64003),y=i(92393),f=i(74849),b=i(22131),x=i(4968);const w=f.A` .option-item-bar{background:var(--color-neutral-stroke-2,#EEEEEE)}.option-item-bar.selected{background:var(--color-brand-background-2-hover,#E0EDFF)}.pick-winner-option{border:1px solid var(--color-neutral-stroke-1,#D1D1D1)}`,$=f.A` .option-item-bar{background:var(--color-neutral-stroke-2,#3D3D3D)}.option-item-bar.selected{background:var(--color-brand-background-2-hover,#243966)}.like-icon{filter:invert(1)}.pick-winner-option{border:1px solid var(--color-neutral-stroke-1,#666666)}`,S=f.A` .pick-winner-container{border-top:1px solid ${c.hb};padding:8px 0;gap:8px;display:grid}.pick-winner-container.ruby{border:none;gap:16px;padding:0}.pick-winner-options{padding:unset;display:grid;gap:6px;margin-top:unset;margin-bottom:4px}.ruby .pick-winner-options{margin:unset;gap:16px}.pick-winner-option{all:unset;${x.f}
        display: flex;
        height: 36px;
        align-items: center;
        border-radius: 100px;
        overflow: hidden;
        background: ${g.Wl}}.pick-winner-option:focus-visible{outline:-webkit-focus-ring-color auto 1px;outline-offset:2px}.ruby .pick-winner-option{height:56px;border:none}.pick-winner-option:not(.voted):not(.disabled):hover{cursor:pointer;background-color:${h.Xt}}.pick-winner-option.entrypoint{height:30px}.option-item-content{display:flex;justify-content:space-between;width:100%;position:relative;font-weight:600;padding:0 10px;font-size:14px}.ruby .option-item-content{padding:0 16px;align-items:center}.option-item-bar{position:absolute;height:100%;left:0;width:0%;transition:width 0.5s ease-in-out}.option-item-text-container{display:flex;gap:6px}.ruby .option-item-text-container{gap:12px;align-items:center}.option-item-text{-webkit-line-clamp:1;overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;word-break:break-all}.option-item-content.entrypoint:not(.selected){font-weight:400}.option-item-image{width:auto;height:24px}.ruby .option-item-image{height:40px}.like-button-container{align-items:center;display:flex}.pick-winner-text-container{display:flex;flex-direction:column;gap:2px}.pick-winner-primary-text{font-size:${u.k};font-weight:600}.ruby .pick-winner-primary-text,.ruby .option-item-text,.ruby .option-item-result{font-weight:550;font-size:18px;line-height:${m.O}}.ruby .option-item-result{display:flex;gap:4px}.pick-winner-secondary-text{font-size:${u.k};
        color: ${v.c}}.comments-button{all:unset;font-size:inherit;${x.f}
        color: ${y.W_};text-decoration:underline;cursor:pointer}.comments-button:hover{color:${y.YL}}.comments-button:focus-visible{outline:-webkit-focus-ring-color auto 1px}.ruby .like-icon{height:24px}`.withBehaviors((0,b.C7)(w),(0,b.G2)($));var k=i(96950),T=i(69259),C=i(93809),z=i(39957),F=i(58792),M=i(60239);const D=`${(0,F.rA)().StaticsUrl}/latest/fluent-icons/thumb_like_16_regular.svg`,E=`${(0,F.rA)().StaticsUrl}/latest/fluent-icons/thumb_like_16_filled.svg`,P=t=>k.qy`
    <div class="like-button-container">
        <img class="like-icon" src="${e=>t?E:D}" alt="" />
    </div>
`,_=k.qy`
    <div class="option-item-result">
        ${(t,e)=>e.parent.getPollResultText(t)}
        ${(0,T.z)((t,e)=>e.parent.viewModel.isRuby&&e.parent.viewModel.gameState!==a.T0.Final,k.qy`
            ${(t,e)=>P(e.parent.viewModel.userVote===t.id)}
        `)}
    </div>
`,B=k.qy`
    <button
        type="button"
        id=${t=>t.id}
        class=${(t,e)=>e.parent.teamButtonClassNames}
        @click=${(t,e)=>{var i,r;return e.parent.getCanUserVote()&&(null===(i=(r=e.parent).handlePollOptionOnClick)||void 0===i?void 0:i.call(r,t.id))}}
        data-t=${(t,e)=>{var i;return e.parent.getCanUserVote()?null===(i=e.parent.viewModel.telemetryContext)||void 0===i?void 0:i.voteButtonTag:null}}
        style=${(t,e)=>e.parent.getTeamButtonStyles(t)}
        aria-label=${(t,e)=>e.parent.getTeamButtonAriaLabel(t)}
        title=${(t,e)=>e.parent.getTeamButtonAriaLabel(t)}
    >
        <div
            class=${(t,e)=>e.parent.getTeamButtonPercentageBarClassNames(t.id)}
            style=${(t,e)=>e.parent.getTeamButtonPercentageBarStyles(t)}
        ></div>
        <div class=${(t,e)=>e.parent.getOptionItemContentClassNames(t.id)}>
            <div class="option-item-text-container">
                ${(0,T.z)((t,e)=>!e.parent.viewModel.isEntrypoint,k.qy`
                    <img class="option-item-image" alt="" src=${t=>t.imageUrl||""} />
                `)}
                <span class="option-item-text" aria-hidden="true">${(t,e)=>e.parent.getTeamName(t)}</span>
                ${(0,T.z)((t,e)=>!e.parent.viewModel.isRuby&&!e.parent.viewModel.disableVoting&&!e.parent.viewModel.isEntrypoint&&e.parent.viewModel.userVote===t.id,k.qy`
                    ${(t,e)=>P(e.parent.viewModel.userVote===t.id)}
                `)}
            </div>
            ${(0,T.z)((t,e)=>!e.parent.getCanUserVote(),_,k.qy`
                ${(0,T.z)((t,e)=>!e.parent.viewModel.isEntrypoint,k.qy`
                    ${(t,e)=>P(e.parent.viewModel.userVote===t.id)}
                `)}
            `)}
        </div>
    </button>
`,R=k.qy`
    <div
        class="pick-winner-container ${t=>t.viewModel.isRuby?"ruby":""}"
        data-t=${t=>{var e;return null===(e=t.viewModel.telemetryContext)||void 0===e?void 0:e.rootTag}}
    >
        <div class="pick-winner-text-container">
            ${(0,T.z)(t=>!!t.getComponentString(!0),k.qy`
                <div class="pick-winner-primary-text">
                    ${t=>t.getComponentString(!0)}
                </div>
            `)}
            ${(0,T.z)(t=>!t.viewModel.isRuby&&!!t.getComponentString(!1),k.qy`
                <div
                    class="pick-winner-secondary-text"
                    :innerHTML=${(0,C.U)(t=>t.getComponentString(!1),M.r)}
                ></div>
            `)}
        </div>
        <div class="pick-winner-options">
            ${(0,z.ux)(t=>t.viewModel.teamsVoteData,k.qy`
                ${B}
            `,{positioning:!0})}
        </div>
    </div>
`,A=k.qy`
    ${(0,T.z)(t=>!!t.viewModel,R)}
`;let I=class extends p{};I=(0,r.Cg)([(0,d.E)({name:"sports-pick-winner-wc",template:A,styles:S,shadowOptions:{delegatesFocus:!0}})],I)},34959(t,e,i){i.d(e,{V(){return d}});var r=i(79811),a=i(23587),o=i(49150),n=i(58792),s=i(96950),l=i(93552),p=i(22341);class d extends a.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.gameStatsFormatMap={teamEarnedRunAverage:{toFix:2,isPercent:!1},faceoffWinPct:{isPercent:!0},fieldGoalPer:{toFix:1,isPercent:!0},freeThrowsPercentage:{toFix:1,isPercent:!0},threePointersPercentage:{toFix:2,isPercent:!0},timeOfPossession:{isTime:!0}},this.gameStatsLocKeyMap={yards:"rushingYards",battingAverage:"teamBattingAverage",earnedRunAverage:"teamEarnedRunAverage",strikeouts:"strikeoutsThrown",walks:"walksAllowed",errors:"errorsCommitted",personalFouls:"fouls",fieldGoalsPercentage:"fieldGoalPer",totalYards:"totalYards",passingYards:"passingYardsAllowedPerGame",penaltyYards:"penaltyYardsPerGame",timeOfPossession:"timeOfPossession"}}async transform(t){this.isCopilotTheme=t.isCopilotTheme||!1;const e={...t,spotlightData:this.transformSportsSpotlightData(t.spotlightData,t.tabClickThroughUrl,t.isSpotlightFRE)},i=await this.getCurrentViewModel(e);return{viewTemplate:s.qy`
                <sports-spotlight
                    :viewModel="${i}"
                ></sports-spotlight>`}}async getCurrentViewModel(t){if(!t||0===Object.keys(t).length)return void(0,p.vV)(l.K0b,"Spotlight metadata missing",`market=${n.T3.CurrentMarket}`,t);const e=await this.getMatches(t),{cardSize:i,tabClickThroughUrl:r}=t;let s;const d=i===o.uE._1x_1y||i===o.uE._05u;let c,g;!d&&this.transformerProvider.config.enablePickWinner&&(s=await this.getPolls(t)),!t.isSpotlightFRE&&d||null!=s||(c=this.getVideoInfo(t),g=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:a.BP.SportsSpotlightVideo}));const h=this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{...t.telemetryConstants,name:a.BP.SportsInfoSpotlight});let u,m;d||null!=c||null!=s||(u=await this.getGameStatsInfo(t)),e.length||(m=t.spotlightData.headerData,m.clickThroughUrl=t.tabClickThroughUrl);return{cardSize:i,tabClickThroughUrl:r,matches:e,sportsGameStatsCard:u,sportsPickWinnerCard:s,sportsVideo:c,headerData:m,spotsVideoTelemetry:g,telemetryTag:h,sportsGameLeadersCard:await this.getGameLeadersInfo(t),isCopilotTheme:this.isCopilotTheme}}async getPolls(t){const{pollOptionId:e,isSpotlight2Card:i,spotlightData:{poll:r,matchlist:o}={}}=t;if(!(null!=r&&r.pollId||(null==r?void 0:r.type)===a.t9.PickWinner)||null==o||!o.length||!o[0].sportsMatchData)return null;const{participantOne:n,participantTwo:s}=o[0].sportsMatchData||{};if(!o||!n||!s)return null;if(e){var l;r.userVote=e;const t=null===(l=r.options)||void 0===l?void 0:l.find(t=>t.id===e);var p;if(t)t.count=(parseInt(t.count)+1).toString();else null===(p=r.options)||void 0===p||p.push({id:e,count:"1"})}const d={poll:r,match:o[0].sportsMatchData,isSpotlight2Card:i,parentTelemetryObject:t.telemetryObject,telemetryConstants:t.telemetryConstants};return await this.transformerProvider.generateView(d,a.hi.SportsPickWinner)}getVideoInfo(t){const{video:e}=t.spotlightData||{},i=t.isSpotlightFRE?null:this.transformerProvider.strings.gameHighlights;return e?{...e,videoTagTitle:i}:null}async getGameStatsInfo(t){const{spotlightData:e,isSpotlight2Card:i}=t||{},{sportsGameStats:r,isSeasonStats:o=!1,matchlist:n,isGameStatsFull:s}=e||{};if(!r)return null;const{cardSize:l}=t,{participantOne:p,participantTwo:d}=n[0].sportsMatchData||{},c={cardSize:l,sportsGameStats:r,isSeasonStats:o,isSpotlight2Card:i,isFullCard:s,participants:[p,d],isCopilotTheme:this.isCopilotTheme};return await this.transformerProvider.generateView(c,a.hi.SportsGameStats)}async getGameLeadersInfo(t){var e,i;const{gameLeaders:o,matchlist:n}=t.spotlightData||{},{sportsMatchData:s}=n.length?n[0]:{sportsMatchData:void 0},l={};if(null!=s&&null!==(e=s.participantOne)&&void 0!==e&&e.id&&(l[s.participantOne.id]=(0,r.gS)(s.participantOne.primaryColorHex)),null!=s&&null!==(i=s.participantTwo)&&void 0!==i&&i.id&&(l[s.participantTwo.id]=(0,r.gS)(s.participantTwo.primaryColorHex)),!o)return null;const{cardSize:p}=t,d={cardSize:p,sportsGameLeaders:o,teamColors:l,parentTelemetryObject:t.telemetryObject};return await this.transformerProvider.generateView(d,a.hi.SportsGameLeaders)}async getMatches(t){const{spotlightData:e,telemetryObject:i,telemetryConstants:o,isHeroCard:n,isSpotlight2Card:s,followedSports:l=new Map}=t,{matchlist:p}=e||{};if(!p)return[];const d=(0,r.Yo)(p),c=p.map(async e=>{const p=e.sportsMatchData,c=(0,r.gK)(p.participantOne,l),g=(0,r.gK)(p.participantTwo,l),h={matchData:e,parentTelemetryObject:i,telemetryConstants:o,participantOneFollowed:c,participantTwoFollowed:g,isContainLiveMatch:d,reason:"",enableLiveScores:this.transformerProvider.config.enableLiveScores,showMatchUXV2:n,isSpotlight2Card:s,isSpotlightCard:Boolean(t.spotlightData.statistics),isCopilotTheme:this.isCopilotTheme};return this.transformerProvider.generateView(h,a.hi.SportsMatch)});return(await Promise.all(c)).filter(r.z2)}transformSportsSpotlightData(t,e){let i=arguments.length>2&&void 0!==arguments[2]&&arguments[2];const{statistics:o,video:s,match:d,poll:c,headerData:g,gameLeaders:h}=t;let u,m=r.Zi,v=r.ZL;const y=[];if(d){var f,b,x,w,$;const t=(0,r.yn)(d.gameStartDateTime);d.gameDate=(0,r.AL)(t,n.T3.CurrentMarket),d.gameStartTime=(d.gameStartDateTimeIsToBeAnnounced?null:(0,r.ry)(t,n.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,d.gameStateCatetory="string"!=typeof d.gameState?(0,r.m5)(d.gameState.state):d.gameStateCatetory,"string"!=typeof d.gameState&&(d.gamePeriodAndClock=(0,r.PH)(d.gameState)),d.participantOne&&(d.participantOne.scheduleUrl=(0,r.Ot)(d.participantOne.gameCenterUrl)),d.participantTwo&&(d.participantTwo.scheduleUrl=(0,r.Ot)(d.participantTwo.gameCenterUrl)),d.gameCenterUrl&&(d.matchClickthroughUrl=(0,r.Ot)(d.gameCenterUrl)),d.participantOne.imageUrl=(0,r.iK)(d.participantOne.imageId,!d.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),d.participantTwo.imageUrl=(0,r.iK)(d.participantTwo.imageId,!d.participantOne.imageId,this.transformerProvider.config.teamImageInfoEnhanced),"string"==typeof d.gameState||d.gamePeriod||(d.gamePeriod=d.gameState.gamePeriod||d.gamePeriod),d.gameState=d.gameStateCatetory===a.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:d.gameStateCatetory,this.adjustParticipantColors(d);const e=(null===(f=d.participantOne)||void 0===f?void 0:f.primaryColorHex)===(null===(b=d.participantTwo)||void 0===b?void 0:b.primaryColorHex)&&"ffffff"===(null===(x=d.participantOne)||void 0===x||null===(x=x.primaryColorHex)||void 0===x?void 0:x.toLowerCase());!e&&null!==(w=d.participantOne)&&void 0!==w&&w.primaryColorHex&&(m=(0,r.gS)(d.participantOne.primaryColorHex)),!e&&null!==($=d.participantTwo)&&void 0!==$&&$.primaryColorHex&&(v=(0,r.gS)(d.participantTwo.primaryColorHex)),d.matchClickthroughUrl?u=d.matchClickthroughUrl:d.gameCenterUrl&&(u=(0,r.Ot)(d.gameCenterUrl),d.matchClickthroughUrl=u),y.push({sportsMatchData:d})}const S=this.transformGameState(o,[m,v]),k=!(h&&0!==Object.keys(h).length||S&&0!==S.length||s||c);if(i||0!==y.length&&!k&&u){if(s){let t=u??"";i&&(t=(0,r.Ot)(e)),s.msnVideoEmbedLink=(0,r._S)(s,t)}return{gameLeaders:h,matchlist:y,sportsGameStats:S,video:s,poll:c,matchClickthroughUrl:u||"",isSeasonStats:o&&o.season&&2===o.season.length,isGameStatsFull:!(null==o||!o.isFullCard),headerData:g}}(0,p.vV)(l.K0b,"Spotlight metadata missing",`market=${n.T3.CurrentMarket}`,t)}transformGameState(t,e){if(!t||0===Object.keys(t).length)return;let i=[];t.season&&2===t.season.length?i=t.season:t.game&&2===t.game.length&&(i=t.game);const r=[];if(i[0]&&i[1]){const a=i[0],o=i[1],n=t.statsKeyOrder||Object.keys(a);for(const t of n){const i=Number(a[t]),n=Number(o[t]),s=this.gameStatsFormatMap[t],l=this.formatGameStatsNumber(i,s),p=this.formatGameStatsNumber(n,s),d=this.calculatePercentNumbers(i,n),c={key:this.gameStatsLocKeyMap[t]||t,left:i,right:n,leftText:l,rightText:p,leftColor:e[0],rightColor:e[1],...d};r.push(c)}}return r}formatGameStatsNumber(t,e){if(!e)return t.toString();let i="";return e.isPercent&&(i="%"),void 0!==e.toFix?`${t.toFixed(e.toFix)}${i}`:e.isTime?this.secondsToMinutes(t):`${t}${i}`}secondsToMinutes(t){return`${Math.floor(t/60)}:${Math.floor(t%60).toString().padStart(2,"0")}`}calculatePercentNumbers(t,e){let i=0,r=0,a=0;return 0!==t&&0!==e?(a=.7,i=t/(t+e)*99.3,r=e/(t+e)*99.3):0===t&&0===e?(i=0,r=0,a=0):0===t?(i=2.3,r=97,a=.7):0===e&&(i=97,r=2.3,a=.7),{leftPercent:Number(i.toFixed(1)),rightPercent:Number(r.toFixed(1)),gap:a}}adjustParticipantColors(t){var e,i;if(!this.isCopilotTheme)return;const a=null===(e=t.participantOne)||void 0===e?void 0:e.primaryColorHex.toLowerCase(),o=null===(i=t.participantTwo)||void 0===i?void 0:i.primaryColorHex.toLowerCase(),n=this.isClashingColor(a),s=this.isClashingColor(o);n&&(t.participantOne.primaryColorHex=r.Zi),s&&(t.participantTwo.primaryColorHex=r.ZL)}isClashingColor(t){const e=(0,r.jJ)(),i=t.startsWith("#")?t.slice(1):t,a=parseInt(i.slice(0,2),16),o=parseInt(i.slice(2,4),16),n=parseInt(i.slice(4,6),16),s=a>200&&o>200&&n>200;return e?s||a<50&&o<50&&n<50:s}}},36516(t,e){e.A='<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><g opacity=".75"><rect x=".24" y=".71" width="19.05" height="19.05" rx="9.52" fill="#fff"/><path d="M10.74 6.46a.75.75 0 1 0-1.5 0v3.25H5.99a.75.75 0 1 0 0 1.5h3.25v3.25a.75.75 0 0 0 1.5 0v-3.25h3.25a.75.75 0 1 0 0-1.5h-3.25V6.46Z" fill="#212121"/></g></svg>'},42792(t,e,i){i.d(e,{R7(){return m},e(){return h},kc(){return u},nH(){return g}});var r=i(57416),a=i(55153),o=i(95239),n=i(26920),s=i(48751),l=i(64187),p=i(22131),d=i(74849),c=i(50882);const g=d.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,h=d.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${n.XA} * 1px) solid ${a.cu};
        border-radius: calc((${r.JU} - ${n.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${s.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${n.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,u=(0,p.mr)(d.A`
            :host {
                background: ${c.A.Canvas};
                color: ${c.A.CanvasText};
            }
        `),m=d.A`
    ${h}
    ${g}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(u)},43774(t,e,i){i.d(e,{p4(){return m},ls(){return v},vA(){return u},nF(){return h}});var r=i(45755),a=i(68009),o=i(95239);const{create:n}=r.G,s=n("neutral-stroke-strong-hover-delta",40),l=n("neutral-stroke-strong-active-delta",16),p=n("neutral-stroke-strong-focus-delta",25);var d=i(31023);const{create:c}=r.G,g=c({name:"neutral-stroke-strong-recipe"},{evaluate(t){return function(t,e,i,r,o,n){const s=(0,a.F)(e),l=t.colorContrast(e,i),p=t.closestIndexOf(l);return{rest:l,hover:t.get(p+s*r),active:t.get(p+s*o),focus:t.get(p+s*n)}}(t(d.r),t(o.p),3,t(s),t(l),t(p))}}),h=c("neutral-stroke-strong-rest",t=>t(g).evaluate(t).rest),u=c("neutral-stroke-strong-hover",t=>t(g).evaluate(t).hover),m=c("neutral-stroke-strong-active",t=>t(g).evaluate(t).active),v=c("neutral-stroke-strong-focus",t=>t(g).evaluate(t).focus)},47417(t,e,i){i.d(e,{Bk(){return u},UU(){return g},C9(){return w},OY(){return y},eU(){return b}});var r=i(3083),a=i(58792),o=i(42161),n=i(52012);const s=Object.freeze({sport:"sport",league:"league",team:"team",player:"player",flag:"flag",venue:"venue",background:"background",teaser:"teaser"});Object.freeze({[n.zv.baseball]:"OSB.26BE_Baseball.png",[n.zv.football]:"OSB.1F3C8_AmericanFootball.png",[n.zv.volleyballbeach]:"OSB.1F3D0_Volleyball.png",[n.zv.volleyballteam]:"OSB.1F3D0_Volleyball.png",[n.zv.tennis]:"OSB.Tennis.png",[n.zv.tabletennis]:"OSB.1F3DG_TableTennis.png",[n.zv.soccer]:"OSB.1F3D1_Soccer.png",[n.zv.rugbyleague]:"OSB.1F3C9_RugbyFootball.png",[n.zv.rugbyunion]:"OSB.1F3C9_RugbyFootball.png",[n.zv.golf]:"OSB.26F3_Golf.png",[n.zv.cricket]:"OSB.1F3CF_CricketGame.png",[n.zv.boxing]:"OSB.1F94A_Boxing.png",[n.zv.bowling]:"OSB.1F3B3_Bowling.png",[n.zv.basketball]:"OSB.1F3C0_Basketball.png",[n.zv.badminton]:"OSB.1F3F8_Badminton.png",[n.zv.icehockey]:"OSB.1F3D2_IceHockey.png"}),i(48566);var l=i(26220),p=i(50180),d=i(36297);const c="OSB.team_logo_placeholder.png",g=`${(0,a.rA)().StaticsUrl}/latest/sports/img/IPL/DefaultPlayerImage.svg`,h=`${(0,a.rA)().StaticsUrl}/latest/sports/img/flags/generic.svg`,u={width:28,height:28,enableDpiScaling:!0,devicePixelRatio:2,format:r.f5.PNG},m="sports/",v="MSports";function y(t,e,i){let a=!(arguments.length>3&&void 0!==arguments[3])||arguments[3],o=t;if((0,p.oT)(o)){if(!a)return"";switch(i){case s.player:o=g;break;case s.team:o=c;break;case s.flag:o=h;break;default:o=c}}return e.crop||(e.crop=0),e.padding||0===e.padding||(e.padding=1),o.indexOf(".")>0&&!o.startsWith("http")?(0,r.oQ)(`${r.Ro}?id=${o}&pid=${v}`,e):f(o,e)}function f(t,e){return t.startsWith("http")?(0,r.oQ)(t,e):(0,r.XP)(t,e)}function b(t,e){if(t||(t=m),t.startsWith("/")||(t=`/${t}`),e)for(const i in e)Object.prototype.hasOwnProperty.call(e,i)&&(t=t.replace(`{${i}}`,e[i]));let i=`${a.T3.NavTargetUrlWithLocale}${t}`;if(i=(0,o.wY)(i),function(t){const e=new d.m(t||(0,l.iA)());return"1"===e.get("vptest")||"vp"===e.get("reqsrc")}())return i;const r=new URL(i),n=new URLSearchParams((0,l.iA)()),s=n.getAll("item");null!=s&&s.length&&s.forEach(t=>{t&&r.searchParams.append("item",t)});const p=n.getAll("src");null!=p&&p.length&&p.forEach(t=>{t&&r.searchParams.append("src",t)});const c=n.get("uxmode");return c&&r.searchParams.append("uxmode",c),r.href}const x={FullName:"FullName",ShortName:"ShortName",SchoolName:"SchoolName",Alias:"Alias",Abbreviation:"Abbreviation"};function w(t){var e,i,r,a,o,n,s,l,d;let c=arguments.length>1&&void 0!==arguments[1]?arguments[1]:[];if(!t)return null;if(!c.length){var g,h;if(!(0,p.oT)(null===(g=t.name)||void 0===g?void 0:g.localizedName))return t.name.localizedName;if(!(0,p.oT)(null===(h=t.name)||void 0===h?void 0:h.rawName))return t.name.rawName}for(const g of c)switch(g){case x.FullName:if(!(0,p.oT)(null===(e=t.name)||void 0===e?void 0:e.localizedName)||!(0,p.oT)(null===(i=t.name)||void 0===i?void 0:i.rawName))return t.name.localizedName??t.name.rawName;break;case x.ShortName:if(!(0,p.oT)(null===(r=t.shortName)||void 0===r?void 0:r.localizedName))return t.shortName.localizedName;if(!(0,p.oT)(null===(a=t.name)||void 0===a?void 0:a.localizedName))return t.name.localizedName;if(!(0,p.oT)(null===(o=t.shortName)||void 0===o?void 0:o.rawName))return t.shortName.rawName;if(!(0,p.oT)(null===(n=t.name)||void 0===n?void 0:n.rawName))return t.name.rawName;break;case x.SchoolName:if(!(0,p.oT)(null===(s=t.schoolName)||void 0===s?void 0:s.localizedName))return t.schoolName.localizedName;if(!(0,p.oT)(t.schoolName))return t.schoolName;break;case x.Alias:if(!(0,p.oT)(null===(l=t.alias)||void 0===l?void 0:l.localizedName))return t.alias.localizedName;if(!(0,p.oT)(t.alias))return t.alias;break;case x.Abbreviation:if(!(0,p.oT)(null===(d=t.abbreviation)||void 0===d?void 0:d.localizedName))return t.abbreviation.localizedName;if(!(0,p.oT)(t.abbreviation))return t.abbreviation}return null}},49150(t,e,i){var r;i.d(e,{GH(){return s},uE(){return r},_n(){return a},iD(){return o},CE(){return n}}),function(t){t._1x_1y="_1x_1y",t._1x_2y="_1x_2y",t._1x_3y="_1x_3y",t._1x_4y="_1x_4y",t._1x_5y="_1x_5y",t._2x_1y="_2x_1y",t._2x_2y="_2x_2y",t._2x_3y="_2x_3y",t._2x_4y="_2x_4y",t._2x_6y="_2x_6y",t._3x_1y="_3x_1y",t._3x_2y="_3x_2y",t._4x_1y="_4x_1y",t._4x_2y="_4x_2y",t._5x_1y="_5x_1y",t._5x_2y="_5x_2y",t._125u="1.25u",t._15u="1.5u",t._05u="0.5u",t._2c="2c",t.pill="pill"}(r||(r={}));const a={DropdownRecommendation:"dropdown-recommendation",DefaultRecommendation:"default-recommendation",DefaultNotification:"default-notification",ExplorationTab:"exploration-tab",ExplorationReco:"exploration-recommendation",UsabilityFeedbackToast:"usability-feedback-toast"},o={dropdownHistory:"dropdownHistory",dismissHistory:"dismissHistory",suppressHistory:"suppressHistory",usefulTipHistoryYes:"usefulTipHistoryYes",usefulTipHistoryNo:"usefulTipHistoryNo",usefulTipHistoryDismiss:"usefulTipHistoryDismiss"};function n(t,e){return 0!==t&&["_1x_3y","_1x_1y"].includes(e)&&304===t}class s{constructor(t){this.transformerProvider=t}}},52012(t,e,i){i.d(e,{WB(){return a},zv(){return r}});const r=Object.freeze({unknown:"Unknown",football:"Football",baseball:"Baseball",basketball:"Basketball",basketball3x3:"Basketball3x3",bowling:"Bowling",cricket:"Cricket",icehockey:"IceHockey",fieldhockey:"FieldHockey",racing:"Racing",tennis:"Tennis",soccer:"Soccer",golf:"Golf",australianrules:"AustralianRules",rugbyunion:"RugbyUnion",rugbyleague:"RugbyLeague",archery:"Archery",athletics:"Athletics",badminton:"Badminton",cycling:"Cycling",boxing:"Boxing",canoeing:"Canoeing",climbing:"Climbing",equestrianism:"Equestrianism",fencing:"Fencing",gymnasticsartistic:"GymnasticsArtistic",gymnasticsrhytmic:"GymnasticsRhytmic",gymnasticstrampoline:"GymnasticsTrampoline",handball:"Handball",judo:"Judo",karate:"Karate",summerolympics:"SummerOlympics",paralympics:"Paralympics",pentathlon:"Pentathlon",swimmingartistic:"SwimmingArtistic",swimming:"Swimming",diving:"Diving",waterpolo:"WaterPolo",rowing:"Rowing",sailing:"Sailing",shooting:"Shooting",skateboarding:"Skateboarding",surfing:"Surfing",taekwondo:"Taekwondo",triathlon:"Triathlon",tabletennis:"TableTennis",volleyballteam:"VolleyballTeam",volleyballbeach:"VolleyballBeach",weightlifting:"Weightlifting",wrestling:"Wrestling",softball:"Softball",trackandfield:"TrackAndField",mma:"MMA",netball:"Netball",boccia:"Boccia",biathlon:"Biathlon",bobsledding:"Bobsledding",curling:"Curling",luge:"Luge",skating:"Skating",skiing:"Skiing",breaking:"Breaking"});new Set(["Soccer_InternationalIntFriendlyGames","Soccer_BelgiumSuperCup","Baseball_ChineseTaipeiCpbl","Soccer_InternationalClubsUefaEuropaConferenceLeague","Soccer_FranceCoupeDeFrance","Soccer_Turkey1Lig","Soccer_BelgiumSuperCup","Soccer_VietnamVLeague","Soccer_BrazilBrasileiroSerieC","Football_CanadaCfl","Soccer_BoliviaDivisionProfesional","Football_USAUSFL"]);const a=Object.freeze([r.football,r.basketball,r.baseball,r.cricket,r.soccer,r.icehockey])},52077(t,e,i){i.d(e,{SportsGameStatsTransformer(){return r.O},SportsMatchTransformer(){return a.SportsMatchTransformer},SportsSpotlightTransformer(){return o.V}});var r=i(70512),a=i(82724),o=i(34959);Promise.resolve().then(i.bind(i,27666)),Promise.resolve().then(i.bind(i,71891)),Promise.resolve().then(i.bind(i,76435))},54229(t,e,i){i.d(e,{aC(){return y},YJ(){return o},x1(){return n},iJ(){return m},h9(){return v},LE(){return g},Eh(){return d},Ai(){return p},dI(){return c},j8(){return h},ao(){return u}});var r=i(85349),a=i(19359);const o={Customize:r.MS.Customize,Paginate:r.MS.Paginate,Hide:r.MS.Hide,Cancel:r.MS.Cancel,Close:r.MS.Close,Dislike:r.MS.Dislike,Show:r.MS.Show,Click:r.MS.Click};class n{createTelemetryObjectTag(t){return t?t.getMetadataTag():""}createTelemetryObject(t,e,i,o){if(!t||!e)return;const{name:n,content:s,...l}=e,p={...s,type:(null==s?void 0:s.type)||r.b5.StructuredData,vertical:this.verticalName,category:this.categoryName,subcategory:this.subCategoryName},d={...this.ext,signature:i};o&&(d.previewType=o);const c={...l,ext:d,zone:this.zone};return(0,a.g)(n,p,c)}createViewTelemetryObject(t,e){return this.createTelemetryObject(t,{name:e.name,action:r.EG.View,behavior:r.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType)}createViewTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:r.MS.View,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createNavClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createAddClickTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Add,type:r.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createHoverShowTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.Hover,behavior:r.MS.Show,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createMouseLeaveCloseTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,action:r.EG.MouseLeave,behavior:r.MS.Close,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createDislikeActionTelemetryTag(t,e){const i=this.createTelemetryObject(t,{name:e.name,behavior:r.MS.Dislike,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(i)}createFollowTelemetryTag(t,e,i){const a=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:i?r.MS.Follow:r.MS.Unfollow,type:r.MJ.ActionButton,content:{headline:e.headline}},e.signature,e.previewType);return this.createTelemetryObjectTag(a)}createMenuDataProviderTelemetryTag(t,e,i){const a=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Undefined,type:r.MJ.ActionButton,content:{headline:e.headline},zone:i},e.signature,e.previewType);return this.createTelemetryObjectTag(a)}createNavClickWithTypeTelemetryTag(t,e,i){const a=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:r.MS.Navigate,type:i,content:{headline:e.headline,id:e.id,brandId:e.brandId,type:e.type||r.b5.StructuredData}},e.signature,e.previewType);return this.createTelemetryObjectTag(a)}createBehaviorTelemetryTag(t,e,i){const a=this.createTelemetryObject(t,{name:e.name,action:r.EG.Click,behavior:i,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);return this.createTelemetryObjectTag(a)}createBaseContentCardTelemetryContext(t,e){const i=this.createTelemetryObject(t,{name:e.name,type:r.MJ.ContentCard,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType),a=this.createTelemetryObject(i,{name:e.name,type:r.MJ.Headline,behavior:r.MS.Navigate,content:{headline:e.headline,id:e.id,brandId:e.brandId}},e.signature,e.previewType);if(i&&a)return{contentCard:i,destination:a}}initTelemetryBuilder(t,e,i,r,a){this.verticalName=t,this.categoryName=e,this.ext=i,this.zone=r,this.subCategoryName=a}updateExt(t){this.ext=t}}var s=i(77367),l=i(84742);function p(t){try{s.YT.sendActionEvent(t,r.EG.MouseLeave,r.MS.Close)}catch(t){return}}function d(t){try{s.YT.sendActionEvent(t,r.EG.Hover,r.MS.Show)}catch(t){return}}function c(t,e){try{s.YT.sendActionEvent(t,r.EG.Click,r.MS.Navigate,e)}catch(t){return}}function g(t,e,i){try{s.YT.sendActionEvent(t,e?r.EG.KeyPress:r.EG.Click,i?r.MS.Follow:r.MS.Unfollow)}catch(t){return}}function h(t){try{if(!t)throw new Error("Current target is undefined, cannot send content view telemetry.");s.YT.sendContentViewEvent(t,l.ym.View)}catch(t){return}}function u(t,e){const i=e?`${e}`:"";s.YT.addOrUpdateTmplProperty(t,i)}function m(t){s.YT.removeTmplProperty(t)}function v(t){for(const e of t)m(e)}var y,f=i(22341);!function(t){t.safeExecute=function(t,e,i,r,a){let o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return t()}catch(t){return i&&(0,f.vV)(i,`${r}: ${null==t?void 0:t.message}`,a,o),e}},t.safeExecuteAsync=async function(t,e,i,r,a){let o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};try{return await t()}catch(t){return i&&(0,f.vV)(i,`${r}: ${null==t?void 0:t.message}`,a,o),Promise.resolve(e)}},t.logExceptionWithFormat=function(t,e,i,r,a){let o=arguments.length>5&&void 0!==arguments[5]?arguments[5]:{};(0,f.c_)(t,e,`${r}${r?": ":""}${i}`,a,o)},t.logErrorWithFormat=function(t,e,i,r){let a=arguments.length>4&&void 0!==arguments[4]?arguments[4]:{};(0,f.vV)(t,`${i}${i?": ":""}${e}`,r,a)}}(y||(y={}))},60239(t,e,i){i.d(e,{r(){return o}});var r=i(54996),a=i(42277);const o=i(68244).F.create({trustedType:{createHTML:t=>r.sanitize(t,{RETURN_TRUSTED_TYPE:!0})},guards:{aspects:{[a.D.property]:{innerHTML:(t,e,i,a)=>function(t,e,i){const o=r.sanitize(i,{RETURN_TRUSTED_TYPE:!0});for(var n=arguments.length,s=new Array(n>3?n-3:0),l=3;l<n;l++)s[l-3]=arguments[l];a(t,e,o,...s)}}}}})},64812(t,e,i){i.r(e),i.d(e,{SportsGameLeaders(){return At}});var r=i(56911),a=i(84564);class o extends a.z{}var n=i(92011),s=i(61138),l=i(12640),p=i(74849);const d=p.A` :host{--secondary-font-color:#999999}`,c=p.A` :host{--secondary-font-color:#707070}`,g=p.A` :host{display:inline-block;width:100%}.game-leaders{display:grid;gap:12px}.category-row{display:grid;justify-items:center;gap:4px}.category-title{font-size:${s.k};
        line-height: ${s.F};font-weight:400;color:var(--secondary-font-color)}.player-cards{width:100%;display:grid;grid-template-columns:1fr 1fr}`.withBehaviors(new l.N(c,d));var h=i(96950),u=i(39957),m=i(69259),v=i(60815),y=i(25109);const f=Object.freeze({default:"default",lite:"lite"}),b=Object.freeze({Stack:"stack",SideBySide:"side-by-side"});class x extends n.L{constructor(){super(),this.type=f.default,this.name="",this.fullName="",this.nameDetail="",this.description="",this.image="",this.isDarkMode=(0,y.ud)(),this.playerInfoRenderMode=b.Stack,this.isRuby=!1,this.isCopilot=!1,this.isMai=!1,this.imageClickHandler=()=>{this.redirectLink&&open(this.redirectLink,"_blank")},this.colorSchemeChangeHandler=this.colorSchemeChangeHandler.bind(this)}connectedCallback(){super.connectedCallback();const t=window.matchMedia("(prefers-color-scheme: dark)");t.addEventListener&&t.addEventListener("change",this.colorSchemeChangeHandler)}disconnectedCallback(){super.disconnectedCallback();window.matchMedia("(prefers-color-scheme: dark)").removeEventListener("change",this.colorSchemeChangeHandler)}colorSchemeChangeHandler(){this.isDarkMode=(0,y.ud)()}get playerNameInitials(){if(!this.name||!this.name.trim())return"";const t=this.name.trim().split(/\s+/);if(t.length<2)return this.name.charAt(0);const e=t[0],i=t[1];return`${e.charAt(0)}${i.charAt(0)}`}get playerNameAndNameDetailsCombined(){return[this.name,this.nameDetail].filter(Boolean).join(" ")}}(0,r.Cg)([v.sH],x.prototype,"type",void 0),(0,r.Cg)([v.sH],x.prototype,"name",void 0),(0,r.Cg)([v.sH],x.prototype,"fullName",void 0),(0,r.Cg)([v.sH],x.prototype,"nameDetail",void 0),(0,r.Cg)([v.sH],x.prototype,"playerNumber",void 0),(0,r.Cg)([v.sH],x.prototype,"description",void 0),(0,r.Cg)([v.sH],x.prototype,"image",void 0),(0,r.Cg)([v.sH],x.prototype,"teamColor",void 0),(0,r.Cg)([v.sH],x.prototype,"teamImage",void 0),(0,r.Cg)([v.sH],x.prototype,"injuryInfo",void 0),(0,r.Cg)([v.sH],x.prototype,"statistics",void 0),(0,r.Cg)([v.sH],x.prototype,"statisticsLabel",void 0),(0,r.Cg)([v.sH],x.prototype,"isDarkMode",void 0),(0,r.Cg)([v.sH],x.prototype,"playerInfoRenderMode",void 0),(0,r.Cg)([v.sH],x.prototype,"redirectLink",void 0),(0,r.Cg)([v.sH],x.prototype,"isPlayerImageAvailable",void 0),(0,r.Cg)([v.sH],x.prototype,"columnLayout",void 0),(0,r.Cg)([v.sH],x.prototype,"isRuby",void 0),(0,r.Cg)([v.sH],x.prototype,"isCopilot",void 0),(0,r.Cg)([v.sH],x.prototype,"isMai",void 0);var w=i(22683),$=i(41123),S=i(43774),k=i(62047),T=i(37302),C=i(24458),z=i(89580),F=i(64003),M=i(22131),D=i(45755);D.G.create("cricket-win-color"),D.G.create("copilot-header-color"),D.G.create("ruby-border-radius"),D.G.create("copilot-container-fill-color"),D.G.create("sp-container-1-col-width"),D.G.create("sp-container-mobile-width"),D.G.create("sp-container-flyout-width"),D.G.create("sp-container-2-col-width"),D.G.create("sp-container-3-col-width"),D.G.create("sp-container-4-col-width"),D.G.create("sp-container-padding"),D.G.create("sp-container-one-col-padding"),D.G.create("sp-container-mobile-padding"),D.G.create("sp-container-margin"),D.G.create("sp-container-one-col-margin"),D.G.create("sp-container-mobile-margin"),D.G.create("sp-container-corner-radius"),D.G.create("sp-container-one-col-corner-radius"),D.G.create("sp-content-row-gap"),D.G.create("sp-content-row-gap-one-col"),D.G.create("sp-content-row-gap-mobile"),D.G.create("sp-content-column-gap"),D.G.create("sp-content-column-gap-one-col"),D.G.create("sp-content-column-gap-mobile"),D.G.create("sp-vertical-container-margin-bottom"),D.G.create("sp-vertical-container-margin-bottom-one-col"),D.G.create("sp-vertical-container-margin-bottom-mobile"),D.G.create("sp-container-title-margin"),D.G.create("sp-container-title-one-col-margin"),D.G.create("sp-container-title-mobile-margin"),D.G.create("sp-scroll-proxy-container-margin"),D.G.create("sp-scroll-proxy-container-one-col-margin"),D.G.create("sp-scores-schedule-container-padding"),D.G.create("sp-scores-schedule-container-one-col-padding"),D.G.create("sp-scores-schedule-container-mobile-padding"),D.G.create("sp-game-summary-container-padding"),D.G.create("sp-game-summary-container-one-col-padding"),D.G.create("sp-game-summary-container-mobile-padding"),D.G.create("sp-cricket-rankings-container-header-padding"),D.G.create("sp-cricket-rankings-container-header-one-col-padding"),D.G.create("sp-cricket-rankings-container-header-mobile-padding");const E=D.G.create("sp-text-base-font-size"),P=(D.G.create("sp-text-minus-1-font-size"),D.G.create("sp-text-minus-2-font-size"),D.G.create("sp-text-minus-3-font-size"),D.G.create("sp-text-plus-1-font-size")),_=(D.G.create("sp-text-plus-2-font-size"),D.G.create("sp-text-plus-3-font-size"),D.G.create("sp-text-plus-4-font-size"),D.G.create("sp-text-plus-5-font-size"),D.G.create("sp-text-minus-1-line-height"),D.G.create("sp-text-minus-2-line-height"),D.G.create("sp-text-minus-3-line-height"),D.G.create("sp-text-base-line-height")),B=(D.G.create("sp-text-plus-1-line-height"),D.G.create("sp-text-plus-2-line-height"),D.G.create("sp-font-color")),R=D.G.create("sp-font-color-sub"),A=(D.G.create("sp-cr-font-color-sub"),D.G.create("sp-mai-background-color"),D.G.create("section-header-color"),D.G.create("sp-cr-top-border-color"),D.G.create("sp-cr-live-color-lll"),D.G.create("sp-cr-live-color-ll"),D.G.create("sp-cr-live-color-l"),D.G.create("sp-cr-live-color"),D.G.create("sp-cr-delayed-color"),D.G.create("sp-copilot-divider-color"),D.G.create("sp-copilot-divider-border"),D.G.create("sp-tab-hover-background-color"),D.G.create("sp-tab-pressed-background-color"),D.G.create("sp-tab-pressed-font-color"),D.G.create("sp-button-hover-background-color"),D.G.create("sp-button-pressed-background-color"),D.G.create("sp-button-pressed-font-color"),D.G.create("sp-button-second-hover-background-color"),D.G.create("sp-button-second-pressed-background-color"),D.G.create("sp-button-second-pressed-font-color"),p.A`
    .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        white-space: nowrap;
        border-width: 0;
        clip-path: inset(100%);
    }

    .ellipsis {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    @supports (-webkit-line-clamp: 2) {
        .ellipsis.with-2-lines {
            white-space: normal;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
    }
`),I=p.A` :host{--ruby-player-round-bg:rgba(255,255,255,5%);--ruby-player-team-shadow:#000000;--ruby-player-team-bg:#F6F9FC;--ruby-player-name-color:#FFFFFF;--ruby-stat-val-color:#FFFFFF;--ruby-player-desc-color:${R};
        --ruby-lite-round-bg: rgba(255, 255, 255, 0.05);
        --ruby-copilot-lite-round-bg: rgba(157, 168, 217, 0.05);
        --player-initials-bg: #6D585B;
        --player-initials-color: #F2DDCC;
    }
`,j=p.A` :host{--ruby-player-round-bg:rgba(0,0,0,5%);--ruby-player-team-shadow:#FFFFFF;--ruby-player-team-bg:#23272B;--ruby-player-name-color:#23272B;--ruby-stat-val-color:#23272B;--ruby-player-desc-color:${R};
        --ruby-lite-round-bg: rgba(0, 0, 0, 0.05);
        --ruby-copilot-lite-round-bg: rgba(204, 196, 192, 0.2);
        --player-initials-bg: #FFD79C;
        --player-initials-color: #33302E;
    }
`,L=p.A` .ruby .player-desc-wrapper .player-desc,.sports-player-card.lite.ruby.copilot .player-info .player-name{forced-color-adjust:auto}`,O=p.A`
    ${A} :host{display:inline-block;width:100%;border-bottom:1px solid ${w.hb}}.sports-player-card{object-fit:cover;width:100%;height:100%}.ruby.sports-player-card{column-gap:16px}.ruby.copilot.sports-player-card{column-gap:12px}.sports-player-card,.player-image,.player-info,.injury-info,.player-stats,.player-stat{display:flex}.player-info,.injury-info,.player-stat{flex-direction:column}.sports-player-card{display:flex;align-items:flex-start}.sports-player-card.lite{display:flex;align-items:center}.sports-player-card.lite .player-image{align-items:center}.sports-player-card .player-image{display:flex;flex-direction:row;height:100%}.sports-player-card .player-image .player-image-info{display:flex;flex-direction:column;justify-content:space-between;align-items:center}.player-image .player-image-info .player-info-team{height:${$.Z};
        width: ${$.Z}}.player-image .player-image-info .player-info-number{font-size:${s.k};
        line-height: ${s.F};
        color: ${S.ls}}.player-image .player-image-info .player-info-number-small{font-size:${k.t};
        line-height: ${k.e}}.sports-player-card .player-image .player-round-image{box-sizing:content-box;padding:0;position:relative;border-radius:50%;background:unset;border:1px solid ${T.X4};overflow:hidden}.sports-player-card .player-image .player-round-image-clickable{box-sizing:content-box;padding:0;position:relative;border-radius:50%;background:unset;border:1px solid ${T.X4};overflow:hidden;cursor:pointer}.sports-player-card .player-image .player-round-image,.sports-player-card .player-image .player-round-image-clickable{width:65px;height:65px}.sports-player-card.lite .player-image .player-round-image,.sports-player-card.lite .player-image .player-round-image-clickable{width:36px;height:36px}.sports-player-card .player-image .player-icon{height:100%;width:100%}.sports-player-card .player-image .player-image-link{width:100%;position:absolute;bottom:0;display:flex;justify-content:center;align-items:center;background:rgba(0,0,0,0.44);backdrop-filter:blur(1px)}.player-image-link image{fill:${C.m_}}.player-info{width:60%;flex-direction:column;padding:5px 15px 0 15px}.sports-player-card.lite .player-info{padding:5px}.player-info .player-name{font-size:${$.K};
        line-height: ${$.Z};font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.ruby .player-info .player-name{font-size:${z.Y};line-height:24px;font-weight:550;color:var(--ruby-player-name-color)}.sports-player-card.lite.ruby .player-info .player-name{font-size:${$.K}}.sports-player-card.lite.ruby.copilot .player-info .player-name{font-size:${E};
        line-height: ${_};
        font-weight: 410;
        color: ${B}}.player-info .player-name .name-detail{font-weight:400;color:${F.c}}.sports-player-card .player-info{width:100%;min-width:0;flex-direction:column;display:flex;align-items:flex-start;padding:0 12px}.ruby.sports-player-card .player-info{width:unset;flex-grow:1;padding:0}.ruby.copilot.sports-player-card .player-info{width:calc(100% - 48px);align-items:unset;gap:2px}.sports-player-card .player-info .player-stats{width:100%;display:flex;justify-content:space-between;text-align:center}.sports-player-card .player-info .player-stats .player-stat{display:flex;flex-direction:column;align-items:flex-start}.sports-player-card.lite .player-info .player-name{font-size:${$.K}}.player-info .player-desc{font-size:${k.t};
        line-height: ${k.e};
        color: ${S.ls};white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.injury-info,.player-stats{line-height:${$.Z};
        font-size: ${$.K}}.injury-info .injury-status{display:flex;align-items:center}.injury-status .status-icon{width:${z.Y};
        height: ${z.Y};display:inline-block;border-radius:50%;background:#E8B738}.injury-status .status-text{padding-inline-start:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:115px}.player-stats{justify-content:space-between;text-align:center}.stat-val,.injury-status{font-weight:600;font-size:${$.K};
        line-height: ${$.Z}}.stat-title{font-size:${s.k};
        line-height: ${s.F};
        color: ${S.ls}}.ruby.sports-player-card{align-items:center}.ruby-player-image{position:relative;width:80px;height:80px}.layout-1 .ruby-player-image{width:60px;height:60px}.ruby-player-image.only-team-image,.layout-1 .ruby-player-image.only-team-image{align-self:flex-start;width:24px;height:24px}.ruby-player-round-image{width:100%;height:100%;background-color:var(--ruby-player-round-bg);border-radius:50%}.ruby-player-team-image{position:absolute;right:2px;bottom:2px;width:24px;height:24px;box-shadow:0 0 0 2px var(--ruby-player-team-shadow);background-color:var(--ruby-player-team-bg);border-radius:50%}.layout-1 .ruby-player-team-image{width:20px;height:20px}.player-desc-wrapper{display:flex;max-width:100%}.ruby .player-desc-wrapper{gap:8px}.ruby .player-desc-wrapper .player-info-number{font-size:${$.K};
        line-height: ${$.Z};color:var(--ruby-player-desc-color)}.ruby .player-desc-wrapper .player-desc{font-size:${$.K};
        line-height: ${$.Z};color:var(--ruby-player-desc-color)}.ruby.lite.copilot .player-desc-wrapper .player-desc{font-size:${$.K};
        line-height: ${$.Z}}.ruby .player-stats{margin-top:8px}.layout-1.ruby .player-stats{margin-top:4px}.ruby .player-stat{flex:1 1 0}.ruby .player-stat:last-child{flex:0 1 42px}.ruby.layout-2 .player-stat:last-child{flex:1 1 0}.ruby .stat-val{font-size:${z.Y};line-height:24px;font-weight:550;color:var(--ruby-stat-val-color)}.ruby .stat-title{font-weight:550;color:var(--ruby-player-desc-color)}.layout-4.ruby .stat-title{font-size:${$.K};
        line-height: ${$.Z}}.ruby.lite.layout-4 .player-info .player-name{font-size:${z.Y};
        line-height: ${z.v}}.ruby.lite.layout-4 .player-info .player-desc-wrapper{font-size:${$.K};
        line-height: ${$.Z}}.ruby.lite .player-image .player-round-image,.ruby.lite .player-image .player-round-image-clickable{background:var(--ruby-lite-round-bg)}.ruby.copilot.lite .player-image .player-round-image,.ruby.copilot.lite .player-image .player-round-image-clickable{background:var(--ruby-copilot-lite-round-bg)}.ruby.lite.layout-4 .player-image .player-round-image,.ruby.lite.layout-4 .player-image .player-round-image-clickable{height:40px;width:40px}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;background-color:var(--background-color,--player-initials-bg);border-radius:50%}.player-initials > span{font-size:${P};
        line-height: ${_};font-weight:400;letter-spacing:-0.01em;color:var(--font-color,--player-initials-color)}.layout-1 .player-initials > span{font-size:${E};
    }

`.withBehaviors(new l.N(j,I),(0,M.mr)(L)),H=h.qy`
    <div class="injury-info">
        <span class="injury-status">
            ${(0,m.z)(t=>{var e;return null===(e=t.injuryInfo)||void 0===e?void 0:e.statusIconColor},h.qy`
                <i class="status-icon" style="background: ${t=>{var e,i;return t.isDarkMode?null===(e=t.injuryInfo)||void 0===e||null===(e=e.statusIconColor)||void 0===e?void 0:e.dark:null===(i=t.injuryInfo)||void 0===i||null===(i=i.statusIconColor)||void 0===i?void 0:i.primary}}"></i>
            `)}
            <span class="status-text" title="${t=>{var e;return null===(e=t.injuryInfo)||void 0===e?void 0:e.status}}">
                ${t=>{var e;return null===(e=t.injuryInfo)||void 0===e?void 0:e.status}}
            </span>
        </span>
        ${(0,m.z)(t=>{var e;return null===(e=t.injuryInfo)||void 0===e?void 0:e.injuryArea},h.qy`
            <span class="injury-area">${t=>{var e;return null===(e=t.injuryInfo)||void 0===e?void 0:e.injuryArea}}</span>
        `)}
    </div>
`;var N=i(58792),V=i(47417);const G=`${(0,N.rA)().StaticsUrl}/latest/sports/icons/SportsImageExplorer.svg`,U=h.qy`
    <div class="player-stats">
        ${(0,u.ux)(t=>t.statistics,h.qy`
            <div class="player-stat">
                <span class="stat-val">${t=>void 0===t.value?"-":t.value}</span>
                ${(0,m.z)(t=>!!t.abbreviation,h.qy`
                    <span class="stat-title" title="${t=>t.title}">${t=>t.abbreviation}</span>
                `)}
            </div>
        `)}
    </div>
`,W=h.qy`
    <div class="player-image">
        ${(0,m.z)(t=>t.type===f.default,h.qy`
            <div class="player-image-info">
                ${(0,m.z)(t=>t.teamImage,h.qy`
                    <img class="player-info-team" loading="lazy" role="presentation" src="${t=>t.teamImage||" "}" />
                `)}
                ${(0,m.z)(t=>t.playerNumber,h.qy`
                    <span class="${t=>t.isPlayerImageAvailable?"player-info-number":"player-info-number-small"}">
                        #${t=>t.playerNumber}
                    </span>
                `)}
            </div>
        `)}
        ${(0,m.z)(t=>t.isPlayerImageAvailable,h.qy`
            <div 
                class="${t=>t.redirectLink?"player-round-image-clickable":"player-round-image"}" 
                @click=${t=>t.imageClickHandler()}
            >
                ${(0,m.z)(t=>t.image&&""!==t.image,h.qy`
                    <img class="player-icon" loading="lazy" src=${t=>t.image} alt="${t=>t.fullName||t.name}" />
                `,h.qy`
                    <span class="sr-only">${t=>t.fullName||t.name}</span>
                    <div
                        class="player-initials"
                        title=${t=>t.fullName||t.name}
                        aria-hidden="true"
                    >
                        <span>${t=>t.playerNameInitials}</span>
                    </div>
                `)}
                ${(0,m.z)(t=>t.redirectLink,h.qy`
                    <div class="player-image-link">
                        <img src=${G} alt="sportsImageExplorerIcon" loading="lazy" aria-hidden="true" />
                    </div>
                `)}
            </div>
        `)}
    </div>
`,Y=h.qy`
    <img class="ruby-player-round-image" loading="lazy" src=${t=>(0,V.OY)(V.UU,V.Bk)} alt=${t=>t.fullName||t.name} />
`,q=h.qy`
    ${(0,m.z)(t=>t.isPlayerImageAvailable,h.qy`
        <div class="ruby-player-image" @click=${t=>t.imageClickHandler()}>
            <img class="ruby-player-round-image" loading="lazy" src=${t=>t.image} alt=${t=>t.fullName||t.name} />
            ${(0,m.z)(t=>t.teamImage,h.qy`
                <img class="ruby-player-team-image" loading="lazy" role="presentation" src=${t=>t.teamImage} />
            `)}
        </div>
    `,h.qy`
        ${(0,m.z)(t=>t.teamImage,h.qy`
            <div class="ruby-player-image only-team-image" @click=${t=>t.imageClickHandler()}>
                <img class="ruby-player-round-image" loading="lazy" src=${t=>t.teamImage} alt=${t=>t.fullName||t.name} />
            </div>
        `,Y)}
    `)}
`,J=h.qy`
    <div class="sports-player-card ${t=>t.type} ${t=>t.columnLayout?`layout-${t.columnLayout}`:""} ${t=>t.isRuby?"ruby":""} ${t=>t.isCopilot?"copilot":""}">
        ${(0,m.z)(t=>t.isRuby&&t.type!==f.lite,q,W)}
        <div class="player-info">
            <span class="sr-only">${t=>t.fullName||t.name}</span>
            <span
                class="player-name"
                title=${t=>t.fullName||t.name}
                aria-hidden="true"
            >
                ${t=>t.name}
                <span class="name-detail"> ${t=>t.nameDetail}</span>
            </span>
            <div class="player-desc-wrapper">
                ${(0,m.z)(t=>t.playerNumber&&t.isRuby,h.qy`<span class="player-info-number">#${t=>t.playerNumber}</span>`)}
                <span class="player-desc">${t=>t.description}</span>
            </div>
            ${(0,m.z)(t=>t.injuryInfo,H)}
            ${(0,m.z)(t=>{var e;return null===(e=t.statistics)||void 0===e?void 0:e.length},U)}
        </div>
    </div>
`;var X=i(36452);const K=p.A`
    ${A} :host{display:inline-block;width:100%}.sports-player-card{object-fit:cover;width:100%;height:100%;flex-direction:column;align-items:center}.sports-player-card,.player-image,.player-info,.injury-info,.player-stats,.player-stat{display:flex}.player-stats{flex-direction:row}.player-info,.injury-info,.player-stat{flex-direction:column}.player-stat{margin-inline-start:6px}.player-image{padding-bottom:5px;position:relative}.sports-player-card.grid-card .player-image{padding-bottom:0;align-items:center}.player-image img{width:40px;height:40px;border-radius:50px;border:1px solid ${X.I2}}.sports-player-card.grid-card .player-image img{width:36px;height:36px;border-radius:50%;background:unset;border:1px solid ${T.X4}}.player-image{bottom:5px;border-end-start-radius:5px;padding:2px 0}.player-info{width:60%;flex-direction:column;align-items:center}.player-info-text-content{flex-direction:column;align-items:center;display:flex}.sports-player-card.grid-card .player-info{padding:5px}.player-info .player-name{font-size:${s.k};font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;width:100px;text-align:center}.player-desc{overflow:hidden;text-overflow:ellipsis;width:100px;text-align:center;white-space:nowrap}.player-info .player-desc{font-size:${k.t};
        line-height: ${k.e}}.injury-info,.player-stats{line-height:${k.e};
        font-size: ${k.t}}.injury-info .injury-status{display:flex;align-items:center}.injury-status .status-icon{width:${k.t};
        height: ${k.e};display:inline-block;border-radius:50%;background:#E8B738}.injury-status .status-text{padding-inline-start:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:115px}.player-stats{justify-content:space-around;text-align:center;width:100px}.stat-val,.injury-status{font-weight:600;font-size:${s.k}}.stat-title,.player-desc{color:${S.ls}}.sports-player-card.side-by-side{flex-direction:row}.sports-player-card.side-by-side .player-info{flex-direction:row;width:100%}.sports-player-card.side-by-side .player-info .player-info-text-content{margin-inline-start:10px}.sports-player-card.side-by-side .player-info .player-name{text-align:unset}.sports-player-card.side-by-side .player-image{bottom:unset}.sports-player-card.side-by-side .player-info .player-name{text-align:unset;width:150px}.sports-player-card.side-by-side .player-desc{text-align:unset;width:150px}.sports-player-card.side-by-side .injury-status .status-icon{height:7px;width:7px}.sports-player-card.side-by-side .injury-status .injury-info{padding-inline-start:10px}`.withBehaviors(),Z=h.qy`
    <div class="player-stats">
        ${(0,u.ux)(t=>t.statistics,h.qy`
            ${(0,m.z)(t=>!!t.abbreviation,h.qy`
                <div class="player-stat">
                    <span class="stat-val">${t=>void 0===t.value?"-":t.value}</span>
                    <span class="stat-title" title="${t=>t.title??t.abbreviation}">${t=>t.abbreviation}</span>
                </div>
            `)}
        `)}
    </div>
`,Q=h.qy`
    <div class="sports-player-card ${t=>t.type} ${t=>t.playerInfoRenderMode==b.SideBySide?"side-by-side":""}">
        <div class="player-image">
            <img loading="lazy" src=${t=>t.image} alt="${t=>t.fullName||t.name}">
        </div>
        <div class="player-info">
            <div class="player-info-text-content">
                <span class="sr-only">${t=>t.fullName||t.name}</span>
                <span class="player-name" title="${t=>t.fullName||t.name}" aria-hidden="true">${t=>t.name}</span>
                <span class="player-desc">${t=>t.description+" "}
                    <span> ${t=>null==t.playerNumber?"":"#"+t.playerNumber}</span>
                </span>
            </div>
            ${(0,m.z)(t=>t.injuryInfo,H)}
            ${(0,m.z)(t=>{var e;return null===(e=t.statistics)||void 0===e?void 0:e.length},Z)}
        </div>
    </div>
`,tt=p.A` :host{--secondary-font-color:#999999;--image-border-color:#666666}`,et=p.A` :host{--secondary-font-color:#707070;--image-border-color:#D1D1D1}`,it=p.A`
    ${A} :host{display:inline-block;width:100%;min-width:0}.sports-player-card{display:grid;grid-template-columns:max-content auto;align-items:center;gap:6px}.player-round-image{object-fit:cover;border-radius:50%;overflow:hidden}.image-border{border:1px solid var(--image-border-color)}.player-icon{width:36px;height:36px;display:block}.player-info{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;min-width:0}.player-name{font-weight:600;text-align:left;max-width:96px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;height:20px;font-size:${$.K};
        line-height: ${$.Z};max-width:100%}.player-stats{display:flex;flex-wrap:nowrap;font-size:12px;height:20px;gap:2px;display:flex;align-items:center}.player-stats-vals{display:flex;flex-wrap:nowrap;font-size:${$.K};
        line-height: ${$.Z}}.player-stats-titles{display:flex;flex-wrap:nowrap;font-size:${$.K};
        line-height: ${$.Z}}.stat-val{font-weight:600}.stat-title{font-weight:400;color:var(--secondary-font-color)}`.withBehaviors(new l.N(et,tt)),rt=h.qy`
    <div class="player-stats">
        <div class="player-stats-vals">
            ${(0,u.ux)(t=>t.statistics,h.qy`
                <span class="stat-val">${t=>void 0===t.value?"-":t.value}</span>
                ${(0,m.z)((t,e)=>!e.isLast,h.qy`-`)}
            `,{positioning:!0})}
        </div>
        <div class="player-stats-titles">
            ${(0,u.ux)(t=>t.statistics,h.qy`
                ${(0,m.z)(t=>!!t.abbreviation,h.qy`
                    <span class="stat-title" title="${t=>t.title}">${t=>t.abbreviation}</span>
                `)}
                ${(0,m.z)((t,e)=>!e.isLast,h.qy`<span class="stat-title">-</span>`)}        
            `,{positioning:!0})}
        </div>
    </div>
`,at=h.qy`
<div class="sports-player-card ${t=>t.type}">
    ${(0,m.z)(t=>t.isPlayerImageAvailable,h.qy`
        <div class="player-round-image ${t=>t.teamColor?"image-border":""}" style="background-color:${t=>t.teamColor};">
            <img class="player-icon" loading="lazy" src=${t=>t.image} alt="${t=>t.fullName||t.name}">
        </div>
    `)}
    <div class="player-info">
        <span class="sr-only">${t=>t.fullName||t.name}</span>
        <span class="player-name" title="${t=>t.fullName||t.name}" aria-hidden="true">
            ${t=>t.name}
        </span>
        ${(0,m.z)(t=>{var e;return null===(e=t.statistics)||void 0===e?void 0:e.length},rt)}
    </div>
</div>
`;var ot=i(37079),nt=i(62198),st=i(32257);const lt=p.A` .player-image,.player-stats{background-color:#9DA8D90D}.player-initials{background-color:#6D585B}.team-logo{box-shadow:0 0 0 2px #282F42;background-color:#282F42}`,pt=p.A` .player-image,.player-stats{background-color:#CCC4C033}.player-initials{background-color:#FFD79C}.team-logo{box-shadow:0 0 0 2px #F4EFED;background-color:#F4EFED}`,dt=p.A`
    ${A} .sports-player-card *{box-sizing:border-box}.sports-player-card{display:flex;flex-direction:column;align-items:center;width:100%;row-gap:12px;text-align:center}.layout-1.sports-player-card{row-gap:8px}.player-image-container{position:relative;width:90px;height:90px}.player-image{width:100%;height:100%;border-radius:50%}.mai .player-image{background-color:${st.GEK}}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;border-radius:50%}.player-initials > span{font-size:${ot.F};
        line-height: ${nt.b};
        font-weight: 400;
        letter-spacing: -0.01em;
        color: ${B}}.team-logo{position:absolute;inset-inline-end:2px;bottom:2px;width:28px;height:28px;border-radius:50%}.mai .team-logo{box-shadow:0 0 0 2px ${st.GEK};
        background-color: ${st.GEK}}.player-info{display:flex;flex-direction:column;align-items:center;width:100%;padding-inline:4px}.player-name{width:100%;font-size:15px;line-height:${$.Z};
        font-weight: 700;
        color: ${B};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-description{width:100%;font-size:${s.k};
        line-height: ${s.F};
        font-weight: 650;
        color: ${R};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-stats{display:flex;justify-content:space-between;margin-top:auto;padding:8px 12px;width:100%;column-gap:4px;border-radius:12px}.mai .player-stats{border-radius:${st.g6L};
        background-color: ${st.GEK}}.player-stats:has(:only-child){justify-content:center}.player-stat{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto}.stat-value{display:block;font-size:${$.K};
        line-height: ${$.Z};
        font-weight: 650;
        color: ${B};white-space:nowrap}.stat-title{display:block;font-size:${k.t};
        line-height: ${k.e};
        font-weight: 700;
        color: ${R};
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
`.withBehaviors(new l.N(pt,lt));var ct=i(30439),gt=i(52012);const ht=h.qy`
    <div class="player-image-container">
        ${(0,m.z)(t=>t.isPlayerImageAvailable&&t.image&&!t.redirectLink,h.qy`
            <img class="player-image" loading="lazy" src=${t=>t.image} alt=${t=>t.fullName||t.name} />
        `,h.qy`
            <span class="sr-only">${t=>t.fullName||t.name}</span>
            <div
                class="player-initials"
                title=${t=>t.fullName||t.name}
                aria-hidden="true"
            >
                <span>${t=>t.playerNameInitials}</span>
            </div>
        `)}
        ${(0,m.z)(t=>t.teamImage,h.qy`
            <img class="team-logo" loading="lazy" role="presentation" src=${t=>t.teamImage} alt="" />
        `)}
    </div>
`,ut=h.qy`
    <header class="player-info">
        <span class="sr-only">${t=>t.fullName||t.name}</span>
        <span
            id=${t=>`header-${t.id}`}
            class="player-name"
            title=${t=>t.fullName||t.name}
            aria-hidden="true"
        >
            ${t=>t.name}
        </span>
        <span class="player-description">
            ${t=>t.playerNumber?`#${t.playerNumber} ${t.description}`:`${t.description}`}
        </span>
    </header>
`,mt=h.qy`
    ${(0,m.z)(t=>t.abbreviation&&t.abbreviation.trim(),h.qy`
        <div class="player-stat" role="listitem">
            <span class="sr-only">${t=>`${t.value} ${t.title}`}</span>
            <span class="stat-value" aria-hidden="true">
                ${t=>t.value}
            </span>
            <span class="stat-title" title=${t=>t.title} aria-hidden="true">
                ${t=>t.abbreviation}
            </span>
        </div>
    `)}
`,vt=h.qy`
    <div class="player-stat" role="listitem">
        <span class="sr-only">${t=>`${t.value} ${t.title}`}</span>
        <span class="stat-value"  aria-hidden="true">
            ${t=>t.value}
        </span>
        ${(0,m.z)(t=>t.abbreviation,h.qy`
            <span class="stat-title" title=${t=>t.title} aria-hidden="true">
                ${t=>t.abbreviation}
            </span>
        `)}
    </div>
`,yt=h.qy`
    <div class="sports-player-card ${t=>t.isMai?"mai":""} layout-${t=>t.columnLayout}" role="article" aria-labelledby=${t=>t.id?`header-${t.id}`:""}>
        ${ht}
        ${ut}
        <div class="player-stats" role="list" aria-label=${t=>t.statisticsLabel||""}>
            ${(0,u.ux)(t=>t.statistics,h.qy`
                ${(0,m.z)(t=>(null===ct.Nx||void 0===ct.Nx?void 0:ct.Nx.Sport)===gt.zv.soccer,mt,vt)}
            `)}
        </div>
    </div>
`;var ft=i(29222);const bt=p.A` :host{--player-initials-bg:#6D585B}`,xt=p.A` :host{--player-initials-bg:#FFD79C}`,wt=p.A`
    ${A} :host{--player-image-bg:${st.GEK};
        --player-stats-bg: ${st.GEK};
        --player-initials-color: ${B};
        --team-logo-shadow: ${st.GEK};
        --team-logo-bg: ${st.GEK}}.sports-player-card *{box-sizing:border-box}.sports-player-card{display:flex;align-items:flex-start;width:100%;gap:12px}.layout-1.sports-player-card{gap:8px}.player-content{flex:1;min-width:0;display:flex;flex-direction:column;gap:12px}.layout-1 .player-content{gap:8px}.player-image-container{position:relative;flex:0 0 80px;width:80px;height:80px}.player-image{width:100%;height:100%;background-color:var(--player-image-bg);border-radius:50%}.player-initials{display:flex;align-items:center;justify-content:center;width:100%;height:100%;background-color:var(--player-initials-bg);border-radius:50%}.player-initials > span{font-size:${ot.F};
        line-height: ${nt.b};font-weight:400;letter-spacing:-0.01em;color:var(--player-initials-color)}.team-logo{position:absolute;inset-inline-end:2px;bottom:2px;width:28px;height:28px;box-shadow:0 0 0 2px var(--team-logo-shadow);background-color:var(--team-logo-bg);border-radius:50%}.player-info{display:flex;flex-direction:row;align-items:center;justify-content:space-between;width:100%;gap:4px}.player-name{flex:0 0 auto;min-width:0;max-width:75%;font-size:15px;line-height:${$.Z};
        font-weight: 700;
        color: ${B};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.player-description{flex:1 1 auto;min-width:0;font-size:${s.k};
        line-height: ${s.F};
        font-weight: 650;
        color: ${R};overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:end}.player-stats{display:flex;justify-content:space-between;margin-top:auto;padding:8px 12px;width:100%;column-gap:4px;border-radius:12px;background-color:var(--player-stats-bg)}@supports (corner-shape:squircle){.player-stats{border-radius:calc(12px * ${ft.MU6});corner-shape:squircle}}.player-stats:has(:only-child){justify-content:center}.player-stat{display:grid;grid-template-columns:1fr;grid-template-rows:auto auto}.stat-value{display:block;font-size:${$.K};
        line-height: ${$.Z};
        font-weight: 650;
        color: ${B};white-space:nowrap}.stat-title{display:block;font-size:${k.t};
        line-height: ${k.e};
        font-weight: 700;
        color: ${R};
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
`.withBehaviors(new l.N(xt,bt)),$t=h.qy`
    <div class="player-image-container">
        ${(0,m.z)(t=>t.isPlayerImageAvailable&&t.image&&!t.redirectLink,h.qy`
            <img class="player-image" loading="lazy" src=${t=>t.image} alt=${t=>t.fullName||t.name} />
        `,h.qy`
            <span class="sr-only">${t=>t.fullName||t.name}</span>
            <div
                class="player-initials"
                title=${t=>t.fullName||t.name}
                aria-hidden="true"
            >
                <span>${t=>t.playerNameInitials}</span>
            </div>
        `)}
        ${(0,m.z)(t=>t.teamImage,h.qy`
            <img class="team-logo" loading="lazy" role="presentation" src=${t=>t.teamImage} alt="" />
        `)}
    </div>
`,St=h.qy`
    <header class="player-info">
        <span class="sr-only">${t=>t.fullName||t.name}</span>
        <span
            id=${t=>`header-${t.id}`}
            class="player-name"
            title=${t=>t.fullName||t.name}
            aria-hidden="true"
        >
            ${t=>t.name}
        </span>
        <span class="player-description">
            ${t=>t.playerNumber?`#${t.playerNumber} ${t.description}`:`${t.description}`}
        </span>
    </header>
`,kt=h.qy`
    ${(0,m.z)(t=>t.abbreviation&&t.abbreviation.trim(),h.qy`
        <div class="player-stat" role="listitem">
            <span class="sr-only">${t=>t.title?`${t.value} ${t.title}`:`${t.value}`}</span>
            <span class="stat-value" aria-hidden="true">
                ${t=>t.value}
            </span>
            <span class="stat-title" title=${t=>t.title} aria-hidden="true">
                ${t=>t.abbreviation}
            </span>
        </div>
    `)}
`,Tt=h.qy`
    <div class="player-stat" role="listitem">
        <span class="sr-only">${t=>t.title?`${t.value} ${t.title}`:`${t.value}`}</span>
        <span class="stat-value"  aria-hidden="true">
            ${t=>t.value}
        </span>
        ${(0,m.z)(t=>t.abbreviation,h.qy`
            <span class="stat-title" title=${t=>t.title} aria-hidden="true">
                ${t=>t.abbreviation}
            </span>
        `)}
    </div>
`,Ct=h.qy`
    <div class="sports-player-card layout-${t=>t.columnLayout}" role="article" aria-labelledby=${t=>t.id?`header-${t.id}`:""}>
        ${$t}
        <div class="player-content">
            ${St}
            <div class="player-stats" role="list" aria-label=${t=>t.statisticsLabel||""}>
                ${(0,u.ux)(t=>t.statistics,h.qy`
                    ${(0,m.z)(t=>(null===ct.Nx||void 0===ct.Nx?void 0:ct.Nx.Sport)===gt.zv.soccer,kt,Tt)}
                `)}
            </div>
        </div>
    </div>
`;let zt=class extends x{};zt=(0,r.Cg)([(0,n.E)({name:"sports-player-card",template:J,styles:O})],zt);let Ft=class extends x{};Ft=(0,r.Cg)([(0,n.E)({name:"sports-player-card-v2",template:Q,styles:K})],Ft);let Mt=class extends x{};Mt=(0,r.Cg)([(0,n.E)({name:"sports-player-card-v3",template:at,styles:it})],Mt);let Dt=class extends x{};Dt=(0,r.Cg)([(0,n.E)({name:"sports-player-card-copilot",template:yt,styles:dt})],Dt);let Et=class extends x{};Et=(0,r.Cg)([(0,n.E)({name:"sports-player-card-mai",template:Ct,styles:wt})],Et);const Pt=h.qy`
    <sports-player-card-v3
        class="player-card"
        :type=${t=>f.default}
        :name=${t=>t.playerName}
        :playerNumber=${t=>t.playerNumber}
        :image=${t=>t.playerImage}
        :teamColor=${t=>t.teamColor}
        :teamImage=${t=>t.playerImage}
        :isPlayerImageAvailable=${t=>t.playerImage}
        :statistics=${t=>t.playerStats}>
    </sports-player-card-v3>
`,_t=h.qy`
    <div class="category-row">
        <div class="category-title">
            ${t=>t.categoryTitle}
        </div>
        <div class="player-cards">
            ${(0,u.ux)(t=>t.players,Pt)}
        </div>
    </div>
`,Bt=h.qy`
    <div class="game-leaders">
        ${(0,u.ux)(t=>t.viewModel.sportsGameLeaders.categories,_t,{positioning:!0})}
    </div>
`,Rt=h.qy`
    ${(0,m.z)(t=>null!=t.viewModel,Bt)}
`;let At=class extends o{};At=(0,r.Cg)([(0,n.E)({name:"sports-game-leaders",template:Rt,styles:g,shadowOptions:{delegatesFocus:!0}})],At)},67689(t,e,i){i.d(e,{h(){return a}});var r=i(2827);function a(){return(0,r.oh)()}},70512(t,e,i){i.d(e,{O(){return o}});var r=i(49150),a=i(23587);class o extends a.Bc{constructor(){super(...arguments),this.getCardTitle=(t,e)=>e?this.transformerProvider.strings.teamStats:t?this.transformerProvider.strings.seasonStats:this.transformerProvider.strings.gameStats}async transform(t){return{viewModel:await this.getCurrentViewModel(t)}}async getCurrentViewModel(t){const{cardSize:e,isFullCard:i,sportsGameStats:a,isSpotlight2Card:o,participants:n,isSeasonStats:s,isCopilotTheme:l}=t;let p=0;switch(e){case r.uE._1x_2y:p=i?5:3;break;case r.uE._1x_3y:p=7;break;case r.uE._2x_2y:p=4;break;case r.uE._15u:p=3}return{sportsGameStats:a.slice(0,p).map(t=>{const e=t.key;return{...t,leftText:this.getStatText(t.leftText,e),rightText:this.getStatText(t.rightText,e),left:this.getBarPercentage(t.left,t.right,e),right:this.getBarPercentage(t.right,t.left,e),key:this.transformerProvider.strings[e]||e}}),cardSize:e,isSpotlight2Card:o,isFullCard:i,participants:n,cardTitle:this.getCardTitle(s,l),isCopilotTheme:l,telemetryTag:""}}isPercentStats(t){return null==t?void 0:t.includes("%")}getBarPercentage(t,e,i){const r=this.isPercentStats(i);return 0===t&&0===e?0:100*(r?t:t/(t+e))}getStatText(t,e){return t&&e?this.isPercentStats(e)?`${(100*parseFloat(t)).toFixed(1)}`:t:""}}},71891(t,e,i){i.r(e),i.d(e,{SportsGameStats(){return M}});var r=i(56911),a=i(84564),o=i(67689);class n extends a.z{constructor(){super(...arguments),this.isAdaptiveThemeEnabled=(0,o.h)()}}var s=i(92011),l=i(86856),p=i(12640),d=i(74849),c=i(4126),g=i(22131);const h=d.A` @container (min-width:180px) and (max-width:233px){.dvrg-hdr{font-size:12px}}`,u=d.A` .game-stats-title,.dtitle{color:rgba(255,255,255,1)}.game-stats-item{color:rgba(255,255,255,1)}.game-stats-item-content{background:rgba(255,255,255,0.6);outline:1px solid rgba(255,255,255,0.20)}.s-bar{background-color:rgba(255,255,255,0.05)}`,m=d.A` .game-stats-item-content{background:rgba(0,0,0,0.5)}`,v=d.A` .game-stats-item-content{transform:scaleX(-1)}`,y=d.A` :host{width:100%;position:relative}.full-card{height:100%;display:flex;flex-direction:column}.game-stats-title{height:20px;width:100%;line-height:20px;text-align:center;font-size:14px;font-weight:600;color:rgba(26,26,26,1);margin-top:10px;margin-bottom:10px}.team-container{display:flex;gap:5px;align-items:center;font-weight:600}.game-team-icons{justify-content:space-between;display:flex;padding-bottom:10px}.team-icon{height:20px}.team-name{display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}.game-stats-list{height:118px;width:100%;box-sizing:border-box;background:var(--sports-item-background);border-radius:8px;padding:10px;display:flex;flex-direction:column;justify-content:space-between;color:red}.spotlight-two .game-stats-list{height:110px}.full-card .game-stats-list{flex-grow:1;height:unset}.game-stats-item{height:26px;font-size:12px;color:rgba(26,26,26,1)}.game-stats-item-header,.dvrg-hdr{height:16px;line-height:16px;display:flex;justify-content:space-between;&>span:{display:inline-block}}.game-stats-item-content{height:8px;line-height:8px;margin-top:2px;border-radius:6px}.game-stats-item-header > span:first-child{padding-right:2px}.game-stats-item-header > span:nth-child(2){overflow:hidden;white-space:nowrap}.game-stats-item-header > span:last-child{padding-left:2px}.left{padding-left:0}.right{padding-right:0}._1x_3y{height:276px}._2x_2y{height:132px;font-weight:600;padding:0px}._15u{height:210px}.s-bars{display:flex;flex-direction:row;height:8px}.s-bar{background-color:rgba(0,0,0,0.05);height:8px;position:relative;width:calc(50%)}.bg-br-l{border-radius:6px 0px 0px 6px;padding-right:1px}.bg-br-r{border-radius:0px 6px 6px 0px;padding-left:1px}.s-bar-l{float:right;border-radius:6px 0 0 6px}.s-bar-r{border-radius:0 6px 6px 0}.s-bar > div{display:block;height:100%;overflow:hidden;position:relative}.s-dvrg,.br-cntr,.brs-cntr{display:flex;flex-direction:column}.s-dvrg,.brs-cntr{gap:12px;font-size:14px}.dtitle{height:20px;width:100%;line-height:20px;font-size:14px;font-weight:600;color:rgba(26,26,26,1)}.brs-cntr{height:118px;width:100%;box-sizing:border-box;border-radius:8px}.br-cntr{gap:4px}.dvrg-hdr{line-height:var(--smtc-text-global-body2-line-height,20px);height:auto}.dtitle{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.s-dvrg{color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523);container-type:inline-size}`.withBehaviors(new l.t(null,v),new p.N(m,u),new c.o("isAdaptiveThemeEnabled",!0,h),(0,g.mr)(d.A` :host{forced-color-adjust:auto}`));var f=i(96950),b=i(69259),x=i(39957);const w=f.qy`
    <div class="game-stats-item">
        <div class="game-stats-item-header">
            <span>
                ${t=>t.leftText}
            </span>
            <span>
                ${t=>t.key}
            </span>
            <span>
                ${t=>t.rightText}
            </span>
        </div>
        <div class="game-stats-item-content"
            style="${t=>0!==t.gap?`background: linear-gradient(to right, ${t.leftColor} 0%, ${t.leftColor} ${t.leftPercent}%, #FFFFFF ${t.leftPercent}%, #FFFFFF ${t.leftPercent+t.gap}%, ${t.rightColor} ${t.leftPercent+t.gap}%, ${t.rightColor} 100%)`:""}"
        >
        </div>
    </div>
`,$=f.qy`
    <div class="team-container">
        ${(0,b.z)((t,e)=>0!==e.index,f.qy`<div class="team-name">${t=>t.name}</div>`)}
        <img class="team-icon" src="${t=>t.imageUrl}" alt="${t=>t.imageAltText}" onerror="this.style.display='none';this.alt=''" />
        ${(0,b.z)((t,e)=>0===e.index,f.qy`<div class="team-name">${t=>t.name}</div>`)}
    </div>
`,S=f.qy`
    <div class="game-team-icons">
        ${(0,x.ux)(t=>t.viewModel.participants,$,{positioning:!0})}
    </div>
`,k=f.qy`
<div class="game-stats-title">${t=>t.viewModel.cardTitle}</div>
`,T=f.qy`
    <div class="${t=>t.viewModel.isFullCard?"full-card":""} ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}">
        ${(0,b.z)(t=>t.viewModel.isFullCard&&t.viewModel.participants,S)}
        ${(0,b.z)(t=>!t.viewModel.isFullCard&&"_2x_2y"!==t.viewModel.cardSize,k)}
        <div class="game-stats-list ${t=>"1.5u"===t.viewModel.cardSize?"_15u":t.viewModel.cardSize}">
            ${(0,x.ux)(t=>t.viewModel.sportsGameStats,w)}
        </div>
    </div>
`,C=f.qy`
    <div class="s-dvrg">
        <div class="dtitle">${t=>t.viewModel.cardTitle}</div>
        <div class="brs-cntr">
            ${(0,x.ux)(t=>t.viewModel.sportsGameStats,f.qy`
        <div class="br-cntr">
            <div class="dvrg-hdr">
                <span class="left">
                    ${t=>t.leftText}
                </span>
                <span>
                    ${t=>t.key}
                </span>
                <span class="right">
                    ${t=>t.rightText}
                </span>
            </div>
            <div class="s-bars">
                <div class="s-bar bg-br-l">
                    <div class="s-bar-l"
                            style="background-color: ${t=>t.leftColor||"#A71930"};
                                width: ${t=>t.left}%;">
                    </div>
                </div>

                <div class="s-bar bg-br-r">
                    <div class="s-bar-r"
                            style="background-color: ${t=>t.rightColor||"#036779"};
                                width: ${t=>t.right}%;">
                    </div>
                </div>
            </div>
        </div>
    `)}
        </div>
    </div>
`,z=f.qy`${t=>{var e;return null!==(e=t.viewModel)&&void 0!==e&&e.isCopilotTheme?C:T}}`,F=f.qy`
    ${(0,b.z)(t=>null!=t.viewModel,z)}
`;let M=class extends n{};M=(0,r.Cg)([(0,s.E)({name:"sports-game-stats",template:F,styles:y,shadowOptions:{delegatesFocus:!0}})],M)},76435(t,e,i){i.r(e),i.d(e,{SportsMatch(){return nt}});var r=i(56911),a=i(54229),o=i(84564);class n extends o.z{constructor(){super(...arguments),this.getMatchData=()=>this.viewModel.matchData.sportsMatchData,this.isVertical=()=>null!=this.viewModel&&this.viewModel.isVertical,this.isCopilotTheme=()=>null!=this.viewModel&&this.viewModel.isCopilotTheme}get isWindowsCopilot(){return null!=this.viewModel&&this.viewModel.isWindows&&this.viewModel.isCopilotTheme}handleClickFollowIcon(t,e,i,r){if(t&&t.currentTarget){t.preventDefault(),t.stopPropagation();const o="keydown"===t.type||"keypress"===t.type||"keyup"===t.type;(0,a.LE)(t.currentTarget,o,e),this.viewModel.followClickHandler&&this.viewModel.followClickHandler(i,e,r)}}}var s=i(92011),l=i(48751),p=i(62047),d=i(61138),c=i(41123),g=i(71157),h=i(62198),u=i(4283),m=i(4968),v=i(12640),y=i(50882),f=i(74849),b=i(4126),x=i(22131);const w="#CD3800",$="#E98F6D",S=f.A` .date,.nodate{width:auto}`,k=f.A` :host{--line-color:rgba(61,61,61,1);--header-color-live:rgba(255,153,164,1);--ruby-live-text-bg:rgba(9,102,32,0.2);--ruby-live-text-color:rgba(108,197,123,1)}.winner-tag path{fill:#FFFFFF}.detail-live-animation{background:${$}}.game-in-progress-text{color:${$}}.side-by-side-hover-canvas:hover{background:rgba(0,0,0,0.6)}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#1A1A1A}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#FFFFFF}.live-line{border-top:1px solid ${$};
        background-color: ${$}}.standings-style{color:${l.l}}:host-context([is-ruby-feed-card]) .matchup-neutral-background{border:1px solid #5A5E63}.kcntr .post-game .kscr:not(.winner-team){color:var(--smtc-foreground-ctrl-neutral-primary-pressed,#A4ADC8)}`,T=f.A` :host{--header-color-live:#C42B1C;--standings-color:#707070;--line-color:#F2F2F2;--kumo-live-bg:rgba(171,47,64,1);--kumo-live-text:rgba(255,255,255,1);--ruby-live-text-bg:#94DC7F33;--ruby-live-text-color:rgba(0,127,48,1)}.sports-match{padding:4px 0;text-decoration:none;display:grid;row-gap:14px;border-radius:6px;height:58px;${m.f}}.sports-match.reason{padding:1px 0}.sports-match.superbowl-half-u{padding:6px 16px;height:auto}.sports-match:focus-visible{outline:${l.l} solid 2px;outline-offset:-2px}.side-by-side-matchup-content{display:flex;flex-direction:row;justify-content:space-between;align-items:center;position:relative;border-radius:6px}.superbowl-half-u .side-by-side-matchup-content{padding:0}.matchup-neutral-background{border-radius:6px;background:var(--sports-item-background)}.matchup-neutral-background.no-bg{background:rgba(0,0,0,0)}.matchup-neutral-background:hover,.matchup-neutral-background:focus-visible{background:var(--sports-item-hover-background)}.matchup-neutral-background:active{background:var(--sports-item-active-background)}.side-by-side-gradient-container{height:45px;width:100%;border-radius:6px 6px 0px 0px;position:absolute}.reason .side-by-side-gradient-container{height:40px}.side-by-side-hover-canvas{display:flex;justify-content:center;align-items:center;position:absolute;width:100%;height:100%;z-index:3;font-size:14px;font-weight:bolder;background:rgba(255,255,255,0);color:rgba(0,0,0,0);overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.side-by-side-hover-canvas:hover{border-radius:6px;border:1.6px solid #6581CA;background:rgba(255,255,255,0.85);color:${l.l}}.video-indicator{display:none}.middle-game-detail{display:flex;flex-direction:row;justify-content:space-around;color:${l.l};font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center}.middle-notification-game-detail{align-items:center}.bottom-game-detail{color:${l.l};
        font-size: ${p.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:100px}.bottom-notification-container{display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;max-height:28px;text-align:center;max-width:108px}.bottom-notification-container.pregame{white-space:normal}.notification-message{display:block;max-width:108px;font-weight:400;color:${l.l}}.underline-text{text-decoration:underline}.superbowl-1-u .bottom-game-detail,.superbowl-half-u .bottom-game-detail{color:${l.l}}.foreground-rest-text-color{color:${l.l}}.top-game-detail{color:${l.l};
        font-size: ${p.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:140px}.finals-match .top-game-detail,.finals-match .bottom-game-detail{color:${l.l}}.super-bowl{font-weight:700;text-transform:uppercase;color:${l.l}}.game-details{display:flex;flex-direction:column;align-items:center;width:100px;overflow:hidden}.side-by-side-matchup-content:hover .game-details-wrapper .game-details{display:none}.side-by-side-matchup-content:hover .game-details-wrapper .game-details-additional-info{display:flex}.game-details-additional-info{display:none;flex-direction:column;align-items:center;justify-content:center;width:100px}.game-details-additional-info .round-info,.game-details-additional-info .round-scores-info{font-size:${d.k};
        line-height: ${d.F};
        color: ${l.l};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-details-additional-info .round-summary-info{font-size:${c.K};
        line-height: ${c.Z};
        font-weight: 600;
        color: ${l.l};max-width:110px;white-space:nowrap;overflow:hidden}.participant-container{display:flex;align-items:center;flex-direction:column;width:84px;color:${l.l};z-index:0}.spotlight-two .participant-container{width:64px}.participant-container img{width:36px;height:36px}.participant-icon{display:flex;border:none;cursor:pointer;width:36px;height:36px;border-radius:8px;align-items:center;justify-content:center;background:transparent}.participant-icon.participant-icon-large{width:70px;height:50px}.participant-container .logo-backplate.participant-icon-large img{width:40px;height:40px}.participant-icon.logo-backplate{border-radius:8px;width:40px;height:40px;img{width:28px;height:28px}}.side-by-side-matchup-content .follow-icon{opacity:0;pointer-events:none;margin-right:-20px;margin-top:-16px}.side-by-side-matchup-content:hover .follow-icon{opacity:1;pointer-events:all}.follow-icon:focus-visible,.sports-match:focus-visible .follow-icon{opacity:1;pointer-events:all}.spotlight-two .right-participant .follow-icon{position:relative;left:-18px}.icon-selected,.icon-add{z-index:2}.icon-add > svg > g{opacity:1}.icon-add > svg > g > path,.icon-selected > svg > path{fill:#FFFFFF}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#0078d4}.game-in-progress-text{color:${w};
        font-size: ${d.k};
        line-height: ${d.F};font-weight:400}.live-scores-detail .game-in-progress-text{border-top:1px solid ${w};
        font-size: ${p.t}}.participant-name-style{font-size:${d.k};
        line-height: ${d.F};max-width:64px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-weight:600}.game-time-text-style{font-size:${g.T};
        line-height: ${g.O};max-width:100px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}.game-time-notification-text-style{font-size:${d.k};
        line-height: ${d.F};max-width:100px}.game-score-notification-text-style{font-size:${g.T};
        line-height: ${g.O}}.game-score-text-style{color:${l.l};
        line-height: ${g.O};
        font-size: ${h.a};margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;font-weight:600}.long-score{font-size:var(--type-ramp-minus-1-font-size,12px)}.long-score .game-score-text-style{font-size:var(--type-ramp-minus-1-font-size,12px);margin:0px 2px}.detail-live-animation{height:2px;background:${w};transform:translateZ(0);animation:liveAnimation 1.6s ease-out infinite 1.0s alternate}@keyframes liveAnimation{0%{width:50px}100%{width:2px}}.video-detail,.top-detail{display:flex;align-items:center;height:14px;margin-bottom:-4px}.top-detail{max-height:40px}.video-detail > span{height:14px;color:${l.l};
        font-size: ${p.t};line-height:14px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;max-width:64px}.top-detail > span{font-size:${p.t};
        line-height: ${p.e};
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        color: ${l.l}}.game-winner-team,.game-winner-description{text-align:center;font-size:${c.K};
        line-height: ${c.Z};
        font-weight: 900;
        color: ${l.l};white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-family:Arial,Segoe,sans-serif}.game-winner-description{margin-top:-4px}.click-for-detail{display:inline-block;background:rgb(196 43 28);color:rgb(255,255,255);font-size:var(--type-ramp-base-font-size);line-height:var(--type-ramp-base-font-size);height:15px;padding:2px 5px;margin:3px;border-radius:4px;font-weight:600;animation:3s ease 0s infinite normal none running gradbg;-webkit-animation:3s ease 0s infinite normal none running gradbg;max-width:80px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden}@keyframes gradbg{0%{background-position:10% 0%}50%{background-position:91% 100%}100%{background-position:10% 0%}}.detail-live-score{font-size:${d.k};
        line-height: ${d.F};
        font-weight: 600;
        white-space: nowrap;
        text-overflow: ellipsis;
        overflow: hidden;
        color: ${u.IR};text-decoration:none}.detail-live-score:hover,.detail-live-score:focus-visible{text-decoration:underline;cursor:pointer}.winner-tag > svg{fill:currentColor;display:block;margin:0 auto}.rtl.winner-tag > svg{transform:scaleX(-1)}.winner-tag.scale-x{transform:scaleX(-1)}.game-time-dot-seperator{margin:0 4px}.live-line{border:none;border-top:1px solid ${w};
        width: 16px;
        height: 0;
        left: 126px;
        top: 20px;
        position: absolute;
        background-color: ${w}}.vert-header,.line-part div:nth-of-type(2),.in-prog-vert,.game-date{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);font-style:normal}.vert-noline,.matchup-vert{display:flex;flex-direction:column;align-items:flex-start}.vert-noline{gap:8px;align-self:stretch;border-radius:8px}.vert-header{font-weight:600;color:${l.l}}.matchup-vert{gap:12px;align-self:stretch}.part-vert,.part-info{display:flex;align-items:center}.part-vert{justify-content:space-between;align-self:stretch}.part-info{width:90%;gap:10px}.icon-vert{width:32px;height:32px;flex-shrink:0}.icon-vert img{max-width:100%;max-height:100%;width:auto;height:auto}.name,.score,.line-part div:nth-of-type(2),.game-date > div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.name,.score{font-size:var(--type-ramp-plus-2-font-size,20px);font-style:normal;font-weight:600;line-height:var(--type-ramp-plus-2-line-height,28px);color:${l.l}}.in-prog-vert{color:var(--header-color-live);font-weight:600}.standings-style{color:var(--standings-color);text-align:right;font-size:var(--type-ramp-base-font-size,14px);font-style:normal;font-weight:400;line-height:var(--type-ramp-base-line-height,20px)}.line-match{display:flex;flex-direction:row;align-items:center;padding:0px;gap:12px;width:100%;height:auto}.line-match > div:first-child{display:flex;flex-direction:row;align-items:flex-start;padding:0px;gap:4px;width:168px}.line-wrap{display:flex;flex-direction:column;justify-content:center;align-items:flex-start;padding:0px;gap:8px;width:168px;height:auto}.line-part{display:flex;flex-direction:row;align-items:center;padding:0px;gap:6px;width:100%}.line-part div:nth-of-type(2){font-weight:400}.line-icon{width:24px;height:24px;flex-shrink:0}.line-icon img{max-width:100%;max-height:100%;width:auto;height:auto}.game-date{font-weight:400;text-align:center;width:68px}.vert-line{width:0px;height:50px;border:1px solid var(--line-color)}.kpart{width:48px;height:74px;gap:4px;align-items:center}.kmtch,.kscr-cntr,.kscr{display:flex;flex-direction:row}.nodate,.date,.kpart{display:flex;flex-direction:column}.kmtch{width:260px;height:74px;gap:0;justify-content:space-between;align-items:center;color:${l.l}}.kicon{width:40px;height:40px;img{width:40px;height:40px}}.kname,.pghdr,.prehdr{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.kname{max-height:24px;max-width:65px;font-weight:600;line-height:24px;font-size:var(--type-ramp-plus-1-font-size,16px);text-align:left}.long-name{max-width:72px;font-size:var(--type-ramp-base-font-size,14px)}.kscr-cntr{justify-content:space-around;font-size:28px;line-height:var(--type-ramp-plus-1-line-height);font-weight:600;white-space:nowrap;text-align:center;align-items:center;gap:6px;margin-bottom:8px}.kscr{font-weight:600;text-align:center;line-height:var(--type-ramp-plus-4-line-height);font-size:var(--type-ramp-plus-5-font-size);margin:0px 4px;align-items:center;column-gap:4px;gap:6px;font-variant-ligatures:none}.ktime{font-weight:600;text-align:center;font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px);margin:0px 4px;display:flex;flex-direction:row;align-items:center;column-gap:4px;margin-bottom:8px}.nodate{align-items:center;gap:4px;width:148px}.date{align-items:center;gap:4px;width:148px}.pghdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.prehdr{font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);font-weight:400;text-align:center;width:100%}.kcntr{text-decoration:none;${m.f}}.kcntr:focus-visible{outline-offset:-1px}.kmtch{padding:12px 0}:host(:first-of-type) :not(.kcntr) .kmtch{padding-top:0}:host(:last-of-type) :not(.kcntr) .kmtch{padding-bottom:0}.g-dtl{display:flex;flex-direction:column;gap:2px;align-items:center}:host-context(.sports-match-list) .kscr{font-size:var(--type-ramp-plus-3-font-size)}:host-context(.sports-match-list) .kcntr .kscr{font-size:var(--smtc-text-global-title1-font-size,28px);line-height:var(--smtc-text-global-title1-line-height,32px)}._05u .nodate,._05u .date,._05u .kpart{gap:8px}._05u.kcntr .kmtch{height:98px}.kmtch{padding:7px 0px;width:100%;height:78px;box-sizing:border-box;color:var(--smtc-foreground-ctrl-neutral-primary-rest,#282523)}.kname{font-size:var(--smtc-text-global-body2-font-size,15px);line-height:var(--smtc-text-global-body2-line-height,20px)}.r-live-text{font-weight:400;font-size:var(--smtc-text-global-caption1-font-size,12px);line-height:var(--smtc-text-global-caption1-line-height,16px);color:var(--ruby-live-text-color,rgba(0,127,48,1));font-weight:600;text-transform:uppercase}.post-game .kscr:not(.winner-team){color:var(--smtc-theme-color-foreground-secondary-650,#4c4642)}.kscr-cntr{display:grid;grid-template-columns:1fr min-content 1fr}.kscr-cntr .part-left{justify-content:end}.kpart{height:auto}.r-live-tag{background:var(--ruby-live-text-bg,rgba(237,246,232,1));border-radius:8px;padding:6px;display:grid;grid-template-columns:auto auto;gap:4px}.r-live-icon{width:20px;height:20px;margin:-2px}.kcntr .winner-tag > svg{width:10px;height:10px}.kcntr .winner-tag svg path{fill:currentColor}`.withBehaviors(new v.N(null,k),(0,x.mr)(f.A` :host{forced-color-adjust:auto}@media screen and (-ms-high-contrast:active){.super-bowl,.participant-container,.top-game-detail,.middle-game-detail,.bottom-game-detail,.top-detail > span,.game-score-text-style,.game-in-progress-text,.video-detail,.game-winner-description{color:${y.A.CanvasText}}.icon-add > svg > g > path,.icon-selected > svg > path{fill:${y.A.LinkText}}.icon-add > svg > g > rect,.icon-selected > svg > rect{fill:#000000;stroke:${y.A.LinkText}}.click-for-detail{border:1px solid;background-color:${y.A.LinkText}}.detail-live-animation{background-color:${y.A.LinkText}}.scores-line{overflow:hidden}}`),new b.o("isWindowsCopilot",!0,S));var C=i(23587),z=i(50180),F=i(96950),M=i(69259),D=i(36516),E=i(10500),P='<svg width="6" height="7" viewBox="0 0 6 7" fill="none"><path d="M.38 2.82a.8.8 0 0 0 0 1.36l4.5 2.71c.5.3 1.12-.07 1.12-.67V.78c0-.6-.63-.98-1.13-.67L.38 2.82Z" fill="#1A1A1A"/></svg>';const _=(t,e)=>F.qy`
    <div class="follow-icon"
        role="button"
        tabindex="0"
        title="${i=>(0,z.GP)(e?i.viewModel.strings.followSports||"":i.viewModel.strings.haveFollowed||"",t.name||"")}"
        @click="${(i,r)=>i.handleClickFollowIcon(r.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:C.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||"")}"
        @keyup="${(i,r)=>r&&r.event&&"Enter"===r.event.key?i.handleClickFollowIcon(r.event,e,{id:t.satoriId||"",name:t.name,yId:t.yId||"",type:C.XR.Team,imageUrl:t.imageUrl},t.scheduleUrl||""):null}"
        data-t="${t=>{var e;return null===(e=t.viewModel)||void 0===e?void 0:e.followTelemetryTag}}"
    >
        <div class="${t=>e?"icon-add":"icon-selected"}"> ${F.qy.partial(e?D.A:E.A)}</div>
    </div>
`,B=F.qy`
    <div class="game-details">
        ${F.qy`<div class="top-game-detail">${t=>t.viewModel.topDetailText}</div>`}
        ${t=>function(t,e){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:null,r=arguments.length>3&&void 0!==arguments[3]?arguments[3]:null;switch(t.getMatchData().gameStateCatetory){case C.Xp.preGame:return null==i?K():Z(i);case C.Xp.inprogressGame:return rt();case C.Xp.postGame:return e?it():(0,z.oT)(t.viewModel.topDetailText)?tt(r||""):et();default:return K()}}(t,t.viewModel.shouldShowChampionPostGame,t.viewModel.preGameNotificationMessage,t.viewModel.postGameNotificationMessage)}
    </div>
`,R=F.qy`
    <div class="${t=>t.getMatchData().additionalInfo?"game-details-wrapper":""}">
        ${B}
        ${t=>j(t.getMatchData().additionalInfo)}
    </div>
`,A=()=>F.qy`
    <div class="g-dtl ${t=>t.getMatchData().gameStateCatetory}">
        <div class="nodate">
            ${t=>t.getMatchData().gameStateCatetory===C.Xp.inprogressGame?H:""}
            ${t=>t.getMatchData().gameStateCatetory===C.Xp.postGame?N:""}
            <div class="kscr-cntr">
                <span class="kscr ${t=>{var e;return null!==(e=t.getMatchData().participantOne)&&void 0!==e&&e.isWinner?"winner-team":""}} part-left">
                    ${(0,M.z)(t=>{var e;return null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.isWinner},F.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${F.qy.partial(P)}</span>`)}
                    ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)??""}}
                </span>
                ${t=>{var e,i;return(0,z.oT)((null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)||"")||(0,z.oT)((null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":L}}
                <span class="kscr ${t=>{var e;return null!==(e=t.getMatchData().participantTwo)&&void 0!==e&&e.isWinner?"winner-team":""}}">
                    ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.score)??""}}
                    ${(0,M.z)(t=>{var e;return null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.isWinner},F.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${F.qy.partial(P)}</span>`)}
                </span>
            </div>
        </div>
    </div>
`,I=()=>F.qy`
    <div class="date">
        <div class="prehdr">${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.rightHeaderText}}</div>
        <div class="ktime">${t=>t.getMatchData().gameStartTime}</div>
    </div>
`,j=t=>t?F.qy`
            <div class="game-details-additional-info">
                <div class="round-info">
                    ${t.round||""}
                </div>
                <div class="round-summary-info">
                    ${t.roundSummary||""}
                </div>
                <div class="round-scores-info">
                    ${t.scores}
                </div>
            </div>
        `:null,L=F.qy`
    <span class="scores-line">${F.qy.partial(C.Z5)}</span>
`,O=F.qy`
    <span>${F.qy.partial("·")}</span>
`,H=F.qy`
    <div class="r-live-tag">
        <img class= "r-live-icon" src="${t=>t.viewModel.liveIconUrl}" />
        <span class="r-live-text">${C.T0.Live}</span>
    </div>
`,N=F.qy`
    <div class="pghdr">
        <span>${C.T0.Final}</span>
        ${t=>t.getMatchData().gameDate?O:""}
        <span>${t=>t.getMatchData().gameDate}</span>
    </div>
`,V=F.qy`
    <div class="vert-noline">
        <div class="vert-header ${t=>t.getMatchData().gameStateCatetory===C.Xp.inprogressGame?"in-prog-vert":""}">
            ${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.header}}
        </div>
        <div class="matchup-vert">
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${t=>{var e;return null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name}}">
                        ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}
                    </div>
                </div>
                <div class="score ${t=>t.getMatchData().gameStateCatetory===C.Xp.preGame?"standings-style":""}">${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.topScoreText}}</div>
            </div>
            <div class="part-vert">
                <div class="part-info">
                    <div class="icon-vert">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div class="name" title="${t=>{var e;return null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name}}">
                        ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}
                    </div>
                </div>
                <div class="score ${t=>t.getMatchData().gameStateCatetory===C.Xp.preGame?"standings-style":""}">${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.bottomScoreText}}</div>
            </div>
        </div>
    </div>
`,G=F.qy`
    <div class="line-match">
        <div>
            <div class="line-wrap">
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantOneImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}
                    </div>
                </div>
                <div class="line-part">
                    <div class="line-icon">
                        <img
                            role="presentation"
                            src="${t=>t.viewModel.participantTwoImgIcon}"
                            onerror="this.style.display='none';this.alt=''"
                        />
                    </div>
                    <div>
                        ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}
                    </div>
                </div>
            </div>
            <div class="vert-line"></div>
        </div>
        <div class="game-date">
            <div>${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.leftHeaderText}}</div>
            <div>${t=>{var e;return null===(e=t.viewModel.headerText)||void 0===e?void 0:e.rightHeaderText}}</div>
        </div>
    </div>
`,U=F.qy`
    ${t=>t.viewModel.isSpotlightCard?q:Y}
`,W=F.qy`
    <div class="kmtch">
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${t=>t.viewModel.participantOneImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}"
                />
            </div>
            <div class="kname ${t=>{var e,i;return null!==(e=t.getMatchData().participantOne)&&void 0!==e&&e.shortName||null===(i=t.getMatchData().participantOne)||void 0===i||!i.name?"":"long-name"}}" title="${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}">
                ${t=>{var e,i;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.shortName)||(null===(i=t.getMatchData().participantOne)||void 0===i?void 0:i.name)||""}}
            </div>
        </div>
        ${t=>(t=>t.getMatchData().gameStateCatetory===C.Xp.inprogressGame||t.getMatchData().gameStateCatetory===C.Xp.postGame?A():I())(t)}
        <div class="kpart">
            <div class="kicon">
                <img
                    role="presentation"
                    src="${t=>t.viewModel.participantTwoImgIcon}"
                    onerror="this.style.display='none';this.alt=''"
                    title="${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}"
                />
            </div>
            <div class="kname ${t=>{var e,i;return null!==(e=t.getMatchData().participantTwo)&&void 0!==e&&e.shortName||null===(i=t.getMatchData().participantTwo)||void 0===i||!i.name?"":"long-name"}}" title="${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}">
                ${t=>{var e,i;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.shortName)||(null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.name)||""}}
            </div>
        </div>
    </div>
`,Y=F.qy`
    <a class="kcntr ${t=>"0.5u"===t.viewModel.cardSize?"_05u":""}"
        tabindex="${t=>t.viewModel.tabIndex}"
        href="${t=>t.getMatchData().matchClickthroughUrl?t.getMatchData().matchClickthroughUrl:void 0}"
        target="${t=>t.viewModel.linkTarget}"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        ${W}
    </a>
`,q=F.qy`
    <div class="kcntr ${t=>"0.5u"===t.viewModel.cardSize?"_05u":""}">
        ${W}
    </div>
`,J=F.qy`
    ${t=>t.viewModel.needsVerticalLine?G:V}
`,X=F.qy`
    <a class="
        sports-match matchup-neutral-background
        ${t=>t.viewModel.noBackgrounds?"no-bg":""}
        ${t=>t.viewModel.reason.length>0?"reason":""}
        ${t=>t.viewModel.isSpotlight2Card?"spotlight-two":""}
    "
        tabindex="${t=>t.viewModel.tabIndex}"
        href="${t=>t.getMatchData().matchClickthroughUrl?t.getMatchData().matchClickthroughUrl:void 0}"
        target="${t=>t.viewModel.linkTarget}"
        data-t="${t=>t.viewModel.telemetryTag}"
    >
        <div role="presentation" class="side-by-side-gradient-container" style="${t=>`background-image: ${t.viewModel.backgroundGradient};`}"></div>
        <div class="side-by-side-matchup-content" style="${t=>t.viewModel.overrideStyleForMatch} ${t=>t.viewModel.matchupContentNotificationStyleIfNecessary}">
            <div class="participant-container ${t=>t.viewModel.shouldDisplayT4?"":" participant-one-alignment"}">
                <div class="participant-icon ${t=>t.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${t=>t.viewModel.showMatchUXV2?"logo-backplate":""}" style="${t=>`background-color: ${t.viewModel.participantOneColor};`}">
                    <img
                        role="presentation"
                        src="${t=>t.viewModel.participantOneImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${t=>_(t.getMatchData().participantOne||{},!t.viewModel.participantOneFollowed)}
                </div>
                <div class="participant-name-style" title="${t=>{var e;return null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name}}">
                    ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.name)||""}}
                </div>
            </div>
            ${R}
            <div class="participant-container right-participant ${t=>t.viewModel.shouldDisplayT4?"":" participant-two-alignment"}">
                <div class="participant-icon ${t=>t.viewModel.useLargeTeamIcon?"participant-icon-large":""} ${t=>t.viewModel.showMatchUXV2?"logo-backplate":""}" style="${t=>`background-color: ${t.viewModel.participantTwoColor};`}">
                    ${(0,M.z)(t=>t.viewModel.isSpotlight2Card,F.qy`${t=>_(t.getMatchData().participantTwo||{},!t.viewModel.participantTwoFollowed)}`)}
                    <img
                        role="presentation"
                        src="${t=>t.viewModel.participantTwoImgIcon}"
                        onerror="this.style.display='none';this.alt=''"
                    />
                    ${(0,M.z)(t=>!t.viewModel.isSpotlight2Card,F.qy`${t=>_(t.getMatchData().participantTwo||{},!t.viewModel.participantTwoFollowed)}`)}
                </div>
                <div class="participant-name-style" title="${t=>{var e;return null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name}}">
                    ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.name)||""}}
                </div>
            </div>
        </div>
    </a>
`,K=()=>F.qy`
    <div class="middle-game-detail" title="${t=>t.getMatchData().gameStartTime}">
        <span class="game-time-text-style" >
            ${t=>t.getMatchData().gameStartTime||""}
        </span>
    </div>
    <div class="bottom-game-detail ${t=>t.viewModel.shouldDisplayT4?"":"foreground-rest-text-color"}" title="${t=>t.getMatchData().tvChannel?`${t.getMatchData().gameDate} - ${t.getMatchData().tvChannel}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameDate||""}</span>
            ${t=>t.getMatchData().tvChannel&&t.getMatchData().gameDate?L:""}
        <span>${t=>t.getMatchData().tvChannel||""}</span>
    </div>
`,Z=t=>F.qy`
    <div class="middle-game-detail" title="${t=>t.getMatchData().gameStartTime+"-"+t.getMatchData().gameDate}">
        <span class="game-time-text-style game-time-notification-text-style">
            ${t=>`${t.getMatchData().gameStartTime||""}`}
        </span>
        <span class="game-time-text-style game-time-notification-text-style game-time-dot-seperator">
            ${t=>""+(t.getMatchData().gameStartTime?"·":"")}
        </span>
        <span class="game-time-text-style game-time-notification-text-style">
            ${t=>`${t.getMatchData().gameDate}`}
        </span>
    </div>
    <div class="${"bottom-game-detail bottom-notification-container pregame"}" title="${t}">
        <span class=${t=>t.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
            ${t}
        </span>
    </div>
`,Q=()=>F.qy`
    <div class="middle-game-detail ${t=>t.viewModel.hasLongScore?"long-score":""}">
        <span class="game-score-text-style">
            ${(0,M.z)(t=>{var e;return null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.isWinner},F.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag text-align-end">${F.qy.partial(P)}</span>`)}
            ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)??""}}
        </span>
        ${t=>{var e,i;return(0,z.oT)((null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)||"")||(0,z.oT)((null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":L}}
        <span class="game-score-text-style">
            ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.score)??""}}
            ${(0,M.z)(t=>{var e;return null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.isWinner},F.qy`<span class="${"rtl"===document.dir?"rtl":""} winner-tag scale-x">${F.qy.partial(P)}</span>`)}
        </span>
    </div>
`,tt=t=>F.qy`
    <div class="top-game-detail"
        title="${t=>t.getMatchData().gameState?`${t.getMatchData().gameDate} - ${t.getMatchData().gameState}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameState||""}</span>
        ${t=>t.getMatchData().gameDate&&t.getMatchData().gameState?O:""}
        <span>${t=>t.getMatchData().gameDate||""}</span>
    </div>
    ${Q()}
    ${(0,M.z)(!(0,z.oT)(t),F.qy`
        <div class="${"bottom-game-detail bottom-notification-container"}" title="${t}">
            <span class=${t=>t.viewModel.shouldUnderlineNotificationMessage?"notification-message underline-text":"notification-message"}>
                ${t}
            </span>
        </div>
    `)}
`,et=()=>F.qy`
    ${Q()}
    <div class="bottom-game-detail"
        title="${t=>t.getMatchData().gameState?`${t.getMatchData().gameDate} - ${t.getMatchData().gameState}`:t.getMatchData().gameDate}">
        <span>${t=>t.getMatchData().gameState||""}</span>
        ${t=>t.getMatchData().gameDate&&t.getMatchData().gameState?O:""}
        <span>${t=>t.getMatchData().gameDate||""}</span>
    </div>
`,it=()=>F.qy`
    <div class="top-game-detail superbowl-top">
        <div class="game-winner-team">
            ${t=>at(t)}
        </div>
        <div class="game-winner-description" title="${t=>t.viewModel.strings.champions||""}">
            ${t=>t.viewModel.strings.championsFormatted}
        </div>
    </div>
    <div class="middle-game-detail">
        <span class="game-score-text-style">
            ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)??""}}
        </span>
        ${t=>{var e,i;return(0,z.oT)((null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)||"")||(0,z.oT)((null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":L}}
        <span class="game-score-text-style">
            ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.score)??""}}
        </span>
    </div>
`,rt=()=>F.qy`
    <div class="middle-game-detail">
        ${t=>t.viewModel.enableLiveScores?F.qy`
    <span class="game-score-text-style">
        ${t=>{var e;return(null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)??""}}
    </span>
    ${t=>{var e,i;return(0,z.oT)((null===(e=t.getMatchData().participantOne)||void 0===e?void 0:e.score)||"")||(0,z.oT)((null===(i=t.getMatchData().participantTwo)||void 0===i?void 0:i.score)||"")?"":L}}
    <span class="game-score-text-style">
        ${t=>{var e;return(null===(e=t.getMatchData().participantTwo)||void 0===e?void 0:e.score)??""}}
    </span>
`:F.qy`
    <span class="click-for-detail" title="click to see score and details">
        ${t=>(t.viewModel.strings.sportsLive||"LIVE").toLocaleUpperCase()}
    </span>
`}
    </div>
    <div class="bottom-game-detail ${t=>t.viewModel.enableLiveScores?"live-scores-detail":""}" title="${t=>t.getMatchData().tvChannel?`${t.getMatchData().gamePeriodAndClock} - ${t.getMatchData().tvChannel}`:t.getMatchData().gamePeriodAndClock}">
        <span class="game-in-progress-text" title="${t=>t.getMatchData().gamePeriodAndClock}">
            ${t=>t.getMatchData().gamePeriodAndClock||""}
        </span>
        ${t=>t.getMatchData().gamePeriodAndClock&&t.getMatchData().tvChannel?L:""}
        <span title="${t=>t.getMatchData().tvChannel}">${t=>t.getMatchData().tvChannel||""}</span>
    </div>
`,at=t=>{const e=t.getMatchData();if(e&&e.gameStateCatetory==C.Xp.postGame){var i,r;let t=null!==(i=e.participantOne)&&void 0!==i&&i.isWinner?null===(r=e.participantOne)||void 0===r||null===(r=r.name)||void 0===r?void 0:r.toUpperCase():null;var a,o;if(!t)t=null!==(a=e.participantTwo)&&void 0!==a&&a.isWinner?null===(o=e.participantTwo)||void 0===o||null===(o=o.name)||void 0===o?void 0:o.toUpperCase():null;return t||""}return""},ot=F.qy`
    ${t=>t.isVertical()?F.qy` ${J} `:t.isCopilotTheme()?F.qy` ${U} `:t.viewModel?F.qy` ${X} `:void 0}
`;let nt=class extends n{};nt=(0,r.Cg)([(0,s.E)({name:"sports-match",template:ot,styles:T,shadowOptions:{delegatesFocus:!0}})],nt)},79811(t,e,i){i.d(e,{AL(){return dt},B5(){return ut},CP(){return K},EZ(){return lt},F_(){return G},HX(){return k},Hn(){return X},Hv(){return _},IR(){return Q},K4(){return et},Lw(){return W},Ot(){return st},PH(){return mt},UU(){return x},VQ(){return N},VY(){return Z},Yf(){return F},Yo(){return tt},ZL(){return $},Zi(){return w},_K(){return B},_S(){return bt},bm(){return j},bw(){return H},d(){return ft},d$(){return S},gK(){return xt},gS(){return pt},iK(){return nt},jJ(){return it},ju(){return I},lb(){return V},m5(){return ht},nD(){return vt},or(){return U},p6(){return L},qM(){return A},ry(){return ct},s$(){return rt},sP(){return Y},wB(){return R},ww(){return q},yl(){return O},yn(){return gt},z2(){return E},zy(){return yt}});var r=i(23587),a=i(3083),o=i(85312),n=i(22341),s=i(80895),l=i(58792),p=i(90366),d=i(2827),c=i(42161),g=i(54229),h=i(49150),u=i(97266),m=i(50180),v=i(25109),y=i(26220),f=i(94016),b=i(52356);const x="OSC.LBUDD745586EC750353FBC1F3971212F2F92540502D2A29306D4081FAD3D5858B79B",w="#A71930",$="#036779",S="#B10E1C",k="#DC626D",T="sportshero",C="sportsspotlight2",z=[r.v1.TeamVsTeamExploration,r.v1.CricketExploration,r.v1.TennisExploration],F=t=>{if(t){return M(t)}return""},M=t=>t?(D(t)?t+="&h=50&w=50&m=6&q=100&u=t&o=t&l=f&f=png":t.indexOf("//www.bing.com/th?")>=0&&t.indexOf("&w=")>0&&(t=t.split("&w=")[0]+"&w=100&h=100&qlt=100&c=0&rs=1"),t):t,D=t=>["//img-s-msn-com.akamaized.net/tenant/amp/entityid","//img-s.msn.cn/tenant/amp/entityid"].some(e=>t.indexOf(e)>=0);function E(t){return null!=t}const P=t=>!t||!t.trim(),_=t=>B(t,80,80,!0),B=function(){let t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:"",e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:40,i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:40,r=arguments.length>3&&void 0!==arguments[3]&&arguments[3];return t?t.replace(/w=([\d]*)?&h=([\d]*)?/,`w=${r?i+20:i}&h=${r?e+20:e}`):null},R=t=>t.get(r.kA.sportsData),A=t=>{var e;const i=H(t);return g.aC.safeExecute(()=>{var t;return(null===(t=i.tabContent)||void 0===t||null===(t=t.league)||void 0===t||null===(t=t.sportsMatches)||void 0===t?void 0:t.map(t=>({sportsMatchData:t})))||[]},void 0,o.ON,`Sports V2 sportsMatches is not valid. sportsMatches=${JSON.stringify(null===(e=i.tabContent)||void 0===e||null===(e=e.league)||void 0===e?void 0:e.sportsMatches)}; tabType=${i.tabType};`)},I=t=>{var e;return null===(e=H(t).tabContent)||void 0===e||null===(e=e.freTeams)||void 0===e?void 0:e.map(t=>({...t,id:t.id||t.satoriId}))},j=t=>H(t).reason||"-1",L=t=>{var e;return null===(e=H(t).tabContent)||void 0===e?void 0:e.sportsSpotLightData},O=t=>t.get(r.kA.pollOptionId),H=t=>{var e;const i=R(t),r=Y(t)-1;return null===(e=i.Model)||void 0===e?void 0:e.Tabs[r]},N=t=>Boolean(t)&&z.includes(t),V=t=>t===r.v1.Fre,G=t=>t===r.v1.SpotlightFRE,U=t=>t===r.v1.StandingsRankings,W=(t,e)=>{const i=t.get(r.kA.dislikedEntities);return null==i?void 0:i.has(e)},Y=t=>t.get(r.kA.tabCurrentPageIndex)||1,q=t=>{const e=H(t);return e?J(e.tabType):r.v1.TeamVsTeam},J=t=>{switch(t){case r.v1.TeamVsTeamExploration:case r.v1.CricketExploration:case r.v1.TennisExploration:case r.v1.EventBrief:case r.v1.TeamVsTeamWithBracket:case r.v1.SpotlightTennis:case r.v1.SpotlightRace:case r.v1.SpotlightGolf:case r.v1.SpotlightFRE:case r.v1.StandingsRankings:case r.v1.SportsMedal:case r.v1.LeagueEventResultOneVsOne:case r.v1.LeagueEventResultOneVsMany:case r.v1.LeagueEventResultTeamVsTeam:case r.v1.LeagueEvents:case r.v1.TeamStandingWithEvents:case r.v1.TeamStandingWithMedals:case r.v1.SpotlightCricket:case r.v1.TournamentsList:case r.v1.Spotlight2c:return t;case r.v1.SeasonStatistics:case r.v1.Video:case r.v1.Countdown:case r.v1.Spotlight:return r.v1.Spotlight;default:return r.v1.TeamVsTeam}};function X(t){return"boolean"==typeof t?t:!!t&&("1"===t||"true"===t.toLowerCase())}function K(t){switch(t){case h.uE._1x_1y:return"small";case h.uE._1x_3y:return"large";default:return"medium"}}const Z=(t,e)=>void 0!==t&&void 0!==e&&(e.get(t)||!1),Q=(t,e,i)=>{switch(t){case h.uE._15u:case h.uE._1x_2y:return 3;case h.uE._1x_3y:return e===r.aB.Cricket?4:i;default:return 1}},tt=t=>t.some(t=>t&&t.sportsMatchData&&t.sportsMatchData.gameStateCatetory===r.Xp.inprogressGame),et=(t,e,i,r)=>{const a=r;return a&&a[i]&&a[i][e.toString()]?(0,m.GP)((t=>{let e=146;return t===h.uE._1x_2y?e=304:t===h.uE._1x_3y&&(e=462),`https://img-s-msn-com.akamaized.net/tenant/amp/entityid/{0}.img?w=300&h=${e}&q=90&m=6&f=jpg&u=t`})(i),a[i][e.toString()]):null},it=()=>l.T3.AppType===f.u.BingHomepage?b.y.appInDarkMode():(null===s.F_||void 0===s.F_?void 0:s.F_.get(s.nz.IsDarkMode))??(0,v.ud)(),rt=(t,e,i,a)=>{const o=+t;if(!a||Number.isNaN(o)||o<0)return"";if(1===o)return i===r.XR.League?e.followedReasonLeague:e.followedReasonTeam;const n=r.IG[t];return n&&e[n]||""},at="BB1dV8FG",ot="MSports";function nt(t){let e=arguments.length>1&&void 0!==arguments[1]&&arguments[1],i=arguments.length>2?arguments[2]:void 0;const r={format:a.f5.PNG,enableDpiScaling:!1,crop:0,...i};return P(t)?e?(0,a.XP)(at,r):null:t.indexOf(".")>0?(0,a.oQ)(`${a.Ro}?id=${t}&pid=${ot}`,r):(0,a.XP)(t,r)}function st(t){if(null!=t&&t.startsWith("http"))return t;if(!t)return"";const e=(0,c.g2)((0,p.t7)(t));return(0,d.oh)()?function(t){if(!t)return t;try{const e=new URL((0,y.$N)()),i=new URL(t),r=e.searchParams.getAll("item").find(t=>t.startsWith("flights:"));return r&&i.searchParams.append("item",r),i.href}catch{return t}}(e):e}function lt(t,e){if(!t||!e)return t;try{const i=new URL(t),r=i.searchParams;return Object.keys(e).forEach(t=>{t&&e[t]&&r.set(t,e[t])}),i.toString()}catch{return t}}function pt(t){return t&&!t.startsWith("#")?`#${t}`:t}function dt(t,e){const i=new u.e;try{return i.localizedMonthDate(t,e)}catch(i){(0,n.vV)(o.Gu,"Sports card localizedMonthDate exception.",`date=${t} market=${e} error=${i&&i.message}`);let r=t.toLocaleDateString("en-us",{month:"short",day:"numeric"});return r||(r=t.toDateString()),r?r.replace(/\u200E/g,"").replace(/\u200F/g,""):r}}function ct(t,e){const i=new u.e;try{return i.formatTimeFromDate(t,e)}catch(i){return(0,n.vV)(o.Gu,"Sports card formatTimeFromDate exception.",`date=${t} market=${e} error=${i&&i.message}`),t.toTimeString()}}function gt(t){const e=60*(new Date).getTimezoneOffset()*1e3,i=new Date(t).valueOf();return new Date(i-e)}function ht(t){switch(t){case"PreGame":default:return r.Xp.preGame;case"InProgressGame":case"InProgress":return r.Xp.inprogressGame;case"Final":case"PostGame":return r.Xp.postGame}}function ut(t){var e;return"string"!=typeof t.gameState?ht(null===(e=t.gameState)||void 0===e?void 0:e.state):t.gameStateCatetory}function mt(t){if(!t||"string"==typeof t)return"";const{gamePeriod:e,gameClock:i}=t;return e&&i?`${e} ${i}`:e||i||""}function vt(t){return!t||"object"==typeof t&&0===Object.keys(t).length}function yt(t){var e;return(null===(e=t.get(r.kA.cardType))||void 0===e?void 0:e.toLowerCase().startsWith(T))||!1}function ft(t){var e;return(null===(e=t.get(r.kA.cardType))||void 0===e?void 0:e.toLowerCase().startsWith(C))||!1}function bt(t,e){if(t.id&&e){const i=new URL(e);i.searchParams.append("videoId",t.id),e=i.toString()}return e}function xt(t,e){return!t.hasExplicitInterest||null!=e&&e.has(t.satoriId)||null!=e&&e.has(t.yId)?!0===(null==e?void 0:e.get(t.satoriId||""))||!0===(null==e?void 0:e.get(t.yId||"")):(null==e||e.set(t.satoriId,!0),!0)}},82724(t,e,i){i.r(e),i.d(e,{SportsMatchTransformer(){return l}});var r=i(23587),a=i(79811),o=i(31157),n=i(58792),s=i(94016);class l extends r.Bc{constructor(){super(...arguments),this.isCopilotTheme=!1,this.getPreGameNotificationMessage=t=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==t&&t.gameStateCatetory===r.Xp.preGame?t.preGameNotificationMessage:null,this.getPostGameNotificationMessage=t=>this.isCopilotTheme?null:this.transformerProvider.config.enableInCardNotifications&&null!==t&&t.gameStateCatetory===r.Xp.postGame?t.postGameNotificationMessage:null,this.getMatchupContentNotificationStyleIfNecessary=t=>this.isNotificationEnabledAndAvailable(t)?"side-by-side-matchup-content-notification":"",this.isNotificationEnabledAndAvailable=t=>null!=this.getPreGameNotificationMessage(t)||null!=this.getPostGameNotificationMessage(t),this.getTeamColor=function(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"";return null!=t&&t.primaryColor?(0,a.gS)(t.primaryColor):null!=t&&t.primaryColorHex?(0,a.gS)(t.primaryColorHex):e},this.getTeamImageUrl=t=>{if(null!=t&&t.imageUrl)return(0,a.Hv)(null==t?void 0:t.imageUrl);const e=(0,a.iK)(null==t?void 0:t.imageId,!(null!=t&&t.imageId),this.transformerProvider.config.teamImageInfoEnhanced);return(0,a.Hv)(e)},this.getBackgroundGradient=t=>{if(!t)return"";const e=this.getTeamColor(t.participantOne),i=this.getTeamColor(t.participantTwo);if(!e||!i||e===i&&"#ffffff"===e.toLowerCase())return"";const r=this.hexToRgba(e,1),a=this.hexToRgba(e,.35),o=this.hexToRgba(i,1),n=this.hexToRgba(i,.35);return`linear-gradient(\n                        ${this.isRTLDirection()?"-120deg":"120deg"},\n                        ${r} 0%,\n                        ${r} 10.75%,\n                        ${a} 11%,\n                        ${a} 14.75%,\n                        transparent 15%,\n                        transparent 85%,\n                        ${n} 85.25%,\n                        ${n} 89%,\n                        ${o} 89.25%,\n                        ${o} 100%)`},this.isRTLDirection=()=>document.dir===o.O.rtl,this.getGameDate=t=>{const{gameStartDateTime:e,gameStateCatetory:i}=t||{};if(this.isCopilotTheme){const t=(0,a.yn)(e),o=i===r.Xp.postGame?{month:"short",day:"numeric"}:{weekday:"short",day:"numeric",month:"long"};return t.toLocaleDateString(n.T3.CurrentMarket,o)}{const t=(0,a.yn)(e);return(0,a.AL)(t,n.T3.CurrentMarket)}}}async transform(t){return{viewModel:await this.getViewModel(t)}}updateAdditionalInfo(t){const{sportsMatchData:e}=t;if(e&&e.additionalInfo){if(!e.additionalInfo.round&&e.additionalInfo.roundLocKey){var i;let t=this.transformerProvider.strings[e.additionalInfo.roundLocKey];null===(i=e.additionalInfo.roundParams)||void 0===i||i.forEach((e,i)=>{var r;t=null===(r=t)||void 0===r?void 0:r.replace(`{${i}}`,e)}),e.additionalInfo.round=t}if(!e.additionalInfo.roundSummary&&e.additionalInfo.roundLocKey){var r;let t=this.transformerProvider.strings[e.additionalInfo.roundSummaryLocKey];null===(r=e.additionalInfo.roundSummaryParams)||void 0===r||r.forEach((e,i)=>{var r;t=null===(r=t)||void 0===r?void 0:r.replace(`{${i}}`,e)}),e.additionalInfo.roundSummary=t}}}getGroupInfo(t){const e=t.matchData.sportsMatchData;var i;if(e.groupInfo)return null===(i=this.transformerProvider.strings.groupText)||void 0===i?void 0:i.replace("${0}",e.groupInfo)}hexToRgba(t){let e=arguments.length>1&&void 0!==arguments[1]?arguments[1]:1;const i=t.match(/\w\w/g);if(!i)return"";const[r,a,o]=i.map(t=>parseInt(t,16));return`rgba(${r},${a},${o},${e})`}hasLongScore(t){var e,i;const r=(null===(e=t.participantOne)||void 0===e?void 0:e.score)||"",a=(null===(i=t.participantTwo)||void 0===i?void 0:i.score)||"";return r.length+a.length>6}getHeaderText(t){var e,i,a,o;if(!t||0===Object.keys(t).length)return{header:"",topScoreText:"",bottomScoreText:"",leftHeaderText:"",rightHeaderText:""};const{gameStartDateTime:n,gameDate:s,gamePeriodAndClock:l,gameStateCatetory:p}=t,d=null===(e=t.participantOne)||void 0===e?void 0:e.score,c=null===(i=t.participantTwo)||void 0===i?void 0:i.score,g=null===(a=t.participantOne)||void 0===a?void 0:a.standings,h=null===(o=t.participantTwo)||void 0===o?void 0:o.standings,u=new Date(n).getFullYear(),m=t.gameStartTime?t.gameStartTime.toLocaleLowerCase():"";let v,y,f,b,x;switch(p){case r.Xp.preGame:v=m,y=this.isCopilotTheme?s:`${s}, ${u}`,f=g,b=h;break;case r.Xp.inprogressGame:v=this.transformerProvider.strings.sportsLive.toLocaleUpperCase(),y=l,f=d,b=c;break;case r.Xp.postGame:v=this.transformerProvider.strings.sportsStateFinal,y=`${s}, ${u}`,f=d,b=c;break;default:v=m,y=s,f=g,b=h}switch(!0){case!!v&&!!y:x=`${v} • ${y}`;break;case!!v:x=v;break;case!!y:x=y;break;default:x=""}return{header:x,topScoreText:f,bottomScoreText:b,leftHeaderText:v,rightHeaderText:y}}async getViewModel(t){const{matchData:e,isVertical:i,telemetryConstants:o,showMatchUXV2:l,noBackgrounds:p,participantOneFollowed:d,participantTwoFollowed:c,reason:g,isContainLiveMatch:h,parentTelemetryObject:u,topDetailText:m,useLargeTeamIcon:v,hasVerticalLine:y,isSpotlight2Card:f,isSpotlightCard:b}=t||{},x=e.sportsMatchData;this.isCopilotTheme=t.isCopilotTheme||!1,this.updateAdditionalInfo(e),"string"!=typeof x.gameState&&(x.gameStateCatetory=(0,a.m5)(x.gameState.state));const w=(0,a.yn)(x.gameStartDateTime);x.gameDate=this.getGameDate(x),x.gameStartTime=(x.gameStartDateTimeIsToBeAnnounced?null:(0,a.ry)(w,n.T3.CurrentMarket))||this.transformerProvider.strings.sportsTBA,"string"!=typeof x.gameState&&(x.gamePeriodAndClock=(0,a.PH)(x.gameState)),"string"!=typeof x.gameState&&(x.gamePeriod=x.gameState.gamePeriod),x.participantOne&&(x.participantOne.scheduleUrl=(0,a.Ot)(x.participantOne.gameCenterUrl)),x.participantTwo&&(x.participantTwo.scheduleUrl=(0,a.Ot)(x.participantTwo.gameCenterUrl)),x.gameCenterUrl&&(x.matchClickthroughUrl=(0,a.Ot)(x.gameCenterUrl)),x.participantOne.imageUrl=(0,a.iK)(x.participantOne.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),x.participantTwo.imageUrl=(0,a.iK)(x.participantTwo.imageId,!1,this.transformerProvider.config.teamImageInfoEnhanced),x.gameState=x.gameStateCatetory===r.Xp.postGame?this.transformerProvider.strings.sportsStateFinal:x.gameStateCatetory;const $={...o,name:r.BP.Game},S=i||t.isCopilotTheme,k=this.transformerProvider.config.enableLiveScores,T=l&&!p&&!k,C=(0,a.jJ)()?`${n.T3.StaticsUrl}/pr-5772998/icons-wc/icons/sports/LiveIconDark.svg`:`${n.T3.StaticsUrl}/latest/icons-wc/icons/sports/LiveIcon.svg`;return{backgroundGradient:k||l?"":this.getBackgroundGradient(x),followClickHandler:this.transformerProvider.followClickEntityHandler,followTelemetryTag:this.transformerProvider.telemetryBuilder.createFollowTelemetryTag(u,{...$,name:r.BP.FollowTeam},!0),hasLongScore:this.hasLongScore(x),gameNumber:"number",linkTarget:"_blank",matchData:e,matchupContentNotificationStyleIfNecessary:this.getMatchupContentNotificationStyleIfNecessary(x),overrideStyleForMatch:"",participantOneColor:T?this.getTeamColor(x.participantOne):"",participantOneFollowed:d,participantOneImgIcon:this.getTeamImageUrl(x.participantOne),participantTwoColor:T?this.getTeamColor(x.participantTwo):"",participantTwoFollowed:c,participantTwoImgIcon:this.getTeamImageUrl(x.participantTwo),postGameNotificationMessage:this.getPostGameNotificationMessage(x),preGameNotificationMessage:this.getPreGameNotificationMessage(x),reason:g,shouldDisplayT4:!h,shouldShowChampionPostGame:!1,shouldShowFollowIcon:!1,shouldUnderlineNotificationMessage:!1,showLiveDetail:!1,strings:{...this.transformerProvider.strings,championsFormatted:this.transformerProvider.strings.champions&&this.transformerProvider.strings.champions.toUpperCase()||r.kt},tabIndex:0,telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(u,$),cardSize:t.cardSize,topDetailText:this.getGroupInfo(t)||m||"",useLargeTeamIcon:k||v,enableLiveScores:k||l,showMatchUXV2:k||l,noBackgrounds:p,isVertical:i,headerText:S?this.getHeaderText(x):void 0,needsVerticalLine:y,liveIconUrl:C,isSpotlight2Card:f,isSpotlightCard:b,isCopilotTheme:this.isCopilotTheme,isWindows:n.T3.AppType===s.u.WindowsNewsWidgets}}}},84564(t,e,i){i.d(e,{z(){return n}});var r=i(56911),a=i(60815),o=i(92011);class n extends o.L{}(0,r.Cg)([a.sH],n.prototype,"viewModel",void 0)},92079(t,e,i){i.d(e,{a(){return n}});var r=i(56911),a=i(92011),o=i(31525);let n=class extends a.L{connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){}addSubscriptions(){}initHandlers(){}};n=(0,r.Cg)([o.x],n)},94016(t,e,i){var r,a;i.d(e,{u(){return r}}),function(t){t.BingHomepage="bingHomepage",t.ChannelMobile="channelmobile",t.Community="community",t.ContentTools="contentTools",t.EdgeChromium="edgeChromium",t.EdgeMobile="edgeMobile",t.Finance="finance",t.Gaming="gaming",t.CGHomePage="cgHomePage",t.CGSideBar="cgSideBar",t.HomePage="homePage",t.Hub="hub",t.Health="health",t.KnowledgeAgents="knowledgeAgents",t.Office="office",t.Personalize="personalize",t.qna="qna",t.msn="msn",t.MSNStudio="msnStudio",t.SharedWidgets="sharedWidgets",t.SuperApp="superApp",t.Shopping="shopping",t.Sports="sports",t.Distribution="distribution",t.Traffic="traffic",t.Travel="travel",t.UGC="ugc",t.Views="views",t.Weather="weather",t.WeatherWidgets="weatherWidgets",t.WeatherLocal="weatherLocal",t.Windows="windows",t.WindowsNewsPlus="windowsNewsPlus",t.WindowsNewsWidgets="winWidgets",t.WindowsShell="windowsShell",t.WindowsShellV2="windowsShellV2",t.WebWidgets="webWidgets"}(r||(r={})),function(t){t.Default="Default",t.WinDashboard="WinDashboard",t.Edge="Edge"}(a||(a={}))},97448(t,e,i){i.r(e),i.d(e,{SportsGameLeadersTransformer(){return d},SportsGameStatsTransformer(){return c.O},SportsMatchTransformer(){return g.SportsMatchTransformer},SportsPickWinnerTransformer(){return u},SportsSpotlightTransformer(){return m.V}});var r=i(49150),a=i(23587),o=i(79811),n=i(22341),s=i(93552);const l=Object.freeze({points:"PTSAbbr",goals:"GAbbr",assists:"AAbbr",saves:"SVAbbr",hits:"HAbbr",atBats:"ABAbbr",strikeOuts:"KAbbr",yards:"YDSAbbr",receptions:"RECAbbr",rebounds:"REBAbbr",attempts:"FGAAbbr",redCards:"RCAbbr",yellowCards:"YCAbbr",powerPlayGoals:"PPGAbbr",powerPlayAssists:"PPAAbbr",fieldGoalsPercentage:"FGPerAbbr",freeThrowsPercentage:"FTPerAbbr",turnovers:"TOAbbr",defensiveRebounds:"DREBAbbr",offensiveRebounds:"OREBAbbr",runsBattedIn:"RBIAbbr",cmpPercValue:"CMPAbbr",touchdowns:"TDAbbr",interceptions:"INTAbbr",rating:"RTGAbbr",longest:"LGAbbr"}),p=Object.freeze({points:"points",rebounds:"rebounds",assists:"assists",passingYards:"passing",rushingYards:"rushing",receivingYards:"receiving",hits:"hits",rbi:"RBI",strikeOuts:"strikeouts",goals:"goals",saves:"saves",cards:"cards"});class d extends a.Bc{async transform(t){try{return{viewModel:await this.getCurrentViewModel(t)}}catch(e){(0,n.vV)(s.EfP,"GameLeadersMetadata is invalid",`jsonData:${JSON.stringify(t)}`,void 0)}}async getCurrentViewModel(t){if(!t)return(0,n.vV)(s.EfP,"GameLeadersMetadata is invalid",`jsonData:${JSON.stringify(t)}`,void 0),null;let e=0;switch(t.cardSize){case r.uE._1x_1y:e=1;break;case r.uE._1x_2y:e=3;break;case r.uE._1x_3y:e=5;break;case r.uE._2x_2y:e=4}const i=this.transformSportsGameLeadersToVM(t.sportsGameLeaders,t.teamColors).slice(0,e),a=t.parentTelemetryObject.getMetadataTag();return{sportsGameLeaders:{categories:i},cardSize:t.cardSize,cardTitle:this.transformerProvider.strings.gameLeaders,telemetryTag:a}}transformSportsGameLeadersToVM(t,e){if(null==t||!t.categoryKeyOrder||null==t||!t.categories)return(0,n.vV)(s.EfP,"GameLeaders object is not valid",`jsonData:${JSON.stringify(t)}`,void 0),[];return t.categoryKeyOrder.map(i=>{const r=t.categories[i];if(!r)return(0,n.vV)(s.EfP,"GameLeaders category data is missing",`jsonData:${JSON.stringify(t)}`,void 0),null;const a=r.players.map(t=>{const i=r.statsKeyOrder.map(e=>({abbreviation:this.transformerProvider.strings[l[e]]||e.slice(0,3).toLocaleUpperCase(),title:e,value:Number(t.playerStats[e]).toFixed(0)||0}));return e[t.teamId]||(0,n.vV)(s.khl,"GameLeaders player team color is missing",`jsonData:${JSON.stringify(t)}`,void 0),{playerImage:(0,o.iK)(t.playerImage||o.UU,!t.playerImage,this.transformerProvider.config.teamImageInfoEnhanced),playerName:t.playerName,playerNumber:t.playerNumber,teamColor:e[t.teamId],playerStats:i}});return{categoryTitle:this.transformerProvider.strings[p[i]]||i.toLocaleUpperCase(),players:a}}).filter(t=>t)}}var c=i(70512),g=i(82724),h=i(54229);class u extends a.Bc{async transform(t){return{viewModel:await this.getCurrentViewModel(t)}}async getCurrentViewModel(t){var e;const{poll:i,telemetryConstants:r,parentTelemetryObject:o,match:n,isSpotlight2Card:s}=t||{},{participantOne:l,participantTwo:p,gameState:d,gameId:c}=n||{},{strings:g,telemetryBuilder:u}=this.transformerProvider,m=[l,p];let v=0;return Array.isArray(i.options)||(i.options=[]),null===(e=i.options)||void 0===e||e.forEach(t=>{t.id!==m[0].id&&t.id!==m[1].id||(v+=parseInt(t.count))}),{strings:{...g},isSpotlight2Card:s,isEntrypoint:!0,teamsVoteData:m.map(t=>{var e;const r=parseInt(null===(e=i.options)||void 0===e||null===(e=e.find(e=>e.id===t.id))||void 0===e?void 0:e.count)||0;return{id:t.id,imageUrl:t.imageUrl,shortName:t.shortName||t.name,hasWon:t.isWinner,voteCount:r,votePercentage:Math.round(r/v*100)||0}}),gameState:"string"==typeof d?d:d.state,userVote:i.userVote,disableVoting:d!==a.Xp.preGame,telemetryContext:{rootTag:o.getMetadataTag(),voteButtonTag:u.createBehaviorTelemetryTag(o,{...r,name:a.BP.SportsPickWinner},h.YJ.Click)},recordUserVote:async t=>{this.transformerProvider.recordUserVote(c,a.t9.PickWinner,t)},telemetryTag:o.getMetadataTag()}}}var m=i(34959);Promise.resolve().then(i.bind(i,27666)),Promise.resolve().then(i.bind(i,71891)),Promise.resolve().then(i.bind(i,76435)),Promise.resolve().then(i.bind(i,34386)),Promise.resolve().then(i.bind(i,64812))},99657(t,e,i){i.d(e,{D(){return n},I(){return o}});var r=i(45755);const{create:a}=r.G,o=a("sloppy-click-z-index",1),n=a("click-z-index",1)}}]);