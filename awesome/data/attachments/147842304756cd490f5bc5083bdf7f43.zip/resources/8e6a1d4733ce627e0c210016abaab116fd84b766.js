// © Microsoft Corporation. All rights reserved.
import { logPcsReturned, verifyJSLoading, setupJSErrorHandler, setupScriptLoadErrorHandler, setupJSPromiseRejectionHandler, logError, Severity } from "@msnews/page-error-handling";
import { WebWorkerInitializer } from "@msnews/core";
import { loadDisplayAdSdkFromHead } from "@msnews/display-ad-service";
import * as inlineHeadCommon from "@msnews/inline-head-common";
import { getOcid, isWinHPOcid } from "@msnews/url-util";
inlineHeadCommon.init();
// log signal that PCS has returned and inline JS is executing.
const dataInfoString = document.head.attributes["data-info"].value;
let flights;
if (dataInfoString) {
    // dataInfoString string contains many items separated by `;`get the one for flights
    const flightString = dataInfoString.split(";").find(a => a.startsWith("f:"));
    if (flightString) {
        flights = flightString.substring(2);
        if (flights.indexOf("1sw-pcsreturnhp") > -1) {
            logPcsReturned(location.href);
        }
    }
}
if (!hasFlight("hp-noww")) {
    new WebWorkerInitializer().init();
}
setupJSErrorHandler();
setupJSPromiseRejectionHandler();
setupScriptLoadErrorHandler();
// Verify JS files were properly loaded,
verifyJSLoading();
// We have to use this custom flight extracting function instead of headData.CurrentFlightSet
// to avoid inlining in the HTMl file huge core lib (+40kb minified at the moment).
export function hasFlight(flightName) {
    const targetFlight = flightName?.toLowerCase() || "";
    // dataInfoString string contains many items separated by `;` get the one for flights
    const flightsStr = document.head?.getAttribute("data-info")?.split(";").find(a => a.startsWith("f:")) || "";
    // Remove the "f:" prefix and split by comma, then check for exact match
    return flightsStr.slice(2).split(",").some(f => {
        const flight = f.trim().toLowerCase();
        if (!flight) {
            return false;
        }
        return flight === targetFlight;
    });
}
if (!hasFlight("prg-hp-fvrf")) {
    loadDisplayAdSdkFromHead();
}
const ocid = getOcid(location.href) || "hpmsn";
const isWinHP = isWinHPOcid(ocid);
// For SSR flight to send early log
if ((hasFlight("prg-hp-ssr") || hasFlight("prg-c-hp-ssr")) && !isWinHP) {
    const activeSw = navigator.serviceWorker?.controller;
    setTimeout(() => {
        logError("Early Log - No Alert", 19018, {
            swURL: activeSw?.scriptURL,
            swState: activeSw?.state,
            timeToSendEarlyLog: performance.now()
        }, Severity.Deprecated);
    }, hasFlight("prg-c-hp-ssr") ? 60 : 0);
}
//# sourceMappingURL=inline-head.js.map