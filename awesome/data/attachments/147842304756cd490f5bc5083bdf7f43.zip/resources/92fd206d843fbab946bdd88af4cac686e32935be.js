(self.homePageWebpackChunks=self.homePageWebpackChunks||[]).push([["money-info-spotlight-currency"],{1817(t,e,i){"use strict";i.r(e),i.d(e,{MoneyInfoDateFilterChart(){return y}});var r=i(56911),a=i(27208),o=i(92707),s=i(60815);class n extends o.z{get isOneDayChart(){return!this.chartType||this.chartType===a.NB.OneDayOneMinute}get accentColor(){var t;if(this.isOneDayChart)return this.viewModel.accentColor;return(null===(t=this.getState().get(a.Xe.ChartDateFilterData))||void 0===t?void 0:t[this.chartType]).changePcntNumber>0?this.viewModel.positiveColor:this.viewModel.negativeColor}get baselinePrice(){var t;return this.isOneDayChart?null===(t=this.chartData)||void 0===t?void 0:t.chartBaseline:void 0}get chartData(){var t,e,i;if(this.isOneDayChart)return this.viewModel.chartData;const r=null===(t=this.getState().get(a.Xe.ChartDateFilterData))||void 0===t?void 0:t[this.chartType];return r?{chartSeries:null===(e=r.chartData)||void 0===e?void 0:e.series,pricesMaxCount:null===(i=r.chartData)||void 0===i?void 0:i.total,chartBaseline:r.pricePreviousClose,changePcnt:r.changePcnt}:{}}handleChangeFilter(t){this.viewModel.handleDateFilterChartChange(this.viewModel.quote.id,t)}updateChart(t){this.chartType=t}addSubscriptions(){super.addSubscriptions(),this.getState().subscribe(a.Xe.ChartDateFilterChartType,this.updateChart.bind(this),{signal:this.subscriptionController.signal})}}(0,r.Cg)([s.sH],n.prototype,"chartType",void 0);var l=i(92011),h=i(12640),c=i(74849),d=i(64003);const p=c.A` :host{--active-color:#235CCF}.filter button.selected,.filter button.selected:hover,.filter button.selected:active,.filter button.selected:focus{background-color:var(--active-color)}.filter button{color:#FFF}.sp-hero .filter button{color:#ADADAD}.sp-hero .filter button.selected{color:#FFF;background-color:#292929}`,u=c.A` :host{--active-color:#2169EB}.filter{display:flex;justify-content:space-between;margin-top:4px}.filter button.selected{background-color:var(--active-color);color:#FFF}.filter button{cursor:pointer;width:36px;height:18px;overflow:hidden;border-radius:20px;white-space:nowrap;padding:3px 6px;border:0px;font-size:var(--type-ramp-minus-2-font-size,10px);line-height:var(--type-ramp-minus-2-line-height,14px);background-color:var(--quote-background)}.filter button:hover{background-color:var(--quote-hover-background)}.filter button:active,.filter button:focus{background-color:var(--quote-active-background)}.no-data{display:flex;align-items:center;justify-content:center;width:244px;height:70px;box-sizing:border-box;padding-bottom:16px;color:${d.c}}.sp-hero .filter{margin-top:8px}.sp-hero .filter button{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px);height:20px;width:34px;background-color:transparent;font-weight:400;color:#242424}.sp-hero .filter button.selected{background-color:#E0EDFF;font-weight:600}`.withBehaviors(new h.N(null,p));var g=i(96950),v=i(39957);const f=g.qy`<div class="filter">${(0,v.ux)(t=>t.viewModel.filterButtonsList,g.qy`<button class="${(t,e)=>t.id!==e.parent.chartType&&e.parent.chartType?"":"selected"}" data-t="${t=>t.telemetryTag}" @click=${(t,e)=>e.parent.handleChangeFilter(t.id)} title="${t=>t.title}" aria-current="${(t,e)=>t.id===e.parent.chartType||!e.parent.chartType}">${t=>t.title}</button>`)}</div>`,x=g.qy`<msn-stock-chart width=${t=>t.viewModel.chartWidth} height=${t=>t.viewModel.chartHeight} skip-transform=${()=>!0} fill-color=${t=>t.accentColor} baseline-color=${t=>t.viewModel.baselineColor} baseline-text=${t=>t.viewModel.previousCloseText} :changePcnt=${t=>t.viewModel.isSpotlightHero?"":t.viewModel.chartData.changePcnt??""} :isDarkModeTheme=${t=>t.viewModel.isDarkModeTheme} :baselinePrice=${t=>t.baselinePrice} :pricesMaxCount=${t=>t.chartData.pricesMaxCount} :enableBaselineText=${t=>t.viewModel.enableBaselineText&&t.isOneDayChart} :enableChangePcntText=${t=>t.isOneDayChart} :prices=${t=>{var e;return null===(e=t.chartData)||void 0===e?void 0:e.chartSeries}} :enableAnimation=${t=>t.viewModel.isChartAnimationEnabled} :fullAnimationDuration=${t=>t.viewModel.chartAnimationDuration} :hasConnectingLine=${t=>t.viewModel.isSpotlightHero} :lineWidth=${t=>t.viewModel.isSpotlightHero?1:1.5} :circleRadius=${t=>t.viewModel.isSpotlightHero?3:4} :baselineDashArray=${t=>t.viewModel.isSpotlightHero?"1 4":"3 5"}></msn-stock-chart>`,m=g.qy`<div class="no-data" style="width: ${t=>t.viewModel.chartWidth}px; height: ${t=>t.viewModel.chartHeight}px">${t=>t.viewModel.strings.dataIsNotAvailable}</div>`,b=g.qy`<template><div class="${t=>t.viewModel.isSpotlightHero?"sp-hero":""}">${t=>{var e;return null!==(e=t.chartData)&&void 0!==e&&null!==(e=e.chartSeries)&&void 0!==e&&e.length?x:m}} ${f}</div></template>`;let y=class extends n{};y=(0,r.Cg)([(0,l.E)({name:"date-filter-chart",template:b,styles:u,shadowOptions:{delegatesFocus:!0}})],y)},4968(t,e,i){"use strict";i.d(e,{f(){return l}});var r=i(64187),a=i(74849),o=i(42792),s=i(99657),n=i(36452);const l=a.A.partial`position: relative; z-index: ${s.D};`;a.A`
    ${o.e}
    ${o.nH}

    ${(0,r.V)("grid")} :host {
        grid-template-rows: auto 1fr minMax(16px, auto);
        grid-template-columns: 100%;
        ${l}
    }

    .content {
        padding: 0 var(--sd-card-content-padding-inline, 16px);
        overflow: hidden;
    }

    ::slotted([slot="header"]) {
        grid-row: 1;
    }
    ::slotted([slot="footer"]) {
        grid-row: 3;
    }

    ::slotted([slot="image"]) {
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        z-index: -1;
    }

    /* Ensure neutral buttons have a stroke per the design */
    ::slotted(fluent-button[appearance="neutral"]),
    ::slotted(fluent-anchor[appearance="neutral"]) {
        border: 1px solid ${n.I2};
    }

    ::slotted(fluent-button[appearance="neutral"]:hover),
    ::slotted(fluent-anchor[appearance="neutral"]:hover) {
        border-color: ${n.mb};
    }

    ::slotted(fluent-button[appearance="neutral"]:active),
    ::slotted(fluent-anchor[appearance="neutral"]:active) {
        border-color: ${n.MY};
    }

    .header-overlay,
    .footer-overlay {
        position: absolute;
        background: rgba(255, 255, 255, 0.46);
        height: 100%;
        width: 100%;
        opacity: 0;
    }

    .header-overlay {
        grid-row: 1 / span 1;
    }

    .footer-overlay {
        grid-row: 3 / span 1;
    }

    .gradient {
        position: absolute;
        grid-row: 2 / span 1;
        height: 100%;
        width: 100%;
        opacity: 0;
        background: linear-gradient(
            180deg,
            rgba(255, 255, 255, 0.46) 0%,
            rgba(255, 255, 255, 0) 22%,
            rgba(255, 255, 255, 0) 86%,
            rgba(255, 255, 255, 0.46) 100%
        );
    }

    @media (prefers-color-scheme: dark) {
        .header-overlay,
        .footer-overlay {
            background: rgba(0, 0, 0, 0.54);
        }

        .gradient {
            background: linear-gradient(
                180deg,
                rgba(0, 0, 0, 0.54) 0%,
                rgba(0, 0, 0, 0) 22%,
                rgba(0, 0, 0, 0) 86%,
                rgba(0, 0, 0, 0.54) 100%
            );
        }
    }

    :host([immersive-card]) .header-overlay,
    :host([immersive-card]) .footer-overlay,
    :host([immersive-card]) .gradient {
        opacity: 1;
    }
`.withBehaviors(o.kc)},42792(t,e,i){"use strict";i.d(e,{R7(){return v},e(){return u},kc(){return g},nH(){return p}});var r=i(57416),a=i(55153),o=i(95239),s=i(26920),n=i(48751),l=i(64187),h=i(22131),c=i(74849),d=i(50882);const p=c.A`
    :host([size][card-fill-color="light-blue"]) {
        background: linear-gradient(140.53deg, #f0e1f7 9.32%, #cddfff 58.45%);
    }

    :host([size][card-fill-color="light-purple"]) {
        background: linear-gradient(139.03deg, #ffe9e1 5.05%, #f0e1f7 51.71%);
    }

    :host([size][card-fill-color="light-sky"]) {
        background: linear-gradient(140.53deg, #f5f7e1 9.32%, #cdf0ff 58.45%);
    }

    :host([size][card-fill-color="light-pink"]) {
        background: linear-gradient(139.03deg, #fff1cd 5.05%, #ffe8ed 51.71%);
    }

    :host([size][card-fill-color="light-yellow"]) {
        background: linear-gradient(140.53deg, #fffedc 9.32%, #fff4d7 58.45%);
    }

    :host([size][card-fill-color="light-bluebird"]) {
        background: linear-gradient(139.03deg, #e1e6f8 5.05%, #ebfefb 51.71%);
    }

    :host([size][card-fill-color="light-orange"]) {
        background: linear-gradient(140.56deg, #f0e1f7 5.42%, #ffe9e1 51.68%);
    }

    :host([size][card-fill-color="light-aqua"]) {
        background: linear-gradient(140.56deg, #cef9ff 5.42%, #e3f9f3 51.68%);
    }

    :host([size][card-fill-color="light-green"]) {
        background: linear-gradient(140.56deg, #fffee9 5.42%, #d0f0e1 51.68%);
    }

    :host([size][card-fill-color="dark-plum"]) {
        background: linear-gradient(138.52deg, #512c2c -1.32%, #252c4e 85.77%);
    }

    :host([size][card-fill-color="dark-desert"]) {
        background: linear-gradient(138.25deg, #553f2b -1.2%, #372d54 84.27%);
    }

    :host([size][card-fill-color="dark-dawn"]) {
        background: linear-gradient(140.02deg, #58314f -2.33%, #29203c 84.75%);
    }

    :host([size][card-fill-color="dark-sea"]) {
        background: linear-gradient(138.52deg, #264b50 0.44%, #292448 85.15%);
    }

    :host([size][card-fill-color="dark-orange"]) {
        background: linear-gradient(140.69deg, #514c28 -7.13%, #482b24 87.33%);
    }

    :host([size][card-fill-color="dark-tropic"]) {
        background: linear-gradient(140.08deg, #0b4b4f 1.27%, #39371e 85.21%);
    }

    :host([size][card-fill-color="dark-merlot"]) {
        background: linear-gradient(140.02deg, #5c452f -2.33%, #3a1b26 84.75%);
    }

    :host([size][card-fill-color="dark-purple"]) {
        background: linear-gradient(140.02deg, #283266 -2.33%, #351740 84.75%);
    }

    :host([size][card-fill-color="dark-green"]) {
        background: linear-gradient(138.44deg, #57511f 0.35%, #17352f 83.81%);
    }
`,u=c.A`
    ${(0,l.V)("flex")} :host {
        background: ${o.p};
        outline: calc(${s.XA} * 1px) solid ${a.cu};
        border-radius: calc((${r.JU} - ${s.XA}) * 1px);
        box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.04);
        box-sizing: border-box;
        color: ${n.l};
        contain: content;
        content-visibility: auto;
    }

    :host(:hover) {
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.14);
    }

    @media (prefers-color-scheme: dark) {
        :host(:hover) {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.26);
        }
    }

    /* Safari specific styles because border-radius and outline aren't compatible in current version  */
    @supports selector(:nth-child(1 of x)) {
        :host {
            outline: none;
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${a.cu},
                0px 2px 4px rgba(0, 0, 0, 0.04);
        }

        :host(:hover) {
            box-shadow: 0 0 0 calc(${s.XA} * 1px) ${a.cu},
                0px 4px 8px rgba(0, 0, 0, 0.14);
        }

        @media (prefers-color-scheme: dark) {
            :host(:hover) {
                box-shadow: 0 0 0 calc(${s.XA} * 1px) ${a.cu},
                    0px 4px 8px rgba(0, 0, 0, 0.26);
            }
        }
    }

    :host([size="_1x_1y"]) {
        width: calc(${a.QG} * 1px);
        height: calc(${a.l8} * 1px);
    }

    :host([size="_1x_2y"]) {
        width: calc(${a.QG} * 1px);
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_2y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc((${a.l8} * 2px) + (${a.Sn} * 1px));
    }

    :host([size="_2x_1y"]) {
        width: calc((${a.QG} * 2px) + (${a.Sn} * 1px));
        height: calc(${a.l8} * 1px);
    }

    ::slotted(*) {
        color: inherit;
    }
`,g=(0,h.mr)(c.A`
            :host {
                background: ${d.A.Canvas};
                color: ${d.A.CanvasText};
            }
        `),v=c.A`
    ${u}
    ${p}

        :host([card-secondary-color]) {
        background: linear-gradient(
            var(--gradient-angle),
            var(--gradient-start-color) 35.59%,
            var(--gradient-end-color) 100%
        );
        background-clip: padding-box;
    }
`.withBehaviors(g)},62376(t,e,i){"use strict";i.r(e),i.d(e,{SpotlightCurrency(){return W}});var r=i(56911),a=i(27208),o=i(92707),s=i(60815);class n extends o.z{constructor(){super(...arguments),this.chartType=a.NB.OneDayOneMinute}get chartData(){return this.viewModel.chartData}get shouldUseChartChangePcnt(){return this.chartType&&this.chartType!==a.NB.OneDayOneMinute}get quoteDataByChartType(){var t,e;let i;var r,o;this.chartType===a.NB.OneDayOneMinute?i=null===(r=this.viewModel.chartData)||void 0===r?void 0:r.chartData:i=null===(o=this.getState())||void 0===o?void 0:o.get(a.Xe.ChartDateFilterData)[this.chartType];const s=this.shouldUseChartChangePcnt?null===(t=i)||void 0===t?void 0:t.changePcnt:null,n=this.shouldUseChartChangePcnt?null===(e=i)||void 0===e?void 0:e.changePcntNumber:null,l=s||this.viewModel.quote.changePcnt,h=n||this.viewModel.quote.changePcntNumber;return this.viewModel.getQuoteDataByChartType(this.chartType,l,h)}get notificationText(){var t;return null===(t=this.quoteDataByChartType.notification)||void 0===t?void 0:t.shortHeadline}get changePcntColor(){return this.quoteDataByChartType.accentColor}get changePcnt(){return this.quoteDataByChartType.changePcnt}updateChartType(t){this.chartType=t}addSubscriptions(){var t;super.addSubscriptions(),null===(t=this.getState())||void 0===t||t.subscribe(a.Xe.ChartDateFilterChartType,this.updateChartType.bind(this),{signal:this.subscriptionController.signal})}onChartDictChange(t){const e=this.viewModel.chartData;var i,r;e&&t&&(e.chartSeries=null==t||null===(i=t[this.viewModel.quote.id])||void 0===i||null===(i=i.chartData)||void 0===i?void 0:i.series,e.chartBaseline=null==t||null===(r=t[this.viewModel.quote.id])||void 0===r?void 0:r.pricePreviousClose,this.viewModel={...this.viewModel,chartData:e})}onQuoteItemDictChange(t){var e;const i=null===(e=this.viewModel)||void 0===e||null===(e=e.quote)||void 0===e?void 0:e.id,r=null==t?void 0:t[i];r&&(this.viewModel={...this.viewModel,quote:{...r}})}}(0,r.Cg)([s.sH],n.prototype,"chartType",void 0);var l=i(92011),h=i(64003),c=i(61138),d=i(48751),p=i(41123),u=i(4968),g=i(12640),v=i(74849);const f=v.A` :host{--standard-grey:rgba(255,255,255,0.54) !important}`,x=v.A` :host{--standard-grey:rgba(0,0,0,0.54)}.currency{background:none;height:100%;border-radius:8px}.notf-ic{height:16px;padding-left:4px;padding-right:4px}.notf-ic svg{height:16px;width:16px}.sec-title-str{color:${h.c};
        margin: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: ${c.k};
        line-height: ${c.F};min-width:66px}.price{align-items:center;justify-content:flex-end;display:flex}.price-str{color:${d.l};
        font-weight: 600;
        font-size: ${p.K};
        line-height: ${p.Z};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}._1x_1y .sm-font .price-str{font-size:var(--type-ramp-base-font-size,14px) !important}._1x_2y .sm-font .price-str,._1x_3y .sm-font .price-str{font-size:var(--type-ramp-plus-3-font-size,24px) !important;line-height:var(--type-ramp-plus-3-line-height,32px) !important}.sl-quote{display:flex;flex-direction:column;justify-content:space-between;align-items:flex-start;height:100%;padding:12px;box-sizing:border-box;border-radius:6px;text-decoration:none;color:${d.l};
        ${u.f}}.sl-sm-left{min-width:0px}.sl-quote._1x_1y{display:grid;grid-column-gap:8px;grid-template-columns:48px 1fr min-content;padding:9px 12px !important;align-items:center}.currency-wrapper{height:100%;display:flex;flex-direction:column}.chart-wrapper{margin-top:auto;margin-bottom:0}.sl-quote .sec-title-str{font-weight:400;color:var(--standard-grey);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sl-quote._1x_1y .sec-title-str{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);color:${d.l}}.sl-quote .price-str{font-size:var(--type-ramp-plus-4-font-size,28px);line-height:var(--type-ramp-plus-4-line-height,36px)}.sl-quote._1x_1y .price-str{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px)}.sl-quote._1x_3y .price-str{font-weight:600;font-size:var(--type-ramp-plus-5-font-size,32px);line-height:var(--type-ramp-plus-5-line-height,40px)}.sl-price-row{display:grid;grid-template-columns:min-content 1fr;grid-gap:8px;align-items:baseline;margin-bottom:2px}.sl-quote .notf-tx{font-weight:600;font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);padding:0px 6px;display:-webkit-box;overflow:hidden;-webkit-line-clamp:2;-webkit-box-orient:vertical;text-overflow:ellipsis}.sl-quote._1x_1y .notf-tx{-webkit-line-clamp:1}.sl-quote._1x_3y .notf-tx{font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);display:flex;align-items:center}.sl-quote .glcn{display:flex;align-items:center}.sl-quote .glcn .notf-ic{line-height:16px;padding:0px}.sl-quote .glcn .notf-ic svg{width:16px;height:16px}.sl-quote._1x_3y .glcn .notf-ic{height:20px}.sl-quote._1x_3y .glcn .notf-ic svg{width:20px;height:20px}.change-pcnt{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);font-weight:600;height:20px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}._1x_1y .change-pcnt{text-align:end}.icn{display:flex}.icn,.icn img{width:28px;height:28px}.icn img{object-fit:contain}.sl-quote._1x_1y.curr{grid-template-columns:min-content 1fr min-content;height:auto}.sl-quote._1x_1y.curr .notf-tx{padding:0;margin-top:4px}.sl-quote._1x_1y.curr .price{margin-bottom:4px}.sl-quote._1x_1y.currency .sec-title-str{font-size:var(--type-ramp-minus-1-font-size,12px);line-height:var(--type-ramp-minus-1-line-height,16px)}.sl-quote._1x_1y.currency .price-str{line-height:var(--type-ramp-minus-1-line-height,16px)}.sm-disp-name{font-size:var(--type-ramp-base-font-size,14px);line-height:var(--type-ramp-base-line-height,20px);color:${h.c};overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sl-title-curr{grid-template-columns:1fr;grid-gap:2px;margin-bottom:4px}.sl-title-curr .sl-cur-name{margin:0}.sl-cur-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:var(--type-ramp-plus-1-font-size,16px);line-height:var(--type-ramp-plus-1-line-height,22px);font-weight:600;margin:0px 6px}.sl-cur-name.no-flag{margin:0px}.sl-quote._1x_3y .sl-cur-name{font-size:var(--type-ramp-plus-2-font-size,20px);line-height:var(--type-ramp-plus-2-line-height,28px)}.sl-quote .curr-info{position:relative;height:38px;width:100%;margin-bottom:6px}._1x_3y.sl-quote .curr-info{height:52px}.sl-quote .curr-top{display:flex;align-items:center}.sl-quote._1x_3y .curr-top{margin-bottom:2px}.sl-quote .curr-icon{height:18px;border-radius:2px}.sl-quote .curr-top svg{height:18px}.sl-quote._1x_1y.currency .icn,.sl-quote._1x_1y.currency .icn img{width:initial;height:38px;border-radius:2px;max-width:48px}.sl-quote.curr._1x_2y .sec-title-str,.sl-quote.curr._1x_3y .sec-title-str{max-width:120px}.curr-arr{position:absolute;left:108px}._1x_3y .curr-arr{top:4px}.curr-arr svg{width:16px;fill:${d.l}}.curr-info .from{position:absolute;left:0px}.curr-info .to{position:absolute;left:136px}.curr-info .from .sec-title-str{max-width:125px}.curr-info .to .sec-title-str{max-width:110px}.logo{width:16px;height:16px}.sl-quote._1x_3y .logo{width:20px;height:20px}.sp-hero.sl-quote{padding:0px}`.withBehaviors(new g.N(null,f));var m=i(96950),b=i(69259),y=i(89517),$=i.n(y),w=i(58792);const C=m.qy`<img src="${t=>{var e;return null===(e=t.quoteDataByChartType.notification)||void 0===e?void 0:e.iconUrl}}" class="notf-ic" alt="">`,k=m.qy`<span class="notf-tx ${t=>t.viewModel.quoteNotificationClass}" style="color: ${t=>{var e;return null===(e=t.quoteDataByChartType.notification)||void 0===e?void 0:e.accentColor}};">${t=>t.notificationText}</span>`,z=m.qy`<img src="${(0,w.rA)().StaticsUrl}latest/money/icons/StockEmptyStateCircle.svg" alt="">`,_=(t,e)=>m.qy` ${()=>t?m.qy`<img src="${e=>t}" alt="" class="curr-icon" loading=lazy onerror="this.style.display='none'" />`:z}
`,q=t=>m.qy`<div class="sec-title-str">${t}</div>`,D=m.qy`<div class="curr-info"><div class="from"><div class="curr-top">${(0,b.z)(t=>t.viewModel.shouldShowCurrencyFlag(t.viewModel.currencyData.from.symbol),m.qy` ${t=>_(t.viewModel.currencyData.from.iconUrl,t.viewModel.currencyData.from.displayName)} `)}<span class="sl-cur-name ${t=>t.viewModel.shouldShowCurrencyFlag(t.viewModel.currencyData.from.symbol)?"":"no-flag"}">${t=>t.viewModel.currencyData.from.shortName}</span></div>${t=>q(t.viewModel.currencyData.from.displayName)}</div><div class="curr-arr">${m.qy.partial($())}</div><div class="to"><div class="curr-top">${(0,b.z)(t=>t.viewModel.shouldShowCurrencyFlag(t.viewModel.currencyData.to.symbol),m.qy` ${t=>_(t.viewModel.currencyData.to.iconUrl,t.viewModel.currencyData.to.displayName)} `)}<span class="sl-cur-name ${t=>t.viewModel.shouldShowCurrencyFlag(t.viewModel.currencyData.to.symbol)?"":"no-flag"}">${t=>t.viewModel.currencyData.to.shortName}</span></div>${t=>q(t.viewModel.currencyData.to.displayName)}</div></div>`,P=m.qy`<div class="price ${t=>t.viewModel.hasSmallPriceFont?"sm-font":""}"><span class="price-str">${t=>t.viewModel.quote.price}</span></div>`,T=m.qy`<div class="change-pcnt" style="color: ${t=>t.changePcntColor};" aria-label="${t=>t.viewModel.quoteChangeAriaLabel}">&lrm;${t=>t.viewModel.quote.priceNumber?t.changePcnt:"-"}&lrm;</div>`,F=m.qy`<div class="sl-price-row">${P} ${T}</div>`,M=m.qy`<div class="glcn">${C} ${k}</div>`,S=m.qy`<div class="icn">${t=>""===t.viewModel.iconUrl?z:m.qy`<img src="${t=>t.viewModel.iconUrl}" alt="" loading=lazy onerror="this.style.display='none'" />`}</div>`,A=m.qy`<div class="chart-wrapper">${(0,b.z)(t=>t.viewModel.dateFilterChartData,m.qy`<date-filter-chart :viewModel="${t=>t.viewModel.dateFilterChartData}"></date-filter-chart>`)}</div>`,N=m.qy`<div class="currency-wrapper">${D} ${F} ${(0,b.z)(t=>t.quoteDataByChartType.notification,M)} ${A}</div>`,B=m.qy`<div class="sm-disp-name">${t=>t.viewModel.currencyData.from.displayName}</div>`,L=m.qy` ${(0,b.z)(t=>t.viewModel.shouldShowCurrencyFlag(t.viewModel.quote.currency||""),S)}<div class="sl-sm-left"><div class="sec-title-str">${t=>t.viewModel.quote.symbol}</div><div>${(0,b.z)(t=>t.quoteDataByChartType.notification,M)} ${(0,b.z)(t=>!t.quoteDataByChartType.notification,B)}</div></div><div class="sl-sm-right">${P} ${T}</div>`,H=m.qy`<a class="sl-quote currency ${t=>t.viewModel.cardSize} ${t=>t.viewModel.isSpotlightHero?"sp-hero":""}" href="${t=>t.viewModel.destinationUrl}" target="${t=>t.viewModel.openLinksInNewTab?"_blank":"_self"}" data-t="${t=>t.viewModel.telemetryTag}" role="link" tabindex="-1" aria-label="${t=>t.viewModel.quoteRowAriaLabel}" title="${t=>t.viewModel.quote.tooltipText}">${t=>"_1x_1y"===t.viewModel.cardSize?L:N}</a>`,I=m.qy` ${(0,b.z)(t=>t&&t.viewModel,H)}
`;let W=class extends n{};W=(0,r.Cg)([(0,l.E)({name:"spotlight-currency",template:I,styles:x,shadowOptions:{delegatesFocus:!0}})],W)},76725(t,e,i){"use strict";i.r(e),i.d(e,{DateFilterChartTransformer(){return r.i},MSNStockChartTransformer(){return a.u},SpotlightCurrencyTransformer(){return u}});var r=i(84953),a=i(88015),o=i(27208),s=i(54229),n=i(49150),l=i(93552),h=i(86449),c=i(58792),d=i(30236),p=i(96950);class u extends o.IB{async transform(t){var e;this.quote=t.quote,this.cardSize=t.cardSize,this.isDarkModeTheme=(0,h.jJ)(),this.previewType=t.previewType,this.notifications=null===(e=t.quoteNotificationDetails)||void 0===e?void 0:e[this.quote.id],(0,h.ih)(this.quote,t.tabName),await this.updateCurrencyData();const i=await this.getCurrentViewModel(t);return{viewTemplate:p.qy`
                <spotlight-currency
                    :viewModel="${i}"
                ></spotlight-currency>`}}getAccentColor(t){return(0,h.BK)(this.isDarkModeTheme,t||0,this.transformerProvider.config.swapGainLossColor)}getNotfIconUrl(t,e){var i;return(0,d.kX)(this.transformerProvider.config.urls,e||0,null==t?void 0:t.notificationType,this.transformerProvider.config.swapGainLossColor,null==t||null===(i=t.notification)||void 0===i?void 0:i.signal)}getNotificationsInfo(t){const e=this.getNotificationData(t);return e?{iconUrl:this.getNotfIconUrl(e,t),shortHeadline:e.shortHeadline,accentColor:(0,h.bQ)(e,{...this.quote,changePcntNumber:t},this.isDarkModeTheme,this.transformerProvider.config.swapGainLossColor)}:null}getNotificationData(t){const e=(0,h.U7)(this.previewType,this.notifications);if(null!=e&&e.length)return e[0];{const{pricePctNotfThresholdMarket:e,pricePctNotfBaseline:i,disableNotificationForVp:r}=this.transformerProvider.config,a={...this.quote,changePcntNumber:t};if((0,h.Uj)(a,e,i,r))return(0,h.nW)(a,[],this.transformerProvider.strings,!0)}}getQuoteDataByChartType(t,e,i){return{accentColor:this.getAccentColor(i),notification:t===o.NB.OneDayOneMinute?this.getNotificationsInfo(i):null,changePcnt:this.getChangePcnt(t,e)}}getChangePcnt(t,e){var i;if(this.cardSize===n.uE._1x_1y)return e;const{changePcntPeriod5D:r,changePcntPeriod1W:a,changePcntPeriod1M:s,changePcntPeriod3M:l,changePcntPeriod1Y:h,changePcntPeriod5Y:c,changePcntPeriodAll:d}=this.transformerProvider.strings;return(null===(i={[o.NB.OneDayOneMinute]:"{0}",[o.NB.FiveDays]:r,[o.NB.OneWeekFifteenMinutes]:a,[o.NB.OneMonth]:s,[o.NB.ThreeMonth]:l,[o.NB.OneYear]:h,[o.NB.FiveYear]:c,[o.NB.All]:d}[t])||void 0===i?void 0:i.replace("{0}",e||""))||""}async updateDateFilterChartData(t){if(!this.chartData)return void(this.dateFilterChartData=void 0);const e=this.getChartChangePcntNumber(t),i={experienceName:t.experienceName,chartData:this.chartData,accentColor:this.getAccentColor(e||0),quote:t.quote,chartHeight:this.getChartHeight(),chartWidth:this.chartWidth,telemetryObject:t.telemetryObject,previousCloseText:(0,h.Fq)(this.chartPricePreviousClose,this.transformerProvider.strings.previousClose)},r=await this.transformerProvider.generateView(i,o.Ai.DateFilterChart);this.dateFilterChartData=r.viewModel}async updateAllChartData(t){this.cardSize!==n.uE._1x_1y&&(this.chartData=await this.generateChartData(t)),await this.updateDateFilterChartData(t)}getChartChangePcntNumber(t){var e,i;return(0,h.tc)(null===(e=t.chartData)||void 0===e?void 0:e.chartType,!1,null===(i=t.chartData)||void 0===i?void 0:i.changePcntNumber,t.quote.changePcntNumber)}async getCurrentViewModel(t){const e=[];e.push(this.updateAllChartData(t)),await Promise.allSettled(e);const{isChartAnimationEnabled:i,chartAnimationDuration:r,openLinksInNewTab:a}=this.transformerProvider.config;return{telemetryTag:this.transformerProvider.telemetryBuilder.createNavClickTelemetryTag(t.telemetryObject,{name:o.CD.quoteItemClick,signature:t.signature,headline:t.destinationUrl}),cardSize:this.cardSize,experienceName:t.experienceName,destinationUrl:t.destinationUrl,isChartAnimationEnabled:i,chartAnimationDuration:r,quote:this.quote,quoteChangeAriaLabel:this.quoteChangeAriaLabel,quoteRowAriaLabel:this.quoteRowAriaLabel,shouldShowCurrencyFlag:this.shouldShowCurrencyFlag,getQuoteDataByChartType:this.getQuoteDataByChartType.bind(this),currencyData:this.currencyData,chartData:this.chartData,chartHeight:this.getChartHeight(),chartWidth:this.chartWidth,isSpotlightHero:(0,h.Fm)(t.experienceName),dateFilterChartData:this.dateFilterChartData,isDarkModeTheme:this.isDarkModeTheme,previousCloseText:(0,h.Fq)(this.chartPricePreviousClose,this.transformerProvider.strings.previousClose),enableBaselineText:!0,enableChangePcntText:!0,openLinksInNewTab:a,iconUrl:this.currencyData.from.iconUrl,hasSmallPriceFont:(0,h.we)(this.cardSize,this.quote.price)}}async generateChartData(t){const{quote:e,chartData:i,cardSize:r}=t,a={quote:e,chartData:i,cardSize:r};return(await this.transformerProvider.generateView(a,o.Ai.MSNStockChart)).viewModel}get chartPricePreviousClose(){var t;return(null===(t=this.chartData)||void 0===t?void 0:t.chartBaselineLoc)||""}get chartWidth(){return 244}getChartHeight(){return this.cardSize===n.uE._1x_2y?70:192}shouldShowCurrencyFlag(t){return(0,h.Kb)(t,c.T3.CurrentMarket)}useSymbolTitle(){return(0,h.Mx)(this.quote)&&this.quote&&!!this.quote.displayName&&this.quote.displayName.includes("/")}updateCurrencyData(){s.aC.safeExecute(()=>{if(this.useSymbolTitle()&&this.quote.displayName){const[t,e]=this.quote.displayName.split("/"),[i,r]=this.quote.symbol.split("/"),a=this.transformerProvider.config.currencySymbols,o=a[i]??"",s=a[r]??"";this.currencyData={from:{displayName:t,shortName:`${i} ${o}`,iconUrl:(0,h.A0)(i),symbol:i},to:{displayName:e,shortName:`${r} ${s}`,iconUrl:(0,h.A0)(r),symbol:r}}}},void 0,l.$B_,`MoneyInfo - Spotlight Currency - error while parsing displayName and symbol "${this.quote.id}"`)}get quoteChangeAriaLabel(){return`${this.quote.changePcnt} ${this.quote.displayName} ${this.quote.changeValue}`}get quoteRowAriaLabel(){let t;return t=this.quote.gain||this.quote.unchanged?this.transformerProvider.strings.increasedByText:this.transformerProvider.strings.decreasedByText,`${this.quote.symbol}, ${this.quote.displayName}. ${this.transformerProvider.strings.priceIsText} ${this.quote.price}. ${t} ${this.quote.changePcnt}`}}Promise.resolve().then(i.bind(i,62376)),Promise.resolve().then(i.bind(i,92510)),Promise.resolve().then(i.bind(i,1817))},84953(t,e,i){"use strict";i.d(e,{i(){return s}});var r=i(27208),a=i(86449),o=i(85349);class s extends r.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getFilterButtonsList(t){const{cryptos:e,deprecatedToNewCryptos:i}=this.transformerProvider.config,o=(0,a.qA)(e,i,t.quote),{dateChartFilter1D:s,dateChartFilter5D:n,dateChartFilter1M:l,dateChartFilter3M:h,dateChartFilter1Y:c,dateChartFilter5Y:d,dateChartFilterAll:p}=this.transformerProvider.strings,{OneDayOneMinute:u,OneWeekFifteenMinutes:g,FiveDays:v,OneMonth:f,ThreeMonth:x,OneYear:m,FiveYear:b,All:y}=r.NB;return[{id:u,title:s},{id:o?g:v,title:n},{id:f,title:l},{id:m,title:c},{id:b,title:d},{id:y,title:p}].map(e=>({...e,telemetryTag:this.getButtonTelemetryTag(t,e.id)}))}getButtonTelemetryTag(t,e){return this.transformerProvider.telemetryBuilder.createBehaviorTelemetryTag(t.telemetryObject,{name:r.CD.MoneyDateFilterChartButtonClick,headline:e},o.MS.Click)}async getViewModel(t){const{swapGainLossColor:e,isChartAnimationEnabled:i,chartAnimationDuration:r}=this.transformerProvider.config,o=(0,a.Fm)(t.experienceName);return{experienceName:t.experienceName,chartData:t.chartData,accentColor:t.accentColor,baselineColor:o?(0,a.Bp)((0,a.jJ)()):t.accentColor,quote:t.quote,isDarkModeTheme:(0,a.jJ)(),handleDateFilterChartChange:this.transformerProvider.handleDateFilterChartChange,positiveColor:(0,a.BK)((0,a.jJ)(),1,e),negativeColor:(0,a.BK)((0,a.jJ)(),-1,e),isChartAnimationEnabled:i,chartAnimationDuration:r,chartHeight:t.chartHeight,chartWidth:t.chartWidth,enableBaselineText:!0,previousCloseText:t.previousCloseText,filterButtonsList:this.getFilterButtonsList(t),isSpotlightHero:o,strings:{dataIsNotAvailable:this.transformerProvider.strings.dataIsNotAvailable},telemetryTag:""}}}},88015(t,e,i){"use strict";i.d(e,{u(){return s}});var r=i(27208),a=i(49150),o=i(86449);class s extends r.IB{async transform(t){return{viewModel:await this.getViewModel(t)}}getChartFillColor(t){return t?(0,o.BK)((0,o.jJ)(),t.changePcntNumber||0,this.transformerProvider.config.swapGainLossColor):""}chartPricePreviousClose(t){return t?t.pricePreviousClose:void 0}getChartWidth(t){return t.cardSize===a.uE._1x_1y?104:32}getChartHeight(t){return t.cardSize===a.uE._1x_1y?18:28}getChangePcnt(t){var e,i;return(0,o.tc)(null===(e=t.chartData)||void 0===e?void 0:e.chartType,!1,null===(i=t.chartData)||void 0===i?void 0:i.changePcnt,t.quote.changePcnt)}async getViewModel(t){var e,i,r;return{chartId:t.quote.id,chartWidth:this.getChartWidth(t),chartHeight:this.getChartHeight(t),chartFillColor:this.getChartFillColor(t.quote),chartData:t.chartData,baselineFillColor:this.getChartFillColor(t.quote),baseLineText:"",chartBaseline:this.chartPricePreviousClose(null==t?void 0:t.chartData),chartBaselineLoc:null==t||null===(e=t.chartData)||void 0===e?void 0:e.pricePreviousCloseLoc,isDarkModeTheme:!1,isSpotlight:!1,enableBaselineText:!0,enableChangePcntText:!0,changePcnt:this.getChangePcnt(t)||"",chartSeries:null===(i=t.chartData)||void 0===i||null===(i=i.chartData)||void 0===i?void 0:i.series,pricesMaxCount:null===(r=t.chartData)||void 0===r||null===(r=r.chartData)||void 0===r?void 0:r.total,telemetryTag:"",cardSize:t.cardSize}}}},89517(t){t.exports='<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M10.84 2.63a.5.5 0 00-.68.74L16.33 9H2.5a.5.5 0 000 1h13.83l-6.17 5.63a.5.5 0 00.68.74l6.91-6.32a.75.75 0 000-1.1l-6.91-6.32z"></path></svg>'},92707(t,e,i){"use strict";i.d(e,{z(){return l}});var r=i(56911),a=i(27208),o=i(60815),s=i(92011),n=i(31525);let l=class extends s.L{constructor(){super(...arguments),this.subscriptionController=new AbortController}connected(){this.initHandlers(),this.addSubscriptions()}disconnected(){this.removeSubscriptions()}removeSubscriptions(){this.subscriptionController.abort()}getState(){return a.vP.get(this.viewModel.experienceName)||null}addSubscriptions(){if(this.viewModel.experienceName){const t=this.getState();t&&(t.subscribe(a.Xe.CardSize,this.onSizeChangeHandlerScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.ChartItemDict,this.onChartItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.showNotificationText,this.onShowNotificationTextChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.QuoteItemDict,this.onQuoteItemDictChangeScoped,{signal:this.subscriptionController.signal}),t.subscribe(a.Xe.CardWidth,this.onCardWidthChangedScoped,{signal:this.subscriptionController.signal}))}}initHandlers(){this.onSizeChangeHandlerScoped=this.onSizeChange.bind(this),this.onChartItemDictChangeScoped=this.onChartDictChange.bind(this),this.onShowNotificationTextChangeScoped=this.onShowNotificationTextChange.bind(this),this.onQuoteItemDictChangeScoped=this.onQuoteItemDictChange.bind(this),this.onCardWidthChangedScoped=this.onCardWidthChanged.bind(this)}onSizeChange(t){}onChartDictChange(t){}onShowNotificationTextChange(t){}onQuoteItemDictChange(t){}onCardWidthChanged(t){}};(0,r.Cg)([o.sH],l.prototype,"viewModel",void 0),l=(0,r.Cg)([n.x],l)},99657(t,e,i){"use strict";i.d(e,{D(){return s},I(){return o}});var r=i(45755);const{create:a}=r.G,o=a("sloppy-click-z-index",1),s=a("click-z-index",1)}}]);